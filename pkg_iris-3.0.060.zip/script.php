<?php

/**
 * @package     Iris
 * @subpackage  pkg_iris
 * @copyright   (C) 2026 Cyrille Poussin, Joomanji
 * @license     GNU General Public License version 2 or later
 *
 * LE SCRIPT DU PAQUET. Quatre choses, et seulement celles-la.
 *
 *  1. AVANT : refuser un Joomla plus ancien que 6. Iris n'est mesure que sur
 *     Joomla 6, et le coeur dont il reprend les champs et les fenetres a
 *     change depuis la 5.
 *
 *  2. APRES UNE PREMIERE POSE : activer le plugin systeme, le plugin de
 *     contenu et le bouton de l'editeur, qui arrivent eteints par defaut. Seulement s'ils n'existaient
 *     pas avant : un plugin que l'administrateur a eteint le reste.
 *
 *  3. APRES : retirer l'ancien serveur de mise a jour du plugin seul
 *     (`plg_system_iris.xml`). Les sites en Iris 2.x le consultent encore, et
 *     c'est par lui qu'ils recoivent ce paquet ; une fois le paquet pose,
 *     seul `pkg_iris.xml` fait foi. Sans ce retrait, chaque nouvelle version
 *     serait proposee deux fois. Joomla ne le retire pas de lui-meme :
 *     `plugins/extension/joomla`, `processUpdateSites()`, ne fait qu'ajouter
 *     (lu dans Joomla 6.1.3).
 *
 *  4. LES FORMATS : autoriser dans com_media ceux que demandent les Options
 *     d'Iris, et les retirer a la desinstallation (FormatsHelper).
 *
 *  5. APRES : rendre au coeur le site des traductions s'il porte l'adresse
 *     d'Iris (voir reparerSiteGreffe(), ajoute a 3.0.060 le 10 octobre 2026).
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            InstallerScriptInterface::class,
            new class ($container->get(DatabaseInterface::class)) implements InstallerScriptInterface {
                /**
                 * Les plugins a allumer a la premiere pose : [dossier, element].
                 *
                 * LE PLUGIN SYSTEME EN FAIT PARTIE (3.0.032). Il manquait : sur un
                 * site neuf, il arrivait eteint, et avec lui les pastilles et le
                 * rangement d'Iris dans le menu Contenu (Iris restait dans
                 * Composants). Vu par Cyrille sur un site en production le
                 * 30 septembre 2026 ; le banc ne le montrait pas, le plugin y
                 * existait deja avant le paquet.
                 */
                private const A_ALLUMER = [['system', 'iris'], ['content', 'iris'], ['editors-xtd', 'iris']];

                /** Ceux qui existaient deja avant cette pose. */
                private array $existants = [];

                public function __construct(private DatabaseInterface $db)
                {
                }

                public function install(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function update(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function uninstall(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function preflight(string $type, InstallerAdapter $adapter): bool
                {
                    // A LA DESINSTALLATION, com_media retrouve ses listes : Iris
                    // retire les formats qu'il y avait ajoutes, et eux seuls.
                    // Maintenant, tant que com_iris est encore la.
                    if ($type === 'uninstall') {
                        if ($this->formats()) {
                            \Cyrille\Component\Iris\Administrator\Helper\FormatsHelper::appliquer(true);
                        }

                        // Les miniatures des PDF : Joomla ne retire que les
                        // dossiers nommes dans le manifeste (css, js).
                        $mini = JPATH_ROOT . '/media/com_iris/miniatures';

                        if (is_dir($mini)) {
                            \Joomla\Filesystem\Folder::delete($mini);
                        }

                        return true;
                    }

                    /*
                     * LA VERSION DE JOOMLA VISEE (regle de Cyrille du 5 octobre
                     * 2026) : nos produits suivent la derniere version mineure.
                     * 3.0.055 est faite pour 6.1 et 6.2, et refuse plus ancien,
                     * avec un message qui dit quoi faire.
                     */
                    if (version_compare(JVERSION, '6.1.0', '<')) {
                        Factory::getApplication()->enqueueMessage(Text::sprintf('PKG_IRIS_JOOMLA_6', JVERSION), 'error');

                        return false;
                    }

                    foreach (self::A_ALLUMER as [$dossier, $element]) {
                        if ($this->idPlugin($dossier, $element) > 0) {
                            $this->existants[] = $dossier . '/' . $element;
                        }
                    }

                    return true;
                }

                public function postflight(string $type, InstallerAdapter $adapter): bool
                {
                    if ($type === 'uninstall') {
                        return true;
                    }

                    foreach (self::A_ALLUMER as [$dossier, $element]) {
                        if (!\in_array($dossier . '/' . $element, $this->existants, true)) {
                            $this->allumer($dossier, $element);
                        }
                    }

                    $this->retirerAncienServeur();
                    $this->reparerSiteGreffe();
                    $this->retirerAncienManifeste();

                    // Les formats demandes par les Options d'Iris (par defaut :
                    // docx, xlsx, pptx) sont autorises dans com_media.
                    if ($this->formats()) {
                        \Cyrille\Component\Iris\Administrator\Helper\FormatsHelper::appliquer();
                    }

                    return true;
                }

                /**
                 * La classe des formats, chargee a la main si besoin : juste
                 * apres la pose de com_iris, son espace de noms n'est pas
                 * forcement connu du chargeur de cette requete.
                 */
                private function formats(): bool
                {
                    $classe = \Cyrille\Component\Iris\Administrator\Helper\FormatsHelper::class;

                    if (!class_exists($classe)) {
                        $fichier = JPATH_ADMINISTRATOR . '/components/com_iris/src/Helper/FormatsHelper.php';

                        if (is_file($fichier)) {
                            require_once $fichier;
                        }
                    }

                    return class_exists($classe);
                }

                private function idPlugin(string $dossier, string $element): int
                {
                    $query = $this->db->getQuery(true)
                        ->select($this->db->quoteName('extension_id'))
                        ->from($this->db->quoteName('#__extensions'))
                        ->where($this->db->quoteName('type') . ' = ' . $this->db->quote('plugin'))
                        ->where($this->db->quoteName('folder') . ' = :dossier')
                        ->where($this->db->quoteName('element') . ' = :element')
                        ->bind(':dossier', $dossier)
                        ->bind(':element', $element);

                    return (int) $this->db->setQuery($query)->loadResult();
                }

                private function allumer(string $dossier, string $element): void
                {
                    $id = $this->idPlugin($dossier, $element);

                    if ($id === 0) {
                        return;
                    }

                    $query = $this->db->getQuery(true)
                        ->update($this->db->quoteName('#__extensions'))
                        ->set($this->db->quoteName('enabled') . ' = 1')
                        ->where($this->db->quoteName('extension_id') . ' = :id')
                        ->bind(':id', $id, ParameterType::INTEGER);
                    $this->db->setQuery($query)->execute();
                }

                /**
                 * Le lien entre le plugin et l'ancien serveur, puis le serveur
                 * lui-meme s'il ne sert plus a personne.
                 */
                /**
                 * LE MANIFESTE DU COMPOSANT S'APPELLE iris.xml DEPUIS 3.0.044.
                 *
                 * Joomla cherche le manifeste d'un composant sous le nom de
                 * l'element sans « com_ » (InstallerHelper::getInstallationXML :
                 * administrator/components/com_iris/iris.xml). Nomme
                 * com_iris.xml, il n'etait pas trouve : Systeme, Base de donnees
                 * signalait « Un probleme » (version de la base 3.0.0xx contre
                 * « Iris version () »). Une mise a jour laisse l'ancien
                 * com_iris.xml dans le dossier : on le retire, une fois le
                 * nouveau en place.
                 */
                private function retirerAncienManifeste(): void
                {
                    $dossier = JPATH_ADMINISTRATOR . '/components/com_iris';

                    if (is_file($dossier . '/iris.xml') && is_file($dossier . '/com_iris.xml')) {
                        @unlink($dossier . '/com_iris.xml');
                    }
                }

                /**
                 * LE SITE DES TRADUCTIONS QUI PORTE L'ADRESSE D'IRIS.
                 *
                 * La panne, vue par Cyrille le 10 octobre 2026 sur asso-arsi.com
                 * (Joomla 6.1.4, Iris 3.0.041) : aucune mise a jour d'Iris n'est
                 * proposee, alors que pkg_iris.xml annonce 3.0.060. Dans Sites de
                 * mise a jour, la fiche n° 2 « Accredited Joomla! Translations »,
                 * de type « collection », porte l'adresse pkg_iris.xml et sert a
                 * la fois au pack en-GB et a Iris. Joomla lit donc le xml d'Iris
                 * comme une liste de traductions, n'y trouve rien et ne propose
                 * rien ; et le pack de langue a perdu ses traductions.
                 *
                 * Le mecanisme (plugins/extension/joomla, addUpdateSite(), Joomla
                 * 6.1) : quand aucune fiche ne porte l'adresse du manifeste et que
                 * l'extension est deja reliee a une fiche, Joomla REECRIT
                 * l'adresse de cette fiche au lieu d'en creer une. Il a suffi
                 * qu'Iris soit relie a la fiche n° 2 (lien orphelin laisse par une
                 * extension desinstallee qui avait le meme extension_id, c'est
                 * l'hypothese la plus probable, non prouvee) pour que l'adresse
                 * des traductions soit ecrasee.
                 *
                 * « Reconstruire » ne repare rien : les fiches 1 a 3 du coeur sont
                 * conservees telles quelles (essaye sur asso-arsi.com), et la
                 * fiche du coeur est en lecture seule dans l'administration.
                 *
                 * La reparation, ici, en postflight, donc AVANT que Joomla traite
                 * les serveurs du manifeste (onExtensionAfterUpdate) :
                 *  - toute fiche qui n'est pas de type « extension » et porte
                 *    l'adresse d'Iris est detachee d'Iris ;
                 *  - si d'autres extensions s'en servent encore, elle retrouve
                 *    l'adresse des traductions, relue dans le manifeste du pack
                 *    en-GB ; sinon elle est retiree ;
                 *  - Joomla ne trouve plus alors ni adresse ni lien, et cree pour
                 *    Iris une fiche neuve, de type « extension ».
                 */
                private function reparerSiteGreffe(): void
                {
                    $db = $this->db;

                    $query = $db->getQuery(true)
                        ->select($db->quoteName('update_site_id'))
                        ->from($db->quoteName('#__update_sites'))
                        ->where($db->quoteName('location') . ' LIKE ' . $db->quote('%/pkg_iris.xml'))
                        ->where($db->quoteName('type') . ' <> ' . $db->quote('extension'));
                    $sites = array_map('intval', $db->setQuery($query)->loadColumn());

                    if (!$sites) {
                        return;
                    }

                    $query = $db->getQuery(true)
                        ->select($db->quoteName('extension_id'))
                        ->from($db->quoteName('#__extensions'))
                        ->where($db->quoteName('type') . ' = ' . $db->quote('package'))
                        ->where($db->quoteName('element') . ' = ' . $db->quote('pkg_iris'));
                    $paquet = (int) $db->setQuery($query)->loadResult();

                    foreach ($sites as $site) {
                        if ($paquet > 0) {
                            $query = $db->getQuery(true)
                                ->delete($db->quoteName('#__update_sites_extensions'))
                                ->where($db->quoteName('update_site_id') . ' = :site')
                                ->where($db->quoteName('extension_id') . ' = :eid')
                                ->bind(':site', $site, ParameterType::INTEGER)
                                ->bind(':eid', $paquet, ParameterType::INTEGER);
                            $db->setQuery($query)->execute();
                        }

                        $query = $db->getQuery(true)
                            ->delete($db->quoteName('#__updates'))
                            ->where($db->quoteName('update_site_id') . ' = :site')
                            ->bind(':site', $site, ParameterType::INTEGER);
                        $db->setQuery($query)->execute();

                        $query = $db->getQuery(true)
                            ->select('COUNT(*)')
                            ->from($db->quoteName('#__update_sites_extensions'))
                            ->where($db->quoteName('update_site_id') . ' = :site')
                            ->bind(':site', $site, ParameterType::INTEGER);
                        $restants = (int) $db->setQuery($query)->loadResult();

                        if ($restants > 0) {
                            $adresse = $this->adresseTraductions();
                            $query   = $db->getQuery(true)
                                ->update($db->quoteName('#__update_sites'))
                                ->set($db->quoteName('location') . ' = :adresse')
                                ->set($db->quoteName('last_check_timestamp') . ' = 0')
                                ->where($db->quoteName('update_site_id') . ' = :site')
                                ->bind(':adresse', $adresse)
                                ->bind(':site', $site, ParameterType::INTEGER);
                            $db->setQuery($query)->execute();

                            continue;
                        }

                        $query = $db->getQuery(true)
                            ->delete($db->quoteName('#__update_sites'))
                            ->where($db->quoteName('update_site_id') . ' = :site')
                            ->bind(':site', $site, ParameterType::INTEGER);
                        $db->setQuery($query)->execute();
                    }
                }

                /**
                 * L'adresse des traductions officielles, relue dans le manifeste
                 * du pack en-GB (toujours present) plutot qu'ecrite en dur : elle
                 * change a chaque version majeure de Joomla.
                 */
                private function adresseTraductions(): string
                {
                    $manifeste = JPATH_ADMINISTRATOR . '/manifests/packages/pkg_en-GB.xml';

                    if (is_file($manifeste)) {
                        $xml = @simplexml_load_file($manifeste);

                        if ($xml && isset($xml->updateservers->server)) {
                            $adresse = trim((string) $xml->updateservers->server);

                            if ($adresse !== '') {
                                return $adresse;
                            }
                        }
                    }

                    return 'https://update.joomla.org/language/translationlist_' . (int) JVERSION . '.xml';
                }

                private function retirerAncienServeur(): void
                {
                    $query = $this->db->getQuery(true)
                        ->select($this->db->quoteName('update_site_id'))
                        ->from($this->db->quoteName('#__update_sites'))
                        ->where($this->db->quoteName('location') . ' LIKE ' . $this->db->quote('%/plg_system_iris.xml'));
                    $sites = array_map('intval', $this->db->setQuery($query)->loadColumn());

                    foreach ($sites as $site) {
                        $query = $this->db->getQuery(true)
                            ->delete($this->db->quoteName('#__update_sites_extensions'))
                            ->where($this->db->quoteName('update_site_id') . ' = :site')
                            ->bind(':site', $site, ParameterType::INTEGER);
                        $this->db->setQuery($query)->execute();

                        $query = $this->db->getQuery(true)
                            ->delete($this->db->quoteName('#__update_sites'))
                            ->where($this->db->quoteName('update_site_id') . ' = :site')
                            ->bind(':site', $site, ParameterType::INTEGER);
                        $this->db->setQuery($query)->execute();

                        $query = $this->db->getQuery(true)
                            ->delete($this->db->quoteName('#__updates'))
                            ->where($this->db->quoteName('update_site_id') . ' = :site')
                            ->bind(':site', $site, ParameterType::INTEGER);
                        $this->db->setQuery($query)->execute();
                    }
                }
            }
        );
    }
};
