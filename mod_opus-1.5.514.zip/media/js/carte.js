/**
 * LA CARTE D'OPUS - 3 octobre 2026
 *
 * SANS BIBLIOTHEQUE. Quelques centaines de lignes posent les fonds
 * d'OpenStreetMap, les reperes, le deplacement, le zoom et l'itineraire du
 * visiteur jusqu'a un lieu. Leaflet aurait fait la meme chose avec dix fois
 * plus de code, une feuille de style a lui et des mises a jour a suivre.
 *
 * RIEN N'EST DEMANDE A OPENSTREETMAP AVANT LE CLIC. La zone montre les
 * reperes sur un fond neutre et un bouton « Afficher la carte ». Le clic
 * charge les tuiles ; « Itineraire jusqu'ici » aussi, puisqu'il faut la carte
 * pour dessiner le trajet.
 *
 * L'ITINERAIRE : la position du visiteur (le navigateur lui demande son
 * accord) ou une adresse qu'il tape, puis le service d'itineraires
 * d'OpenStreetMap (routing.openstreetmap.de, FOSSGIS). Un calcul par clic,
 * jamais en boucle : c'est la condition d'usage du service.
 *
 * AU CLAVIER : la zone se prend au clavier une fois chargee ; les fleches la
 * deplacent, plus et moins zooment. La liste des lieux reste le contenu.
 */
(function () {
	'use strict';

	var TUILE = 256;
	var TUILES = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
	var ROUTE = 'https://routing.openstreetmap.de/{p}/route/v1/driving/{a};{b}?overview=full&geometries=geojson';
	var CHERCHE = 'https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q=';
	var PROFILS = { pied: 'routed-foot', velo: 'routed-bike', voiture: 'routed-car' };
	var OSRM = { pied: 'foot', velo: 'bike', voiture: 'car' };
	var GOOGLE = { pied: 'walking', velo: 'bicycling', voiture: 'driving' };

	/* --- Mercator : degres <-> pixels du monde au zoom z ------------------- */
	function versPixels(lat, lon, z) {
		var n = TUILE * Math.pow(2, z);
		var s = Math.sin(Math.max(-85, Math.min(85, lat)) * Math.PI / 180);

		return {
			x: (lon + 180) / 360 * n,
			y: (0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI)) * n
		};
	}

	function versDegres(x, y, z) {
		var n = TUILE * Math.pow(2, z);
		var lon = x / n * 360 - 180;
		var m = Math.PI - 2 * Math.PI * y / n;

		return { lat: 180 / Math.PI * Math.atan(0.5 * (Math.exp(m) - Math.exp(-m))), lon: lon };
	}

	function el(nom, classe, texte) {
		var e = document.createElement(nom);

		if (classe) { e.className = classe; }
		if (texte != null) { e.textContent = texte; }

		return e;
	}

	function nombre(v, dec) {
		try {
			return new Intl.NumberFormat(document.documentElement.lang || undefined, { maximumFractionDigits: dec }).format(v);
		} catch (x) {
			return String(Math.round(v * Math.pow(10, dec)) / Math.pow(10, dec));
		}
	}

	function duree(s) {
		var min = Math.max(1, Math.round(s / 60));

		return min < 60 ? min + ' min' : Math.floor(min / 60) + ' h ' + String(min % 60).padStart(2, '0');
	}

	function distance(m) {
		return m < 1000 ? nombre(Math.round(m / 10) * 10, 0) + ' m' : nombre(m / 1000, 1) + ' km';
	}

	/* --- Une carte ---------------------------------------------------------- */
	function Carte(racine) {
		var d;

		try { d = JSON.parse(racine.getAttribute('data-opus-carte') || '{}'); } catch (x) { return; }

		this.racine = racine;
		this.d = d;
		this.t = d.textes || {};
		this.zone = racine.querySelector('.opus__carte-zone');
		this.trajetBoite = racine.querySelector('.opus__carte-trajet');
		this.lieux = (d.lieux || []).filter(function (l) { return typeof l.lat === 'number' && typeof l.lon === 'number'; });
		this.chargee = false;
		this.mode = 'pied';
		this.route = null;
		this.depart = null;
		this.cible = null;

		if (!this.zone || !this.lieux.length) { return; }

		var bouton = this.zone.querySelector('.opus__carte-afficher');
		var moi = this;

		if (bouton) {
			bouton.hidden = false;
			bouton.addEventListener('click', function () { moi.charger(true); });
		}

		[].slice.call(racine.querySelectorAll('.opus__carte-route')).forEach(function (b) {
			b.hidden = false;
			b.addEventListener('click', function () { moi.itineraire(+b.getAttribute('data-n'), b); });
		});
	}

	Carte.prototype.charger = function (focus) {
		if (this.chargee) { return; }

		this.chargee = true;

		var z = this.zone;
		var moi = this;

		z.classList.add('opus__carte-zone--chargee');
		z.textContent = '';
		z.tabIndex = 0;

		this.calqueTuiles = el('div', 'opus__carte-tuiles');
		this.calqueTrace = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
		this.calqueTrace.setAttribute('class', 'opus__carte-trace');
		this.calqueTrace.setAttribute('aria-hidden', 'true');
		this.chemin = document.createElementNS('http://www.w3.org/2000/svg', 'path');
		this.calqueTrace.appendChild(this.chemin);
		this.calqueReperes = el('div', 'opus__carte-reperes');
		this.calqueReperes.setAttribute('aria-hidden', 'true');

		z.appendChild(this.calqueTuiles);
		z.appendChild(this.calqueTrace);
		z.appendChild(this.calqueReperes);

		// Les reperes de la liste servent de modele : meme couleur, meme contenu.
		this.reperes = this.lieux.map(function (l) {
			var ligne = moi.racine.querySelector('.opus__carte-lieu[data-n="' + l.n + '"]');
			var modele = ligne ? ligne.querySelector('.opus__carte-repere') : null;
			var classe = ligne ? (ligne.getAttribute('data-classe') || '') : '';
			var r = el('span', 'opus__carte-repere' + (classe ? ' ' + classe : ''));

			r.style.setProperty('--opus-repere', modele ? modele.style.getPropertyValue('--opus-repere') : '');
			r.innerHTML = modele ? modele.innerHTML : '<span>' + l.n + '</span>';
			r.setAttribute('data-n', l.n);
			moi.calqueReperes.appendChild(r);

			return r;
		});

		var zoom = el('div', 'opus__carte-zoom');
		var plus = el('button', '', '+');
		var moins = el('button', '', '−');

		plus.type = moins.type = 'button';
		plus.setAttribute('aria-label', this.t.zoomer || '+');
		moins.setAttribute('aria-label', this.t.dezoomer || '-');
		plus.addEventListener('click', function () { moi.zoomer(1); });
		moins.addEventListener('click', function () { moi.zoomer(-1); });
		zoom.appendChild(plus);
		zoom.appendChild(moins);
		z.appendChild(zoom);

		var credit = el('span', 'opus__carte-credit');
		credit.innerHTML = '© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>';
		this.creditRoute = el('span', '', '');
		credit.appendChild(this.creditRoute);
		z.appendChild(credit);

		// La vue de l'image de la facade : la carte s'ouvre exactement la, sans sauter.
		if (this.d.vue && typeof this.d.vue.z === 'number') {
			this.z = this.d.vue.z;
			this.cx = this.d.vue.cx;
			this.cy = this.d.vue.cy;
			this.dessiner();
		} else {
			this.cadrer(this.lieux.map(function (l) { return [l.lat, l.lon]; }), this.d.zoom || 0);
		}

		this.brancher();

		if (focus) { z.focus({ preventScroll: true }); }
	};

	/* Le zoom qui montre tous les points, marges comprises. */
	Carte.prototype.cadrer = function (points, zoomFixe) {
		var w = this.zone.clientWidth || 600;
		var h = this.zone.clientHeight || 400;
		var z = 16;

		if (zoomFixe) {
			z = zoomFixe;
		} else if (points.length > 1) {
			for (z = 17; z > 2; z--) {
				var ps = points.map(function (p) { return versPixels(p[0], p[1], z); });
				var xs = ps.map(function (p) { return p.x; });
				var ys = ps.map(function (p) { return p.y; });

				if (Math.max.apply(0, xs) - Math.min.apply(0, xs) <= w - 90 && Math.max.apply(0, ys) - Math.min.apply(0, ys) <= h - 110) { break; }
			}
		}

		var lat = 0;
		var lon = 0;
		var tous = points.map(function (p) { return versPixels(p[0], p[1], z); });
		var mx = (Math.min.apply(0, tous.map(function (p) { return p.x; })) + Math.max.apply(0, tous.map(function (p) { return p.x; }))) / 2;
		var my = (Math.min.apply(0, tous.map(function (p) { return p.y; })) + Math.max.apply(0, tous.map(function (p) { return p.y; }))) / 2;

		this.z = z;
		this.cx = mx;
		this.cy = my + 12;
		this.dessiner();

		return { lat: lat, lon: lon };
	};

	Carte.prototype.zoomer = function (pas, px, py) {
		var nz = Math.max(3, Math.min(18, this.z + pas));

		if (nz === this.z) { return; }

		var w = this.zone.clientWidth;
		var h = this.zone.clientHeight;
		var ox = px == null ? w / 2 : px;
		var oy = py == null ? h / 2 : py;
		var wx = this.cx - w / 2 + ox;
		var wy = this.cy - h / 2 + oy;
		var f = Math.pow(2, nz - this.z);

		this.cx = wx * f - ox + w / 2;
		this.cy = wy * f - oy + h / 2;
		this.z = nz;
		this.dessiner();
	};

	Carte.prototype.dessiner = function () {
		var w = this.zone.clientWidth;
		var h = this.zone.clientHeight;
		var n = Math.pow(2, this.z);
		var gauche = this.cx - w / 2;
		var haut = this.cy - h / 2;
		var gardees = {};
		var moi = this;

		this.tuiles = this.tuiles || {};

		for (var tx = Math.floor(gauche / TUILE); tx <= Math.floor((gauche + w) / TUILE); tx++) {
			for (var ty = Math.floor(haut / TUILE); ty <= Math.floor((haut + h) / TUILE); ty++) {
				if (ty < 0 || ty >= n) { continue; }

				var vx = ((tx % n) + n) % n;
				var cle = this.z + '/' + tx + '/' + ty;
				var img = this.tuiles[cle];

				if (!img) {
					img = new Image();
					img.alt = '';
					img.decoding = 'async';
					img.draggable = false;
					img.src = TUILES.replace('{z}', this.z).replace('{x}', vx).replace('{y}', ty);
					this.calqueTuiles.appendChild(img);
					this.tuiles[cle] = img;
				}

				img.style.left = Math.round(tx * TUILE - gauche) + 'px';
				img.style.top = Math.round(ty * TUILE - haut) + 'px';
				gardees[cle] = true;
			}
		}

		Object.keys(this.tuiles).forEach(function (cle) {
			if (!gardees[cle]) {
				moi.tuiles[cle].remove();
				delete moi.tuiles[cle];
			}
		});

		this.lieux.forEach(function (l, i) {
			var p = versPixels(l.lat, l.lon, moi.z);

			moi.reperes[i].style.left = (p.x - gauche) + 'px';
			moi.reperes[i].style.top = (p.y - haut) + 'px';
		});

		if (this.vous && this.depart) {
			var v = versPixels(this.depart[0], this.depart[1], this.z);

			this.vous.style.left = (v.x - gauche) + 'px';
			this.vous.style.top = (v.y - haut) + 'px';
		}

		this.calqueTrace.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
		this.calqueTrace.setAttribute('width', w);
		this.calqueTrace.setAttribute('height', h);
		this.chemin.setAttribute('d', !this.route ? '' : this.route.map(function (c, k) {
			var p = versPixels(c[1], c[0], moi.z);

			return (k ? 'L' : 'M') + (p.x - gauche).toFixed(1) + ' ' + (p.y - haut).toFixed(1);
		}).join(' '));
	};

	Carte.prototype.brancher = function () {
		var z = this.zone;
		var moi = this;
		var prise = null;
		var doigts = {};
		var pince = null;

		/*
		 * GLISSER POUR SE DEPLACER, PINCER POUR ZOOMER. Un doigt ou la souris
		 * deplace la carte ; deux doigts qui s'ecartent ou se rapprochent
		 * zooment, d'un cran a chaque fois que l'ecart double ou se divise.
		 */
		function ecart() {
			var p = Object.keys(doigts).map(function (k) { return doigts[k]; });

			return p.length < 2 ? null : {
				d: Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y),
				x: (p[0].x + p[1].x) / 2,
				y: (p[0].y + p[1].y) / 2
			};
		}

		z.addEventListener('pointerdown', function (e) {
			if (e.target.closest('button, a')) { return; }

			doigts[e.pointerId] = { x: e.clientX, y: e.clientY };
			z.setPointerCapture(e.pointerId);

			pince = ecart();
			// Le repere est retenu ICI : une fois le pointeur capture, le lacher vise la zone.
			prise = pince ? null : { x: e.clientX, y: e.clientY, cx: moi.cx, cy: moi.cy, repere: e.target.closest('.opus__carte-repere[data-n]') };
		});

		z.addEventListener('pointermove', function (e) {
			if (doigts[e.pointerId]) { doigts[e.pointerId] = { x: e.clientX, y: e.clientY }; }

			if (pince) {
				var maintenant = ecart();

				if (!maintenant) { return; }

				var r = z.getBoundingClientRect();
				var f = maintenant.d / pince.d;

				if (f > 1.6 || f < 0.62) {
					moi.zoomer(f > 1 ? 1 : -1, maintenant.x - r.left, maintenant.y - r.top);
					pince = maintenant;
				}

				return;
			}

			if (!prise) { return; }

			moi.cx = prise.cx - (e.clientX - prise.x);
			moi.cy = prise.cy - (e.clientY - prise.y);
			moi.dessiner();
		});

		/*
		 * UN CLIC SUR UN REPERE, SANS GLISSER : le lieu s'allume dans la liste,
		 * qui defile jusqu'a lui. Plus de cinq pixels de mouvement, c'etait un
		 * deplacement de la carte, pas un choix.
		 */
		function lacher(e) {
			var repere = prise ? prise.repere : null;

			if (prise && repere && Math.hypot(e.clientX - prise.x, e.clientY - prise.y) < 5) {
				moi.activer(+repere.getAttribute('data-n'), true);
			}

			delete doigts[e.pointerId];
			pince = ecart();
			prise = null;
		}

		z.addEventListener('pointerup', lacher);
		z.addEventListener('pointercancel', lacher);

		z.addEventListener('dblclick', function (e) {
			var r = z.getBoundingClientRect();

			moi.zoomer(e.shiftKey ? -1 : 1, e.clientX - r.left, e.clientY - r.top);
		});

		/*
		 * LA MOLETTE ZOOME, UNE FOIS LA CARTE OUVERTE. Avant le clic, la zone
		 * n'ecoute rien et la page defile normalement ; apres, le visiteur a
		 * choisi la carte. Un cran par 120 de molette, pour qu'un pave tactile
		 * ne fasse pas sauter cinq niveaux d'un coup.
		 */
		var cumul = 0;

		z.addEventListener('wheel', function (e) {
			e.preventDefault();
			cumul += e.deltaY;

			if (Math.abs(cumul) < 60) { return; }

			var r = z.getBoundingClientRect();

			moi.zoomer(cumul < 0 ? 1 : -1, e.clientX - r.left, e.clientY - r.top);
			cumul = 0;
		}, { passive: false });

		z.addEventListener('keydown', function (e) {
			var pas = 80;
			var k = e.key;

			if (k === 'ArrowLeft') { moi.cx -= pas; } else if (k === 'ArrowRight') { moi.cx += pas; } else if (k === 'ArrowUp') { moi.cy -= pas; } else if (k === 'ArrowDown') { moi.cy += pas; } else if (k === '+' || k === '=') { moi.zoomer(1); return e.preventDefault(); } else if (k === '-' || k === '_') { moi.zoomer(-1); return e.preventDefault(); } else { return; }

			e.preventDefault();
			moi.dessiner();
		});

		if (window.ResizeObserver) {
			new ResizeObserver(function () { moi.dessiner(); }).observe(z);
		}
	};

	/* --- L'itineraire -------------------------------------------------------- */
	Carte.prototype.lieu = function (n) {
		return this.lieux.filter(function (l) { return l.n === n; })[0];
	};

	Carte.prototype.activer = function (n, defiler) {
		var cadre = this.racine.querySelector('.opus__carte-defile');

		[].slice.call(this.racine.querySelectorAll('.opus__carte-lieu')).forEach(function (li) {
			var actif = +li.getAttribute('data-n') === n;

			li.classList.toggle('opus__carte-lieu--actif', actif);

			// Le cadre defile seul : la page, elle, ne bouge pas.
			if (actif && defiler && cadre && cadre.scrollHeight > cadre.clientHeight) {
				cadre.scrollTo({ top: li.offsetTop - 8, behavior: 'smooth' });
			}
		});

		(this.reperes || []).forEach(function (r) {
			r.classList.toggle('opus__carte-repere--actif', +r.getAttribute('data-n') === n);
		});
	};

	Carte.prototype.itineraire = function (n, bouton) {
		this.charger(false);
		this.cible = this.lieu(n);
		this.retour = bouton;

		if (!this.cible) { return; }

		this.activer(n);
		this.zone.scrollIntoView({ block: 'nearest', behavior: 'smooth' });

		if (this.depart) {
			this.calculer();

			return;
		}

		this.panneau('cherche');

		var moi = this;

		if (!navigator.geolocation) {
			this.panneau('adresse', this.t.refus);

			return;
		}

		navigator.geolocation.getCurrentPosition(function (pos) {
			moi.depart = [pos.coords.latitude, pos.coords.longitude];
			moi.calculer();
		}, function () {
			moi.panneau('adresse', moi.t.refus);
		}, { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 });
	};

	Carte.prototype.calculer = function () {
		var moi = this;
		var c = this.cible;
		var url = ROUTE.replace('{p}', PROFILS[this.mode])
			.replace('{a}', this.depart[1] + ',' + this.depart[0])
			.replace('{b}', c.lon + ',' + c.lat);

		this.panneau('calcul');

		fetch(url).then(function (r) { return r.ok ? r.json() : Promise.reject(); }).then(function (j) {
			var r = j && j.routes && j.routes[0];

			if (!r) { return Promise.reject(); }

			moi.route = r.geometry.coordinates;
			moi.resume = distance(r.distance) + ', ' + duree(r.duration);
			moi.poserVous();
			moi.creditRoute.textContent = ' · ' + (moi.t.source || '');
			moi.cadrer(moi.route.map(function (p) { return [p[1], p[0]]; }), 0);
			moi.panneau('trajet');
		}).catch(function () {
			moi.route = null;
			moi.dessiner();
			moi.panneau('erreur', moi.t.echec);
		});
	};

	Carte.prototype.poserVous = function () {
		if (!this.vous) {
			this.vous = el('span', 'opus__carte-vous');
			this.vous.setAttribute('title', this.t.vous || '');
			this.calqueReperes.appendChild(this.vous);
		}
	};

	Carte.prototype.guidage = function () {
		var a = this.depart[0] + ',' + this.depart[1];
		var b = this.cible.lat + ',' + this.cible.lon;

		if (this.d.guidage === 'aucun') { return ''; }

		if (this.d.guidage === 'google') {
			return 'https://www.google.com/maps/dir/?api=1&origin=' + a + '&destination=' + b + '&travelmode=' + GOOGLE[this.mode];
		}

		return 'https://www.openstreetmap.org/directions?engine=fossgis_osrm_' + OSRM[this.mode] + '&route=' + a + '%3B' + b;
	};

	Carte.prototype.fermer = function () {
		this.route = null;
		this.creditRoute.textContent = '';
		this.trajetBoite.hidden = true;
		this.trajetBoite.textContent = '';
		this.activer(-1);

		if (this.vous) {
			this.vous.remove();
			this.vous = null;
		}

		this.cadrer(this.lieux.map(function (l) { return [l.lat, l.lon]; }), this.d.zoom || 0);

		if (this.retour) { this.retour.focus(); }
	};

	/* Le panneau sous la carte : ce qui se passe, et ce qu'on peut faire. */
	Carte.prototype.panneau = function (etat, message) {
		var b = this.trajetBoite;
		var t = this.t;
		var moi = this;

		b.hidden = false;
		b.textContent = '';
		b.setAttribute('role', 'region');
		b.setAttribute('aria-label', (t.jusqua || '%s').replace('%s', this.cible.nom));

		var tete = el('div', 'opus__carte-trajet-tete');
		var titre = el('strong', '', (t.jusqua || '%s').replace('%s', this.cible.nom));
		var etatTexte = el('span', '', '');

		etatTexte.setAttribute('aria-live', 'polite');
		tete.appendChild(titre);
		tete.appendChild(etatTexte);
		b.appendChild(tete);

		if (etat === 'cherche') { etatTexte.textContent = t.cherche || ''; }
		if (etat === 'calcul') { etatTexte.textContent = t.calcul || ''; }
		if (etat === 'trajet') { etatTexte.textContent = this.resume; }
		if (etat === 'erreur' || etat === 'adresse') { etatTexte.textContent = message || ''; }

		if (etat === 'trajet' || etat === 'calcul' || etat === 'erreur') {
			var modes = el('div', 'opus__carte-modes');

			modes.setAttribute('role', 'group');
			modes.setAttribute('aria-label', t.moyen || '');
			['pied', 'velo', 'voiture'].forEach(function (m) {
				var bt = el('button', '', t[m] || m);

				bt.type = 'button';
				bt.setAttribute('aria-pressed', String(moi.mode === m));
				bt.addEventListener('click', function () {
					moi.mode = m;
					moi.calculer();
				});
				modes.appendChild(bt);
			});
			b.appendChild(modes);
		}

		if (etat === 'adresse') {
			var f = el('form', 'opus__carte-depart');
			var lab = el('label', '', t.depart || '');
			var champ = el('input');
			var ok = el('button', 'opus__carte-route', t.calculer || 'OK');

			champ.type = 'text';
			champ.autocomplete = 'street-address';
			champ.required = true;
			lab.appendChild(champ);
			ok.type = 'submit';
			f.appendChild(lab);
			f.appendChild(ok);
			f.addEventListener('submit', function (e) {
				e.preventDefault();
				etatTexte.textContent = t.cherche || '';
				fetch(CHERCHE + encodeURIComponent(champ.value)).then(function (r) { return r.json(); }).then(function (j) {
					if (!j || !j[0]) { return Promise.reject(); }

					moi.depart = [parseFloat(j[0].lat), parseFloat(j[0].lon)];
					moi.calculer();
				}).catch(function () {
					etatTexte.textContent = t.introuvable || '';
					champ.focus();
				});
			});
			b.appendChild(f);
			champ.focus();
		}

		var pied = el('div', 'opus__carte-trajet-pied');

		if (etat === 'trajet') {
			var depuis = el('span', '', t.depuis || '');
			pied.appendChild(depuis);

			var lien = this.guidage();

			if (lien) {
				var g = el('a', '', (t.guidage || '%s').replace('%s', this.d.guidage === 'google' ? 'Google Maps' : 'OpenStreetMap'));

				g.href = lien;
				g.target = '_blank';
				g.rel = 'noopener';
				pied.appendChild(g);
			}
		}

		if (etat !== 'adresse') {
			var autre = el('button', 'opus__carte-lien', t.adresse || '');

			autre.type = 'button';
			autre.addEventListener('click', function () {
				moi.depart = null;
				moi.panneau('adresse');
			});
			pied.appendChild(autre);
		}

		var fin = el('button', 'opus__carte-lien', t.fermer || '');

		fin.type = 'button';
		fin.addEventListener('click', function () { moi.fermer(); });
		pied.appendChild(fin);
		b.appendChild(pied);
	};

	function demarrer() {
		[].slice.call(document.querySelectorAll('.opus__carte[data-opus-carte]')).forEach(function (r) {
			if (!r.opusCarte) { r.opusCarte = new Carte(r); }
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', demarrer);
	} else {
		demarrer();
	}
})();
