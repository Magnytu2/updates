/*
 * LA CHARTE JOOMANJI DANS OPUS.
 *
 * FICHIER ECRIT EN ENTIER PAR `_charte/charte.py` : n'y rien ecrire a la
 * main. Une amelioration se fait dans `_charte/composants`, puis
 * `python3 _charte/charte.py recopier opus`. La livraison refuse un fichier
 * qui diverge (`charte.py verifier opus`).
 *
 * Composants : jetons v2, aide v2, fenetre v1, onglet v1, accueil v1.
 */

// >>> CHARTE JOOMANJI : aide v2 (ne pas modifier ici : _charte/composants) >>>
/*
 * LE « i » D'AIDE ET SA BULLE. Charte Joomanji, composant « aide », v1,
 * 9 octobre 2026.
 *
 * Le balisage est celui du coeur de Joomla (`repeatable-table.php`) : un
 * `span.icon-info-circle[tabindex]`, puis sa bulle `[role="tooltip"]` en
 * voisine immediate. Ce script en fait un vrai bouton : clic, Entree ou
 * Espace ouvrent et ferment ; la croix, Echap, un clic ailleurs, un
 * defilement ou un redimensionnement ferment ; une seule bulle ouverte.
 *
 * PLUSIEURS PRODUITS SUR LA MEME PAGE (Opus dans un ecran qui porte aussi
 * Iris) : le premier qui charge pose les ecoutes, les suivants ajoutent
 * seulement leur portee. Sans cela, deux copies basculeraient la meme bulle
 * deux fois, et elle ne s'ouvrirait jamais.
 *
 * Textes : `JHELP` et `JCLOSE`, clefs du coeur, a passer par `Text::script`.
 * Un produit appelle `window.JoomanjiAide.preparer(racine)` apres avoir
 * ajoute des pastilles ; sinon elles sont preparees a leur premier clic.
 *
 * PIEGES DEJA PAYES (Opus, 9 octobre 2026) :
 * - l'ecoute du clic est en CAPTURE : en bulle, un formulaire l'arretait ;
 * - la pastille est dans un `label` : `preventDefault`, sinon le champ du
 *   label s'ouvre ;
 * - la bulle est posee en `position: fixed` a l'ouverture : le
 *   `.table-responsive` du coeur la coupait dans les en-tetes de colonnes ;
 * - aucun nom global hors de `window.JoomanjiAide` : une fonction de meme nom
 *   dans le produit ecraserait la notre sans un mot.
 */
(function () {
  'use strict';

  var PORTEE = '#attrib-montage, #attrib-icones';

  if (window.JoomanjiAide) {
    window.JoomanjiAide.portees.push(PORTEE);

    return;
  }

  var R = window.JoomanjiAide = { version: 1, portees: [PORTEE], preparer: preparer };
  var compteur = 0;
  var ouverte = null;

  function mot(cle, defaut) {
    if (window.Joomla && Joomla.Text && Joomla.Text._) {
      var t = Joomla.Text._(cle);
      if (t && t !== cle) { return t; }
    }

    return defaut;
  }

  function dansPortee(el) {
    return R.portees.some(function (p) { return !!el.closest(p); });
  }

  function preparer(racine) {
    [].slice.call((racine || document).querySelectorAll('.icon-info-circle[tabindex]:not([data-jmj-aide])'))
      .forEach(function (p) {
        var bulle = p.nextElementSibling;

        if (!dansPortee(p) || !bulle || bulle.getAttribute('role') !== 'tooltip') { return; }

        if (!bulle.id) {
          compteur += 1;
          bulle.id = 'jmj-aide-' + compteur;
        }

        p.dataset.jmjAide = '1';
        p.removeAttribute('aria-hidden');
        p.setAttribute('role', 'button');
        p.setAttribute('aria-label', mot('JHELP', 'Aide'));
        p.setAttribute('aria-describedby', bulle.id);
        p.setAttribute('aria-controls', bulle.id);
        p.setAttribute('aria-expanded', 'false');

        if (!bulle.querySelector('.jmj-aide__croix')) {
          var croix = document.createElement('button');
          croix.type = 'button';
          croix.className = 'jmj-aide__croix';
          croix.setAttribute('aria-label', mot('JCLOSE', 'Fermer'));
          croix.title = croix.getAttribute('aria-label');
          croix.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M6.4 4.9 12 10.5l5.6-5.6 1.5 1.5L13.5 12l5.6 5.6-1.5 1.5L12 13.5l-5.6 5.6-1.5-1.5L10.5 12 4.9 6.4z"/></svg>';
          bulle.appendChild(croix);
        }
      });
  }

  function fermer(rendreFocus) {
    if (!ouverte) { return; }

    var p = ouverte;
    var b = p.nextElementSibling;
    ouverte = null;
    p.setAttribute('aria-expanded', 'false');

    if (b) {
      b.classList.remove('jmj-aide--ouverte');
      b.style.position = '';
      b.style.left = '';
      b.style.top = '';
    }

    if (rendreFocus) { p.focus(); }
  }

  function basculer(p) {
    if (!p.dataset.jmjAide) { preparer(p.parentElement); }

    var b = p.nextElementSibling;

    if (!b || b.getAttribute('role') !== 'tooltip') { return; }

    var etait = ouverte === p;
    fermer(false);

    if (etait) { return; }

    ouverte = p;
    p.setAttribute('aria-expanded', 'true');
    b.classList.add('jmj-aide--ouverte');

    // Posee par rapport a l'ecran, sous la pastille, ramenee dans l'ecran.
    var r = p.getBoundingClientRect();
    b.style.position = 'fixed';
    b.style.left = '0px';
    b.style.top = '0px';
    var gauche = Math.max(8, Math.min(r.left, window.innerWidth - b.offsetWidth - 8));
    var haut = r.bottom + 6;

    if (haut + b.offsetHeight > window.innerHeight - 8) {
      haut = Math.max(8, r.top - b.offsetHeight - 6);
    }

    b.style.left = Math.round(gauche) + 'px';
    b.style.top = Math.round(haut) + 'px';
  }

  function pastille(cible) {
    var p = cible.closest ? cible.closest('.icon-info-circle[tabindex]') : null;

    return p && dansPortee(p) ? p : null;
  }

  document.addEventListener('click', function (ev) {
    var p = pastille(ev.target);

    if (p) {
      ev.preventDefault();
      ev.stopPropagation();
      basculer(p);

      return;
    }

    if (ev.target.closest && ev.target.closest('.jmj-aide--ouverte')) {
      ev.preventDefault();
      if (ev.target.closest('.jmj-aide__croix')) { fermer(true); }

      return;
    }

    fermer(false);
  }, true);

  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape' && ouverte) {
      ev.preventDefault();
      fermer(true);

      return;
    }

    if (ev.key === 'Enter' || ev.key === ' ') {
      var p = pastille(ev.target);

      if (p) {
        ev.preventDefault();
        basculer(p);
      }
    }
  });

  window.addEventListener('scroll', function () { fermer(false); }, true);
  window.addEventListener('resize', function () { fermer(false); });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { preparer(document); });
  } else {
    preparer(document);
  }
})();
// <<< CHARTE JOOMANJI : aide <<<

// >>> CHARTE JOOMANJI : fenetre v1 (ne pas modifier ici : _charte/composants) >>>
/*
 * LA FENETRE DE CONFIRMATION. Charte Joomanji, composant « fenetre », v1,
 * 9 octobre 2026.
 *
 *   window.JoomanjiFenetre.demander({
 *     titre: 'Remplacer la mise en page',
 *     texte: 'Tout le montage actuel sera remplace.',   // echappe ici ; ligne vide = paragraphe
 *     ton: 'danger',                                    // ou rien
 *     bouton: 'Remplacer'                               // le nom du bouton de confirmation
 *   }).then(function (oui) { ... });
 *
 * Rend une promesse : vrai si l'on a confirme, faux sinon.
 *
 *   window.JoomanjiFenetre.saisir({
 *     titre: 'Nouveau dossier',
 *     corps: '<label ...>Nom</label><input name="nom" ...>',  // HTML du produit, deja echappe
 *     pret: function (corps) { ... },                          // appele une fois la fenetre ouverte
 *     ton: 'danger', bouton: 'Creer'                           // comme demander()
 *   }).then(function (valeurs) { ... });
 *
 * La meme fenetre, avec des champs : rend les valeurs des champs nommes du
 * corps (`{ nom: '...' }`, case a cocher en vrai ou faux, bouton radio
 * choisi), ou `null` si l'on a annule. Le focus va au premier champ.
 *
 * « Une fenetre a nous », ni `confirm()` du navigateur (« 127.0.0.1
 * indique »), ni `JoomlaDialog`. Un `dialog` natif ouvert par `showModal()` :
 * fond inerte, Echap, focus rendu a la fermeture. Il est cree au premier
 * appel, sous `body`, et resservi ensuite.
 *
 * Textes : `JCANCEL` et `JCLOSE` (clefs du coeur), `JMJ_FENETRE_VALIDER` et
 * `JMJ_FENETRE_DEFINITIF` (clefs de la charte, dans les fichiers de langue
 * de chaque produit). Les quatre passent par `Text::script`.
 *
 * PIEGES DEJA PAYES (Iris, Opus, Formulus) :
 * - la reponse se lit a l'ENVOI (le bouton presse) et Echap a `cancel`, qui
 *   part tout de suite ; `close` ne vient qu'en dernier recours : Chrome le
 *   retient dans un onglet qui n'a pas le premier plan ;
 * - un drapeau `fini` evite de repondre deux fois ;
 * - deux questions rapprochees attendent leur tour (file), aucune ne
 *   repond a la place de l'autre ;
 * - l'aspect se remet a chaque ouverture : un evenement en retard ne doit pas
 *   repeindre la question suivante ;
 * - en ton danger, le focus est sur Annuler : un Entree distrait ne detruit rien ;
 * - aucun nom global hors de `window.JoomanjiFenetre`.
 */
(function () {
  'use strict';

  if (window.JoomanjiFenetre) {
    return;
  }

  var dialogue = null;
  var file = Promise.resolve();
  var SVG = {
    croix: 'M6.4 4.9 12 10.5l5.6-5.6 1.5 1.5L13.5 12l5.6 5.6-1.5 1.5L12 13.5l-5.6 5.6-1.5-1.5L10.5 12 4.9 6.4z',
    alerte: 'M12 2 1 21h22L12 2Zm0 4 7.5 13h-15L12 6Zm1 11h-2v-2h2v2Zm0-3h-2v-4h2v4Z'
  };

  function mot(cle, defaut) {
    if (window.Joomla && Joomla.Text && Joomla.Text._) {
      var t = Joomla.Text._(cle);
      if (t && t !== cle) { return t; }
    }

    return defaut;
  }

  function echap(t) {
    return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function icone(nom) {
    return '<svg class="jmj-fenetre__i" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="' + SVG[nom] + '"/></svg>';
  }

  function creer() {
    var d = document.createElement('dialog');
    var fermer = echap(mot('JCLOSE', 'Fermer'));

    d.className = 'jmj-fenetre';
    d.id = 'jmj-fenetre';
    d.setAttribute('aria-labelledby', 'jmj-fenetre-titre');
    d.setAttribute('aria-describedby', 'jmj-fenetre-corps');
    // Valider EN PREMIER dans le code : Entree declenche le premier bouton
    // d'envoi. La croix est la derniere, pour la meme raison.
    d.innerHTML = '<form method="dialog">' +
      '<h3 id="jmj-fenetre-titre"></h3>' +
      '<div id="jmj-fenetre-corps"></div>' +
      '<div class="jmj-fenetre__pied">' +
        '<button type="submit" class="btn btn-primary" value="ok" id="jmj-fenetre-ok"></button>' +
        '<button type="submit" class="btn btn-secondary" value="annuler">' + echap(mot('JCANCEL', 'Annuler')) + '</button>' +
      '</div>' +
      '<button type="submit" class="jmj-fenetre__croix" value="annuler" aria-label="' + fermer + '" title="' + fermer + '">' + icone('croix') + '</button>' +
      '</form>';
    document.body.appendChild(d);

    return d;
  }

  function ouvrir(q, saisie) {
    dialogue = dialogue || creer();

    // Sans `dialog` (navigateur ancien) : la question du navigateur, moins
    // belle, mais personne ne perd rien sans le savoir.
    if (typeof dialogue.showModal !== 'function') {
      return Promise.resolve(saisie ? null : window.confirm(q.texte || q.titre || ''));
    }

    return new Promise(function (resoudre) {
      var dlg = dialogue;
      var danger = q.ton === 'danger';
      var bOk = dlg.querySelector('#jmj-fenetre-ok');
      var h = dlg.querySelector('#jmj-fenetre-titre');
      var forme = dlg.querySelector('form');
      var fini = false;

      h.textContent = q.titre || '';
      var corps = dlg.querySelector('#jmj-fenetre-corps');
      var retour = document.activeElement;

      // `corps` : du HTML fourni par le produit (saisir). Sinon `texte`, un
      // paragraphe par bloc separe d'une ligne vide, echappe : il peut porter
      // des noms saisis.
      corps.innerHTML = q.corps != null ? q.corps : String(q.texte || '').split(/\n{2,}/)
        .filter(function (bout) { return bout !== ''; })
        .map(function (bout) { return '<p>' + echap(bout) + '</p>'; }).join('');
      dlg.classList.toggle('jmj-fenetre--danger', danger);
      bOk.className = 'btn ' + (danger ? 'btn-danger' : 'btn-primary');
      bOk.textContent = q.bouton || mot('JMJ_FENETRE_VALIDER', 'Valider');

      if (danger) {
        h.insertAdjacentHTML('afterbegin', icone('alerte'));
        h.insertAdjacentHTML('beforeend', '<span class="jmj-fenetre__definitif">' + echap(mot('JMJ_FENETRE_DEFINITIF', 'Action définitive')) + '</span>');
      }

      function envoi(e) { fin(e.submitter ? e.submitter.value : ''); }
      function annulation() { fin(''); }
      function fermeture() { fin(dlg.returnValue); }
      function fin(reponse) {
        if (fini) { return; }
        fini = true;
        dlg.removeEventListener('close', fermeture);
        dlg.removeEventListener('cancel', annulation);
        forme.removeEventListener('submit', envoi);
        if (dlg.open && reponse !== 'ok') { dlg.close(); }
        if (retour && retour.focus && document.contains(retour)) { retour.focus(); }

        if (!saisie) {
          resoudre(reponse === 'ok');

          return;
        }

        var valeurs = {};

        [].slice.call(corps.querySelectorAll('[name]')).forEach(function (c) {
          if (c.type === 'radio' && !c.checked) { return; }
          valeurs[c.name] = c.type === 'checkbox' ? c.checked : c.value;
        });
        resoudre(reponse === 'ok' ? valeurs : null);
      }

      dlg.addEventListener('close', fermeture);
      dlg.addEventListener('cancel', annulation);
      forme.addEventListener('submit', envoi);
      dlg.returnValue = '';
      dlg.showModal();

      // En ton danger, le focus sur Annuler ; sinon le premier champ, puis Valider.
      var premier = danger ? dlg.querySelector('.jmj-fenetre__pied [value=annuler]')
        : (corps.querySelector('input:not([type=hidden]), select, textarea') || bOk);

      premier.focus();
      if (premier.select && premier.tagName === 'INPUT') { premier.select(); }
      if (typeof q.pret === 'function') { q.pret(corps); }
    });
  }

  function enFile(q, saisie) {
    var question = file.then(function () { return ouvrir(q || {}, saisie); });

    file = question.catch(function () {});

    return question;
  }

  function demander(q) { return enFile(q, false); }
  function saisir(q) { return enFile(q, true); }

  window.JoomanjiFenetre = { version: 1, demander: demander, saisir: saisir };
})();
// <<< CHARTE JOOMANJI : fenetre <<<

// >>> CHARTE JOOMANJI : onglet v1 (ne pas modifier ici : _charte/composants) >>>
/*
 * « ENREGISTRER » LAISSE SUR L'ONGLET OU L'ON ETAIT. Charte Joomanji,
 * composant « onglet », v1, 9 octobre 2026.
 *
 * Regle de Cyrille du 3 octobre 2026, pour toutes nos extensions a onglets.
 * Le code est celui de `retenirOnglet()` d'Opus 1.5.419 (recopie dans Iris),
 * rendu commun : il sert a tout formulaire d'edition de l'administration qui
 * porte des onglets du coeur (`joomla-tab`), module ou element de composant.
 *
 * Le `recall` de joomla-tab ne suffit pas : il range l'onglet sous l'adresse
 * de la page, et cette adresse change a l'enregistrement (`client_id=` a
 * l'ouverture, `client_id=0` au retour). On range donc l'onglet sous
 * l'extension, la vue et l'identifiant de l'element, et on CLIQUE son bouton
 * au retour, sans jamais forcer ses attributs. Rien sur un element neuf
 * (id 0), rien pour les onglets internes d'un sous-formulaire, rien hors de
 * l'administration (la fenetre d'edition d'Opus sur le site).
 *
 * Aucun nom global hors de `window.JoomanjiOnglet`. Deux produits sur la meme
 * page : le premier fait le travail, les autres ne font rien.
 */
(function () {
  'use strict';

  if (window.JoomanjiOnglet) {
    return;
  }

  window.JoomanjiOnglet = { version: 1 };

  function retenir() {
    if (!document.body || !document.body.classList.contains('admin')) { return; }

    var form = document.querySelector('form[name="adminForm"]');

    if (!form || !form.querySelector('joomla-tab')) { return; }

    var lire = function (nom, texte) {
      var m = new RegExp('[?&]' + nom + '=([^&#]*)').exec(texte || '');

      return m ? decodeURIComponent(m[1]) : '';
    };
    var action = form.getAttribute('action') || '';
    var adresse = window.location.search;
    var id = lire('id', action) || lire('id', adresse) || lire('extension_id', adresse);

    if (!id || id === '0') { return; }

    var clef = 'jmj.onglet.' + (lire('option', action) || lire('option', adresse)) + '.' +
      (lire('view', action) || lire('view', adresse) || lire('task', action)) + '.' + id;

    form.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('button[role="tab"][aria-controls]') : null;

      if (!b || b.closest('joomla-field-subform')) { return; }

      try { window.sessionStorage.setItem(clef, b.getAttribute('aria-controls')); } catch (x) { /* stockage refuse */ }
    });

    var voulu = '';

    try { voulu = window.sessionStorage.getItem(clef) || ''; } catch (x) { return; }

    if (!voulu) { return; }

    var essais = 0;

    (function rouvrir() {
      var b = form.querySelector('button[role="tab"][aria-controls="' + voulu.replace(/"/g, '') + '"]');

      if (b) {
        if (b.getAttribute('aria-selected') !== 'true') { b.click(); }

        return;
      }

      if (++essais < 20) { window.setTimeout(rouvrir, 100); }
    })();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', retenir);
  } else {
    retenir();
  }
})();
// <<< CHARTE JOOMANJI : onglet <<<
