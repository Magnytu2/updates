/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * L'AGENDA, 4 octobre 2026 (serie 1.5.4xx).
 *
 * Le PHP a tout ecrit : le mois en cours, la liste, les fiches. Ce script
 * montre les boutons, redessine la grille des autres mois A L'IDENTIQUE de
 * `_elements.php`, bascule entre jour, mois, annee et liste, ouvre la fiche d'un autre
 * evenement et fabrique le fichier .ics que Google Agenda, Outlook et le
 * calendrier du telephone savent lire. Aucune bibliotheque.
 */
(function () {
  'use strict';

  function esc(t) {
    return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function pad(n) { return (n < 10 ? '0' : '') + n; }

  function iso(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }

  function plus(T, n) {
    return (n > 1 ? T.autres : T.autre).replace('%d', n).replace('%s', n);
  }

  /** Un agenda de la page. */
  function Agenda(racine) {
    var d;

    try { d = JSON.parse(racine.getAttribute('data-opus-agenda') || '{}'); } catch (e) { return; }

    var T     = d.textes || {};
    var mini  = d.vue === 'mini';
    var p     = d.auj.split('-');
    var an    = +p[0];
    var mois  = +p[1] - 1;
    var vue   = d.depart;
    var choisi = d.auj;
    // Le jour de la vue au jour, 5 octobre 2026 : « le 10 octobre merite une vue au jour », Cyrille.
    var jourVu = d.auj;
    var zoneJour  = racine.querySelector('.opus__agenda-jourvue');
    var zoneAnnee = racine.querySelector('.opus__agenda-annee');
    var toutes = d.vue === 'deux';
    var garderFiche = false;
    var tbody = racine.querySelector('.opus__agenda-table tbody');
    var periode = racine.querySelector('.opus__agenda-periode');
    var caption = racine.querySelector('.opus__agenda-table caption');
    var titre = (racine.querySelector('.opus__agenda-titre') || {}).textContent || '';
    var ouverts = {};
    var mode = d.fiche === 'popup' ? 'popup' : (d.fiche === 'droite' || d.fiche === 'gauche') ? 'liste' : 'seule';
    var defile = racine.querySelector('.opus__agenda-defile');
    var dialogue = null;
    var retourFocus = null;

    /*
     * LA FENETRE : les fiches, ecrites dessous par le PHP, passent dans un
     * `dialog` du navigateur. Il pose le focus, rend le reste inerte et se
     * ferme a Echap ; le bouton Fermer et un clic hors de la fiche aussi.
     */
    if (mode === 'popup') {
      var fiches = racine.querySelector('.opus__agenda-fiches');

      if (fiches && typeof HTMLDialogElement === 'function') {
        dialogue = document.createElement('dialog');
        dialogue.className = 'opus__agenda-dialog';
        dialogue.setAttribute('aria-label', titre);
        var fermer = document.createElement('button');
        fermer.type = 'button';
        fermer.className = 'opus__agenda-fermer';
        fermer.setAttribute('aria-label', T.fermer || 'Fermer');
        fermer.innerHTML = '<svg aria-hidden="true" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>';
        fermer.addEventListener('click', function () { dialogue.close(); });
        dialogue.appendChild(fermer);
        dialogue.appendChild(fiches);
        racine.appendChild(dialogue);
        dialogue.addEventListener('click', function (ev) { if (ev.target === dialogue) { dialogue.close(); } });
        dialogue.addEventListener('close', function () { if (retourFocus) { retourFocus.focus(); } });
      } else {
        mode = 'seule';
      }
    }

    // Le prochain evenement : celui que la fiche montre au depart.
    var prochain = null;
    d.occ.forEach(function (o) { if (!prochain && o.p && o.j >= d.auj) { prochain = o; } });
    if (!prochain && d.occ.length) { prochain = d.occ[d.occ.length - 1]; }

    [].forEach.call(racine.querySelectorAll('.opus__agenda-quand'), function (q) { q.setAttribute('data-depart', q.textContent); });

    /*
     * LA DATE DE LA FICHE OUVRE SA JOURNEE, 5 octobre 2026 : « la possibilite
     * depuis la fiche de cliquer et d'ouvrir la vue jour », Cyrille. Seulement
     * avec toutes les vues ; sinon la date reste un texte.
     */
    function poserQuand(fiche, texte) {
      var q = fiche.querySelector('.opus__agenda-quand');
      if (!q) { return; }
      var e = +fiche.getAttribute('data-e');
      var o = +fiche.getAttribute('data-o') || 0;
      var j = ((d.quand[e] || {})[o] || {}).j;
      if (d.vue !== 'deux' || !j) { q.textContent = texte; return; }
      q.innerHTML = '<button type="button" class="opus__agenda-voirjour" data-voir="' + esc(j) + '">' + esc(texte) + '</button>';
    }

    [].forEach.call(racine.querySelectorAll('.opus__agenda-fiche'), function (f) {
      var q = f.querySelector('.opus__agenda-quand');
      if (q) { poserQuand(f, q.getAttribute('data-depart')); }
    });
    [].forEach.call(racine.querySelectorAll('.opus__agenda-nav, .opus__agenda-bascule, .opus__agenda-ics'), function (n) { n.hidden = false; });
    racine.classList.add('opus__agenda--actif');

    function parJour(jour) {
      return d.occ.filter(function (o) { return o.j === jour; });
    }

    function dateDe(j) { return new Date(+j.slice(0, 4), +j.slice(5, 7) - 1, +j.slice(8, 10)); }

    function nomJour(jd) { return d.jours[(jd.getDay() - d.premier + 7) % 7].long; }

    function dateLongue(jd) { return nomJour(jd) + ' ' + jd.getDate() + ' ' + d.mois[jd.getMonth()] + ' ' + jd.getFullYear(); }

    function compte(n) { return (n > 1 ? T.nbs : T.nb).replace('%d', n).replace('%s', n); }

    /* LES SEMAINES D'UN MOIS : des lignes de sept dates, du premier jour de la semaine du site. */
    function semaines(a, m) {
      var dec = (new Date(a, m, 1).getDay() - d.premier + 7) % 7;
      var j0  = new Date(a, m, 1 - dec);
      var r   = [];

      for (var s = 0; s < 6; s++) {
        var lundi = new Date(j0.getFullYear(), j0.getMonth(), j0.getDate() + s * 7);
        if (s > 0 && lundi.getMonth() !== m) { break; }
        var sem = [];
        for (var k = 0; k < 7; k++) { sem.push(new Date(j0.getFullYear(), j0.getMonth(), j0.getDate() + s * 7 + k)); }
        r.push(sem);
      }

      return r;
    }

    /* LA GRILLE D'UN MOIS, comme `_elements.php` l'ecrit. */
    function dessinerMois() {
      if (!tbody) { return; }

      var h   = '';

      semaines(an, mois).forEach(function (sem) {
        h += '<tr>';

        sem.forEach(function (jd) {
          var jour = iso(jd);
          var occ  = parJour(jour);
          var cls  = (jd.getMonth() !== mois ? 'opus__agenda-hors ' : '') + (jour === d.auj ? 'opus__agenda-auj ' : '') + (jour < d.auj ? 'opus__agenda-passe' : '');

          h += '<td class="' + cls.trim() + '" data-jour="' + jour + '">';

          if (mini) {
            h += '<button type="button" class="opus__agenda-jour' + (occ.length ? ' opus__agenda-jour--plein' : '') + '" data-jour="' + jour + '" aria-pressed="' + (jour === choisi) + '"' +
              (occ.length ? ' style="--opus-agenda-c: ' + esc(d.ev[occ[0].e].c) + '"' : '') + '>' + jd.getDate() +
              (occ.length ? '<span class="visually-hidden">, ' + occ.length + '</span>' : '') + '</button>';
          } else {
            var tous = !!ouverts[jour];
            // Avec toutes les vues, le numero du jour ouvre ce jour.
            h += toutes
              ? '<button type="button" class="opus__agenda-num" data-voir="' + jour + '" aria-label="' + esc(T.voirJour.replace('%s', dateLongue(jd))) + '">' + jd.getDate() + '</button>'
              : '<span class="opus__agenda-num">' + jd.getDate() + '</span>';
            (tous ? occ : occ.slice(0, 2)).forEach(function (o) {
              var ev = d.ev[o.e];
              h += '<button type="button" class="opus__agenda-puce' + (ev.cl ? ' ' + esc(ev.cl) : '') + '" data-e="' + o.e + '" data-o="' + o.o + '" style="--opus-agenda-c: ' + esc(ev.c) + '">' +
                (o.h ? '<b>' + esc(o.h) + '</b> ' : '') + esc(ev.t) + '</button>';
            });
            if (!tous && occ.length > 2) {
              h += '<button type="button" class="opus__agenda-plus" data-plus="' + jour + '">' + esc(plus(T, occ.length - 2)) + '</button>';
            }
          }

          h += '</td>';
        });

        h += '</tr>';
      });

      tbody.innerHTML = h;

      var nom = d.mois[mois] + ' ' + an;
      if (periode) { periode.textContent = nom; }
      if (caption) { caption.textContent = titre + ', ' + nom; }
    }

    /* LA LISTE DU JOUR CHOISI, sous le mini calendrier. */
    function dessinerJour() {
      var zone = racine.querySelector('.opus__agenda-jourliste');
      if (!zone) { return; }

      var occ = parJour(choisi);
      var td  = racine.querySelector('td[data-jour="' + choisi + '"]');
      var jd  = new Date(+choisi.slice(0, 4), +choisi.slice(5, 7) - 1, +choisi.slice(8, 10));
      var nomJour = d.jours[(jd.getDay() - d.premier + 7) % 7].long;
      var h = '<p class="opus__agenda-jourtitre">' + esc(nomJour + ' ' + jd.getDate() + ' ' + d.mois[jd.getMonth()]) + '</p>';

      if (occ.length) {
        h += '<ul class="opus__agenda-jourevts">' + occ.map(function (o) {
          var ev = d.ev[o.e];
          return '<li>' + (o.h ? '<b>' + esc(o.h) + '</b> ' : '') + (ev.u ? '<a href="' + esc(ev.u) + '">' + esc(ev.t) + '</a>' : esc(ev.t)) + '</li>';
        }).join('') + '</ul>';
      } else {
        h += '<p class="opus__agenda-vide">' + esc(T.vide) + '</p>';
      }

      zone.innerHTML = h;
      if (td) { /* garde le focus sur le jour */ }
    }

    /* LA VUE AU JOUR : les seances du jour, comme une journee de la liste. */
    function dessinerJourVu() {
      if (!zoneJour) { return; }

      var occ = parJour(jourVu);
      var h = '';

      if (occ.length) {
        h += '<ul class="opus__agenda-evts">' + occ.map(function (o) {
          var ev = d.ev[o.e];
          return '<li class="opus__agenda-evt' + (ev.cl ? ' ' + esc(ev.cl) : '') + '" style="--opus-agenda-c: ' + esc(ev.c) + '">' +
            '<span class="opus__agenda-heure">' + esc(o.h || (o.p ? T.journee : T.suite)) + '</span>' +
            '<span class="opus__agenda-point" aria-hidden="true"></span>' +
            '<span class="opus__agenda-quoi"><button type="button" class="opus__agenda-ouvrir" data-e="' + o.e + '" data-o="' + o.o + '">' + esc(ev.t) + '</button>' +
            (ev.l ? '<span class="opus__agenda-ou">' + esc(ev.l) + '</span>' : '') + '</span></li>';
        }).join('') + '</ul>';
      } else {
        h += '<p class="opus__agenda-vide">' + esc(T.vide) + '</p>';
      }

      zoneJour.innerHTML = h;

      // La fiche suit : celle de la premiere seance du jour, sauf si l'on vient d'une fiche.
      if (occ.length && mode !== 'popup' && !garderFiche) { ouvrir(occ[0].e, occ[0].o, false); }
      garderFiche = false;
    }

    /* L'ANNEE : douze petits mois, un point sous chaque jour qui a un evenement. */
    function dessinerAnnee() {
      if (!zoneAnnee) { return; }

      var tete = '<thead><tr>' + d.jours.map(function (j) {
        return '<th scope="col"><abbr title="' + esc(j.long) + '">' + esc(j.court.charAt(0)) + '</abbr></th>';
      }).join('') + '</tr></thead>';
      var h = '';

      for (var m = 0; m < 12; m++) {
        h += '<div class="opus__agenda-an-mois"><button type="button" class="opus__agenda-an-titre" data-mois="' + m + '">' + esc(d.mois[m]) + '</button>' +
          '<table class="opus__agenda-an-table"><caption class="visually-hidden">' + esc(d.mois[m] + ' ' + an) + '</caption>' + tete + '<tbody>';

        semaines(an, m).forEach(function (sem) {
          h += '<tr>';
          sem.forEach(function (jd) {
            if (jd.getMonth() !== m) { h += '<td></td>'; return; }
            var jour = iso(jd);
            var occ  = parJour(jour);
            h += '<td' + (jour === d.auj ? ' class="opus__agenda-auj"' : '') + '><button type="button" class="opus__agenda-jour' + (occ.length ? ' opus__agenda-jour--plein' : '') + '" data-voir="' + jour + '"' +
              (occ.length ? ' style="--opus-agenda-c: ' + esc(d.ev[occ[0].e].c) + '"' : '') + '>' + jd.getDate() +
              (occ.length ? '<span class="visually-hidden">, ' + esc(compte(occ.length)) + '</span>' : '') + '</button></td>';
          });
          h += '</tr>';
        });

        h += '</tbody></table></div>';
      }

      zoneAnnee.innerHTML = h;
    }

    /* LA VUE EN COURS, redessinee, et son titre au-dessus. */
    function dessiner() {
      if (vue === 'jour') {
        dessinerJourVu();
        if (periode) { periode.textContent = dateLongue(dateDe(jourVu)); }
      } else if (vue === 'annee') {
        dessinerAnnee();
        if (periode) { periode.textContent = String(an); }
      } else {
        dessinerMois();
      }
    }

    function montrerVue() {
      if (!toutes) { return; }
      var zones = { mois: racine.querySelector('.opus__agenda-mois'), liste: racine.querySelector('.opus__agenda-liste'), jour: zoneJour, annee: zoneAnnee };
      Object.keys(zones).forEach(function (k) { if (zones[k]) { zones[k].hidden = k !== vue; } });
      var nav = racine.querySelector('.opus__agenda-nav');
      if (nav) { nav.hidden = vue === 'liste'; }
      if (periode) { periode.hidden = vue === 'liste'; }
      var noms = (T.nav || {})[vue];
      if (noms) {
        var pr = racine.querySelector('[data-nav="-1"]');
        var sv = racine.querySelector('[data-nav="1"]');
        if (pr) { pr.setAttribute('aria-label', noms[0]); }
        if (sv) { sv.setAttribute('aria-label', noms[1]); }
      }
      [].forEach.call(racine.querySelectorAll('[data-vue]'), function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-vue') === vue)); });
      if (vue !== 'liste') { dessiner(); }
    }

    /* ALLER A UN JOUR, depuis le mois, l'annee ou « +2 autres ». */
    function allerJour(j) {
      jourVu = j;
      var x = dateDe(j);
      an = x.getFullYear();
      mois = x.getMonth();
      vue = 'jour';
      montrerVue();
      var cible = zoneJour && zoneJour.querySelector('button');
      if (cible) { cible.focus(); } else if (periode) { periode.setAttribute('tabindex', '-1'); periode.focus(); }
    }

    /* LA FICHE : celle de l'evenement choisi, avec la date de CETTE seance. */
    function ouvrir(e, o, focus) {
      var fiches = racine.querySelectorAll('.opus__agenda-fiche');
      var cible = null;

      [].forEach.call(fiches, function (f) {
        var moi = +f.getAttribute('data-e') === e;
        // En liste, toutes restent ; seule la choisie s'allume.
        if (mode === 'liste') { f.classList.toggle('opus__agenda-fiche--active', moi); } else { f.hidden = !moi; }
        if (moi) { cible = f; }
      });

      if (!cible) { return; }

      var estProchain = prochain && prochain.e === e && prochain.o === o;
      var q = cible.querySelector('.opus__agenda-quand');
      cible.setAttribute('data-o', o);
      if (q) { poserQuand(cible, estProchain ? q.getAttribute('data-depart') : ((d.quand[e] || {})[o] || {}).q || q.getAttribute('data-depart')); }
      // « Aussi le » : les autres seances du meme titre, sans celle qu'on regarde.
      var aussi = cible.querySelector('.opus__agenda-info--aussi dd');
      if (aussi) {
        // Les seances qui reviennent sont des evenements de meme titre.
        aussi.textContent = d.occ.filter(function (x) {
          return x.p && x.e !== e && d.ev[x.e].g === d.ev[e].g && (d.passes || x.j >= d.auj);
        }).map(function (x) { return d.quand[x.e][x.o].c; }).join(', ');
      }
      var pr = cible.querySelector('.opus__agenda-prochain');
      if (pr) { pr.hidden = !estProchain; }
      var rt = cible.querySelector('.opus__agenda-retour');
      if (rt) { rt.hidden = estProchain || mode !== 'seule'; }
      if (pr && mode === 'popup') { pr.hidden = true; }
      cible.setAttribute('data-o', o);

      // EN LISTE, le cadre defile jusqu'a la fiche, pas la page : comme un repere de la carte.
      if (mode === 'liste' && defile) {
        defile.scrollTo({ top: cible.offsetTop - defile.offsetTop - 4, behavior: focus ? 'smooth' : 'auto' });
      }

      if (mode === 'popup') {
        if (focus && dialogue) {
          retourFocus = document.activeElement;
          if (!dialogue.open) { dialogue.showModal(); }
          var tt = cible.querySelector('.opus__agenda-fichetitre');
          if (tt) { tt.setAttribute('tabindex', '-1'); tt.focus(); }
        }
        return;
      }

      if (focus) {
        var t = cible.querySelector('.opus__agenda-fichetitre');
        if (t) {
          t.setAttribute('tabindex', '-1');
          t.focus({ preventScroll: true });
          if (mode === 'seule' && (cible.getBoundingClientRect().top < 0 || cible.getBoundingClientRect().bottom > window.innerHeight)) {
            cible.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
          }
        }
      }
    }

    /* LE FICHIER .ICS, fabrique ici : rien ne passe par le serveur. */
    function ics(e, o) {
      var ev = d.ev[e];
      var q  = (d.quand[e] || {})[o];
      if (!ev || !q) { return; }

      var echap = function (t) { return String(t || '').replace(/\\/g, '\\\\').replace(/;/g, '\;').replace(/,/g, '\\,').replace(/\r?\n/g, '\\n'); };
      var jour  = q.s.length === 8;
      var maintenant = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d+/, '');
      var lignes = [
        'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Joomanji//Opus//FR', 'CALSCALE:GREGORIAN', 'BEGIN:VEVENT',
        'UID:' + d.id + '-' + e + '-' + o + '-' + q.s + '@' + location.hostname,
        'DTSTAMP:' + maintenant,
        'DTSTART' + (jour ? ';VALUE=DATE:' : ':') + q.s
      ];

      if (q.f) { lignes.push('DTEND' + (jour ? ';VALUE=DATE:' : ':') + q.f); }
      lignes.push('SUMMARY:' + echap(ev.t));
      if (ev.l) { lignes.push('LOCATION:' + echap(ev.l)); }
      if (ev.u) { lignes.push('URL:' + new URL(ev.u, location.href).href); }
      lignes.push('END:VEVENT', 'END:VCALENDAR');

      var blob = new Blob([lignes.join('\r\n') + '\r\n'], { type: 'text/calendar;charset=utf-8' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = (ev.t.normalize ? ev.t.normalize('NFD').replace(/[\u0300-\u036f]/g, '') : ev.t).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '.ics';
      document.body.appendChild(a);
      a.click();
      window.setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
    }

    /*
     * « AJOUTER A MON AGENDA » OUVRE UN PETIT MENU, 4 octobre 2026. « Choisir
     * son agenda, par exemple Google Agenda, et le valider simplement »,
     * Cyrille. Google et Outlook ont chacun une adresse qui ouvre leur fenetre
     * d'ajout deja remplie : un clic, puis Enregistrer chez eux. Les autres
     * (Apple, Thunderbird, le telephone) lisent le fichier .ics.
     */
    function dates(q) {
      var jour = q.s.length === 8;
      var lire = function (t) {
        return new Date(+t.slice(0, 4), +t.slice(4, 6) - 1, +t.slice(6, 8), jour ? 0 : +t.slice(9, 11), jour ? 0 : +t.slice(11, 13));
      };
      var ecrire = function (dt) {
        return dt.getFullYear() + pad(dt.getMonth() + 1) + pad(dt.getDate()) + (jour ? '' : 'T' + pad(dt.getHours()) + pad(dt.getMinutes()) + '00');
      };
      var debut = lire(q.s);
      var fin = q.f ? lire(q.f) : new Date(debut.getTime() + (jour ? 86400000 : 3600000));
      var iso = function (dt) {
        return dt.getFullYear() + '-' + pad(dt.getMonth() + 1) + '-' + pad(dt.getDate()) + (jour ? '' : 'T' + pad(dt.getHours()) + ':' + pad(dt.getMinutes()) + ':00');
      };
      return { jour: jour, s: ecrire(debut), f: ecrire(fin), isoS: iso(debut), isoF: iso(fin) };
    }

    function fermerMenus() {
      [].forEach.call(racine.querySelectorAll('.opus__agenda-ajout'), function (m) { m.remove(); });
      [].forEach.call(racine.querySelectorAll('.opus__agenda-ics[aria-expanded="true"]'), function (b) { b.setAttribute('aria-expanded', 'false'); });
    }

    function menuAgenda(bouton, e, o) {
      var ouvert = bouton.getAttribute('aria-expanded') === 'true';
      fermerMenus();
      if (ouvert) { return; }

      var ev = d.ev[e];
      var q  = (d.quand[e] || {})[o];
      if (!ev || !q) { return; }

      var t = dates(q);
      var url = ev.u ? new URL(ev.u, location.href).href : location.href;
      var google = 'https://calendar.google.com/calendar/render?action=TEMPLATE'
        + '&text=' + encodeURIComponent(ev.t)
        + '&dates=' + t.s + '/' + t.f
        + (t.jour ? '' : '&ctz=' + encodeURIComponent(d.tz || 'UTC'))
        + (ev.l ? '&location=' + encodeURIComponent(ev.l) : '')
        + '&details=' + encodeURIComponent(url);
      var outlook = 'https://outlook.live.com/calendar/0/deeplink/compose?path=%2Fcalendar%2Faction%2Fcompose&rru=addevent'
        + '&subject=' + encodeURIComponent(ev.t)
        + '&startdt=' + encodeURIComponent(t.isoS)
        + '&enddt=' + encodeURIComponent(t.isoF)
        + (t.jour ? '&allday=true' : '')
        + (ev.l ? '&location=' + encodeURIComponent(ev.l) : '')
        + '&body=' + encodeURIComponent(url);
      var nf = '<span class="visually-hidden"> ' + esc(T.fenetre || '') + '</span>';
      var menu = document.createElement('div');
      menu.className = 'opus__agenda-ajout';
      menu.innerHTML = '<a href="' + esc(google) + '" target="_blank" rel="noopener">' + esc(T.google) + nf + '</a>'
        + '<a href="' + esc(outlook) + '" target="_blank" rel="noopener">' + esc(T.outlook) + nf + '</a>'
        + '<button type="button" class="opus__agenda-ajout-ics" data-e="' + e + '" data-o="' + o + '">' + esc(T.fichier) + '</button>';
      bouton.setAttribute('aria-expanded', 'true');
      bouton.insertAdjacentElement('afterend', menu);
      menu.querySelector('a').focus();
      menu.addEventListener('click', function (x) { if (x.target.closest('a')) { window.setTimeout(fermerMenus, 0); } });
    }

    document.addEventListener('keydown', function (x) {
      if (x.key === 'Escape' && racine.querySelector('.opus__agenda-ajout')) {
        var b = racine.querySelector('.opus__agenda-ics[aria-expanded="true"]');
        fermerMenus();
        if (b) { b.focus(); }
      }
    });

    document.addEventListener('click', function (x) {
      if (!x.target.closest('.opus__agenda-ajout, .opus__agenda-ics')) { fermerMenus(); }
    });

    racine.addEventListener('click', function (ev) {
      var b = ev.target.closest('button');
      if (!b || !racine.contains(b)) { return; }

      if (b.hasAttribute('data-nav')) {
        var n = +b.getAttribute('data-nav');
        if (n === 0) {
          an = +p[0]; mois = +p[1] - 1; jourVu = d.auj;
        } else if (vue === 'jour') {
          var x = dateDe(jourVu);
          x.setDate(x.getDate() + n);
          jourVu = iso(x); an = x.getFullYear(); mois = x.getMonth();
        } else if (vue === 'annee') {
          an += n;
        } else {
          mois += n; if (mois < 0) { mois = 11; an--; } if (mois > 11) { mois = 0; an++; }
        }
        dessiner();
        return;
      }

      if (b.hasAttribute('data-voir')) {
        if (dialogue && dialogue.open) { dialogue.close(); }
        var depuis = b.classList.contains('opus__agenda-voirjour') ? b.closest('.opus__agenda-fiche') : null;
        garderFiche = !!depuis;
        allerJour(b.getAttribute('data-voir'));
        // Venue d'une fiche, la journee garde cette fiche allumee.
        if (depuis && mode !== 'popup') { ouvrir(+depuis.getAttribute('data-e'), +depuis.getAttribute('data-o'), false); }
        return;
      }

      if (b.hasAttribute('data-mois')) {
        mois = +b.getAttribute('data-mois');
        vue = 'mois';
        montrerVue();
        var bm = racine.querySelector('[data-vue="mois"]');
        if (bm) { bm.focus(); }
        return;
      }

      if (b.hasAttribute('data-vue')) {
        vue = b.getAttribute('data-vue');
        montrerVue();
        return;
      }

      if (b.hasAttribute('data-plus')) {
        var j = b.getAttribute('data-plus');
        // Avec toutes les vues, « +2 autres » ouvre la journee entiere.
        if (toutes) { allerJour(j); return; }
        ouverts[j] = true;
        dessinerMois();
        var premier = racine.querySelector('td[data-jour="' + j + '"] .opus__agenda-puce:nth-of-type(3)');
        if (premier) { premier.focus(); }
        return;
      }

      if (b.classList.contains('opus__agenda-jour')) {
        choisi = b.getAttribute('data-jour');
        [].forEach.call(racine.querySelectorAll('.opus__agenda-jour'), function (x) { x.setAttribute('aria-pressed', String(x === b)); });
        dessinerJour();
        return;
      }

      if (b.classList.contains('opus__agenda-ics')) {
        var f = b.closest('.opus__agenda-fiche');
        var e = +b.getAttribute('data-e');
        var o = f && f.hasAttribute('data-o') ? +f.getAttribute('data-o') : (prochain && prochain.e === e ? prochain.o : 0);
        menuAgenda(b, e, o);
        return;
      }

      if (b.classList.contains('opus__agenda-ajout-ics')) {
        ics(+b.getAttribute('data-e'), +b.getAttribute('data-o'));
        fermerMenus();
        return;
      }

      if (b.classList.contains('opus__agenda-retour')) {
        if (prochain) { ouvrir(prochain.e, prochain.o, true); }
        return;
      }

      if (b.hasAttribute('data-e') && b.hasAttribute('data-o')) {
        ouvrir(+b.getAttribute('data-e'), +b.getAttribute('data-o'), true);
      }
    });

    // Le depart : la vue choisie, la fiche du prochain et ses boutons.
    montrerVue();
    if (prochain && !mini && mode !== 'popup') { ouvrir(prochain.e, prochain.o, false); }
    if (mini) { dessinerMois(); }
  }

  function lancer() {
    [].forEach.call(document.querySelectorAll('[data-opus-agenda]'), Agenda);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', lancer);
  } else {
    lancer();
  }
})();
