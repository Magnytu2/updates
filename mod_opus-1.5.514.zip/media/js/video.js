/**
 * LA VIDEO SE CHARGE AU CLIC - 3 octobre 2026
 *
 * Le bouton Lire est un vrai lien vers la video : sans ce script, il l'ouvre
 * chez la plateforme. Avec lui, le lecteur se pose a la place de l'image, et
 * c'est seulement a ce moment que la page contacte YouTube, Vimeo,
 * Dailymotion ou PeerTube. Avant le clic, aucun cookie tiers, aucune requete.
 *
 * LE FOCUS SUIT LA VIDEO : un visiteur au clavier qui vient d'appuyer sur
 * Lire se retrouve dans le lecteur, pas en haut de la page.
 *
 * ON NE TOUCHE QU'A NOS LIENS. Le clic est ecoute sur le document, mais seul
 * un lien qui porte `data-opus-video` est intercepte.
 */
(function () {
	'use strict';

	document.addEventListener('click', function (e) {
		var lien = e.target.closest ? e.target.closest('a.opus__video-lire[data-opus-video]') : null;

		if (!lien || e.ctrlKey || e.metaKey || e.shiftKey || e.button === 1) { return; }

		var adresse = lien.getAttribute('data-opus-video');

		if (!/^https:\/\//.test(adresse)) { return; }

		e.preventDefault();

		var ecran = lien.closest('.opus__video-ecran');
		var cadre = document.createElement('iframe');

		cadre.className = 'opus__video-lecteur';
		cadre.src = adresse;
		cadre.title = lien.getAttribute('data-opus-titre') || '';
		cadre.allow = 'autoplay; fullscreen; picture-in-picture; encrypted-media; clipboard-write';
		cadre.setAttribute('allowfullscreen', '');
		cadre.referrerPolicy = 'strict-origin-when-cross-origin';

		ecran.textContent = '';
		ecran.appendChild(cadre);
		ecran.classList.add('opus__video-ecran--lu');

		cadre.focus();
	});
})();
