<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LA PILE D'ELEMENTS, morceau partage par plusieurs mises en page.
 *
 * LE NOM COMMENCE PAR UN UNDERSCORE, ET CE N'EST PAS UN HASARD. Le champ
 * `modulelayout` du coeur liste les mises en page avec
 * `Folder::files($chemin, '^[^_]*\.php$')` : un nom qui commence par un
 * underscore n'est jamais propose. C'est ainsi que le coeur separe ses
 * morceaux de ses mises en page, et ce fichier ne risque donc pas d'apparaitre
 * comme une disposition a part entiere.
 *
 * POURQUOI IL EXISTE. Quatre dispositions posent la meme pile : titre,
 * sous-titre, texte, separateur, boutons. Recopiee quatre fois, une correction
 * s'applique a trois exemplaires et on cherche la panne dans le quatrieme.
 *
 * Il attend une variable `$liste`, preparee par le repartiteur. Appele par
 * `require`, il partage toutes les autres.
 */

\defined('_JEXEC') or die;
?>
<?php
/*
 * LA CLASSE DE L IMAGE VIENT DE L APPELANT.
 *
 * Dans une carte, Corpus habille `.carte__image` : c est cette classe qui
 * colle l image au bord haut, sans marge et sans rayon a elle. Ailleurs,
 * l image porte la notre. L appelant pose donc `$classeImage` avant le
 * `require`, et ce fichier ne decide rien.
 */
$classeImage = $classeImage ?? 'opus__image';

/*
 * LE LIEN D UNE CARTE S ACCROCHE A SON PREMIER TITRE.
 *
 * Corpus etire `.carte__titre a` sur toute la carte : le titre porte donc
 * le seul vrai lien, et la carte entiere devient cliquable sans ajouter ni
 * balise ni tabulation supplementaire. Hors carte, `$lienCarte` est vide et
 * rien ne change.
 *
 * `$titreLie` retient qu il est pose : les titres suivants de la meme pile
 * restent des titres.
 */
$lienCarte = $lienCarte ?? [];
$titreLie  = false;
?>
<?php foreach ($liste as $el) : ?>
	<?php switch ($el->type) :
		case 'heading': ?>
			<?php if (trim((string) ($el->label ?? '')) !== '') : ?>
				<?php $lie = !$titreLie && !empty($lienCarte['href']); ?>
				<?php $titreLie = $titreLie || $lie; ?>
				<<?php echo $el->tag; ?> class="<?php echo $lie ? 'carte__titre' : 'opus__titre'; ?><?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"<?php echo $el->attrId; ?>>
					<?php if ($lie) : ?>
						<a href="<?php echo htmlspecialchars($lienCarte['href'], ENT_QUOTES, 'UTF-8'); ?>"
						   <?php if (!empty($lienCarte['target'])) : ?>
						   target="<?php echo $lienCarte['target']; ?>" rel="<?php echo $lienCarte['rel']; ?>"
						   <?php endif; ?>>
							<?php echo htmlspecialchars($el->label, ENT_QUOTES, 'UTF-8'); ?>
							<?php if (!empty($lienCarte['mention'])) : ?>
								<span class="visually-hidden"><?php echo $lienCarte['mention']; ?></span>
							<?php endif; ?>
						</a>
					<?php else : ?>
						<?php echo htmlspecialchars($el->label, ENT_QUOTES, 'UTF-8'); ?>
					<?php endif; ?>
				</<?php echo $el->tag; ?>>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'subheading': ?>
			<?php if (trim((string) ($el->label ?? '')) !== '') : ?>
				<p class="opus__soustitre<?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"<?php echo $el->attrId; ?>>
					<?php echo htmlspecialchars($el->label, ENT_QUOTES, 'UTF-8'); ?>
				</p>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'text': ?>
			<?php if (trim((string) ($el->body ?? '')) !== '') : ?>
				<div class="opus__texte<?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"<?php echo $el->attrId; ?>>
					<?php echo $el->body; ?>
				</div>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'image': ?>
			<?php
			/*
			 * LA LARGEUR ET LA HAUTEUR VIENNENT DU GESTIONNAIRE DE MEDIAS.
			 * Elles evitent le decalage de la page au chargement, sans que
			 * personne ait a les saisir.
			 *
			 * UNE IMAGE DECORATIVE GARDE UN `alt` VIDE, et c est le choix fait
			 * dans le champ : `accessiblemedia` rend la case, l assistant rend
			 * le texte, et le RGAA veut l un ou l autre, jamais rien.
			 */
			?>
			<?php if (!empty($el->visuel)) : ?>
				<?php
				/*
				 * UNE SEULE CLASSE DE BASE. `imageClasses` commence deja par
				 * `opus__image` : l ecrire en plus donnait
				 * `opus__image opus__image opus__image--16-9`
				 * dans la page. `$classeImage` ne sert donc que si l assistant n a
				 * rien calcule, ce qui arrive sur un montage enregistre avant que ces
				 * reglages existent.
				 */
				$habits = trim((string) ($el->imageClasses ?? '')) !== ''
				    ? $el->imageClasses
				    : $classeImage;

				/*
				 * UNE IMAGE LEGENDEE EST UNE `figure`, PAS UNE IMAGE SUIVIE D UN
				 * PARAGRAPHE.
				 *
				 * `figcaption` lie la legende a son image : un lecteur d ecran les
				 * annonce ensemble, et la visionneuse de Corpus va y chercher le texte
				 * a afficher sous l image agrandie (`template.js` l. 706). Un `p` pose
				 * dessous ne dirait ni l un ni l autre.
				 *
				 * LA FIGURE NE S ECRIT QUE S IL Y A UNE LEGENDE : sans elle, elle
				 * ajouterait une balise et une marge pour rien.
				 */
				$legende = trim((string) ($el->imgLegende ?? ''));
				?>
				<?php if ($legende !== '') : ?><figure class="opus__figure<?php echo $el->alignement === 'start' ? '' : ' opus__el--' . $el->alignement; ?>"><?php endif; ?>
				<img class="<?php echo $habits; ?><?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"
				     src="<?php echo htmlspecialchars($el->visuel['src'], ENT_QUOTES, 'UTF-8'); ?>"
				     alt="<?php echo htmlspecialchars($el->visuel['alt'], ENT_QUOTES, 'UTF-8'); ?>"
				     <?php if ($el->visuel['width']) : ?>width="<?php echo (int) $el->visuel['width']; ?>"<?php endif; ?>
				     <?php if ($el->visuel['height']) : ?>height="<?php echo (int) $el->visuel['height']; ?>"<?php endif; ?>
				     <?php
				     /*
				      * LES DEUX ATTRIBUTS VONT ENSEMBLE, ET C EST LE SEUL REGLAGE QUI
				      * CHANGE LA VITESSE. `loading="eager"` dit au navigateur de ne pas
				      * attendre, `fetchpriority="high"` lui dit de la faire passer
				      * devant le reste. L un sans l autre ne sert qu a moitie.
				      */
				     ?>
				     <?php if (!empty($el->imageCharge)) : ?>
				     loading="eager" fetchpriority="high"
				     <?php else : ?>
				     loading="lazy"
				     <?php endif; ?>
				     decoding="async"<?php echo $el->imageStyle ?? ''; ?><?php echo $el->attrId; ?>>
				<?php if ($legende !== '') : ?>
					<figcaption class="opus__legende"><?php echo htmlspecialchars($legende, ENT_QUOTES, 'UTF-8'); ?></figcaption>
					</figure>
				<?php endif; ?>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'liste': ?>
			<?php if ($el->items !== []) : ?>
				<?php
				/*
				 * `ul` OU `ol`, ET CE N'EST PAS DECORATIF. Un lecteur d'ecran
				 * annonce « liste de 5 elements », et une liste numerotee dit en
				 * plus que l'ordre compte. Choisir la balise, c'est choisir ce
				 * qu'on annonce.
				 *
				 * « Sans marque » garde la liste et retire les puces : la
				 * structure reste, seul le dessin change.
				 */
				$ordonnee = ($el->listStyle ?? 'puces') === 'numeros';
				$nue      = ($el->listStyle ?? 'puces') === 'nue';
				?>
				<?php
				/*
				 * LES COLONNES SONT UNE CLASSE, PAS UN STYLE EN LIGNE : trois
				 * valeurs possibles, trois classes, et la feuille decide quand elles
				 * se replient.
				 */
				$colonnes = (int) ($el->listColonnes ?? 1);
				$colonnes = $colonnes > 1 && $colonnes < 4 ? $colonnes : 1;
				?>
				<<?php echo $ordonnee ? 'ol' : 'ul'; ?> class="opus__liste<?php echo $nue ? ' opus__liste--nue' : ''; ?><?php echo $colonnes > 1 ? ' opus__liste--colonnes-' . $colonnes : ''; ?><?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"<?php echo $el->attrId; ?>>
					<?php foreach ($el->items as $item) : ?>
						<li>
							<?php if ($item->href !== '') : ?>
								<a href="<?php echo htmlspecialchars($item->href, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($item->texte, ENT_QUOTES, 'UTF-8'); ?></a>
							<?php else : ?>
								<?php echo htmlspecialchars($item->texte, ENT_QUOTES, 'UTF-8'); ?>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</<?php echo $ordonnee ? 'ol' : 'ul'; ?>>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'alerte': ?>
			<?php
			$corps = trim((string) ($el->body ?? ''));
			$titre = trim((string) ($el->label ?? ''));
			?>
			<?php if ($corps !== '' || $titre !== '') : ?>
				<?php
				/*
				 * LE BALISAGE EST CELUI DU TAMPON « Message - Alerte » DE CORPUS,
				 * A LA LETTRE : `message rule message--<ton>`, un `role="note"`, un
				 * `div` interieur, et le titre en `message__titre`. Une alerte
				 * posee par le module et une alerte redigee dans l'editeur doivent
				 * se ressembler au pixel pres.
				 */
				?>
				<div class="message rule message--<?php echo htmlspecialchars((string) ($el->alertTon ?? 'info'), ENT_QUOTES, 'UTF-8'); ?><?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"
				     role="note"<?php echo $el->attrId; ?>>
					<div>
						<?php if ($titre !== '') : ?>
							<p class="message__titre"><?php echo htmlspecialchars($titre, ENT_QUOTES, 'UTF-8'); ?></p>
						<?php endif; ?>
						<?php if ($corps !== '') : ?>
							<?php echo $corps; ?>
						<?php endif; ?>
					</div>
				</div>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'points': ?>
			<?php if ($el->pointsListe !== []) : ?>
				<?php
				/*
				 * LA LISTE DU TAMPON « Page - Points cles avec visuel », SANS SON
				 * IMAGE : elle se pose dans l'autre colonne de la rangee. On livre
				 * la piece, jamais l'assemblage.
				 *
				 * `list-unstyled` ET LES PASTILLES VIENNENT DE BOOTSTRAP, que
				 * Corpus charge (`index.php` l. 85) et dont le tampon se sert deja.
				 * Le rang est ecrit par la mise en page et non par un compteur CSS :
				 * `aria-hidden` le retire de l'annonce, et un numero absent du
				 * document serait absent de l'impression.
				 */
				$marque = (string) ($el->pointsMarque ?? 'numero');
				?>
				<ol class="opus__points list-unstyled<?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"<?php echo $el->attrId; ?>>
					<?php foreach ($el->pointsListe as $rang => $point) : ?>
						<li class="opus__point">
							<?php if ($marque !== 'aucune') : ?>
								<span class="opus__point-marque badge rounded-circle" aria-hidden="true"><?php echo $marque === 'numero' ? (int) $rang + 1 : ''; ?></span>
							<?php endif; ?>
							<div>
								<?php if ($point->titre !== '') : ?>
									<p class="opus__point-titre"><?php echo htmlspecialchars($point->titre, ENT_QUOTES, 'UTF-8'); ?></p>
								<?php endif; ?>
								<?php if ($point->texte !== '') : ?>
									<p class="opus__point-texte"><?php echo $point->texte; ?></p>
								<?php endif; ?>
							</div>
						</li>
					<?php endforeach; ?>
				</ol>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'etat': ?>
			<?php $mot = trim((string) ($el->label ?? '')); ?>
			<?php if ($mot !== '') : ?>
				<?php
				/*
				 * LA COULEUR NE PORTE JAMAIS L'INFORMATION SEULE.
				 *
				 * La pastille est en `aria-hidden` et le mot est ecrit a cote :
				 * qui ne distingue pas le vert du brun lit « Disponible » comme
				 * tout le monde. Le tampon « Grille - Cartes avec etat » fait
				 * deja ainsi, et c'est ce que demande le RGAA.
				 *
				 * LE MOT EST EN `strong`, PAS EN GRAS DE STYLE : c'est une
				 * information importante, pas une decoration, et un lecteur
				 * d'ecran l'annonce comme telle.
				 */
				?>
				<p class="opus__etat opus__etat--<?php echo htmlspecialchars((string) ($el->etatTon ?? 'succes'), ENT_QUOTES, 'UTF-8'); ?><?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"<?php echo $el->attrId; ?>>
					<span class="opus__etat-puce" aria-hidden="true"></span>
					<strong><?php echo htmlspecialchars($mot, ENT_QUOTES, 'UTF-8'); ?></strong>
				</p>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'tableau': ?>
			<?php if ($el->tableauPret !== null) : ?>
				<?php
				/*
				 * LE TABLEAU, 2 octobre 2026 (serie 1.5.4xx).
				 *
				 * `tableau` EST LA CLASSE DE CORPUS : son cadre, ses filets, ses
				 * en-tetes et ses lignes alternees sont ceux de tous les tableaux
				 * du site. `blocs.css` n'ajoute que ce que Corpus ne sait pas :
				 * les reglages par ligne et par colonne, les fiches sur petit
				 * ecran, la premiere colonne figee.
				 *
				 * TOUT EST DEJA DECIDE ET ECHAPPE PAR L'ASSISTANT, sauf le texte
				 * des cases, echappe ici a la sortie.
				 *
				 * LES CLASSES DES LIGNES ET DES CASES viennent de l'assistant :
				 * `opus__tableau-ligne--neutre`, `--teinte`, `--gras`, `--maj`,
				 * `--total` sur la ligne, `opus__tableau-case--centre`, `--droite`,
				 * `--neutre`, `--teinte`, `--gras`, `--maj` sur la case. Elles sont
				 * nommees ici pour que le catalogue de l'onglet CSS les rattache a
				 * l'element Tableau.
				 */
				$tab = $el->tableauPret;
				?>
				<div class="opus__tableau <?php echo $tab->classes; ?>"<?php echo $el->attrId; ?>>
					<div class="opus__tableau-defile" tabindex="0" role="region"<?php echo $tab->nom; ?>>
						<table class="tableau opus__tableau-table" role="table">
							<?php if ($tab->legende !== '') : ?>
								<caption id="<?php echo $tab->idLegende; ?>"><span class="opus__tableau-legende"><?php echo htmlspecialchars($tab->legende, ENT_QUOTES, 'UTF-8'); ?></span></caption>
							<?php endif; ?>
							<?php if ($tab->colonnes !== []) : ?>
								<colgroup>
									<?php foreach ($tab->colonnes as $col) : ?>
										<col<?php echo $col; ?>>
									<?php endforeach; ?>
								</colgroup>
							<?php endif; ?>
							<?php foreach (['thead' => $tab->entete !== null ? [$tab->entete] : [], 'tbody' => $tab->corps] as $groupe => $lignesTab) : ?>
								<?php if ($lignesTab !== []) : ?>
									<<?php echo $groupe; ?> role="rowgroup">
										<?php foreach ($lignesTab as $ligneTab) : ?>
											<tr<?php echo $ligneTab->attrs; ?>>
												<?php foreach ($ligneTab->cases as $caseTab) : ?>
													<<?php echo $caseTab->balise . $caseTab->attrs; ?>><?php echo htmlspecialchars($caseTab->texte, ENT_QUOTES, 'UTF-8'); ?></<?php echo $caseTab->balise; ?>>
												<?php endforeach; ?>
											</tr>
										<?php endforeach; ?>
									</<?php echo $groupe; ?>>
								<?php endif; ?>
							<?php endforeach; ?>
						</table>
					</div>
				</div>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'video': ?>
			<?php if ($el->videoPrete !== null) : ?>
				<?php
				/*
				 * LA VIDEO, 3 octobre 2026 (serie 1.5.4xx).
				 *
				 * UNE PLATEFORME SORT EN FACADE : l'image, et un bouton Lire qui
				 * est un vrai lien vers la video. Sans JavaScript, il l'ouvre
				 * chez la plateforme ; avec, `video.js` pose le lecteur a sa
				 * place. Rien n'est demande a la plateforme avant ce clic.
				 *
				 * UN FICHIER DU SITE SORT EN BALISE `video`, avec les commandes
				 * du navigateur et ses sous-titres.
				 *
				 * L'IMAGE EST DECORATIVE (`alt` vide) : c'est le bouton qui porte
				 * le titre de la video, et c'est lui qu'un lecteur d'ecran lit.
				 *
				 * Classes : `opus__video`, `opus__video-ecran`, `opus__video-image`,
				 * `opus__video-lire`, `opus__video-titre`, `opus__video-avis`,
				 * `opus__video-legende`, `opus__video-transcription`,
				 * `opus__video-fichier`, `opus__video--verticale`.
				 */
				$vid = $el->videoPrete;
				$e   = static fn ($t) => htmlspecialchars((string) $t, ENT_QUOTES, 'UTF-8');
				?>
				<figure class="opus__video<?php echo $vid->sorte === 'plateforme' && $vid->vertical ? ' opus__video--verticale' : ''; ?><?php echo $vid->classes !== '' ? ' ' . $vid->classes : ''; ?>"<?php echo $el->attrId; ?>>
					<?php if ($vid->sorte === 'plateforme') : ?>
						<div class="opus__video-ecran" style="--opus-video-ratio: <?php echo $vid->ratio; ?>">
							<?php if ($vid->image !== '') : ?>
								<img class="opus__video-image" src="<?php echo $e($vid->image); ?>" alt="" loading="lazy" decoding="async">
							<?php endif; ?>
							<a class="opus__video-lire" href="<?php echo $e($vid->lien); ?>" data-opus-video="<?php echo $e($vid->lecteur); ?>" data-opus-titre="<?php echo $e($vid->titre); ?>" aria-label="<?php echo $e(\Joomla\CMS\Language\Text::sprintf('MOD_OPUS_VIDEO_PLAY', $vid->titre) . ' (' . \Joomla\CMS\Language\Text::sprintf('MOD_OPUS_VIDEO_NOTICE', $vid->plateforme) . ')'); ?>">
								<span class="opus__video-titre" aria-hidden="true"><?php echo $e($vid->titre); ?></span>
								<span class="opus__video-rond" aria-hidden="true"></span>
							</a>
							<span class="opus__video-avis" aria-hidden="true"><?php echo $e(\Joomla\CMS\Language\Text::sprintf('MOD_OPUS_VIDEO_NOTICE', $vid->plateforme)); ?></span>
						</div>
					<?php else : ?>
						<div class="opus__video-ecran opus__video-ecran--fichier">
							<video class="opus__video-fichier" controls preload="metadata" playsinline<?php echo $vid->boucle ? ' loop' : ''; ?><?php echo $vid->muet ? ' muted' : ''; ?><?php echo $vid->image !== '' ? ' poster="' . $e($vid->image) . '"' : ''; ?> aria-label="<?php echo $e($vid->titre); ?>">
								<source src="<?php echo $e($vid->src); ?>"<?php echo $vid->mime !== '' ? ' type="' . $vid->mime . '"' : ''; ?>>
								<?php if ($vid->pistes !== null) : ?>
									<track kind="captions" src="<?php echo $e($vid->pistes['src']); ?>" srclang="<?php echo $e($vid->pistes['langue']); ?>" label="<?php echo $e($vid->pistes['nom']); ?>" default>
								<?php endif; ?>
								<a href="<?php echo $e($vid->src); ?>"><?php echo $e($vid->titre); ?></a>
							</video>
						</div>
					<?php endif; ?>
					<?php if ($vid->legende !== '') : ?>
						<figcaption class="opus__video-legende"><?php echo $e($vid->legende); ?></figcaption>
					<?php endif; ?>
					<?php if ($vid->transcription !== '') : ?>
						<details class="opus__video-transcription">
							<summary><?php echo \Joomla\CMS\Language\Text::_('MOD_OPUS_VIDEO_TRANSCRIPT_OPEN'); ?></summary>
							<div class="opus__video-transcription-texte"><?php echo nl2br($e($vid->transcription)); ?></div>
						</details>
					<?php endif; ?>
				</figure>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'carte': ?>
			<?php if ($el->cartePrete !== null) : ?>
				<?php
				/*
				 * LA CARTE, 3 octobre 2026 (serie 1.5.4xx).
				 *
				 * LA LISTE EST ECRITE EN TEXTE, TOUJOURS : c'est elle qu'un lecteur
				 * d'ecran lit, et elle reste la si la carte ne se charge pas. Les
				 * reperes de la zone sont decoratifs (`aria-hidden`), leurs numeros
				 * ou pictogrammes sont les memes que ceux de la liste.
				 *
				 * AVANT LE CLIC, AUCUNE TUILE : un fond neutre, les reperes, et le
				 * bouton « Afficher la carte » que `carte.js` rend visible. Sans
				 * script, la zone reste un schema et la liste porte tout.
				 *
				 * Classes : `opus__carte`, `opus__carte--liste-droite`, `-gauche`,
				 * `-dessus`, `-dessous`, `opus__carte--goutte`, `--rond`, `--carre`,
				 * `opus__carte-zone`, `opus__carte-repere`, `opus__carte-lieux`,
				 * `opus__carte-lieu`, `opus__carte-trajet`.
				 */
				$map = $el->cartePrete;
				$e   = static fn ($t) => htmlspecialchars((string) $t, ENT_QUOTES, 'UTF-8');
				$T   = static fn ($k) => \Joomla\CMS\Language\Text::_($k);
				?>
				<div class="opus__carte <?php echo $e($map->classes); ?>"<?php echo $el->attrId; ?> data-opus-carte="<?php echo $e($map->donnees); ?>">
					<p class="opus__carte-titre" id="<?php echo $map->id; ?>-titre"><?php echo $e($map->titre); ?></p>
					<div class="opus__carte-corps">
						<div class="opus__carte-zone" role="region" aria-labelledby="<?php echo $map->id; ?>-titre" style="--opus-carte-h: <?php echo (int) $map->hauteur; ?>px">
							<div class="opus__carte-fond" aria-hidden="true"<?php echo $map->image !== '' ? ' style="background-image: url(\'' . $e($map->image) . '\')"' : ''; ?>></div>
							<?php if ($map->image !== '') : ?>
								<span class="opus__carte-credit">&copy; OpenStreetMap</span>
							<?php endif; ?>
							<div class="opus__carte-reperes" aria-hidden="true">
								<?php foreach ($map->lieux as $lieu) : ?>
									<?php if ($lieu->lat !== null) : ?>
										<span class="opus__carte-repere<?php echo $lieu->classe !== '' ? ' ' . $e($lieu->classe) : ''; ?>" data-n="<?php echo $lieu->n; ?>" style="left: calc(50% + <?php echo (int) ($lieu->dx ?? 0); ?>px); top: calc(50% + <?php echo (int) ($lieu->dy ?? 0); ?>px); --opus-repere: <?php echo $e($lieu->couleur); ?>"><span><?php echo $lieu->marque; ?></span></span>
									<?php endif; ?>
								<?php endforeach; ?>
							</div>
							<button type="button" class="opus__carte-afficher" hidden><?php echo $T('MOD_OPUS_MAP_SHOW'); ?></button>
							<span class="opus__carte-avis" aria-hidden="true"><?php echo $T('MOD_OPUS_MAP_NOTICE'); ?></span>
						</div>
						<div class="opus__carte-defile" tabindex="0" role="region" aria-labelledby="<?php echo $map->id; ?>-titre" style="--opus-carte-h: <?php echo (int) $map->hauteur; ?>px">
						<ol class="opus__carte-lieux" aria-labelledby="<?php echo $map->id; ?>-titre">
							<?php foreach ($map->lieux as $lieu) : ?>
								<li class="opus__carte-lieu<?php echo $lieu->classe !== '' ? ' ' . $e($lieu->classe) : ''; ?>" data-n="<?php echo $lieu->n; ?>" data-classe="<?php echo $e($lieu->classe); ?>">
									<span class="opus__carte-repere opus__carte-repere--liste" aria-hidden="true" style="--opus-repere: <?php echo $e($lieu->couleur); ?>"><span><?php echo $lieu->marque; ?></span></span>
									<?php if (($lieu->image ?? '') !== '') : ?>
										<img class="opus__carte-image" src="<?php echo $e($lieu->image); ?>" alt="" loading="lazy">
									<?php endif; ?>
									<span class="opus__carte-nom">
										<?php if ($lieu->lien !== []) : ?>
											<a href="<?php echo $e($lieu->lien['href']); ?>"<?php echo $lieu->lien['target'] !== '' ? ' target="_blank" rel="noopener"' : ''; ?>><?php echo $e($lieu->nom); ?><?php if ($lieu->lien['mention'] !== '') : ?><span class="visually-hidden"> <?php echo $lieu->lien['mention']; ?></span><?php endif; ?></a>
										<?php else : ?>
											<?php echo $e($lieu->nom); ?>
										<?php endif; ?>
									</span>
									<?php if ($lieu->adresse !== '') : ?>
										<address class="opus__carte-adresse"><?php echo $e($lieu->adresse); ?></address>
									<?php endif; ?>
									<?php if ($lieu->infos !== []) : ?>
										<ul class="opus__carte-infos">
											<?php foreach ($lieu->infos as $info) : ?>
												<li class="opus__carte-info opus__carte-info--<?php echo $e($info->sorte); ?><?php echo $info->classe !== '' ? ' ' . $e($info->classe) : ''; ?>">
													<?php if ($info->intitule !== '') : ?>
														<span class="opus__carte-info-nom"><?php echo $e($info->intitule) . $T('MOD_OPUS_LABEL_SEP'); ?></span>
													<?php endif; ?>
													<?php if (($info->html ?? '') !== '') : ?>
														<?php // Le rendu d'un champ personnalise, prepare par son plugin du coeur. ?>
														<?php echo $info->html; ?>
													<?php elseif ($info->href !== '') : ?>
														<a href="<?php echo $e($info->href); ?>"<?php echo $info->onglet ? ' target="_blank" rel="noopener"' : ''; ?>><?php echo $e($info->texte); ?><?php if ($info->onglet) : ?><span class="visually-hidden"> <?php echo $T('MOD_OPUS_NEW_WINDOW'); ?></span><?php endif; ?></a>
													<?php else : ?>
														<?php echo nl2br($e($info->texte)); ?>
													<?php endif; ?>
												</li>
											<?php endforeach; ?>
										</ul>
									<?php endif; ?>
									<?php if ($lieu->lat !== null && $map->route) : ?>
										<button type="button" class="opus__carte-route" data-n="<?php echo $lieu->n; ?>" hidden><?php echo $T('MOD_OPUS_MAP_ROUTE_HERE'); ?></button>
									<?php elseif ($lieu->guidage !== '') : ?>
										<a class="opus__carte-guidage" href="<?php echo $e($lieu->guidage); ?>" target="_blank" rel="noopener"><?php echo $T('MOD_OPUS_MAP_DIRECTIONS'); ?><span class="visually-hidden"> <?php echo $T('MOD_OPUS_NEW_WINDOW'); ?></span></a>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ol>
						</div>
					</div>
					<div class="opus__carte-trajet" hidden></div>
				</div>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'agenda': ?>
			<?php if ($el->agendaPret !== null) : ?>
				<?php
				/*
				 * L'AGENDA, 4 octobre 2026 (serie 1.5.4xx).
				 *
				 * TOUT EST ECRIT ICI, LISIBLE SANS SCRIPT : le mois en cours en vrai
				 * tableau, la liste des evenements a venir, et la fiche de chaque
				 * evenement (une seule visible, celle du prochain). `agenda.js` montre
				 * les boutons, change de mois et de vue, ouvre une autre fiche et
				 * fabrique le fichier .ics. Sans lui, les deux vues restent affichees.
				 *
				 * Classes : `opus__agenda`, `opus__agenda--deux`, `--mois`, `--liste`,
				 * `--mini`, `opus__agenda--fiche-droite`, `-gauche`, `-dessous`,
				 * `opus__agenda--l3` a `--l6`, `opus__agenda-mois`, `opus__agenda-puce`,
				 * `opus__agenda-liste`, `opus__agenda-fiche`, `opus__agenda-info--lieu`…
				 */
				$ag = $el->agendaPret;
				$e  = static fn ($t) => htmlspecialchars((string) $t, ENT_QUOTES, 'UTF-8');
				$T  = static fn ($k) => \Joomla\CMS\Language\Text::_($k);
				$mini = $ag->vue === 'mini';
				?>
				<div class="opus__agenda <?php echo $e($ag->classes); ?>"<?php echo $el->attrId; ?> id="<?php echo $ag->id; ?>" data-opus-agenda="<?php echo $e($ag->donnees); ?>">
					<p class="opus__agenda-titre" id="<?php echo $ag->id; ?>-titre"><?php echo $e($ag->titre); ?></p>
					<div class="opus__agenda-corps">
						<div class="opus__agenda-vues">
							<div class="opus__agenda-outils">
								<div class="opus__agenda-nav" hidden>
									<button type="button" class="opus__agenda-btn" data-nav="-1" aria-label="<?php echo $T('MOD_OPUS_AGENDA_PREV'); ?>"><span aria-hidden="true">&lsaquo;</span></button>
									<button type="button" class="opus__agenda-btn" data-nav="1" aria-label="<?php echo $T('MOD_OPUS_AGENDA_NEXT'); ?>"><span aria-hidden="true">&rsaquo;</span></button>
									<?php if (!$mini) : ?>
										<button type="button" class="opus__agenda-btn" data-nav="0"><?php echo $T('MOD_OPUS_AGENDA_TODAY'); ?></button>
									<?php endif; ?>
								</div>
								<p class="opus__agenda-periode" aria-live="polite"><?php echo $e($ag->periode); ?></p>
								<?php if ($ag->vue === 'deux') : ?>
									<div class="opus__agenda-bascule" role="group" aria-label="<?php echo $T('MOD_OPUS_AGENDA_VIEW_LABEL'); ?>" hidden>
										<button type="button" class="opus__agenda-btn" data-vue="jour" aria-pressed="<?php echo $ag->depart === 'jour' ? 'true' : 'false'; ?>"><?php echo $T('MOD_OPUS_AGENDA_VIEW_DAY'); ?></button>
										<button type="button" class="opus__agenda-btn" data-vue="mois" aria-pressed="<?php echo $ag->depart === 'mois' ? 'true' : 'false'; ?>"><?php echo $T('MOD_OPUS_AGENDA_VIEW_MONTH'); ?></button>
										<button type="button" class="opus__agenda-btn" data-vue="annee" aria-pressed="<?php echo $ag->depart === 'annee' ? 'true' : 'false'; ?>"><?php echo $T('MOD_OPUS_AGENDA_VIEW_YEAR'); ?></button>
										<button type="button" class="opus__agenda-btn" data-vue="liste" aria-pressed="<?php echo $ag->depart === 'liste' ? 'true' : 'false'; ?>"><?php echo $T('MOD_OPUS_AGENDA_VIEW_LIST'); ?></button>
									</div>
								<?php endif; ?>
							</div>

							<?php if ($ag->vue !== 'liste') : ?>
								<div class="opus__agenda-mois">
									<table class="opus__agenda-table">
										<caption class="visually-hidden"><?php echo $e($ag->titre . ', ' . $ag->periode); ?></caption>
										<thead>
											<tr>
												<?php foreach ($ag->jours as $j) : ?>
													<th scope="col"><abbr title="<?php echo $e($j['long']); ?>"><?php echo $e($mini ? mb_substr($j['court'], 0, 1) : $j['court']); ?></abbr></th>
												<?php endforeach; ?>
											</tr>
										</thead>
										<tbody>
											<?php foreach ($ag->semaines as $semaine) : ?>
												<tr>
													<?php foreach ($semaine as $jour) : ?>
														<td class="<?php echo trim(($jour->hors ? 'opus__agenda-hors ' : '') . ($jour->auj ? 'opus__agenda-auj ' : '') . ($jour->passe ? 'opus__agenda-passe' : '')); ?>" data-jour="<?php echo $jour->jour; ?>">
															<?php if ($mini) : ?>
																<button type="button" class="opus__agenda-jour<?php echo $jour->occ !== [] ? ' opus__agenda-jour--plein' : ''; ?>" data-jour="<?php echo $jour->jour; ?>" aria-pressed="<?php echo $jour->auj ? 'true' : 'false'; ?>"<?php echo $jour->occ !== [] ? ' style="--opus-agenda-c: ' . $e($ag->evenements[$jour->occ[0]['e']]->couleur) . '"' : ''; ?>><?php echo $jour->num; ?><?php if ($jour->occ !== []) : ?><span class="visually-hidden">, <?php echo \count($jour->occ); ?></span><?php endif; ?></button>
															<?php else : ?>
																<span class="opus__agenda-num"><?php echo $jour->num; ?></span>
																<?php foreach (\array_slice($jour->occ, 0, 2) as $o) : ?>
																	<?php $ev = $ag->evenements[$o['e']]; ?>
																	<button type="button" class="opus__agenda-puce<?php echo $ev->classe !== '' ? ' ' . $e($ev->classe) : ''; ?>" data-e="<?php echo $o['e']; ?>" data-o="<?php echo $o['o']; ?>" style="--opus-agenda-c: <?php echo $e($ev->couleur); ?>"><?php if ($o['h'] !== '') : ?><b><?php echo $e($o['h']); ?></b> <?php endif; ?><?php echo $e($ev->titre); ?></button>
																<?php endforeach; ?>
																<?php if (\count($jour->occ) > 2) : ?>
																	<button type="button" class="opus__agenda-plus" data-plus="<?php echo $jour->jour; ?>"><?php echo $e(sprintf(\count($jour->occ) - 2 > 1 ? $T('MOD_OPUS_AGENDA_JS_MORE') : $T('MOD_OPUS_AGENDA_JS_ONE_MORE'), \count($jour->occ) - 2)); ?></button>
																<?php endif; ?>
															<?php endif; ?>
														</td>
													<?php endforeach; ?>
												</tr>
											<?php endforeach; ?>
										</tbody>
									</table>
								</div>
							<?php endif; ?>

							<?php if ($mini) : ?>
								<div class="opus__agenda-jourliste" aria-live="polite">
									<p class="opus__agenda-jourtitre"><?php echo $e($ag->jourAuj); ?></p>
									<?php $occAuj = []; foreach ($ag->semaines as $s) { foreach ($s as $j) { if ($j->auj) { $occAuj = $j->occ; } } } ?>
									<?php if ($occAuj !== []) : ?>
										<ul class="opus__agenda-jourevts">
											<?php foreach ($occAuj as $o) : ?>
												<?php $ev = $ag->evenements[$o['e']]; ?>
												<li><?php if ($o['h'] !== '') : ?><b><?php echo $e($o['h']); ?></b> <?php endif; ?><?php if (($ev->lien['href'] ?? '') !== '') : ?><a href="<?php echo $e($ev->lien['href']); ?>"><?php echo $e($ev->titre); ?></a><?php else : ?><?php echo $e($ev->titre); ?><?php endif; ?></li>
											<?php endforeach; ?>
										</ul>
									<?php else : ?>
										<p class="opus__agenda-vide"><?php echo $T('MOD_OPUS_AGENDA_EMPTY_DAY'); ?></p>
									<?php endif; ?>
								</div>
							<?php endif; ?>

							<?php if ($ag->vue === 'deux') : ?>
								<?php // Le jour et l'annee : dessines par agenda.js, qui seul montre leurs boutons. ?>
								<div class="opus__agenda-jourvue" hidden></div>
								<div class="opus__agenda-annee" hidden></div>
							<?php endif; ?>

							<?php if ($ag->vue === 'deux' || $ag->vue === 'liste') : ?>
								<div class="opus__agenda-liste">
									<?php if ($ag->liste === []) : ?>
										<p class="opus__agenda-vide"><?php echo $T('MOD_OPUS_AGENDA_NONE'); ?></p>
									<?php else : ?>
										<?php foreach ($ag->liste as $jour) : ?>
											<h3 class="opus__agenda-listejour"><span><?php echo $e($jour->nom); ?></span> <span><?php echo $e($jour->date); ?></span></h3>
											<ul class="opus__agenda-evts">
												<?php foreach ($jour->occ as $o) : ?>
													<?php $ev = $ag->evenements[$o['e']]; ?>
													<li class="opus__agenda-evt<?php echo $ev->classe !== '' ? ' ' . $e($ev->classe) : ''; ?>" style="--opus-agenda-c: <?php echo $e($ev->couleur); ?>">
														<span class="opus__agenda-heure"><?php echo $e($o['h'] !== '' ? $o['h'] : ($o['p'] ? $T('MOD_OPUS_AGENDA_ALLDAY') : $T('MOD_OPUS_AGENDA_CONTINUED'))); ?></span>
														<span class="opus__agenda-point" aria-hidden="true"></span>
														<span class="opus__agenda-quoi">
															<button type="button" class="opus__agenda-ouvrir" data-e="<?php echo $o['e']; ?>" data-o="<?php echo $o['o']; ?>"><?php echo $e($ev->titre); ?></button>
															<?php if ($ev->lieu !== '') : ?><span class="opus__agenda-ou"><?php echo $e($ev->lieu); ?></span><?php endif; ?>
														</span>
													</li>
												<?php endforeach; ?>
											</ul>
										<?php endforeach; ?>
									<?php endif; ?>
								</div>
							<?php endif; ?>

							<?php if ($ag->legende !== []) : ?>
								<ul class="opus__agenda-legende" aria-label="<?php echo $T('MOD_OPUS_AGENDA_LEGEND'); ?>">
									<?php foreach ($ag->legende as $l) : ?>
										<li style="--opus-agenda-c: <?php echo $e($l->couleur); ?>"><?php echo $e($l->nom); ?></li>
									<?php endforeach; ?>
								</ul>
							<?php endif; ?>
						</div>

						<?php if (!$mini) : ?>
							<?php
							/*
							 * TROIS FACONS DE MONTRER LES FICHES. A droite ou a gauche, TOUTES,
							 * dans un cadre qui defile a la hauteur de l'agenda, comme la liste
							 * des lieux de la carte : la prochaine est allumee. Dessous, une
							 * seule, celle qu'on a choisie. En fenetre, `agenda.js` les deplace
							 * dans un `dialog` ; sans script, elles restent dessous, lisibles.
							 */
							$enListe = \in_array($ag->fiche, ['droite', 'gauche'], true);
							?>
							<div class="opus__agenda-fiches">
								<div class="opus__agenda-defile"<?php echo $enListe ? ' tabindex="0" role="region" aria-label="' . $e($ag->titre) . '"' : ''; ?>>
								<?php foreach ($ag->fiches as $ev) : ?>
									<?php $estProchain = $ag->prochain !== null && $ag->prochain['e'] === $ev->n; ?>
									<article class="opus__agenda-fiche<?php echo $estProchain ? ' opus__agenda-fiche--active' : ''; ?><?php echo $ev->passe ? ' opus__agenda-fiche--passee' : ''; ?><?php echo $ev->classe !== '' ? ' ' . $e($ev->classe) : ''; ?>" data-e="<?php echo $ev->n; ?>" data-o="<?php echo (int) $ev->depart; ?>" style="--opus-agenda-c: <?php echo $e($ev->couleur); ?>" aria-labelledby="<?php echo $ag->id . '-f' . $ev->n; ?>"<?php echo (!$enListe && !$estProchain) ? ' hidden' : ''; ?>>
										<p class="opus__agenda-prochain"><?php echo $T('MOD_OPUS_AGENDA_NEXT_EVENT'); ?></p>
										<?php if ($ev->image !== '') : ?>
											<img class="opus__agenda-image" src="<?php echo $e($ev->image); ?>" alt="" loading="lazy">
										<?php endif; ?>
										<h3 class="opus__agenda-fichetitre" id="<?php echo $ag->id . '-f' . $ev->n; ?>"><?php if (($ev->lien['href'] ?? '') !== '') : ?><a href="<?php echo $e($ev->lien['href']); ?>"<?php echo $ev->lien['target'] !== '' ? ' target="_blank" rel="noopener"' : ''; ?>><?php echo $e($ev->titre); ?></a><?php else : ?><?php echo $e($ev->titre); ?><?php endif; ?></h3>
										<dl class="opus__agenda-infos">
											<div class="opus__agenda-info opus__agenda-info--quand"><dt><?php echo $T('MOD_OPUS_AGENDA_WHEN') . $T('MOD_OPUS_LABEL_SEP'); ?></dt><dd class="opus__agenda-quand"><?php echo $e($ev->quand); ?></dd></div>
											<?php if ($ev->autresDates !== []) : ?>
												<div class="opus__agenda-info opus__agenda-info--aussi"><dt><?php echo $T('MOD_OPUS_AGENDA_ALSO') . $T('MOD_OPUS_LABEL_SEP'); ?></dt><dd><?php echo $e(implode(', ', $ev->autresDates)); ?></dd></div>
											<?php endif; ?>
											<?php foreach ($ev->infos as $info) : ?>
												<div class="opus__agenda-info opus__agenda-info--<?php echo $e($info->sorte); ?><?php echo $info->classe !== '' ? ' ' . $e($info->classe) : ''; ?>">
													<?php if ($info->intitule !== '') : ?><dt><?php echo $e($info->intitule) . $T('MOD_OPUS_LABEL_SEP'); ?></dt><?php endif; ?>
													<dd>
														<?php if (($info->html ?? '') !== '') : ?>
															<?php // Le rendu du champ personnalise, prepare par son plugin du coeur. ?>
															<?php echo $info->html; ?>
														<?php elseif ($info->href !== '') : ?>
															<a href="<?php echo $e($info->href); ?>"<?php echo $info->onglet ? ' target="_blank" rel="noopener"' : ''; ?>><?php echo $e($info->texte); ?><?php if ($info->onglet) : ?><span class="visually-hidden"> <?php echo $T('MOD_OPUS_NEW_WINDOW'); ?></span><?php endif; ?></a>
														<?php else : ?>
															<?php echo nl2br($e($info->texte)); ?>
														<?php endif; ?>
														<?php if ($info->adresse !== '') : ?>
															<address class="opus__agenda-adresse"><?php echo $e($info->adresse); ?></address>
														<?php endif; ?>
														<?php if ($info->carte !== '') : ?>
															<a class="opus__agenda-voir" href="<?php echo $e($info->carte); ?>" target="_blank" rel="noopener"><?php echo $T('MOD_OPUS_AGENDA_SEE_MAP'); ?><span class="visually-hidden"> <?php echo $T('MOD_OPUS_NEW_WINDOW'); ?></span></a>
														<?php endif; ?>
													</dd>
												</div>
											<?php endforeach; ?>
										</dl>
										<div class="opus__agenda-actions">
												<?php if (($ev->lien['href'] ?? '') !== '') : ?>
													<a class="opus__agenda-lien" href="<?php echo $e($ev->lien['href']); ?>"<?php echo $ev->lien['target'] !== '' ? ' target="_blank" rel="noopener"' : ''; ?>><?php echo $e($ev->lienTexte !== '' ? $ev->lienTexte : $T('MOD_OPUS_AGENDA_MORE_INFO')); ?><?php if ($ev->lien['mention'] !== '') : ?><span class="visually-hidden"> <?php echo $ev->lien['mention']; ?></span><?php endif; ?></a>
												<?php endif; ?>
												<?php if ($ag->ics) : ?>
													<button type="button" class="opus__agenda-ics" data-e="<?php echo $ev->n; ?>" aria-expanded="false" hidden><svg aria-hidden="true" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="5" width="17" height="15.5" rx="2"/><path d="M8 3v4M16 3v4M3.5 10h17M12 13v5M9.5 15.5h5"/></svg><?php echo $T('MOD_OPUS_AGENDA_ADD'); ?></button>
												<?php endif; ?>
												<button type="button" class="opus__agenda-retour" hidden><svg aria-hidden="true" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/></svg><?php echo $T('MOD_OPUS_AGENDA_BACK'); ?></button>
											</div>
									</article>
								<?php endforeach; ?>
								</div>
							</div>
						<?php endif; ?>
					</div>
					<?php if ($ag->schema !== '') : ?>
						<script type="application/ld+json"><?php echo $ag->schema; ?></script>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'fiche': ?>
			<?php if ($el->ficheListe !== []) : ?>
				<?php
				/*
				 * LA FICHE, D'APRES LE TAMPON « DONNEES - FICHE ».
				 *
				 * UN `dl`, ET UN `div` PAR PAIRE. Le `div` n'est pas decoratif : sans
				 * lui, rien ne relie un `dt` a son `dd` pour la mise en page, et une
				 * fiche de dix lignes se lirait en deux colonnes decalees. C'est le
				 * balisage du tampon, a la lettre, et le HTML l'autorise depuis
				 * longtemps.
				 *
				 * `corpus-specs` EST UNE CLASSE DE CORPUS : c'est elle qui pose le
				 * filet entre les lignes et pousse la valeur a droite. Sans Corpus la
				 * fiche reste une liste de definitions lisible, sans ses filets. A
				 * ajouter a la feuille de repli de Cassiopeia.
				 *
				 * UN TERME SANS VALEUR SORT QUAND MEME, et sa valeur reste vide : une
				 * caracteristique qu'on annonce sans la renseigner est une information
				 * en soi, et un `dt` sans `dd` casserait la liste.
				 */
				?>
				<dl class="corpus-specs<?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"<?php echo $el->attrId; ?>>
					<?php foreach ($el->ficheListe as $ligne) : ?>
						<div>
							<dt><?php echo htmlspecialchars($ligne->terme, ENT_QUOTES, 'UTF-8'); ?></dt>
							<dd><?php echo htmlspecialchars($ligne->valeur, ENT_QUOTES, 'UTF-8'); ?></dd>
						</div>
					<?php endforeach; ?>
				</dl>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'adresse': ?>
			<?php
			/*
			 * L'ADRESSE, D'APRES LE TAMPON « PAGE - COORDONNEES ».
			 *
			 * `<address>` N'EST PAS UNE COQUETTERIE. C'est la balise que le tampon
			 * emploie, et elle dit « voici comment joindre le responsable de ce
			 * contenu ». Un `p` dirait « voici du texte ». La difference ne se voit
			 * pas a l'ecran ; elle s'entend au lecteur d'ecran et se lit dans les
			 * donnees structurees.
			 *
			 * LE NOM DE L'ORGANISME EST DEDANS, pas au-dessus : il fait partie de
			 * ce qu'on recopie sur une enveloppe.
			 *
			 * C'EST ICI QUE LA CARTE VIENDRA SE GREFFER. Les coordonnees
			 * geographiques, calculees une fois a l'enregistrement, se poseront sur
			 * cet element et non sur le contact : c'est l'adresse qu'on place sur un
			 * fond de carte, pas un numero de telephone.
			 */
			$coordNom = trim((string) ($el->coordNom ?? ''));
			?>
			<?php if ($coordNom !== '' || $el->coordLignes !== []) : ?>
				<address class="opus__adresse<?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"<?php echo $el->attrId; ?>>
					<?php if ($coordNom !== '') : ?>
						<strong><?php echo htmlspecialchars($coordNom, ENT_QUOTES, 'UTF-8'); ?></strong><?php echo $el->coordLignes !== [] ? '<br>' : ''; ?>
					<?php endif; ?>
					<?php foreach ($el->coordLignes as $rang => $ligne) : ?>
						<?php echo htmlspecialchars($ligne, ENT_QUOTES, 'UTF-8'); ?><?php echo $rang < \count($el->coordLignes) - 1 ? '<br>' : ''; ?>
					<?php endforeach; ?>
				</address>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'contact': ?>
			<?php
			/*
			 * LE CONTACT : CE QUI SE CLIQUE, ET CE QUI SE LIT.
			 *
			 * LE TELEPHONE ET LE COURRIEL SONT DES LIENS. Le lien `tel:` est calcule
			 * par le repartiteur depuis le numero affiche : personne ne saisit son
			 * numero deux fois. Le tampon le justifie : « sur telephone, on appelle
			 * d'un doigt au lieu de recopier dix chiffres. »
			 *
			 * LES INTITULES SONT ECRITS, PAS SOUS-ENTENDUS. « 01 00 00 00 00 » seul,
			 * lu a voix haute par une machine, ne dit pas si c'est un telephone ou
			 * un numero de dossier. Ils passent par les langues du module, donc ils
			 * suivent la langue du site.
			 */
			$coordMail   = trim((string) ($el->coordCourriel ?? ''));
			$coordTel    = trim((string) ($el->coordTel ?? ''));
			$coordHeures = trim((string) ($el->coordHoraires ?? ''));
			?>
			<?php if ($coordTel !== '' || $coordMail !== '' || $coordHeures !== '') : ?>
				<div class="opus__contact<?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"<?php echo $el->attrId; ?>>
					<?php if ($coordTel !== '' || $coordMail !== '') : ?>
						<p class="opus__coord-joindre">
							<?php if ($coordTel !== '') : ?>
								<?php echo \Joomla\CMS\Language\Text::_('MOD_OPUS_COORD_PHONE_LABEL'); ?>
								<?php if ($el->coordTelLien !== '') : ?>
									<a href="tel:<?php echo htmlspecialchars($el->coordTelLien, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($coordTel, ENT_QUOTES, 'UTF-8'); ?></a>
								<?php else : ?>
									<?php echo htmlspecialchars($coordTel, ENT_QUOTES, 'UTF-8'); ?>
								<?php endif; ?>
								<?php echo $coordMail !== '' ? '<br>' : ''; ?>
							<?php endif; ?>
							<?php if ($coordMail !== '') : ?>
								<?php echo \Joomla\CMS\Language\Text::_('MOD_OPUS_COORD_MAIL_LABEL'); ?>
								<a href="mailto:<?php echo htmlspecialchars($coordMail, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($coordMail, ENT_QUOTES, 'UTF-8'); ?></a>
							<?php endif; ?>
						</p>
					<?php endif; ?>
					<?php if ($coordHeures !== '') : ?>
						<p class="opus__coord-heures"><?php echo nl2br(htmlspecialchars($coordHeures, ENT_QUOTES, 'UTF-8')); ?></p>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'liens': ?>
			<?php if ($el->liensListe !== []) : ?>
				<?php
				/*
				 * MEME DESSIN QUE LA LISTE, MEMES CLASSES : un sommaire fait de
				 * liens et une liste ecrite a la main doivent se ressembler, sinon
				 * la page raconte que ce sont deux choses differentes.
				 */
				$style    = (string) ($el->liensStyle ?? 'numeros');
				$ordonnee = $style === 'numeros';
				$nue      = $style === 'nue';
				$colonnes = (int) ($el->liensColonnes ?? 1);
				$colonnes = $colonnes > 1 && $colonnes < 4 ? $colonnes : 1;
				?>
				<?php if ($style === 'etiquettes') : ?>
					<?php
					/*
					 * LES ETIQUETTES SONT UNE LISTE, PAS UNE SUITE DE LIENS.
					 *
					 * Le tampon « Donnees - Etiquettes » de Corpus le dit et le
					 * justifie : « C'est une liste et non une suite de liens : le
					 * lecteur d'ecran annonce alors leur nombre, et on sait combien il
					 * en reste a parcourir. » D'ou le `ul` et les `li`, que l'aplat
					 * visuel ne montre pas.
					 *
					 * `etiquettes` ET `etiquette` SONT DES CLASSES DE CORPUS, pas des
					 * notres : c'est le template qui les habille (`template.css`
					 * l. 2335 et 2348). Sur un site qui ne tourne pas sous Corpus la
					 * liste reste lisible, elle perd sa forme de pastille. Les deux
					 * classes sont donc a ajouter a la feuille de repli de Cassiopeia,
					 * avec `.bouton`, `.carte`, `.message` et `.accordeon`.
					 *
					 * SANS CIBLE, L'ETIQUETTE N'EST PAS UN LIEN. Un `a` sans `href`
					 * n'est pas atteignable au clavier et ne s'annonce pas : on ecrit
					 * alors un `span`, qui porte la meme classe et ne promet rien.
					 */
					?>
					<ul class="etiquettes<?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"<?php echo $el->attrId; ?>>
						<?php foreach ($el->liensListe as $lien) : ?>
							<li>
								<?php if (!empty($lien->lien['href'])) : ?>
									<a class="etiquette" href="<?php echo htmlspecialchars($lien->lien['href'], ENT_QUOTES, 'UTF-8'); ?>"
									   <?php if (!empty($lien->lien['target'])) : ?>
									   target="<?php echo $lien->lien['target']; ?>" rel="<?php echo $lien->lien['rel']; ?>"
									   <?php endif; ?>>
										<?php echo htmlspecialchars($lien->texte, ENT_QUOTES, 'UTF-8'); ?>
										<?php if (!empty($lien->lien['mention'])) : ?>
											<span class="visually-hidden"><?php echo $lien->lien['mention']; ?></span>
										<?php endif; ?>
									</a>
								<?php else : ?>
									<span class="etiquette"><?php echo htmlspecialchars($lien->texte, ENT_QUOTES, 'UTF-8'); ?></span>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php else : ?>
				<<?php echo $ordonnee ? 'ol' : 'ul'; ?> class="opus__liste<?php echo $nue ? ' opus__liste--nue' : ''; ?><?php echo $colonnes > 1 ? ' opus__liste--colonnes-' . $colonnes : ''; ?><?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"<?php echo $el->attrId; ?>>
					<?php foreach ($el->liensListe as $lien) : ?>
						<li>
							<?php if (!empty($lien->lien['href'])) : ?>
								<a href="<?php echo htmlspecialchars($lien->lien['href'], ENT_QUOTES, 'UTF-8'); ?>"
								   <?php if (!empty($lien->lien['target'])) : ?>
								   target="<?php echo $lien->lien['target']; ?>" rel="<?php echo $lien->lien['rel']; ?>"
								   <?php endif; ?>>
									<?php echo htmlspecialchars($lien->texte, ENT_QUOTES, 'UTF-8'); ?>
									<?php if (!empty($lien->lien['mention'])) : ?>
										<span class="visually-hidden"><?php echo $lien->lien['mention']; ?></span>
									<?php endif; ?>
								</a>
							<?php else : ?>
								<?php echo htmlspecialchars($lien->texte, ENT_QUOTES, 'UTF-8'); ?>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</<?php echo $ordonnee ? 'ol' : 'ul'; ?>>
				<?php endif; ?>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'citation': ?>
			<?php
			$dit   = trim((string) ($el->body ?? ''));
			$source = trim((string) ($el->quoteSource ?? ''));
			?>
			<?php if ($dit !== '') : ?>
				<?php if ($source !== '') : ?>
					<?php
					/*
					 * L'ATTRIBUTION SORT DU `blockquote`, ET CE N'EST PAS UN DETAIL
					 * DE PURISTE. Ce qui est cite, ce sont les mots, pas la
					 * signature : la mettre dedans ferait dire a l'auteur qu'il a
					 * prononce son propre nom. La `figure` les reunit sans les
					 * confondre, et c'est ce que recommande le HTML.
					 */
					?>
					<figure class="opus__citation<?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"<?php echo $el->attrId; ?>>
						<blockquote><?php echo $dit; ?></blockquote>
						<figcaption class="opus__citation-source"><?php echo htmlspecialchars($source, ENT_QUOTES, 'UTF-8'); ?></figcaption>
					</figure>
				<?php else : ?>
					<blockquote class="<?php echo $el->classe; ?>"<?php echo $el->attrId; ?>><?php echo $dit; ?></blockquote>
				<?php endif; ?>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'chiffres': ?>
			<?php if ($el->chiffresListe !== []) : ?>
				<?php
				/*
				 * UNE LISTE DE DESCRIPTIONS, ET C'EST EXACTEMENT CE QUE C'EST : un
				 * terme, sa definition. `dl` l'annonce comme tel ; une suite de
				 * paragraphes en gras ne dirait pas que 1 200 et « personnes
				 * accompagnees » vont ensemble.
				 *
				 * LA VALEUR AVANT LE LIBELLE DANS LE DOCUMENT, et le CSS les
				 * inverse a l'ecran quand il le faut : ce qui est lu suit ce qui
				 * est ecrit.
				 */
				?>
				<?php
				/*
				 * LA TAILLE ET LA POSE SONT DEUX CLASSES, PAS DEUX STYLES.
				 *
				 * « Il faudrait que l'on puisse augmenter la taille du texte de
				 * prix », et « le champ Ce qu'il mesure doit etre a droite du
				 * prix », Cyrille, 23 septembre 2026, devant la rangee de tarifs.
				 */
				$habits = ['opus__chiffres'];

				if (($el->chiffresTaille ?? 'normale') !== 'normale') {
					$habits[] = 'opus__chiffres--' . $el->chiffresTaille;
				}

				if (($el->chiffresPose ?? 'dessous') === 'droite') {
					$habits[] = 'opus__chiffres--en-ligne';
				}

				if ($el->classe !== '') {
					$habits[] = $el->classe;
				}
				?>
				<dl class="<?php echo implode(' ', $habits); ?>"<?php echo $el->attrId; ?>>
					<?php foreach ($el->chiffresListe as $chiffre) : ?>
						<div class="opus__chiffre">
							<?php
							/*
							 * CHAQUE PART PORTE SES HABITS, PAS LE `dl` : c'est le
							 * chiffre qu'on veut colorer, ou ce qu'il mesure, ou sa
							 * source, jamais le jeu entier. Le champ Classe de
							 * l'element reste un cran au-dessus, pour ce qui
							 * concerne les trois ensemble.
							 *
							 * UNE SEULE FONCTION POUR LES TROIS : le jour ou une
							 * quatrieme part arrive, il n'y a rien a recopier.
							 */
							$habitsDe = static function (string $base, string $ton, string $classe): string {
								$habits = [$base];

								if ($ton !== '') {
									$habits[] = $base . '--' . $ton;
								}

								if ($classe !== '') {
									$habits[] = $classe;
								}

								return implode(' ', $habits);
							};
							?>
							<dt class="<?php echo $habitsDe('opus__chiffre-valeur', $chiffre->tonValeur, $chiffre->classeValeur); ?>"><?php echo htmlspecialchars($chiffre->valeur, ENT_QUOTES, 'UTF-8'); ?></dt>
							<dd class="<?php echo $habitsDe('opus__chiffre-mesure', $chiffre->tonMesure, $chiffre->classeMesure); ?>"><?php echo htmlspecialchars($chiffre->mesure, ENT_QUOTES, 'UTF-8'); ?></dd>
							<?php if ($chiffre->source !== '') : ?>
								<?php
								/*
								 * LA SOURCE EST UN SECOND `dd`, ET C'EST VOULU.
								 *
								 * Un `dt` peut avoir plusieurs `dd` : le HTML le prevoit,
								 * et c'est exactement le cas ici, « ce que le chiffre
								 * mesure » puis « d'ou il vient ». La sortir du `dl`
								 * romprait le lien entre la source et son chiffre pour un
								 * lecteur d'ecran.
								 *
								 * `note` EST LA CLASSE DE CORPUS pour une mention
								 * discrete, celle du tampon. A ajouter a la feuille de
								 * repli de Cassiopeia.
								 */
								?>
								<dd class="<?php echo $habitsDe('opus__chiffre-source', $chiffre->tonSource, $chiffre->classeSource); ?> note"><?php echo htmlspecialchars($chiffre->source, ENT_QUOTES, 'UTF-8'); ?></dd>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</dl>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'barres': ?>
			<?php if ($el->barresListe !== []) : ?>
				<?php
				/*
				 * UNE LISTE DE DESCRIPTIONS, COMME LES CHIFFRES : un mot, sa part.
				 * `dl` dit que « Design » et « 86 % » vont ensemble ; une suite de
				 * paragraphes ne le dirait pas.
				 *
				 * LE TRAIT EST DANS LE `dd`, PAS A COTE. Un `dl` n'accepte entre
				 * ses paires que `dt` et `dd` : un troisieme element frere, meme
				 * dans un `div`, sortirait du balisage prevu. Le trait accompagne
				 * la valeur, il est donc dedans, avec elle.
				 *
				 * LA PART PASSE PAR UNE VARIABLE CSS, PAS PAR `width`. Un
				 * `--part: 86%` laisse la feuille decider ce qu'elle en fait : une
				 * longueur pour un trait, un angle pour un anneau. Un `width` en
				 * dur ne saurait faire que le premier.
				 *
				 * ELLE SE POSE SUR LA LIGNE, PAS SUR LE TRAIT, et c'est ce qui
				 * permet aux deux formes de partager le meme balisage : en
				 * anneau, c'est la piste qui s'en sert, pas le trait, qui ne sort
				 * meme pas. Les enfants en heritent, un seul style en ligne
				 * suffit.
				 */
				$habits = ['opus__barres'];

				if (($el->barresForme ?? 'traits') === 'anneaux') {
					$habits[] = 'opus__barres--anneaux';
				}

				if (($el->barresTrait ?? 'normale') !== 'normale') {
					$habits[] = 'opus__barres--' . $el->barresTrait;
				}

				if ((string) ($el->barresNombre ?? '1') === '0') {
					$habits[] = 'opus__barres--muettes';
				}

				if ($el->classe !== '') {
					$habits[] = $el->classe;
				}
				?>
				<dl class="<?php echo implode(' ', $habits); ?>"<?php echo $el->attrId; ?>>
					<?php foreach ($el->barresListe as $barre) : ?>
						<?php
						$habitsBarre = ['opus__barre'];

						if ($barre->ton !== '') {
							$habitsBarre[] = 'opus__barre--' . $barre->ton;
						}

						if ($barre->classe !== '') {
							$habitsBarre[] = $barre->classe;
						}
						?>
						<div class="<?php echo implode(' ', $habitsBarre); ?>" style="--part: <?php echo htmlspecialchars((string) $barre->part, ENT_QUOTES, 'UTF-8'); ?>%">
							<dt class="opus__barre-terme"><?php echo htmlspecialchars($barre->terme, ENT_QUOTES, 'UTF-8'); ?></dt>
							<dd class="opus__barre-part">
								<?php
								/*
								 * LE TRAIT EST MASQUE AUX LECTEURS D'ECRAN. Il ne
								 * porte rien que le nombre ecrit a cote ne dise
								 * deja ; annonce, il ferait entendre une boite vide
								 * de plus a chaque ligne.
								 */
								?>
								<span class="opus__barre-piste" aria-hidden="true"><span class="opus__barre-trait"></span></span>
								<span class="opus__barre-nombre"><?php echo htmlspecialchars($barre->ecrit, ENT_QUOTES, 'UTF-8'); ?>&nbsp;%</span>
							</dd>
						</div>
					<?php endforeach; ?>
				</dl>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'accordeon': ?>
			<?php if ($el->voletsListe !== []) : ?>
				<?php
				/*
				 * LE BALISAGE DU TAMPON « FAQ - Accordeon », A LA LETTRE, parce que
				 * c'est `template.js` de Corpus qui le fait vivre : il branche
				 * `.accordeon__bouton`, bascule `aria-expanded` et le `hidden` du
				 * volet. Le module n'ecrit pas une ligne de script.
				 *
				 * L'IDENTIFIANT PORTE LA CLEF DU BLOC ET LE RANG. Deux accordeons
				 * sur la meme page avec un `acc-1` chacun, et le bouton de l'un
				 * ouvrirait le volet de l'autre, sans la moindre erreur pour le
				 * signaler.
				 *
				 * LE NIVEAU DE TITRE SUIT LA PAGE : un accordeon dans une carte
				 * n'est pas au meme rang qu'un accordeon dans une ouverture, et
				 * `$niveauDepart` le sait deja.
				 */
				$rangVolet = 0;
				$balise    = 'h' . min(6, $niveauDepart + 1);
				?>
				<div class="accordeon<?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"<?php echo $el->attrId; ?>>
					<?php foreach ($el->voletsListe as $volet) : ?>
						<?php
						$rangVolet++;
						$idVolet = htmlspecialchars($clefBloc . '-acc-' . $rangVolet, ENT_QUOTES, 'UTF-8');
						?>
						<<?php echo $balise; ?> class="accordeon__titre">
							<button type="button" class="accordeon__bouton"
							        aria-expanded="<?php echo $volet->ouvert ? 'true' : 'false'; ?>"
							        aria-controls="<?php echo $idVolet; ?>">
								<?php echo htmlspecialchars($volet->titre, ENT_QUOTES, 'UTF-8'); ?>
							</button>
						</<?php echo $balise; ?>>
						<div class="accordeon__volet" id="<?php echo $idVolet; ?>"<?php echo $volet->ouvert ? '' : ' hidden'; ?>>
							<?php echo $volet->texte; ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'separator': ?>
			<?php // Un separateur d'espace ne dessine rien : il n'a donc pas de trait a annoncer. ?>
			<?php if (($el->separatorStyle ?? 'thin') === 'space') : ?>
				<div class="opus__espace" aria-hidden="true"></div>
			<?php else : ?>
				<hr class="opus__separateur opus__separateur--<?php echo $el->separatorStyle ?? 'thin'; ?><?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"<?php echo $el->attrId; ?>>
			<?php endif; ?>
			<?php break; ?>

		<?php case 'buttons': ?>
			<?php
			/*
			 * AUTANT DE BOUTONS QUE LA LISTE EN PORTE, chacun avec son format,
			 * ses pictogrammes et son lien. L'assistant a deja ecarte ceux qui
			 * n'ont pas de libelle : un bouton sans libelle ne sort pas,
			 * l'aide du champ le dit et la carte du montage ne le montre pas
			 * non plus.
			 *
			 * LE SENS EST UNE CLASSE, PAS UN STYLE EN LIGNE : « cote a cote »
			 * n'ecrit rien, c'est deja ce que fait la rangee de boutons.
			 */
			?>
			<?php if (!empty($el->boutons)) : ?>
				<p class="opus__boutons<?php echo ($el->sens ?? 'row') === 'column' ? ' opus__boutons--pile' : ''; ?><?php echo $el->classe !== '' ? ' ' . $el->classe : ''; ?>"<?php echo $el->attrId; ?>>
					<?php foreach ($el->boutons as $bouton) : ?>
						<?php
						/*
						 * UN BOUTON SANS LIEN RESTE UN BOUTON, PAS UN LIEN MORT.
						 *
						 * Ecrit `href="#"`, il menait en haut de la page : le
						 * visiteur clique, la page saute, et rien ne se passe.
						 * Sans lien, on rend donc un `<span>` : il se voit, il
						 * ne se clique pas, et aucun lecteur d'ecran ne
						 * l'annonce comme une destination.
						 */
						$href = $bouton->lien['href'] ?? '';
						$balise = $href !== '' ? 'a' : 'span';
						?>
						<<?php echo $balise; ?> class="bouton<?php echo $bouton->variante !== '' ? ' bouton--' . $bouton->variante : ''; ?><?php echo ($bouton->taille ?? '') !== '' ? ' bouton--' . $bouton->taille : ''; ?><?php echo ($bouton->classe ?? '') !== '' ? ' ' . $bouton->classe : ''; ?>"
						   <?php if ($href !== '') : ?>
						   href="<?php echo htmlspecialchars($href, ENT_QUOTES, 'UTF-8'); ?>"
						   <?php endif; ?>
						   <?php if (!empty($bouton->lien['target'])) : ?>
						   target="<?php echo $bouton->lien['target']; ?>" rel="<?php echo $bouton->lien['rel']; ?>"
						   <?php endif; ?>>
							<?php
							/*
							 * LE PICTOGRAMME DOUBLE LE LIBELLE, IL NE LE
							 * REMPLACE JAMAIS. `aria-hidden` et `focusable` a
							 * false : un lecteur d'ecran lit le mot, pas le
							 * dessin. C'est la regle ecrite en tete de la
							 * planche de Corpus, et elle vaut ici.
							 */
							?>
							<?php
							/*
							 * LE HELPER CHOISIT LA MECANIQUE, PAS LA MISE EN
							 * PAGE. Un nom de la planche sort en `<use>`, une
							 * icone declaree par l'administrateur sort en
							 * masque. Ecrire le test ici l'aurait mis en deux
							 * exemplaires, avant et apres, et en quatre le jour
							 * ou un autre bloc porte des boutons.
							 */
							echo $helper->picto($bouton->avant);
							?>
							<?php echo htmlspecialchars($bouton->libelle, ENT_QUOTES, 'UTF-8'); ?>
							<?php echo $helper->picto($bouton->apres); ?>
							<?php if (!empty($bouton->lien['mention'])) : ?>
								<span class="visually-hidden"><?php echo $bouton->lien['mention']; ?></span>
							<?php endif; ?>
						</<?php echo $balise; ?>>
					<?php endforeach; ?>
				</p>
			<?php endif; ?>
			<?php break; ?>

	<?php endswitch; ?>
<?php endforeach; ?>
