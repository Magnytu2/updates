<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   (C) 2026 Joomanji
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

/*
 * LE LECTEUR DE CALENDRIER .ICS, 5 octobre 2026.
 *
 * Demande d'un utilisateur, reprise par Cyrille : afficher dans l'agenda
 * d'Opus les evenements d'un calendrier en ligne (Google Agenda, Outlook,
 * Apple, Nextcloud, l'export de DPCalendar...), par son adresse iCal.
 *
 * ECRIT POUR OPUS, SANS BIBLIOTHEQUE. Regle de Cyrille : pas de dependance de
 * plus. Le format iCalendar (RFC 5545) est du texte ; on n'en lit que ce que
 * l'agenda affiche : titre, debut, fin ou duree, lieu, description, adresse
 * web, et ce qui fait les dates d'un evenement qui revient (RRULE, EXDATE,
 * RECURRENCE-ID).
 *
 * LES REPETITIONS : quotidienne, hebdomadaire, mensuelle, annuelle, avec un
 * intervalle, un nombre de fois ou une date de fin, des jours de la semaine
 * (« le 1er lundi », « le dernier vendredi »), des jours du mois et des mois.
 * C'est ce que produisent les agendas courants. BYSETPOS, BYWEEKNO et les
 * repetitions a l'heure ou a la minute ne sont pas lus : l'evenement garde
 * alors sa seule premiere date, plutot qu'une serie fausse.
 *
 * LES HEURES sont calculees a l'heure du lieu de l'evenement (TZID), puis
 * ramenees au fuseau du site : une seance « tous les mardis a 20 h » reste a
 * 20 h de part et d'autre du changement d'heure.
 */

namespace Joomanji\Module\Opus\Site\Helper;

\defined('_JEXEC') or die;

final class IcsLecteur
{
    /** Au plus, par evenement et en tout : un calendrier tres charge ne bloque pas la page. */
    private const PAR_EVENEMENT = 200;
    private const EN_TOUT       = 1000;
    private const TOURS         = 5000;

    private const JOURS = ['MO' => 1, 'TU' => 2, 'WE' => 3, 'TH' => 4, 'FR' => 5, 'SA' => 6, 'SU' => 7];

    /*
     * Les fuseaux nommes « a la Windows » par Outlook, quand PHP n'a pas
     * l'extension intl pour les traduire. Les plus courants en Europe et en
     * Amerique du Nord ; un nom inconnu prend le fuseau du site.
     */
    private const WINDOWS = [
        'Romance Standard Time'          => 'Europe/Paris',
        'W. Europe Standard Time'        => 'Europe/Berlin',
        'Central Europe Standard Time'   => 'Europe/Budapest',
        'Central European Standard Time' => 'Europe/Warsaw',
        'GMT Standard Time'              => 'Europe/London',
        'Greenwich Standard Time'        => 'Atlantic/Reykjavik',
        'E. Europe Standard Time'        => 'Europe/Chisinau',
        'FLE Standard Time'              => 'Europe/Kiev',
        'GTB Standard Time'              => 'Europe/Bucharest',
        'Russian Standard Time'          => 'Europe/Moscow',
        'Eastern Standard Time'          => 'America/New_York',
        'Central Standard Time'          => 'America/Chicago',
        'Mountain Standard Time'         => 'America/Denver',
        'Pacific Standard Time'          => 'America/Los_Angeles',
        'AUS Eastern Standard Time'      => 'Australia/Sydney',
        'UTC'                            => 'UTC',
    ];

    private \DateTimeZone $site;

    private int $total = 0;

    public function __construct(\DateTimeZone $site)
    {
        $this->site = $site;
    }

    /**
     * Les evenements du calendrier qui touchent la fenetre [$de, $a].
     *
     * Chaque evenement : titre, lieu, description, url, journee, et ses
     * dates, une paire [debut, fin|null] par occurrence, au fuseau du site.
     */
    public function evenements(string $texte, \DateTimeImmutable $de, \DateTimeImmutable $a): array
    {
        $vevents = $this->composants($texte);
        $maitres = [];
        $remplace = [];

        // Les occurrences deplacees ou annulees d'une serie (RECURRENCE-ID), rangees par UID.
        foreach ($vevents as $v) {
            if (isset($v['RECURRENCE-ID'])) {
                $uid = $this->valeur($v, 'UID');
                $rid = $this->date($v['RECURRENCE-ID'][0]);

                if ($uid !== '' && $rid !== null) {
                    $remplace[$uid][$this->cle($rid[0], $rid[1])] = $v;
                    continue;
                }
            }

            $maitres[] = $v;
        }

        $sortie = [];

        foreach ($maitres as $v) {
            if ($this->total >= self::EN_TOUT) {
                break;
            }

            if (strtoupper($this->valeur($v, 'STATUS')) === 'CANCELLED') {
                continue;
            }

            $ev = $this->evenement($v, $remplace[$this->valeur($v, 'UID')] ?? [], $de, $a);

            if ($ev !== null) {
                $sortie[] = $ev;
            }
        }

        // Une occurrence deplacee dont la serie n'est pas dans le fichier : un evenement a part.
        foreach ($remplace as $uid => $liste) {
            foreach ($maitres as $v) {
                if ($this->valeur($v, 'UID') === $uid) {
                    continue 2;
                }
            }

            foreach ($liste as $v) {
                if (strtoupper($this->valeur($v, 'STATUS')) !== 'CANCELLED' && ($ev = $this->evenement($v, [], $de, $a)) !== null) {
                    $sortie[] = $ev;
                }
            }
        }

        return $sortie;
    }

    /** Un VEVENT lu et deplie en dates. */
    private function evenement(array $v, array $remplace, \DateTimeImmutable $de, \DateTimeImmutable $a): ?array
    {
        $titre = $this->valeur($v, 'SUMMARY');
        $d     = isset($v['DTSTART']) ? $this->date($v['DTSTART'][0]) : null;

        if ($titre === '' || $d === null) {
            return null;
        }

        [$debut, $journee] = $d;
        $fin = null;

        if (isset($v['DTEND']) && ($f = $this->date($v['DTEND'][0])) !== null) {
            $fin = $f[0];
        } elseif (isset($v['DURATION'])) {
            $fin = $this->plusDuree($debut, $v['DURATION'][0]['v']);
        }

        // La fin d'une journee entiere est EXCLUSIVE dans le format : le jour d'apres.
        if ($fin !== null && $journee) {
            $fin = $fin->modify('-1 day');
        }

        $duree = ($fin !== null && $fin > $debut) ? $fin->getTimestamp() - $debut->getTimestamp() : 0;

        // Les dates : la premiere, ou toutes celles de la serie.
        $exclues = [];

        foreach ($v['EXDATE'] ?? [] as $p) {
            foreach (explode(',', $p['v']) as $x) {
                if (($e = $this->date(['p' => $p['p'], 'v' => $x])) !== null) {
                    $exclues[$this->cle($e[0], $journee)] = true;
                }
            }
        }

        $starts = isset($v['RRULE']) ? $this->serie($debut, $this->valeur($v, 'RRULE'), $a) : [$debut];
        $dates  = [];

        foreach ($starts as $s) {
            $k = $this->cle($s, $journee);

            if (isset($exclues[$k])) {
                continue;
            }

            $sd = $s;
            $sf = $duree > 0 ? $s->modify('+' . $duree . ' seconds') : null;

            // Une occurrence deplacee prend ses nouvelles dates ; annulee, elle disparait.
            if (isset($remplace[$k])) {
                $r = $remplace[$k];

                if (strtoupper($this->valeur($r, 'STATUS')) === 'CANCELLED') {
                    continue;
                }

                if (isset($r['DTSTART']) && ($rd = $this->date($r['DTSTART'][0])) !== null) {
                    $sd = $rd[0];
                    $sf = (isset($r['DTEND']) && ($rf = $this->date($r['DTEND'][0])) !== null) ? $rf[0] : ($duree > 0 ? $sd->modify('+' . $duree . ' seconds') : null);

                    if ($sf !== null && $rd[1]) {
                        $sf = $sf->modify('-1 day');
                    }
                }
            }

            $sd = $this->auSite($sd, $journee);
            $sf = $sf !== null ? $this->auSite($sf, $journee) : null;
            $sf = ($sf !== null && $sf > $sd) ? $sf : null;

            // Dans la fenetre seulement : ni trop loin dans le passe, ni trop loin devant.
            if (($sf ?? $sd) < $de || $sd > $a) {
                continue;
            }

            $dates[] = [$sd, $sf];

            if (\count($dates) >= self::PAR_EVENEMENT || ++$this->total >= self::EN_TOUT) {
                break;
            }
        }

        if ($dates === []) {
            return null;
        }

        $url = $this->valeur($v, 'URL');

        return [
            'titre'       => $titre,
            'journee'     => $journee,
            'dates'       => $dates,
            'lieu'        => $this->valeur($v, 'LOCATION'),
            'description' => $this->valeur($v, 'DESCRIPTION'),
            'url'         => preg_match('#^https?://#i', $url) ? $url : '',
        ];
    }

    /*
     * LES DATES D'UNE SERIE (RRULE), a l'heure du lieu de l'evenement.
     *
     * On avance periode par periode (jour, semaine, mois, annee, selon FREQ et
     * INTERVAL), on pose dans chaque periode les dates que disent BYDAY,
     * BYMONTHDAY et BYMONTH, et on s'arrete a COUNT, a UNTIL ou a la fin de
     * la fenetre. La premiere date (DTSTART) compte toujours dans COUNT.
     */
    private function serie(\DateTimeImmutable $debut, string $regle, \DateTimeImmutable $limite): array
    {
        $r = [];

        foreach (explode(';', strtoupper($regle)) as $morceau) {
            [$k, $val] = array_pad(explode('=', $morceau, 2), 2, '');
            $r[$k] = $val;
        }

        $freq = $r['FREQ'] ?? '';

        if (!\in_array($freq, ['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY'], true) || isset($r['BYSETPOS']) || isset($r['BYWEEKNO'])) {
            return [$debut];
        }

        $pas   = max(1, (int) ($r['INTERVAL'] ?? 1));
        $count = isset($r['COUNT']) ? max(1, (int) $r['COUNT']) : 0;
        $until = null;

        if (isset($r['UNTIL']) && ($u = $this->date(['p' => [], 'v' => $r['UNTIL']])) !== null) {
            $until = $u[1] ? $u[0]->setTime(23, 59, 59) : $u[0];
        }

        $fin    = $until !== null && $until < $limite ? $until : $limite->setTimezone($debut->getTimezone());
        $jours  = $this->jours($r['BYDAY'] ?? '');
        $mjours = array_values(array_filter(array_map('intval', explode(',', $r['BYMONTHDAY'] ?? '')), static fn ($n) => $n !== 0 && abs($n) <= 31));
        $mois   = array_values(array_filter(array_map('intval', explode(',', $r['BYMONTH'] ?? '')), static fn ($n) => $n >= 1 && $n <= 12));
        $heure  = [(int) $debut->format('H'), (int) $debut->format('i'), (int) $debut->format('s')];

        $sortie = [];
        $n      = 0;

        for ($p = 0, $tours = 0; $tours < self::TOURS; $p += $pas, $tours++) {
            $candidats = [];

            switch ($freq) {
                case 'DAILY':
                    $j = $debut->modify('+' . $p . ' days');

                    if (($jours === [] || isset($jours[(int) $j->format('N')])) && ($mois === [] || \in_array((int) $j->format('n'), $mois, true))) {
                        $candidats[] = $j;
                    }
                    break;

                case 'WEEKLY':
                    // Le lundi de la semaine de depart, puis chaque jour demande de la semaine.
                    $lundi = $debut->modify('-' . ((int) $debut->format('N') - 1) . ' days')->modify('+' . $p . ' weeks');
                    $liste = $jours !== [] ? array_keys($jours) : [(int) $debut->format('N')];
                    sort($liste);

                    foreach ($liste as $jn) {
                        $candidats[] = $lundi->modify('+' . ($jn - 1) . ' days');
                    }
                    break;

                case 'MONTHLY':
                    $m = $debut->modify('first day of this month')->modify('+' . $p . ' months');

                    if ($mois === [] || \in_array((int) $m->format('n'), $mois, true)) {
                        $candidats = $this->dansLeMois($m, $jours, $r['BYDAY'] ?? '', $mjours, (int) $debut->format('j'));
                    }
                    break;

                case 'YEARLY':
                    $an = (int) $debut->format('Y') + $p;

                    foreach ($mois !== [] ? $mois : [(int) $debut->format('n')] as $mo) {
                        $m = $debut->setDate($an, $mo, 1);

                        if ($jours === [] && $mjours === []) {
                            $jour = (int) $debut->format('j');

                            if ($jour <= (int) $m->format('t')) {
                                $candidats[] = $m->setDate($an, $mo, $jour);
                            }
                        } else {
                            $candidats = array_merge($candidats, $this->dansLeMois($m, $jours, $r['BYDAY'] ?? '', $mjours, (int) $debut->format('j')));
                        }
                    }
                    break;
            }

            $passe = false;

            foreach ($candidats as $c) {
                $c = $c->setTime(...$heure);

                if ($c < $debut) {
                    continue;
                }

                if ($c > $fin) {
                    $passe = true;
                    break;
                }

                $sortie[] = $c;
                $n++;

                if (($count && $n >= $count) || \count($sortie) >= self::PAR_EVENEMENT * 3) {
                    return $sortie;
                }
            }

            if ($passe) {
                break;
            }
        }

        // DTSTART fait toujours partie de la serie, meme s'il ne tombe pas sur BYDAY.
        if ($sortie === [] || $sortie[0] != $debut) {
            array_unshift($sortie, $debut);
        }

        return $sortie;
    }

    /** Les dates d'un mois : jours du mois, « 2e mardi », « dernier vendredi », ou tous les lundis. */
    private function dansLeMois(\DateTimeImmutable $m, array $jours, string $byday, array $mjours, int $jourDepart): array
    {
        $total  = (int) $m->format('t');
        $sortie = [];

        foreach ($mjours as $j) {
            $j = $j < 0 ? $total + $j + 1 : $j;

            if ($j >= 1 && $j <= $total) {
                $sortie[] = $m->setDate((int) $m->format('Y'), (int) $m->format('n'), $j);
            }
        }

        if ($jours !== []) {
            foreach (explode(',', $byday) as $b) {
                if (!preg_match('/^([+-]?\d{1,2})?(MO|TU|WE|TH|FR|SA|SU)$/', trim($b), $x)) {
                    continue;
                }

                $jn  = self::JOURS[$x[2]];
                $rang = (int) ($x[1] ?? 0);
                $tous = [];

                for ($j = 1; $j <= $total; $j++) {
                    $d = $m->setDate((int) $m->format('Y'), (int) $m->format('n'), $j);

                    if ((int) $d->format('N') === $jn) {
                        $tous[] = $d;
                    }
                }

                if ($rang === 0) {
                    $sortie = array_merge($sortie, $tous);
                } elseif ($rang > 0 && isset($tous[$rang - 1])) {
                    $sortie[] = $tous[$rang - 1];
                } elseif ($rang < 0 && isset($tous[\count($tous) + $rang])) {
                    $sortie[] = $tous[\count($tous) + $rang];
                }
            }
        }

        if ($sortie === [] && $mjours === [] && $jours === [] && $jourDepart <= $total) {
            $sortie[] = $m->setDate((int) $m->format('Y'), (int) $m->format('n'), $jourDepart);
        }

        usort($sortie, static fn ($a, $b) => $a <=> $b);

        return $sortie;
    }

    /** BYDAY lu en numeros de jour ISO (1 lundi ... 7 dimanche), rangs ignores. */
    private function jours(string $byday): array
    {
        $sortie = [];

        foreach (explode(',', $byday) as $b) {
            if (preg_match('/(MO|TU|WE|TH|FR|SA|SU)$/', trim($b), $x)) {
                $sortie[self::JOURS[$x[1]]] = true;
            }
        }

        return $sortie;
    }

    /*
     * UNE DATE DU FICHIER : [DateTimeImmutable, journee entiere ?].
     * « 20261113 » (VALUE=DATE), « 20261113T090000 » (heure flottante, celle
     * du site), « ...Z » (UTC), ou avec TZID. L'heure est gardee dans le fuseau
     * de l'evenement : auSite() la convertit apres le calcul des series.
     */
    private function date(array $p): ?array
    {
        $v = trim($p['v']);

        if (preg_match('/^(\d{4})(\d{2})(\d{2})$/', $v, $m)) {
            return [new \DateTimeImmutable($m[1] . '-' . $m[2] . '-' . $m[3] . ' 00:00:00', $this->site), true];
        }

        if (!preg_match('/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})(Z?)$/', $v, $m)) {
            return null;
        }

        $tz = $m[7] === 'Z' ? new \DateTimeZone('UTC') : $this->fuseau($p['p']['TZID'] ?? '');

        try {
            return [new \DateTimeImmutable("$m[1]-$m[2]-$m[3] $m[4]:$m[5]:$m[6]", $tz), false];
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** Une heure ramenee au fuseau du site ; une journee entiere reste ce jour-la. */
    private function auSite(\DateTimeImmutable $d, bool $journee): \DateTimeImmutable
    {
        return $journee
            ? new \DateTimeImmutable($d->format('Y-m-d') . ' 00:00:00', $this->site)
            : $d->setTimezone($this->site);
    }

    /** La cle d'une occurrence, pour EXDATE et RECURRENCE-ID : au jour pres, ou a la seconde en UTC. */
    private function cle(\DateTimeImmutable $d, bool $journee): string
    {
        return $journee ? $d->format('Ymd') : $d->setTimezone(new \DateTimeZone('UTC'))->format('Ymd\THis');
    }

    /** Un fuseau nomme par le fichier : nom IANA, nom Windows, sinon celui du site. */
    private function fuseau(string $nom): \DateTimeZone
    {
        $nom = trim($nom, " \"'");

        if ($nom === '') {
            return $this->site;
        }

        try {
            return new \DateTimeZone($nom);
        } catch (\Throwable $e) {
            // Un nom Windows (Outlook), traduit par intl quand il est la, sinon par la table.
        }

        if (class_exists('IntlTimeZone')) {
            $iana = \IntlTimeZone::getIDForWindowsID($nom);

            if (\is_string($iana) && $iana !== '') {
                try {
                    return new \DateTimeZone($iana);
                } catch (\Throwable $e) {
                }
            }
        }

        return isset(self::WINDOWS[$nom]) ? new \DateTimeZone(self::WINDOWS[$nom]) : $this->site;
    }

    /** Une duree ISO (« PT1H30M », « P1D ») ajoutee a une date. */
    private function plusDuree(\DateTimeImmutable $d, string $duree): ?\DateTimeImmutable
    {
        $duree = ltrim(trim($duree), '+');

        if ($duree === '' || $duree[0] === '-') {
            return null;
        }

        try {
            return $d->add(new \DateInterval($duree));
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** La valeur texte d'une propriete, sans les echappements du format. */
    private function valeur(array $v, string $nom): string
    {
        if (!isset($v[$nom][0])) {
            return '';
        }

        return trim(strtr($v[$nom][0]['v'], ['\\n' => "\n", '\\N' => "\n", '\\,' => ',', '\\;' => ';', '\\\\' => '\\']));
    }

    /*
     * LES VEVENT DU FICHIER, en tableaux : [PROPRIETE => [['p' => parametres,
     * 'v' => valeur], ...]]. Les lignes repliees (une ligne qui commence par
     * une espace continue la precedente) sont recollees d'abord. Les VALARM
     * et autres sous-composants d'un evenement sont ignores.
     */
    private function composants(string $texte): array
    {
        $texte = preg_replace("/\r\n[ \t]|\n[ \t]|\r[ \t]/", '', $texte);
        $lignes = preg_split("/\r\n|\n|\r/", $texte);
        $sortie = [];
        $ev = null;
        $profond = 0;

        foreach ($lignes as $l) {
            if ($l === '') {
                continue;
            }

            if (strcasecmp($l, 'BEGIN:VEVENT') === 0) {
                $ev = [];
                $profond = 0;
                continue;
            }

            if ($ev === null) {
                continue;
            }

            if (stripos($l, 'BEGIN:') === 0) {
                $profond++;
                continue;
            }

            if (stripos($l, 'END:') === 0) {
                if ($profond > 0) {
                    $profond--;
                    continue;
                }

                if (strcasecmp($l, 'END:VEVENT') === 0) {
                    $sortie[] = $ev;
                    $ev = null;
                }

                continue;
            }

            if ($profond > 0) {
                continue;
            }

            // NOM;PARAM=VALEUR;PARAM="VA:LEUR":valeur. Les deux-points d'un parametre entre guillemets ne coupent pas.
            if (!preg_match('/^([A-Za-z0-9-]+)((?:;[^:;"]+=(?:"[^"]*"|[^:;"]*))*):(.*)$/s', $l, $m)) {
                continue;
            }

            $params = [];

            if ($m[2] !== '' && preg_match_all('/;([^=;]+)=("[^"]*"|[^;]*)/', $m[2], $pp, PREG_SET_ORDER)) {
                foreach ($pp as $x) {
                    $params[strtoupper($x[1])] = trim($x[2], '"');
                }
            }

            $ev[strtoupper($m[1])][] = ['p' => $params, 'v' => $m[3]];
        }

        return $sortie;
    }
}
