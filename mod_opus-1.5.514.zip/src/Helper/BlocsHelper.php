<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * L'ASSISTANT.
 *
 * Il porte toutes les decisions, pour que les fichiers de tmpl/ ne contiennent
 * que du balisage. C'est ce qui permet a un integrateur d'ecrire SA mise en
 * page dans les surcharges du template sans avoir a redecouvrir ces regles.
 */

namespace Joomanji\Module\Opus\Site\Helper;

use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\Date\Date;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Http\HttpFactory;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Content\Site\Helper\RouteHelper;
use Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;
use Joomla\Registry\Registry;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

class BlocsHelper
{
    /**
     * VRAI DES QU'UN ONGLET A ETE LU DANS LE MONTAGE.
     *
     * Il sert au repartiteur, qui ne demande le script `joomla-tab` du coeur
     * que si la page en a besoin. Le savoir nait ici parce que c'est ici qu'on
     * parcourt le montage : le refaire dans le repartiteur serait lire deux
     * fois la meme chose pour la meme reponse.
     */
    private bool $onglets = false;

    /**
     * VRAI DES QU'UNE VIDEO DE PLATEFORME EST POSEE, pour la meme raison que les
     * onglets : le petit script qui pose le lecteur au clic ne se charge que
     * sur une page qui en a besoin.
     */
    private bool $videos = false;

    /** VRAI DES QU'UNE CARTE EST POSEE : `carte.js` ne se charge qu'alors. */
    private bool $cartes = false;

    /** Le montage porte-t-il au moins une carte ? */
    public function aDesCartes(): bool
    {
        return $this->cartes;
    }

    /** Le montage porte-t-il au moins une video a lancer au clic ? */
    public function aDesVideos(): bool
    {
        return $this->videos;
    }

    /** Le montage lu porte-t-il au moins un element Onglets ? */
    public function aDesOnglets(): bool
    {
        return $this->onglets;
    }

    /**
     * La classe posee sur le conteneur racine du module.
     *
     * Elle sert a deux choses : limiter la portee du CSS personnalise, et
     * donner a l'integrateur un point d'accroche stable.
     *
     * UN SEUL CHAMP POUR CELA, ET C'EST CELUI DU COEUR. Le module a porte un
     * « Classe du montage » a lui jusqu'au 22 septembre 2026, a cote du
     * « Suffixe de classe du module » que Joomla pose dans Parametres avances.
     * Deux champs pour la meme chose, dont un que l'administrateur connait
     * deja depuis quinze ans : le notre est parti.
     */
    /**
     * UNE CLASSE SAISIE SORT ECHAPPEE, ET C'EST LE SEUL ENDROIT QUI LE FAIT.
     *
     * Releve du 25 septembre 2026 : les neuf champs de classe du manifeste, et
     * le suffixe du coeur, arrivaient tels quels dans 39 attributs `class` des
     * fichiers de `tmpl/`. Un guillemet tape par erreur fermait l'attribut, et
     * la suite de la saisie devenait du balisage. Le coeur, lui, passe son
     * suffixe de classe par `htmlspecialchars()` dans chacune de ses mises en
     * page.
     *
     * On echappe ICI, a la lecture, plutot que dans les 39 sorties : toutes
     * les classes saisies passent par cet assistant, aucune mise en page ne les
     * lit dans le Registry. `double_encode` a faux, parce que `preparer()` et
     * `rangees()` peuvent repasser sur une valeur deja lue : un `&amp;` ne
     * doit pas devenir `&amp;amp;`.
     *
     * C'EST LA SECONDE CEINTURE. La premiere est `validate="CssIdentifier"`
     * dans le manifeste : mesure sur le banc, un guillemet saisi dans la
     * classe d'une rangee est refuse a l'enregistrement (« Champ invalide :
     * Classe »). Mais seize champs de classe (valeur, mesure, source, barre)
     * portaient `type="CssIdentifier"`, un type qui n'existe pas : Joomla
     * retombe alors en champ texte, SANS aucun controle. Corrige le meme jour.
     * Cet echappement reste pour ce que le formulaire ne voit pas : un montage
     * importe, une valeur enregistree avant la correction.
     *
     * On ne retire rien : corriger la valeur serait une correction
     * silencieuse du choix de l'utilisateur.
     */
    public function classeSaisie($valeur): string
    {
        return htmlspecialchars(trim((string) $valeur), ENT_QUOTES, 'UTF-8', false);
    }

    public function classeRacine(Registry $params, $module): string
    {
        $classes = ['opus'];

        $suffixe = trim((string) $params->get('moduleclass_sfx', ''));

        if ($suffixe !== '') {
            $classes[] = $this->classeSaisie($suffixe);
        }

        return implode(' ', $classes);
    }

    /**
     * Remet un sous-formulaire en liste simple, dans l'ordre saisi, sans les
     * elements masques.
     *
     * POURQUOI CETTE FONCTION EXISTE : un sous-formulaire enregistre par
     * Joomla revient tantot en tableau, tantot en objet dont les clefs sont
     * des index, selon qu'il a ete relu depuis la base ou depuis le
     * formulaire. Le normaliser une fois evite de traiter les deux cas dans
     * chaque mise en page.
     *
     * L'ORDRE DES LIGNES EST L'ORDRE DU RENDU. La poignee du composant du coeur
     * reordonne les lignes, et nous n'y touchons pas : aucun `order` en CSS,
     * qui ferait diverger ce qui est lu au clavier de ce qui est affiche.
     */
    public function elements($brut): array
    {
        if (empty($brut)) {
            return [];
        }

        $sortie = [];

        foreach ($this->lignes($brut) as $ligne) {
            // Masque : la saisie est gardee, elle ne sort simplement pas.
            if (isset($ligne->show) && (int) $ligne->show === 0) {
                continue;
            }

            $sortie[] = $ligne;
        }

        return $sortie;
    }

    /**
     * Les lignes d'une liste, telles quelles, SANS ecarter les masquees.
     *
     * LES RANGEES N'ONT PLUS D'OEIL, et elles passent donc par ici. Retirer le
     * champ du manifeste ne suffisait pas : un module regle pendant la beta a
     * pu enregistrer `show=0` sur une rangee, et le filtre l'aurait ecartee
     * pour toujours, sans plus aucun bouton pour la faire revenir. Une rangee
     * qu'on ne voit pas et qu'on ne peut pas retrouver est pire que trois
     * facons de la cacher.
     *
     * @param  mixed  $brut  Ce que le registre rend pour une liste.
     * @return array<int, object>
     */
    public function lignes($brut): array
    {
        if (empty($brut)) {
            return [];
        }

        $lignes = \is_object($brut) ? get_object_vars($brut) : (array) $brut;

        return array_map(function ($ligne) { return (object) $ligne; }, array_values($lignes));
    }

    /**
     * Prepare une liste d'elements pour une mise en page.
     *
     * TOUTE DECISION SE PREND ICI, PAS DANS tmpl/. Un fichier de mise en page
     * ne doit contenir que du balisage : c'est ce qui permet a un integrateur
     * d'ecrire la sienne dans les surcharges du template sans redecouvrir la
     * regle du niveau de titre, celle du lien en nouvelle fenetre ou celle de
     * l'image.
     *
     * Chaque element revient avec, selon son type : `tag`, `texte`, `lien`,
     * `image`, `classe`. La mise en page n'a plus qu'a choisir ou les poser.
     */
    public function preparer(array $elements, int $niveauDepart): array
    {
        foreach ($elements as $el) {
            /*
             * LA CLASSE SAISIE ET CELLE DE L'ALIGNEMENT COHABITENT.
             *
             * Le champ derriere la roue dentee s'appelle `classe`, comme dans
             * Corpus, et c'est aussi le nom que porte la classe d'alignement
             * calculee ici : sans ce garde, la premiere ecrasait la seconde en
             * silence, et l'alignement cessait de fonctionner des qu'une classe
             * etait saisie.
             *
             * `blocsBrut` retient la valeur d'origine pour que deux appels de
             * `preparer()` sur la meme liste ne cumulent pas l'alignement.
             */
            if (!isset($el->blocsBrut)) {
                $el->blocsBrut = $this->classeSaisie($el->classe ?? '');
            }

            /*
             * L'ALIGNEMENT EST RENDU DEUX FOIS, ET LES DEUX SERVENT.
             *
             * `classe` porte la classe toute faite, pour une pile d'elements
             * ou chaque element est sa propre boite. `alignement` rend la
             * valeur brute, pour les mises en page qui doivent la poser
             * AILLEURS que sur la boite : dans une carte, `align-self` sur
             * `.carte` l'empecherait de s'etirer a la hauteur de ses voisines,
             * et une carte plus courte que les autres se voit tout de suite.
             */
            $el->alignement = (string) ($el->align ?? 'start');
            $el->classe = trim($this->classeAlignement($el->alignement) . ' ' . $el->blocsBrut);
            $el->identifiant = trim((string) ($el->identifiant ?? ''));

            /*
             * L'ATTRIBUT TOUT FAIT, PARCE QU'UN `id=""` VIDE N'EST PAS ANODIN.
             *
             * Ecrit tel quel dans chaque mise en page, un identifiant absent
             * sortirait `id=""` sur tous les elements de toutes les pages :
             * `document.querySelector('#')` est une erreur de syntaxe, et un
             * validateur le signale a chaque ligne. On rend donc soit
             * l'attribut complet, soit rien du tout.
             */
            $el->attrId = $el->identifiant === ''
                ? ''
                : ' id="' . htmlspecialchars($el->identifiant, ENT_QUOTES, 'UTF-8') . '"';

            if (($el->type ?? '') === 'heading') {
                $el->tag = $this->baliseTitre($el->headingLevel ?? '', $niveauDepart);
            }

            if (isset($el->image)) {
                $el->visuel = $this->image($el->image);
            }

            if (($el->type ?? '') === 'image') {
                $el->imageClasses = $this->habillageImage($el);
                $el->imageStyle   = $this->styleImage($el);
                $el->imageCharge  = ($el->imgChargement ?? 'differe') === 'immediat';
            }

            if (isset($el->linkType)) {
                $el->lien = $this->lien($el);
            }

            // Les boutons, prets a poser. Vide pour les autres types d'element.
            $el->sens    = ($el->sens ?? '') === 'column' ? 'column' : 'row';
            $el->boutons = ($el->type ?? '') === 'buttons' ? $this->boutons($el) : [];

            /*
             * LA LISTE : UNE LIGNE, UN ELEMENT.
             *
             * Le decoupage se fait ici, une fois, et pas dans la mise en page :
             * un integrateur qui surcharge `_elements.php` recoit un tableau
             * pret a parcourir, sans avoir a redecouvrir ce qu'est une ligne.
             *
             * LES LIGNES VIDES SAUTENT. On en laisse toujours une en fin de
             * saisie, et elle sortirait en puce vide.
             */
            $el->items = [];

            if (($el->type ?? '') === 'liste') {
                foreach (preg_split('/\R/', (string) ($el->listItems ?? '')) as $ligne) {
                    $ligne = trim($ligne);

                    if ($ligne === '') {
                        continue;
                    }

                    /*
                     * « TEXTE | ADRESSE » FAIT UN LIEN, ET C'EST TOUT CE QU'IL Y A
                     * A APPRENDRE.
                     *
                     * Mesure faite le 23 septembre 2026 sur la page d'accueil de
                     * landing.joomanji.eu : son sommaire est une liste de huit
                     * LIENS. Une liste qui ne sait ecrire que du texte ne refait
                     * donc pas une page existante, et c'etait le seul manque.
                     *
                     * POURQUOI UNE BARRE ET PAS DU HTML. Ouvrir la zone au HTML
                     * aurait suffi, et aurait demande a celui qui redige de savoir
                     * ecrire une balise `a`. La barre verticale ne s'apprend pas,
                     * elle se voit dans l'aide du champ, et elle reste lisible
                     * quand on relit sa liste six mois plus tard.
                     *
                     * ON COUPE A LA PREMIERE BARRE SEULEMENT : une adresse peut en
                     * contenir une, un texte aussi, et la premiere separe toujours
                     * les deux.
                     */
                    $adresse = '';
                    $barre   = strpos($ligne, '|');

                    if ($barre !== false) {
                        $adresse = trim(substr($ligne, $barre + 1));
                        $ligne   = trim(substr($ligne, 0, $barre));
                    }

                    if ($ligne === '') {
                        continue;
                    }

                    $el->items[] = (object) ['texte' => $ligne, 'href' => $adresse];
                }
            }

            /*
             * LES COORDONNEES : L'ADRESSE EN LIGNES, LE TELEPHONE EN LIEN.
             *
             * DEUX ELEMENTS, PAS UN : `adresse` et `contact`. Arbitrage de
             * Cyrille, 24 septembre 2026, apres avoir vu un element unique
             * livre a demi rempli : « il faut deux blocs, avec des champs
             * differents ». Les deux preparations vivent cote a cote ici parce
             * qu'elles se lisent ensemble, pas parce que ce serait le meme
             * element.
             *
             * DEUX CHOSES SE PREPARENT ICI, ET AUCUNE NE S'INVENTE DANS LA MISE
             * EN PAGE.
             *
             * 1. L'ADRESSE EST UNE SUITE DE LIGNES, comme la liste : c'est ainsi
             *    qu'on ecrit une adresse, et c'est ce que `<address>` attend. Le
             *    saut se fait avec un `<br>` et non un paragraphe par ligne : une
             *    adresse est UN bloc, pas quatre.
             *
             * 2. LE LIEN `tel:` SE CALCULE DEPUIS LE NUMERO AFFICHE. Le tampon
             *    « Page - Coordonnees » de Corpus le dit : « sur telephone, on
             *    appelle d'un doigt au lieu de recopier dix chiffres. » Mais
             *    personne ne doit avoir a saisir deux fois son numero, une fois
             *    pour l'oeil et une fois pour la machine. On garde donc les
             *    chiffres et le `+` de tete, et on jette tout le reste : espaces,
             *    points, tirets, parentheses.
             *
             * CE QUE CE CALCUL NE SAIT PAS FAIRE : deviner un indicatif. Un
             * numero ecrit « 01 00 00 00 00 » donne « tel:0100000000 », qui
             * fonctionne depuis le pays et pas depuis l'etranger. Celui qui veut
             * l'international ecrit « +33 1 00 00 00 00 », et le lien suit. On ne
             * devine pas un pays a partir d'un zero.
             */
            $el->coordLignes = [];

            if (($el->type ?? '') === 'adresse') {
                foreach (preg_split('/\R/', (string) ($el->coordAdresse ?? '')) as $ligne) {
                    $ligne = trim($ligne);

                    if ($ligne !== '') {
                        $el->coordLignes[] = $ligne;
                    }
                }
            }

            $el->coordTelLien = '';

            $numero = trim((string) ($el->coordTel ?? ''));

            if ($numero !== '') {
                $plus  = str_starts_with($numero, '+') ? '+' : '';
                $brut  = preg_replace('/\D+/', '', $numero);

                if ($brut !== '') {
                    $el->coordTelLien = $plus . $brut;
                }
            }

            /*
             * LES CHIFFRES ET LES VOLETS : MEME MECANIQUE QUE LES POINTS.
             *
             * Une entree dont les deux champs sont vides ne sort pas : c'est une
             * ligne ajoutee et pas encore remplie, et elle laisserait un trou.
             */
            $el->chiffresListe = [];

            if (($el->type ?? '') === 'chiffres') {
                foreach ($this->elements($el->chiffres ?? null) as $chiffre) {
                    $valeur = trim((string) ($chiffre->valeur ?? ''));
                    $mesure = trim((string) ($chiffre->mesure ?? ''));

                    if ($valeur === '' && $mesure === '') {
                        continue;
                    }

                    /*
                     * LA SOURCE EST FACULTATIVE ET N'EST PAS DECORATIVE.
                     *
                     * Le tampon « Donnees - Chiffres verifiables » de Corpus
                     * n'ajoute qu'une chose aux chiffres cles : la ligne qui dit
                     * d'ou vient le nombre. « 1 200 personnes accompagnees » est
                     * une affirmation ; « chiffre issu du rapport d'activite
                     * 2026, page 12 » la rend verifiable. Un chiffre sans source
                     * reste possible, c'est le meme element.
                     */
                    $source = trim((string) ($chiffre->source ?? ''));

                    /*
                     * CHAQUE PART DU CHIFFRE PORTE SES PROPRES HABITS.
                     *
                     * « Comment je pourrais faire pour mettre la valeur 1 200 en
                     * rouge ? », Cyrille, 23 puis 24 septembre 2026, puis « il me
                     * faudrait cela pour chaque champ, valeur, mesure et
                     * source ». Le champ Classe de l'element se pose sur le
                     * `dl` : il vise les trois chiffres a la fois, et il faut
                     * connaitre le nom de la classe interne pour descendre
                     * jusqu'a une part.
                     *
                     * DEUX REPONSES QUI NE SE CONCURRENCENT PAS, par part. Le TON
                     * couvre le cas courant sans une ligne de CSS, avec les
                     * couleurs de Corpus. La CLASSE couvre tout le reste, et se
                     * pose au meme endroit.
                     *
                     * LE TON EST FILTRE CONTRE UNE LISTE FERMEE : une valeur
                     * inventee ecrirait une classe qui n'existe pas, et la
                     * feuille resterait muette sans qu'on sache pourquoi.
                     */
                    $habiller = function (string $ton): string {
                        return \in_array($ton, ['accent', 'succes', 'alerte', 'erreur'], true) ? $ton : '';
                    };

                    $el->chiffresListe[] = (object) [
                        'valeur'       => $valeur,
                        'mesure'       => $mesure,
                        'source'       => $source,
                        'tonValeur'    => $habiller((string) ($chiffre->tonValeur ?? '')),
                        'classeValeur' => $this->classeSaisie($chiffre->classeValeur ?? ''),
                        'tonMesure'    => $habiller((string) ($chiffre->tonMesure ?? '')),
                        'classeMesure' => $this->classeSaisie($chiffre->classeMesure ?? ''),
                        'tonSource'    => $habiller((string) ($chiffre->tonSource ?? '')),
                        'classeSource' => $this->classeSaisie($chiffre->classeSource ?? ''),
                    ];
                }
            }

            /*
             * LES BARRES : UNE PART, UN MOT, UN TRAIT.
             *
             * « Ce qui manque : des barres graphe », Cyrille, 24 septembre 2026.
             *
             * LA PART EST BORNEE ICI, ET NULLE PART AILLEURS. Le manifeste pose
             * `min` et `max` sur le champ, mais un `min` de formulaire est un
             * garde-fou de saisie, pas une garantie : un montage importe, un
             * champ vide, une valeur collee, et `width: 340%` sortirait une
             * barre qui deborde de la colonne sans un mot d'erreur. On borne
             * donc au moment de lire, une fois pour toutes.
             *
             * UNE LIGNE SANS MOT NI PART NE SORT PAS, comme partout ailleurs :
             * c'est une ligne ajoutee et pas encore remplie. Une part a zero,
             * elle, est une vraie valeur et sort : « Reste a faire, 0 % » veut
             * dire quelque chose.
             */
            $el->barresListe = [];

            if (($el->type ?? '') === 'barres') {
                foreach ($this->elements($el->barres ?? null) as $barre) {
                    $terme = trim((string) ($barre->terme ?? ''));
                    $brut  = $barre->part ?? '';

                    if ($terme === '' && trim((string) $brut) === '') {
                        continue;
                    }

                    $part = max(0.0, min(100.0, (float) $brut));

                    /*
                     * LE TON EST FILTRE CONTRE UNE LISTE FERMEE, comme celui des
                     * chiffres : une valeur inventee ecrirait une classe qui
                     * n'existe pas, et la feuille resterait muette.
                     */
                    $ton = (string) ($barre->tonBarre ?? '');

                    $el->barresListe[] = (object) [
                        'terme'  => $terme,
                        'part'   => $part,
                        /*
                         * LE NOMBRE ECRIT N'A PAS DE DECIMALE INUTILE : 86 et non
                         * 86.0, mais 12.5 reste 12.5.
                         */
                        'ecrit'  => rtrim(rtrim(number_format($part, 1, ',', ' '), '0'), ','),
                        'ton'    => \in_array($ton, ['accent', 'succes', 'alerte', 'erreur'], true) ? $ton : '',
                        'classe' => $this->classeSaisie($barre->classeBarre ?? ''),
                    ];
                }
            }

            /*
             * LA FICHE : DES PAIRES, MEME MECANIQUE QUE LES CHIFFRES.
             *
             * ELLE RESSEMBLE AUX CHIFFRES CLES ET N'EST PAS LA MEME CHOSE, et la
             * difference vaut d'etre dite parce qu'elle decide laquelle employer.
             * Les chiffres cles MONTRENT trois valeurs, grandes, pour frapper.
             * La fiche ENUMERE cinq ou dix caracteristiques, petites, pour qu'on
             * les consulte : preparation, cuisson, pour combien de personnes.
             * L'une se regarde, l'autre se lit ligne a ligne.
             *
             * C'EST POURQUOI ELLE EST UN ELEMENT A PART et non un reglage de
             * taille des chiffres : le tampon « Donnees - Fiche » de Corpus lui
             * donne une classe a elle, `corpus-specs`, qui pose un filet entre
             * chaque ligne et pousse la valeur a droite. Un reglage de taille ne
             * fabriquerait pas ces filets.
             *
             * UNE LIGNE DONT LES DEUX CHAMPS SONT VIDES NE SORT PAS : c'est une
             * ligne ajoutee et pas encore remplie.
             */
            $el->ficheListe = [];

            if (($el->type ?? '') === 'fiche') {
                foreach ($this->elements($el->fiche ?? null) as $ligne) {
                    $terme  = trim((string) ($ligne->terme ?? ''));
                    $valeur = trim((string) ($ligne->valeur ?? ''));

                    if ($terme === '' && $valeur === '') {
                        continue;
                    }

                    $el->ficheListe[] = (object) ['terme' => $terme, 'valeur' => $valeur];
                }
            }

            /*
             * LE TABLEAU ARRIVE PRET A POSER, comme tout le reste.
             *
             * `tableau` est le champ brut, le JSON que la grille de l'ecran
             * d'administration ecrit. `tableauPret` est ce que la mise en page
             * pose : les cases echappees a l'avance n'existent pas ici, mais
             * chaque decision (en-tete ou case, alignement, fond, la ligne qui
             * l'emporte sur la colonne) est deja prise. Un integrateur qui
             * surcharge `_elements.php` n'a plus que des boucles a ecrire.
             */
            $el->tableauPret = ($el->type ?? '') === 'tableau' ? $this->tableau($el) : null;

            // La video, decidee ici comme le tableau : la mise en page n'a plus qu'a poser.
            $el->videoPrete = ($el->type ?? '') === 'video' ? $this->video($el) : null;

            // La carte aussi : positions trouvees, reperes, liste, tout est decide ici.
            $el->cartePrete = ($el->type ?? '') === 'carte' ? $this->carte($el) : null;

            // L'agenda aussi : occurrences, grille du mois, liste et fiches, tout est decide ici.
            $el->agendaPret = ($el->type ?? '') === 'agenda' ? $this->agenda($el) : null;

            /*
             * LES LIENS : LA MECANIQUE DES BOUTONS, SANS LE BOUTON.
             *
             * `lien()` sait deja lire `linkType`, `linkMenu`, `linkUrl` et
             * `linkNewTab` : c'est le meme jeu de champs, donc le meme
             * assistant. Un lien sans intitule ne sort pas ; c'est l'intitule
             * qu'on lit et qu'on clique.
             */
            $el->liensListe = [];

            if (($el->type ?? '') === 'liens') {
                foreach ($this->elements($el->liens ?? null) as $ligne) {
                    $libelle = trim((string) ($ligne->text ?? ''));

                    // Un lien vers un article, sans intitule, prend le titre de l'article.
                    if ($libelle === '' && (string) ($ligne->linkType ?? '') === 'article') {
                        $libelle = (string) ($this->article((int) ($ligne->linkArticle ?? 0))->titre ?? '');
                    }

                    if ($libelle === '') {
                        continue;
                    }

                    $el->liensListe[] = (object) [
                        'texte' => $libelle,
                        'lien'  => $this->lien($ligne),
                    ];
                }
            }

            $el->voletsListe = [];

            if (($el->type ?? '') === 'accordeon') {
                foreach ($this->elements($el->volets ?? null) as $volet) {
                    $titre = trim((string) ($volet->titre ?? ''));

                    /*
                     * UN VOLET SANS TITRE N'EXISTE PAS : le titre EST le bouton
                     * qui l'ouvre. Sans lui, le contenu serait inatteignable.
                     */
                    if ($titre === '') {
                        continue;
                    }

                    $el->voletsListe[] = (object) [
                        'titre'  => $titre,
                        'texte'  => (string) ($volet->texte ?? ''),
                        'ouvert' => (int) ($volet->ouvert ?? 0) === 1,
                    ];
                }
            }

            /*
             * LES POINTS CLES : UN SOUS-FORMULAIRE, DONC LE MEME TRAITEMENT QUE
             * LES BOUTONS. Un point sans intitule ET sans texte ne sort pas :
             * c'est une ligne ajoutee et pas encore remplie.
             */
            $el->pointsListe = [];

            if (($el->type ?? '') === 'points') {
                foreach ($this->elements($el->points ?? null) as $point) {
                    $titre = trim((string) ($point->titre ?? ''));
                    $texte = trim((string) ($point->texte ?? ''));

                    if ($titre === '' && $texte === '') {
                        continue;
                    }

                    $el->pointsListe[] = (object) ['titre' => $titre, 'texte' => $texte];
                }
            }
        }

        return $elements;
    }

    /**
     * Les rapports permis, en douziemes.
     *
     * REPRIS DE `helper-gabarits.php` DE CORPUS, l. 130, a l'identique : une
     * valeur absente ou fautive rend des parts egales plutot que de casser la
     * page parce qu'un rapport a ete mal saisi. Le reste des douziemes va a la
     * premiere colonne, pour que la somme fasse toujours douze.
     */
    protected function rapport(int $colonnes, string $brut): array
    {
        $parts = array_map('intval', array_filter(explode('-', $brut), 'strlen'));

        if (\count($parts) === $colonnes && array_sum($parts) === 12) {
            return $parts;
        }

        $egal = (int) floor(12 / max(1, $colonnes));
        $rendu = array_fill(0, $colonnes, $egal);
        $rendu[0] += 12 - ($egal * $colonnes);

        return $rendu;
    }

    /**
     * Les codes de colonne permis selon le nombre de colonnes de la rangee.
     *
     * Repris de Corpus, l. 148. `p` pour une rangee d'une seule colonne, puis
     * gauche et droite, puis gauche, centre et droite.
     */
    protected function colonnesPermises(int $colonnes): array
    {
        if ($colonnes >= 3) {
            return ['g', 'c', 'd'];
        }

        if ($colonnes === 2) {
            return ['g', 'd'];
        }

        return ['p'];
    }

    /**
     * Le montage complet : les rangees, leurs colonnes, et les blocs dedans.
     *
     * C'EST LE SEUL ENDROIT QUI CONNAIT LE MODELE. Les fichiers de tmpl/ ne
     * font que parcourir ce qu'il rend : un integrateur qui ecrit sa propre
     * mise en page dans les surcharges du template n'a ni a relire le
     * manifeste, ni a redecouvrir comment un bloc trouve sa rangee.
     *
     * LE MODELE EST CELUI DE CORPUS, A LA LETTRE : `colonnes` de 1 a 3, un
     * rapport en douziemes, des codes de colonne p, g, c, d, un fond qui porte
     * directement la classe de section du template et un « appliquer a » qui
     * le pose sur une seule colonne. Meme normalisation, memes noms, meme
     * repli quand une valeur est fautive.
     *
     * UN BLOC DESIGNE SA RANGEE PAR SON NUMERO, comme une brique. Consequence
     * assumee, et ecrite dans l'aide du champ : deplacer une rangee deplace son
     * numero, pas son contenu.
     *
     * UN BLOC QUI DESIGNE UNE RANGEE INEXISTANTE EST ABANDONNE. Il ne se
     * rattache pas a la derniere rangee, ni a la premiere : apparaitre au
     * mauvais endroit est pire que ne pas apparaitre, parce qu'on cherche la
     * cause dans le contenu au lieu de la chercher dans le numero.
     *
     * @return array<int, object> Une rangee par entree, dans l'ordre de saisie.
     */
    public function montage(Registry $params, int $niveauDepart): array
    {
        $rangees = $this->lignes($params->get('rangees'));
        $blocs   = $this->elements($params->get('blocs'));

        /*
         * RIEN DANS LE NOUVEAU MODELE : on regarde si l'ancien a quelque chose
         * a dire avant de rendre une page vide.
         */
        if ($rangees === []) {
            $reprise = $this->reprise($params);

            if ($reprise === []) {
                return [];
            }

            $rangees = [$reprise[0]];
            $blocs   = $reprise[1];
        }

        $sortie = [];

        foreach ($rangees as $rang => $rangee) {
            $colonnes = max(1, min(3, (int) ($rangee->colonnes ?? 1)));
            $codes    = $this->colonnesPermises($colonnes);
            $fond     = (string) ($rangee->fond ?? '');

            /*
             * SUR QUOI LE FOND SE POSE. Vide : toute la rangee. Sinon le code
             * d'une colonne. Une colonne qui n'existe pas dans cette rangee
             * ramene le fond sur la rangee entiere : mieux vaut un aplat trop
             * large qu'un aplat disparu. C'est le choix de Corpus, l. 798.
             */
            $fondSur = strtolower(substr((string) ($rangee->fondSur ?? ''), 0, 1));

            if ($fond === '' || !\in_array($fondSur, $codes, true)) {
                $fondSur = '';
            }

            $r = (object) [
                'colonnes' => $colonnes,
                'codes'    => $codes,
                'parts'    => $this->rapport($colonnes, (string) ($rangee->rapport ?? '')),
                'fond'     => $fond,
                'fondSur'  => $fondSur,
                /*
                 * LE DEFAUT EST « AU MILIEU » DEPUIS LE 23 SEPTEMBRE 2026.
                 *
                 * « Tes alignements devraient etre toujours par defaut au milieu
                 * dans l'axe horizontal », Cyrille. Deux colonnes de hauteurs
                 * differentes collees en haut laissent un vide sous la plus
                 * courte, et c'est ce vide qu'on voit. Au milieu, les deux se
                 * repondent.
                 *
                 * LE REPLI SUIT LE MANIFESTE : une rangee enregistree avant ce
                 * jour porte sa valeur, et ne bouge pas. Seules les rangees sans
                 * valeur du tout, ou neuves, prennent le nouveau defaut.
                 */
                'hauteur'  => (string) ($rangee->hauteur ?? 'center'),
                'classe'   => $this->classeSaisie($rangee->classe ?? ''),
                'attrId'   => '',
                'cases'    => [],
            ];

            $identifiant = trim((string) ($rangee->identifiant ?? ''));

            if ($identifiant !== '') {
                $r->attrId = ' id="' . htmlspecialchars($identifiant, ENT_QUOTES, 'UTF-8') . '"';
            }

            // Une case par colonne permise, toujours, meme vide.
            foreach ($codes as $code) {
                $r->cases[$code] = [];
            }

            $sortie[$rang + 1] = $r;
        }

        foreach ($blocs as $bloc) {
            $numero = (int) ($bloc->rangee ?? 1);

            if (!isset($sortie[$numero])) {
                continue;
            }

            $rangee = $sortie[$numero];
            $code   = strtolower(substr((string) ($bloc->colonne ?? 'p'), 0, 1));

            /*
             * UN CODE HORS DE LA RANGEE RETOMBE SUR SA PREMIERE COLONNE, et ce
             * n'est pas une correction silencieuse : c'est ce que l'aide du
             * reglage promet. Un bloc pose a droite puis une rangee ramenee a
             * une colonne doit rester visible, pas disparaitre.
             */
            if (!isset($rangee->cases[$code])) {
                $code = $rangee->codes[0];
            }

            $bloc->type   = (string) ($bloc->type ?? 'ouverture');
            $bloc->classe = $this->classeSaisie($bloc->classe ?? '');

            /*
             * LE CADRE S'AJOUTE A LA CLASSE DU BLOC, ET C'EST TOUT.
             *
             * Chaque mise en page ecrit deja `$bloc->classe` sur son conteneur,
             * quel que soit son type : l'encadrement profite donc a l'ouverture
             * comme aux cartes, a la galerie et au carrousel, sans qu'aucun des
             * quatre fichiers n'ait a le savoir.
             */
            $cadre = (string) ($bloc->cadre ?? '');

            if (\in_array($cadre, ['doux', 'teinte', 'trait'], true)) {
                $bloc->classe = trim($bloc->classe . ' opus__cadre opus__cadre--' . $cadre);
            }
            $bloc->attrId = '';

            $identifiant = trim((string) ($bloc->identifiant ?? ''));

            if ($identifiant !== '') {
                $bloc->attrId = ' id="' . htmlspecialchars($identifiant, ENT_QUOTES, 'UTF-8') . '"';
            }

            /*
             * LE CONTENU EST PREPARE ICI, UNE FOIS, ET SELON LE TYPE DU BLOC.
             *
             * Les titres des cartes descendent d'un cran : une carte vit dans
             * une rangee, elle n'est pas au meme rang qu'un titre d'ouverture.
             */
            $bloc->elements = $this->preparer($this->elements($bloc->elements ?? null), $niveauDepart);
            $bloc->cartes   = $this->preparer($this->elements($bloc->cartes ?? null), $niveauDepart + 1);

            /*
             * CHAQUE CARTE PREPARE SA PROPRE PILE.
             *
             * Depuis le 22 septembre 2026 une carte n est plus faite de trois
             * champs fixes mais d une pile d elements, comme l ouverture. Le
             * quatrieme niveau du formulaire (blocs > cartes > elements >
             * boutons) se replie donc ici en une liste prete a dessiner.
             *
             * LES TITRES DESCENDENT ENCORE D UN CRAN : le bloc Cartes est deja
             * a `niveauDepart + 1`, et un titre de carte vit sous le titre de
             * la rangee qui la porte.
             */
            foreach ($bloc->cartes as $carte) {
                $carte->pile = $this->preparer(
                    $this->elements($carte->elements ?? null),
                    $niveauDepart + 1
                );
            }

            /*
             * LE BLOC ONGLETS, 24 septembre 2026 : MEME MECANIQUE QUE LES
             * CARTES, A LA LETTRE.
             *
             * « Voila un exemple avec la mise en page Cartes. Je veux la meme
             * chose, mais pour des onglets », Cyrille, apres trois essais rates
             * ou j'en avais fait un element a quatre champs fixes. Un onglet
             * est un CONTENANT : il porte son titre, qui fait le bouton, et une
             * pile d'elements qu'on ordonne librement.
             *
             * UN ONGLET SANS TITRE NE SORT PAS, et la regle est plus dure
             * qu'ailleurs : un onglet sans titre donnerait dans la barre un
             * bouton VIDE, que personne ne pourrait nommer ni atteindre au
             * clavier. Un onglet sans contenu, lui, reste : le titre suffit a
             * en faire un onglet, et la pile se remplira.
             *
             * LES TITRES DESCENDENT D'UN CRAN, comme dans une carte : ce qui
             * est dans un panneau vit sous le titre qui porte le bloc.
             */
            $bloc->onglets = $this->preparer($this->elements($bloc->onglets ?? null), $niveauDepart + 1);

            $gardes = [];

            foreach ($bloc->onglets as $onglet) {
                $onglet->titre = trim((string) ($onglet->titre ?? ''));

                if ($onglet->titre === '') {
                    continue;
                }

                $onglet->dispo = \in_array(($onglet->dispo ?? 'empile'), ['media-droite', 'media-gauche'], true)
                    ? $onglet->dispo
                    : 'empile';

                $onglet->actif = (string) ($onglet->actif ?? '0') === '1';

                $onglet->pile = $this->preparer(
                    $this->elements($onglet->elements ?? null),
                    $niveauDepart + 1
                );

                $gardes[] = $onglet;
            }

            $bloc->onglets = $gardes;

            /*
             * LA FRISE, 24 septembre 2026 : ENCORE LA MEME MECANIQUE.
             *
             * « Un montage sur deux axes pour presenter une echelle de temps,
             * par exemple une entreprise qui evolue », Cyrille. Une etape porte
             * son repere, la date ou le jalon, et une pile d'elements.
             *
             * UNE ETAPE SANS REPERE NI CONTENU NE SORT PAS. Contrairement a un
             * onglet, dont le titre se voit seul dans la barre, une etape vide
             * ne dessinerait qu'une pastille sur l'axe, sans rien a cote : un
             * trou que rien n'explique.
             */
            $bloc->etapes = $this->preparer($this->elements($bloc->etapes ?? null), $niveauDepart + 1);

            $gardesEtapes = [];

            foreach ($bloc->etapes as $etape) {
                $etape->repere = trim((string) ($etape->repere ?? ''));

                $etape->pile = $this->preparer(
                    $this->elements($etape->elements ?? null),
                    $niveauDepart + 1
                );

                if ($etape->repere === '' && $etape->pile === []) {
                    continue;
                }

                /*
                 * LE TON EST FILTRE CONTRE UNE LISTE FERMEE, comme partout
                 * ailleurs : une valeur inventee ecrirait une classe qui
                 * n'existe pas, et la feuille resterait muette.
                 */
                $ton = (string) ($etape->tonEtape ?? '');

                $etape->ton = \in_array($ton, ['accent', 'succes', 'alerte', 'erreur'], true) ? $ton : '';

                $gardesEtapes[] = $etape;
            }

            $bloc->etapes = $gardesEtapes;

            if ($bloc->type === 'onglets' && $gardes !== []) {
                $this->onglets = true;
            }

            /*
             * UN BLOC QUI NE DESSINERA RIEN N'OCCUPE PAS DE COLONNE.
             *
             * La mise en page ecarte deja un bloc vide, mais trop tard : la
             * colonne etait ecrite avant qu'on sache que son contenu se
             * tairait. Resultat vu sur le banc le 21 septembre 2026, un bloc
             * Cartes ajoute et pas encore rempli : `<div class="colonne-7
             * opus__colonne"></div>`, sept douziemes de page blancs, et
             * l'ouverture d'a cote enfermee dans ses cinq douziemes.
             *
             * LA CARTE DU MONTAGE LE DISAIT DEJA, elle affichait « a remplir ».
             * Elle promet de ne montrer que ce qui sortira ; c'etait donc la
             * page qui avait tort, pas elle.
             */
            if (!$this->blocRempli($bloc)) {
                continue;
            }

            $rangee->cases[$code][] = $bloc;
        }

        /*
         * LE RAPPORT SAISI EST LE RAPPORT RENDU, MEME QUAND UNE COLONNE EST
         * VIDE.
         *
         * CE BLOC A DIT L'INVERSE PENDANT UNE JOURNEE, et les deux versions
         * viennent d'une mesure, d'ou la note. Le 21 septembre, une rangee en
         * 5/7 dont la GAUCHE etait vide sortait son contenu en `colonne-7`
         * colle au bord gauche : sept douziemes de contenu la ou l'auteur en
         * attendait cinq, et cinq douziemes de blanc au mauvais endroit. La
         * reponse d'alors : redistribuer les douze douziemes entre les
         * survivantes.
         *
         * Le 22 septembre a 16 h, Cyrille pose l'autre moitie du probleme :
         * « je devrais avoir l'ouverture seulement sur la gauche sur un
         * rapport de 7/5, ce n'est pas le cas ». Mesure : `colonne-12` au lieu
         * de `colonne-7`. La redistribution avalait le vide de DROITE, qui est
         * pourtant une respiration voulue, c'est meme ainsi qu'on obtient une
         * colonne de texte etroite sans rien poser a cote.
         *
         * LA REGLE QUI SATISFAIT LES DEUX : le vide de droite se garde, le
         * vide de gauche se comble. Une colonne vide qui precede du contenu
         * sort en placeholder, pour que la grille pose le contenu dans sa
         * case ; une colonne vide qui ne precede rien ne sort pas, et ses
         * douziemes restent blancs. Le rapport saisi n'est plus jamais
         * recalcule.
         */
        foreach ($sortie as $rangee) {
            $pleines = [];

            foreach ($rangee->codes as $index => $code) {
                if ($rangee->cases[$code] !== []) {
                    $pleines[] = $index;
                }
            }

            if ($pleines === []) {
                $rangee->codes = [];

                continue;
            }

            // Tout ce qui suit la derniere colonne pleine ne sort pas.
            $dernier = $pleines[\count($pleines) - 1];
            $codes   = [];
            $parts   = [];

            foreach ($rangee->codes as $index => $code) {
                if ($index > $dernier) {
                    continue;
                }

                $codes[] = $code;
                $parts[] = max(1, (int) $rangee->parts[$index]);
            }

            $rangee->codes = $codes;
            $rangee->parts = $parts;

            /*
             * UN FOND POSE SUR UNE COLONNE QUI NE SORT PLUS REVIENT SUR LA
             * RANGEE, sinon l'aplat n'est dessine nulle part et le reglage
             * semble sans effet.
             */
            if ($rangee->fondSur !== '' && !\in_array($rangee->fondSur, $codes, true)) {
                $rangee->fondSur = '';
            }
        }

        /*
         * UNE RANGEE SANS AUCUN BLOC NE SORT PAS.
         *
         * Sans ce filtre, une rangee ajoutee puis oubliee laissait une bande
         * vide dans la page, avec sa gouttiere et son fond. C'est la regle de
         * Corpus pour ses gabarits, et l'aide du champ la dit.
         */
        return array_values(array_filter($sortie, function ($rangee) {
            foreach ($rangee->cases as $blocs) {
                if ($blocs !== []) {
                    return true;
                }
            }

            return false;
        }));
    }

    /**
     * Reprend la saisie d'un module regle avant le modele rangees + blocs.
     *
     * POURQUOI ELLE EXISTE. Le 21 septembre 2026, les quatre listes de contenu
     * et le champ `layout` ont ete remplaces par des rangees et des blocs. Les
     * anciens noms de reglages restent en base : sans cette reprise, un module
     * deja rempli remontait VIDE apres la mise a jour, et sa saisie semblait
     * perdue alors qu'elle etait toujours la.
     *
     * ELLE NE S'EXECUTE QU'A VIDE. Des qu'une rangee existe, elle ne touche
     * plus a rien : un module repris puis modifie ne doit jamais se faire
     * reecrire par l'ancienne saisie restee en base.
     *
     * ELLE N'ENREGISTRE RIEN. Elle fabrique le montage a l'affichage ; c'est le
     * premier enregistrement depuis l'ecran de reglage qui fixe le nouveau
     * modele. Un module qu'on ne rouvre jamais continue donc de sortir la meme
     * page, indefiniment.
     *
     * @return array<int, object> Les rangees deduites, ou un tableau vide.
     */
    protected function reprise(Registry $params): array
    {
        $layout = (string) $params->get('layout', '');

        if ($layout === '') {
            return [];
        }

        // `_:atouts` pour un fichier du module, `corpus:atouts` pour une
        // surcharge du template : seule la forme nous interesse.
        $i = strpos($layout, ':');
        $forme = $i === false ? $layout : substr($layout, $i + 1);

        $ouverture = $params->get('opening');
        $cartes    = $params->get('cards');
        $diapos    = $params->get('slides');
        $images    = $params->get('images');

        // Les dispositions a deux colonnes gardent leur rapport et leur cote.
        $aDeuxColonnes = \in_array($forme, ['atouts', 'illustration'], true);
        $rapport = $aDeuxColonnes ? (string) $params->get('rowRatio', '5-7') : '';
        $gauche  = (string) $params->get('rowOpeningSide', 'left') === 'left';

        $fonds = ['tinted' => 'section--tint', 'alternate' => 'section--alt'];
        $ancienFond = (string) $params->get('rowBackground', 'none');

        $rangee = (object) [
            'colonnes' => $aDeuxColonnes ? 2 : 1,
            'rapport'  => $rapport,
            'fond'     => $fonds[$ancienFond] ?? '',
            'fondSur'  => '',
            'hauteur'  => (string) $params->get('rowVerticalAlign', 'start'),
            'show'     => '1',
        ];

        $blocs = [];

        $poser = function (string $type, $contenu, string $colonne) use (&$blocs) {
            if (empty($contenu)) {
                return;
            }

            $bloc = (object) ['type' => $type, 'rangee' => 1, 'colonne' => $colonne, 'show' => '1'];

            if ($type === 'ouverture') {
                $bloc->elements = $contenu;
            } elseif ($type === 'carrousel') {
                $bloc->diapos = $contenu;
            } else {
                $bloc->cartes = $contenu;
            }

            $blocs[] = $bloc;
        };

        /*
         * LES SIX ANCIENNES DISPOSITIONS RETOMBENT SUR DEUX BLOCS.
         *
         * Le module n'en dessine plus que deux : l'ouverture et les cartes.
         * Un carrousel ou une galerie regles avant la bascule reviennent donc
         * en grille de cartes, avec leur contenu : image, titre, texte et lien
         * sont les memes champs, rien n'est perdu, et la page change d'allure
         * sans se vider. Mieux vaut cela qu'un module devenu blanc.
         */
        switch ($forme) {
            case 'atouts':
            case 'illustration':
                $poser('ouverture', $ouverture, $gauche ? 'g' : 'd');
                $poser('cartes', $cartes, $gauche ? 'd' : 'g');
                break;

            case 'carrousel':
                $poser('cartes', $diapos, 'p');
                break;

            case 'galerie':
                $poser('cartes', $images, 'p');
                break;

            case 'portraits':
                $poser('cartes', $cartes, 'p');
                break;

            default:
                $poser('ouverture', $ouverture, 'p');
                break;
        }

        if ($blocs === []) {
            return [];
        }

        return [$rangee, $blocs];
    }

    /**
     * LE COMPTEUR DES TABLEAUX DE LA PAGE.
     *
     * La legende porte un identifiant, que la zone de defilement cite pour se
     * nommer. Deux tableaux dans la page, et deux fois le meme identifiant, le
     * navigateur ne trouverait que le premier : la seconde zone porterait le
     * nom du premier tableau.
     */
    private static int $tableaux = 0;

    /**
     * Le tableau, pret a poser.
     *
     * CE QUE LE JSON CONTIENT, ecrit par `admin.js` :
     *   lignes : les cases, une liste de listes de textes ;
     *   col    : un reglage par colonne, regl : un reglage par ligne.
     * Chaque reglage peut porter a (g, c, d), f (alt, tint), g, m (1), w et u
     * (largeur et unite), h (hauteur minimale, px), t (trait de total), cl, id.
     *   cases  : les reglages d'une cellule seule, par « ligne,colonne »
     *            (a, f, g, m, cl, id). La cellule l'emporte sur tout.
     *
     * LA LIGNE L'EMPORTE SUR LA COLONNE, case par case. C'est ce que dit le
     * panneau de reglage de la colonne, et l'apercu de l'administration
     * applique exactement la meme regle : un apercu qui ment est pire que pas
     * d'apercu.
     *
     * RIEN NE SORT SI TOUTES LES CASES SONT VIDES. Un tableau ajoute et pas
     * encore rempli ne dessinerait qu'un cadre vide, et un lecteur d'ecran
     * annoncerait un tableau de zero information.
     *
     * LES ROLES SONT ECRITS EN DUR, ET CE N'EST PAS UNE REDONDANCE. En fiches,
     * sur petit ecran, les cases passent en `display: block` : Chrome et Safari
     * retirent alors au tableau sa semantique, et le lecteur d'ecran n'entend
     * plus qu'une suite de textes. Les roles explicites la lui rendent.
     */
    public function tableau(object $el): ?object
    {
        $brut = json_decode((string) ($el->tableau ?? ''), true);

        if (!\is_array($brut) || !\is_array($brut['lignes'] ?? null)) {
            return null;
        }

        $lignes = [];
        $nc     = 0;
        $plein  = false;

        foreach ($brut['lignes'] as $ligne) {
            if (!\is_array($ligne)) {
                continue;
            }

            $cases = [];

            foreach (array_values($ligne) as $case) {
                $case    = \is_scalar($case) ? trim((string) $case) : '';
                $plein   = $plein || $case !== '';
                $cases[] = $case;
            }

            $lignes[] = $cases;
            $nc       = max($nc, \count($cases));
        }

        if (!$plein) {
            return null;
        }

        $reglage = static function ($liste, int $rang): array {
            $r = \is_array($liste) ? ($liste[$rang] ?? []) : [];

            return \is_array($r) ? $r : [];
        };

        // Un identifiant saisi ne sort que s'il en est un : `#` suivi d'un chiffre ne se vise pas.
        $ident = static function ($valeur): string {
            $v = trim((string) $valeur);

            return preg_match('/^[A-Za-z][A-Za-z0-9_-]*$/', $v) ? $v : '';
        };

        $teteLigne   = (string) ($el->tabTeteLigne ?? '1') !== '0';
        $teteColonne = (string) ($el->tabTeteColonne ?? '1') !== '0';
        $etroit      = ($el->tabEtroit ?? 'fiches') === 'defile' ? 'defile' : 'fiches';
        $bordures    = (string) ($el->tabBordures ?? 'cadre');
        $bordures    = \in_array($bordures, ['cadre', 'lignes', 'grille', 'aucune'], true) ? $bordures : 'cadre';

        // La racine `opus__tableau` est ecrite en toutes lettres par la mise en page.
        $classes = ['opus__tableau--' . $etroit, 'opus__tableau--' . $bordures];

        // Colonnes egales : la table passe en `table-layout: fixed` (blocs.css).
        if (($el->tabLargeurs ?? 'contenu') === 'egales') {
            $classes[] = 'opus__tableau--egales';
        }

        if ((string) ($el->tabAlterne ?? '1') === '0') {
            $classes[] = 'opus__tableau--uni';
        }

        if (($el->classe ?? '') !== '') {
            $classes[] = $el->classe;
        }

        $alignement = ['c' => 'opus__tableau-case--centre', 'd' => 'opus__tableau-case--droite'];
        $fond       = ['alt' => 'neutre', 'tint' => 'teinte'];

        // Les intitules de colonnes, repetes devant chaque case quand le tableau passe en fiches.
        $intitules = $teteLigne ? $lignes[0] : [];

        // --- les colonnes : largeur et identifiant --------------------------
        $colonnes = [];
        $utile    = false;

        for ($c = 0; $c < $nc; $c++) {
            $k     = $reglage($brut['col'] ?? [], $c);
            $attrs = '';
            $w     = (float) ($k['w'] ?? 0);
            $px    = ($k['u'] ?? '%') === 'px';

            if ($w > 0 && $w <= ($px ? 4000 : 100)) {
                $attrs .= ' style="width:' . rtrim(rtrim(number_format($w, 2, '.', ''), '0'), '.') . ($px ? 'px' : '%') . '"';
            }

            if ($ident($k['id'] ?? '') !== '') {
                $attrs .= ' id="' . $ident($k['id']) . '"';
            }

            $utile      = $utile || $attrs !== '';
            $colonnes[] = $attrs;
        }

        // --- les lignes -------------------------------------------------------
        $entete = null;
        $corps  = [];

        foreach ($lignes as $i => $cases) {
            $cases = array_pad($cases, $nc, '');
            $r     = $reglage($brut['regl'] ?? [], $i);
            $estTete = $teteLigne && $i === 0;

            $cl = [];

            if (isset($fond[$r['f'] ?? ''])) {
                $cl[] = 'opus__tableau-ligne--' . $fond[$r['f']];
            }

            if (!empty($r['g'])) { $cl[] = 'opus__tableau-ligne--gras'; }
            if (!empty($r['m'])) { $cl[] = 'opus__tableau-ligne--maj'; }
            if (!empty($r['t'])) { $cl[] = 'opus__tableau-ligne--total'; }

            if ($this->classeSaisie($r['cl'] ?? '') !== '') {
                $cl[] = $this->classeSaisie($r['cl']);
            }

            $attrs = ' role="row"';
            $attrs .= $cl !== [] ? ' class="' . implode(' ', $cl) . '"' : '';
            $attrs .= $ident($r['id'] ?? '') !== '' ? ' id="' . $ident($r['id']) . '"' : '';

            $h = (int) ($r['h'] ?? 0);

            if ($h > 0 && $h <= 2000) {
                $attrs .= ' style="--opus-tableau-h:' . $h . 'px"';
            }

            $sortie = [];

            foreach ($cases as $c => $texte) {
                $k  = $reglage($brut['col'] ?? [], $c);

                // La cellule seule, ranges par « ligne,colonne » : elle l'emporte sur sa ligne et sa colonne.
                $x  = \is_array($brut['cases'] ?? null) && \is_array($brut['cases'][$i . ',' . $c] ?? null)
                    ? $brut['cases'][$i . ',' . $c]
                    : [];
                $cc = [];
                $a  = (string) (($x['a'] ?? '') !== '' ? $x['a'] : (($r['a'] ?? '') !== '' ? $r['a'] : ($k['a'] ?? '')));

                if (isset($alignement[$a])) {
                    $cc[] = $alignement[$a];
                }

                /*
                 * LE FOND : la cellule, sinon la ligne, sinon la colonne. Le fond
                 * de la ligne est pose sur la ligne elle-meme ; celui de la
                 * cellule se peint par-dessus, celui de la colonne seulement
                 * sous une ligne qui n'en a pas.
                 */
                if (isset($fond[$x['f'] ?? ''])) {
                    $cc[] = 'opus__tableau-case--' . $fond[$x['f']];
                } elseif (!isset($fond[$r['f'] ?? '']) && isset($fond[$k['f'] ?? ''])) {
                    $cc[] = 'opus__tableau-case--' . $fond[$k['f']];
                }

                if (!empty($k['g']) || !empty($x['g'])) { $cc[] = 'opus__tableau-case--gras'; }
                if (!empty($k['m']) || !empty($x['m'])) { $cc[] = 'opus__tableau-case--maj'; }

                foreach ([$k, $x] as $source) {
                    if ($this->classeSaisie($source['cl'] ?? '') !== '') {
                        $cc[] = $this->classeSaisie($source['cl']);
                    }
                }

                $classe = $cc !== [] ? ' class="' . implode(' ', $cc) . '"' : '';
                $classe .= $ident($x['id'] ?? '') !== '' ? ' id="' . $ident($x['id']) . '"' : '';

                if ($estTete) {
                    $sortie[] = (object) ['balise' => 'th', 'attrs' => ' role="columnheader" scope="col"' . $classe, 'texte' => $texte];
                } elseif ($teteColonne && $c === 0) {
                    $sortie[] = (object) ['balise' => 'th', 'attrs' => ' role="rowheader" scope="row"' . $classe, 'texte' => $texte];
                } else {
                    $intitule = trim((string) ($intitules[$c] ?? ''));
                    $etiquette = $intitule !== ''
                        ? ' data-label="' . htmlspecialchars($intitule, ENT_QUOTES, 'UTF-8') . '"'
                        : '';
                    $sortie[] = (object) ['balise' => 'td', 'attrs' => ' role="cell"' . $classe . $etiquette, 'texte' => $texte];
                }
            }

            $ligne = (object) ['attrs' => $attrs, 'cases' => $sortie];

            if ($estTete) {
                $entete = $ligne;
            } else {
                $corps[] = $ligne;
            }
        }

        self::$tableaux++;

        $legende   = trim((string) ($el->tabLegende ?? ''));
        $idLegende = 'opus-tableau-' . substr(md5((string) ($el->tableau ?? '') . $legende), 0, 8) . '-' . self::$tableaux;

        /*
         * LA ZONE QUI DEFILE EST NOMMEE, ET ELLE SE PREND AU CLAVIER. Sans
         * `tabindex`, un tableau plus large que l'ecran ne se fait pas defiler
         * sans souris ; sans nom, le lecteur d'ecran annonce « region » sans dire
         * laquelle. La legende la nomme quand elle existe, un mot sinon.
         */
        $nom = $legende !== ''
            ? ' aria-labelledby="' . $idLegende . '"'
            : ' aria-label="' . htmlspecialchars(Text::_('MOD_OPUS_TABLE_SCROLL'), ENT_QUOTES, 'UTF-8') . '"';

        return (object) [
            'classes'   => implode(' ', $classes),
            'legende'   => $legende,
            'idLegende' => $idLegende,
            'nom'       => $nom,
            'colonnes'  => $utile ? $colonnes : [],
            'entete'    => $entete,
            'corps'     => $corps,
        ];
    }

    /**
     * LES PLATEFORMES CONNUES, et ce qu'il faut a chacune.
     *
     * `oembed` : l'adresse qui rend les dimensions et la vignette d'une video,
     * interrogee par le serveur, jamais par le visiteur. `{u}` est l'adresse
     * de la video, encodee.
     */
    private const PLATEFORMES = [
        'youtube'     => ['nom' => 'YouTube', 'oembed' => 'https://www.youtube.com/oembed?format=json&url={u}'],
        'vimeo'       => ['nom' => 'Vimeo', 'oembed' => 'https://vimeo.com/api/oembed.json?url={u}'],
        'dailymotion' => ['nom' => 'Dailymotion', 'oembed' => 'https://www.dailymotion.com/services/oembed?format=json&url={u}'],
        'peertube'    => ['nom' => 'PeerTube', 'oembed' => 'https://{h}/services/oembed?format=json&url={u}'],
    ];

    /**
     * Reconnait une adresse de video, quelle que soit sa forme.
     *
     * YouTube s'ecrit au moins de six facons (`watch?v=`, `youtu.be/`,
     * `/shorts/`, `/embed/`, `/live/`, `m.youtube.com`) ; Vimeo cache un
     * jeton apres l'identifiant pour une video non repertoriee ; PeerTube vit
     * sur n'importe quel serveur, et se reconnait a son chemin.
     *
     * @return array{p: string, id: string, h: string, jeton: string, vertical: bool}|null
     */
    public function reconnaitreVideo(string $adresse): ?array
    {
        $u = parse_url(trim($adresse));

        if (empty($u['host']) || !\in_array(strtolower($u['scheme'] ?? ''), ['http', 'https'], true)) {
            return null;
        }

        $hote   = strtolower($u['host']);
        $chemin = (string) ($u['path'] ?? '');
        parse_str((string) ($u['query'] ?? ''), $q);
        $base = preg_replace('/^(www\.|m\.)/', '', $hote);
        $ok   = static fn ($id) => \is_string($id) && preg_match('/^[\w-]{2,64}$/', $id);

        if ($base === 'youtu.be' && $ok($id = trim($chemin, '/'))) {
            return ['p' => 'youtube', 'id' => $id, 'h' => '', 'jeton' => '', 'vertical' => false];
        }

        if (\in_array($base, ['youtube.com', 'youtube-nocookie.com', 'music.youtube.com'], true)) {
            if ($ok($q['v'] ?? null)) {
                return ['p' => 'youtube', 'id' => $q['v'], 'h' => '', 'jeton' => '', 'vertical' => false];
            }

            if (preg_match('#^/(shorts|embed|live|v)/([\w-]{6,})#', $chemin, $m)) {
                return ['p' => 'youtube', 'id' => $m[2], 'h' => '', 'jeton' => '', 'vertical' => $m[1] === 'shorts'];
            }
        }

        if (\in_array($base, ['vimeo.com', 'player.vimeo.com'], true)
            && preg_match('#/(?:video/)?(\d{5,})(?:/([0-9a-f]{6,}))?#', $chemin, $m)) {
            return ['p' => 'vimeo', 'id' => $m[1], 'h' => '', 'jeton' => $m[2] ?? (string) ($q['h'] ?? ''), 'vertical' => false];
        }

        if ($base === 'dailymotion.com' && preg_match('#/(?:embed/)?video/([a-z0-9]+)#i', $chemin, $m)) {
            return ['p' => 'dailymotion', 'id' => $m[1], 'h' => '', 'jeton' => '', 'vertical' => false];
        }

        if ($base === 'dai.ly' && $ok($id = trim($chemin, '/'))) {
            return ['p' => 'dailymotion', 'id' => $id, 'h' => '', 'jeton' => '', 'vertical' => false];
        }

        if (preg_match('#^/(?:w|videos/watch|videos/embed)/([\w-]{8,})#', $chemin, $m)) {
            return ['p' => 'peertube', 'id' => $m[1], 'h' => $hote, 'jeton' => '', 'vertical' => false];
        }

        return null;
    }

    /** « 1:30 », « 90 » ou « 1:02:03 », en secondes. Zero si illisible. */
    private function secondes(string $saisie): int
    {
        $saisie = trim($saisie);

        if ($saisie === '' || !preg_match('/^\d+(:\d{1,2}){0,2}$/', $saisie)) {
            return 0;
        }

        $total = 0;

        foreach (explode(':', $saisie) as $morceau) {
            $total = $total * 60 + (int) $morceau;
        }

        return $total;
    }

    /** L'adresse du lecteur, posee au clic seulement. */
    private function adresseLecteur(array $v, int $debut, bool $muet): string
    {
        switch ($v['p']) {
            case 'youtube':
                // youtube-nocookie : rien n'est depose avant la lecture elle-meme.
                $q = ['autoplay' => 1, 'rel' => 0, 'cc_load_policy' => 1, 'playsinline' => 1];
                if ($debut > 0) { $q['start'] = $debut; }
                if ($muet) { $q['mute'] = 1; }

                return 'https://www.youtube-nocookie.com/embed/' . $v['id'] . '?' . http_build_query($q);

            case 'vimeo':
                // dnt : Vimeo ne suit pas le visiteur.
                $q = ['autoplay' => 1, 'dnt' => 1];
                if ($v['jeton'] !== '') { $q['h'] = $v['jeton']; }
                if ($muet) { $q['muted'] = 1; }

                return 'https://player.vimeo.com/video/' . $v['id'] . '?' . http_build_query($q) . ($debut > 0 ? '#t=' . $debut . 's' : '');

            case 'dailymotion':
                $q = ['video' => $v['id'], 'autoplay' => 1];
                if ($debut > 0) { $q['startTime'] = $debut; }
                if ($muet) { $q['mute'] = 'true'; }

                return 'https://geo.dailymotion.com/player.html?' . http_build_query($q);

            default:
                $q = ['autoplay' => 1, 'title' => 0, 'warningTitle' => 0];
                if ($debut > 0) { $q['start'] = $debut . 's'; }
                if ($muet) { $q['muted'] = 1; }

                return 'https://' . $v['h'] . '/videos/embed/' . $v['id'] . '?' . http_build_query($q);
        }
    }

    /**
     * LES DIMENSIONS ET LA VIGNETTE, DEMANDEES UNE FOIS, PAR LE SERVEUR.
     *
     * Le visiteur ne contacte jamais la plateforme avant son clic : c'est le
     * site qui lui demande, une seule fois, les dimensions de la video et sa
     * vignette, et qui copie celle-ci dans `images/opus/videos/`. La reponse
     * est gardee dans le cache de Joomla ; un echec aussi, pour une journee,
     * afin qu'une plateforme qui ne repond pas ne ralentisse pas chaque page.
     *
     * QUATRE SECONDES AU PLUS. Au-dela, la video sort en 16:9, sans vignette :
     * un fond sombre et le bouton Lire.
     *
     * @return array{w: int, h: int, image: string}
     */
    private function metaVideo(array $v, string $adresse): array
    {
        $vide  = ['w' => 0, 'h' => 0, 'image' => ''];
        $cle   = $v['p'] . '-' . preg_replace('/[^\w-]/', '', $v['id']);
        $dir   = JPATH_CACHE . '/mod_opus';
        $fiche = $dir . '/video-' . $cle . '.json';

        if (is_file($fiche)) {
            $lu = json_decode((string) file_get_contents($fiche), true);

            if (\is_array($lu) && (empty($lu['echec']) || time() - (int) $lu['echec'] < 86400)) {
                return array_merge($vide, array_intersect_key($lu, $vide));
            }
        }

        $meta = $vide;

        try {
            $http = HttpFactory::getHttp();
            $url  = strtr(self::PLATEFORMES[$v['p']]['oembed'], ['{u}' => rawurlencode($adresse), '{h}' => $v['h']]);
            $rep  = $http->get($url, [], 4);
            $o    = $rep->getStatusCode() === 200 ? json_decode((string) $rep->getBody(), true) : null;

            if (!\is_array($o)) {
                throw new \RuntimeException('oEmbed');
            }

            $meta['w'] = (int) ($o['width'] ?? 0);
            $meta['h'] = (int) ($o['height'] ?? 0);

            // YouTube : la grande vignette quand elle existe, la moyenne sinon.
            $sources = $v['p'] === 'youtube'
                ? ['https://i.ytimg.com/vi/' . $v['id'] . '/maxresdefault.jpg', 'https://i.ytimg.com/vi/' . $v['id'] . '/hqdefault.jpg']
                : [(string) ($o['thumbnail_url'] ?? '')];

            foreach ($sources as $src) {
                if ($src === '' || !preg_match('#^https://#', $src)) {
                    continue;
                }

                $img   = $http->get($src, [], 4);
                $corps = $img->getStatusCode() === 200 ? (string) $img->getBody() : '';

                if (\strlen($corps) > 1000 && @getimagesizefromstring($corps)) {
                    $dossier = JPATH_ROOT . '/images/opus/videos';

                    if (!is_dir($dossier)) {
                        @mkdir($dossier, 0755, true);
                    }

                    if (@file_put_contents($dossier . '/' . $cle . '.jpg', $corps) !== false) {
                        $meta['image'] = 'images/opus/videos/' . $cle . '.jpg';
                    }

                    break;
                }
            }
        } catch (\Throwable $e) {
            $meta['echec'] = time();
        }

        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        @file_put_contents($fiche, json_encode($meta));

        return array_intersect_key($meta, $vide);
    }

    /** Un chemin choisi dans le gestionnaire de medias, en adresse du site. */
    private function cheminMedia($valeur): string
    {
        $v = trim((string) $valeur);

        if ($v === '') {
            return '';
        }

        $v = HTMLHelper::cleanImageURL($v)->url;

        if (preg_match('#^(https?:)?//#i', $v)) {
            return $v;
        }

        return Uri::root(true) . '/' . ltrim($v, '/');
    }

    /**
     * La video, prete a poser.
     *
     * DEUX CAS. Une video de plateforme sort en FACADE : une image, un bouton
     * Lire qui est un vrai lien vers la video (il marche sans JavaScript), et
     * l'adresse du lecteur en attribut ; `video.js` pose l'iframe au clic. Un
     * fichier du site sort en balise `video` du navigateur, avec ses
     * commandes : il n'y a personne a qui ne rien demander.
     *
     * RIEN NE SORT SANS ADRESSE RECONNUE NI FICHIER. Une adresse qu'Opus ne
     * reconnait pas est un oubli a corriger, pas une video a deviner.
     */
    public function video(object $el): ?object
    {
        $titre  = trim((string) ($el->videoTitre ?? ''));
        $titre  = $titre !== '' ? $titre : Text::_('MOD_OPUS_ELEMENT_VIDEO');
        $debut  = $this->secondes((string) ($el->videoDebut ?? ''));
        $muet   = (string) ($el->videoMuet ?? '0') === '1';
        $image  = $this->cheminMedia($el->videoImage ?? '');
        $fichier = $this->cheminMedia($el->videoFichier ?? '');

        $commun = [
            'titre'         => $titre,
            'legende'       => trim((string) ($el->videoLegende ?? '')),
            'transcription' => trim((string) ($el->videoTranscription ?? '')),
            'image'         => $image,
            'classes'       => $el->classe,
        ];

        if ($fichier !== '') {
            $ext  = strtolower(pathinfo(parse_url($fichier, PHP_URL_PATH) ?: '', PATHINFO_EXTENSION));
            $mime = ['mp4' => 'video/mp4', 'm4v' => 'video/mp4', 'mov' => 'video/mp4', 'webm' => 'video/webm', 'ogv' => 'video/ogg', 'ogg' => 'video/ogg'][$ext] ?? '';
            $vtt  = $this->cheminMedia($el->videoSousTitres ?? '');
            $lang = Factory::getApplication()->getLanguage();

            return (object) array_merge($commun, [
                'sorte'   => 'fichier',
                'src'     => $fichier . ($debut > 0 ? '#t=' . $debut : ''),
                'mime'    => $mime,
                'pistes'  => $vtt !== '' ? ['src' => $vtt, 'langue' => substr($lang->getTag(), 0, 2), 'nom' => $lang->getName()] : null,
                'boucle'  => (string) ($el->videoBoucle ?? '0') === '1',
                'muet'    => $muet,
            ]);
        }

        $adresse = trim((string) ($el->videoAdresse ?? ''));
        $v       = $adresse !== '' ? $this->reconnaitreVideo($adresse) : null;

        if ($v === null) {
            return null;
        }

        $meta = $this->metaVideo($v, $adresse);
        $w    = $meta['w'];
        $h    = $meta['h'];

        if ($v['vertical']) {
            [$w, $h] = [9, 16];
        } elseif ($w <= 0 || $h <= 0) {
            [$w, $h] = [16, 9];
        }

        $this->videos = true;

        return (object) array_merge($commun, [
            'sorte'      => 'plateforme',
            'plateforme' => self::PLATEFORMES[$v['p']]['nom'],
            'lien'       => $adresse,
            'lecteur'    => $this->adresseLecteur($v, $debut, $muet),
            'ratio'      => $w . ' / ' . $h,
            'vertical'   => $h > $w,
            'image'      => $image !== '' ? $image : ($meta['image'] !== '' ? Uri::root(true) . '/' . $meta['image'] : ''),
        ]);
    }

    /** Les couleurs de repere : des jetons du template, avec leur repli. */
    private const COULEURS_CARTE = [
        'accent' => 'var(--accent, #2f5fa7)',
        'encre'  => 'var(--encre, #1d2939)',
        'succes' => 'var(--succes, #2f7d4f)',
        'info'   => 'var(--info, #1b6ca8)',
        'alerte' => 'var(--alerte, #b26b00)',
        'erreur' => 'var(--erreur, #b42318)',
    ];

    /** Le nombre de cartes deja posees dans la page, pour des identifiants uniques. */
    private static int $nCartes = 0;

    /** Les adresses demandees a Nominatim pendant cette page : trois au plus. */
    private int $geoDemandes = 0;

    /**
     * LA POSITION D'UNE ADRESSE, DEMANDEE UNE FOIS, PAR LE SERVEUR.
     *
     * Nominatim, le service de recherche d'OpenStreetMap, demande un usage
     * modere : une requete par seconde au plus, et un nom d'application. La
     * reponse est gardee dans le cache de Joomla ; un echec aussi, une
     * journee. TROIS ADRESSES NOUVELLES AU PLUS PAR AFFICHAGE, une seconde
     * d'ecart entre elles : une carte de vingt lieux se remplit en quelques
     * visites au lieu de bloquer la premiere vingt secondes.
     *
     * @return array{0: float, 1: float}|null
     */
    private function geocoder(string $adresse): ?array
    {
        $adresse = trim(preg_replace('/\s+/', ' ', $adresse));

        if ($adresse === '') {
            return null;
        }

        $dir   = JPATH_CACHE . '/mod_opus';
        $fiche = $dir . '/geo-' . md5(mb_strtolower($adresse)) . '.json';

        if (is_file($fiche)) {
            $lu = json_decode((string) file_get_contents($fiche), true);

            if (\is_array($lu) && isset($lu['lat'], $lu['lon'])) {
                return [(float) $lu['lat'], (float) $lu['lon']];
            }

            if (\is_array($lu) && !empty($lu['echec']) && time() - (int) $lu['echec'] < 86400) {
                return null;
            }
        }

        if ($this->geoDemandes >= 3) {
            return null;
        }

        if ($this->geoDemandes > 0) {
            usleep(1100000);
        }

        $this->geoDemandes++;
        $rep = ['echec' => time()];

        try {
            $lang  = Factory::getApplication()->getLanguage()->getTag();
            $url   = 'https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q=' . rawurlencode($adresse);
            $reponse = HttpFactory::getHttp()->get($url, [
                'User-Agent'      => 'Opus, module Joomla (' . Uri::root() . ')',
                'Accept-Language' => $lang,
            ], 5);
            $o = $reponse->getStatusCode() === 200 ? json_decode((string) $reponse->getBody(), true) : null;

            if (\is_array($o) && isset($o[0]['lat'], $o[0]['lon'])) {
                $rep = ['lat' => (float) $o[0]['lat'], 'lon' => (float) $o[0]['lon']];
            }
        } catch (\Throwable $e) {
            // L'echec est garde une journee, la carte sort sans ce lieu.
        }

        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        @file_put_contents($fiche, json_encode($rep));

        return isset($rep['lat']) ? [$rep['lat'], $rep['lon']] : null;
    }

    /** Un nombre de coordonnee saisi a la main, virgule ou point. */
    private function coordonnee($valeur, float $borne): ?float
    {
        $v = str_replace(',', '.', trim((string) $valeur));

        if ($v === '' || !is_numeric($v) || abs((float) $v) > $borne) {
            return null;
        }

        return (float) $v;
    }

    /** Projection de Mercator, en fraction du monde (0 a 1). */
    private static function mercator(float $lat, float $lon): array
    {
        $lat = max(-85.0, min(85.0, $lat));
        $s   = sin(deg2rad($lat));

        return [($lon + 180) / 360, 0.5 - log((1 + $s) / (1 - $s)) / (4 * M_PI)];
    }

    /** Les pixels du monde au zoom z (tuiles de 256). */
    private static function pixelsMonde(float $lat, float $lon, int $z): array
    {
        [$x, $y] = self::mercator($lat, $lon);
        $n = 256 * (2 ** $z);

        return [$x * $n, $y * $n];
    }

    /**
     * LA VUE DE DEPART : le zoom et le centre qui montrent tous les lieux.
     *
     * Calculee ici une fois, pour une colonne etroite (520 px) : l'image de la
     * facade et la carte chargee au clic partent exactement de la meme vue, et
     * le visiteur ne voit rien sauter au moment du clic.
     *
     * @return array{z: int, cx: float, cy: float}
     */
    private function vueCarte(array $places, int $zoomFixe, int $h): array
    {
        $z = $zoomFixe ?: 16;

        if (!$zoomFixe && \count($places) > 1) {
            for ($z = 17; $z > 2; $z--) {
                $pts = array_map(static fn ($l) => self::pixelsMonde($l->lat, $l->lon, $z), $places);
                $xs  = array_column($pts, 0);
                $ys  = array_column($pts, 1);

                if (max($xs) - min($xs) <= 430 && max($ys) - min($ys) <= $h - 110) {
                    break;
                }
            }
        }

        $pts = array_map(static fn ($l) => self::pixelsMonde($l->lat, $l->lon, $z), $places);
        $xs  = array_column($pts, 0);
        $ys  = array_column($pts, 1);

        return ['z' => $z, 'cx' => round((min($xs) + max($xs)) / 2, 1), 'cy' => round((min($ys) + max($ys)) / 2 + 12, 1)];
    }

    /**
     * L'IMAGE DE LA CARTE, POUR LA FACADE.
     *
     * « Au lieu d'un rectangle vide, on ne peut pas avoir une image de la
     * carte ? », Cyrille, 3 octobre 2026. Si : LE SERVEUR assemble une fois les
     * tuiles d'OpenStreetMap autour de la vue de depart, et range l'image dans
     * `images/opus/cartes/`. Le visiteur la recoit du site, pas d'OpenStreetMap :
     * rien ne part chez eux avant son clic.
     *
     * 1280 PX DE LARGE, centree dans la zone : elle couvre une colonne comme
     * une pleine largeur, et les reperes, places en decalage du centre, tombent
     * au bon endroit quelle que soit la largeur.
     *
     * LES TUILES SONT GARDEES SEPT JOURS dans le cache, comme le demande la
     * politique d'usage des tuiles d'OpenStreetMap : on ne redemande pas ce
     * qu'on a deja. Sans GD, ou si une tuile manque, pas d'image : la zone
     * garde son fond neutre.
     */
    private function imageCarte(array $vue, int $h): string
    {
        if (!\function_exists('imagecreatetruecolor')) {
            return '';
        }

        $w    = 1280;
        $cle  = md5($vue['z'] . '|' . $vue['cx'] . '|' . $vue['cy'] . '|' . $w . '|' . $h);
        $rel  = 'images/opus/cartes/' . $cle . '.jpg';
        $abs  = JPATH_ROOT . '/' . $rel;

        if (is_file($abs)) {
            return Uri::root(true) . '/' . $rel;
        }

        $z      = $vue['z'];
        $n      = 2 ** $z;
        $gauche = $vue['cx'] - $w / 2;
        $haut   = $vue['cy'] - $h / 2;
        $img    = imagecreatetruecolor($w, $h);
        $fond   = imagecolorallocate($img, 233, 228, 220);
        $cache  = JPATH_CACHE . '/mod_opus/tuiles';
        $http   = null;

        imagefill($img, 0, 0, $fond);

        if (!is_dir($cache)) {
            @mkdir($cache, 0755, true);
        }

        for ($tx = (int) floor($gauche / 256); $tx <= (int) floor(($gauche + $w) / 256); $tx++) {
            for ($ty = (int) floor($haut / 256); $ty <= (int) floor(($haut + $h) / 256); $ty++) {
                if ($ty < 0 || $ty >= $n) {
                    continue;
                }

                $vx      = (($tx % $n) + $n) % $n;
                $fichier = $cache . '/' . $z . '-' . $vx . '-' . $ty . '.png';
                $octets  = is_file($fichier) && time() - filemtime($fichier) < 7 * 86400 ? file_get_contents($fichier) : '';

                if ($octets === '' || $octets === false) {
                    try {
                        $http ??= HttpFactory::getHttp();
                        $rep    = $http->get('https://tile.openstreetmap.org/' . $z . '/' . $vx . '/' . $ty . '.png', [
                            'User-Agent' => 'Opus, module Joomla (' . Uri::root() . ')',
                        ], 5);
                        $octets = $rep->getStatusCode() === 200 ? (string) $rep->getBody() : '';
                    } catch (\Throwable $e) {
                        $octets = '';
                    }

                    if ($octets === '') {
                        imagedestroy($img);

                        return '';
                    }

                    @file_put_contents($fichier, $octets);
                }

                $tuile = @imagecreatefromstring($octets);

                if ($tuile === false) {
                    continue;
                }

                imagecopy($img, $tuile, (int) round($tx * 256 - $gauche), (int) round($ty * 256 - $haut), 0, 0, 256, 256);
                imagedestroy($tuile);
            }
        }

        if (!is_dir(\dirname($abs))) {
            @mkdir(\dirname($abs), 0755, true);
        }

        $ok = @imagejpeg($img, $abs, 82);
        imagedestroy($img);

        return $ok ? Uri::root(true) . '/' . $rel : '';
    }

    /** Une adresse web saisie : rendue seulement si elle commence par http(s). */
    private function lienSur(string $url): array
    {
        $url = trim($url);

        if (!preg_match('#^https?://[^\s/]+#i', $url)) {
            return [];
        }

        $hote = preg_replace('/^www\./i', '', (string) parse_url($url, PHP_URL_HOST));

        return ['url' => $url, 'texte' => $hote];
    }

    /**
     * LES RESEAUX SOCIAUX D'UN LIEU : une adresse par ligne, le nom du reseau
     * deduit de l'adresse. Ecrit en toutes lettres, sans logo : le lien dit
     * ou il mene, et aucun dessin de marque n'est embarque dans le module.
     */
    private function reseaux(string $brut): array
    {
        $noms = [
            'facebook.com' => 'Facebook', 'fb.com' => 'Facebook', 'instagram.com' => 'Instagram',
            'linkedin.com' => 'LinkedIn', 'x.com' => 'X', 'twitter.com' => 'X',
            'youtube.com' => 'YouTube', 'youtu.be' => 'YouTube', 'tiktok.com' => 'TikTok',
            'pinterest.com' => 'Pinterest', 'pinterest.fr' => 'Pinterest', 'threads.net' => 'Threads',
            'bsky.app' => 'Bluesky', 'mastodon.social' => 'Mastodon', 'whatsapp.com' => 'WhatsApp', 'wa.me' => 'WhatsApp',
        ];
        $sortie = [];

        foreach (preg_split('/\R/', $brut) as $ligne) {
            $l = $this->lienSur($ligne);

            if ($l === []) {
                continue;
            }

            $hote = strtolower($l['texte']);
            $l['texte'] = $noms[$hote] ?? (preg_match('/(^|\.)mastodon\./', $hote) ? 'Mastodon' : $l['texte']);
            $sortie[] = $l;
        }

        return $sortie;
    }

    /**
     * LES INFORMATIONS D'UN LIEU, DANS L'ORDRE CHOISI.
     *
     * Chaque ligne a un type, et le type decide du rendu : un lien d'appel,
     * un lien de courriel, l'adresse d'un site sans son www, le nom d'un
     * reseau en toutes lettres, un lien vers un element de menu, ou du texte
     * sur plusieurs lignes. CINQ AU PLUS, comme le manifeste.
     *
     * LES CHAMPS FIXES DE LA PREMIERE VERSION (soir du 3 octobre 2026, banc
     * seulement) sont relus si la liste est vide : un module enregistre avec
     * eux ne perd rien avant d'etre repris.
     *
     * @return array<int, object{sorte: string, intitule: string, texte: string, href: string, onglet: bool}>
     */
    private function infosLieu(object $l): array
    {
        $lignes = $this->lignes($l->infos ?? null);

        if ($lignes === []) {
            $anciens = [
                ['texte', (string) ($l->precision ?? '')],
                ['tel', (string) ($l->telephone ?? '')],
                ['horaires', (string) ($l->horaires ?? '')],
                ['site', (string) ($l->site ?? '')],
            ];

            foreach (preg_split('/\R/', (string) ($l->reseaux ?? '')) as $r) {
                $anciens[] = ['reseau', $r];
            }

            $anciens[] = ['texte', (string) ($l->texte ?? '')];

            foreach ($anciens as [$type, $valeur]) {
                if (trim($valeur) !== '') {
                    $lignes[] = (object) ['type' => $type, 'valeur' => $valeur, 'valeurLongue' => $valeur];
                }
            }
        }

        $sortie = [];

        foreach (\array_slice($lignes, 0, 5) as $ligne) {
            $type     = (string) ($ligne->type ?? 'texte');
            $intitule = trim((string) ($ligne->intitule ?? ''));
            $court    = trim((string) ($ligne->valeur ?? ''));
            $long     = trim((string) ($ligne->valeurLongue ?? ''));
            $info     = ['sorte' => $type, 'intitule' => $intitule, 'texte' => '', 'href' => '', 'onglet' => false, 'classe' => $this->classeSaisie($ligne->classe ?? '')];

            switch ($type) {
                case 'tel':
                    if ($court === '') { continue 2; }
                    $info['texte'] = $court;
                    $info['href']  = 'tel:' . preg_replace('/[^\d+]/', '', $court);
                    break;

                case 'courriel':
                    if (!filter_var($court, FILTER_VALIDATE_EMAIL)) { continue 2; }
                    $info['texte'] = $court;
                    $info['href']  = 'mailto:' . $court;
                    break;

                case 'site':
                case 'reseau':
                    $lien = $type === 'reseau' ? ($this->reseaux($court)[0] ?? []) : $this->lienSur($court);
                    if ($lien === []) { continue 2; }
                    $info['texte']  = $lien['texte'];
                    $info['href']   = $lien['url'];
                    $info['onglet'] = true;
                    break;

                case 'page':
                    $itemid = (int) ($ligne->page ?? 0);
                    $item   = $itemid > 0 ? Factory::getApplication()->getMenu()->getItem($itemid) : null;
                    if (!$item) { continue 2; }
                    // L'intitule devient le texte du lien ; sans lui, le titre de l'element de menu.
                    $info['texte']    = $intitule !== '' ? $intitule : (string) $item->title;
                    $info['intitule'] = '';
                    $info['href']     = Route::_('index.php?Itemid=' . $itemid);
                    break;

                default:
                    $valeur = $long !== '' ? $long : $court;
                    if ($valeur === '') { continue 2; }
                    $info['sorte'] = $type === 'horaires' ? 'horaires' : 'texte';
                    $info['texte'] = $valeur;
            }

            $sortie[] = (object) $info;
        }

        return $sortie;
    }


    /**
     * LES LIEUX VENUS DES ARTICLES, 4 octobre 2026. « Le meme principe pour la
     * carte », Cyrille : un article par lieu, son titre pour nom et pour lien,
     * son adresse et sa position dans des champs personnalises (la position
     * evite le geocodage, trois adresses neuves au plus par affichage), les
     * autres champs choisis avec leur nom et leur rendu du coeur.
     *
     * Les objets rendus ressemblent a une ligne de lieu saisie ; ce qui est
     * deja pret passe par `_infos`, `_lien` et `_image`.
     */
    private function lieuxArticles(object $el): array
    {
        $cats = array_values(array_filter(array_map('intval', (array) ($el->carteCategories ?? []))));

        if ($cats === []) {
            return [];
        }

        $app = Factory::getApplication();
        $db  = Factory::getContainer()->get(DatabaseInterface::class);
        $now = Factory::getDate()->toSql();
        $q   = $db->getQuery(true)
            ->select($db->quoteName(['a.id', 'a.title', 'a.alias', 'a.catid', 'a.language', 'a.introtext', 'a.images']))
            ->from($db->quoteName('#__content', 'a'))
            ->whereIn($db->quoteName('a.catid'), $cats)
            ->where($db->quoteName('a.state') . ' = 1')
            ->whereIn($db->quoteName('a.access'), $app->getIdentity()->getAuthorisedViewLevels())
            ->where('(' . $db->quoteName('a.publish_up') . ' IS NULL OR ' . $db->quoteName('a.publish_up') . ' <= ' . $db->quote($now) . ')')
            ->where('(' . $db->quoteName('a.publish_down') . ' IS NULL OR ' . $db->quoteName('a.publish_down') . ' > ' . $db->quote($now) . ')')
            ->order($db->quoteName('a.ordering') . ' ASC, ' . $db->quoteName('a.title') . ' ASC')
            ->setLimit(300);

        if (Multilanguage::isEnabled($app)) {
            $q->whereIn($db->quoteName('a.language'), [$app->getLanguage()->getTag(), '*'], ParameterType::STRING);
        }

        try {
            $lignes = $db->setQuery($q)->loadObjectList();
        } catch (\Throwable $e) {
            return [];
        }

        $idAdresse = (int) ($el->carteChampAdresse ?? 0);
        $idLat     = (int) ($el->carteChampLat ?? 0);
        $idLon     = (int) ($el->carteChampLon ?? 0);
        $idsFiche  = array_values(array_filter(array_map('intval', (array) ($el->carteChamps ?? []))));
        $fiche     = (string) ($el->carteFicheArticle ?? '1') === '1';
        $sortie    = [];

        foreach ($lignes as $a) {
            $champs  = $this->champsArticle($a);
            $infos   = [];
            $adresse = $this->texteChamp($champs[$idAdresse] ?? null);
            $lat     = $this->texteChamp($champs[$idLat] ?? null);
            $lon     = $this->texteChamp($champs[$idLon] ?? null);

            // UN ARTICLE SANS ADRESSE NI POSITION N'EST PAS UN LIEU : il n'a rien a faire sur la carte.
            if ($adresse === '' && ($lat === '' || $lon === '')) {
                continue;
            }

            if ($fiche) {
                $intro = trim(preg_replace('/\s+/u', ' ', strip_tags((string) $a->introtext)));

                if (mb_strlen($intro) > 180) {
                    $intro = rtrim(mb_substr($intro, 0, 180)) . '…';
                }

                if ($intro !== '') {
                    $infos[] = (object) ['sorte' => 'texte', 'intitule' => '', 'texte' => $intro, 'href' => '', 'onglet' => false, 'html' => '', 'classe' => ''];
                }
            }

            foreach ($idsFiche as $id) {
                $c = $champs[$id] ?? null;

                if ($c === null || \in_array($id, [$idAdresse, $idLat, $idLon], true) || trim(strip_tags((string) $c->value)) === '') {
                    continue;
                }

                $infos[] = (object) [
                    'sorte' => 'champ', 'intitule' => trim((string) ($c->label ?? '')) !== '' ? (string) $c->label : (string) $c->title,
                    'texte' => '', 'html' => (string) $c->value, 'href' => '', 'onglet' => false,
                    'classe' => 'opus__carte-info--' . preg_replace('/[^a-z0-9-]/', '', (string) $c->name),
                ];
            }

            $images = $fiche ? json_decode((string) $a->images) : null;

            $sortie[] = (object) [
                'nom'     => (string) $a->title,
                'adresse' => $adresse,
                'lat'     => $lat,
                'lon'     => $lon,
                '_infos'  => $infos,
                '_lien'   => ['href' => Route::_(RouteHelper::getArticleRoute($a->id . ':' . $a->alias, $a->catid, $a->language)), 'target' => '', 'rel' => '', 'mention' => ''],
                '_image'  => $images ? $this->cheminMedia($images->image_intro ?? '') : '',
            ];
        }

        return $sortie;
    }

    /**
     * La carte, prete a poser.
     *
     * LA LISTE EST LE CONTENU, LA CARTE EN EST L'ILLUSTRATION. Chaque lieu
     * nomme sort dans la liste, trouve ou non ; seuls les lieux dont la
     * position est connue ont un repere et un bouton d'itineraire.
     *
     * AVANT LE CLIC, PAS UNE TUILE : la zone montre un fond neutre et les
     * reperes, places ici en pourcentages a partir de leurs positions. Le
     * visiteur voit ou sont les lieux les uns par rapport aux autres sans que
     * la page ait rien demande a OpenStreetMap.
     */
    public function carte(object $el): ?object
    {
        $lieux = [];
        $forme = \in_array($el->carteForme ?? '', ['goutte', 'rond', 'carre'], true) ? $el->carteForme : 'goutte';
        $base  = self::COULEURS_CARTE[$el->carteCouleur ?? ''] ?? self::COULEURS_CARTE['accent'];
        $iconeCarte = ($el->carteContenu ?? 'numero') === 'icone' ? trim((string) ($el->carteIcone ?? '')) : '';
        $guidage = \in_array($el->carteGuidage ?? '', ['osm', 'google', 'aucun'], true) ? $el->carteGuidage : 'osm';
        $route   = (string) ($el->carteRoute ?? '1') === '1';

        // LES LIEUX : saisis dans le module, ou venus des articles de categories.
        $sources = ($el->carteSource ?? 'ici') === 'articles' ? $this->lieuxArticles($el) : $this->lignes($el->lieux ?? null);

        foreach ($sources as $l) {
            $nom     = trim((string) ($l->nom ?? ''));
            $adresse = trim((string) ($l->adresse ?? ''));

            if ($nom === '' && $adresse === '') {
                continue;
            }

            $lat = $this->coordonnee($l->lat ?? '', 90);
            $lon = $this->coordonnee($l->lon ?? '', 180);

            if ($lat === null || $lon === null) {
                [$lat, $lon] = $this->geocoder($adresse) ?? [null, null];
            }

            $c = (string) ($l->couleur ?? '');
            $perso = (string) ($l->couleurPerso ?? '');

            if ($c === 'perso' && preg_match('/^#[0-9a-f]{6}$/i', $perso)) {
                $couleur = $perso;
            } else {
                $couleur = self::COULEURS_CARTE[$c] ?? $base;
            }

            $icone = trim((string) ($l->icone ?? '')) !== '' ? trim((string) $l->icone) : $iconeCarte;
            $n     = \count($lieux) + 1;

            $lieux[] = (object) [
                'n'         => $n,
                'nom'       => $nom !== '' ? $nom : $adresse,
                'adresse'   => $nom !== '' ? $adresse : '',
                'infos'     => $l->_infos ?? $this->infosLieu($l),
                'image'     => $l->_image ?? '',
                'classe'    => $this->classeSaisie($l->classe ?? ''),
                // Le lien : element de menu ou adresse ; l'ancien champ `lien` (banc, 1.5.421) reste lu.
                'lien'      => $l->_lien ?? $this->lien($l) ?: (trim((string) ($l->lien ?? '')) !== '' ? ['href' => trim((string) $l->lien), 'target' => '', 'rel' => '', 'mention' => ''] : []),
                'lat'       => $lat,
                'lon'       => $lon,
                'couleur'   => $couleur,
                'marque'    => $icone !== '' ? $this->picto($icone) : (string) $n,
                'guidage'   => '',
                'x'         => 50.0,
                'y'         => 50.0,
            ];
        }

        if ($lieux === []) {
            return null;
        }

        // LES REPERES DE LA FACADE, en pourcentages de la zone, marges comprises.
        $places = array_filter($lieux, static fn ($l) => $l->lat !== null);

        if ($places !== []) {
            $pts  = array_map(static fn ($l) => self::mercator($l->lat, $l->lon), $places);
            $xs   = array_column($pts, 0);
            $ys   = array_column($pts, 1);
            $dx   = max(max($xs) - min($xs), 1e-9);
            $dy   = max(max($ys) - min($ys), 1e-9);
            $seul = \count($places) === 1;

            foreach ($places as $k => $l) {
                $l->x = $seul ? 50.0 : round(12 + 76 * ($pts[$k][0] - min($xs)) / $dx, 2);
                $l->y = $seul ? 55.0 : round(18 + 70 * ($pts[$k][1] - min($ys)) / $dy, 2);

                if (!$route || $guidage !== 'aucun') {
                    $dest = $l->lat . ',' . $l->lon;
                    $l->guidage = $guidage === 'google'
                        ? 'https://www.google.com/maps/dir/?api=1&destination=' . $dest
                        : 'https://www.openstreetmap.org/directions?to=' . $dest;
                }
            }
        }

        if ($guidage === 'aucun') {
            foreach ($lieux as $l) {
                $l->guidage = '';
            }
        }

        $this->cartes = true;
        self::$nCartes++;

        $hauteurs = ['petite' => 300, 'moyenne' => 420, 'grande' => 560];
        $h = ($el->carteHauteur ?? 'moyenne') === 'libre'
            ? max(200, min(1200, (int) ($el->carteHauteurPx ?? 480)))
            : ($hauteurs[$el->carteHauteur ?? ''] ?? 420);
        $liste = \in_array($el->carteListe ?? '', ['droite', 'gauche', 'dessus', 'dessous'], true) ? $el->carteListe : 'droite';
        $zoom  = (string) ($el->carteZoom ?? 'auto');
        $titre = trim((string) ($el->carteTitre ?? ''));
        $vue   = $places !== [] ? $this->vueCarte($places, ctype_digit($zoom) ? (int) $zoom : 0, $h) : null;
        $image = $vue !== null ? $this->imageCarte($vue, $h) : '';

        // Les reperes de la facade, decales du centre en pixels : l'image est centree, eux aussi.
        if ($vue !== null) {
            foreach ($places as $l) {
                $p = self::pixelsMonde($l->lat, $l->lon, $vue['z']);
                $l->dx = round($p[0] - $vue['cx']);
                $l->dy = round($p[1] - $vue['cy']);
            }
        }

        $donnees = [
            'lieux'   => array_values(array_map(static fn ($l) => [
                'n' => $l->n, 'lat' => $l->lat, 'lon' => $l->lon, 'nom' => $l->nom,
            ], $places)),
            'zoom'    => ctype_digit($zoom) ? (int) $zoom : 0,
            'vue'     => $vue,
            'route'   => $route,
            'guidage' => $guidage,
            'textes'  => [
                'zoomer'    => Text::_('MOD_OPUS_MAP_JS_ZOOM_IN'),
                'dezoomer'  => Text::_('MOD_OPUS_MAP_JS_ZOOM_OUT'),
                'jusqua'    => Text::_('MOD_OPUS_MAP_JS_TO'),
                'pied'      => Text::_('MOD_OPUS_MAP_JS_FOOT'),
                'velo'      => Text::_('MOD_OPUS_MAP_JS_BIKE'),
                'voiture'   => Text::_('MOD_OPUS_MAP_JS_CAR'),
                'moyen'     => Text::_('MOD_OPUS_MAP_JS_MODE'),
                'depuis'    => Text::_('MOD_OPUS_MAP_JS_FROM_HERE'),
                'adresse'   => Text::_('MOD_OPUS_MAP_JS_FROM_ADDRESS'),
                'depart'    => Text::_('MOD_OPUS_MAP_JS_START_LABEL'),
                'calculer'  => Text::_('MOD_OPUS_MAP_JS_COMPUTE'),
                'fermer'    => Text::_('MOD_OPUS_MAP_JS_CLOSE'),
                'guidage'   => Text::_('MOD_OPUS_MAP_JS_GUIDE'),
                'cherche'   => Text::_('MOD_OPUS_MAP_JS_LOCATING'),
                'calcul'    => Text::_('MOD_OPUS_MAP_JS_ROUTING'),
                'refus'     => Text::_('MOD_OPUS_MAP_JS_DENIED'),
                'introuvable' => Text::_('MOD_OPUS_MAP_JS_NOT_FOUND'),
                'echec'     => Text::_('MOD_OPUS_MAP_JS_FAILED'),
                'vous'      => Text::_('MOD_OPUS_MAP_JS_YOU'),
                'source'    => Text::_('MOD_OPUS_MAP_JS_ROUTE_CREDIT'),
            ],
        ];

        return (object) [
            'id'        => 'opus-carte-' . self::$nCartes,
            'titre'     => $titre !== '' ? $titre : Text::_('MOD_OPUS_ELEMENT_MAP'),
            'classes'   => trim('opus__carte--liste-' . $liste . ' opus__carte--' . $forme
                . (\in_array($liste, ['droite', 'gauche'], true) ? ' opus__carte--l' . (\in_array((string) ($el->carteLargeur ?? '5'), ['3', '4', '5', '6'], true) ? (string) ($el->carteLargeur ?? '5') : '5') : '')
                . ' ' . $el->classe),
            'hauteur'   => $h,
            'image'     => $image,
            'lieux'     => $lieux,
            'route'     => $route,
            'nomGuidage' => $guidage === 'google' ? 'Google Maps' : 'OpenStreetMap',
            'donnees'   => json_encode($donnees, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ];
    }

    /* ======================================================================
       L'AGENDA, 4 octobre 2026 (serie 1.5.4xx).

       Maquette validee par Cyrille : https://claude.ai/artifact/SN1gmrt19DqVcHHzx6TTRv
       Le dos est celui de la carte : une liste d'evenements comme celle des
       lieux, cinq infos au plus par evenement, la fiche a droite, a gauche ou
       dessous. La grille du mois est un tableau HTML ecrit ici ; `agenda.js`
       la redessine pour les autres mois, a l'identique.
       ====================================================================== */

    /** VRAI DES QU'UN AGENDA EST POSE : `agenda.js` ne se charge qu'alors. */
    private bool $agendas = false;

    /** Le nombre d'agendas deja poses dans la page, pour des identifiants uniques. */
    private static int $nAgendas = 0;

    /** Le montage porte-t-il au moins un agenda ? */
    public function aDesAgendas(): bool
    {
        return $this->agendas;
    }

    /** Le fuseau du site : l'heure d'une seance est celle du lieu, pas celle du visiteur. */
    private function fuseau(): \DateTimeZone
    {
        try {
            return new \DateTimeZone((string) Factory::getApplication()->get('offset', 'UTC'));
        } catch (\Throwable $e) {
            return new \DateTimeZone('UTC');
        }
    }

    /**
     * UNE DATE SAISIE, LUE TELLE QUELLE. Le champ Date du coeur, avec
     * `filter="none"`, garde « 2026-10-14 15:30:00 » : c'est l'heure du lieu.
     */
    private function dateSaisie($valeur): ?\DateTimeImmutable
    {
        $v = trim((string) $valeur);

        if ($v === '' || str_starts_with($v, '0000')) {
            return null;
        }

        foreach (['Y-m-d H:i:s', 'Y-m-d H:i', 'Y-m-d'] as $f) {
            $d = \DateTimeImmutable::createFromFormat('!' . $f, $v, $this->fuseau());

            if ($d !== false) {
                return $d;
            }
        }

        return null;
    }

    /** Une date ecrite dans la langue du site, avec les noms de jours et de mois du coeur. */
    private function dateLangue(\DateTimeImmutable $d, string $format): string
    {
        $date = new Date($d->format('Y-m-d H:i:s'), $this->fuseau());
        $date->setTimezone($this->fuseau());

        return $date->format($format, true);
    }

    /**
     * QUAND, EN TOUTES LETTRES, POUR LA FICHE : « mercredi 14 octobre 2026, de
     * 15:30 a 16:15 ». Les formes viennent des clefs de langue, la date du
     * format long du coeur (DATE_FORMAT_LC1).
     */
    private function quand(\DateTimeImmutable $debut, ?\DateTimeImmutable $fin, bool $journee): string
    {
        $long  = Text::_('DATE_FORMAT_LC1');
        $heure = Text::_('MOD_OPUS_AGENDA_TIME_FORMAT');
        $jour  = $this->dateLangue($debut, $long);

        // UNE SOIREE QUI FINIT APRES MINUIT reste une soiree : « de 20:00 a 01:00 », pas « du 24 au 25 ».
        $court = $fin !== null && !$journee && $fin->getTimestamp() - $debut->getTimestamp() < 86400;

        if ($fin !== null && !$court && $fin->format('Y-m-d') !== $debut->format('Y-m-d')) {
            return Text::sprintf('MOD_OPUS_AGENDA_WHEN_DAYS', $jour, $this->dateLangue($fin, $long));
        }

        if ($journee) {
            return $jour;
        }

        if ($fin !== null && $fin > $debut) {
            return Text::sprintf('MOD_OPUS_AGENDA_WHEN_FROM_TO', $jour, $debut->format($heure), $fin->format($heure));
        }

        return Text::sprintf('MOD_OPUS_AGENDA_WHEN_AT', $jour, $debut->format($heure));
    }

    /**
     * LES INFOS D'UN EVENEMENT, DANS L'ORDRE CHOISI : celles d'un lieu, plus le
     * lieu (avec son lien de carte), la reservation, le tarif et le public.
     */
    private function infosEvenement(object $ev, string $guidage): array
    {
        $sortie = [];

        foreach (\array_slice($this->lignes($ev->infos ?? null), 0, 5) as $ligne) {
            $type     = (string) ($ligne->type ?? 'texte');
            $intitule = trim((string) ($ligne->intitule ?? ''));
            $court    = trim((string) ($ligne->valeur ?? ''));
            $info     = [
                'sorte' => $type, 'intitule' => $intitule, 'texte' => '', 'href' => '', 'onglet' => false,
                'adresse' => '', 'carte' => '', 'html' => '', 'classe' => $this->classeSaisie($ligne->classe ?? ''),
            ];

            switch ($type) {
                case 'lieu':
                    $adresse = trim((string) ($ligne->adresse ?? ''));
                    if ($court === '' && $adresse === '') { continue 2; }
                    $info['texte']   = $court !== '' ? $court : $adresse;
                    $info['adresse'] = $court !== '' ? $adresse : '';
                    if ($adresse !== '' && $guidage !== 'aucun') {
                        $info['carte'] = $guidage === 'google'
                            ? 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($adresse)
                            : 'https://www.openstreetmap.org/search?query=' . rawurlencode($adresse);
                    }
                    break;

                case 'enligne':
                    // UN EVENEMENT EN LIGNE, 4 octobre 2026 : « En ligne », lie a
                    // l'adresse ou le suivre si elle est donnee. schemaAgenda() en
                    // tire un VirtualLocation et le mode de participation.
                    $lien = $this->lienSur($court);
                    $info['texte'] = Text::_('MOD_OPUS_AGENDA_INFO_ONLINE');
                    if ($lien !== []) {
                        $info['href']   = $lien['url'];
                        $info['onglet'] = true;
                    }
                    break;

                case 'tel':
                    if ($court === '') { continue 2; }
                    $info['texte'] = $court;
                    $info['href']  = 'tel:' . preg_replace('/[^\d+]/', '', $court);
                    break;

                case 'courriel':
                    if (!filter_var($court, FILTER_VALIDATE_EMAIL)) { continue 2; }
                    $info['texte'] = $court;
                    $info['href']  = 'mailto:' . $court;
                    break;

                case 'site':
                case 'reservation':
                    $lien = $this->lienSur($court);
                    if ($lien === []) { continue 2; }
                    $info['texte']  = $type === 'reservation' && $intitule !== '' ? $intitule : $lien['texte'];
                    $info['href']   = $lien['url'];
                    $info['onglet'] = true;
                    if ($type === 'reservation') { $info['intitule'] = $intitule !== '' ? '' : Text::_('MOD_OPUS_AGENDA_INFO_BOOKING'); }
                    break;

                case 'page':
                    $itemid = (int) ($ligne->page ?? 0);
                    $item   = $itemid > 0 ? Factory::getApplication()->getMenu()->getItem($itemid) : null;
                    if (!$item) { continue 2; }
                    $info['texte']    = $intitule !== '' ? $intitule : (string) $item->title;
                    $info['intitule'] = '';
                    $info['href']     = Route::_('index.php?Itemid=' . $itemid);
                    break;

                case 'texte':
                    $long = trim((string) ($ligne->valeurLongue ?? ''));
                    $valeur = $long !== '' ? $long : $court;
                    if ($valeur === '') { continue 2; }
                    $info['texte'] = $valeur;
                    break;

                default:
                    // Tarif, public : une valeur courte, avec son intitule par defaut.
                    if ($court === '') { continue 2; }
                    $info['texte'] = $court;
            }

            // L'intitule par defaut, sauf pour le texte libre et les liens qui portent deja leur nom.
            if ($info['intitule'] === '' && !\in_array($type, ['texte', 'page', 'reservation'], true)) {
                $noms = [
                    'lieu' => 'MOD_OPUS_AGENDA_INFO_PLACE', 'enligne' => 'MOD_OPUS_AGENDA_INFO_PLACE', 'site' => 'MOD_OPUS_MAP_INFO_SITE', 'tarif' => 'MOD_OPUS_AGENDA_INFO_PRICE',
                    'public' => 'MOD_OPUS_AGENDA_INFO_AUDIENCE', 'tel' => 'MOD_OPUS_MAP_INFO_TEL', 'courriel' => 'MOD_OPUS_MAP_INFO_MAIL',
                ];
                $info['intitule'] = isset($noms[$type]) ? Text::_($noms[$type]) : '';
            }

            $sortie[] = (object) $info;
        }

        return $sortie;
    }

    /** Les evenements saisis dans le module. */
    private function evenementsSaisis(object $el, string $base, string $guidage): array
    {
        $sortie = [];

        foreach ($this->lignes($el->evenements ?? null) as $ev) {
            $titre = trim((string) ($ev->titre ?? ''));
            $debut = $this->dateSaisie($ev->debut ?? '');

            if ($titre === '' || $debut === null) {
                continue;
            }

            $journee = (string) ($ev->journee ?? '0') === '1';
            $fin     = $this->dateSaisie($ev->fin ?? '');
            $fin     = ($fin !== null && $fin > $debut) ? $fin : null;
            $dates   = [[$debut, $fin]];

            $cle = (string) ($ev->couleur ?? '');

            $sortie[] = (object) [
                'titre'   => $titre,
                'cle'     => isset(self::COULEURS_CARTE[$cle]) ? $cle : $base,
                'classe'  => $this->classeSaisie($ev->classe ?? ''),
                'journee' => $journee,
                'dates'   => $dates,
                'infos'   => $this->infosEvenement($ev, $guidage),
                'lien'    => $this->lien($ev),
                'lienTexte' => $this->texteParDefaut($ev, trim((string) ($ev->linkTexte ?? ''))),
                'image'   => $this->cheminMedia($ev->image ?? ''),
            ];
        }

        return $sortie;
    }

    /**
     * UN CALENDRIER EN LIGNE (.ics), 5 octobre 2026. Demande d'un utilisateur
     * qui affiche aujourd'hui un agenda iCal avec DPCalendar : coller l'adresse
     * publique d'un agenda (Google, Outlook, Apple, Nextcloud, export de
     * DPCalendar) et le voir avec les vues et les fiches d'Opus.
     *
     * C'EST LE SERVEUR QUI LIT LE CALENDRIER, jamais le navigateur du
     * visiteur. Une copie est gardee dans le cache de Joomla le temps choisi
     * (une heure par defaut) : la page ne paie la lecture qu'une fois, et si
     * l'adresse ne repond plus, la derniere copie sert encore.
     *
     * Ce que le fichier donne, Opus le range comme un evenement saisi : le
     * lieu (avec « Voir sur la carte », ou « En ligne » si c'est une adresse
     * web), la description en texte, l'adresse web en titre cliquable et en
     * bouton « En savoir plus ». La fenetre lue va de trois mois en arriere a
     * quinze mois devant : assez pour les vues, sans deplier une serie sans fin.
     */
    private function evenementsIcs(object $el, string $base, string $guidage): array
    {
        $url = trim((string) ($el->agendaIcsUrl ?? ''));
        $url = preg_replace('#^webcals?://#i', 'https://', $url);

        if (!preg_match('#^https?://[^\s/]+#i', $url)) {
            return [];
        }

        $duree = (int) ($el->agendaIcsRelire ?? 3600);
        $duree = \in_array($duree, [900, 3600, 21600, 86400], true) ? $duree : 3600;
        $texte = $this->icsTexte($url, $duree);

        if ($texte === '') {
            $this->icsSignaler($el, $this->icsErreur !== '' ? $this->icsErreur : 'vide');

            return [];
        }

        $tz      = $this->fuseau();
        $lecteur = new IcsLecteur($tz);
        $sortie  = [];

        // Depuis le 1er janvier de l'an dernier : la vue a l'annee montre l'annee entiere,
        // et le mois de janvier peut encore regarder decembre.
        $de  = new \DateTimeImmutable('first day of january last year 00:00', $tz);
        $lus = $lecteur->evenements($texte, $de, new \DateTimeImmutable('+15 months', $tz));

        if ($lus === []) {
            $this->icsSignaler($el, Text::_('MOD_OPUS_AGENDA_ICS_NONE'));
        }

        foreach ($lus as $e) {
            $infos = [];
            $lieu  = trim(preg_replace('/\s+/u', ' ', $e['lieu']));

            if (preg_match('#^https?://\S+$#i', $lieu)) {
                // Une visioconference : le lieu est une adresse web.
                $infos[] = (object) [
                    'sorte' => 'enligne', 'intitule' => Text::_('MOD_OPUS_AGENDA_INFO_PLACE'), 'texte' => Text::_('MOD_OPUS_AGENDA_INFO_ONLINE'),
                    'href' => $lieu, 'onglet' => true, 'html' => '', 'adresse' => '', 'carte' => '', 'classe' => '',
                ];
            } elseif ($lieu !== '') {
                // Le lieu d'un agenda est souvent une adresse entiere : elle sert aussi au lien de carte.
                $infos[] = (object) [
                    'sorte' => 'lieu', 'intitule' => Text::_('MOD_OPUS_AGENDA_INFO_PLACE'), 'texte' => $lieu,
                    'href' => '', 'onglet' => false, 'html' => '', 'adresse' => '', 'classe' => '',
                    'carte' => $guidage !== 'aucun'
                        ? ($guidage === 'google' ? 'https://www.google.com/maps/search/?api=1&query=' : 'https://www.openstreetmap.org/search?query=') . rawurlencode($lieu)
                        : '',
                ];
            }

            $desc = trim(strip_tags($e['description']));

            if (mb_strlen($desc) > 600) {
                $desc = rtrim(mb_substr($desc, 0, 600)) . '…';
            }

            if ($desc !== '') {
                $infos[] = (object) ['sorte' => 'texte', 'intitule' => '', 'texte' => $desc, 'href' => '', 'onglet' => false, 'html' => '', 'adresse' => '', 'carte' => '', 'classe' => ''];
            }

            $sortie[] = (object) [
                'titre'     => $e['titre'],
                'cle'       => $base,
                'classe'    => 'opus__agenda-fiche--ics',
                'journee'   => $e['journee'],
                'dates'     => $e['dates'],
                'infos'     => $infos,
                'lien'      => $e['url'] !== '' ? ['href' => $e['url'], 'target' => '_blank', 'rel' => 'noopener', 'mention' => Text::_('MOD_OPUS_NEW_WINDOW')] : [],
                'lienTexte' => Text::_('MOD_OPUS_AGENDA_MORE_INFO'),
                'image'     => '',
            ];
        }

        return $sortie;
    }

    /** La raison du dernier echec de lecture d'un calendrier .ics, pour le message aux administrateurs. */
    private string $icsErreur = '';

    /**
     * UN CALENDRIER QUI NE DONNE RIEN, DIT A CEUX QUI PEUVENT LE CORRIGER. Sans
     * evenement, l'agenda ne sort pas, et une page muette ne dit pas pourquoi :
     * un message de Joomla l'explique, aux seuls utilisateurs qui peuvent
     * modifier les modules, ou a tous quand le debogage de Joomla est actif.
     * Les visiteurs d'un site en service ne voient rien.
     */
    private function icsSignaler(object $el, string $raison): void
    {
        try {
            $app = Factory::getApplication();

            if ($app->isClient('site') && ((\defined('JDEBUG') && JDEBUG) || $app->getIdentity()->authorise('core.edit', 'com_modules'))) {
                $app->enqueueMessage(Text::sprintf('MOD_OPUS_AGENDA_ICS_ERROR', trim((string) ($el->agendaTitre ?? '')), $raison), 'warning');
            }
        } catch (\Throwable $e) {
        }
    }

    /**
     * LE TEXTE DU CALENDRIER, lu au plus une fois par periode choisie. La copie
     * vit dans le cache de Joomla (`cache/mod_opus/ics-...`) : vider le cache
     * force une nouvelle lecture. Un fichier de plus de 5 Mo n'est pas lu.
     */
    private function icsTexte(string $url, int $duree): string
    {
        $dir   = JPATH_CACHE . '/mod_opus';
        $copie = $dir . '/ics-' . md5($url) . '.ics';

        if (is_file($copie) && time() - (int) filemtime($copie) < $duree) {
            return (string) file_get_contents($copie);
        }

        // Une adresse en panne sans copie : on ne la redemande qu'un quart d'heure plus tard (10 s d'attente a chaque fois sinon).
        $echec = $copie . '.echec';

        if (!is_file($copie) && is_file($echec) && time() - (int) filemtime($echec) < min($duree, 900)) {
            return '';
        }

        try {
            $reponse = HttpFactory::getHttp()->get($url, ['User-Agent' => 'Opus, module Joomla (' . Uri::root() . ')', 'Accept' => 'text/calendar, */*'], 10);
            $corps   = (string) $reponse->getBody();

            $this->icsErreur = $reponse->getStatusCode() === 200 ? (stripos($corps, 'BEGIN:VCALENDAR') === false ? 'pas un calendrier .ics' : '') : 'HTTP ' . $reponse->getStatusCode();

            if ($reponse->getStatusCode() === 200 && \strlen($corps) < 5242880 && stripos($corps, 'BEGIN:VCALENDAR') !== false) {
                if (!is_dir($dir)) {
                    @mkdir($dir, 0755, true);
                }

                @file_put_contents($copie, $corps);

                return $corps;
            }
        } catch (\Throwable $e) {
            // L'adresse ne repond pas : la derniere copie, si elle existe.
            $this->icsErreur = $e->getMessage();
        }

        if (is_file($copie)) {
            // On ne relit pas a chaque page une adresse en panne : la copie repart pour une periode.
            @touch($copie);

            return (string) file_get_contents($copie);
        }

        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        @touch($echec);

        return '';
    }

    /**
     * LES ARTICLES D'UNE OU PLUSIEURS CATEGORIES, places a leur date de
     * creation ou de publication. « Un petit calendrier en colonne pour
     * afficher les dates de creation d'articles en fonction des categories
     * choisies », Cyrille, 4 octobre 2026. Les droits d'acces, la langue et
     * les dates de publication du coeur sont respectes.
     */
    private function evenementsArticles(object $el, string $base, string $guidage = 'osm'): array
    {
        $cats = array_values(array_filter(array_map('intval', (array) ($el->agendaCategories ?? []))));

        if ($cats === []) {
            return [];
        }

        $mode = (string) ($el->agendaDate ?? 'created');
        $col  = $mode === 'publish_up' ? 'publish_up' : 'created';
        $app  = Factory::getApplication();
        $db   = Factory::getContainer()->get(DatabaseInterface::class);
        $now  = Factory::getDate()->toSql();
        $q    = $db->getQuery(true)
            ->select($db->quoteName(['a.id', 'a.title', 'a.alias', 'a.catid', 'a.language', 'a.introtext', 'a.images']))
            ->select($db->quoteName('a.' . $col, 'quand'))
            ->from($db->quoteName('#__content', 'a'))
            ->whereIn($db->quoteName('a.catid'), $cats)
            ->where($db->quoteName('a.state') . ' = 1')
            ->whereIn($db->quoteName('a.access'), $app->getIdentity()->getAuthorisedViewLevels())
            ->where('(' . $db->quoteName('a.publish_up') . ' IS NULL OR ' . $db->quoteName('a.publish_up') . ' <= ' . $db->quote($now) . ')')
            ->where('(' . $db->quoteName('a.publish_down') . ' IS NULL OR ' . $db->quoteName('a.publish_down') . ' > ' . $db->quote($now) . ')')
            ->order($db->quoteName('a.' . $col) . ' DESC')
            ->setLimit(300);

        if (Multilanguage::isEnabled($app)) {
            $q->whereIn($db->quoteName('a.language'), [$app->getLanguage()->getTag(), '*'], ParameterType::STRING);
        }

        try {
            $lignes = $db->setQuery($q)->loadObjectList();
        } catch (\Throwable $e) {
            return [];
        }

        // LES CHAMPS PERSONNALISES CHOISIS derriere la roue : les dates, le lieu, et ceux de la fiche.
        $idDebut   = (int) ($el->agendaChampDebut ?? 0);
        $idFin     = (int) ($el->agendaChampFin ?? 0);
        $idLieu    = (int) ($el->agendaChampLieu ?? 0);
        $idAdresse = (int) ($el->agendaChampAdresse ?? 0);
        $idsFiche  = array_values(array_filter(array_map('intval', (array) ($el->agendaChamps ?? []))));
        $parChamp  = $mode === 'champ' || $idLieu || $idAdresse || $idsFiche !== [];
        $ficheArticle = (string) ($el->agendaFicheArticle ?? '1') === '1';

        if ($mode === 'champ' && $idDebut <= 0) {
            return [];
        }

        $sortie = [];

        foreach ($lignes as $a) {
            $champs = $parChamp ? $this->champsArticle($a) : [];

            // LA DATE : celle d'un champ Calendrier, ou celle de l'article.
            if ($mode === 'champ') {
                [$d, $journee] = $this->dateChamp($champs[$idDebut] ?? null);
                [$f]           = $this->dateChamp($champs[$idFin] ?? null);

                if ($d === null) {
                    continue;
                }

                $f = ($f !== null && $f > $d) ? $f : null;
            } else {
                if (empty($a->quand)) {
                    continue;
                }

                $d = (new \DateTimeImmutable((string) $a->quand, new \DateTimeZone('UTC')))->setTimezone($this->fuseau())->setTime(0, 0);
                $f = null;
                $journee = true;
            }

            $infos = [];

            // Le lieu et son adresse, avec le lien de carte, comme un evenement saisi.
            $lieu    = $this->texteChamp($champs[$idLieu] ?? null);
            $adresse = $this->texteChamp($champs[$idAdresse] ?? null);

            if ($lieu !== '' || $adresse !== '') {
                $infos[] = (object) [
                    'sorte' => 'lieu', 'intitule' => Text::_('MOD_OPUS_AGENDA_INFO_PLACE'), 'texte' => $lieu !== '' ? $lieu : $adresse,
                    'href' => '', 'onglet' => false, 'html' => '', 'classe' => '',
                    'adresse' => $lieu !== '' ? $adresse : '',
                    'carte' => ($adresse !== '' && $guidage !== 'aucun')
                        ? ($guidage === 'google' ? 'https://www.google.com/maps/search/?api=1&query=' : 'https://www.openstreetmap.org/search?query=') . rawurlencode($adresse)
                        : '',
                ];
            }

            // Les autres champs choisis, avec leur nom et leur rendu du coeur (un lien reste un lien).
            foreach ($idsFiche as $id) {
                $c = $champs[$id] ?? null;

                if ($c === null || \in_array($id, [$idDebut, $idFin, $idLieu, $idAdresse], true) || trim(strip_tags((string) $c->value)) === '') {
                    continue;
                }

                $infos[] = (object) [
                    'sorte' => 'champ', 'intitule' => trim((string) ($c->label ?? '')) !== '' ? (string) $c->label : (string) $c->title, 'texte' => '', 'html' => (string) $c->value,
                    'href' => '', 'onglet' => false, 'adresse' => '', 'carte' => '', 'classe' => 'opus__agenda-info--' . preg_replace('/[^a-z0-9-]/', '', (string) $c->name),
                ];
            }

            // LA FICHE FACON BLOG : le texte d'introduction, l'image d'introduction.
            $intro = trim(preg_replace('/\s+/u', ' ', strip_tags((string) $a->introtext)));

            if (mb_strlen($intro) > 220) {
                $intro = rtrim(mb_substr($intro, 0, 220)) . '…';
            }

            if ($ficheArticle && $intro !== '') {
                array_unshift($infos, (object) ['sorte' => 'texte', 'intitule' => '', 'texte' => $intro, 'href' => '', 'onglet' => false, 'html' => '', 'adresse' => '', 'carte' => '', 'classe' => '']);
            }

            $image = '';

            if ($ficheArticle) {
                $images = json_decode((string) $a->images);
                $image  = $this->cheminMedia($images->image_intro ?? '');
            }

            $sortie[] = (object) [
                'titre'     => (string) $a->title,
                'cle'       => $base,
                'classe'    => 'opus__agenda-fiche--article',
                'journee'   => $journee,
                'dates'     => [[$d, $f]],
                'infos'     => $infos,
                'lien'      => ['href' => Route::_(RouteHelper::getArticleRoute($a->id . ':' . $a->alias, $a->catid, $a->language)), 'target' => '', 'rel' => '', 'mention' => ''],
                'lienTexte' => Text::_('MOD_OPUS_LINK_READ_MORE'),
                'image'     => $image,
            ];
        }

        return $sortie;
    }

    /**
     * LES CHAMPS PERSONNALISES D'UN ARTICLE, par identifiant, lus par le coeur
     * (`FieldsHelper::getFields`) : droits d'acces, categories et langue
     * respectes, valeur brute et rendu prepare par le plugin du champ.
     */
    private function champsArticle(object $a): array
    {
        try {
            $item = (object) ['id' => (int) $a->id, 'catid' => (int) $a->catid, 'language' => (string) $a->language];
            $tous = FieldsHelper::getFields('com_content.article', $item, true);
        } catch (\Throwable $e) {
            return [];
        }

        $sortie = [];

        foreach ($tous as $c) {
            $sortie[(int) $c->id] = $c;
        }

        return $sortie;
    }

    /**
     * La date d'un champ Calendrier. Le coeur la range en UTC (filtre
     * USER_UTC du plugin) : on la ramene a l'heure du site. Sans heure dans le
     * champ, c'est un evenement d'une journee.
     *
     * @return array{0: ?\DateTimeImmutable, 1: bool}
     */
    private function dateChamp(?object $c): array
    {
        $v = $c !== null ? trim((string) $c->rawvalue) : '';

        if ($v === '' || str_starts_with($v, '0000')) {
            return [null, true];
        }

        try {
            $d = (new \DateTimeImmutable($v, new \DateTimeZone('UTC')))->setTimezone($this->fuseau());
        } catch (\Throwable $e) {
            return [null, true];
        }

        $heure = (int) ($c->fieldparams instanceof Registry ? $c->fieldparams->get('showtime', 0) : 0) === 1;

        return [$heure ? $d : $d->setTime(0, 0), !$heure];
    }

    /** Le texte d'un champ (lieu, adresse) : son rendu sans balises. */
    private function texteChamp(?object $c): string
    {
        return $c !== null ? trim(html_entity_decode(strip_tags((string) $c->value), ENT_QUOTES, 'UTF-8')) : '';
    }

    /**
     * LA GRILLE D'UN MOIS : des semaines de sept jours, le premier jour celui
     * de la langue du site. Chaque jour porte ses occurrences ; la mise en page
     * en montre deux, puis « + n autres ».
     */
    public function grilleAgenda(int $an, int $mois, array $occ, string $auj, int $premier): array
    {
        $parJour = [];

        foreach ($occ as $o) {
            $parJour[$o['j']][] = $o;
        }

        $un  = new \DateTimeImmutable(sprintf('%04d-%02d-01', $an, $mois), $this->fuseau());
        $dec = ((int) $un->format('w') - $premier + 7) % 7;
        $d   = $un->modify('-' . $dec . ' days');
        $semaines = [];

        for ($s = 0; $s < 6; $s++) {
            if ($s > 0 && (int) $d->format('n') !== $mois) {
                break;
            }

            $semaine = [];

            for ($j = 0; $j < 7; $j++) {
                $cle = $d->format('Y-m-d');
                $semaine[] = (object) [
                    'jour'  => $cle,
                    'num'   => (int) $d->format('j'),
                    'hors'  => (int) $d->format('n') !== $mois,
                    'auj'   => $cle === $auj,
                    'passe' => $cle < $auj,
                    'occ'   => $parJour[$cle] ?? [],
                ];
                $d = $d->modify('+1 day');
            }

            $semaines[] = $semaine;
        }

        return $semaines;
    }

    /**
     * L'agenda, pret a poser.
     *
     * RIEN NE SORT SANS EVENEMENT DATE. La fiche montre d'abord le prochain
     * evenement ; la liste commence aujourd'hui, sauf si l'on garde le passe.
     */
    public function agenda(object $el): ?object
    {
        $base    = isset(self::COULEURS_CARTE[$el->agendaCouleur ?? '']) ? $el->agendaCouleur : 'accent';
        $guidage = \in_array($el->agendaGuidage ?? '', ['osm', 'google', 'aucun'], true) ? $el->agendaGuidage : 'osm';
        $source  = \in_array($el->agendaSource ?? 'ici', ['articles', 'ics'], true) ? $el->agendaSource : 'ici';
        $evs     = match ($source) {
            'articles' => $this->evenementsArticles($el, $base, $guidage),
            'ics'      => $this->evenementsIcs($el, $base, $guidage),
            default    => $this->evenementsSaisis($el, $base, $guidage),
        };

        if ($evs === []) {
            return null;
        }

        $tz      = $this->fuseau();
        $auj     = (new \DateTimeImmutable('now', $tz))->format('Y-m-d');
        $heure   = Text::_('MOD_OPUS_AGENDA_TIME_FORMAT');
        $court   = Text::_('MOD_OPUS_AGENDA_DATE_SHORT');
        $occ     = [];
        $quand   = [];

        foreach ($evs as $i => $ev) {
            $ev->n = $i;

            foreach ($ev->dates as $k => [$debut, $fin]) {
                $quand[$i][$k] = [
                    'q' => $this->quand($debut, $fin, $ev->journee),
                    'c' => $this->dateLangue($debut, $court) . ($ev->journee ? '' : ' ' . $debut->format($heure)),
                    's' => $ev->journee ? $debut->format('Ymd') : $debut->format('Ymd\THis'),
                    'f' => $fin !== null ? ($ev->journee ? $fin->modify('+1 day')->format('Ymd') : $fin->format('Ymd\THis')) : '',
                    'iso' => $ev->journee ? $debut->format('Y-m-d') : $debut->format(DATE_ATOM),
                    'isoFin' => $fin !== null ? ($ev->journee ? $fin->format('Y-m-d') : $fin->format(DATE_ATOM)) : '',
                    'j' => $debut->format('Y-m-d'),
                ];

                // Une occurrence par jour couvert : un evenement sur deux jours se voit sur les deux.
                $jour = $debut->setTime(0, 0);
                // Sur chaque jour couvert, sauf une soiree de moins de vingt-quatre heures.
                $long = $fin !== null && ($ev->journee || $fin->getTimestamp() - $debut->getTimestamp() >= 86400);
                $der  = ($long ? $fin : $debut)->setTime(0, 0);

                for ($n = 0; $jour <= $der && $n < 62; $n++, $jour = $jour->modify('+1 day')) {
                    $premier = $n === 0;
                    $occ[] = [
                        'e' => $i, 'o' => $k, 'j' => $jour->format('Y-m-d'),
                        'h' => ($premier && !$ev->journee) ? $debut->format($heure) : '',
                        'p' => $premier ? 1 : 0,
                        't' => ($premier && !$ev->journee) ? $debut->format('H:i') : '',
                    ];
                }
            }
        }

        usort($occ, static fn ($a, $b) => strcmp($a['j'] . ($a['t'] ?: '00:00'), $b['j'] . ($b['t'] ?: '00:00')));

        $passes = (string) ($el->agendaPasses ?? '0') === '1';
        $liste  = $passes ? $occ : array_values(array_filter($occ, static fn ($o) => $o['j'] >= $auj));

        // LE PROCHAIN : la premiere occurrence a venir, sinon la derniere passee.
        $prochain = null;

        foreach ($occ as $o) {
            if ($o['j'] >= $auj && $o['p']) {
                $prochain = $o;
                break;
            }
        }

        $prochain ??= end($occ) ?: null;

        // Pour chaque evenement, l'occurrence que sa fiche montre au depart.
        foreach ($evs as $ev) {
            $ev->depart = 0;

            foreach ($occ as $o) {
                if ($o['e'] === $ev->n && $o['p'] && $o['j'] >= $auj) {
                    $ev->depart = $o['o'];
                    break;
                }
            }

            $ev->quand  = $quand[$ev->n][$ev->depart]['q'];
            $ev->groupe = mb_strtolower(trim($ev->titre));
            $ev->autresDates = [];

            $ev->couleur = self::COULEURS_CARTE[$ev->cle];
            $ev->lieu    = '';

            $ev->ou = '';

            foreach ($ev->infos as $info) {
                if ($info->sorte === 'lieu') {
                    $ev->lieu = $info->texte;
                    $ev->ou   = trim($info->texte . ($info->adresse !== '' ? ', ' . $info->adresse : ''));
                    break;
                }

                // Sans lieu physique, un evenement en ligne dit « En ligne » (fichier .ics, fenetres).
                if ($info->sorte === 'enligne' && $ev->ou === '') {
                    $ev->ou = trim($info->texte . ($info->href !== '' ? ', ' . $info->href : ''));
                }
            }
        }

        /*
         * « AUSSI LE » : LES SEANCES QUI REVIENNENT sont des evenements dupliques,
         * rassembles par leur titre. On les liste dans l'ordre du calendrier.
         */
        foreach ($occ as $o) {
            if (!$o['p'] || (!$passes && $o['j'] < $auj)) {
                continue;
            }

            foreach ($evs as $ev) {
                // Une autre seance du meme titre, ou une autre date de la meme serie (calendrier .ics).
                $autre = $ev->n !== $o['e'] ? $ev->groupe === $evs[$o['e']]->groupe : $o['o'] !== $ev->depart;

                if ($autre && \count($ev->autresDates) < 8) {
                    $ev->autresDates[] = $quand[$o['e']][$o['o']]['c'];
                }
            }
        }

        $fiches = $evs;
        usort($fiches, static fn ($a, $b) => $a->dates[0][0] <=> $b->dates[0][0]);

        foreach ($fiches as $ev) {
            $ev->passe = ($ev->dates[0][1] ?? $ev->dates[0][0])->format('Y-m-d') < $auj;
        }

        $this->agendas = true;
        self::$nAgendas++;

        $vue     = \in_array($el->agendaVue ?? '', ['deux', 'mois', 'liste', 'mini'], true) ? $el->agendaVue : 'deux';
        $depart  = $vue === 'deux'
            ? (\in_array($el->agendaDepart ?? 'mois', ['jour', 'mois', 'annee', 'liste'], true) ? $el->agendaDepart : 'mois')
            : ($vue === 'mini' ? 'mois' : $vue);
        $fiche   = \in_array($el->agendaFiche ?? '', ['droite', 'gauche', 'dessous', 'popup'], true) ? $el->agendaFiche : 'droite';
        // UN CHAMP MASQUE PAR `showon` N'EST PAS ENREGISTRE : on lit donc toujours avec un defaut.
        $largeur = (string) ($el->agendaLargeur ?? '4');
        $largeur = \in_array($largeur, ['3', '4', '5', '6'], true) ? $largeur : '4';
        $premier = (int) Factory::getApplication()->getLanguage()->getFirstDay();
        $titre   = trim((string) ($el->agendaTitre ?? ''));
        [$an, $mois] = array_map('intval', explode('-', substr($auj, 0, 7)));

        // Les noms du coeur, dans l'ordre de la semaine du site.
        $cles   = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
        $courts = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
        $jours  = [];

        for ($j = 0; $j < 7; $j++) {
            $x = ($premier + $j) % 7;
            $jours[] = ['long' => Text::_($cles[$x]), 'court' => Text::_($courts[$x])];
        }

        $moisNoms = [];

        foreach (['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'] as $m) {
            $moisNoms[] = Text::_($m);
        }

        // LA LEGENDE : les couleurs nommees, dans l'ordre du reglage.
        $legende = [];

        foreach (['accent' => 'Accent', 'encre' => 'Encre', 'succes' => 'Succes', 'info' => 'Info', 'alerte' => 'Alerte', 'erreur' => 'Erreur'] as $cle => $suffixe) {
            $nom = trim((string) ($el->{'agendaNom' . $suffixe} ?? ''));

            if ($nom !== '') {
                $legende[] = (object) ['nom' => $nom, 'couleur' => self::COULEURS_CARTE[$cle]];
            }
        }

        // LES JOURS DE LA LISTE, regroupes.
        $jourListe = [];

        foreach ($liste as $o) {
            if (!isset($jourListe[$o['j']])) {
                $d = new \DateTimeImmutable($o['j'], $tz);
                $jourListe[$o['j']] = (object) [
                    'nom'  => $this->dateLangue($d, 'l'),
                    'date' => $this->dateLangue($d, Text::_('DATE_FORMAT_LC3')),
                    'occ'  => [],
                ];
            }

            $jourListe[$o['j']]->occ[] = $o;
        }

        $id = 'opus-agenda-' . self::$nAgendas;

        $donnees = [
            'id'      => $id,
            'auj'     => $auj,
            'tz'      => $tz->getName(),
            'premier' => $premier,
            'vue'     => $vue,
            'depart'  => $depart,
            'passes'  => $passes,
            'jours'   => $jours,
            'mois'    => $moisNoms,
            'occ'     => $occ,
            'quand'   => $quand,
            'ev'      => array_map(static fn ($ev) => [
                't' => $ev->titre, 'c' => $ev->couleur, 'cl' => $ev->classe, 'l' => $ev->ou, 'g' => $ev->groupe,
                'u' => $ev->lien['href'] ?? '',
            ], $evs),
            'ics'     => (string) ($el->agendaIcs ?? '1') === '1',
            'fiche'   => \in_array($el->agendaFiche ?? '', ['droite', 'gauche', 'dessous', 'popup'], true) ? $el->agendaFiche : 'droite',
            'textes'  => [
                'autres'   => Text::_('MOD_OPUS_AGENDA_JS_MORE'),
                'autre'    => Text::_('MOD_OPUS_AGENDA_JS_ONE_MORE'),
                'journee'  => Text::_('MOD_OPUS_AGENDA_ALLDAY'),
                'suite'    => Text::_('MOD_OPUS_AGENDA_CONTINUED'),
                'vide'     => Text::_('MOD_OPUS_AGENDA_EMPTY_DAY'),
                'fermer'   => Text::_('MOD_OPUS_AGENDA_CLOSE'),
                'google'   => Text::_('MOD_OPUS_AGENDA_ADD_GOOGLE'),
                'outlook'  => Text::_('MOD_OPUS_AGENDA_ADD_OUTLOOK'),
                'fichier'  => Text::_('MOD_OPUS_AGENDA_ADD_ICS'),
                'fenetre'  => Text::_('MOD_OPUS_NEW_WINDOW'),
                'aucun'    => Text::_('MOD_OPUS_AGENDA_NONE'),
                'nb'       => Text::_('MOD_OPUS_AGENDA_JS_COUNT'),
                'nbs'      => Text::_('MOD_OPUS_AGENDA_JS_COUNT_PLURAL'),
                'voirJour' => Text::_('MOD_OPUS_AGENDA_JS_SEE_DAY'),
                'nav'      => [
                    'jour'  => [Text::_('MOD_OPUS_AGENDA_PREV_DAY'), Text::_('MOD_OPUS_AGENDA_NEXT_DAY')],
                    'mois'  => [Text::_('MOD_OPUS_AGENDA_PREV'), Text::_('MOD_OPUS_AGENDA_NEXT')],
                    'annee' => [Text::_('MOD_OPUS_AGENDA_PREV_YEAR'), Text::_('MOD_OPUS_AGENDA_NEXT_YEAR')],
                ],
            ],
        ];

        return (object) [
            'id'        => $id,
            'titre'     => $titre !== '' ? $titre : Text::_('MOD_OPUS_ELEMENT_AGENDA'),
            'classes'   => trim('opus__agenda--' . $vue . ($vue !== 'mini' ? ' opus__agenda--fiche-' . $fiche . (\in_array($fiche, ['droite', 'gauche'], true) ? ' opus__agenda--l' . $largeur : '') : '') . ' ' . $el->classe),
            'fiche'     => $fiche,
            // Les fiches dans l'ordre du calendrier : c'est celui de la liste a cote de l'agenda.
            'fiches'    => $fiches,
            'vue'       => $vue,
            'depart'    => $depart,
            'periode'   => $moisNoms[$mois - 1] . ' ' . $an,
            'jours'     => $jours,
            'semaines'  => $this->grilleAgenda($an, $mois, $occ, $auj, $premier),
            'liste'     => array_values($jourListe),
            'evenements' => $evs,
            'prochain'  => $prochain,
            'auj'       => $auj,
            'jourAuj'   => $this->dateLangue(new \DateTimeImmutable($auj, $tz), Text::_('DATE_FORMAT_LC1')),
            'legende'   => $legende,
            'ics'       => $donnees['ics'],
            // Les articles portent deja leur propre schema ; la saisie et le
            // calendrier en ligne n'en ont pas d'autre que celui-ci.
            'schema'    => $source !== 'articles' ? $this->schemaAgenda($evs, $quand, $auj) : '',
            'donnees'   => json_encode($donnees, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ];
    }

    /**
     * LES EVENEMENTS POUR LES MOTEURS DE RECHERCHE (schema.org Event), les
     * prochains seulement, cinquante au plus.
     */
    private function schemaAgenda(array $evs, array $quand, string $auj): string
    {
        $liste = [];

        foreach ($evs as $ev) {
            foreach ($quand[$ev->n] as $q) {
                if ($q['j'] < $auj || \count($liste) >= 50) {
                    continue;
                }

                $e = ['@context' => 'https://schema.org', '@type' => 'Event', 'name' => $ev->titre, 'startDate' => $q['iso']];

                if ($q['isoFin'] !== '') {
                    $e['endDate'] = $q['isoFin'];
                }

                /*
                 * LE MODE DE PARTICIPATION, 4 octobre 2026 : un lieu seul, sur
                 * place ; « En ligne » seul, en ligne (VirtualLocation) ; les deux,
                 * mixte. Google lit `eventAttendanceMode` pour ranger l'evenement.
                 */
                $places   = [];
                $virtuels = [];

                foreach ($ev->infos as $info) {
                    if ($info->sorte === 'lieu' && $places === []) {
                        $places[] = ['@type' => 'Place', 'name' => $info->texte] + ($info->adresse !== '' ? ['address' => $info->adresse] : []);
                    }

                    if ($info->sorte === 'enligne' && $virtuels === []) {
                        $virtuels[] = ['@type' => 'VirtualLocation'] + ($info->href !== '' ? ['url' => $info->href] : []);
                    }

                    if ($info->sorte === 'texte' && !isset($e['description'])) {
                        $e['description'] = $info->texte;
                    }
                }

                if ($places !== [] || $virtuels !== []) {
                    $e['eventAttendanceMode'] = 'https://schema.org/' . ($virtuels === [] ? 'Offline' : ($places === [] ? 'Online' : 'Mixed')) . 'EventAttendanceMode';
                    $lieux = array_merge($places, $virtuels);
                    $e['location'] = \count($lieux) === 1 ? $lieux[0] : $lieux;
                }

                if (($ev->lien['href'] ?? '') !== '') {
                    $e['url'] = str_starts_with($ev->lien['href'], 'http') ? $ev->lien['href'] : rtrim(Uri::root(), '/') . '/' . ltrim(preg_replace('#^' . preg_quote(Uri::root(true), '#') . '#', '', $ev->lien['href']), '/');
                }

                if ($ev->image !== '') {
                    $e['image'] = str_starts_with($ev->image, 'http') ? $ev->image : rtrim(Uri::root(), '/') . '/' . ltrim(preg_replace('#^' . preg_quote(Uri::root(true), '#') . '#', '', $ev->image), '/');
                }

                $liste[] = $e;
            }
        }

        return $liste === [] ? '' : json_encode($liste, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG);
    }

    /**
     * Le contenu d'un bloc a-t-il quelque chose a montrer ?
     *
     * La mise en page pose la question avant d'ecrire le conteneur du bloc :
     * un cadre vide prend sa marge dans la page et se cherche dans
     * l'inspecteur.
     */
    public function blocRempli(object $bloc): bool
    {
        if ($bloc->type === 'ouverture') {
            return $bloc->elements !== [];
        }

        /*
         * UN ONGLET SUFFIT A REMPLIR LE BLOC, MEME SANS CONTENU, et c'est la
         * difference avec une carte : le titre d'un onglet se voit tout seul
         * dans la barre. Un onglet titre mais vide dessine donc quelque chose,
         * et le bloc doit garder sa colonne. Les onglets sans titre, eux, ont
         * deja ete ecartes a la lecture.
         */
        if ($bloc->type === 'onglets') {
            return $bloc->onglets !== [];
        }

        /*
         * UNE FRISE SANS ETAPE N'EST PAS UNE FRISE : elle ne dessinerait qu'un
         * axe nu. Les etapes vides ont deja ete ecartees a la lecture.
         */
        if ($bloc->type === 'frise') {
            return $bloc->etapes !== [];
        }

        /*
         * UNE CARTE VIDE NE COMPTE PAS. Trois cartes ajoutees et pas encore
         * remplies, c est un bloc qui ne dessinera rien : il ne doit donc pas
         * reserver sa colonne. La mise en page ecarte les memes cartes, une a
         * une ; ici on repond pour le bloc entier.
         */
        foreach ($bloc->cartes as $carte) {
            if (!empty($carte->pile)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Le niveau de titre de depart.
     *
     * Un module vit hors du contenu principal : son titre est un h2. Il
     * descend a h3 quand la page affiche deja son propre titre, pour ne pas
     * doubler le rang. Aucun niveau n'est jamais ecrit en dur dans une mise en
     * page.
     */
    public function niveauDepart(CMSApplicationInterface $app): int
    {
        $menu = $app->getMenu() ? $app->getMenu()->getActive() : null;

        if ($menu && (int) $menu->getParams()->get('show_page_heading', 0) === 1) {
            return 3;
        }

        return 2;
    }

    /**
     * La balise d'un titre, depuis le choix de l'utilisateur et le niveau de
     * depart. « Automatique » suit le contexte, un choix explicite l'emporte.
     */
    public function baliseTitre(?string $choix, int $depart): string
    {
        $choix = (string) $choix;

        if (preg_match('/^h[2-6]$/', $choix)) {
            return $choix;
        }

        return 'h' . min(6, max(2, $depart));
    }

    /**
     * La classe d'alignement d'un element.
     *
     * Une classe par valeur, jamais un style en ligne : un style en ligne ne
     * se surcharge qu'avec un `!important`, et c'est la spirale qu'on refuse.
     */
    public function classeAlignement(?string $valeur): string
    {
        switch ((string) $valeur) {
            case 'center':
                return 'opus__el--center';
            case 'end':
                return 'opus__el--end';
            default:
                return '';
        }
    }

    /**
     * Le lien d'un element : adresse, cible, et ce qu'il faut annoncer.
     *
     * Rend un tableau vide quand il n'y a pas de lien, pour que la mise en page
     * n'ait qu'un `if` a ecrire.
     *
     * NOUVEL ONGLET : `rel="noopener"` et la mention « nouvelle fenetre » sont
     * ajoutes d'office. Le RGAA exige de prevenir l'ouverture d'une nouvelle
     * fenetre, et personne ne pense a l'ecrire a la main.
     */
    public function lien(object $element, string $prefixe = ''): array
    {
        /*
         * LE PREFIXE SERT AUX BOUTONS, QUI ONT CHACUN LEUR LIEN.
         *
         * L'element porte `linkType`, `linkMenu`, `linkUrl`, `linkNewTab` ; un
         * bouton porte `button2LinkType`, `button2LinkMenu`, et ainsi de suite.
         * Une seule fonction lit les deux : trois copies de ces trente lignes
         * auraient fini par diverger, et c'est toujours celle qu'on a oubliee
         * qui garde le defaut.
         *
         * `$prefixe` vide rend donc exactement le comportement d'avant.
         */
        $champ = static function (string $nom) use ($prefixe): string {
            return $prefixe === '' ? $nom : $prefixe . ucfirst($nom);
        };

        $type = (string) ($element->{$champ('linkType')} ?? 'none');

        if ($type === 'none') {
            return [];
        }

        $href = '';

        if ($type === 'menu') {
            $itemid = (int) ($element->{$champ('linkMenu')} ?? 0);

            if ($itemid > 0) {
                $href = Route::_('index.php?Itemid=' . $itemid);
            }
        } elseif ($type === 'url') {
            $href = trim((string) ($element->{$champ('linkUrl')} ?? ''));
        } elseif ($type === 'article') {
            $href = $this->article((int) ($element->{$champ('linkArticle')} ?? 0))->href ?? '';
        }

        if ($href === '') {
            return [];
        }

        /*
         * LE NOUVEL ONGLET NE SE NOMME PAS PAREIL DES DEUX COTES : l'element
         * porte `linkNewTab`, un bouton porte `button2NewTab`, sans le mot
         * « Link ». On regarde donc les deux, plutot que d'imposer un nom au
         * manifeste pour arranger cette fonction.
         */
        $nouvelOnglet = (int) (
            $element->{$prefixe === '' ? 'linkNewTab' : $prefixe . 'NewTab'}
            ?? $element->{$champ('linkNewTab')}
            ?? 0
        ) === 1;

        return [
            'href'     => $href,
            'target'   => $nouvelOnglet ? '_blank' : '',
            'rel'      => $nouvelOnglet ? 'noopener' : '',
            'mention'  => $nouvelOnglet ? Text::_('MOD_OPUS_NEW_WINDOW') : '',
        ];
    }

    /** Les articles deja lus pendant cette page : un bouton par article ne coute qu'une requete. */
    private array $articles = [];

    /**
     * UN ARTICLE CHOISI DANS LA FENETRE DU COEUR, 4 octobre 2026.
     *
     * « Un bouton qui correspond a Lire la suite de la vue blog », Cyrille.
     * L'adresse vient de `RouteHelper::getArticleRoute`, comme celle du coeur :
     * meme element de menu, meme adresse propre. RIEN NE SORT pour un article
     * depublie, hors de ses dates, ou que le visiteur n'a pas le droit de voir :
     * un lien vers une page interdite est un lien mort.
     *
     * @return object{href: string, titre: string}|null
     */
    public function article(int $id): ?object
    {
        if ($id <= 0) {
            return null;
        }

        if (\array_key_exists($id, $this->articles)) {
            return $this->articles[$id];
        }

        $this->articles[$id] = null;

        try {
            $app = Factory::getApplication();
            $db  = Factory::getContainer()->get(DatabaseInterface::class);
            $now = Factory::getDate()->toSql();
            $q   = $db->getQuery(true)
                ->select($db->quoteName(['id', 'title', 'alias', 'catid', 'language', 'access']))
                ->from($db->quoteName('#__content'))
                ->where($db->quoteName('id') . ' = ' . $id)
                ->where($db->quoteName('state') . ' = 1')
                ->where('(' . $db->quoteName('publish_up') . ' IS NULL OR ' . $db->quoteName('publish_up') . ' <= ' . $db->quote($now) . ')')
                ->where('(' . $db->quoteName('publish_down') . ' IS NULL OR ' . $db->quoteName('publish_down') . ' > ' . $db->quote($now) . ')');
            $a = $db->setQuery($q)->loadObject();

            if ($a && \in_array((int) $a->access, $app->getIdentity()->getAuthorisedViewLevels(), true)) {
                $this->articles[$id] = (object) [
                    'href'  => Route::_(RouteHelper::getArticleRoute($a->id . ':' . $a->alias, $a->catid, $a->language)),
                    'titre' => (string) $a->title,
                ];
            }
        } catch (\Throwable $e) {
            // Pas d'article lisible : pas de lien, plutot qu'une page en erreur.
        }

        return $this->articles[$id];
    }

    /** « Lire la suite » quand le texte est vide et que le lien mene a un article. */
    private function texteParDefaut(object $ligne, string $texte): string
    {
        if ($texte !== '' || (string) ($ligne->linkType ?? '') !== 'article') {
            return $texte;
        }

        return $this->article((int) ($ligne->linkArticle ?? 0)) ? Text::_('MOD_OPUS_LINK_READ_MORE') : '';
    }

    /**
     * Les boutons d'un element, prets a poser.
     *
     * UNE LISTE, ET PLUS TROIS CHAMPS FIGES. Le manifeste portait
     * `button1Text`, `button2Text`, `button3Text` et leurs sept champs chacun
     * jusqu'au 22 septembre 2026. Trois au maximum, aucun deplacement, aucune
     * duplication : c'etait le prix d'une prudence sur l'imbrication, et
     * Cyrille a tranche l'autre sens. La liste est un sous-formulaire de plus,
     * au troisieme niveau, `blocs > elements > boutons`.
     *
     * UN BOUTON SANS LIBELLE NE SORT PAS. Ce n'est pas une correction
     * silencieuse : l'aide du champ le dit, et la carte du montage ne le
     * montre pas non plus.
     *
     * `lien()` EST APPELEE SANS PREFIXE, et c'est tout l'interet des noms
     * choisis dans le manifeste : une ligne de bouton porte `linkType`,
     * `linkMenu`, `linkUrl`, `linkNewTab`, exactement ce que la fonction
     * attend d'un element. Les trente lignes du lien ne sont ecrites qu'une
     * fois.
     *
     * @return array  Liste de boutons : libelle, variante, icones, lien.
     */
    /**
     * LES ICONES DECLAREES PAR L'ADMINISTRATEUR, nom => fichier.
     *
     * Lues une fois par rendu et gardees : les mises en page les demandent une
     * fois par bouton, et relire le parametre a chaque fois n'apprendrait rien
     * de nouveau.
     */
    private array $miennes = [];

    public function poserMesIcones($brut): void
    {
        $this->miennes = [];

        /*
         * LA MEME DONNEE ARRIVE SOUS TROIS FORMES, ET LA TROISIEME MANQUAIT
         * ICI.
         *
         * Tableau quand elle vient d'etre envoyee, objet quand elle sort du
         * Registry, CHAINE JSON quand le Registry ne l'a pas encore decodee.
         * Les deux champs d'administration lisaient bien les trois ; la page
         * publique, non. Resultat mesure le 25 septembre 2026 : le bouton
         * portait « perso:minions », la liste d'administration l'offrait, et
         * le site ne dessinait rien, sans erreur.
         */
        if (\is_string($brut)) {
            $decode = json_decode($brut);
            $brut   = $decode === null ? [] : $decode;
        }

        if (\is_object($brut)) {
            $brut = (array) $brut;
        }

        if (!\is_array($brut)) {
            return;
        }

        foreach ($brut as $ligne) {
            $ligne = (array) $ligne;

            $nom     = strtolower(preg_replace('#[^A-Za-z0-9-]#', '-', trim((string) ($ligne['nom'] ?? ''))));
            $fichier = trim((string) ($ligne['fichier'] ?? ''));

            if ($nom === '' || $nom === '-' || $fichier === '') {
                continue;
            }

            $this->miennes[$nom] = $fichier;
        }
    }

    /**
     * LE PICTOGRAMME D'UN BOUTON, ET LE SEUL ENDROIT QUI CHOISIT COMMENT.
     *
     * DEUX MECANIQUES, ET LE NOM DIT LAQUELLE. Un nom ordinaire, `i-fleche`,
     * est un symbole de la planche : on ecrit un `<use>`, et c'est ce que fait
     * le template depuis toujours. Un nom prefixe de `perso:` est un FICHIER
     * choisi par l'administrateur : on le pose en MASQUE.
     *
     * POURQUOI UN MASQUE ET PAS UNE IMAGE. Une `<img>` garde les couleurs du
     * fichier : sur un bouton plein, un dessin noir devient invisible, et sur
     * un bouton de couleur il jure. Un masque ne reprend que la FORME et la
     * remplit de `currentColor`, donc de la couleur du texte du bouton. Une
     * icone a soi se comporte alors exactement comme une icone livree.
     *
     * ON NE REMET JAMAIS LE CONTENU DU FICHIER DANS LA PAGE. Le chemin part
     * dans une `url()`, le navigateur va le chercher comme une image et n'en
     * lit que les pixels : un SVG pose en masque ne peut porter ni script ni
     * lien. C'est ce qui permet d'accepter un fichier choisi dans le
     * gestionnaire de medias sans avoir a le relire.
     *
     * @param   string  $nom  La valeur enregistree dans le champ Icone.
     *
     * @return  string  Le balisage, ou la chaine vide s'il n'y a pas d'icone.
     */
    public function picto(string $nom): string
    {
        $nom = trim($nom);

        if ($nom === '') {
            return '';
        }

        /*
         * LE PICTOGRAMME DOUBLE LE LIBELLE, IL NE LE REMPLACE JAMAIS.
         * `aria-hidden` et `focusable="false"` dans les deux cas : un lecteur
         * d'ecran lit le mot du bouton, pas le dessin.
         */
        if (strpos($nom, 'perso:') !== 0) {
            return '<svg class="i" aria-hidden="true" focusable="false"><use href="#'
                . htmlspecialchars($nom, ENT_QUOTES, 'UTF-8')
                . '"></use></svg>';
        }

        $clef = substr($nom, 6);

        /*
         * UNE ICONE SUPPRIMEE NE LAISSE PAS UN TROU. L'administrateur peut
         * retirer une ligne de l'onglet Icones alors qu'un bouton la nomme
         * encore : le bouton garde son libelle et perd son dessin, ce qui est
         * la bonne facon d'echouer.
         */
        if (!isset($this->miennes[$clef])) {
            return '';
        }

        $fichier = HTMLHelper::_('cleanImageURL', $this->miennes[$clef]);
        $url     = \is_object($fichier) ? ($fichier->url ?? '') : (string) $fichier;

        /*
         * `cleanImageURL` PEUT RENDRE VIDE : un fichier renomme ou supprime
         * depuis, un adaptateur inconnu. On retombe sur le chemin brut ampute
         * de son fragment, qui reste la meilleure reponse possible. Le meme
         * repli que dans le champ d'administration, pour que l'apercu et la
         * page publique montrent la meme chose.
         */
        if ($url === '') {
            $url = explode('#', (string) $this->miennes[$clef])[0];
        }

        if ($url === '') {
            return '';
        }

        /*
         * L'ADRESSE EST RENDUE ABSOLUE. Le gestionnaire de medias enregistre
         * un chemin relatif a la racine du site. En page publique la balise
         * `<base>` de Joomla le fait tomber juste, mais un module peut etre
         * rendu hors de ce cadre, dans un flux ou une previsualisation, et le
         * chemin y serait resolu depuis ailleurs. Le meme calcul que dans le
         * champ d'administration, ou l'absence de `<base>` sortait un 404.
         */
        if (!preg_match('#^(?:https?:)?//|^/#', $url)) {
            $url = Uri::root(true) . '/' . ltrim($url, '/');
        }

        /*
         * L'URL EST ECHAPPEE DEUX FOIS, pour deux langages. `htmlspecialchars`
         * la met a l'abri dans l'attribut `style`, et les apostrophes et
         * parentheses sont retirees avant, parce qu'elles fermeraient l'`url()`
         * du CSS, ce que l'echappement HTML ne voit pas.
         */
        $url = str_replace(["'", '"', '(', ')', "\n", "\r"], '', $url);

        return '<span class="i i--perso" aria-hidden="true" style="--opus-icone:url(\''
            . htmlspecialchars($url, ENT_QUOTES, 'UTF-8')
            . '\')"></span>';
    }

    public function boutons(object $element): array
    {
        $boutons = [];

        foreach ($this->elements($element->boutons ?? null) as $ligne) {
            $libelle = $this->texteParDefaut($ligne, trim((string) ($ligne->text ?? '')));

            if ($libelle === '') {
                continue;
            }

            $boutons[] = (object) [
                'libelle'  => $libelle,
                'variante' => $this->varianteBouton((string) ($ligne->variant ?? '')),
                'taille'   => (string) ($ligne->taille ?? '') === 'petit' ? 'petit' : '',
                'classe'   => $this->classeSaisie($ligne->classe ?? ''),
                'avant'    => (string) ($ligne->iconBefore ?? ''),
                'apres'    => (string) ($ligne->iconAfter ?? ''),
                'lien'     => $this->lien($ligne),
            ];
        }

        return $boutons;
    }

    /**
     * LE NOM DE VARIANTE QUE CORPUS HABILLE VRAIMENT.
     *
     * MESURE DU 22 SEPTEMBRE 2026, DANS LE NAVIGATEUR, SUR LE BANC. Le module
     * ecrivait `bouton--contour` et `bouton--lien`. Ces deux classes
     * n'existent nulle part dans `template.css` : les trois formats rendaient
     * donc le MEME bouton, aplat plein, et personne ne s'en etait apercu parce
     * qu'un bouton plein est plausible. Releve : fond, texte, bordure et
     * retrait identiques au pixel pour les trois valeurs.
     *
     * Corpus habille `.bouton`, `.bouton--second` et `.bouton--tertiaire` :
     * plein, contour sur fond clair, texte souligne sans cadre. Ce sont ces
     * noms-la, et c'est la regle du projet, quand Corpus nomme deja une chose
     * on reprend son nom.
     *
     * LES ANCIENNES VALEURS SONT TRADUITES, PAS JETEES. Un montage enregistre
     * avant aujourd'hui porte `contour` ou `lien` : il doit rendre ce que son
     * auteur croyait avoir choisi, pas retomber sur le format plein.
     */
    public function varianteBouton(string $valeur): string
    {
        switch ($valeur) {
            case 'second':
            case 'contour':
                return 'second';

            case 'tertiaire':
            case 'lien':
                return 'tertiaire';

            default:
                return '';
        }
    }

    /**
     * Une image du champ media du coeur, prete a poser.
     *
     * `cleanImageURL` du coeur retire le fragment `#joomlaImage://...` et rend
     * au passage la largeur et la hauteur enregistrees : les ecrire dans la
     * balise evite le decalage de la page au chargement, sans que personne ait
     * a les saisir.
     */
    /**
     * Les classes d une image, d apres ses reglages.
     *
     * TOUT PASSE PAR DES CLASSES, JAMAIS PAR DU STYLE EN LIGNE, sauf la largeur
     * maximale, qui est un nombre saisi et ne peut pas s ecrire autrement. Une
     * classe se surcharge depuis l onglet CSS personnalise du template ; un
     * style en ligne ne se surcharge qu a coups de `!important`, et la regle de
     * Corpus est qu on n en ecrit pas.
     *
     * L HABILLAGE NE DIT PAS A QUOI IL RESSEMBLE. La classe dit « habillee », et
     * c est la feuille du module qui va chercher les jetons de forme de Corpus.
     * Le module ne choisit donc jamais une epaisseur ni un rayon.
     *
     * @return string Les classes, pretes a poser, sans espace en trop.
     */
    public function habillageImage(object $el): string
    {
        $classes = ['opus__image'];

        $format = (string) ($el->imgFormat ?? '');

        // Seuls les quatre rapports connus sont acceptes : une valeur inventee
        // sortirait une classe que personne n habille.
        if (\in_array($format, ['16-9', '4-3', '1-1', '3-4'], true)) {
            $classes[] = 'opus__image--' . $format;

            if (($el->imgCadrage ?? 'cover') === 'contain') {
                $classes[] = 'opus__image--entiere';
            }
        }

        $habillage = (string) ($el->imgHabillage ?? 'habillee');

        /*
         * « Icone » EST UN RACCOURCI, PAS UN MOTEUR DE PLUS.
         *
         * « Parfois c est juste une icone », Cyrille, 23 septembre 2026. Le cas
         * se reglait deja, en deux temps : habillage nu, puis largeur limitee a
         * trois ou quatre rem. Mais le defaut « habillee » pose une bordure et
         * un angle autour d un pictogramme de 48 px, et rien ne laisse deviner
         * qu il faut deux reglages pour l enlever.
         *
         * UNE SEULE CLASSE PORTE LES DEUX : ni bordure, ni angle, et une taille
         * d icone. Le plafond de largeur, s il est demande, la surcharge, parce
         * qu il s ecrit en style et passe donc devant.
         */
        if (\in_array($habillage, ['nue', 'ronde', 'icone'], true)) {
            $classes[] = 'opus__image--' . $habillage;
        }

        if (($el->imgLargeur ?? 'pleine') === 'limitee') {
            $classes[] = 'opus__image--plafond';
        }

        return implode(' ', $classes);
    }

    public function image($champ): array
    {
        if (empty($champ)) {
            return [];
        }

        $champ = \is_string($champ) ? json_decode($champ) : (object) $champ;

        $src = trim((string) ($champ->imagefile ?? ''));

        if ($src === '') {
            return [];
        }

        $propre = HTMLHelper::cleanImageURL($src);
        $alt    = (string) ($champ->alt_text ?? '');

        return [
            'src'    => $propre->url,
            'width'  => $propre->attributes['width'] ?? 0,
            'height' => $propre->attributes['height'] ?? 0,
            // alt vide ASSUME : l'image est decorative, le lecteur d'ecran la saute.
            'alt'    => (int) ($champ->alt_empty ?? 0) === 1 ? '' : $alt,
        ];
    }

    /**
     * Le seul style en ligne d une image : son plafond de largeur.
     *
     * DEUX UNITES, ET CHACUNE A SA RAISON. Le rem suit la taille de texte du
     * visiteur : c est ce qu il faut pour une photo, qui accompagne un texte et
     * doit grandir avec lui. Le pixel ne suit rien : c est ce qu il faut pour
     * un logo ou un pictogramme, qu on pose a une taille exacte.
     *
     * LES BORNES NE CORRIGENT PLUS EN SILENCE. La premiere version ramenait a
     * 40 toute valeur hors de 6 a 90 : un plafond de 2 rem, saisi pour une
     * petite image, ressortait a 40 sans un mot. Elle se contente desormais
     * d ecarter ce qui n est pas un nombre utilisable.
     */
    public function styleImage(object $el): string
    {
        if (($el->imgLargeur ?? 'pleine') !== 'limitee') {
            return '';
        }

        $max = (int) ($el->imgMax ?? 40);
        $unite = ($el->imgMaxUnite ?? 'rem') === 'px' ? 'px' : 'rem';

        // Zero ou negatif ferait disparaitre l image ; au-dela, la valeur ne
        // plafonne plus rien et autant ne rien ecrire.
        if ($max < 1) {
            return '';
        }

        if ($unite === 'px' && $max > 2000) {
            return '';
        }

        if ($unite === 'rem' && $max > 200) {
            return '';
        }

        return ' style="max-width: ' . $max . $unite . '"';
    }

    /**
     * Pose le CSS personnalise dans l'en-tete de page.
     *
     * UN SEUL DEPOT PAR MODULE. `addStyleDeclaration` concatene, donc un meme
     * module publie deux fois ecrirait deux fois la meme feuille. Le repere
     * statique l'empeche.
     */
    public function poserCss(Registry $params, $document): void
    {
        static $poses = [];

        $css = trim((string) $params->get('customCss', ''));

        if ($css === '') {
            return;
        }

        $repere = md5($css);

        if (isset($poses[$repere])) {
            return;
        }

        $poses[$repere] = true;

        $document->addStyleDeclaration($css);
    }
}
