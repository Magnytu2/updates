<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE REPARTITEUR.
 *
 * Il prepare ce dont la mise en page a besoin, et rien de plus. Tout ce qui
 * demande une decision (quel niveau de titre, quel lien, quel element sort)
 * est dans l'assistant, pour que les fichiers de tmpl/ restent lisibles par
 * qui veut en ecrire un.
 */

namespace Joomanji\Module\Opus\Site\Dispatcher;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;
use Joomla\CMS\Language\Text;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
    use HelperFactoryAwareTrait;

    /**
     * La planche de pictogrammes a-t-elle deja ete posee dans cette page ?
     *
     * DEUX MODULES SUR LA MEME PAGE NE POSENT QU'UNE PLANCHE. Les identifiants
     * de ses symboles sont uniques par document : une seconde copie ferait
     * trente-quatre `id` en double, et un `<use>` ne saurait plus lequel viser.
     * La propriete est statique parce que la question porte sur la PAGE, pas
     * sur le module.
     */
    private static bool $planchePosee = false;

    /**
     * Les donnees remises a la mise en page.
     *
     * @return  array
     */
    protected function getLayoutData(): array
    {
        $data   = parent::getLayoutData();
        $params = $data['params'];

        /** @var \Joomanji\Module\Opus\Site\Helper\BlocsHelper $helper */
        $helper = $this->getHelperFactory()->getHelper('BlocsHelper');

        /*
         * LES ICONES DECLAREES PAR L'ADMINISTRATEUR, remises a l'assistant
         * avant qu'il ne prepare quoi que ce soit : c'est lui qui fabrique le
         * balisage d'un pictogramme, et il doit savoir lesquelles existent.
         */
        $helper->poserMesIcones($params->get('iconesPerso'));

        /*
         * L'ASSISTANT VA JUSQU'AUX MISES EN PAGE, et c'est le seul objet qui y
         * va. Il n'y decide plus rien : il n'y sert qu'a fabriquer un
         * pictogramme, ce qui demande de savoir quelles icones sont declarees,
         * une connaissance qui n'a pas a etre recopiee dans chaque gabarit.
         */
        $data['helper'] = $helper;

        // La classe racine du module : celle du montage, plus le suffixe du coeur.
        $data['racine'] = $helper->classeRacine($params, $this->module);

        /*
         * LE NIVEAU DE TITRE DE DEPART SE DECIDE UNE SEULE FOIS, ici, et se
         * transmet aux elements. Il ne doit jamais etre ecrit en dur dans une
         * mise en page : un module pose dans une page qui affiche deja son
         * titre descend d'un cran, et il n'y a jamais qu'un seul h1 par page.
         */
        $niveau = $helper->niveauDepart($data['app']);

        /*
         * LE MONTAGE : LES RANGEES, LEURS COLONNES, ET LES BLOCS DEDANS.
         *
         * Un seul appel, et tout le modele est dans l'assistant. Le fichier de
         * mise en page n'a plus qu'a parcourir : il ne sait ni comment un bloc
         * trouve sa rangee, ni qu'un bloc orphelin est abandonne, ni qu'une
         * rangee vide ne sort pas.
         */
        $data['rangees'] = $helper->montage($params, $niveau);

        $data['niveauDepart'] = $niveau;

        /*
         * UN IDENTIFIANT UNIQUE PAR MODULE PUBLIE.
         *
         * Le carrousel de Bootstrap se commande par `data-bs-target="#..."` :
         * ses fleches et ses pastilles designent leur carrousel par son
         * identifiant. Deux modules Carrousel sur la meme page avec le meme
         * identifiant, et les fleches du second piloteraient le premier, sans
         * la moindre erreur pour le signaler.
         *
         * L'identifiant du module en base est unique par definition, et il ne
         * change pas d'un affichage a l'autre : les pastilles gardent donc leur
         * cible apres un rechargement, et le cache de page ne melange rien.
         */
        $data['identifiant'] = 'opus-' . (int) $this->module->id;

        /*
         * LE CSS PERSONNALISE PART DANS L'EN-TETE, PAS DANS LE CORPS.
         *
         * `addStyleDeclaration` du document, avec un repere de dedoublonnage :
         * un meme module publie deux fois ne le sortirait qu'une seule fois.
         * Une balise `style` ecrite dans la mise en page sortirait au milieu du
         * corps de page, et autant de fois que le module est publie.
         */
        $helper->poserCss($params, $data['app']->getDocument());

        /*
         * LA FEUILLE DU MODULE.
         *
         * Enregistree puis employee, comme Corpus le fait dans son index.php.
         * Elle depend de `template.corpus` : le navigateur la recevra donc
         * APRES celle du template, ce qui evite d'avoir a gagner une bataille
         * de specificite pour trois regles.
         *
         * `assetExists` avant de declarer la dependance : sur un site qui ne
         * tourne pas sous Corpus, la feuille se charge quand meme, seule. Les
         * jetons manquants retombent alors sur les valeurs de repli ecrites
         * dans le fichier.
         */
        $data['planche'] = '';

        $wa = $data['app']->getDocument()->getWebAssetManager();

        $avecCorpus = $wa->assetExists('style', 'template.corpus');

        $dependances = $avecCorpus ? ['template.corpus'] : [];

        $wa->registerAndUseStyle('mod_opus', 'mod_opus/blocs.css', [], [], $dependances);

        /*
         * UN SEUL VOLET OUVERT A LA FOIS, avec Corpus comme sans lui.
         *
         * « Il faudrait qu'il n'y ait toujours qu'une ligne qui reste ouverte,
         * que ce soit pour Corpus ou Cassiopeia. » Cyrille, 24 septembre 2026.
         *
         * IL SE CHARGE TOUJOURS, ET C'EST LA RAISON D'ETRE DU FICHIER :
         * l'OUVERTURE d'un volet est faite par `template.js` de Corpus ou par
         * `sans-corpus.js`, mais la FERMETURE DES AUTRES n'appartient ni a l'un
         * ni a l'autre. C'est une regle du module, elle doit valoir dans les
         * deux cas, et l'ecrire en double l'aurait fait diverger au premier
         * changement.
         *
         * DEUX KILO-OCTETS, ET SEULEMENT SUR UNE PAGE QUI PORTE CE MODULE.
         */
        $wa->registerAndUseScript(
            'mod_opus.accordeon',
            'mod_opus/accordeon.js',
            [],
            ['defer' => true],
            ['core']
        );

        /*
         * LES ONGLETS SONT CEUX DE JOOMLA - 24 septembre 2026.
         *
         * `webcomponent.joomla-tab` est livre avec le coeur depuis la 4. Il
         * fabrique les boutons, pose les roles ARIA, branche les fleches du
         * clavier, retient l'onglet ouvert et sait replier la rangee en
         * accordeon sous une largeur donnee. Ecrire tout cela serait deux
         * cents lignes a nous, a maintenir, et moins sures.
         *
         * SON SCRIPT SEUL, JAMAIS SA FEUILLE. `webcomponent.joomla-tab` existe
         * en deux assets du meme nom, un script et un style : le style ecrit
         * des gris en dur, `#f5f5f5` pour la barre et `#ccc` pour le filet, qui
         * ne suivraient ni la charte du site ni le mode sombre. On demande donc
         * le type explicitement, et l'habillage est le notre.
         *
         * SEULEMENT SI LA PAGE EN A UN. Un module qui ne pose aucun onglet ne
         * doit pas charger ce script : les parametres ne suffisent pas a le
         * savoir sans relire tout le montage, mais le helper vient de le
         * parcourir et a pose son drapeau. On le lui demande.
         */
        if ($helper->aDesOnglets()) {
            $wa->useScript('webcomponent.joomla-tab');
        }

        /*
         * LE REPLI POUR UN SITE SANS CORPUS - 24 septembre 2026.
         *
         * POURQUOI IL EXISTE : Cyrille ne peut pas faire de publicite pour
         * Corpus sur le site des extensions de Joomla.org, il n'y presente que
         * ses modules. Ce module doit donc fonctionner AU MINIMUM sous
         * Cassiopeia. Ce n'est pas une option.
         *
         * DEUX FICHIERS, CHARGES SEULEMENT ICI. La feuille pose les jetons que
         * Corpus declare dans son `:root` et refait les sept classes du
         * template que les mises en page ecrivent. Le script refait les deux
         * seules choses qui sont des FONCTIONS et non des styles : l'accordeon,
         * qui sans lui ne s'ouvre pas, et la visionneuse de la galerie.
         *
         * ZERO OCTET ET ZERO RISQUE POUR LES UTILISATEURS DE CORPUS, qui sont
         * les seuls clients d'aujourd'hui : sur leur site, ces deux fichiers ne
         * sont jamais demandes. C'est ce qui rend la chose sure, et c'est
         * pourquoi le repli est un fichier a part plutot que des regles
         * ajoutees a `blocs.css`.
         *
         * LA FEUILLE DE REPLI VIENT APRES `blocs.css`, ce qui n'a l'air de rien
         * et compte : `blocs.css` lit des jetons, le repli les declare. A
         * specificite egale, c'est l'ordre qui decide, et la declaration doit
         * etre lue avant d'etre employee dans la cascade des valeurs calculees.
         */
        if (!$avecCorpus) {
            $wa->registerAndUseStyle(
                'mod_opus.sans-corpus',
                'mod_opus/sans-corpus.css',
                [],
                [],
                ['mod_opus']
            );

            $wa->registerAndUseScript(
                'mod_opus.sans-corpus',
                'mod_opus/sans-corpus.js',
                [],
                ['defer' => true],
                ['core']
            );

            Text::script('MOD_OPUS_GAL_PREV');
            Text::script('MOD_OPUS_GAL_NEXT');
            Text::script('MOD_OPUS_GAL_CLOSE');
            Text::script('MOD_OPUS_GAL_RANK');

            /*
             * LA PLANCHE DE PICTOGRAMMES, PARCE QUE PERSONNE D'AUTRE NE LA POSE.
             *
             * Les boutons ecrivent `<use href="#i-fleche">`, et un `<use>` ne
             * trouve son symbole que dans le MEME document. Sous Corpus, le
             * template a deja pose sa planche : on ne touche a rien. Sans lui,
             * il n'y a rien, et le bouton sortait avec un SVG vide, sans erreur
             * et sans icone.
             *
             * ELLE EST LUE, PAS LIEE. Un fichier `.svg` appele en `<img>` ou en
             * `<use href="fichier.svg#i-fleche">` est un AUTRE document : le
             * navigateur refuse alors d'en tirer un symbole, et les regles de
             * couleur du site ne l'atteignent pas. Le contenu doit etre dans la
             * page, donc lu ici et remis a la mise en page.
             *
             * SIX KILO-OCTETS, ET SEULEMENT POUR UN SITE SANS CORPUS. Les
             * utilisateurs de Corpus, qui sont les clients d'aujourd'hui, ne
             * paient pas un octet pour cette ligne.
             */
            if (!self::$planchePosee) {
                $fichier = JPATH_ROOT . '/media/mod_opus/icones/pictogrammes.svg';

                if (is_file($fichier)) {
                    $contenu = file_get_contents($fichier);

                    if ($contenu !== false) {
                        /*
                         * LES COMMENTAIRES PARTENT AVANT TOUT LE RESTE, ET CE
                         * N'EST PAS UNE PRECAUTION DE STYLE.
                         *
                         * Le commentaire en tete du fichier montre comment
                         * employer la planche, et cet exemple contient les
                         * lettres `<svg`. Chercher `<svg` d'abord tombait donc
                         * DANS LE COMMENTAIRE : la page publique sortait la fin
                         * du commentaire en texte, « TOUJOURS aria-hidden et
                         * focusable a false... », suivie d'un pictogramme
                         * orphelin. Vu sur le banc le 25 septembre 2026.
                         *
                         * La declaration `<?xml ...?>` part avec : au milieu
                         * d'une page HTML, c'est une instruction de traitement
                         * que le navigateur range dans le corps.
                         */
                        $propre = preg_replace('#<!--.*?-->#s', '', $contenu);
                        $debut  = strpos($propre, '<svg');

                        if ($debut !== false) {
                            $data['planche']     = substr($propre, $debut);
                            self::$planchePosee  = true;
                        }
                    }
                }
            }
        }

        return $data;
    }
}
