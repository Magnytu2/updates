<?php

/**
 * @package     plg_system_iris
 * @copyright   (C) 2026 Cyrille
 * @license     GPL v2 or later
 */

\defined('_JEXEC') or die;

use Cyrille\Plugin\System\Iris\Extension\Iris;
use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\Database\DatabaseInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Event\DispatcherInterface;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            PluginInterface::class,
            function (Container $container) {
                $plugin = new Iris(
                    $container->get(DispatcherInterface::class),
                    (array) PluginHelper::getPlugin('system', 'iris')
                );
                $plugin->setApplication(Factory::getApplication());
                $plugin->setDatabase($container->get(DatabaseInterface::class));

                return $plugin;
            }
        );
    }
};
