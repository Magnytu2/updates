/**
 * plg_system_iris — pastilles d'utilisation dans le gestionnaire de média
 */
(() => {
  'use strict';

  const boot = () => {
    const opts = window.Joomla && Joomla.getOptions ? Joomla.getOptions('plg_system_iris') : null;

    if (!opts) {
      return;
    }

    const fileCache = new Map();     // chemin fichier -> true|false|'managed'
    const folderCache = new Map();   // chemin dossier -> {used, unused, managed} | {managed:true}
    const pendingFiles = new Set();
    const pendingFolders = new Set();
    let timer = null;

    const humanSize = (bytes) => {
      const units = ['o', 'Ko', 'Mo', 'Go'];
      let i = 0;
      let value = bytes;
      while (value >= 1024 && i < units.length - 1) {
        value /= 1024;
        i += 1;
      }
      return `${value.toFixed(value >= 100 || i === 0 ? 0 : 1)} ${units[i]}`;
    };

    const currentFolder = () => {
      const raw = new URLSearchParams(window.location.search).get('path') || '';
      const idx = raw.indexOf(':/');
      const adapter = idx >= 0 ? raw.slice(0, idx) : 'local-images';
      const root = adapter.startsWith('local-') ? adapter.slice(6) : 'images';
      const folder = (idx >= 0 ? raw.slice(idx + 2) : '').replace(/^\/+|\/+$/g, '');
      return folder ? `${root}/${folder}` : root;
    };

    const nameElement = (item) => item.querySelector('.media-browser-item-info')
      || (item.cells && item.cells.length > 1 ? item.cells[1] : null)
      || item.firstElementChild;

    const itemName = (item) => {
      const info = item.querySelector('.media-browser-item-info');

      if (info) {
        return (info.getAttribute('title') || info.textContent || '').trim();
      }

      const el = nameElement(item);

      if (!el) {
        return '';
      }

      const clone = el.cloneNode(true);
      clone.querySelectorAll('.mu-inline, .mu-menu-wrap').forEach((n) => n.remove());
      return (clone.textContent || '').trim();
    };

    const pathForFile = (item) => {
      const img = item.querySelector('.media-browser-item-preview img');

      if (img && img.getAttribute('src')) {
        try {
          const url = new URL(img.getAttribute('src'), window.location.origin);
          const root = currentFolder().split('/')[0];
          const idx = url.pathname.indexOf(`/${root}/`);
          if (idx >= 0) {
            return decodeURIComponent(url.pathname.slice(idx + 1));
          }
        } catch (e) { /* ignore */ }
      }

      const name = itemName(item);
      return name ? `${currentFolder()}/${name}` : null;
    };

    /* ------------------------------ Pastilles ---------------------------- */

    const applyFileBadge = (item, state) => {
      const preview = item.querySelector('.media-browser-item-preview') || item.firstElementChild || item;
      let badge = item.querySelector('.mu-badge');

      if (state === true && !opts.badgeUsed) {
        if (badge) badge.remove();
        return;
      }

      const cls = state === true ? 'mu-used' : (state === 'managed' ? 'mu-managed' : 'mu-unused');

      if (badge && badge.classList.contains(cls)) {
        return; // déjà à jour : évite les boucles avec le MutationObserver
      }

      if (!badge) {
        badge = document.createElement('span');
        badge.className = 'mu-badge';
        preview.appendChild(badge);
      }

      badge.classList.remove('mu-used', 'mu-unused', 'mu-managed');
      badge.classList.add(cls);

      if (state === true) {
        badge.innerHTML = '<span class="icon-publish" aria-hidden="true"></span>';
        badge.title = opts.text.used;
      } else if (state === 'managed') {
        badge.innerHTML = '<span class="icon-puzzle" aria-hidden="true"></span>';
        badge.title = opts.text.managed;
      } else {
        badge.innerHTML = '<span class="icon-unpublish" aria-hidden="true"></span>';
        badge.title = opts.text.unused;
      }
    };

    const applyFileInfo = (item, info) => {
      if (info.size == null) {
        return;
      }

      const preview = item.querySelector('.media-browser-item-preview') || item.firstElementChild || item;
      const sig = `${info.size}|${info.w || ''}x${info.h || ''}`;
      let wrap = item.querySelector('.mu-info');

      if (wrap && wrap.dataset.muSig === sig) {
        return;
      }

      if (!wrap) {
        wrap = document.createElement('span');
        wrap.className = 'mu-info';
        preview.appendChild(wrap);
      }

      wrap.dataset.muSig = sig;

      let html = `<span class="mu-info-pill">${humanSize(info.size)}</span>`;

      if (info.w) {
        html += `<span class="mu-info-pill">${info.w}×${info.h} px</span>`;
      }

      wrap.innerHTML = html;
    };

    const applyFolderBadges = (item, data) => {
      const host = item.querySelector('.media-browser-item-preview')
        || item.querySelector('.media-browser-item-directory')
        || item.firstElementChild
        || item;
      const sig = (data.managed === true
        ? 'M'
        : `${data.used}/${data.unused}/${data.managed || 0}`) + `|${data.size || 0}`;

      if (item.dataset.muSig === sig) {
        return;
      }

      item.dataset.muSig = sig;

      // Poids total du dossier (bas droite)
      if (data.size != null) {
        let info = item.querySelector('.mu-info');

        if (!info) {
          info = document.createElement('span');
          info.className = 'mu-info';
          host.appendChild(info);
        }

        info.innerHTML = `<span class="mu-info-pill">${humanSize(data.size)}</span>`;
      }

      let wrap = item.querySelector('.mu-folder-badges');

      if (!wrap) {
        wrap = document.createElement('span');
        wrap.className = 'mu-folder-badges';
        host.appendChild(wrap);
      }

      if (data.managed === true) {
        wrap.innerHTML = '<span class="mu-pill mu-pill-managed"><span class="icon-puzzle" aria-hidden="true"></span></span>';
        wrap.firstElementChild.title = opts.text.folderManaged;
        return;
      }

      wrap.innerHTML = '';

      const pill = (cls, count, title) => {
        const el = document.createElement('span');
        el.className = `mu-pill ${cls}`;
        el.textContent = String(count);
        el.title = title.replace('%s', String(count));
        wrap.appendChild(el);
      };

      pill('mu-pill-used', data.used, opts.text.folderUsed);
      pill('mu-pill-unused', data.unused, opts.text.folderUnused);

      if (data.managed > 0) {
        pill('mu-pill-managed', data.managed, opts.text.folderManaged);
      }
    };

    /* ------------------------------ Requêtes ----------------------------- */

    const request = (body) => fetch(opts.ajaxUrl, {
      method: 'POST',
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      body,
    }).then((r) => {
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return r.json();
    });

    const makeBody = (task, paths) => {
      const body = new URLSearchParams();
      body.append('task', task);
      body.append(opts.token, '1');
      paths.forEach((p) => body.append('paths[]', p));
      return body;
    };

    const checkFiles = (paths) => {
      if (!paths.length) return;
      request(makeBody('check', paths))
        .then((json) => {
          const data = json && json.data && json.data[0];
          if (!data || !data.results) return;
          Object.entries(data.results).forEach(([p, state]) => {
            fileCache.set(p, state && typeof state === 'object' ? state : { used: state });
            pendingFiles.delete(p);
          });
          scan();
        })
        .catch(() => paths.forEach((p) => pendingFiles.delete(p)));
    };

    const checkFolders = (paths) => {
      if (!paths.length) return;
      request(makeBody('folders', paths))
        .then((json) => {
          const data = json && json.data && json.data[0];
          if (!data || !data.results) return;
          Object.entries(data.results).forEach(([p, counts]) => {
            folderCache.set(p, counts);
            pendingFolders.delete(p);
          });
          scan();
        })
        .catch(() => paths.forEach((p) => pendingFolders.delete(p)));
    };

    /* --------------------- Vue liste (pastilles en ligne) ----------------- */

    const cleanupStray = () => {
      document.querySelectorAll('.mu-badge, .mu-info, .mu-folder-badges').forEach((el) => {
        if (!el.closest('.media-browser-item-preview')) {
          el.remove();
        }
      });
    };

    const inlineFor = (item) => {
      const el = nameElement(item);

      if (!el) {
        return null;
      }

      let wrap = el.querySelector('.mu-inline');

      if (!wrap) {
        wrap = document.createElement('span');
        wrap.className = 'mu-inline';
        el.insertBefore(wrap, el.querySelector('.mu-menu-wrap'));
      }

      return wrap;
    };

    const inlinePill = (wrap, cls, content, title) => {
      const el = document.createElement('span');
      el.className = `mu-pill ${cls}`;
      el.innerHTML = content;
      if (title) el.title = title;
      wrap.appendChild(el);
    };

    const applyInlineFile = (item, state) => {
      const sig = `f|${state}`;

      if (item.dataset.muSig === sig) {
        return;
      }

      const wrap = inlineFor(item);

      if (!wrap) {
        return;
      }

      item.dataset.muSig = sig;
      wrap.innerHTML = '';

      if (state === true && !opts.badgeUsed) {
        return;
      }

      if (state === true) {
        inlinePill(wrap, 'mu-pill-used', '<span class="icon-publish" aria-hidden="true"></span>', opts.text.used);
      } else if (state === 'managed') {
        inlinePill(wrap, 'mu-pill-managed', '<span class="icon-puzzle" aria-hidden="true"></span>', opts.text.managed);
      } else {
        inlinePill(wrap, 'mu-pill-unused', '<span class="icon-unpublish" aria-hidden="true"></span>', opts.text.unused);
      }
    };

    const applyInlineFolder = (item, data) => {
      const sig = `d|${data.managed === true ? 'M' : `${data.used}/${data.unused}/${data.managed || 0}`}|${data.size || 0}`;

      if (item.dataset.muSig === sig) {
        return;
      }

      const wrap = inlineFor(item);

      if (!wrap) {
        return;
      }

      item.dataset.muSig = sig;
      wrap.innerHTML = '';

      if (data.managed === true) {
        inlinePill(wrap, 'mu-pill-managed', '<span class="icon-puzzle" aria-hidden="true"></span>', opts.text.folderManaged);
      } else {
        inlinePill(wrap, 'mu-pill-used', String(data.used), opts.text.folderUsed.replace('%s', String(data.used)));
        inlinePill(wrap, 'mu-pill-unused', String(data.unused), opts.text.folderUnused.replace('%s', String(data.unused)));

        if (data.managed > 0) {
          inlinePill(wrap, 'mu-pill-managed', String(data.managed), opts.text.folderManaged);
        }
      }

      if (data.size != null) {
        inlinePill(wrap, 'mu-pill-size', humanSize(data.size), '');
      }
    };

    const closeMenus = (except) => {
      document.querySelectorAll('.mu-menu.mu-open').forEach((m) => {
        if (m !== except) {
          m.classList.remove('mu-open');
        }
      });
    };

    const ensureInlineActions = (item, name) => {
      const el = nameElement(item);

      if (!el || el.querySelector('.mu-menu-wrap')) {
        return;
      }

      const relPath = `${currentFolder()}/${name}`;
      const siteRoot = `${window.location.origin}${window.location.pathname.replace(/\/administrator\/.*$/, '/')}`;
      const fileUrl = siteRoot + relPath.split('/').map(encodeURIComponent).join('/');

      const raw = new URLSearchParams(window.location.search).get('path') || 'local-images:/';
      const sep = raw.indexOf(':/');
      const adapter = sep >= 0 ? raw.slice(0, sep) : 'local-images';
      const folderPart = (sep >= 0 ? raw.slice(sep + 2) : '').replace(/^\/+|\/+$/g, '');
      const adapterPath = `${adapter}:/${folderPart ? `${folderPart}/` : ''}${name}`;
      const cm = (window.Joomla && Joomla.getOptions ? Joomla.getOptions('com_media') : null) || {};
      const csrf = ((window.Joomla && Joomla.getOptions ? Joomla.getOptions('csrf.token') : '') || opts.token);

      const menu = document.createElement('span');
      menu.className = 'mu-menu';
      menu.addEventListener('click', (e) => e.stopPropagation());

      const addLink = (label, href, attrs = {}) => {
        const a = document.createElement('a');
        a.href = href;
        a.textContent = label;
        Object.entries(attrs).forEach(([k, v]) => a.setAttribute(k, v));
        menu.appendChild(a);
        return a;
      };

      const addAction = (label, handler) => {
        const a = document.createElement('a');
        a.href = '#';
        a.textContent = label;
        a.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          handler(a);
        });
        menu.appendChild(a);
        return a;
      };

      // Mêmes appels que l'application média native (task=api.files)
      const apiCall = (method, body) => {
        if (!cm.apiBaseUrl || !csrf) {
          return Promise.reject(new Error('api'));
        }

        return fetch(`${cm.apiBaseUrl}&task=api.files&path=${encodeURIComponent(adapterPath)}`, {
          method,
          headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
          body: JSON.stringify({ [csrf]: '1', ...body }),
        }).then((r) => {
          if (!r.ok) throw new Error(`HTTP ${r.status}`);
          return r;
        });
      };

      addLink(opts.text.preview, fileUrl, { target: '_blank', rel: 'noopener' });
      addLink(opts.text.download, fileUrl, { download: '' });

      addAction(opts.text.getLink, (a) => {
        const done = () => {
          const original = a.textContent;
          a.textContent = opts.text.linkCopied;
          setTimeout(() => { a.textContent = original; }, 1500);
        };

        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(fileUrl).then(done, () => window.prompt(opts.text.getLink, fileUrl));
        } else {
          window.prompt(opts.text.getLink, fileUrl);
        }
      });

      if (cm.canEdit !== false) {
        addAction(opts.text.rename, () => {
          const dot = name.lastIndexOf('.');
          const base = dot > 0 ? name.slice(0, dot) : name;
          const ext = dot > 0 ? name.slice(dot) : '';
          const answer = window.prompt(opts.text.renamePrompt, base);

          if (!answer || answer === base) {
            return;
          }

          const newPath = `${adapter}:/${folderPart ? `${folderPart}/` : ''}${answer}${ext}`;

          apiCall('PUT', { newPath })
            .then(() => window.location.reload())
            .catch(() => window.alert(opts.text.error));
        });

        // Éditeur d'images de Joomla (recadrer, redimensionner, pivoter)
        if (/\.(jpe?g|png|webp)$/i.test(name)) {
          const base = cm.editViewUrl || 'index.php?option=com_media&view=file';
          addLink(opts.text.edit, `${base}${base.includes('?') ? '&' : '?'}path=${encodeURIComponent(adapterPath)}`);
        }
      }

      if (cm.canDelete !== false) {
        const del = addAction(opts.text.remove, () => {
          if (!window.confirm(opts.text.deleteConfirm.replace('%s', name))) {
            return;
          }

          apiCall('DELETE', {})
            .then(() => window.location.reload())
            .catch(() => window.alert(opts.text.error));
        });
        del.classList.add('mu-danger');
      }

      const wrapEl = document.createElement('span');
      wrapEl.className = 'mu-menu-wrap';

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'mu-menu-btn';
      btn.title = opts.text.actions;
      btn.innerHTML = '<span class="icon-ellipsis-v" aria-hidden="true"></span>';

      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        closeMenus(menu);
        menu.classList.toggle('mu-open');
      });

      wrapEl.appendChild(btn);
      wrapEl.appendChild(menu);
      el.appendChild(wrapEl);
    };

    const scan = () => {
      cleanupStray();

      const needFiles = [];
      const needFolders = [];

      document.querySelectorAll('.media-browser-item').forEach((item) => {
        const grid = !!item.querySelector('.media-browser-item-preview');
        const name = itemName(item);
        const isDir = item.querySelector('.media-browser-item-directory')
          ? true
          : (!grid && name !== '' && !/\.[a-z0-9]{2,5}$/i.test(name));

        if (isDir) {
          if (!name) return;
          const path = `${currentFolder()}/${name}`;

          if (folderCache.has(path)) {
            const data = folderCache.get(path);
            if (grid) {
              applyFolderBadges(item, data);
            } else {
              applyInlineFolder(item, data);
            }
          } else if (!pendingFolders.has(path)) {
            pendingFolders.add(path);
            needFolders.push(path);
          }
          return;
        }

        if (!grid && name) {
          ensureInlineActions(item, name);
        }

        const path = grid ? pathForFile(item) : (name ? `${currentFolder()}/${name}` : null);

        if (!path) return;

        if (fileCache.has(path)) {
          const info = fileCache.get(path);
          if (grid) {
            applyFileBadge(item, info.used);
            applyFileInfo(item, info);
          } else {
            applyInlineFile(item, info.used);
          }
        } else if (!pendingFiles.has(path)) {
          pendingFiles.add(path);
          needFiles.push(path);
        }
      });

      for (let i = 0; i < needFiles.length; i += 100) {
        checkFiles(needFiles.slice(i, i + 100));
      }
      for (let i = 0; i < needFolders.length; i += 30) {
        checkFolders(needFolders.slice(i, i + 30));
      }
    };

    /* ------------------------------ Rapport ------------------------------ */

    const escapeHtml = (s) => s.replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));

    const showReport = () => {
      let overlay = document.querySelector('.mu-overlay');
      if (overlay) overlay.remove();

      overlay = document.createElement('div');
      overlay.className = 'mu-overlay';
      overlay.innerHTML = `
        <div class="mu-modal" role="dialog" aria-modal="true">
          <div class="mu-modal-header">
            <strong>${escapeHtml(opts.text.reportTitle)}</strong>
            <button type="button" class="mu-close" aria-label="${escapeHtml(opts.text.close)}">&times;</button>
          </div>
          <div class="mu-modal-body"><p>${escapeHtml(opts.text.loading)}</p></div>
        </div>`;
      document.body.appendChild(overlay);

      const close = () => overlay.remove();
      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
      overlay.querySelector('.mu-close').addEventListener('click', close);

      const body = makeBody('report', []);
      body.append('refresh', '1');

      request(body)
        .then((json) => {
          const data = json && json.data && json.data[0];
          const target = overlay.querySelector('.mu-modal-body');

          if (!data || !Array.isArray(data.files)) {
            target.innerHTML = `<p>${escapeHtml(opts.text.error)}</p>`;
            return;
          }

          const summary = opts.text.summary
            .replace('%1', String(data.unusedCount))
            .replace('%2', String(data.totalCount))
            .replace('%3', humanSize(data.unusedSize));

          const managedLine = data.managedCount > 0
            ? `<p class="mu-managed-line">${escapeHtml(opts.text.summaryManaged
                .replace('%1', String(data.managedCount))
                .replace('%2', humanSize(data.managedSize)))}</p>`
            : '';

          if (!data.files.length) {
            target.innerHTML = `<p>${escapeHtml(opts.text.noUnused)}</p>${managedLine}`;
            return;
          }

          const rows = data.files.map((f) => `
            <tr><td>${escapeHtml(f.path)}</td>
            <td class="mu-size">${humanSize(f.size)}</td></tr>`).join('');

          target.innerHTML = `
            <p class="mu-summary">${escapeHtml(summary)}</p>
            ${managedLine}
            <p class="mu-caveat">${escapeHtml(opts.text.caveat)}</p>
            <div class="mu-table-wrap">
              <table>
                <thead><tr><th>${escapeHtml(opts.text.file)}</th><th>${escapeHtml(opts.text.size)}</th></tr></thead>
                <tbody>${rows}</tbody>
              </table>
            </div>
            <div class="mu-actions">
              <button type="button" class="btn btn-primary mu-csv">${escapeHtml(opts.text.csv)}</button>
            </div>`;

          target.querySelector('.mu-csv').addEventListener('click', () => {
            const csv = ['"fichier";"octets"']
              .concat(data.files.map((f) => `"${f.path.replace(/"/g, '""')}";${f.size}`))
              .join('\r\n');
            const blob = new Blob([`﻿${csv}`], { type: 'text/csv;charset=utf-8' });
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'fichiers-inutilises.csv';
            a.click();
            URL.revokeObjectURL(a.href);
          });

          // Le rapport vient de reconstruire l'index : on invalide les caches locaux
          fileCache.clear();
          folderCache.clear();
          document.querySelectorAll('[data-mu-sig]').forEach((el) => delete el.dataset.muSig);
          scan();
        })
        .catch(() => {
          overlay.querySelector('.mu-modal-body').innerHTML = `<p>${escapeHtml(opts.text.error)}</p>`;
        });
    };

    const addReportButton = () => {
      if (document.querySelector('.mu-report-btn')) return;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'mu-report-btn';
      btn.innerHTML = `<span class="icon-list" aria-hidden="true"></span> ${escapeHtml(opts.text.reportBtn)}`;
      btn.addEventListener('click', showReport);
      document.body.appendChild(btn);
    };

    /* ------------------------------ Démarrage ---------------------------- */

    const isOurs = (node) => node.classList
      && (node.classList.contains('mu-badge')
        || node.classList.contains('mu-folder-badges')
        || node.classList.contains('mu-pill')
        || node.classList.contains('mu-info')
        || node.classList.contains('mu-info-pill')
        || node.classList.contains('mu-inline')
        || node.classList.contains('mu-menu-wrap')
        || node.classList.contains('mu-menu'));

    const observer = new MutationObserver((mutations) => {
      const relevant = mutations.some((m) => !isOurs(m.target)
        && !(m.addedNodes.length && [...m.addedNodes].every((n) => isOurs(n))));
      if (!relevant) return;
      clearTimeout(timer);
      timer = setTimeout(scan, 300);
    });

    document.addEventListener('click', () => closeMenus());
    observer.observe(document.body, { childList: true, subtree: true });
    addReportButton();
    scan();
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
