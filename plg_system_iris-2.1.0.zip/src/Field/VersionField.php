<?php

/**
 * Iris — Champ d'affichage de la version installée (lecture seule).
 * La version est lue dans le MANIFESTE enregistré par Joomla à l'installation
 * (source unique : le <version> du fichier iris.xml). La constante Iris::VERSION
 * ne sert que de secours — plus aucune valeur à maintenir en double.
 *
 * @copyright (C) 2026 Cyrille
 * @license   GNU General Public License version 2 or later
 */

namespace Cyrille\Plugin\System\Iris\Field;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormField;
use Joomla\Database\DatabaseInterface;
use Cyrille\Plugin\System\Iris\Extension\Iris;

class VersionField extends FormField
{
    protected $type = 'Version';

    protected function getInput()
    {
        return '<span class="badge bg-info">Iris — version installée : '
            . htmlspecialchars($this->installedVersion(), ENT_QUOTES, 'UTF-8')
            . '</span>';
    }

    private function installedVersion(): string
    {
        try {
            $db    = Factory::getContainer()->get(DatabaseInterface::class);
            $cache = $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('manifest_cache'))
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                    ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('iris'))
            )->loadResult();

            $manifest = json_decode((string) $cache, true) ?: [];
            $version  = (string) ($manifest['version'] ?? '');

            return $version !== '' ? $version : Iris::VERSION;
        } catch (\Throwable $e) {
            return Iris::VERSION;
        }
    }
}
