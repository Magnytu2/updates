<?php

/**
 * @package     Opus
 * @copyright   Copyright (C) 2026 joomanji.eu
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE PAQUET ALLUME SES PLUGINS ET ECRIT LA NOTE DES BLOCS.
 *
 * Joomla installe un plugin eteint. Sans ceci, « Opus : poser un bloc »
 * n'apparaissait nulle part apres l'installation (banc, 10 octobre 2026).
 * Un plugin n'est allume qu'a sa premiere arrivee : une mise a jour respecte
 * le choix de qui l'aurait eteint. La premiere arrivee se lit dans la base,
 * avant l'installation, plugin par plugin : le plugin de contenu, nouveau en
 * 1.5.627, s'allume donc aussi lors d'une mise a jour du paquet. (En 1.5.627,
 * lu par la version du paquet, il restait eteint sur le banc.)
 *
 * A chaque installation ou mise a jour, la note de tous les blocs Opus est
 * recalculee (« Article 3 : Titre », lu dans la liste des modules).
 *
 * DEPUIS 1.5.654 (16 octobre 2026) :
 *  - VERROU : installation et mise a jour refusees sur un Joomla plus ancien
 *    que 6.2.0 (CLAUDE.md commun, § 10, « Quelles versions de Joomla nous
 *    suivons »). Le site garde intacte la version d'Opus qu'il avait. La
 *    desinstallation reste libre ;
 *  - PASSAGE DU MODULE SEUL AU PAQUET : le serveur de mises a jour est celui
 *    du paquet (pkg_opus.xml). La fiche de l'ancien serveur du module seul
 *    (mod_opus.xml), qui reste attachee a mod_opus sur un site qui avait le
 *    module seul, est retiree en postflight. Sinon Joomla proposerait deux
 *    mises a jour pour la meme chose.
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\Installer;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;

// Joomla n'emploie l'objet rendu que s'il declare InstallerScriptInterface ;
// sans elle, il cherche une classe pkg_opusInstallerScript et ne lance rien
// (1.5.627 : ni allumage ni note sur le banc). Corrige en 1.5.630.
return new class () implements InstallerScriptInterface {
    public function install(InstallerAdapter $parent): bool
    {
        return true;
    }

    public function update(InstallerAdapter $parent): bool
    {
        return true;
    }

    public function uninstall(InstallerAdapter $parent): bool
    {
        return true;
    }

    /** Les groupes dont le plugin Opus n'existait pas encore avant ce paquet. */
    private array $nouveaux = [];

    /** La version de Joomla en dessous de laquelle Opus refuse de s'installer. */
    private const JOOMLA_MINIMUM = '6.2.0';

    /** L'adresse du serveur du module seul, abandonnee pour celle du paquet. */
    private const ANCIEN_SERVEUR = 'https://magnytu2.github.io/updates/mod_opus.xml';

    public function preflight(string $type, InstallerAdapter $parent): bool
    {
        if ($type !== 'uninstall' && version_compare(JVERSION, self::JOOMLA_MINIMUM, '<')) {
            $this->refuser($parent);

            return false;
        }

        $db = Factory::getContainer()->get(DatabaseInterface::class);

        foreach (['editors-xtd', 'system'] as $groupe) {
            $query = $db->getQuery(true)
                ->select('COUNT(*)')
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                ->where($db->quoteName('folder') . ' = ' . $db->quote($groupe))
                ->where($db->quoteName('element') . ' = ' . $db->quote('opus'));

            if (!(int) $db->setQuery($query)->loadResult()) {
                $this->nouveaux[] = $groupe;
            }
        }

        return true;
    }

    public function postflight(string $type, InstallerAdapter $parent): bool
    {
        $db = Factory::getContainer()->get(DatabaseInterface::class);

        foreach ($this->nouveaux as $groupe) {
            $this->allumer($db, $groupe);
        }

        $this->ancienContenu($db);

        if ($type !== 'uninstall') {
            try {
                $this->ancienServeur($db);
            } catch (\Throwable $e) {
                // Au pire, le site voit encore l'ancienne adresse : sans danger.
            }
        }

        $classe = 'Joomanji\\Plugin\\System\\Opus\\Extension\\Opus';
        $source = JPATH_PLUGINS . '/system/opus/src/Extension/Opus.php';

        if (!class_exists($classe) && is_file($source)) {
            require_once $source;
        }

        if (class_exists($classe)) {
            try {
                $classe::tous($db);
            } catch (\Throwable $e) {
                // La note n'est qu'une aide : l'installation ne doit pas echouer pour elle.
                Factory::getApplication()->enqueueMessage('Opus, note des blocs : ' . $e->getMessage(), 'warning');
            }
        } else {
            Factory::getApplication()->enqueueMessage('Opus, note des blocs : plugin de contenu introuvable', 'warning');
        }

        return true;
    }

    /**
     * LE VERROU : un message clair, dans la langue du site, puis le refus.
     * Le fichier de langue du paquet n'est pas encore installe : on le lit
     * dans le paquet en cours d'installation. Un message de secours en
     * francais prend le relais si la clef reste brute.
     */
    private function refuser(InstallerAdapter $parent): void
    {
        $version = (string) ($parent->getManifest()->version ?? '');
        $cle     = 'PKG_OPUS_ERREUR_JOOMLA_TROP_ANCIEN';
        $message = '';

        try {
            $app    = Factory::getApplication();
            $source = $parent->getParent()->getPath('source');

            if ($source) {
                $app->getLanguage()->load('pkg_opus.sys', $source, null, false, true);
            }

            $message = Text::sprintf($cle, $version);

            if ($message === '' || strpos($message, $cle) === 0) {
                $message = '';
            }

            if ($message === '') {
                $message = sprintf("Opus %s demande Joomla 6.2 ou plus récent. Mettez d'abord Joomla à jour.", $version);
            }

            $app->enqueueMessage($message, 'error');
        } catch (\Throwable $e) {
            // Sans application, le refus suffit.
        }
    }

    /**
     * L'ANCIEN SERVEUR DU MODULE SEUL (mod_opus.xml), retire d'un site qui
     * passe au paquet : la fiche, ses liens a des extensions et les mises a
     * jour deja trouvees par elle. Rien ne se passe sur un site qui ne l'a
     * pas. Le serveur du paquet est pose par Joomla apres ce postflight.
     */
    private function ancienServeur(DatabaseInterface $db): void
    {
        $adresse = self::ANCIEN_SERVEUR;
        $query   = $db->getQuery(true)
            ->select($db->quoteName('update_site_id'))
            ->from($db->quoteName('#__update_sites'))
            ->where($db->quoteName('location') . ' = :adresse')
            ->bind(':adresse', $adresse);
        $sites = array_map('intval', $db->setQuery($query)->loadColumn());

        foreach ($sites as $site) {
            foreach (['#__update_sites_extensions', '#__updates', '#__update_sites'] as $table) {
                $query = $db->getQuery(true)
                    ->delete($db->quoteName($table))
                    ->where($db->quoteName('update_site_id') . ' = :site')
                    ->bind(':site', $site, ParameterType::INTEGER);
                $db->setQuery($query)->execute();
            }
        }
    }

    /**
     * L'ANCIEN PLUGIN DE CONTENU (1.5.627 a 637) est remplace par le plugin
     * systeme : il est desinstalle. Au pire, s'il resiste, il est eteint,
     * pour ne pas travailler deux fois.
     */
    private function ancienContenu(DatabaseInterface $db): void
    {
        $query = $db->getQuery(true)
            ->select($db->quoteName('extension_id'))
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote('content'))
            ->where($db->quoteName('element') . ' = ' . $db->quote('opus'));

        $id = (int) $db->setQuery($query)->loadResult();

        if (!$id) {
            return;
        }

        try {
            // Hors du paquet d'abord : Joomla refuse de desinstaller seul un
            // element qui appartient encore a un paquet.
            $db->setQuery($db->getQuery(true)
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('package_id') . ' = 0')
                ->set($db->quoteName('enabled') . ' = 0')
                ->where($db->quoteName('extension_id') . ' = ' . $id))->execute();

            $installeur = new Installer();
            $installeur->setDatabase($db);
            $installeur->uninstall('plugin', $id);
        } catch (\Throwable $e) {
            // Il reste eteint : sans effet.
        }
    }

    private function allumer(DatabaseInterface $db, string $groupe): void
    {
        $query = $db->getQuery(true)
            ->update($db->quoteName('#__extensions'))
            ->set($db->quoteName('enabled') . ' = 1')
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote($groupe))
            ->where($db->quoteName('element') . ' = ' . $db->quote('opus'));

        $db->setQuery($query)->execute();
    }
};
