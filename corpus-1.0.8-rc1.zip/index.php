<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * REECRIT le 31 juillet 2026 depuis maquettes/front-corpus.html.
 *
 * Le balisage d'origine — .navbar, .navbar-brand, .sidebar-inner, les
 * classes de rangee Bootstrap — a ete remplace par celui de la maquette. Les
 * 21 positions de module et les quatre zones du helper sont conservees ; ce
 * sont les CLASSES qui changent, pas les points d'insertion.
 *
 * Consequence assumee : les reglages de Layout qui ne pilotaient qu'une classe
 * Bootstrap n'ont plus de cible. Ils sont a retirer du manifeste.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

/** @var Joomla\CMS\Document\HtmlDocument $this */

$helper = require __DIR__ . '/helper.php';
$helper->init($this);

$app    = Factory::getApplication();
$option = $app->getInput()->getCmd('option', '');

// Emplacement des assets du template, installes par l'element <media> du manifeste.
// Le gestionnaire d'assets prefixe lui-meme la racine du site : l'URI ne doit
// donc comporter ni slash initial, ni $this->baseurl, sous peine de produire
// une adresse en // que le navigateur interprete comme un nom de domaine.
$mediaPath = '/media/templates/site/' . $this->template;
$mediaUrl  = 'media/templates/site/' . $this->template;

// LES FICHIERS LIVRES SE LISENT AVEC UN REPLI SUR LE PARENT — 6 aout 2026.
//
// Le dossier media d'un template enfant est cree VIDE par Joomla : rien n'y
// est copie. Mesure faite a l'ecran sur un enfant reel, en Joomla 6.1, avant
// d'ecrire une ligne — la feuille de l'enfant repondait 404, celle du parent
// 200. Un site sous un style enfant n'avait ni feuille ni script.
//
// `$mediaUrl` sert encore a ECRIRE et a diagnostiquer ; tout ce qui se LIT
// passe par `$fichier()`, qui cherche chez l'enfant puis chez le parent.
$fichier = function ($relatif) use ($helper) {
	return $helper->getMediaFichier($relatif);
};

$wa = $this->getWebAssetManager();

// Bootstrap 5, fourni par Joomla : rien n'est embarque dans le template.
// Il reste charge parce que des composants du coeur en dependent encore ; la
// feuille de Corpus passe apres lui et doit GAGNER sur .btn, .card et .alert.
// C'est a verifier dans l'inspecteur, pas a presumer.
$wa->registerAndUseStyle('corpus.bootstrap', 'media/vendor/bootstrap/css/bootstrap.min.css');

// FontAwesome a ete retire le 31 juillet 2026 : 70 ko pour quinze signes, dont
// aucun ne convenait. Le front utilise des pictogrammes SVG dessines, poses par
// html/layouts/corpus/pictogrammes.php, comme le back-office l'a fait avec
// admin/field/legend.php.
$wa->registerAndUseStyle('template.corpus', $fichier('css/template-j4.css'), [], [], ['corpus.bootstrap']);
$wa->registerAndUseScript('template.corpus', $fichier('js/template.js'), [], ['defer' => true], ['core']);

/*
 * LES POLICES A CHARGER — 2 aout 2026.
 *
 * On ne charge QUE ce qui est reellement affecte au texte ou aux titres. Le
 * defaut ne charge rien : c'est tout l'interet de la pile systeme.
 *
 * LA SOURCE N'EST PAS UN REGLAGE GLOBAL, et la premiere version se trompait
 * la-dessus : elle ne permettait pas la pile systeme pour le texte ET Roboto
 * pour les titres, qui est le cas le plus courant. La source est une propriete
 * de CHAQUE police ; on regarde donc les deux affectations.
 */
$corpusPolices = trim((string) $this->params->get('typoTexte', '') . ' '
    . (string) $this->params->get('typoTitres', ''));

// Roboto vit dans `media/vendor/` de Joomla, pas chez nous : notre feuille ne
// fait que declarer trois @font-face qui pointent dessus.
if (str_contains($corpusPolices, 'Roboto,')) {
    $wa->registerAndUseStyle('corpus.roboto', $fichier('css/roboto.css'), [], [], ['template.corpus']);
}

/*
 * UNE POLICE EXTERNE EST UNE REQUETE VERS UN TIERS, faite par le navigateur du
 * VISITEUR, qui lui transmet son adresse IP. C'est le choix de l'administrateur,
 * pas le notre : on la charge parce qu'il l'a demande, et le champ le lui dit
 * en toutes lettres.
 *
 * Elle n'est chargee que si elle SERT : une URL saisie puis abandonnee ne doit
 * pas continuer a peser sur chaque page.
 *
 * `filter_var` refuse tout ce qui n'est pas une URL — sans ce controle, la
 * valeur partirait telle quelle dans un attribut `href`.
 */
$corpusUrlPolice = trim((string) $this->params->get('typoUrl', ''));

if ($corpusUrlPolice !== ''
    && str_contains($corpusPolices, 'var(--police-externe)')
    && filter_var($corpusUrlPolice, FILTER_VALIDATE_URL)) {
    $wa->registerAndUseStyle('corpus.police-externe', $corpusUrlPolice, [], [], ['template.corpus']);
}

// Feuille de style personnelle, si elle a ete deposee par l'utilisateur.
if (is_file(JPATH_ROOT . '/' . $fichier('css/custom.css'))) {
    $wa->registerAndUseStyle('corpus.custom', $fichier('css/custom.css'), [], [], ['template.corpus']);
}

// Repartition des colonnes.
//
// C'est le HELPER qui calcule les largeurs, pas nous : il lit les reglages
// layoutWidth_col_1 et layoutWidth_col_2, verifie qu'un module est bien
// publie dans la colonne, deduit la largeur du contenu, et repasse a 12 si le
// reste devient trop etroit. Toute cette logique existe deja et fonctionne.
//
// Il l'exprime en classes Bootstrap — `col-lg-4`. On en extrait le nombre et
// on le traduit dans notre grille. La premiere version de ce fichier deduisait
// la repartition du seul NOMBRE de colonnes remplies : le reglage de largeur
// n'avait alors aucun effet, ce que Cyrille a vu tout de suite en le passant
// a 4 sans rien voir changer.
$corpusColonne = static function ($classe, $defaut) {
    return preg_match('/col-lg-(\d+)/', (string) $classe, $m)
        ? 'colonne-' . (int) $m[1]
        : $defaut;
};

$corpusCol1 = $helper->has('col1-class');
$corpusCol2 = $helper->has('col2-class');

$corpusMain  = $corpusColonne($helper->get('main-class'), 'colonne-12');
$corpusCote1 = $corpusColonne($helper->get('col1-class'), 'colonne-3');
$corpusCote2 = $corpusColonne($helper->get('col2-class'), 'colonne-3');

// Contenu a droite : la grille place les elements dans l'ordre du document,
// on deplace donc le contenu en dernier. `order` sur une grille ne change que
// l'ordre VISUEL — l'ordre de lecture et de tabulation suit le document, ce
// qui est exactement ce qu'on veut : le contenu reste lu en premier.
$corpusOrdreMain = str_contains((string) $helper->get('main-class'), 'order-lg-last')
    ? ' corpus-ordre-dernier'
    : '';

$corpusNom    = $helper->siteName();
$corpusSlogan = $helper->siteSlogan();
$corpusLogo   = trim((string) $helper->getParam('styleLogoImage'));
$corpusClasse = $corpusLogo !== '' ? 'marque--image' : 'marque--texte';
?>
<!DOCTYPE html>
<?php
/*
 * LA VARIANTE DE FORME, posee sur <html> comme le theme.
 *
 * Meme mecanique que `data-theme`, et pour la meme raison : un attribut sur la
 * racine, des jetons redefinis dessous, aucune regle a battre. Voir
 * media/scss/_variantes.scss.
 *
 * Vide par defaut — le socle s'applique. La valeur vient du style de template,
 * ce qui la rend assignable par entree de menu : une page peut porter une
 * variante et pas les autres, sans deuxieme template.
 *
 * `data-theme="clair"` reste ecrit en dur : template.js le corrige des le
 * chargement selon le choix memorise. Ecrire « clair » plutot que rien evite
 * le clignotement blanc chez un usager en mode sombre.
 */
$corpusVariante = trim((string) $this->params->get('styleVariante', ''));

/*
 * LE THEME D'UNE ZONE — Layout → En-tete, Navigation, Pied.
 *
 * Un pied sombre sur un site clair, une barre de navigation sombre au-dessus
 * d'un contenu clair : les deux motifs les plus courants du web. La classe est
 * la MEME que celle des bandes de modules — le mecanisme repose les jetons du
 * theme sur la portee, sans regarder de quel element il s'agit.
 *
 * Vide, la zone suit la page et le choix du visiteur.
 *
 * La valeur vient d'une liste fermee du manifeste, mais on ne le PRESUME pas :
 * elle arrive de la base, et un style importe d'ailleurs pourrait porter
 * n'importe quoi dans un attribut de classe. On n'ecrit que ce qu'on reconnait.
 */
$corpusParams = $this->params;

// `static` et une capture explicite : une fermeture declaree ici herite de
// `$this`, mais s'en remettre a ce lien implicite dans un fichier de template
// est fragile. On passe ce dont on a besoin, et rien d'autre.
$corpusTheme = static function (string $zone) use ($corpusParams) {
	$valeur = (string) $corpusParams->get('layoutTheme_' . $zone, '');

	return in_array($valeur, ['section--sombre', 'section--clair'], true)
		? ' ' . $valeur
		: '';
};

/*
 * LES ZONES EPINGLEES.
 *
 * `layoutSticky_header` et `layoutSticky_nav` existaient depuis le portage et
 * NE FAISAIENT RIEN : le comportement vivait dans le balisage de JA Simpli, et
 * la reecriture d'index.php du 31 juillet 2026 ne l'a pas repris. Cocher la
 * case ne produisait aucun effet, et rien ne le signalait.
 *
 * La feuille sait desormais epingler, template.js mesure les hauteurs. Ici on
 * ne fait que poser la classe.
 */
/*
 * LE FOND D'UNE ZONE — memes valeurs que pour une bande de modules.
 *
 * La classe n'ecrit qu'un jeton, `--fond-zone` ; c'est la feuille qui decide
 * de ce que chaque surface en fait. Voir _mise-en-page.scss.
 */
$corpusFond = static function (string $zone) use ($corpusParams) {
	$valeur = (string) $corpusParams->get('layoutFond_' . $zone, '');

	return in_array($valeur, ['section--alt', 'section--teinte'], true)
		? ' ' . $valeur
		: '';
};

$corpusEpingle = static function (string $zone, string $classe) use ($corpusParams) {
	return (string) $corpusParams->get('layoutSticky_' . $zone, '0') === '1'
		? ' ' . $classe
		: '';
};

/*
 * LES REGLAGES D'ACCESSIBILITE DE L'UTILISATEUR — 4 aout 2026.
 *
 * Joomla offre quatre cases dans le profil de chaque utilisateur : monochrome,
 * contraste eleve, surligner les liens, agrandir le texte. L'interface
 * previent que ce sont « des reglages disponibles uniquement dans les
 * templates PRIS EN CHARGE, par exemple Atum ».
 *
 * CORPUS NE LES LISAIT PAS. Les quatre cases existaient, elles ne faisaient rien
 * sur le site. Releve par Cyrille le 4 aout, en les activant dans son profil.
 *
 * Les noms de parametres et les noms de classes sont ceux d'Atum, a la lettre.
 * Ce n'est pas de la paresse : quelqu'un qui coche « contraste eleve » doit
 * obtenir la meme chose dans l'administration et sur le site. Une invention de
 * notre part serait une incoherence de plus a expliquer.
 *
 * LES QUATRE CLASSES VONT SUR <html>, ET NON SUR <body> COMME ATUM. Ce n'est
 * pas un detail de gout : c'est ce qui repare un defaut qu'Atum a et qu'on ne
 * veut pas.
 *
 * `filter` — celui du monochrome et du contraste — cree un bloc de reference
 * pour les descendants en `position: fixed`, SAUF sur l'element racine du
 * document : la specification prevoit cette exception.
 *
 * Pose sur <body>, il ferait donc defiler avec la page ce qui doit rester
 * fixe. Corpus a deux regles en `position: fixed`, dont le panneau
 * « Parametres d'affichage ». Voir _accessibilite-utilisateur.scss : l'effet
 * lui-meme n'a pas pu etre verifie a l'ecran, la regle vient du texte de la
 * specification, et <html> est de toute facon le choix sur.
 *
 * `a11y_font` y allait deja, pour une autre raison : il change la taille de
 * reference, dont tous les rem du site decoulent.
 */
$corpusUtilisateur = $app->getIdentity();

$corpusA11yFont      = (bool) $corpusUtilisateur->getParam('a11y_font', '');
$corpusA11yMono      = (bool) $corpusUtilisateur->getParam('a11y_mono', '');
$corpusA11yContraste = (bool) $corpusUtilisateur->getParam('a11y_contrast', '');
$corpusA11ySurligne  = (bool) $corpusUtilisateur->getParam('a11y_highlight', '');

$corpusA11y = ($corpusA11yFont ? ' a11y_font' : '')
    . ($corpusA11yMono ? ' monochrome' : '')
    . ($corpusA11yContraste ? ' a11y_contrast' : '')
    . ($corpusA11ySurligne ? ' a11y_highlight' : '');
?>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>" data-theme="clair"<?php
	echo $corpusVariante === '' ? '' : ' data-variante="' . htmlspecialchars($corpusVariante, ENT_QUOTES, 'UTF-8') . '"';
	echo $corpusA11y === '' ? '' : ' class="' . trim($corpusA11y) . '"'; ?>>

<head>
	<!-- Custom code -->
	<?php $helper->_('advancedCodeBeforeHead'); ?>
	<!-- // Custom code -->

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<?php
	// Le theme est pose AVANT le premier rendu, sinon la page clignote en clair
	// puis bascule. Lecture protegee : un navigateur qui refuse le stockage ne
	// doit pas casser la page.
	?>
	<script>
	(function () {
		try {
			var t = localStorage.getItem('corpus-theme') || 'systeme';
			var s = window.matchMedia('(prefers-color-scheme: dark)').matches;
			document.documentElement.dataset.theme = t === 'systeme' ? (s ? 'sombre' : 'clair') : t;
		} catch (e) { /* stockage refuse : on reste en clair */ }
	})();
	</script>

	<?php
	// Temoin de version : permet de verifier d'un coup d'oeil, dans le code
	// source de la page, quel fichier index.php est reellement execute.
	echo '<!-- CORPUS 1.0.8-rc1 | css=' . $mediaUrl . '/css/template-j4.css'
		. ' | existe=' . (is_file(JPATH_ROOT . $mediaPath . '/css/template-j4.css') ? 'oui' : 'NON')
		. ' -->' . "\n";
	?>

	<jdoc:include type="head" />

	<!-- Custom color style -->
	<?php $helper->addCustomStyle(); ?>
	<!-- Custom code -->
	<?php $helper->_('advancedCodeAfterHead'); ?>
	<!-- // Custom code -->
</head>

<body class="page-<?php $helper->_('view') ?> <?php $helper->_('page-class') ?>">

	<!-- Premier element focalisable de la page : il permet d'atteindre le
	     contenu sans parcourir la navigation. RGAA 12.7. -->
	<a class="evitement" href="#contenu"><?php echo Text::_('TPL_CORPUS_SKIP_TO_CONTENT'); ?></a>

	<?php
	// LA CIBLE DU RETOUR EN HAUT. `tabindex="-1"` n'est pas un detail : sans
	// lui, suivre l'ancre deplace la vue mais PAS le focus, et l'usager au
	// clavier repart d'ou il etait — tout en bas de la page.
	?>
	<span id="corpus-haut" tabindex="-1"></span>

	<?php require __DIR__ . '/html/layouts/corpus/pictogrammes.php'; ?>

	<!-- Custom code -->
	<?php $helper->_('advancedCodeBeforeBody'); ?>
	<!-- // Custom code -->

	<?php
	/*
	 * LA BARRE D'INFORMATION — 3 aout 2026.
	 *
	 * La bande fine au-dessus de l'en-tete : reseaux sociaux d'un cote, telephone,
	 * courriel ou horaires de l'autre. Deux positions, exactement comme l'en-tete
	 * et la navigation — l'administrateur decide ce qui va de chaque cote au lieu
	 * de dependre de l'ordre de publication.
	 *
	 * FINE NE VEUT PAS DIRE PETITE. Le referentiel interdit tout texte sous 1 rem.
	 * La bande est fine par ses marges : un numero de telephone illisible n'est
	 * pas un detail de style.
	 */
	$corpusBarreG = (string) $helper->get('topbar-left-pos');
	$corpusBarreD = (string) $helper->get('topbar-right-pos');
	?>
	<?php if ($corpusBarreG !== '' || $corpusBarreD !== '') : ?>
	<!-- BARRE D'INFORMATION -->
	<div class="barre-info<?php echo $corpusTheme('topbar') . $corpusFond('topbar'); ?>">
		<div class="page barre-info__contenu">
			<div class="barre-info__cote">
				<?php if ($corpusBarreG !== '') : ?>
				<jdoc:include type="modules" name="<?php echo $corpusBarreG; ?>" style="sans-cadre" />
				<?php endif; ?>
			</div>
			<div class="barre-info__cote barre-info__cote--droite">
				<?php if ($corpusBarreD !== '') : ?>
				<jdoc:include type="modules" name="<?php echo $corpusBarreD; ?>" style="sans-cadre" />
				<?php endif; ?>
			</div>
		</div>
	</div>
	<!-- // BARRE D'INFORMATION -->
	<?php endif; ?>

	<?php if ($helper->is('header-enabled')) : ?>
	<!-- EN-TETE -->
	<header id="entete" class="entete<?php echo $corpusTheme('header') . $corpusFond('header') . $corpusEpingle('header', 'entete--epingle'); ?>"<?php $helper->_bg('header') ?>>
		<div class="page entete__haut">

			<?php
			// Une image de logo remplace le texte : la classe change. Le nom
			// reste dans le balisage, repousse hors de l'ecran par la feuille
			// personnalisee — il porte le lien pour les lecteurs d'ecran et les
			// moteurs de recherche. RGAA 1.1
			?>
			<a class="marque <?php echo $corpusClasse; ?>" href="<?php echo $this->baseurl; ?>/">
				<span class="marque__nom"><?php echo htmlspecialchars($corpusNom, ENT_QUOTES, 'UTF-8'); ?></span>
				<?php if ($corpusSlogan !== '' && $corpusLogo === '') : ?>
				<span class="marque__baseline"><?php echo htmlspecialchars($corpusSlogan, ENT_QUOTES, 'UTF-8'); ?></span>
				<?php endif; ?>
			</a>

			<div class="entete__outils">
				<?php if ($helper->has('header-right-class')) : ?>
				<jdoc:include type="modules" name="<?php $helper->_('header-right-pos') ?>" style="none" />
				<?php endif ?>

				<?php
				// LE BOUTON D'AFFICHAGE N'EST PLUS ICI — 4 aout 2026.
				//
				// Il partageait cette zone avec la position `banner`, et Cyrille
				// a vu le resultat des qu'il y a publie une banniere : le nom du
				// site, l'image de l'annonceur et le bouton se disputaient la
				// meme ligne. Le bouton a perdu, parce que c'est le seul des
				// trois dont la largeur n'etait pas imposee.
				//
				// Il est desormais flottant, contre le bord droit de l'ecran.
				// Voir plus bas, juste avant le panneau. Le bouton du pied de
				// page reste : il sert a ceux qui arrivent en bas sans avoir vu
				// le flottant.
				?>
			</div>
		</div>
	</header>
	<!-- // EN-TETE -->
	<?php endif ?>

	<?php if ($helper->is('nav-enabled')) : ?>
	<!-- NAVIGATION PRINCIPALE -->
	<nav class="navigation<?php echo $corpusTheme('nav') . $corpusFond('nav') . $corpusEpingle('nav', 'navigation--epinglee'); ?>" aria-label="<?php echo htmlspecialchars(Text::_('TPL_CORPUS_MAIN_MENU'), ENT_QUOTES, 'UTF-8'); ?>">
		<div class="page">
			<?php
			// Le menu sort de mod_menu, via la surcharge html/mod_menu/default.php :
			// c'est elle qui produit .nav__liste, les <button aria-expanded> et
			// les trois niveaux.
			//
			// LE BOUTON DE REPLI — 7 aout 2026.
			//
			// Jusqu'ici, sous 48 rem, la liste passait en colonne et restait
			// depliee. Tenable a quatre entrees, intenable a dix : la page
			// s'ouvrait sur un mur de liens, sur chaque page. Cyrille l'a vu
			// sur son telephone et a cherche un reglage qui n'existait pas.
			//
			// Il est pose `hidden` : c'est template.js qui le revele, et lui
			// aussi qui pose `aria-controls` une fois la liste trouvee. Sans
			// JavaScript le bouton n'apparait donc jamais et la liste reste
			// depliee — un menu deplie se parcourt, un bouton mort ne fait
			// rien. Meme regle que le bouton d'impression sous les articles.
			?>
			<button type="button" class="nav__bascule" aria-expanded="false" hidden>
				<svg class="i i--ouvrir" aria-hidden="true" focusable="false"><use href="#i-menu" /></svg>
				<svg class="i i--fermer" aria-hidden="true" focusable="false"><use href="#i-fermer" /></svg>
				<?php echo htmlspecialchars(Text::_('TPL_CORPUS_MENU_BOUTON'), ENT_QUOTES, 'UTF-8'); ?>
			</button>

			<jdoc:include type="modules" name="<?php $helper->_('nav-left-pos') ?>" style="none" />

			<?php
			// « NAV DROITE » EST MAINTENANT DANS LA BARRE — 4 aout 2026.
			//
			// Cyrille a publie la recherche en position `search` et ne l'a pas
			// trouvee. Elle s'affichait bien, mais dans une rangee a part sous
			// le fil d'Ariane, alors que le constructeur de layout la montre
			// « Nav droite », a cote du menu. Le reglage promettait une chose,
			// le gabarit en faisait une autre — et c'est le reglage qui avait
			// raison : c'est lui que l'acheteur lit.
			//
			// La zone reste libre : recherche, drapeaux, ou ce qu'on y publie.
			// Elle ne porte donc AUCUN repere de recherche — celui-la vient du
			// module, notre gabarit mod_finder sortant deja un `<search>`.
			?>
			<?php if ($helper->has('nav-right-class')) : ?>
			<div class="navigation__droite">
				<jdoc:include type="modules" name="<?php $helper->_('nav-right-pos') ?>" style="none" />
			</div>
			<?php endif; ?>
		</div>
	</nav>
	<!-- // NAVIGATION PRINCIPALE -->
	<?php endif ?>

	<?php
	// Le fil d'Ariane vit ENTRE la navigation et le contenu, dans sa propre
	// bande — pas dans la section de contenu. Place a l'interieur, il heritait
	// des 56 px de respiration de la section et flottait au milieu du vide, a
	// 180 px sous la barre de navigation. Il indique ou l'on est : sa place est
	// contre la navigation, qui dit ou l'on peut aller.
	?>
	<!-- FIL D'ARIANE -->
	<div class="page">
		<jdoc:include type="modules" name="breadcrumbs" style="none" />
	</div>
	<!-- // FIL D'ARIANE -->

	<?php
	// LA ZONE « NAV DROITE » A DEMENAGE dans la barre de navigation, quelques
	// lignes plus haut. Elle vivait ici, dans une rangee a elle sous le fil
	// d'Ariane, et portait meme `role="search"` en dur — ce qui aurait fait
	// annoncer « recherche » devant un selecteur de langue.
	?>

	<?php
	// Vue de configuration : le corps de page est desactive, mais le composant
	// doit tout de meme sortir. Les deux branches sont exclusives — il n'y a
	// jamais deux id="contenu" dans le meme document.
	?>
	<?php if (!$helper->is('content-enabled') && $option === 'com_config') : ?>
	<div class="section">
		<div class="page">
			<main id="contenu" tabindex="-1">
				<jdoc:include type="message" />
				<jdoc:include type="component" />
			</main>
		</div>
	</div>
	<?php endif; ?>

	<?php $helper->spotlight('top_1', ['class' => 'top-sl']) ?>
	<?php $helper->spotlight('top_2', ['class' => 'top-sl']) ?>
	<?php $helper->spotlight('top_3', ['class' => 'top-sl']) ?>
	<?php $helper->spotlight('top_4', ['class' => 'top-sl']) ?>

	<?php if ($helper->is('content-enabled')) : ?>
	<!-- CORPS DE PAGE -->
	<div class="section"<?php $helper->_bg('content') ?>>
		<div class="page">
			<div class="grille">
				<main id="contenu" tabindex="-1" class="<?php echo $corpusMain . $corpusOrdreMain; ?>">
					<jdoc:include type="message" />

					<?php
					// Les deux rangees de la colonne de contenu. Le helper a deja
					// verifie l'activation ; ici on ne verifie que la presence d'un
					// module, pour ne pas poser une rangee vide qui prendrait sa marge.
					$corpusHaut = (string) $helper->get('main-top-pos');
					$corpusBas  = (string) $helper->get('main-bottom-pos');
					?>
					<?php
					/*
					 * Le titre d'une rangee de contenu.
					 *
					 * Meme mecanique que les bandes, et le meme garde-fou : le niveau
					 * vient d'une liste fermee, mais il arrive de la base et on ne le
					 * presume pas. Un `<h4>` glisse la deviendrait une balise inventee.
					 *
					 * Le h1 ne porte pas le filet — il l'a deja par la feuille ; les
					 * autres niveaux le demandent.
					 */
					$corpusTitreRangee = static function (string $cle) use ($helper) {
						if (!$helper->has('layoutTitle_' . $cle) && !$helper->has('layoutDesc_' . $cle)) {
							return;
						}

						if ($helper->has('layoutTitle_' . $cle)) {
							$niveau = (string) $helper->get('layoutTitleTag_' . $cle, 'h2');

							if (!in_array($niveau, ['h1', 'h2', 'h3'], true)) {
								$niveau = 'h2';
							}

							echo '<' . $niveau . ($niveau === 'h1' ? '' : ' class="filet"') . '>';
							$helper->_('layoutTitle_' . $cle);
							echo '</' . $niveau . '>';
						}

						if ($helper->has('layoutDesc_' . $cle)) {
							echo '<p class="chapo">';
							$helper->_('layoutDesc_' . $cle);
							echo '</p>';
						}
					};
					?>
					<?php if ($corpusHaut !== '' && $this->countModules($corpusHaut)) : ?>
					<div class="zone-modules zone-modules--haut<?php echo $corpusTheme('main_top') . $corpusFond('main_top'); ?>">
						<?php $corpusTitreRangee('main_top'); ?>
						<jdoc:include type="modules" name="<?php echo $corpusHaut; ?>" style="sans-cadre" />
					</div>
					<?php endif; ?>

					<jdoc:include type="component" />

					<?php if ($corpusBas !== '' && $this->countModules($corpusBas)) : ?>
					<div class="zone-modules zone-modules--bas<?php echo $corpusTheme('main_bottom') . $corpusFond('main_bottom'); ?>">
						<?php $corpusTitreRangee('main_bottom'); ?>
						<jdoc:include type="modules" name="<?php echo $corpusBas; ?>" style="sans-cadre" />
					</div>
					<?php endif; ?>
				</main>

				<?php if ($corpusCol1) : ?>
				<div class="<?php echo $corpusCote1; ?>">
					<jdoc:include type="modules" name="<?php $helper->_('col1-pos') ?>" style="encadre" />
				</div>
				<?php endif; ?>

				<?php if ($corpusCol2) : ?>
				<div class="<?php echo $corpusCote2; ?>">
					<jdoc:include type="modules" name="<?php $helper->_('col2-pos') ?>" style="encadre" />
				</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<!-- // CORPS DE PAGE -->
	<?php endif; ?>

	<?php $helper->spotlight('bot_1', ['class' => 'bot-sl']) ?>
	<?php $helper->spotlight('bot_2', ['class' => 'bot-sl']) ?>
	<?php $helper->spotlight('bot_3', ['class' => 'bot-sl']) ?>
	<?php $helper->spotlight('bot_4', ['class' => 'bot-sl']) ?>

	<!-- PIED DE PAGE -->
	<footer class="pied<?php echo $corpusTheme('footer') . $corpusFond('footer'); ?>">
		<div class="page pied__haut">
			<?php $helper->spotlight('footer', ['class' => 'pied__bloc', 'style' => 'sans-cadre']) ?>
		</div>
		<div class="page pied__bas">
			<?php
			// LA RANGEE BASSE DU PIED — position `footer-bottom`, ajoutee le
			// 4 aout 2026.
			//
			// La maquette y met les liens d'obligation : accessibilite, mentions
			// legales, donnees personnelles. Ils ne pouvaient pas y etre : cette
			// rangee etait ecrite en dur et n'accueillait aucun module. Cyrille
			// a publie le pied et demande comment coller a la maquette — la
			// reponse etait « on ne peut pas », ce qui n'est pas une reponse.
			//
			// Ces liens varient d'un site a l'autre et l'un d'eux est
			// obligatoire en France : ils appartiennent a l'administrateur, pas
			// au gabarit. Un menu publie ici fait l'affaire.
			?>
			<?php if ($this->countModules('footer-bottom')) : ?>
			<jdoc:include type="modules" name="footer-bottom" style="none" />
			<?php endif; ?>

			<button type="button" class="outil" data-corpus-affichage
				aria-expanded="false" aria-controls="corpus-affichage">
				<svg class="i--sm" aria-hidden="true" focusable="false"><use href="#i-affichage" /></svg>
				<span><?php echo Text::_('TPL_CORPUS_DISPLAY_SETTINGS'); ?></span>
			</button>
			<?php
			// LE RETRAIT DU CONSENTEMENT — 6 aout 2026.
			//
			// « Le consentement doit pouvoir etre retire aussi facilement
			// qu'il a ete donne. » Ce n'est pas un confort, c'est le texte :
			// sans ce lien, un bandeau parfait reste non conforme.
			//
			// Il n'apparait que si le gestionnaire est actif, et il appelle
			// `orejime.prompt()`. Le bouton est ecrit en dur plutot qu'ajoute
			// par le script : un moyen de retrait qui dependrait du chargement
			// d'un fichier tiers disparaitrait le jour ou ce fichier manque.
			if ($helper->getSite('consentementActif') && $helper->getSite('consentementLienPied')) : ?>
			<button type="button" class="outil" data-corpus-consentement>
				<span><?php echo Text::_('TPL_CORPUS_CONSENT_REOUVRIR'); ?></span>
			</button>
			<?php endif; ?>
			<?php
			// LA MENTION DE PROPRIETE PORTE LE NOM DU SITE, PAS CELUI DU LOGO.
			// Corrige le 4 aout 2026 : Cyrille lisait « © 2026 Tpl CORPUS » alors
			// que son site s'appelle CORPUS.
			//
			// J'avais repris `$corpusNom`, qui vient du champ « Nom du site » du
			// Theme Customizer. Ce champ-la est le TEXTE DU LOGO : il remplace
			// l'image quand il n'y en a pas, et on y ecrit ce qu'on veut voir
			// en haut a gauche. La mention de propriete, elle, nomme la
			// personne morale — c'est le nom du site de la configuration
			// globale, et lui seul.
			//
			// `.droite` pousse le bloc au bout de la ligne, comme dans la
			// maquette.
			$corpusNomLegal = (string) $app->get('sitename');
			?>
			<span class="droite">&copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars($corpusNomLegal, ENT_QUOTES, 'UTF-8'); ?></span>
		</div>
	</footer>
	<!-- // PIED DE PAGE -->

	<?php
	// LE BOUTON FLOTTANT D'AFFICHAGE — 4 aout 2026, demande de Cyrille.
	//
	// Il etait dans l'en-tete, ou il se faisait ecraser des qu'une banniere
	// etait publiee a cote. Le reglage d'affichage n'appartient pas au contenu
	// de la page : c'est un outil, comme le bouton d'accessibilite que Joomla
	// pose en bas a gauche. Il vit donc au bord de l'ecran, toujours visible,
	// et il ne concourt plus pour une place dans une ligne.
	//
	// PLACE A DROITE, A 30 % DE LA HAUTEUR. Le coin haut-droit est occupe par
	// la barre d'information ; descendre d'un tiers evite aussi le pouce sur
	// telephone, qui balaie plutot le bas.
	//
	// IL EST DANS UN <div> ET PAS DANS L'EN-TETE, volontairement : un element
	// en `position: fixed` place dans un conteneur transforme ou filtre se
	// raccroche a ce conteneur au lieu de l'ecran. Le poser en fin de document,
	// enfant direct du corps, supprime la question.
	//
	// LE LIBELLE N'EST PAS SUPPRIME, il est masque a l'oeil seulement : sans
	// lui, le bouton n'aurait aucun nom accessible et serait annonce
	// « bouton ». Le pictogramme, lui, est `aria-hidden` — il ne redit rien.
	?>
	<button type="button" class="outil-flottant" data-corpus-affichage
		aria-expanded="false" aria-controls="corpus-affichage">
		<svg class="i" aria-hidden="true" focusable="false"><use href="#i-affichage" /></svg>
		<span class="visuellement-cache"><?php echo Text::_('TPL_CORPUS_DISPLAY_SETTINGS'); ?></span>
	</button>

	<?php
	// LE RETOUR EN HAUT — 4 aout 2026, demande de Cyrille.
	//
	// C'EST UN LIEN, PAS UN BOUTON, et c'est le point important. Un bouton
	// aurait eu besoin du script pour faire quoi que ce soit ; un lien vers une
	// ancre remonte la page tout seul, script casse ou pas, et il deplace le
	// FOCUS en meme temps que la vue — ce qu'un `scrollTo` ne fait pas. Au
	// clavier, remonter sans emmener le focus ne sert a rien.
	//
	// Il est masque tant qu'on n'a pas defile : voir `.retour-haut` dans
	// _entete-pied.scss, et la bascule dans template.js. Un bouton « remonter »
	// affiche alors qu'on est deja en haut est un controle qui ne fait rien.
	//
	// Le defilement doux vient de `scroll-behavior` en CSS, pas d'ici : c'est
	// la seule facon de respecter `prefers-reduced-motion` sans le reprogrammer.
	?>
	<a class="outil-flottant retour-haut" href="#corpus-haut" hidden>
		<svg class="i" aria-hidden="true" focusable="false"><use href="#i-fleche-haut" /></svg>
		<span class="visuellement-cache"><?php echo Text::_('TPL_CORPUS_BACK_TO_TOP'); ?></span>
	</a>

	<?php
	// Le panneau d'affichage — trois etats : clair, sombre, systeme.
	// « systeme » suit prefers-color-scheme et reagit EN DIRECT, pas seulement
	// au chargement : le script ecoute matchMedia.
	?>
	<div class="panneau" id="corpus-affichage" role="dialog" aria-modal="true"
		aria-labelledby="corpus-affichage-titre" hidden>
		<div class="panneau__boite">
			<h2 id="corpus-affichage-titre"><?php echo Text::_('TPL_CORPUS_DISPLAY_SETTINGS'); ?></h2>
			<div class="choix">
				<label>
					<input type="radio" name="corpus-theme" value="clair">
					<span><?php echo Text::_('TPL_CORPUS_THEME_LIGHT'); ?></span>
				</label>
				<label>
					<input type="radio" name="corpus-theme" value="sombre">
					<span><?php echo Text::_('TPL_CORPUS_THEME_DARK'); ?></span>
				</label>
				<label>
					<input type="radio" name="corpus-theme" value="systeme">
					<span><?php echo Text::_('TPL_CORPUS_THEME_SYSTEM'); ?></span>
				</label>
			</div>
			<div class="boutons">
				<button type="button" class="bouton" data-corpus-fermer><?php echo Text::_('TPL_CORPUS_CLOSE'); ?></button>
			</div>
		</div>
	</div>

	<?php if ($this->countModules('float-pos')) : ?>
	<jdoc:include type="modules" name="float-pos" style="raw" />
	<?php endif ?>

	<jdoc:include type="modules" name="debug" style="none" />

	<?php
	// =====================================================================
	// LE GESTIONNAIRE DE CONSENTEMENT — 6 aout 2026
	//
	// Corpus ne fournit pas de bandeau : il charge celui qu'on lui indique et
	// l'habille. Le raccord CSS est dans _consentement.scss ; ici, seulement
	// le chargement et la configuration.
	//
	// RIEN N'EST SERVI DEPUIS UN CDN, ET C'EST LE POINT QUI COMPTE. La
	// documentation d'Orejime propose jsDelivr ; charger le gestionnaire de
	// consentement depuis un serveur tiers enverrait l'adresse IP du visiteur
	// a ce tiers AVANT tout consentement. Le chemin est donc local, et le
	// champ le dit.
	//
	// LE FICHIER SUIT LA LANGUE DU SITE. Orejime livre un fichier par theme
	// et par langue — `orejime-standard-fr.js`. Sur un site bilingue, la
	// langue courante decide, avec repli sur l'anglais : un bandeau en
	// francais sur la version anglaise serait le premier defaut visible.
	//
	// LES QUATORZE LANGUES SONT LIVREES AVEC CORPUS — decision de Cyrille le
	// 6 aout 2026 : « je ne sais pas ou je vais vendre le template ». Elles
	// pesent 184 Ko une fois le paquet compresse, et le visiteur n'en recoit
	// JAMAIS qu'une seule, celle de sa page. Un site sans traceur n'en
	// recoit aucune.
	//
	// LE THEME DSFR D'OREJIME N'EST PAS LIVRE, et ce n'est pas une question
	// de poids : il est reserve au `.gouv.fr`, comme le reste du systeme.
	//
	// Le champ « dossier » reste, vide par defaut : il sert a celui qui veut
	// sa propre copie, une langue que le projet n'a pas, ou une version plus
	// recente que celle du paquet.
	if ($helper->getSite('consentementActif')) :
		$consentBase = trim((string) $helper->getSite('consentementChemin'), '/');

		if ($consentBase === '') {
			$consentBase = dirname($fichier('orejime/orejime-standard.css'));
		}

		$consentLangue = substr($app->getLanguage()->getTag(), 0, 2);

		if (!is_file(JPATH_SITE . '/' . $consentBase . '/orejime-standard-' . $consentLangue . '.js')) {
			$consentLangue = 'en';
		}

		$consentServices = trim((string) $helper->getSite('consentementServices'));
		$consentPolitique = (string) $helper->getSite('consentementPolitique');
		?>
	<?php
	// SANS SERVICE DECLARE, ON NE CHARGE RIEN — 6 aout 2026.
	//
	// Orejime ne demande le consentement que pour ce qu'on lui a declare : une
	// liste vide, et il n'affiche rien. C'est logique de sa part, mais c'est
	// une panne silencieuse pour l'administrateur, qui a active le
	// gestionnaire, rempli l'adresse de sa politique, et ne voit aucun
	// bandeau. Mesure faite sur le banc : `purposes: []`, aucun message,
	// aucune erreur en console.
	//
	// On ne peut pas lui parler d'ici — le site public n'est pas l'endroit ou
	// avertir un administrateur. Ce qu'on peut faire, c'est ne pas charger
	// 36 Ko de JavaScript qui ne montreront rien, et le dire dans la
	// description du champ, ou il le lira au moment ou la question se pose.
	if ($consentServices === '' || $consentServices === '[]') : ?>
	<?php else : ?>
	<link rel="stylesheet" href="<?php echo Uri::root(true) . '/' . $consentBase; ?>/orejime-standard.css">
	<script>
		window.orejimeConfig = {
			privacyPolicyUrl: <?php echo json_encode($consentPolitique); ?>,
			purposes: <?php echo $consentServices !== '' ? $consentServices : '[]'; ?>
		};
	</script>
	<script src="<?php echo Uri::root(true) . '/' . $consentBase; ?>/orejime-standard-<?php echo $consentLangue; ?>.js" defer></script>
	<?php endif; ?>
	<?php endif; ?>

	<!-- Custom code -->
	<?php $helper->_('advancedCodeAfterBody'); ?>
	<!-- // Custom code -->

</body>

</html>
