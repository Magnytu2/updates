<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;

/** @var Joomla\CMS\Document\HtmlDocument $this */

$app             = Factory::getApplication();
$doc             = $app->getDocument();
$this->language  = $doc->language;
$this->direction = $doc->direction;

// Le repli enfant vers parent : voir helper::getMediaFichier(). Le dossier
// media d'un enfant est cree vide, et une vue « component » sans feuille est
// une page d'impression illisible.
$helperComposant = require __DIR__ . '/helper.php';
$helperComposant->init($this);

$this->getWebAssetManager()->registerAndUseStyle(
    'template.corpus',
    $helperComposant->getMediaFichier('css/template-j4.css')
);
?>
<!DOCTYPE html>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<jdoc:include type="head" />
</head>
<body class="contentpane modal">
	<jdoc:include type="message" />
	<jdoc:include type="component" />
</body>
</html>
