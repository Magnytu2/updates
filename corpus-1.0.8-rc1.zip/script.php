<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE SCRIPT D'INSTALLATION — ecrit le 3 aout 2026.
 *
 * POURQUOI IL EXISTE. Cinq reglages de position se marchaient dessus depuis le
 * portage, et personne ne l'avait vu :
 *
 *   layoutPos_top_3  et  layoutPos_top_4  valaient TOUS DEUX `main-top`
 *   layoutPos_bot_3  et  layoutPos_bot_4  valaient TOUS DEUX `main-bottom`
 *   layoutPos_header_right                valait `topbar`
 *
 * Consequence a l'ecran : un module publie sur `main-top` s'affichait DEUX
 * FOIS, une fois par bande. Et la position `topbar`, destinee a la barre
 * d'information, etait consommee par la zone « en-tete droite ».
 *
 * CHANGER LE DEFAUT DU MANIFESTE NE SUFFIT PAS. Un defaut ne s'applique qu'a
 * un style jamais enregistre ; des qu'un administrateur a ouvert et sauve le
 * style, la valeur vit en base et le manifeste ne la relit plus. Sans ce
 * script, le double affichage survivrait a la mise a jour — et un client
 * venant de Cassiopeia le decouvrirait sur son site en production.
 *
 * CE QU'IL NE FAIT PAS, ET C'EST VOULU. Il ne corrige QUE les valeurs
 * exactement egales a l'ancien defaut. Un administrateur qui a deliberement
 * pointe Top 3 sur `main-top` garde son choix : on repare une erreur de
 * livraison, on ne redecide pas a sa place.
 *
 * IL NE PEUT PAS FAIRE ECHOUER L'INSTALLATION. Tout est sous `try` et le
 * script rend toujours `true` : une migration de confort ne doit jamais
 * empecher un template de s'installer. En cas d'echec, l'administrateur voit
 * un avertissement et corrige les cinq champs a la main.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            InstallerScriptInterface::class,
            new class () implements InstallerScriptInterface {
                /** Champ => [ancienne valeur, nouvelle]. Rien d'autre n'est touche. */
                private const CORRECTIONS = [
                    'layoutPos_top_3'        => ['main-top',    'top-c'],
                    'layoutPos_top_4'        => ['main-top',    'top-d'],
                    'layoutPos_bot_3'        => ['main-bottom', 'bottom-c'],
                    'layoutPos_bot_4'        => ['main-bottom', 'bottom-d'],
                    'layoutPos_header_right' => ['topbar',      'banner'],

                    // LA GRAISSE DES TITRES — 6 aout 2026. Le defaut du
                    // manifeste passe de 700 a 600, mais un defaut ne
                    // s'applique QU'AUX STYLES NEUFS : un style deja
                    // enregistre garde 700 en base, et la mise a jour n'y
                    // change rien. Mesure faite sur le banc avant d'ecrire.
                    //
                    // On ne corrige que la valeur 700, l'ancien defaut. Un
                    // administrateur qui a choisi 800 garde son choix.
                    'typoTitresGraisse'      => ['700',         '600'],
                ];

                /**
                 * LES ZONES QUE LA MISE A JOUR RALLUME — 6 aout 2026.
                 *
                 * Demande de Cyrille : « toutes les positions identiques a
                 * Cassiopeia soient actives, a chaque installation sur un
                 * Joomla, neuf ou pas ».
                 *
                 * Les huit rangees et le pied etaient eteints faute de valeur
                 * par defaut. Le code en pose une desormais, mais elle ne sert
                 * qu'aux styles qui ne se sont jamais prononces — or Joomla
                 * enregistre TOUS les champs au premier « Enregistrer », donc
                 * un style existant porte un 0 explicite en base. Verifie a
                 * l'ecran : `layoutEnable_top_1 = 0` sur le banc.
                 *
                 * CETTE MIGRATION ECRASE DONC UN CHOIX EXPLICITE, et c'est
                 * assume : une zone allumee mais vide ne produit AUCUN
                 * balisage — `spotlight()` sort avant d'ecrire si la position
                 * n'a pas de module. Le seul effet possible est de faire
                 * apparaitre des modules que l'administrateur avait publies
                 * sans les voir.
                 */
                /**
                 * LES CHAMPS RENOMMES — 6 aout 2026.
                 *
                 * `advancedSiteName` et `advancedSiteSlogan` portaient le
                 * prefixe des Parametres avances alors qu'ils vivent dans le
                 * groupe Logo du Theme Customizer. Ils deviennent `logoText`
                 * et `logoSlogan`.
                 *
                 * Un renommage de champ EFFACE la valeur enregistree : Joomla
                 * ne lit plus que le nouveau nom, et l'ancien reste en base
                 * sans que rien ne l'y cherche. Un site qui avait saisi un nom
                 * affiche retomberait silencieusement sur le nom du site de la
                 * configuration globale — un defaut plausible, donc invisible.
                 *
                 * Cette migration se fait AVANT la premiere vente. Apres, il y
                 * aurait des sites installes, et la fenetre serait fermee.
                 *
                 * Ancien nom => nouveau. La valeur n'est deplacee que si le
                 * nouveau champ n'a rien : jamais d'ecrasement.
                 */
                private const RENOMMAGES = [
                    'advancedSiteName'   => 'logoText',
                    'advancedSiteSlogan' => 'logoSlogan',
                ];

                private const ZONES_A_RALLUMER = [
                    'layoutEnable_topbar',
                    'layoutEnable_top_1', 'layoutEnable_top_2',
                    'layoutEnable_top_3', 'layoutEnable_top_4',
                    'layoutEnable_main_top', 'layoutEnable_main_bottom',
                    'layoutEnable_col_1', 'layoutEnable_col_2',
                    'layoutEnable_bot_1', 'layoutEnable_bot_2',
                    'layoutEnable_bot_3', 'layoutEnable_bot_4',
                    'layoutEnable_footer',
                ];

                public function install(InstallerAdapter $parent): bool
                {
                    return true;
                }

                public function update(InstallerAdapter $parent): bool
                {
                    return true;
                }

                public function uninstall(InstallerAdapter $parent): bool
                {
                    return true;
                }

                public function preflight(string $type, InstallerAdapter $parent): bool
                {
                    return true;
                }

                /**
                 * La migration tourne en POSTFLIGHT : les fichiers sont en place et
                 * le manifeste a deja ete relu. Elle est IDEMPOTENTE — la relancer
                 * ne refait rien, puisqu'aucune valeur ne vaut plus l'ancien defaut.
                 */
                public function postflight(string $type, InstallerAdapter $parent): bool
                {
                    if ($type === 'uninstall') {
                        return true;
                    }

                    try {
                        $corriges = $this->corriger();
                    } catch (\Throwable $e) {
                        Factory::getApplication()->enqueueMessage(
                            Text::_('TPL_CORPUS_MIGRATION_ECHEC'),
                            'warning'
                        );

                        return true;
                    }

                    if ($corriges > 0) {
                        Factory::getApplication()->enqueueMessage(
                            Text::plural('TPL_CORPUS_MIGRATION_POSITIONS', $corriges),
                            'info'
                        );
                    }

                    $this->purgerFeuilles();

                    return true;
                }

                /**
                 * Jette les feuilles personnalisees deja construites.
                 *
                 * POURQUOI C'EST NECESSAIRE — 10 aout 2026. La feuille d'un style
                 * n'est reecrite qu'a l'ENREGISTREMENT de ce style. Un correctif
                 * qui porte sur la fabrication de la feuille — comme celui du
                 * selecteur du logo — n'a donc aucun effet apres une mise a jour :
                 * le client installe, ne voit rien changer, et conclut que le
                 * correctif ne marche pas. Il lui faudrait rouvrir chaque style et
                 * cliquer sur Enregistrer, ce que rien ne lui dit.
                 *
                 * Supprimer le fichier suffit : helper.php le constate absent et
                 * pose la feuille EN LIGNE dans la page, reconstruite a chaque
                 * requete. Le fichier revient de lui-meme au premier
                 * enregistrement. Aucun reglage n'est touche — les valeurs vivent
                 * dans la base, ce fichier n'en est que le rendu.
                 *
                 * Une suppression qui echoue n'est pas une erreur d'installation :
                 * le site continue de tourner avec son ancienne feuille.
                 */
                private function purgerFeuilles(): void
                {
                    $dossier = JPATH_ROOT . '/media/templates/site/corpus/css/custom-styles';

                    if (!is_dir($dossier)) {
                        return;
                    }

                    foreach ((array) glob($dossier . '/*.css') as $feuille) {
                        if (is_file($feuille)) {
                            @unlink($feuille);
                        }
                    }
                }

                /** @return int le nombre de styles reellement modifies */
                private function corriger(): int
                {
                    $db = Factory::getContainer()->get(DatabaseInterface::class);

                    $requete = $db->getQuery(true)
                        ->select($db->quoteName(['id', 'params']))
                        ->from($db->quoteName('#__template_styles'))
                        ->where($db->quoteName('client_id') . ' = 0')
                        ->where($db->quoteName('template') . ' = :nom')
                        ->bind(':nom', $nom);

                    $nom    = 'corpus';
                    $styles = $db->setQuery($requete)->loadObjectList();

                    if (!$styles) {
                        return 0;
                    }

                    $corriges = 0;

                    foreach ($styles as $style) {
                        $params = json_decode((string) $style->params, true);

                        // Un JSON illisible n'est pas un style a reparer : on passe.
                        // Ecrire par-dessus effacerait tous les reglages du client.
                        if (!is_array($params)) {
                            continue;
                        }

                        $change = false;

                        foreach (self::CORRECTIONS as $champ => $paire) {
                            if (isset($params[$champ]) && $params[$champ] === $paire[0]) {
                                $params[$champ] = $paire[1];
                                $change = true;
                            }
                        }

                        foreach (self::RENOMMAGES as $ancien => $nouveau) {
                            if (!array_key_exists($ancien, $params)) {
                                continue;
                            }

                            if (($params[$nouveau] ?? '') === '') {
                                $params[$nouveau] = $params[$ancien];
                            }

                            unset($params[$ancien]);
                            $change = true;
                        }

                        foreach (self::ZONES_A_RALLUMER as $zone) {
                            if (($params[$zone] ?? '1') === '1' || ($params[$zone] ?? 1) === 1) {
                                continue;
                            }

                            $params[$zone] = '1';
                            $change = true;
                        }

                        if (!$change) {
                            continue;
                        }

                        $json = json_encode($params);

                        $maj = $db->getQuery(true)
                            ->update($db->quoteName('#__template_styles'))
                            ->set($db->quoteName('params') . ' = :params')
                            ->where($db->quoteName('id') . ' = :id')
                            ->bind(':params', $json)
                            ->bind(':id', $style->id, ParameterType::INTEGER);

                        $db->setQuery($maj)->execute();
                        $corriges++;
                    }

                    return $corriges;
                }
            }
        );
    }
};
