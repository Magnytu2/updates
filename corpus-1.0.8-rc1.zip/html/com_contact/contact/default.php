<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LA PAGE CONTACT
 *
 * Ecrite le 1er aout 2026, apres deux tentatives en CSS seul qui ont echoue.
 *
 * POURQUOI UNE SURCHARGE ICI, alors qu'on l'a refusee ailleurs. Le gabarit du
 * coeur sort une SUITE PLATE de freres :
 *
 *     .com-contact__container   la fiche
 *     <h2> + .com-contact__form  le formulaire
 *     <h2> + liens / articles / profil / champs personnalises / divers
 *
 * Aucun conteneur ne separe la fiche du reste. En grille, le titre et le
 * formulaire tombent sur deux rangees et la rangee du titre prend la hauteur
 * de la fiche — un trou de 400 px, mesure. En flottement, le trou disparait
 * mais tout ce qui suit vient buter sous la fiche, et un bloc ajoute par un
 * reglage atterrit n'importe ou. Cyrille a pose la bonne question : « si je
 * rajoute des champs personnalises, ils vont ou ? »
 *
 * La reponse ne peut pas etre « ca depend ». On ajoute donc les DEUX
 * conteneurs qui manquent, et chaque bloc a une place nommee.
 *
 * CE QU'ON NE CHANGE PAS : les conditions, les reglages, les evenements de
 * plugin, les sous-gabarits appeles par loadTemplate(). Tout est repris du
 * coeur ligne pour ligne. Seule la structure change.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ContentHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Router\Route;
use Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use Joomla\Component\Contact\Site\Helper\RouteHelper;

/** @var \Joomla\Component\Contact\Site\View\Contact\HtmlView $this */
$tparams = $this->item->params;
$canDo   = ContentHelper::getActions('com_contact', 'category', $this->item->catid);
$canEdit = $canDo->get('core.edit') || ($canDo->get('core.edit.own') && $this->item->created_by === $this->getCurrentUser()->id);
$htag    = $tparams->get('show_page_heading') ? 'h2' : 'h1';
$htag2   = ($tparams->get('show_page_heading') && $tparams->get('show_name')) ? 'h3' : 'h2';

// La fiche n'existe que si l'un de ses morceaux existe. Sans elle, le corps
// prend toute la largeur — on ne laisse pas une colonne vide.
$corpusFiche = (bool) $this->params->get('show_info', 1);
?>
<div class="com-contact contact<?php echo $corpusFiche ? ' corpus-contact' : ''; ?>">

	<?php
	// LA TETE — titre, categorie, etiquettes. Un conteneur, et pas seulement
	// une suite de freres : sans lui, chacun de ces blocs prend une rangee de
	// la grille et decale les colonnes d'autant. Mesure du 1er aout : le corps
	// demarrait en rangee 3 au lieu de 2, donc au niveau des champs
	// personnalises et non du haut de la fiche.
	?>
	<div class="corpus-contact__tete">

	<?php if ($tparams->get('show_page_heading')) : ?>
	<h1><?php echo $this->escape($tparams->get('page_heading')); ?></h1>
	<?php endif; ?>

	<?php if ($this->item->name && $tparams->get('show_name')) : ?>
	<div class="page-header">
		<<?php echo $htag; ?> class="filet">
			<?php if ($this->item->published == 0) : ?>
			<span class="etiquette"><?php echo Text::_('JUNPUBLISHED'); ?></span>
			<?php endif; ?>
			<span class="contact-name"><?php echo $this->item->name; ?></span>
		</<?php echo $htag; ?>>
	</div>
	<?php endif; ?>

	<?php if ($canEdit) : ?>
	<div class="icons"><?php echo HTMLHelper::_('contacticon.edit', $this->item, $tparams); ?></div>
	<?php endif; ?>

	<?php $corpusCategorie = $tparams->get('show_contact_category'); ?>
	<?php if ($corpusCategorie === 'show_no_link') : ?>
	<p class="contact-category"><?php echo $this->item->category_title; ?></p>
	<?php elseif ($corpusCategorie === 'show_with_link') : ?>
	<p class="contact-category">
		<a href="<?php echo RouteHelper::getCategoryRoute($this->item->catid, $this->item->language); ?>">
			<?php echo $this->escape($this->item->category_title); ?></a>
	</p>
	<?php endif; ?>

	<?php echo $this->item->event->afterDisplayTitle; ?>

	<?php if ($tparams->get('show_contact_list') && count($this->contacts) > 1) : ?>
	<form action="#" method="get" name="selectForm" id="selectForm" class="champ">
		<label for="select_contact"><?php echo Text::_('COM_CONTACT_SELECT_CONTACT'); ?></label>
		<?php echo HTMLHelper::_(
			'select.genericlist',
			$this->contacts,
			'select_contact',
			'onchange="document.location.href = this.value"',
			'link',
			'name',
			$this->item->link
		); ?>
	</form>
	<?php endif; ?>

	<?php if ($tparams->get('show_tags', 1) && !empty($this->item->tags->itemTags)) : ?>
	<?php $this->item->tagLayout = new FileLayout('joomla.content.tags'); ?>
	<?php echo $this->item->tagLayout->render($this->item->tags->itemTags); ?>
	<?php endif; ?>

	<?php echo $this->item->event->beforeDisplayContent; ?>

	</div>

	<?php
	// ---------------------------------------------------------------------
	// LA FICHE — colonne de gauche. Elle ne porte QUE l'identite du contact :
	// sa photo, sa fonction, ses coordonnees. Tout ce qui se lit d'un coup
	// d'oeil et qu'on garde sous les yeux pendant qu'on remplit le formulaire.
	// ---------------------------------------------------------------------
	?>
	<?php if ($corpusFiche) : ?>
	<aside class="corpus-contact__fiche com-contact__container">

		<?php if ($this->item->image && $tparams->get('show_image')) : ?>
		<div class="com-contact__thumbnail">
			<?php echo LayoutHelper::render('joomla.html.image', [
				'src' => $this->item->image,
				'alt' => $this->item->name,
			]); ?>
		</div>
		<?php endif; ?>

		<?php if ($this->item->con_position && $tparams->get('show_position')) : ?>
		<p class="contact-position"><?php echo $this->item->con_position; ?></p>
		<?php endif; ?>

		<div class="com-contact__info">
			<?php echo $this->loadTemplate('address'); ?>

			<?php if ($tparams->get('allow_vcard')) : ?>
			<p class="mention">
				<?php echo Text::_('COM_CONTACT_DOWNLOAD_INFORMATION_AS'); ?>
				<a href="<?php echo Route::_('index.php?option=com_contact&view=contact&catid=' . $this->item->catslug . '&id=' . $this->item->slug . '&format=vcf'); ?>"><?php echo Text::_('COM_CONTACT_VCARD'); ?></a>
			</p>
			<?php endif; ?>
		</div>
	</aside>
	<?php endif; ?>

	<?php
	// LES CHAMPS PERSONNALISES — sous la fiche, dans leur propre cadre.
	//
	// Reponse a la question de Cyrille : « si je rajoute des champs
	// personnalises, ils vont ou ? » Ici, et nulle part ailleurs.
	//
	// Joomla les injecte normalement par evenement de plugin, a l'un des trois
	// points d'accroche du contenu — donc a un endroit qui depend du reglage
	// « Affichage automatique » de CHAQUE champ. Autrement dit : nulle part de
	// previsible. On les rend explicitement.
	//
	// A regler une fois cote client : mettre « Affichage automatique » sur
	// « Ne pas afficher automatiquement », sans quoi ils sortiraient deux fois.
	$corpusChamps = [];

	if (class_exists(FieldsHelper::class)) {
		foreach (FieldsHelper::getFields('com_contact.contact', $this->item, true) as $corpusChamp) {
			if (trim((string) $corpusChamp->value) !== '') {
				$corpusChamps[] = $corpusChamp;
			}
		}
	}
	?>
	<?php if ($corpusChamps) : ?>
	<aside class="corpus-contact__champs">
		<h2 class="filet"><?php echo Text::_('TPL_CORPUS_CARACTERISTIQUES'); ?></h2>
		<dl class="corpus-champs">
			<?php foreach ($corpusChamps as $corpusChamp) : ?>
			<dt><?php echo Text::_($corpusChamp->label); ?></dt>
			<dd><?php echo $corpusChamp->value; ?></dd>
			<?php endforeach; ?>
		</dl>
	</aside>
	<?php endif; ?>

	<?php
	// ---------------------------------------------------------------------
	// LE CORPS — colonne de droite, et TOUT LE RESTE Y VA. Formulaire, liens,
	// articles, profil, champs personnalises, autres informations.
	//
	// C'est la reponse a la question de Cyrille : un bloc qu'on active dans
	// les reglages arrive ICI, sous le precedent, avec son titre. Il n'y a pas
	// d'autre endroit possible, et c'est le but.
	// ---------------------------------------------------------------------
	?>
	<div class="corpus-contact__corps">

		<?php if ($this->item->misc && $tparams->get('show_misc')) : ?>
		<<?php echo $htag2; ?> class="filet"><?php echo Text::_('COM_CONTACT_OTHER_INFORMATION'); ?></<?php echo $htag2; ?>>
		<div class="com-contact__miscinfo contact-miscinfo contenu">
			<?php echo $this->item->misc; ?>
		</div>
		<?php endif; ?>

		<?php if ($tparams->get('show_email_form') && ($this->item->email_to || $this->item->user_id)) : ?>
		<<?php echo $htag2; ?> class="filet"><?php echo Text::_('COM_CONTACT_EMAIL_FORM'); ?></<?php echo $htag2; ?>>
		<?php echo $this->loadTemplate('form'); ?>
		<?php endif; ?>

		<?php if ($tparams->get('show_links')) : ?>
		<<?php echo $htag2; ?> class="filet"><?php echo Text::_('COM_CONTACT_LINKS'); ?></<?php echo $htag2; ?>>
		<?php echo $this->loadTemplate('links'); ?>
		<?php endif; ?>

		<?php if ($tparams->get('show_articles') && $this->item->user_id && $this->item->articles) : ?>
		<<?php echo $htag2; ?> class="filet"><?php echo Text::_('JGLOBAL_ARTICLES'); ?></<?php echo $htag2; ?>>
		<?php echo $this->loadTemplate('articles'); ?>
		<?php endif; ?>

		<?php if ($tparams->get('show_profile') && $this->item->user_id && PluginHelper::isEnabled('user', 'profile')) : ?>
		<<?php echo $htag2; ?> class="filet"><?php echo Text::_('COM_CONTACT_PROFILE'); ?></<?php echo $htag2; ?>>
		<?php echo $this->loadTemplate('profile'); ?>
		<?php endif; ?>

		<?php if ($tparams->get('show_user_custom_fields') && $this->contactUser) : ?>
		<?php echo $this->loadTemplate('user_custom_fields'); ?>
		<?php endif; ?>

	</div>

	<?php echo $this->item->event->afterDisplayContent; ?>
</div>
