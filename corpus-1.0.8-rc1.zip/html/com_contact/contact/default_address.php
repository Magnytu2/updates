<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LES COORDONNEES DU CONTACT
 *
 * Ecrit le 1er aout 2026. Le gabarit du coeur sort un <dl> ou UN <dt> est
 * suivi de PLUSIEURS <dd> — l'adresse en compte cinq. Aucune grille CSS ne
 * range ca proprement : elle suppose un <dd> par <dt>, et l'alignement des
 * pictogrammes partait de travers des la deuxieme ligne. Mesure, puis
 * constate a l'ecran par Cyrille.
 *
 * On sort donc UNE LIGNE PAR RENSEIGNEMENT : un pictogramme, un intitule, une
 * valeur. Le pictogramme s'aligne sur la premiere ligne de sa valeur, quel
 * que soit le nombre de lignes de celle-ci.
 *
 * L'intitule reste dans le document, en `.visuellement-cache` : « Adresse »,
 * « Telephone ». Un pictogramme seul ne dit rien a un lecteur d'ecran, et
 * `marker_class` du coeur permettait de le montrer ou de le cacher — on
 * garde ce reglage.
 *
 * Le courriel et le telephone deviennent des liens : sur un telephone, un
 * numero qu'on ne peut pas appeler d'un doigt n'a pas de raison d'etre.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\String\PunycodeHelper;

/** @var \Joomla\Component\Contact\Site\View\Contact\HtmlView $this */

$corpusMarqueur = $this->params->get('marker_class');
$corpusVisible  = $corpusMarqueur !== 'jicon-none';

/**
 * Une ligne : pictogramme, intitule, valeur.
 */
$corpusLigne = static function ($picto, $intitule, $valeur, $classe) use ($corpusVisible) {
    if ($valeur === '' || $valeur === null) {
        return;
    }
    ?>
	<li class="corpus-coordonnee">
		<svg class="i" aria-hidden="true" focusable="false"><use href="#<?php echo $picto; ?>" /></svg>
		<div>
			<span class="<?php echo $corpusVisible ? 'corpus-coordonnee__intitule' : 'visuellement-cache'; ?>"><?php echo $intitule; ?></span>
			<span class="<?php echo $classe; ?>"><?php echo $valeur; ?></span>
		</div>
	</li>
    <?php
};

// L'adresse postale tient sur une seule ligne de liste, ses composantes
// separees par des retours : c'est UNE information, pas cinq.
$corpusAdresse = [];

if ($this->item->address && $this->params->get('show_street_address')) {
    $corpusAdresse[] = nl2br($this->item->address, false);
}

if ($this->item->suburb && $this->params->get('show_suburb')) {
    $corpusAdresse[] = $this->escape($this->item->suburb);
}

if ($this->item->state && $this->params->get('show_state')) {
    $corpusAdresse[] = $this->escape($this->item->state);
}

if ($this->item->postcode && $this->params->get('show_postcode')) {
    $corpusAdresse[] = $this->escape($this->item->postcode);
}

if ($this->item->country && $this->params->get('show_country')) {
    $corpusAdresse[] = $this->escape($this->item->country);
}

$corpusTelLien = static function ($numero) {
    return preg_replace('/[^0-9+]/', '', $numero);
};
?>
<ul class="corpus-coordonnees com-contact__address contact-address">

	<?php if ($this->params->get('address_check') > 0 && $corpusAdresse) : ?>
	<?php $corpusLigne('i-lieu', Text::_('COM_CONTACT_ADDRESS'), implode('<br>', $corpusAdresse), 'contact-street'); ?>
	<?php endif; ?>

	<?php if ($this->item->email_to && $this->params->get('show_email')) : ?>
	<?php $corpusLigne('i-contact', Text::_('COM_CONTACT_EMAIL_LABEL'), $this->item->email_to, 'contact-emailto'); ?>
	<?php endif; ?>

	<?php if ($this->item->telephone && $this->params->get('show_telephone')) : ?>
	<?php $corpusLigne(
        'i-telephone',
        Text::_('COM_CONTACT_TELEPHONE'),
        '<a href="tel:' . $corpusTelLien($this->item->telephone) . '">' . $this->escape($this->item->telephone) . '</a>',
        'contact-telephone'
    ); ?>
	<?php endif; ?>

	<?php if ($this->item->mobile && $this->params->get('show_mobile')) : ?>
	<?php $corpusLigne(
        'i-telephone',
        Text::_('COM_CONTACT_MOBILE'),
        '<a href="tel:' . $corpusTelLien($this->item->mobile) . '">' . $this->escape($this->item->mobile) . '</a>',
        'contact-mobile'
    ); ?>
	<?php endif; ?>

	<?php if ($this->item->fax && $this->params->get('show_fax')) : ?>
	<?php $corpusLigne('i-imprimer', Text::_('COM_CONTACT_FAX'), $this->escape($this->item->fax), 'contact-fax'); ?>
	<?php endif; ?>

	<?php if ($this->item->webpage && $this->params->get('show_webpage')) : ?>
	<?php $corpusLigne(
        'i-lien',
        Text::_('COM_CONTACT_WEBPAGE'),
        '<a href="' . $this->escape($this->item->webpage) . '" target="_blank" rel="noopener noreferrer">'
            . $this->escape(PunycodeHelper::urlToUTF8($this->item->webpage))
            . '<span class="visuellement-cache"> ' . Text::_('TPL_CORPUS_NOUVELLE_FENETRE') . '</span></a>',
        'contact-webpage'
    ); ?>
	<?php endif; ?>
</ul>
