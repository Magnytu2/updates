<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE FORMULAIRE DE CONTACT
 *
 * Une seule chose change : l'intitule du bouton d'envoi.
 *
 * Le coeur ecrit « Envoyer ». Un bouton doit dire ce qu'il fait, et « Envoyer »
 * ne dit pas quoi — c'est le meme defaut que « Cliquez ici » pour un lien.
 * Sur une page qui peut en compter plusieurs, hors contexte, il ne se comprend
 * pas. RGAA 11.9 : l'intitule d'un bouton doit etre pertinent.
 *
 * On ne peut pas corriger cela par une cle de langue : `COM_CONTACT_CONTACT_SEND`
 * appartient au composant, pas au template, et une surcharge de langue serait
 * un reglage de plus a refaire sur chaque site. Le gabarit est le bon endroit.
 *
 * Le reste — les fieldsets, le captcha, les champs caches, le jeton — est
 * repris du coeur sans y toucher.
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/** @var \Joomla\Component\Contact\Site\View\Contact\HtmlView $this */
$wa = $this->getDocument()->getWebAssetManager();
$wa->useScript('keepalive')
    ->useScript('form.validate');

?>
<div class="com-contact__form contact-form">
	<form id="contact-form" action="<?php echo Route::_('index.php'); ?>" method="post" class="form-validate">

		<?php foreach ($this->form->getFieldsets() as $fieldset) : ?>
			<?php if ($fieldset->name === 'captcha' && $this->captchaEnabled) : ?>
				<?php continue; ?>
			<?php endif; ?>

			<?php $fields = $this->form->getFieldset($fieldset->name); ?>
			<?php if (count($fields)) : ?>
			<fieldset>
				<?php if (isset($fieldset->label) && ($legende = trim(Text::_($fieldset->label))) !== '') : ?>
				<legend><?php echo $legende; ?></legend>
				<?php endif; ?>

				<?php foreach ($fields as $field) : ?>
				<?php echo $field->renderField(); ?>
				<?php endforeach; ?>
			</fieldset>
			<?php endif; ?>
		<?php endforeach; ?>

		<?php if ($this->captchaEnabled) : ?>
		<?php echo $this->form->renderFieldset('captcha'); ?>
		<?php endif; ?>

		<div class="boutons">
			<button class="bouton validate" type="submit"><?php echo Text::_('TPL_CORPUS_ENVOYER_LE_MESSAGE'); ?></button>
		</div>

		<input type="hidden" name="option" value="com_contact">
		<input type="hidden" name="task" value="contact.submit">
		<input type="hidden" name="return" value="<?php echo $this->return_page; ?>">
		<input type="hidden" name="id" value="<?php echo $this->item->slug; ?>">
		<?php echo HTMLHelper::_('form.token'); ?>
	</form>
</div>
