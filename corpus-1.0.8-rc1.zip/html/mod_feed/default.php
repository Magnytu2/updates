<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * FIL D'ACTUALITE — mod_feed
 *
 * Ecrit le 4 aout 2026, apres publication du module par Cyrille. Le gabarit du
 * coeur n'a pas ete revu depuis longtemps et porte quatre defauts qu'on ne
 * peut pas corriger a la feuille de style.
 *
 * 1. DES NIVEAUX DE TITRE FAUX. Il sort le nom du flux en `<h2>` et sa date en
 *    `<h3>`, a l'interieur d'un module dont le titre est deja un `<h3>`. On
 *    obtient donc un `<h2>` SOUS un `<h3>` : la structure du document devient
 *    fausse, et c'est elle qui sert a naviguer au lecteur d'ecran. Le nom du
 *    flux n'est d'ailleurs pas un titre de section — c'est un lien vers la
 *    source. Il sort ici en paragraphe, et la date en `<time>`.
 *
 * 2. UN STYLE EN LIGNE `direction:` et les classes `text-left` / `text-right`
 *    de Bootstrap, que Corpus ne charge pas. L'attribut `dir` fait le meme
 *    travail, il est standard, et il est lu par les outils d'assistance.
 *
 * 3. LES DATES EN `DATE_FORMAT_LC3`, alors que tout Corpus ecrit ses dates au
 *    format `TPL_CORPUS_DATE_COURTE`. Un site qui ecrit ses dates de deux facons
 *    selon le module donne le sentiment que personne ne le tient.
 *
 * 4. LE MESSAGE D'ERREUR EN `<div>` NU. Quand le flux ne repond pas — c'est le
 *    cas sur un poste sans acces reseau — le module ecrit une phrase perdue
 *    dans le cadre. Elle passe par notre bloc `.message`, comme partout
 *    ailleurs.
 *
 * LES LIENS S'OUVRENT DANS UN NOUVEL ONGLET, et c'est le coeur qui le decide.
 * Corpus le signale : le pictogramme d'ouverture externe est pose
 * automatiquement sur `a[target="_blank"]`, il n'y a rien a ecrire ici.
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\Filter\OutputFilter;

$corpusMessage = static function (string $texte): void {
    ?>
	<div class="message message--info filet" role="note">
		<div><p><?php echo $texte; ?></p></div>
	</div>
	<?php
};

if (empty($rssurl)) {
    $corpusMessage(Text::_('MOD_FEED_ERR_NO_URL'));

    return;
}

// Le coeur peut renvoyer une chaine deja rendue (cache) : on la ressort telle
// quelle, il n'y a rien a redessiner.
if (!empty($feed) && is_string($feed)) {
    echo $feed;

    return;
}

if ($feed === false) {
    $corpusMessage(Text::_('MOD_FEED_ERR_FEED_NOT_RETRIEVED'));

    return;
}

// `rssrtl` : 0 suit la langue, 1 force la gauche-a-droite, 2 force l'inverse.
$corpusRtl = match ((int) $params->get('rssrtl', 0)) {
    1       => false,
    2       => true,
    default => $app->getLanguage()->isRtl(),
};

$corpusDate = static fn ($date): string => HTMLHelper::_('date', $date, Text::_('TPL_CORPUS_DATE_COURTE'));

?>
<div class="mod-feed" dir="<?php echo $corpusRtl ? 'rtl' : 'ltr'; ?>">

	<?php if ($feed->title !== null && $params->get('rsstitle', 1)) : ?>
	<p class="mod-feed__source">
		<a href="<?php echo htmlspecialchars($rssurl, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener">
			<?php echo htmlspecialchars($feed->title, ENT_QUOTES, 'UTF-8'); ?>
		</a>
	</p>
	<?php endif; ?>

	<?php if ($params->get('rssdate', 1) && $feed->publishedDate !== null) : ?>
	<time class="mod-feed__date" datetime="<?php echo HTMLHelper::_('date', $feed->publishedDate, 'Y-m-d'); ?>">
		<?php echo $corpusDate($feed->publishedDate); ?>
	</time>
	<?php endif; ?>

	<?php if ($params->get('rssdesc', 1) && $feed->description) : ?>
	<div class="mod-feed__description"><?php echo $feed->description; ?></div>
	<?php endif; ?>

	<?php if ($feed->image && $params->get('rssimage', 1)) : ?>
	<div class="mod-feed__image"><?php echo HTMLHelper::_('image', $feed->image->uri, $feed->image->title); ?></div>
	<?php endif; ?>

	<ul class="mod-feed__liste">
	<?php for ($i = 0, $max = min(count($feed), (int) $params->get('rssitems', 3)); $i < $max; $i++) : ?>
		<?php
        $uri = $feed[$i]->uri || !$feed[$i]->isPermaLink ? trim($feed[$i]->uri) : trim($feed[$i]->guid);
        $uri = !$uri || stripos($uri, 'http') !== 0 ? $rssurl : $uri;

        $texte = $feed[$i]->content !== '' ? trim($feed[$i]->content) : '';
        $titre = htmlspecialchars(trim($feed[$i]->title), ENT_QUOTES, 'UTF-8');
        ?>
		<li>
			<?php if (!empty($uri)) : ?>
			<a class="mod-feed__titre" href="<?php echo htmlspecialchars($uri, ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener"><?php echo $titre; ?></a>
			<?php else : ?>
			<span class="mod-feed__titre"><?php echo $titre; ?></span>
			<?php endif; ?>

			<?php if ($params->get('rssitemdate', 0) && $feed[$i]->publishedDate !== null) : ?>
			<time class="date" datetime="<?php echo HTMLHelper::_('date', $feed[$i]->publishedDate, 'Y-m-d'); ?>">
				<?php echo $corpusDate($feed[$i]->publishedDate); ?>
			</time>
			<?php endif; ?>

			<?php if ($params->get('rssitemdesc', 1) && $texte !== '') : ?>
			<div class="mod-feed__extrait">
				<?php
                // Les images du flux sont retirees : elles viennent d'un site
                // qu'on ne maitrise pas, a des tailles qu'on ne connait pas.
                $texte = OutputFilter::stripImages($texte);
                $texte = HTMLHelper::_('string.truncate', $texte, (int) $params->get('word_count', 0));
                echo str_replace('&apos;', "'", $texte);
                ?>
			</div>
			<?php endif; ?>
		</li>
	<?php endfor; ?>
	</ul>
</div>
