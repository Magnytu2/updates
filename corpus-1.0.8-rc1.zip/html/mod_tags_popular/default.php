<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LES ETIQUETTES POPULAIRES
 *
 * Ecrit le 1er aout 2026. Demande de Cyrille : les memes etiquettes que sous
 * les articles, pictogramme compris.
 *
 * POURQUOI UNE SURCHARGE PLUTOT QUE DU CSS. Deux raisons, et la seconde est un
 * mur deja rencontre avec la liste des categories :
 *
 * 1. LE PICTOGRAMME EST DU BALISAGE. Corpus n'a pas de fonte d'icones : une
 *    etiquette porte un <svg><use>. Le coeur n'en produit aucun, et le
 *    dessiner en `mask` depuis la feuille ferait vivre DEUX etiquettes — celle
 *    des articles avec son <svg>, celle du module avec son masque. Deux
 *    dessins pour une seule forme divergent a la premiere retouche.
 *
 * 2. `badge bg-info` NE SE RATTRAPE PAS. Bootstrap ecrit
 *    `.bg-info { background-color: … !important }`. Aucune regle de Corpus ne
 *    peut gagner sans un `!important` de plus. On enleve la classe a la
 *    source, comme pour les categories.
 *
 * Le compteur passe DANS le lien : hors du lien, il se lit « Olive » puis
 * « 4 » sans rapport dit entre les deux, et il n'est pas cliquable alors qu'il
 * touche l'etiquette. Son intitule complet reste annonce aux lecteurs
 * d'ecran ; c'est le texte visible qu'on abrege.
 *
 * Le reste — la route, l'echappement, le message de liste vide — est repris du
 * coeur sans y toucher.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\Component\Tags\Site\Helper\RouteHelper;

?>
<div class="mod-tagspopular tagspopular">
<?php if (!count($list)) : ?>
	<div class="message filet message--info" role="note">
		<div>
			<p class="message__titre"><?php echo Text::_('INFO'); ?></p>
			<p><?php echo Text::_('MOD_TAGS_POPULAR_NO_ITEMS_FOUND'); ?></p>
		</div>
	</div>
<?php else : ?>
	<ul class="etiquettes">
	<?php foreach ($list as $item) : ?>
		<li>
			<a class="etiquette" href="<?php echo Route::_(RouteHelper::getComponentTagRoute($item->tag_id . ':' . $item->alias, $item->language)); ?>">
				<svg class="i--sm" aria-hidden="true" focusable="false"><use href="#i-etiquette" /></svg>
				<?php echo htmlspecialchars($item->title, ENT_COMPAT, 'UTF-8'); ?>
				<?php if (!empty($display_count)) : ?>
				<span class="etiquette__compte">
					<span aria-hidden="true">(<?php echo (int) $item->count; ?>)</span>
					<span class="visuellement-cache"><?php
						echo Text::plural('COM_TAGS_N_ITEMS_COUNTED', (int) $item->count); ?></span>
				</span>
				<?php endif; ?>
			</a>
		</li>
	<?php endforeach; ?>
	</ul>
<?php endif; ?>
</div>
