<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE FORMULAIRE DE CONNEXION
 *
 * Ecrit le 31 juillet 2026 depuis maquettes/front-corpus.html.
 *
 * Ce que le gabarit du coeur produisait, et qu'on ne garde pas :
 *
 *   - `.form-control`, `.input-group`, `.btn btn-primary` : le dessin de
 *     Bootstrap. Corpus a le sien — `.champ`, `.bouton`.
 *   - `.icon-user`, `.icon-eye`, `.icon-register` : des <span> vides qui
 *     attendent FontAwesome. Retire du template, ce sont des carres vides.
 *     Nos pictogrammes dessines les remplacent.
 *   - le libelle en `visually-hidden` derriere un `placeholder` : un
 *     placeholder n'est PAS un libelle. Il disparait des qu'on saisit, il ne
 *     survit pas au zoom, et son contraste est faible par nature.
 *     RGAA 11.1 — chaque champ porte ici un <label> VISIBLE.
 *
 * Le bouton d'affichage du mot de passe garde `input-password-toggle` : c'est
 * le script du coeur (`field.passwordview`) qui s'y accroche. On change le
 * dessin, pas le comportement.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Router\Route;

$app->getDocument()->getWebAssetManager()
    ->useScript('core')
    ->useScript('keepalive')
    ->useScript('field.passwordview');

Text::script('JSHOWPASSWORD');
Text::script('JHIDEPASSWORD');

$idUtilisateur = 'modlgn-username-' . $module->id;
$idMotDePasse  = 'modlgn-passwd-' . $module->id;

?>
<form id="login-form-<?php echo $module->id; ?>" class="corpus-connexion" action="<?php echo Route::_('index.php', true); ?>" method="post">

	<?php if ($params->get('pretext')) : ?>
	<p class="mention"><?php echo $params->get('pretext'); ?></p>
	<?php endif; ?>

	<div class="champ">
		<label for="<?php echo $idUtilisateur; ?>"><?php echo Text::_('MOD_LOGIN_VALUE_USERNAME'); ?></label>
		<input id="<?php echo $idUtilisateur; ?>" type="text" name="username" autocomplete="username">
	</div>

	<div class="champ champ--mdp">
		<label for="<?php echo $idMotDePasse; ?>"><?php echo Text::_('JGLOBAL_PASSWORD'); ?></label>
		<div class="champ__groupe">
			<input id="<?php echo $idMotDePasse; ?>" type="password" name="password" autocomplete="current-password">
			<?php // input-password-toggle est impose par le script du coeur. ?>
			<button type="button" class="revele input-password-toggle">
				<svg class="i" aria-hidden="true" focusable="false"><use href="#i-oeil" /></svg>
				<span class="visuellement-cache"><?php echo Text::_('JSHOWPASSWORD'); ?></span>
			</button>
		</div>
	</div>

	<?php if (PluginHelper::isEnabled('system', 'remember')) : ?>
	<div class="champ champ--case">
		<input type="checkbox" name="remember" value="yes" id="form-login-input-remember-<?php echo $module->id; ?>">
		<label for="form-login-input-remember-<?php echo $module->id; ?>"><?php echo Text::_('MOD_LOGIN_REMEMBER_ME'); ?></label>
	</div>
	<?php endif; ?>

	<?php // Boutons ajoutes par les plugins d'authentification (WebAuthn, etc.) ?>
	<?php foreach ($extraButtons as $button) : ?>
		<?php
		$clesData = array_filter(array_keys($button), static function ($cle) {
			return str_starts_with($cle, 'data-');
		});
		?>
	<div class="boutons">
		<button type="button" class="bouton bouton--second bouton--large <?php echo $button['class'] ?? ''; ?>"
			<?php foreach ($clesData as $cle) : ?>
			<?php echo $cle; ?>="<?php echo $button[$cle]; ?>"
			<?php endforeach; ?>
			<?php if ($button['onclick']) : ?>
			onclick="<?php echo $button['onclick']; ?>"
			<?php endif; ?>
			id="<?php echo $button['id']; ?>">
			<?php if (!empty($button['image'])) : ?>
			<?php echo $button['image']; ?>
			<?php elseif (!empty($button['svg'])) : ?>
			<?php echo $button['svg']; ?>
			<?php endif; ?>
			<?php echo Text::_($button['label']); ?>
		</button>
	</div>
	<?php endforeach; ?>

	<div class="boutons">
		<button type="submit" name="Submit" class="bouton bouton--large"><?php echo Text::_('JLOGIN'); ?></button>
	</div>

	<?php $reglagesUtilisateurs = ComponentHelper::getParams('com_users'); ?>
	<ul class="liste-liens">
		<li><a href="<?php echo Route::_('index.php?option=com_users&view=reset'); ?>"><?php echo Text::_('MOD_LOGIN_FORGOT_YOUR_PASSWORD'); ?></a></li>
		<li><a href="<?php echo Route::_('index.php?option=com_users&view=remind'); ?>"><?php echo Text::_('MOD_LOGIN_FORGOT_YOUR_USERNAME'); ?></a></li>
		<?php if ($reglagesUtilisateurs->get('allowUserRegistration')) : ?>
		<li>
			<a href="<?php echo Route::_($registerLink); ?>">
				<svg class="i--sm" aria-hidden="true" focusable="false"><use href="#i-utilisateur" /></svg>
				<?php echo Text::_('MOD_LOGIN_REGISTER'); ?>
			</a>
		</li>
		<?php endif; ?>
	</ul>

	<input type="hidden" name="option" value="com_users">
	<input type="hidden" name="task" value="user.login">
	<input type="hidden" name="return" value="<?php echo $return; ?>">
	<?php echo HTMLHelper::_('form.token'); ?>

	<?php if ($params->get('posttext')) : ?>
	<p class="mention"><?php echo $params->get('posttext'); ?></p>
	<?php endif; ?>
</form>
