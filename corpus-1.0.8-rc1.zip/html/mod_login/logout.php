<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE MODULE DE CONNEXION, UNE FOIS CONNECTE.
 *
 * Meme raison d'etre que default.php : le gabarit du coeur sort le dessin de
 * Bootstrap et des <span class="icon-..."> vides. Corpus a le sien.
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

?>
<form id="login-form-<?php echo $module->id; ?>" class="corpus-connexion" action="<?php echo Route::_('index.php', true); ?>" method="post">

	<?php if ($params->get('pretext')) : ?>
	<p class="mention"><?php echo $params->get('pretext'); ?></p>
	<?php endif; ?>

	<?php if ($params->get('greeting')) : ?>
	<p class="corpus-connexion__bonjour">
		<svg class="i" aria-hidden="true" focusable="false"><use href="#i-utilisateur" /></svg>
		<?php if ($params->get('name', 0) == 0) : ?>
		<?php echo Text::sprintf('MOD_LOGIN_HINAME', htmlspecialchars($user->get('name'), ENT_QUOTES, 'UTF-8')); ?>
		<?php else : ?>
		<?php echo Text::sprintf('MOD_LOGIN_HINAME', htmlspecialchars($user->get('username'), ENT_QUOTES, 'UTF-8')); ?>
		<?php endif; ?>
	</p>
	<?php endif; ?>

	<div class="boutons">
		<button type="submit" name="Submit" class="bouton bouton--second"><?php echo Text::_('JLOGOUT'); ?></button>
	</div>

	<input type="hidden" name="option" value="com_users">
	<input type="hidden" name="task" value="user.menulogout">
	<?php if ($return) : ?>
	<input type="hidden" name="return" value="<?php echo $return; ?>">
	<?php endif; ?>
	<?php echo HTMLHelper::_('form.token'); ?>

	<?php if ($params->get('posttext')) : ?>
	<p class="mention"><?php echo $params->get('posttext'); ?></p>
	<?php endif; ?>
</form>
