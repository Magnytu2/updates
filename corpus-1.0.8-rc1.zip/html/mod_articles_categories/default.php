<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * ARTICLES - CATEGORIES
 *
 * Ecrit le 4 aout 2026, apres releve du rendu sur localhost:8090/demarches.
 *
 * Le gabarit du coeur sort le nombre d'articles COLLE AU TITRE, dans le meme
 * lien et sans balise autour :
 *
 *     <a href="...">Oliviers                            (2)</a>
 *
 * Deux consequences, et aucune n'est affaire de gout :
 *
 * 1. RIEN A STYLER. Le nombre est du texte nu au milieu d'une chaine : aucune
 *    feuille de style ne peut l'alleger, le decaler ou l'aligner. Toutes nos
 *    listes laterales alignent leur information secondaire a droite — la date
 *    des articles lies, le compte des etiquettes. Celle-ci ne le pouvait pas.
 *
 * 2. UN LECTEUR D'ECRAN ANNONCE « Oliviers 2 ». Deux quoi ? Le nombre est
 *    lisible a l'oeil parce que les parentheses le detachent, mais les
 *    parentheses ne s'entendent pas. Meme correction que pour les etiquettes
 *    populaires : le chiffre reste visible, son intitule complet est annonce.
 *
 * `.liste-liens` est la classe de nos listes : filet de separation, pas de
 * puce, titre a gauche et mention a droite. C'est celle des articles lies.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

if (!$list) {
    return;
}

?>
<ul class="liste-liens mod-articlescategories categories-module">
<?php require ModuleHelper::getLayoutPath('mod_articles_categories', $params->get('layout', 'default') . '_items'); ?>
</ul>
