<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * ARTICLES - CATEGORIES, les entrees.
 *
 * Ce fichier s'appelle lui-meme pour les sous-categories : c'est le mecanisme
 * du coeur, on le garde tel quel. `$list` est empile puis restaure autour de
 * l'appel — y toucher casserait la recursion.
 *
 * L'ETAT « ACTIF » PASSE SUR LE LIEN. Le coeur pose `class="active"` sur le
 * `<li>`. Une classe ne dit rien a un lecteur d'ecran : `aria-current="page"`
 * si, et c'est ce que fait deja notre menu. La classe reste — elle sert au
 * dessin.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\Component\Content\Site\Helper\RouteHelper;

$app    = $app ?? Factory::getApplication();
$input  = $app->getInput();
$option = $input->getCmd('option');
$view   = $input->getCmd('view');
$id     = $input->getInt('id');

foreach ($list as $item) :
    $actif = ($id == $item->id && in_array($view, ['category', 'categories'], true) && $option === 'com_content');
    ?>
	<li<?php echo $actif ? ' class="active"' : ''; ?>>
		<a href="<?php echo Route::_(RouteHelper::getCategoryRoute($item->id, $item->language)); ?>"<?php echo $actif ? ' aria-current="page"' : ''; ?>>
			<span><?php echo htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8'); ?></span>
			<?php if ($params->get('numitems')) : ?>
			<?php // Le chiffre reste visible entre parentheses ; l'intitule
			      // complet part au lecteur d'ecran, qui n'entend pas les
			      // parentheses. ?>
			<span class="compte">
				<span aria-hidden="true">(<?php echo (int) $item->numitems; ?>)</span>
				<span class="visuellement-cache"><?php
					echo Text::plural('TPL_CORPUS_N_ARTICLES', (int) $item->numitems); ?></span>
			</span>
			<?php endif; ?>
		</a>

		<?php if ($params->get('show_description', 0)) : ?>
		<div class="mod-articlescategories__description">
			<?php echo HTMLHelper::_('content.prepare', $item->description, $item->getParams(), 'mod_articles_categories.content'); ?>
		</div>
		<?php endif; ?>

		<?php
        if (
            $params->get('show_children', 0)
            && (($params->get('maxlevel', 0) == 0) || ($params->get('maxlevel') >= ($item->level - $startLevel)))
            && count($item->getChildren())
        ) : ?>
		<ul class="liste-liens liste-liens--enfants">
			<?php
            $temp = $list;
            $list = $item->getChildren();
            require ModuleHelper::getLayoutPath('mod_articles_categories', $params->get('layout', 'default') . '_items');
            $list = $temp;
            ?>
		</ul>
		<?php endif; ?>
	</li>
<?php endforeach; ?>
