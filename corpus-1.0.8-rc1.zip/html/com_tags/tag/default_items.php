<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LES ELEMENTS D'UNE ETIQUETTE
 *
 * Ecrit le 1er aout 2026. Cyrille : « j'ai toujours trouve ca nul d'arriver
 * sur un tableau ».
 *
 * MESURE D'ABORD : ce n'est PAS un tableau. Joomla 6 sort un
 * `<ul class="list-group">` de `<li>` contenant un `<h3>` et un lien, et rien
 * d'autre — ni image, ni texte. Une liste de titres nus ressemble a un
 * tableau, mais le probleme n'est pas la balise : c'est qu'il n'y a rien a
 * regarder.
 *
 * Ce gabarit sort donc LE MEME BALISAGE QUE LA VUE BLOG :
 *
 *     .blog-items > .blog-item > figure.item-image + .item-content
 *
 * Consequence directe : la page d'etiquette herite de tout ce qui a ete ecrit
 * pour le blog — la carte, la mise en colonnes, `image-left`, `no-card`, le
 * pied colle en bas. Aucune ligne de CSS a ajouter, et une seule forme a
 * maintenir.
 *
 * DEUX REGLAGES A ACTIVER, sans quoi il n'y a toujours rien a montrer :
 * « Afficher l'image de l'element » et « Afficher la description de
 * l'element », dans les options de com_tags ou dans le lien de menu.
 *
 * Le formulaire de filtre et le selecteur de nombre restent : ils sont
 * optionnels et l'auteur du site peut les vouloir.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Tags\Site\Helper\RouteHelper;

/** @var \Joomla\Component\Tags\Site\View\Tag\HtmlView $this */
$this->getDocument()->getWebAssetManager()->useScript('com_tags.tag-default');

/*
 * LES DEUX REGLAGES SONT CEUX DU TEMPLATE, pas du composant.
 *
 * com_tags n'offre aucun champ de classe ni de mise en page : demande de
 * Cyrille, 1er aout 2026. Ils vivent donc dans le Theme Customizer, groupe
 * « Pages d'etiquette ».
 *
 * `getTemplate(true)` rend le style actif AVEC ses parametres. Sans le `true`,
 * on n'obtient que le nom — c'est le genre d'oubli qui rend un reglage muet
 * sans rien signaler.
 */
$corpusTpl    = Factory::getApplication()->getTemplate(true)->params;
$corpusVue    = $corpusTpl->get('tagsVue', 'blog');
$corpusClasse = trim('blog-items com-tags__items ' . $corpusTpl->get('tagsClasse', 'columns-3'));

// « Native » : on rend le gabarit du coeur, sans y toucher. C'est une porte de
// sortie, pas un demi-dessin — un site qui n'en veut pas doit retrouver
// exactement ce que Joomla produit.
if ($corpusVue !== 'blog') {
    require JPATH_SITE . '/components/com_tags/tmpl/tag/default_items.php';
    return;
}
?>
<?php if ($this->params->get('filter_field') || $this->params->get('show_pagination_limit')) : ?>
<form action="<?php echo htmlspecialchars(Uri::getInstance()->toString(), ENT_QUOTES, 'UTF-8'); ?>" method="post" name="adminForm" id="adminForm" class="corpus-filtre">

	<?php if ($this->params->get('filter_field')) : ?>
	<div class="champ">
		<label for="filter-search"><?php echo Text::_('COM_TAGS_TITLE_FILTER_LABEL'); ?></label>
		<div class="recherche">
			<input type="text" name="filter-search" id="filter-search"
				value="<?php echo $this->escape($this->state->get('list.filter')); ?>">
			<button type="submit" name="filter_submit" class="bouton"><?php echo Text::_('JGLOBAL_FILTER_BUTTON'); ?></button>
		</div>
	</div>
	<?php endif; ?>

	<?php if ($this->params->get('show_pagination_limit')) : ?>
	<div class="champ">
		<label for="limit"><?php echo Text::_('JGLOBAL_DISPLAY_NUM'); ?></label>
		<?php echo $this->pagination->getLimitBox(); ?>
	</div>
	<?php endif; ?>

	<input type="hidden" name="limitstart" value="">
	<input type="hidden" name="task" value="">
</form>
<?php endif; ?>

<?php if (empty($this->items)) : ?>
<div class="message filet message--info" role="note">
	<div>
		<p class="message__titre"><?php echo Text::_('INFO'); ?></p>
		<p><?php echo Text::_('COM_TAGS_NO_ITEMS'); ?></p>
	</div>
</div>
<?php else : ?>
<div class="<?php echo trim($corpusClasse); ?>">
	<?php foreach ($this->items as $corpusItem) : ?>
		<?php
		$corpusImages = json_decode((string) $corpusItem->core_images);
		$corpusLien   = Route::_(RouteHelper::getItemRoute(
			$corpusItem->content_item_id,
			$corpusItem->core_alias,
			$corpusItem->core_catid,
			$corpusItem->core_language,
			$corpusItem->type_alias,
			$corpusItem->router
		));

		// Les categories de com_users et com_banners n'ont pas de page a
		// elles : leur titre reste du texte, il ne devient pas un lien mort.
		$corpusSansLien = in_array($corpusItem->type_alias, ['com_users.category', 'com_banners.category'], true);
		?>
	<div class="com-tags-tag__item blog-item">

		<?php if ($this->params->get('tag_list_show_item_image', 1) && !empty($corpusImages->image_intro)) : ?>
		<figure class="item-image">
			<?php // L'image ne porte pas de lien : le titre le porte deja, et
			      // deux liens vers la meme page se tabulent deux fois. RGAA 6.1. ?>
			<?php echo HTMLHelper::_('image', $corpusImages->image_intro, $corpusImages->image_intro_alt ?? ''); ?>
		</figure>
		<?php endif; ?>

		<div class="item-content">
			<div class="page-header">
				<h2>
					<?php if ($corpusSansLien) : ?>
					<?php echo $this->escape($corpusItem->core_title); ?>
					<?php else : ?>
					<a href="<?php echo $corpusLien; ?>"><?php echo $this->escape($corpusItem->core_title); ?></a>
					<?php endif; ?>
				</h2>
			</div>

			<?php if ($corpusItem->core_state == 0) : ?>
			<p><span class="etiquette"><?php echo Text::_('JUNPUBLISHED'); ?></span></p>
			<?php endif; ?>

			<?php echo $corpusItem->event->afterDisplayTitle; ?>

			<?php if ($this->params->get('tag_list_show_item_description', 1)) : ?>
			<?php echo $corpusItem->event->beforeDisplayContent; ?>
			<p><?php echo HTMLHelper::_(
                'string.truncate',
                $corpusItem->core_body,
                $this->params->get('tag_list_item_maximum_characters')
            ); ?></p>
			<?php echo $corpusItem->event->afterDisplayContent; ?>
			<?php endif; ?>
		</div>
	</div>
	<?php endforeach; ?>
</div>
<?php endif; ?>
