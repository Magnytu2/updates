<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * ARTICLES LIES — « Sur le meme sujet »
 *
 * Ecrit le 1er aout 2026 depuis maquettes/front-corpus.html, § « Sur le meme
 * sujet ».
 *
 * Le gabarit du coeur produit une seule chaine par ligne :
 *
 *     01-08-2026 - Olives de table et leurs recettes
 *
 * Trois choses vont avec ce format, et aucune n'est un detail de gout :
 *
 * 1. LA DATE PASSE AVANT LE TITRE. C'est l'inverse de ce qu'on cherche dans
 *    une liste : on la parcourt par les titres, pas par les dates. Toutes les
 *    lignes commencent donc par la meme forme, et l'oeil doit sauter huit
 *    caracteres a chaque fois.
 *
 * 2. LE TIRET EST DU TEXTE. Un lecteur d'ecran annonce « zero un tiret zero
 *    huit tiret deux mille vingt-six tiret Olives de table ». La date se lit
 *    en entier avant qu'on sache de quel article il s'agit.
 *
 * 3. LE FORMAT DE DATE EST CELUI DE CORPUS, PARTOUT. `TPL_CORPUS_DATE_COURTE` —
 *    « 01/08/2026 ». Choix de Cyrille, 4 aout 2026, applique a toutes nos
 *    surcharges le meme jour : bloc d'informations d'article, archives, listes
 *    laterales. Un site qui ecrit ses dates de trois facons differentes selon
 *    la page donne le sentiment que personne ne le tient.
 *
 *    L'objection au numerique est reelle — « 01/08/2026 » ne se lit pas de la
 *    meme facon a Paris et a Chicago — et c'est pour ca que le format est une
 *    CHAINE DE LANGUE et non une constante : chaque langue porte son ordre.
 *    La date ISO reste doublee dans `datetime` pour les machines.
 *
 * Corpus sort donc le titre d'abord, et la date en fin de ligne, alignee a
 * droite, dans la taille des mentions. La maquette la donne abregee — « 28
 * juil. » — parce qu'elle ne doit pas concurrencer le titre.
 *
 * `.liste-liens` porte le filet de separation entre les lignes, sans puce.
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

if (!$list) {
    return;
}

?>
<ul class="liste-liens mod-relateditems">
<?php foreach ($list as $item) : ?>
	<li>
		<a href="<?php echo $item->route; ?>">
			<span><?php echo htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8'); ?></span>
			<?php if ($showDate) : ?>
			<?php
                // LA DATE EST COMPLETE, EN CHIFFRES. Choix de Cyrille, 4 aout
                // 2026, apres un essai en « 1 Août » qui abregeait le mois et
                // laissait tomber l'annee de l'annee en cours.
                //
                // Le motif de l'abreviation etait la place : « 1 Août 2026 »
                // occupait 86 px des 290 px de la ligne et faisait passer les
                // titres sur deux lignes. La forme numerique la reprend sans
                // rien perdre — meme information, moins de largeur.
                //
                // LE FORMAT EST UNE CHAINE DE LANGUE, PAS UNE CONSTANTE. Ecrire
                // `d/m/Y` en dur donnerait « 08/01/2026 » a un lecteur
                // americain, qui lirait le 8 janvier. Chaque langue porte son
                // ordre dans `TPL_CORPUS_DATE_COURTE`, et il se corrige sans
                // toucher au code.
                //
                // La date reste doublee en ISO dans `datetime` : c'est elle que
                // lisent les machines, et elle leve l'ambiguite pour de bon.
                ?>
			<time class="date" datetime="<?php echo HTMLHelper::_('date', $item->created, 'Y-m-d'); ?>"><?php
                echo HTMLHelper::_('date', $item->created, Text::_('TPL_CORPUS_DATE_COURTE'));
            ?></time>
			<?php endif; ?>
		</a>
	</li>
<?php endforeach; ?>
</ul>
