<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE CHROME « SANS CADRE » — l'equivalent du `noCard` de Cassiopeia.
 *
 * Ecrit le 1er aout 2026. Le sans-cadre existait deja, mais seulement par le
 * suffixe de classe `sans-cadre` : il fallait le savoir. Il se choisit
 * desormais dans la liste « Style du module », a cote de « card » et
 * « noCard », sous le groupe Corpus.
 *
 * Ce fichier ne dessine rien : il pose le reglage et passe la main au chrome
 * de Corpus. Une copie du gabarit aurait divergé a la premiere retouche.
 */

defined('_JEXEC') or die;

$corpusSansCadre = true;

require __DIR__ . '/encadre.php';
