<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE CHROME DE MODULE — « encadre »
 *
 * Reecrit le 31 juillet 2026 depuis maquettes/front-corpus.html.
 *
 * Le gabarit d'origine sortait quatre niveaux imbriques la ou deux suffisent,
 * sous des noms qui n'etaient pas les notres. Il portait aussi un `<span class="badge">` declenche par une
 * expression reguliere sur le suffixe de classe, et un `span{n}` de
 * Bootstrap 2, mort depuis Joomla 4.
 *
 * Ce que Corpus produit :
 *
 *     <div class="module module--encadre" id="Mod42">
 *       <h3 class="module__titre filet">Titre</h3>
 *       ...contenu...
 *     </div>
 *
 * LE CADRE EST LE DEFAUT. La maquette encadre quatre de ses six modules, et
 * le § 13 des regles de style l'ecrit noir sur blanc : mod_login et com_users
 * sortent en `.module--encadre`.
 *
 * La premiere version de ce gabarit faisait l'inverse — rien d'encadre sauf
 * demande explicite. C'etait substituer mon jugement a la maquette : le
 * reglage etait une bonne idee, son sens etait retourne. Corrige le 31 juillet
 * apres que Cyrille l'a vu a l'ecran.
 *
 * Le suffixe de classe du module reste le reglage de forme :
 *   ` sans-cadre`  retire le cadre, l'ombre et le fond ;
 *   ` sans-filet`  retire le filet du titre.
 *
 * DEUX CHROMES, UN SEUL FICHIER — 1er aout 2026. Cyrille cherchait l'equivalent
 * du `noCard` de Cassiopeia dans la liste « Style du module » et ne le trouvait
 * pas : le suffixe de classe marche, mais un reglage qu'on ne trouve pas est un
 * reglage qui n'existe pas. C'est la meme lecon que le champ `classes` du
 * gabarit de rangee, payee le 31 juillet.
 *
 * `sans-cadre.php` pose donc `$corpusSansCadre` et appelle ce fichier. Le code
 * n'est pas duplique : deux chromes qui divergeraient d'une version a l'autre
 * seraient pires que pas de chrome du tout.
 */

defined('_JEXEC') or die;

$module  = $displayData['module'];
$params  = $displayData['params'];
$attribs = $displayData['attribs'];

if ($module->content === null || $module->content === '') {
    return;
}

$moduleTag = htmlspecialchars($params->get('module_tag', 'div'), ENT_QUOTES, 'UTF-8');
$headerTag = htmlspecialchars($params->get('header_tag', 'h3'), ENT_QUOTES, 'UTF-8');

// Le suffixe de classe sert de reglage de forme. Les mots-cles reconnus sont
// retires de la liste : ils pilotent nos modificateurs, ils n'ont pas a se
// retrouver tels quels dans le document.
$suffixe = trim((string) $params->get('moduleclass_sfx', ''));
$mots    = $suffixe === '' ? [] : preg_split('/\s+/', $suffixe);

// Le chrome peut imposer le sans-cadre ; le suffixe de classe peut aussi le
// demander. L'un OU l'autre suffit — on ne demande jamais deux fois la meme
// chose a l'administrateur.
$sansCadre = !empty($corpusSansCadre) || in_array('sans-cadre', $mots, true);
$sansFilet = in_array('sans-filet', $mots, true);

$reste = array_diff($mots, ['sans-cadre', 'sans-filet']);
$reste = $reste ? ' ' . htmlspecialchars(implode(' ', $reste), ENT_QUOTES, 'UTF-8') : '';

$classes = 'module' . ($sansCadre ? '' : ' module--encadre') . $reste;

// Le titre porte le filet : c'est un TITRE, donc le filet suit son texte et
// non la colonne — width: fit-content, pose dans _typographie.scss.
//
// `header_class` — ajoute le 7 aout 2026. Joomla propose « Classe du titre »
// dans l'onglet Avance de chaque module, a cote de « Balise du titre ». Le
// chrome lisait la seconde et ignorait la premiere : l'administrateur reglait
// un champ qui ne faisait rien, sans que rien ne le dise. Cassiopeia le lit,
// nous non.
$classeTitre = 'module__titre' . ($sansFilet ? '' : ' filet');

$classeSaisie = trim((string) $params->get('header_class', ''));

if ($classeSaisie !== '') {
    $classeTitre .= ' ' . htmlspecialchars($classeSaisie, ENT_QUOTES, 'UTF-8');
}

$html = '<' . $moduleTag . ' class="' . $classes . '" id="Mod' . (int) $module->id . '">';

if ($module->showtitle != 0) {
    $html .= '<' . $headerTag . ' class="' . $classeTitre . '">' . $module->title . '</' . $headerTag . '>';
}

$html .= $module->content;
$html .= '</' . $moduleTag . '>';

echo $html;
