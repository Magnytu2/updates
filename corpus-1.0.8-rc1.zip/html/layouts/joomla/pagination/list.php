<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LA PAGINATION — le conteneur
 *
 * Une seule chose change par rapport au gabarit du coeur : `ms-0 mb-4` s'en
 * va. Ce sont deux utilitaires Bootstrap, et Bootstrap les ecrit en
 * `!important` — notre `.pagination { margin: 0 }` etait donc ecrit mais
 * PERDANT, et rien ne le signalait.
 *
 * On aurait pu repondre par un `!important` de plus. C'est exactement la
 * surenchere qui a fait rejeter le premier back-office : on corrige a la
 * source, la ou la classe est ecrite.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

$list = $displayData['list'];

?>
<nav class="pagination__wrapper" aria-label="<?php echo Text::_('JLIB_HTML_PAGINATION'); ?>">
	<ul class="pagination">
		<?php echo $list['start']['data']; ?>
		<?php echo $list['previous']['data']; ?>

		<?php foreach ($list['pages'] as $page) : ?>
			<?php echo $page['data']; ?>
		<?php endforeach; ?>

		<?php echo $list['next']['data']; ?>
		<?php echo $list['end']['data']; ?>
	</ul>
</nav>
