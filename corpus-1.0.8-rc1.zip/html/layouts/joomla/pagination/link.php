<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LA PAGINATION — un maillon
 *
 * Trois corrections, mesurees sur le banc le 1er aout 2026.
 *
 * 1. LES FLECHES ETAIENT INVISIBLES. Le coeur sort
 *    `<span class="icon-angle-left" aria-hidden="true"></span>` : un span vide
 *    qui attend une fonte d'icones. Corpus n'en charge aucune, et sa regle des
 *    icones orphelines masquait donc les quatre boutons. Ils occupaient leur
 *    place, portaient leur bordure, et ne montraient rien.
 *
 *    Nos pictogrammes dessines les remplacent. Les versions « droite » se
 *    font par rotation en CSS : deux symboles suffisent pour quatre boutons.
 *
 * 2. LA PAGE COURANTE ETAIT UN LIEN VERS `#`. Un lien qui ne mene nulle part
 *    est annonce comme un lien par le lecteur d'ecran, se tabule, et ne fait
 *    rien quand on l'active. Elle sort desormais en <span>, avec
 *    `aria-current="page"` — la valeur normalisee, `true` n'en est pas une.
 *
 * 3. LE LIBELLE ACCESSIBLE ETAIT EN MINUSCULES : `strtolower($item->text)`
 *    sur un numero de page ne sert a rien, et sur un intitule textuel il
 *    donne « aller a la page suivant ». Le texte passe tel quel.
 *
 * Le reste — le calcul des liens, le RTL, le contexte administrateur — est
 * celui du coeur, repris sans y toucher.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

$item    = $displayData['data'];
$display = $item->text;
$app     = Factory::getApplication();
$rtl     = $app->getLanguage()->isRtl();

/*
 * Le pictogramme et son intitule accessible. `$tourne` demande la rotation :
 * une seule paire de symboles sert aux quatre boutons.
 */
$picto  = null;
$tourne = false;

switch ((string) $item->text) {
    case Text::_('JLIB_HTML_START'):
        $picto  = 'i-chevron-gg';
        $tourne = $rtl;
        $aria   = Text::_('JLIB_HTML_GOTO_POSITION_START');
        break;

    case Text::_('JPREV'):
        $picto  = 'i-chevron-g';
        $tourne = $rtl;
        $aria   = Text::_('JLIB_HTML_GOTO_POSITION_PREVIOUS');
        break;

    case Text::_('JNEXT'):
        $picto  = 'i-chevron-g';
        $tourne = !$rtl;
        $aria   = Text::_('JLIB_HTML_GOTO_POSITION_NEXT');
        break;

    case Text::_('JLIB_HTML_END'):
        $picto  = 'i-chevron-gg';
        $tourne = !$rtl;
        $aria   = Text::_('JLIB_HTML_GOTO_POSITION_END');
        break;

    default:
        $aria = Text::sprintf('JLIB_HTML_GOTO_PAGE', $item->text);
        break;
}

if ($picto !== null) {
    $display = '<svg class="i--sm' . ($tourne ? ' i--retourne' : '')
        . '" aria-hidden="true" focusable="false"><use href="#' . $picto . '" /></svg>';
}

$courante = isset($item->active) && $item->active;

if ($displayData['active']) {
    $limit = 'limitstart.value=' . ($item->base > 0 ? (int) $item->base : 0);

    $lien = $app->isClient('administrator')
        ? 'href="#" onclick="document.adminForm.' . $item->prefix . $limit . '; Joomla.submitform();return false;"'
        : 'href="' . $item->link . '"';
}
?>
<?php if ($displayData['active']) : ?>
	<li class="page-item">
		<a class="page-link" aria-label="<?php echo $aria; ?>" <?php echo $lien; ?>><?php echo $display; ?></a>
	</li>
<?php elseif ($courante) : ?>
	<?php // La page courante ne se lie pas a elle-meme. ?>
	<li class="active page-item">
		<span class="page-link" aria-current="page"><?php echo $display; ?></span>
	</li>
<?php else : ?>
	<li class="disabled page-item">
		<span class="page-link" aria-hidden="true"><?php echo $display; ?></span>
	</li>
<?php endif; ?>
