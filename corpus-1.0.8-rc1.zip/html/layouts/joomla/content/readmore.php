<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE BOUTON « LIRE LA SUITE »
 *
 * Le gabarit du coeur sort `a.btn btn-secondary` et un
 * `<span class="icon-chevron-right">` qui attend FontAwesome — un carre vide
 * chez nous. Corpus sort `.bouton bouton--second` et sa fleche dessinee.
 *
 * Les quatre branches du coeur — inscription requise, libelle alternatif,
 * avec ou sans le titre — ne different que par le LIBELLE. On les ramene donc
 * a un seul rendu : la logique choisit le texte, le dessin ne change pas.
 * C'est ce qui rendait le gabarit d'origine long a lire pour quatre fois la
 * meme balise.
 *
 * `aria-label` porte le titre de l'article : hors contexte, « Lire la suite »
 * ne dit pas de quoi. RGAA 6.1 — un lien doit etre explicite pris seul.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

$item   = $displayData['item'];
$params = $displayData['params'];
$lien   = $displayData['link'];

// La fleche suit le sens de lecture de la langue.
$gauche = Factory::getLanguage()->isRtl();

if (!$params->get('access-view')) {
    $libelle = Text::_('JGLOBAL_REGISTER_TO_READ_MORE');
    $aria    = $libelle . ' ' . $this->escape($item->title);
} elseif ($readmore = $item->alternative_readmore) {
    $libelle = $readmore;

    if ($params->get('show_readmore_title', 0) != 0) {
        $libelle .= ' ' . HTMLHelper::_('string.truncate', $item->title, $params->get('readmore_limit'));
    }

    $aria = $this->escape($readmore . ' ' . $item->title);
} elseif ($params->get('show_readmore_title', 0) == 0) {
    $libelle = Text::_('JGLOBAL_READ_MORE');
    $aria    = Text::sprintf('JGLOBAL_READ_MORE_TITLE', $this->escape($item->title));
} else {
    $libelle = Text::sprintf('JGLOBAL_READ_MORE_TITLE', HTMLHelper::_('string.truncate', $item->title, $params->get('readmore_limit')));
    $aria    = Text::sprintf('JGLOBAL_READ_MORE_TITLE', $this->escape($item->title));
}

?>
<p class="readmore">
	<a class="bouton bouton--second" href="<?php echo $lien; ?>" aria-label="<?php echo $aria; ?>">
		<?php echo $libelle; ?>
		<svg class="i--sm" aria-hidden="true" focusable="false"><use href="#i-fleche<?php echo $gauche ? '-g' : ''; ?>" /></svg>
	</a>
</p>
