<?php
/**
 * @package     Joomla.Site
 * @subpackage  Layout
 *
 * @copyright   Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\Component\Content\Site\Helper\RouteHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
$item = $displayData['item'];
$title = $this->escape($item->category_title);
if (!isset($item->catslug)) {
	$item->catslug = $item->category_alias ? ($item->catid.':'.$item->category_alias) : $item->catid;
}
?>
			<dd class="category-name hasTooltip" title="<?php echo Text::sprintf('COM_CONTENT_CATEGORY', ''); ?>">
				<svg class="i--sm" aria-hidden="true" focusable="false"><use href="#i-dossier" /></svg>
				<?php if ($displayData['params']->get('link_category') && $item->catslug) : ?>
					<?php echo HTMLHelper::_('link', Route::_(RouteHelper::getCategoryRoute($item->catslug)), '<span itemprop="genre">'.$title.'</span>'); ?>
				<?php else : ?>
					<span itemprop="genre"><?php echo $title ?></span>
				<?php endif; ?>
			</dd>