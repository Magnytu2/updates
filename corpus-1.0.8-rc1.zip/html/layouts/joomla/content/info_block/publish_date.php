<?php
/**
 * @package     Joomla.Site
 * @subpackage  Layout
 *
 * @copyright   Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
?>
			<dd class="published hasTooltip" title="<?php echo Text::sprintf('COM_CONTENT_PUBLISHED_DATE_ON', ''); ?>">
				<svg class="i--sm" aria-hidden="true" focusable="false"><use href="#i-calendrier" /></svg>
				<time datetime="<?php echo HTMLHelper::_('date', $displayData['item']->publish_up, 'c'); ?>" itemprop="datePublished">
					<?php echo HTMLHelper::_('date', $displayData['item']->publish_up, Text::_('TPL_CORPUS_DATE_COURTE')); ?>
				</time>
			</dd>