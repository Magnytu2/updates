<?php
/**
 * @package     Joomla.Site
 * @subpackage  Layout
 *
 * @copyright   Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\Component\Content\Site\Helper\RouteHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

$item = $displayData['item'];
$params = $displayData['params'];
$title = $this->escape($item->parent_title);
?>
			<dd class="parent-category-name hasTooltip" title="<?php echo Text::sprintf('COM_CONTENT_PARENT', ''); ?>">
				<svg class="i--sm" aria-hidden="true" focusable="false"><use href="#i-dossier" /></svg>
				<?php if ($params->get('link_parent_category') && !empty($item->parent_slug)) : ?>
					<?php echo HTMLHelper::_('link', Route::_(RouteHelper::getCategoryRoute($item->parent_slug)), '<span itemprop="genre">'.$title.'</span>'); ?>
				<?php else : ?>
					<span itemprop="genre"><?php echo $title ?></span>
				<?php endif; ?>
			</dd>