<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LES ETIQUETTES
 *
 * Le gabarit du coeur sort `.tags list-inline` et des `a.btn btn-sm btn-info`
 * — un bouton Bootstrap cyan. Une etiquette n'est pas un bouton : elle
 * qualifie, elle ne declenche pas d'action. Corpus a `.etiquettes` / `.etiquette`.
 *
 * Le pictogramme d'etiquette accompagne chaque terme : il dit ce qu'est cette
 * liste de mots, la ou une simple pastille coloree laisserait deviner.
 *
 * Le parametre `tag_link_class` du coeur n'est plus lu : il ne servait qu'a
 * choisir une couleur de bouton Bootstrap, et Corpus n'en a qu'une.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\Component\Tags\Site\Helper\RouteHelper;

if (empty($displayData)) {
    return;
}

$autorises = Factory::getUser()->getAuthorisedViewLevels();

?>
<ul class="etiquettes">
	<span class="visuellement-cache"><?php echo Text::_('JTAG'); ?></span>
<?php foreach ($displayData as $i => $tag) : ?>
	<?php if (!in_array($tag->access, $autorises)) : ?>
		<?php continue; ?>
	<?php endif; ?>
	<li itemprop="keywords">
		<a class="etiquette" href="<?php echo Route::_(RouteHelper::getComponentTagRoute($tag->tag_id . ':' . $tag->alias, $tag->language)); ?>">
			<svg class="i--sm" aria-hidden="true" focusable="false"><use href="#i-etiquette" /></svg>
			<?php echo $this->escape($tag->title); ?>
		</a>
	</li>
<?php endforeach; ?>
</ul>
