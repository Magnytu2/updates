<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LES MESSAGES SYSTEME
 *
 * Ecrit le 31 juillet 2026 depuis maquettes/front-corpus.html.
 *
 * Le rendu par defaut de Joomla sort un <joomla-alert> avec les classes de
 * Bootstrap. Corpus produit son propre motif :
 *
 *   - pas de cadre, pas de trait a gauche : un fond pale, et le FILET a 70 %
 *     dans la couleur pleine. Le trait epais a gauche d'une boite arrondie est
 *     le motif Bootstrap qu'on voit partout, et un arrondi ne va pas avec une
 *     bordure d'un seul cote ;
 *   - le message garde donc son arrondi sur ses QUATRE coins ;
 *   - un PICTOGRAMME et un INTITULE ECRIT accompagnent toujours la couleur.
 *     C'est la regle RGAA qui compte ici : un daltonien doit distinguer un
 *     succes d'une erreur sans voir la couleur. Le pictogramme est
 *     aria-hidden, il double l'intitule, il ne le remplace pas.
 *
 * Le conteneur garde role="alert" et aria-live : c'est ce qui fait annoncer le
 * message par un lecteur d'ecran quand il apparait apres coup.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

/*
 * CE BLOC S'EXECUTE MEME QUAND IL N'Y A AUCUN MESSAGE. Ne pas le deplacer
 * sous le retour anticipe.
 *
 * DEFAUT MESURE LE 3 AOUT 2026, sur le formulaire de contact. La validation
 * du coeur s'arretait sur « Joomla.renderMessages is not a function », et le
 * message global (« des champs obligatoires sont vides ») n'apparaissait
 * jamais. La fonction vit dans l'asset « messages », que le gabarit du coeur
 * enregistre AVANT de tester si la liste est vide — lignes 45-47 de
 * layouts/joomla/system/message.php. Notre reecriture avait garde le rendu et
 * perdu cette ligne.
 *
 * Consequence reelle : sur une page sans message serveur — c'est-a-dire
 * presque toutes — le script de validation levait une exception au moment
 * d'afficher son alerte. Rien a l'ecran, rien dans le journal PHP. Encore une
 * panne silencieuse.
 *
 * La feuille du composant joomla-alert va avec : les messages ajoutes APRES
 * le chargement de la page sont fabriques en JavaScript, pas par ce gabarit.
 * Ils sortent donc en <joomla-alert> et non dans notre motif — a reprendre.
 */
Text::script('ERROR');
Text::script('MESSAGE');
Text::script('NOTICE');
Text::script('WARNING');
Text::script('JCLOSE');
Text::script('JOK');
Text::script('JOPEN');

// Les intitules de Corpus, pour les messages fabriques en JavaScript. Le motif
// est le meme des deux cotes : c'est template.js qui le construit a partir de
// ces chaines. Voir « Les messages fabriques en JavaScript » dans template.js.
Text::script('TPL_CORPUS_MSG_SUCCES');
Text::script('TPL_CORPUS_MSG_INFO');
Text::script('TPL_CORPUS_MSG_ALERTE');
Text::script('TPL_CORPUS_MSG_ERREUR');
Text::script('TPL_CORPUS_MSG_FERMER');

Factory::getDocument()->getWebAssetManager()
    ->useStyle('webcomponent.joomla-alert')
    ->useScript('messages');

$msgList = $displayData['msgList'] ?? [];

/*
 * PAS DE RETOUR ANTICIPE QUAND LA LISTE EST VIDE. Le conteneur sort TOUJOURS,
 * meme vide.
 *
 * Deuxieme mesure du 3 aout 2026, apres avoir remis l'asset « messages » :
 * la validation echouait toujours, un cran plus loin —
 * « Cannot read properties of null » dans Joomla.removeMessages. La fonction
 * commence par vider #system-message-container ; s'il n'existe pas, elle
 * casse, et le message global n'apparait jamais.
 *
 * Notre reecriture ne le sortait que s'il y avait quelque chose a mettre
 * dedans. C'est logique a la lecture, et faux : le conteneur n'est pas
 * l'emballage des messages du serveur, c'est LA PLACE RESERVEE a ceux que le
 * JavaScript ajoutera. Le gabarit du coeur le sort inconditionnellement,
 * derniere ligne du fichier.
 *
 * CE QU'ON NE REPREND PAS DU COEUR : son addScriptOptions('joomla.messages').
 * Il sert a faire re-dessiner les messages par le JavaScript ; comme nous les
 * rendons ici, cote serveur, ils apparaitraient DEUX FOIS.
 */

/*
 * Correspondance entre les types de Joomla et les notres.
 * Joomla emet : message, notice, warning, error — et « info » selon les
 * extensions. Tout type inconnu retombe sur l'information : mieux vaut un
 * message neutre qu'un message sans forme.
 */
$familles = [
    'message' => ['succes', 'i-succes', 'TPL_CORPUS_MSG_SUCCES'],
    'success' => ['succes', 'i-succes', 'TPL_CORPUS_MSG_SUCCES'],
    'notice'  => ['info',   'i-info',   'TPL_CORPUS_MSG_INFO'],
    'info'    => ['info',   'i-info',   'TPL_CORPUS_MSG_INFO'],
    'warning' => ['alerte', 'i-alerte', 'TPL_CORPUS_MSG_ALERTE'],
    'error'   => ['erreur', 'i-erreur', 'TPL_CORPUS_MSG_ERREUR'],
];

?>
<div id="system-message-container" aria-live="polite">
<?php foreach ($msgList as $type => $msgs) : ?>
	<?php
	$cle = strtolower((string) $type);
	[$famille, $picto, $intitule] = $familles[$cle] ?? $familles['info'];

	// role="alert" pour ce qui interrompt — erreur et avertissement — et
	// role="status" pour le reste : un succes ne doit pas couper la lecture.
	$role = in_array($famille, ['erreur', 'alerte'], true) ? 'alert' : 'status';
	?>
	<div class="message message--<?php echo $famille; ?> filet" role="<?php echo $role; ?>">
		<svg class="i" aria-hidden="true" focusable="false"><use href="#i-<?php echo substr($picto, 2); ?>" /></svg>

		<div>
			<p class="message__titre"><?php echo Text::_($intitule); ?></p>
			<?php foreach ($msgs as $msg) : ?>
			<p><?php echo $msg; ?></p>
			<?php endforeach; ?>
		</div>

		<button type="button" class="message__fermer"
			aria-label="<?php echo htmlspecialchars(Text::_('TPL_CORPUS_MSG_FERMER'), ENT_QUOTES, 'UTF-8'); ?>">
			<svg class="i" aria-hidden="true" focusable="false"><use href="#i-fermer" /></svg>
		</button>
	</div>
<?php endforeach; ?>
</div>
