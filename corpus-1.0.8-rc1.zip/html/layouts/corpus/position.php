<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * UNE RANGEE DE MODULES
 *
 * Rendu par $helper->spotlight(). Les positions de bande passent toutes par
 * ici : Top A a D, Bot A a D, le pied.
 *
 * Reecrit le 31 juillet 2026. Le gabarit herite sortait la grille de
 * Bootstrap — `container`, `row`, `col-lg-8` — et deux classes heritees,
 * `.section-title` et `.section-desc`, qui n'existent nulle part dans le SCSS
 * de Corpus. Une bande de modules n'avait donc ni la largeur utile du corps de
 * page, ni sa gouttiere, et son titre n'avait aucun dessin.
 *
 * Ce qui sort desormais, exactement comme la maquette :
 *
 *     <div id="top-a" class="section">
 *       <div class="page">
 *         <h2 class="filet">Titre</h2>
 *         <div class="grille">
 *           <div class="colonne-8">...</div>
 *           <div class="colonne-4">...</div>
 *
 * LE NIVEAU DU TITRE SE REGLE, depuis le 2 aout 2026 — demande de Cyrille :
 * garder une organisation LOGIQUE des titres selon ce que la bande porte.
 *
 * h2 reste le DEFAUT, et c'est le bon dans la quasi-totalite des cas : la
 * bande vit hors du <main>, elle ne peut pas se ranger sous un titre de niveau
 * superieur. Le h3 herite creait un saut de niveau — RGAA 9.1.
 *
 * LA VALEUR EST FILTREE PAR UNE LISTE BLANCHE, et ce n'est pas de la paranoia :
 * elle finit dans un nom de balise, donc dans le document. Un parametre
 * enregistre par un ancien style, ou saisi a la main dans la base, ne doit pas
 * pouvoir ecrire autre chose qu'un titre.
 *
 * LE FILET : h1 le porte SANS CLASSE — c'est la regle du § 12 de
 * _typographie.scss, un seul h1 par page, donc aucun risque de doublon. h2 et
 * h3 le demandent explicitement.
 */

defined('_JEXEC') or die;

$columns = $displayData['columns'];
$options = $displayData['options'];
$helper  = $displayData['helper'];
$key     = $options['key'];
?>
<div id="<?php echo htmlspecialchars($options['id'], ENT_QUOTES, 'UTF-8'); ?>"<?php echo $options['class']; ?><?php $helper->_bg($key); ?>>
<?php $helper->_container_open($key); ?>

	<?php if ($helper->has('layoutTitle_' . $key)) : ?>
	<?php
	$corpusNiveau = (string) $helper->get('layoutTitleTag_' . $key, 'h2');

	if (!in_array($corpusNiveau, ['h1', 'h2', 'h3'], true)) {
		$corpusNiveau = 'h2';
	}

	// Le h1 porte le filet sans rien demander ; les autres le demandent.
	$corpusClasseTitre = $corpusNiveau === 'h1' ? '' : ' class="filet"';
	?>
	<<?php echo $corpusNiveau . $corpusClasseTitre; ?>><?php
		$helper->_('layoutTitle_' . $key); ?></<?php echo $corpusNiveau; ?>>
	<?php endif; ?>

	<?php if ($helper->has('layoutDesc_' . $key)) : ?>
	<p class="introduction"><?php $helper->_('layoutDesc_' . $key); ?></p>
	<?php endif; ?>

	<?php if ($options['row']) : ?>
	<div class="<?php $helper->_row_class($key); ?>">
	<?php endif; ?>

		<?php foreach ($columns as $column) : ?>
		<?php // Sans largeur, pas de <div> vide autour de la colonne. ?>
		<?php if ($column->width === '') : ?>
		<?php echo $column->html; ?>
		<?php else : ?>
		<div class="<?php echo $column->width; ?>">
			<?php echo $column->html; ?>
		</div>
		<?php endif; ?>
		<?php endforeach; ?>

	<?php if ($options['row']) : ?>
	</div>
	<?php endif; ?>

<?php $helper->_container_close($key); ?>
</div>
