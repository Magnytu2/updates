<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LES 25 PICTOGRAMMES DU SITE PUBLIC
 *
 * Traces SVG dessines a la main pour ce projet, en geometrie simple sur une
 * grille de 24. Ils ne viennent d'aucune bibliotheque — ni Remix, ni Bootstrap
 * Icons, ni FontAwesome. Aucune licence a trainer.
 *
 * Le 25e, le lien sortant, ne vit pas ici mais en masque CSS
 * (--pictogramme-externe) : il n'a jamais besoin d'etre appele a la main, donc
 * une seule copie du trace suffit, et c'est le CSS qui le pose.
 *
 * Emploi :
 *   <svg class="i" aria-hidden="true" focusable="false"><use href="#i-accueil" /></svg>
 *
 * TOUJOURS aria-hidden="true" focusable="false" : le pictogramme double le
 * libelle, il ne le remplace jamais. Sans libelle visible, un
 * .visuellement-cache porte le texte.
 *
 * Ce jeu est un premier jet. Telephone et imprimante ne tiennent pas a 16 px ;
 * les quinze du back-office ont ete redessines plusieurs fois, ceux-ci pas
 * encore. Voir CLAUDE.md § 8.
 */

defined('_JEXEC') or die;

?>
<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">
  <symbol id="i-accueil" viewBox="0 0 24 24"><path d="M12 3.5 3 11.6l1.32 1.48L5 12.47V20.5h5.25V15h3.5v5.5H19v-8.03l.68.61L21 11.6 12 3.5Z"/></symbol>
  <symbol id="i-actualites" viewBox="0 0 24 24"><path d="M4 4h13v16H6.5A2.5 2.5 0 0 1 4 17.5V4Zm2 2v11.5a.5.5 0 0 0 .5.5H15V6H6Zm1.5 1.5h6V11h-6V7.5Zm0 5h6V14h-6v-1.5Zm0 3h6V17h-6v-1.5ZM18.5 8H21v9.5a2.5 2.5 0 0 1-2.5 2.5V8Z"/></symbol>
  <symbol id="i-missions" viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm0 2a8 8 0 1 1 0 16 8 8 0 0 1 0-16Zm4.6 3.4-6.1 2.3-2.3 6.1 6.1-2.3 2.3-6.1ZM12 11a1 1 0 1 1 0 2 1 1 0 0 1 0-2Z"/></symbol>
  <symbol id="i-demarches" viewBox="0 0 24 24"><path d="M5 2h9l5 5v15H5V2Zm2 2v16h10V9h-4V4H7Zm8-.6V7h3.6L15 3.4ZM8 13.6 9.4 12.2l1.7 1.7 3.5-3.5L16 11.8l-4.9 4.9L8 13.6Z"/></symbol>
  <symbol id="i-contact" viewBox="0 0 24 24"><path d="M2 5h20v14H2V5Zm2.4 2L12 12.2 19.6 7H4.4ZM20 8.6l-8 5.4-8-5.4V17h16V8.6Z"/></symbol>
  <symbol id="i-recherche" viewBox="0 0 24 24"><path d="M10 2a8 8 0 1 0 4.9 14.3l5.4 5.4 1.4-1.4-5.4-5.4A8 8 0 0 0 10 2Zm0 2a6 6 0 1 1 0 12 6 6 0 0 1 0-12Z"/></symbol>
  <symbol id="i-affichage" viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 0 9 9 7 7 0 0 1-9-9Zm-1 2.1A7 7 0 1 0 18.9 13 9 9 0 0 1 11 5.1Z"/></symbol>
  <?php // Le bouton de menu, sous 48 rem. Trois barres pleines de 2 sur 24,
        // meme epaisseur apparente que la croix de i-fermer. ?>
  <symbol id="i-menu" viewBox="0 0 24 24"><path d="M3 5h18v2H3zm0 6h18v2H3zm0 6h18v2H3z"/></symbol>
  <symbol id="i-chevron" viewBox="0 0 24 24"><path d="M12 15.5 5.5 9l1.4-1.4L12 12.7l5.1-5.1L18.5 9 12 15.5Z"/></symbol>
  <symbol id="i-fleche" viewBox="0 0 24 24"><path d="M13.2 4.6 20.6 12l-7.4 7.4-1.4-1.4 5-5H3.4v-2h13.4l-5-5 1.4-1.4Z"/></symbol>
  <symbol id="i-fleche-g" viewBox="0 0 24 24"><path d="M10.8 4.6 3.4 12l7.4 7.4 1.4-1.4-5-5h13.4v-2H7.2l5-5-1.4-1.4Z"/></symbol>
  <symbol id="i-fleche-haut" viewBox="0 0 24 24"><path d="M12 3.4 4.6 10.8l1.4 1.4 5-5v13.4h2V7.2l5 5 1.4-1.4L12 3.4Z"/></symbol>
  <symbol id="i-calendrier" viewBox="0 0 24 24"><path d="M7 2h2v2h6V2h2v2h3v18H4V4h3V2ZM6 8v12h12V8H6Zm2 2h3v3H8v-3Z"/></symbol>
  <symbol id="i-utilisateur" viewBox="0 0 24 24"><path d="M12 3a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9Zm0 2a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5Zm-8 16c0-4.4 3.6-7 8-7s8 2.6 8 7h-2c0-3.2-2.7-5-6-5s-6 1.8-6 5H4Z"/></symbol>
  <symbol id="i-dossier" viewBox="0 0 24 24"><path d="M2 4h7.4l2 2.5H22V20H2V4Zm2 2v12h16V8.5h-9.6L8.4 6H4Z"/></symbol>
  <symbol id="i-etiquette" viewBox="0 0 24 24"><path d="M11 2h9v9l-8.5 8.5-9-9L11 2Zm.8 2L4.3 11.5l6.2 6.2L18 10.2V4h-6.2ZM16 5.5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Z"/></symbol>
  <symbol id="i-oeil" viewBox="0 0 24 24"><path d="M12 5c5 0 9 4.5 10 7-1 2.5-5 7-10 7S3 14.5 2 12c1-2.5 5-7 10-7Zm0 2c-3.5 0-6.6 3-7.8 5 1.2 2 4.3 5 7.8 5s6.6-3 7.8-5C18.6 10 15.5 7 12 7Zm0 1.8a3.2 3.2 0 1 1 0 6.4 3.2 3.2 0 0 1 0-6.4Z"/></symbol>
  <symbol id="i-lieu" viewBox="0 0 24 24"><path d="M12 2a7 7 0 0 1 7 7c0 5-7 13-7 13S5 14 5 9a7 7 0 0 1 7-7Zm0 2a5 5 0 0 0-5 5c0 3 3.3 7.9 5 10 1.7-2.1 5-7 5-10a5 5 0 0 0-5-5Zm0 2.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5Z"/></symbol>
  <symbol id="i-telephone" viewBox="0 0 24 24"><path d="M7.3 2.5 10.6 6 8.3 8.3c.9 2 2.4 3.5 4.4 4.4L15 10.4l3.5 3.3-3.3 3.3C9.5 15.7 4.6 10.8 3 6.2l4.3-3.7Z"/></symbol>
  <symbol id="i-rss" viewBox="0 0 24 24"><path d="M4 4c9.9 0 16 6.1 16 16h-3C17 11.8 12.2 7 4 7V4Zm0 6c5.5 0 10 4.5 10 10h-3c0-3.9-3.1-7-7-7v-3Zm2 7a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5Z"/></symbol>
  <symbol id="i-imprimer" viewBox="0 0 24 24"><path d="M7 2h10v4H7V2ZM4 7h16v9h-3v6H7v-6H4V7Zm5 9v4h6v-4H9Zm8-6.5a1 1 0 1 1 0 2 1 1 0 0 1 0-2Z"/></symbol>
  <symbol id="i-info" viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm1 15h-2v-6h2v6Zm0-8h-2V7h2v2Z"/></symbol>
  <symbol id="i-succes" viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm-1 14.4-4.2-4.2 1.4-1.4 2.8 2.8 5.6-5.6 1.4 1.4-7 7Z"/></symbol>
  <symbol id="i-alerte" viewBox="0 0 24 24"><path d="M12 2 1 21h22L12 2Zm0 4 7.5 13h-15L12 6Zm1 11h-2v-2h2v2Zm0-3h-2v-4h2v4Z"/></symbol>
  <symbol id="i-erreur" viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm1 15h-2v-2h2v2Zm0-4h-2V7h2v6Z"/></symbol>
  <symbol id="i-partage" viewBox="0 0 24 24"><path d="M18 2a3 3 0 1 1-2.8 4.1L9.9 9.2a3 3 0 0 1 0 5.6l5.3 3.1a3 3 0 1 1-1 1.7l-5.3-3.1a3 3 0 1 1 0-8.9l5.3-3.1A3 3 0 0 1 18 2Z"/></symbol>
  <symbol id="i-lien" viewBox="0 0 24 24"><path d="M10.6 13.4a1 1 0 0 1 0-1.4l1.4-1.4a1 1 0 0 1 1.4 1.4l-1.4 1.4a1 1 0 0 1-1.4 0ZM8.5 17.8l-2.3 2.3a4 4 0 0 1-5.7-5.7l3.5-3.5a4 4 0 0 1 5.7 0l-1.4 1.4a2 2 0 0 0-2.8 0l-3.5 3.5a2 2 0 0 0 2.8 2.8l2.3-2.3 1.4 1.5ZM15.5 6.2l2.3-2.3a4 4 0 0 1 5.7 5.7l-3.5 3.5a4 4 0 0 1-5.7 0l1.4-1.4a2 2 0 0 0 2.8 0l3.5-3.5a2 2 0 0 0-2.8-2.8l-2.3 2.3-1.4-1.5Z"/></symbol>
  <?php // La croix de fermeture. Elle etait un caractere « x » jusqu'au
        // 3 aout 2026 : a la taille du texte, dans une cible de 2,75 rem, elle
        // paraissait maigre et perdue. Un trace suit l'epaisseur des autres
        // pictogrammes, et il suit la taille qu'on lui donne. ?>
  <symbol id="i-fermer" viewBox="0 0 24 24"><path d="M6.4 4.9 12 10.5l5.6-5.6 1.5 1.5L13.5 12l5.6 5.6-1.5 1.5L12 13.5l-5.6 5.6-1.5-1.5L10.5 12 4.9 6.4z"/></symbol>
  <symbol id="i-tri" viewBox="0 0 24 24"><path d="M12 4 7 10h10l-5-6Zm0 16 5-6H7l5 6Z"/></symbol>
  <?php // Pagination : page precedente, premiere page. Les versions « droite »
        // se font par rotation en CSS, plutot que par deux symboles de plus. ?>
  <symbol id="i-chevron-g" viewBox="0 0 24 24"><path d="M15.1 5.6 8.7 12l6.4 6.4-1.4 1.4L5.9 12l7.8-7.8 1.4 1.4Z"/></symbol>
  <symbol id="i-chevron-gg" viewBox="0 0 24 24"><path d="M11.7 5.6 5.3 12l6.4 6.4-1.4 1.4L2.5 12l7.8-7.8 1.4 1.4Zm9 0L14.3 12l6.4 6.4-1.4 1.4L11.5 12l7.8-7.8 1.4 1.4Z"/></symbol>
</svg>
