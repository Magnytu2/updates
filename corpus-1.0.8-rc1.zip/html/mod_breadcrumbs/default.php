<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE FIL D'ARIANE
 *
 * Ecrit le 31 juillet 2026 depuis maquettes/front-corpus.html.
 *
 * Le gabarit du coeur sort `.mod-breadcrumbs breadcrumb px-3 py-2`, un
 * `float-start` et une icone `.icon-location` qui attend FontAwesome — donc
 * un carre vide chez nous. Corpus produit `.ariane`, et le separateur vient du
 * CSS (`li + li::before`), pas du document : c'est une decoration, elle n'a
 * rien a faire dans le texte lu par un lecteur d'ecran.
 *
 * Points d'accessibilite :
 *   - un <nav> etiquete, avec un <ol> : l'ordre compte dans un fil d'Ariane ;
 *   - la derniere entree porte aria-current="page" et n'est pas un lien —
 *     on ne lie pas vers la page ou l'on est deja ;
 *   - la mention « Vous etes ici » reste dans le document, en
 *     .visuellement-cache : elle donne le contexte sans encombrer l'ecran.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

if (empty($list)) {
    return;
}

// Doublons du fil quand le site est multilingue : la page d'accueil peut
// apparaitre deux fois de suite avec le meme lien.
for ($i = 0; $i < $count; $i++) {
    if ($i === 1 && !empty($list[$i]->link) && !empty($list[$i - 1]->link)
        && $list[$i]->link === $list[$i - 1]->link) {
        unset($list[$i]);
    }
}

end($list);
$dernier = key($list);
reset($list);

$montrerDernier = $params->get('showLast', 1);

?>
<?php
// LE NOM DU REPERE VIENT DU TITRE DU MODULE, et c'est voulu : l'administrateur
// le choisit, dans sa langue. Mais un titre peut etre vide — et un `aria-label`
// vide vaut pas de nom du tout : le repere devient « navigation », sans dire
// laquelle, au milieu des autres.
//
// Repli ajoute le 4 aout 2026 apres relevé sur le site de Cyrille, ou le module
// s'appelait « Breadcrumbs » sur un site en francais.
$corpusNomAriane = trim((string) $module->title) !== ''
    ? $module->title
    : Text::_('TPL_CORPUS_BREADCRUMBS');
?>
<nav class="ariane" aria-label="<?php echo htmlspecialchars($corpusNomAriane, ENT_QUOTES, 'UTF-8'); ?>">
	<span class="visuellement-cache"><?php echo Text::_('MOD_BREADCRUMBS_HERE'); ?></span>
	<ol>
	<?php foreach ($list as $cle => $item) : ?>
		<?php if ($cle !== $dernier) : ?>
			<li>
				<?php if (!empty($item->link)) : ?>
				<a href="<?php echo Route::_($item->link); ?>"><?php echo $item->name; ?></a>
				<?php else : ?>
				<span><?php echo $item->name; ?></span>
				<?php endif; ?>
			</li>
		<?php elseif ($montrerDernier) : ?>
			<?php // La page courante : jamais un lien, et aria-current le dit. ?>
			<li><span aria-current="page"><?php echo $item->name; ?></span></li>
		<?php endif; ?>
	<?php endforeach; ?>
	</ol>
</nav>
