<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE MODULE DE RECHERCHE INTELLIGENTE — mod_finder
 *
 * Ecrit le 1er aout 2026 d'apres maquettes/front-corpus.html, § « Rechercher ».
 *
 * POURQUOI UNE SURCHARGE. Le meme motif que pour mod_menu, et pour la meme
 * raison de fond : le coeur ecrit un pictogramme QU'IL NE DESSINE PAS.
 *
 *     <button class="btn btn-primary">
 *       <span class="icon-search icon-white" aria-hidden="true"></span> Rechercher
 *     </button>
 *
 * Ce <span> attend une fonte d'icones. Corpus n'en a aucune : laisse en place,
 * il ne fait qu'un blanc avant l'intitule. On pose notre <svg><use> a la
 * place, comme partout ailleurs.
 *
 * Le second motif est plus simple : le champ du coeur ne vit dans aucun
 * conteneur nomme. Il sort un <label> puis un <input class="form-control">,
 * freres, et le dessin des champs de Corpus s'accroche a `.champ`. Plutot que
 * d'ecrire une deuxieme fois le dessin d'un champ pour ce seul module — deux
 * declarations qui divergeraient a la premiere retouche — on lui donne le
 * conteneur qui manque.
 *
 * CE QU'ON NE CHANGE PAS : la route, les champs caches de FinderHelper,
 * l'autocompletion awesomplete, la recherche avancee, et les identifiants
 * `mod-finder-searchword<id>` et `js-finder-*` — le script du coeur les lit.
 * Le module reste utilisable sans JavaScript.
 *
 * LE BOUTON EST TOUJOURS LA, contrairement au coeur qui le rend optionnel.
 * Un champ dont la seule validation est la touche Entree n'est pas
 * decouvrable : rien a l'ecran ne dit qu'on peut valider. Le reglage
 * « Afficher le bouton » du module ne pilote donc plus que son INTITULE :
 * ecrit a cote de la loupe, ou porte par elle seule.
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\Module\Finder\Site\Helper\FinderHelper;

$lang = $app->getLanguage();
$lang->load('com_finder', JPATH_SITE);

$corpusId    = 'mod-finder-searchword' . $module->id;
$corpusLabel = $params->get('alt_label', Text::_('JSEARCH_FILTER_SUBMIT'));

/**
 * ECHAPPER SANS ECHAPPER DEUX FOIS.
 *
 * Defaut mesure le 3 aout 2026 : le champ affichait litteralement
 * « Recherche &hellip; ». La chaine de langue du coeur,
 * MOD_FINDER_SEARCH_VALUE, contient une ENTITE HTML — c'est ainsi qu'il
 * ecrit les points de suspension. Un htmlspecialchars() direct echappe son
 * esperluette et l'entite devient du texte.
 *
 * Le coeur, lui, pose Text::_() tel quel dans l'attribut : il fait confiance
 * a ses fichiers de langue. On ne va pas jusque-la — on DECODE d'abord, on
 * echappe ensuite. L'entite redevient un caractere, et une apostrophe ou un
 * chevron malencontreux reste neutralise.
 *
 * A appliquer partout ou une chaine de langue entre dans un attribut : rien
 * ne dit qu'une traduction ne contiendra pas d'entite.
 */
$corpusEchapper = static fn (string $texte): string => htmlspecialchars(
    html_entity_decode($texte, ENT_QUOTES | ENT_HTML5, 'UTF-8'),
    ENT_QUOTES,
    'UTF-8'
);

// Le label reste TOUJOURS dans le document : un champ sans nom accessible est
// un champ qu'un lecteur d'ecran annonce « zone de saisie », rien de plus.
// Le reglage ne decide que de sa visibilite. RGAA 11.1.
$corpusLabelVisible = (bool) $params->get('show_label', 1);
$corpusIntitule     = (bool) $params->get('show_button', 0);

Text::script('MOD_FINDER_SEARCH_VALUE');

/** @var Joomla\CMS\WebAsset\WebAssetManager $wa */
$wa = $app->getDocument()->getWebAssetManager();
$wa->getRegistry()->addExtensionRegistryFile('com_finder');

if ($params->get('show_autosuggest', 1)) {
    $wa->usePreset('awesomplete');
    $app->getDocument()->addScriptOptions(
        'finder-search',
        ['url' => Route::_('index.php?option=com_finder&task=suggestions.suggest&format=json&tmpl=component', false)]
    );

    Text::script('JLIB_JS_AJAX_ERROR_OTHER');
    Text::script('JLIB_JS_AJAX_ERROR_PARSE');
}

$wa->useScript('com_finder.finder');

$corpusAvance = (int) $params->get('show_advanced', 0);

/*
 * LE REPLI SUIT L'EMPLACEMENT, PAS UN REGLAGE — 12 aout 2026.
 *
 * Premiere version : un champ « Recherche repliee » dans le Theme Customizer.
 * Cyrille l'a essaye et l'a ecarte : « lie cette mise en forme tout simplement
 * a la position Search ». Il a raison. Un reglage global repliait aussi la
 * recherche d'une colonne laterale, ou la place ne manque pas — et il fallait
 * savoir qu'il existait pour l'activer.
 *
 * Le repli n'a de sens que dans la BARRE : c'est la que la place se dispute.
 * Le module compare donc sa propre position a celle que le Layout donne a
 * « Nav droite », `search` par defaut. Rien a activer, rien a comprendre :
 * publier la recherche dans la barre suffit.
 *
 * SANS JAVASCRIPT, LE CHAMP RESTE DEPLIE. Le bouton est pose `hidden` et c'est
 * template.js qui le revele, exactement comme le bouton du menu depuis le
 * 7 aout : un bouton mort ne fait rien, un champ deplie se remplit.
 */
$corpusBarre = (string) $app->getTemplate(true)->params->get('layoutPos_nav_right', 'search');
$corpusRepli = $corpusBarre !== '' && (string) $module->position === $corpusBarre;
$corpusIdVolet = 'corpus-recherche-' . $module->id;
?>
<?php if ($corpusRepli) : ?>
<div class="recherche-repli">
	<button type="button" class="recherche-repli__bouton" aria-expanded="false"
		aria-controls="<?php echo $corpusIdVolet; ?>" hidden>
		<svg class="i" aria-hidden="true" focusable="false"><use href="#i-recherche" /></svg>
		<span class="visuellement-cache"><?php echo $corpusEchapper(Text::_('TPL_CORPUS_RECHERCHE_OUVRIR')); ?></span>
	</button>
	<div class="recherche-repli__volet" id="<?php echo $corpusIdVolet; ?>">
<?php endif; ?>
<search>
	<form class="mod-finder js-finder-searchform form-search" action="<?php echo Route::_($route); ?>" method="get">
		<div class="champ">
			<label for="<?php echo $corpusId; ?>"<?php echo $corpusLabelVisible ? '' : ' class="visuellement-cache"'; ?>><?php
				echo $corpusEchapper($corpusLabel); ?></label>

			<div class="recherche">
				<input type="search" name="q" id="<?php echo $corpusId; ?>"
					class="js-finder-search-query"
					value="<?php echo htmlspecialchars($app->getInput()->get("q", "", "string"), ENT_COMPAT, "UTF-8"); ?>"
					placeholder="<?php echo $corpusEchapper(Text::_('MOD_FINDER_SEARCH_VALUE')); ?>">

				<button class="bouton" type="submit">
					<svg class="i i--sm" aria-hidden="true" focusable="false"><use href="#i-recherche" /></svg>
					<?php if ($corpusIntitule) : ?>
					<?php echo Text::_('JSEARCH_FILTER_SUBMIT'); ?>
					<?php else : ?>
					<span class="visuellement-cache"><?php echo Text::_('JSEARCH_FILTER_SUBMIT'); ?></span>
					<?php endif; ?>
				</button>
			</div>
		</div>

		<?php if ($corpusAvance === 2) : ?>
		<p><a href="<?php echo Route::_($route); ?>" class="mod-finder__advanced-link"><?php
			echo Text::_('COM_FINDER_ADVANCED_SEARCH'); ?></a></p>
		<?php elseif ($corpusAvance === 1) : ?>
		<div class="mod-finder__advanced js-finder-advanced">
			<?php echo HTMLHelper::_('filter.select', $query, $params); ?>
		</div>
		<?php endif; ?>

		<?php echo FinderHelper::getGetFields($route, (int) $params->get('set_itemid', 0)); ?>
	</form>
</search>
<?php if ($corpusRepli) : ?>
	</div>
</div>
<?php endif; ?>
