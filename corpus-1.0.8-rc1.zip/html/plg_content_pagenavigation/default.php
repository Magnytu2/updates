<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * ARTICLE PRECEDENT / ARTICLE SUIVANT
 *
 * Surcharge du gabarit du plugin « Contenu - Navigation dans les pages ».
 * Ecrite le 1er aout 2026 depuis maquettes/front-corpus.html.
 *
 * Ce que le plugin produisait, et qu'on ne garde pas :
 *
 * 1. `btn btn-sm btn-secondary` — le dessin de Bootstrap. Corpus a le sien, et
 *    ces deux liens ne sont pas des boutons : ce sont des liens de
 *    navigation, ils ne declenchent aucune action.
 *
 * 2. `<span class="icon-chevron-left">` — un span vide qui attend une fonte
 *    d'icones. Corpus n'en charge aucune : a l'ecran, rien. Nos pictogrammes
 *    dessines les remplacent.
 *
 * 3. LE TITRE DE L'ARTICLE CACHE. Le plugin ecrit « Precedent » a l'ecran et
 *    range le titre reel dans un `visually-hidden`. Le lecteur d'ecran savait
 *    donc ou il allait ; celui qui voit, non. C'est l'inverse de ce qu'on
 *    veut : le titre passe A L'ECRAN, et le libelle « Article precedent »
 *    devient la mention au-dessus.
 *
 *    Consequence RGAA 6.1 : l'intitule du lien se comprend maintenant sorti
 *    de son contexte pour tout le monde, et il n'y a plus deux textes
 *    concurrents a annoncer.
 *
 * Le calcul des liens, le sens de lecture RTL et les libelles configurables
 * du plugin sont conserves.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/**
 * @var \Joomla\Plugin\Content\PageNavigation\Extension\PageNavigation $this
 */
$this->loadLanguage();

$rtl = $this->getLanguage()->isRtl();

// La fleche pointe vers ou l'on va, pas vers le bord de l'ecran.
$corpusFlecheAvant  = $rtl ? 'i-fleche-g' : 'i-fleche';
$corpusFlecheArriere = $rtl ? 'i-fleche' : 'i-fleche-g';

$corpusTitrePrecedent = $rows[$location - 1]->title ?? '';
$corpusTitreSuivant   = $rows[$location + 1]->title ?? '';
?>
<nav class="pagenavigation" aria-label="<?php echo Text::_('PLG_PAGENAVIGATION_ARIA_LABEL'); ?>">
	<?php if ($row->prev) : ?>
	<a class="precedent" href="<?php echo Route::_($row->prev); ?>" rel="prev">
		<svg class="i" aria-hidden="true" focusable="false"><use href="#<?php echo $corpusFlecheArriere; ?>" /></svg>
		<span>
			<small><?php echo Text::_('TPL_CORPUS_ARTICLE_PRECEDENT'); ?></small>
			<strong><?php echo htmlspecialchars($corpusTitrePrecedent, ENT_QUOTES, 'UTF-8'); ?></strong>
		</span>
	</a>
	<?php endif; ?>

	<?php if ($row->next) : ?>
	<a class="suivant" href="<?php echo Route::_($row->next); ?>" rel="next">
		<span>
			<small><?php echo Text::_('TPL_CORPUS_ARTICLE_SUIVANT'); ?></small>
			<strong><?php echo htmlspecialchars($corpusTitreSuivant, ENT_QUOTES, 'UTF-8'); ?></strong>
		</span>
		<svg class="i" aria-hidden="true" focusable="false"><use href="#<?php echo $corpusFlecheAvant; ?>" /></svg>
	</a>
	<?php endif; ?>
</nav>
