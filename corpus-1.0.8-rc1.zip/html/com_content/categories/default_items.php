<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LA LISTE DES CATEGORIES
 *
 * Ecrit le 1er aout 2026 d'apres maquettes/front-corpus.html, § « Liste des
 * categories ».
 *
 * POURQUOI UNE SURCHARGE, alors que le CSS avait presque suffi. Deux raisons,
 * et la premiere est un mur :
 *
 * 1. LE BLEU NE SE RATTRAPE PAS EN CSS. Le coeur sort le compteur en
 *    `<span class="badge bg-info">`, et Bootstrap ecrit
 *    `.bg-info { background-color: … !important }`. Aucune regle de Corpus ne
 *    peut gagner contre ca sans un `!important` de plus — exactement la
 *    surenchere que le projet s'interdit. On enleve donc la classe a la
 *    source.
 *
 * 2. LA MAQUETTE DEMANDE UN PICTOGRAMME ET « (3) ». Le coeur ecrit « Nombre
 *    d'articles : 3 » en toutes lettres, ce qui pese plus que le titre a cote
 *    duquel il se pose. Le nombre reste annonce en entier aux lecteurs
 *    d'ecran — c'est le texte VISIBLE qu'on abrege, pas l'information.
 *
 * CE QU'ON NE CHANGE PAS : la recursion, les conditions de reglage, et
 * surtout les identifiants `category-btn-N` et `category-N` que le script du
 * coeur utilise pour ouvrir les volets. On garde son mecanisme.
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\Component\Content\Site\Helper\RouteHelper;

/** @var \Joomla\Component\Content\Site\View\Categories\HtmlView $this */

if ($this->maxLevelcat == 0 || count($this->items[$this->parent->id]) === 0) {
    return;
}
?>
<div class="com-content-categories__items corpus-categories">
	<?php foreach ($this->items[$this->parent->id] as $item) : ?>
		<?php if (!$this->params->get('show_empty_categories_cat') && !$item->numitems && !count($item->getChildren())) : ?>
			<?php continue; ?>
		<?php endif; ?>

		<?php $corpusEnfants = count($item->getChildren()) > 0 && $this->maxLevelcat > 1; ?>

	<div class="com-content-categories__item">
		<div class="com-content-categories__item-title-wrapper">
			<div class="com-content-categories__item-title">
				<svg class="i--sm" aria-hidden="true" focusable="false"><use href="#i-dossier" /></svg>

				<a href="<?php echo Route::_(RouteHelper::getCategoryRoute($item->id, $item->language)); ?>"><?php
					echo $this->escape($item->title); ?></a>

				<?php if ($this->params->get('show_cat_num_articles_cat') == 1) : ?>
				<?php
				// Le nombre entre parentheses. L'intitule complet reste dans
				// le document pour les lecteurs d'ecran : « 3 » tout seul ne
				// dit pas de quoi on compte trois.
				?>
				<span class="corpus-categories__compte">
					<span aria-hidden="true">(<?php echo (int) $item->numitems; ?>)</span>
					<span class="visuellement-cache"><?php
						echo Text::_('COM_CONTENT_NUM_ITEMS') . ' ' . (int) $item->numitems; ?></span>
				</span>
				<?php endif; ?>
			</div>

			<?php if ($corpusEnfants) : ?>
			<?php
			// Le bouton garde l'identifiant et l'attribut que le script du
			// coeur attend. Seul son dessin change : un chevron, le meme que
			// dans le menu — c'est la meme action.
			?>
			<button type="button"
				id="category-btn-<?php echo (int) $item->id; ?>"
				data-category-id="<?php echo (int) $item->id; ?>"
				class="corpus-categories__bouton"
				aria-expanded="false"
				aria-label="<?php echo $this->escape(Text::sprintf('TPL_CORPUS_OUVRIR_SOUS_MENU', $item->title)); ?>">
				<svg class="chevron" aria-hidden="true" focusable="false"><use href="#i-chevron" /></svg>
			</button>
			<?php endif; ?>
		</div>

		<?php if ($this->params->get('show_description_image') && $item->getParams()->get('image')) : ?>
		<div class="com-content-categories__image">
			<?php echo HTMLHelper::_('image', $item->getParams()->get('image'), $item->getParams()->get('image_alt')); ?>
		</div>
		<?php endif; ?>

		<?php if ($this->params->get('show_subcat_desc_cat') == 1 && $item->description) : ?>
		<div class="com-content-categories__description category-desc">
			<?php echo HTMLHelper::_('content.prepare', $item->description, '', 'com_content.categories'); ?>
		</div>
		<?php endif; ?>

		<?php if ($corpusEnfants) : ?>
		<div class="com-content-categories__children" id="category-<?php echo (int) $item->id; ?>" hidden>
			<?php
			$this->items[$item->id] = $item->getChildren();
			$this->parent = $item;
			$this->maxLevelcat--;
			echo $this->loadTemplate('items');
			$this->parent = $item->getParent();
			$this->maxLevelcat++;
			?>
		</div>
		<?php endif; ?>
	</div>
	<?php endforeach; ?>
</div>
