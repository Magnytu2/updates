<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LA VUE ARTICLE
 *
 * Surcharge ecrite le 31 juillet 2026. Elle ne reecrit pas la logique du
 * coeur — pagination, plugins, images, liens, associations : tout est
 * conserve tel quel. Trois choses seulement changent :
 *
 * 1. LE TITRE porte le filet. C'est un titre, donc le filet suit son texte et
 *    non la colonne.
 *
 * 2. LE CHAPO. Joomla ne distingue l'introduction que dans la vue blog : en
 *    article complet, introtext et fulltext sont concatenes AVANT le passage
 *    des plugins, et plus rien ne dit ou finit l'introduction.
 *
 *    On ne rend donc PAS les deux morceaux separement — cela ferait passer
 *    les plugins deux fois, avec les doublons que cela suppose. On enveloppe
 *    le premier paragraphe, et seulement quand les trois conditions sont
 *    reunies : l'article a bien un fulltext (donc une vraie introduction), le corps
 *    commence par un <p>, et ce <p> n'est pas vide.
 *
 *    LIMITE ASSUMEE, et c'est celle que les regles de style annoncaient : un
 *    article qui commence par une image ou un titre n'a pas d'introduction mise en
 *    forme. Il n'en a pas non plus dans Joomla — c'est la donnee qui manque,
 *    pas le gabarit.
 *
 * 3. LES ETATS — non publie, pas encore publie, expire — sortent en
 *    `.etiquette` et non en `.badge bg-warning text-light` de Bootstrap.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Associations;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Content\Administrator\Extension\ContentComponent;
use Joomla\Component\Content\Site\Helper\RouteHelper;

$params  = $this->item->params;
$canEdit = $params->get('access-edit');
$user    = Factory::getUser();
$info    = $params->get('info_block_position', 0);
$htag    = $this->params->get('show_page_heading') ? 'h2' : 'h1';

$assocParam        = (Associations::isEnabled() && $params->get('show_associations'));
$currentDate       = Factory::getDate()->format('Y-m-d H:i:s');
$isNotPublishedYet = $this->item->publish_up > $currentDate;
$isExpired         = !is_null($this->item->publish_down) && $this->item->publish_down < $currentDate;

/*
 * L'INTRODUCTION. Voir la note en tete de fichier : on enveloppe le premier
 * paragraphe, jamais autre chose.
 *
 * Les DEUX classes sont posees. `introduction` est le nom retenu le 4 aout
 * 2026 ; `chapo` reste pour que le contenu deja ecrit avec le bloc
 * redactionnel « accroche » garde son dessin.
 */
$corpusTexte = $this->item->text;

if (!empty($this->item->fulltext) && preg_match('/^\s*<p(\s[^>]*)?>/i', $corpusTexte)) {
    $corpusTexte = preg_replace(
        '/^(\s*)<p(\s[^>]*)?>/i',
        '$1<p class="introduction chapo"$2>',
        $corpusTexte,
        1
    );
}
?>
<div class="com-content-article item-page<?php echo $this->pageclass_sfx; ?>" itemscope itemtype="https://schema.org/Article">
	<meta itemprop="inLanguage" content="<?php echo ($this->item->language === '*') ? Factory::getApplication()->get('language') : $this->item->language; ?>">

	<?php if ($this->params->get('show_page_heading')) : ?>
	<h1 class="filet"><?php echo $this->escape($this->params->get('page_heading')); ?></h1>
	<?php endif; ?>

	<?php
	if (!empty($this->item->pagination) && !$this->item->paginationposition && $this->item->paginationrelative) {
		echo $this->item->pagination;
	}

	$useDefList = $params->get('show_modify_date') || $params->get('show_publish_date') || $params->get('show_create_date')
		|| $params->get('show_hits') || $params->get('show_category') || $params->get('show_parent_category')
		|| $params->get('show_author') || $assocParam;
	?>

	<?php if ($params->get('show_title')) : ?>
	<<?php echo $htag; ?> class="filet" itemprop="headline"><?php echo $this->escape($this->item->title); ?></<?php echo $htag; ?>>

		<?php // Un etat n'est jamais porte par la couleur seule : le mot est ecrit. ?>
		<?php if ($this->item->state == ContentComponent::CONDITION_UNPUBLISHED) : ?>
		<p><span class="etiquette"><?php echo Text::_('JUNPUBLISHED'); ?></span></p>
		<?php endif; ?>
		<?php if ($isNotPublishedYet) : ?>
		<p><span class="etiquette"><?php echo Text::_('JNOTPUBLISHEDYET'); ?></span></p>
		<?php endif; ?>
		<?php if ($isExpired) : ?>
		<p><span class="etiquette"><?php echo Text::_('JEXPIRED'); ?></span></p>
		<?php endif; ?>
	<?php endif; ?>

	<?php if ($canEdit) : ?>
	<?php echo LayoutHelper::render('joomla.content.icons', ['params' => $params, 'item' => $this->item]); ?>
	<?php endif; ?>

	<?php echo $this->item->event->afterDisplayTitle; ?>

	<?php if ($useDefList && ($info == 0 || $info == 2)) : ?>
	<?php echo LayoutHelper::render('joomla.content.info_block', ['item' => $this->item, 'params' => $params, 'position' => 'above']); ?>
	<?php endif; ?>

	<?php if ($info == 0 && $params->get('show_tags', 1) && !empty($this->item->tags->itemTags)) : ?>
	<?php $this->item->tagLayout = new FileLayout('joomla.content.tags'); ?>
	<?php echo $this->item->tagLayout->render($this->item->tags->itemTags); ?>
	<?php endif; ?>

	<?php echo $this->item->event->beforeDisplayContent; ?>

	<?php if ((int) $params->get('urls_position', 0) === 0) : ?>
	<?php echo $this->loadTemplate('links'); ?>
	<?php endif; ?>

	<?php if ($params->get('access-view')) : ?>
		<?php echo LayoutHelper::render('joomla.content.full_image', $this->item); ?>

		<?php
		if (!empty($this->item->pagination) && !$this->item->paginationposition && !$this->item->paginationrelative) :
			echo $this->item->pagination;
		endif;
		?>

		<?php if (isset($this->item->toc)) : ?>
		<?php echo $this->item->toc; ?>
		<?php endif; ?>

		<?php
		// PAS de .texte ici. Decision de Cyrille, 31 juillet 2026 : le corps
		// d'article prend toute la largeur de sa colonne, et suit donc la
		// mise en page — ajouter une colonne laterale retrecit le texte
		// d'autant, ce qui est le comportement attendu.
		//
		// La mesure de lecture de 66ch reste disponible via .texte, pour les
		// blocs ou on la veut. Elle n'est plus imposee a l'article.
		?>
		<div itemprop="articleBody" class="com-content-article__body contenu">
			<?php echo $corpusTexte; ?>
		</div>

		<?php
		// LES OUTILS SOUS L'ARTICLE — imprimer, courriel, partager.
		//
		// Joomla les a RETIRES du coeur : mesure le 31 juillet 2026, aucun des
		// 239 parametres de com_content ne les porte plus. L'envoi par courriel
		// a saute a cause des robots de spam, l'impression parce que le
		// navigateur sait le faire. Corpus les fournit, reglables un par un
		// depuis le Theme Customizer.
		//
		// AUCUN SCRIPT TIERS, AUCUN LOGO DE MARQUE. Decision de Cyrille du
		// 31 juillet : le partage passe par navigator.share, celui du systeme,
		// qui propose toutes les applications installees. Les boutons officiels
		// des reseaux sociaux sont des traceurs, et leurs logos sont des
		// marques deposees avec leurs propres regles de representation.
		//
		//   - courriel : un lien mailto:, qui marche SANS JavaScript ;
		//   - imprimer et partager : ecrits par template.js. Sans JavaScript
		//     ils n'existent pas du tout, plutot que d'exister sans rien faire.
		//     Un bouton mort promet une action qu'il ne rend pas.
		//
		// La feuille d'impression masque le bloc : imprimer un bouton
		// « Imprimer » n'a aucun sens.
		$corpusOutils = [];

		if ($this->params->get('articleImprimer', 1)) {
			$corpusOutils['imprimer'] = Text::_('TPL_CORPUS_IMPRIMER');
		}

		if ($this->params->get('articlePartage', 1)) {
			$corpusOutils['partager'] = Text::_('TPL_CORPUS_PARTAGER');
			$corpusOutils['copier']   = Text::_('TPL_CORPUS_COPIER_LIEN');
			$corpusOutils['copie']    = Text::_('TPL_CORPUS_LIEN_COPIE');
		}

		$corpusCourriel = (bool) $this->params->get('articleCourriel', 1);
		?>
		<?php if ($corpusOutils || $corpusCourriel) : ?>
		<div class="outils-page" data-corpus-outils aria-live="polite"
			<?php foreach ($corpusOutils as $cle => $libelle) : ?>
			data-<?php echo $cle; ?>="<?php echo htmlspecialchars($libelle, ENT_QUOTES, 'UTF-8'); ?>"
			<?php endforeach; ?>>

			<?php if ($corpusCourriel) : ?>
			<a class="bouton bouton--petit bouton--second" href="mailto:?subject=<?php
				echo rawurlencode($this->item->title); ?>&amp;body=<?php
				echo rawurlencode(Uri::getInstance()->toString()); ?>">
				<svg class="i--sm" aria-hidden="true" focusable="false"><use href="#i-contact" /></svg>
				<?php echo Text::_('TPL_CORPUS_ENVOYER_COURRIEL'); ?>
			</a>
			<?php endif; ?>
		</div>
		<?php endif; ?>

		<?php if ($info == 1 || $info == 2) : ?>
			<?php if ($useDefList) : ?>
			<?php echo LayoutHelper::render('joomla.content.info_block', ['item' => $this->item, 'params' => $params, 'position' => 'below']); ?>
			<?php endif; ?>
			<?php if ($params->get('show_tags', 1) && !empty($this->item->tags->itemTags)) : ?>
			<?php $this->item->tagLayout = new FileLayout('joomla.content.tags'); ?>
			<?php echo $this->item->tagLayout->render($this->item->tags->itemTags); ?>
			<?php endif; ?>
		<?php endif; ?>

		<?php if (!empty($this->item->pagination) && $this->item->paginationposition && !$this->item->paginationrelative) : ?>
		<?php echo $this->item->pagination; ?>
		<?php endif; ?>

		<?php if ((int) $params->get('urls_position', 0) === 1) : ?>
		<?php echo $this->loadTemplate('links'); ?>
		<?php endif; ?>

	<?php elseif ($params->get('show_noauth') == true && $user->get('guest')) : ?>
		<?php echo LayoutHelper::render('joomla.content.intro_image', $this->item); ?>
		<div class="contenu">
			<?php echo HTMLHelper::_('content.prepare', $this->item->introtext); ?>
		</div>

		<?php if ($params->get('show_readmore') && $this->item->fulltext != null) : ?>
			<?php
			$menu   = Factory::getApplication()->getMenu();
			$active = $menu->getActive();
			$itemId = $active->id;
			$link   = new Uri(Route::_('index.php?option=com_users&view=login&Itemid=' . $itemId, false));
			$link->setVar('return', base64_encode(RouteHelper::getArticleRoute($this->item->slug, $this->item->catid, $this->item->language)));
			?>
			<?php echo LayoutHelper::render('joomla.content.readmore', ['item' => $this->item, 'params' => $params, 'link' => $link]); ?>
		<?php endif; ?>
	<?php endif; ?>

	<?php if (!empty($this->item->pagination) && $this->item->paginationposition && $this->item->paginationrelative) : ?>
	<?php echo $this->item->pagination; ?>
	<?php endif; ?>

	<?php echo $this->item->event->afterDisplayContent; ?>
</div>
