<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * Element de menu de type « Separateur ».
 *
 * Joomla rend ces elements avec les classes mod-menu__heading et nav-header.
 * La seconde porte, en Bootstrap 2, le style des en-tetes de liste verticale :
 * gris, onze pixels, majuscules — inadapte a une barre de navigation.
 * Le CSS du template stylise en revanche .separator, la classe qu'employait
 * Joomla 3. On la retablit donc ici : l'en-tete retrouve l'aspect des autres
 * entrees du menu sans qu'aucune regle CSS n'ait a etre ajoutee.
 */

defined('_JEXEC') or die;

$title = $item->anchor_title ? ' title="' . $item->anchor_title . '"' : '';
$class = $item->anchor_css ? ' ' . $item->anchor_css : '';

$linktype = $item->title;

if ($item->menu_image) {
    $image = '<img src="' . $item->menu_image . '" alt="' . $item->title . '">';

    $linktype = $item->menu_image_css
        ? '<span class="' . $item->menu_image_css . '">' . $image . '</span>'
        : $image;

    if ($item->params->get('menu_text', 1)) {
        $linktype .= '<span class="image-title">' . $item->title . '</span>';
    }
}

echo '<span class="mod-menu__heading separator' . $class . '"' . $title . '>' . $linktype . '</span>';
