<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE MENU PRINCIPAL — trois niveaux, motif de divulgation
 *
 * Reecrit le 31 juillet 2026 depuis maquettes/front-corpus.html.
 *
 * L'ancien gabarit sortait le motif Bootstrap : un <span data-bs-toggle> avec
 * un `role="button"` pose a la main, une icone FontAwesome, et le sous-menu
 * ouvert par le dropdown de Bootstrap.
 *
 * Ce que Corpus produit :
 *
 *     <ul class="nav__liste">
 *       <li><a class="nav__lien" aria-current="page">…</a></li>
 *       <li>
 *         <button class="nav__lien" aria-expanded="false" aria-controls="…">…</button>
 *         <ul class="nav__sous" id="…"> … </ul>
 *       </li>
 *     </ul>
 *
 * TROIS REGLES QUI NE SE NEGOCIENT PAS :
 *
 * 1. Une entree qui ouvre un panneau est un <button>, jamais un lien qui ne
 *    mene nulle part. C'est le motif de divulgation.
 * 2. Le bouton recoit la MEME classe que le lien. Sans `font: inherit` et
 *    `background: none` — poses dans _navigation.scss — il s'afficherait en
 *    bouton systeme gris au milieu de liens. C'etait le defaut de la 0.1.
 * 3. Trois niveaux, pas plus. Joomla accepte une profondeur illimitee,
 *    l'usager non : au-dela, le quatrieme niveau vit dans la page. Les
 *    entrees plus profondes sont ignorees.
 *
 * LE PICTOGRAMME vient du champ natif « Classe de l'icone du lien » de
 * l'entree de menu, onglet Type de lien. Y ecrire `i-accueil` pose le
 * pictogramme du meme nom. C'est LE champ prevu pour une icone, celui qu'on
 * trouve naturellement ; « Style CSS du lien » est accepte aussi, en second.
 *
 * Laisse tel quel, Joomla en tire un <span class="p-2 pt-0 i-accueil"> vide
 * qui attend une fonte d'icones — un blanc dans le menu, et rien a voir.
 * On retire donc ce span et on pose notre <svg><use> a la place.
 *
 * Un nom inconnu ne casse rien : il ne pose simplement pas de pictogramme.
 * Le jeu disponible est dans html/layouts/corpus/pictogrammes.php.
 *
 * Le script (media/js/template.js) ne connait AUCUN niveau : il lit
 * aria-expanded et aria-controls. Le meme code sert au deuxieme comme au
 * troisieme.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

use Joomla\CMS\Helper\ModuleHelper;

// Profondeur au-dela de laquelle on ne deroule plus.
//
// Une VARIABLE et non une constante : ce fichier est inclus une fois par
// module de menu publie. Un `const` planterait sur « already defined » des
// qu'il y a deux menus sur la page — le principal et celui du pied, par
// exemple. C'est le genre de defaut qui ne se voit qu'en production.
$corpusNiveauMax = 3;

/**
 * LE MEGA-MENU — ajoute le 12 aout 2026.
 *
 * Une entree de BARRE dont le champ natif « Style CSS du lien » contient le
 * mot `mega` n'ouvre plus un panneau etroit sous elle, mais un panneau large
 * sous la barre, ou chaque entree de niveau 2 devient une COLONNE.
 *
 * POURQUOI « Style CSS du lien » ET PAS « Classe de l'icone du lien » : la
 * seconde porte deja les pictogrammes du menu. Un administrateur qui pose un
 * pictogramme sur son entree de barre perdrait son mega, ou l'inverse.
 *
 * CE DECLENCHEUR EST LA SEULE CHOSE QUI CHANGE QUOI QUE CE SOIT. Sans le mot
 * `mega`, ce fichier produit exactement le HTML qu'il produisait avant —
 * verifie au banc, sur quatre menus, octet pour octet.
 *
 * LE MEGA EST LE SEUL ENDROIT OU L'ON DESCEND A QUATRE NIVEAUX. La
 * hierarchie EST la mise en page : barre, rubrique, page, et le volet qui se
 * deplie sous une page. Partout ailleurs le plafond reste a trois, parce que
 * partout ailleurs le quatrieme niveau serait un sous-menu sous un sous-menu
 * deja deroule — ce qui ne se lit pas.
 *
 * $corpusMega retient le NIVEAU de l'entree qui a ouvert le mega, et vaut
 * null hors mega. On en sort des qu'une entree revient a ce niveau ou
 * au-dessus.
 */
$corpusMega = null;

/**
 * Retire un mot de l'attribut `class` du premier element de $lien, et
 * supprime l'attribut s'il devient vide.
 *
 * Le declencheur est un mot ecrit dans un champ de CLASSE : le coeur le
 * recopie donc tel quel dans la sortie, et `class="mega"` se retrouverait
 * dans le HTML livre. Ce n'est pas une classe de style, c'est un ordre donne
 * au gabarit : il ne doit pas survivre au gabarit.
 *
 * ON NETTOIE LA SORTIE, ON NE TOUCHE PAS A $item. La liste d'entrees est
 * partagee : deux modules affichant le meme menu la parcourent l'un apres
 * l'autre. Retirer le mot de l'objet ferait disparaitre le mega du second
 * module — un defaut invisible sur un site qui n'a qu'un seul menu, et
 * incomprehensible sur un site qui en a deux. C'est exactement le piege des
 * identifiants dupliques, corrige le 1er aout.
 */
$corpusRetirerClasse = static function ($lien, $mot) {
    return preg_replace_callback(
        '/(<[a-z]+[^>]*?)\sclass="([^"]*)"/i',
        static function ($m) use ($mot) {
            $mots = array_values(array_diff(preg_split('/\s+/', trim($m[2])), [$mot, '']));

            return $m[1] . ($mots === [] ? '' : ' class="' . implode(' ', $mots) . '"');
        },
        $lien,
        1
    );
};

/**
 * Recolte le pictogramme SUR LE LIEN PRODUIT PAR LE COEUR, et retire le
 * <span> vide qui le portait.
 *
 * Pourquoi la sortie et non les parametres : le nom du parametre qui stocke
 * la classe d'icone n'est pas celui qu'on croit, et il a change entre les
 * versions de Joomla. Le <span> emis, lui, est la, avec la classe dedans.
 * On lit ce qui est ecrit plutot que de deviner ou c'est range.
 *
 * Le span attend une fonte d'icones. Corpus n'en a pas : laisse en place, il
 * ne fait qu'un blanc dans le menu.
 *
 * $lien est modifie par reference. Renvoie le nom du symbole, ou ''.
 */
$corpusRecolterPictogramme = static function (&$lien) {
    $picto = '';

    $lien = preg_replace_callback(
        '/<span class="([^"]*)"\s+aria-hidden="true">\s*<\/span>/',
        static function ($m) use (&$picto) {
            foreach (preg_split('/\s+/', trim($m[1])) as $mot) {
                if (str_starts_with($mot, 'i-')) {
                    $picto = $mot;
                }
            }

            return '';
        },
        $lien,
        1
    );

    return $picto;
};

$id      = $params->get('tag_id', '') ? ' id="' . htmlspecialchars($params->get('tag_id'), ENT_QUOTES, 'UTF-8') . '"' : '';
$ouverts = 0;   // nombre de <ul> de sous-menu encore ouverts

?>
<ul<?php echo $id; ?> class="nav__liste">
<?php
foreach ($list as $i => &$item) :
    /*
     * ON SORT DU MEGA AVANT D'ECRIRE QUOI QUE CE SOIT — et l'ordre compte.
     *
     * Une entree qui revient au niveau de l'entree porteuse, ou au-dessus,
     * n'appartient plus a son panneau. « Tourisme-Loisirs », niveau 1 juste
     * apres un mega ouvert sur « Vie quotidienne », doit retrouver ses
     * classes de barre. Teste ici, en tete de boucle : un controle s'execute
     * AVANT l'effet qu'il doit empecher.
     */
    if ($corpusMega !== null && $item->level <= $corpusMega) {
        $corpusMega = null;
    }

    // Vrai pour les entrees CONTENUES dans un mega, faux pour l'entree qui le
    // porte : celle-ci garde le dessin de la barre. C'est pour cela que la
    // detection du declencheur vient plus bas, apres cette ligne.
    $dansMega = $corpusMega !== null;

    // Le mega, et lui seul, ouvre un quatrieme cran.
    $niveauMax = $dansMega ? $corpusNiveauMax + 1 : $corpusNiveauMax;

    // Au-dela du niveau maximal, on n'ecrit rien.
    if ($item->level > $niveauMax) {
        continue;
    }

    $itemParams = $item->getParams();

    /*
     * LE DECLENCHEUR : le mot `mega` dans « Style CSS du lien », sur une
     * entree de BARRE qui a des enfants.
     *
     * Trois conditions, et aucune n'est de trop. Le niveau 1 : un mega
     * ouvert depuis un sous-menu n'aurait nulle part ou s'afficher. Des
     * enfants : un mega vide est un panneau vide. Le mot exact : on decoupe
     * la classe en mots plutot que de chercher une sous-chaine, sinon une
     * classe `megaphone` declencherait le panneau.
     */
    $ouvreMega = $item->level === 1
        && $item->deeper
        && in_array('mega', preg_split('/\s+/', trim((string) ($item->anchor_css ?? ''))), true);

    // Une entree « deeper » ouvre un panneau — sauf si ses enfants sont tous
    // au-dela du niveau maximal, auquel cas elle redevient un simple lien.
    $ouvrePanneau = $item->deeper && $item->level < $niveauMax;

    $actif = $item->id == $active_id
        || ($item->type === 'alias' && $itemParams->get('aliasoptions') == $active_id);

    /*
     * UNE RUBRIQUE EST UN TITRE, PAS UNE COMMANDE — arbitre le 12 aout 2026.
     *
     * Au niveau 2 d'un mega, l'entree devient le titre d'une colonne. Sa
     * colonne est DEJA depliee : il n'y a rien a ouvrir, donc pas de bouton,
     * pas de chevron. Un bouton qui n'ouvre rien serait un defaut.
     *
     * C'est le seul endroit ou la regle « une entree de type Titre est un
     * bouton unique » ne s'applique pas — et c'est parce que la condition qui
     * la justifie, un panneau replie, n'existe pas ici.
     */
    $estRubrique = $dansMega && $item->level === 2;

    // Le premier niveau porte .nav__lien, les suivants le dessin du panneau.
    $classeLien   = $item->level === 1 ? 'nav__lien' : '';
    $classeBouton = $item->level === 1 ? 'nav__lien' : 'nav__sous__bouton';
    $classePaire  = 'nav__paire';

    if ($dansMega) {
        $classeLien   = $estRubrique ? 'mega__titre' : 'mega__lien';
        $classeBouton = 'mega__bouton';
        $classePaire  = 'mega__paire';
    }

    /*
     * L'IDENTIFIANT PORTE LE NUMERO DU MODULE, et il a fallu une mesure pour
     * le comprendre. Il valait `corpus-sous-<item>` : deux modules affichant le
     * MEME menu — l'entete et la colonne laterale — sortaient donc deux fois
     * les memes identifiants.
     *
     * Le HTML devenait invalide (RGAA 8.2), mais surtout `getElementById`
     * rendait toujours le panneau de l'entete. Consequence visible : dans la
     * colonne, ouvrir un sous-sous-menu refermait aussitot son parent —
     * `fermerLesAutres` comparait le bouton clique au panneau d'un AUTRE
     * module, ne le trouvait pas dedans, et le prenait donc pour un oncle.
     *
     * Le premier niveau, lui, marchait : le CSS ne lit que le frere adjacent,
     * il ne passe pas par l'identifiant. C'est ce qui rendait le defaut
     * illisible.
     */
    $idPanneau = 'corpus-sous-' . (int) $module->id . '-' . (int) $item->id;

    // Le gabarit du coeur produit l'URL, la cible, le rel et le <span> de
    // l'icone. On le rend TOUJOURS, meme pour une entree qui deviendra un
    // bouton : c'est de la qu'on recolte le pictogramme.
    $lien = '';

    if ($item->type !== 'separator') {
        ob_start();

        switch ($item->type) {
            case 'component':
            case 'heading':
            case 'url':
                require ModuleHelper::getLayoutPath('mod_menu', 'default_' . $item->type);
                break;
            default:
                require ModuleHelper::getLayoutPath('mod_menu', 'default_url');
                break;
        }

        $lien = ob_get_clean();
    }

    $picto = $corpusRecolterPictogramme($lien);
    $svg   = $picto === ''
        ? ''
        : '<svg class="i" aria-hidden="true" focusable="false"><use href="#'
            . htmlspecialchars($picto, ENT_QUOTES, 'UTF-8') . '" /></svg>';

    // Le mot du declencheur a ete recopie dans la classe du lien par le
    // coeur. Il a fait son travail : il sort du HTML ici.
    if ($ouvreMega) {
        $lien = $corpusRetirerClasse($lien, 'mega');
    }

    // Une rubrique est un element de grille : c'est elle qui porte la colonne.
    echo '<li' . ($estRubrique ? ' class="mega__rubrique"' : '') . '>';

    if ($item->type === 'separator') {
        // Un separateur n'est ni un lien ni un bouton : c'est du texte.
        // Dans un mega il prend le dessin d'une entree, pas celui d'un bouton
        // de repli — qui n'existe pas dans une colonne depliee.
        echo '<span class="' . ($dansMega ? $classeLien : $classeBouton) . '">' . $svg
            . '<span>' . htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8') . '</span></span>';
    } elseif ($estRubrique) {
        /*
         * LE TITRE D'UNE COLONNE.
         *
         * Deux formes, selon que l'entree mene quelque part :
         *
         *   type « Titre de sous-menu » → <p class="mega__titre">, du texte.
         *   toute autre entree          → le <a> du coeur, avec la meme
         *                                 classe : elle a une page, on ne la
         *                                 rend pas inatteignable.
         *
         * SUR ECRAN, aucun bouton : la colonne est deja depliee. SUR
         * TELEPHONE, il en faut un — voir la commande de repli ecrite juste
         * apres les deux formes de titre.
         */
        if ($item->type === 'heading') {
            echo '<p class="' . $classeLien . '">' . $svg
                . htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8') . '</p>';
        } else {
            $attributs = ' class="' . $classeLien . '"';

            if ($actif && !str_contains($lien, 'aria-current')) {
                $attributs .= ' aria-current="page"';
            }

            $lien = preg_replace('/<a\b/', '<a' . $attributs, $lien, 1);

            if ($svg !== '') {
                $lien = preg_replace('/(<a[^>]*>)/', '$1' . $svg, $lien, 1);
            }

            echo $lien;
        }

        /*
         * LA COMMANDE DE REPLI D'UNE COLONNE — 12 aout 2026.
         *
         * Sur telephone, le mega redevient un accordeon et TOUT doit etre
         * plie, rubriques comprises : mesure faite, une colonne depliee de
         * plus donnait 26 entrees a derouler d'un coup pour le seul menu
         * « Vie quotidienne ».
         *
         * Mais un titre de colonne ne peut pas etre un bouton : sur ecran, sa
         * colonne est ouverte et le restera. La commande est donc un bouton
         * SEPARE, pose a cote du titre, que la feuille ne revele qu'en dessous
         * de 48 rem. Au-dessus, il vaut `display: none` : il n'est ni visible,
         * ni focalisable, ni annonce — le bureau est strictement celui d'avant
         * cette ligne, et c'est verifie au banc.
         *
         * On ne duplique PAS l'intitule : le titre reste le titre — un lien,
         * s'il en est un — et le bouton ne porte que le chevron et son nom
         * accessible. Aucune chaine nouvelle a traduire : c'est celle des
         * sous-menus, qui existe deja dans les quatre langues.
         */
        if ($ouvrePanneau) {
            echo '<button type="button" class="mega__replier"'
                . ' aria-expanded="false" aria-controls="' . $idPanneau . '">'
                . '<svg class="chevron" aria-hidden="true" focusable="false"><use href="#i-chevron" /></svg>'
                . '<span class="visuellement-cache">'
                . htmlspecialchars(Text::sprintf('TPL_CORPUS_OUVRIR_SOUS_MENU', $item->title), ENT_QUOTES, 'UTF-8')
                . '</span>'
                . '</button>';
        }
    } elseif ($ouvrePanneau) {
        /*
         * DEUX COMMANDES, PAS UNE — corrige le 1er aout 2026.
         *
         * La premiere version faisait de toute entree parente un <button> :
         * son propre lien disparaissait. Cyrille a affecte une vue de
         * categories a « Nos missions » et la page est devenue inatteignable.
         *
         * Une entree parente porte DEUX actions distinctes — aller a sa page,
         * et deplier ses enfants. Deux actions demandent deux commandes : le
         * lien, puis un bouton de chevron a cote. C'est le motif recommande
         * des qu'un parent a une destination reelle.
         *
         * SAUF pour une entree de type « heading », qui n'a par definition
         * aucune page : elle reste un bouton unique, et tout son intitule
         * declenche l'ouverture. Un lien vers nulle part serait pire.
         */
        $corpusMuette = $item->type === 'heading';

        if ($corpusMuette) {
            echo '<button type="button" class="' . $classeBouton . '"'
                . ' aria-expanded="false" aria-controls="' . $idPanneau . '">'
                . $svg
                . '<span>' . htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8') . '</span>'
                . '<svg class="chevron" aria-hidden="true" focusable="false"><use href="#i-chevron" /></svg>'
                . '</button>';
        } else {
            $attributs = $classeLien === '' ? '' : ' class="' . $classeLien . '"';

            if ($actif && !str_contains($lien, 'aria-current')) {
                $attributs .= ' aria-current="page"';
            }

            if ($attributs !== '') {
                $lien = preg_replace('/<a\b/', '<a' . $attributs, $lien, 1);
            }

            if ($svg !== '') {
                $lien = preg_replace('/(<a[^>]*>)/', '$1' . $svg, $lien, 1);
            }

            // Le bouton porte un nom accessible ECRIT : « Afficher le
            // sous-menu de Nos missions ». Un chevron seul ne dit rien, et
            // trois boutons « Afficher » sur une page ne se distinguent pas.
            //
            // Dans une colonne de mega, la meme paire, deux classes de plus :
            // `.mega__paire` au lieu de `.nav__paire`, `.mega__bascule` au
            // lieu de `.nav__chevron`. Le nom accessible ne change pas — la
            // chaine existe deja dans les quatre langues, il n'y a rien a
            // traduire de plus.
            echo '<span class="' . $classePaire . '">'
                . $lien
                . '<button type="button" class="' . ($dansMega ? 'mega__bascule' : 'nav__chevron') . '"'
                . ' aria-expanded="false" aria-controls="' . $idPanneau . '">'
                . '<svg class="chevron" aria-hidden="true" focusable="false"><use href="#i-chevron" /></svg>'
                . '<span class="visuellement-cache">'
                . htmlspecialchars(Text::sprintf('TPL_CORPUS_OUVRIR_SOUS_MENU', $item->title), ENT_QUOTES, 'UTF-8')
                . '</span>'
                . '</button>'
                . '</span>';
        }
    } else {
        // On greffe nos attributs sur le <a> du coeur plutot que de reecrire
        // le lien : lui seul sait gerer les alias, les liens externes et les
        // redirections.
        //
        // aria-current n'est ajoute QUE si le coeur ne l'a pas deja pose.
        // Sinon l'attribut sort deux fois — HTML invalide, et un lecteur
        // d'ecran peut annoncer la page courante en double.
        $attributs = $classeLien === '' ? '' : ' class="' . $classeLien . '"';

        if ($actif && !str_contains($lien, 'aria-current')) {
            $attributs .= ' aria-current="page"';
        }

        if ($attributs !== '') {
            $lien = preg_replace('/<a\b/', '<a' . $attributs, $lien, 1);
        }

        if ($svg !== '') {
            $lien = preg_replace('/(<a[^>]*>)/', '$1' . $svg, $lien, 1);
        }

        echo $lien;
    }

    if ($ouvrePanneau) {
        /*
         * UN SEUL <ul> OUVERT, QUELLE QUE SOIT LA CLASSE — et c'est tout ce
         * qui protege la page.
         *
         * Le compteur $ouverts et le rattrapage par `shallower` plus bas ne
         * savent rien des classes : ils comptent des panneaux. Le mega ne
         * change donc QUE le nom ecrit dans l'attribut, jamais le nombre
         * d'ouvertures ni de fermetures. Un <ul> non ferme casserait toute la
         * page qui suit le menu, et le banc verifie l'equilibre a chaque
         * rendu pour cette raison.
         *
         *   nav__mega     le panneau d'une entree de barre declenchee
         *   mega__liste   les pages d'une rubrique — toujours visibles
         *   mega__volet   le quatrieme niveau, replie
         *   nav__sous     tout le reste, comme avant
         */
        if ($ouvreMega) {
            $classeUl = 'nav__mega';

            // A partir d'ici, les entrees plus profondes appartiennent au
            // mega. Pose APRES le rendu de l'entree porteuse, qui garde le
            // dessin de la barre.
            $corpusMega = $item->level;
        } elseif ($dansMega) {
            $classeUl = $item->level === 2 ? 'mega__liste' : 'mega__volet';
        } else {
            $classeUl = 'nav__sous';
        }

        echo '<ul class="' . $classeUl . '" id="' . $idPanneau . '">';
        $ouverts++;
    } else {
        echo '</li>';

        // L'entree suivante remonte : on referme autant de panneaux qu'il
        // faut, sans jamais descendre sous zero — les entrees ignorees au
        // dela du niveau 3 fausseraient le compte.
        if ($item->shallower) {
            $aFermer = min((int) $item->level_diff, $ouverts);

            for ($n = 0; $n < $aFermer; $n++) {
                echo '</ul></li>';
                $ouverts--;
            }
        }
    }
endforeach;

// Securite : si le dernier element etait profond, il reste des panneaux
// ouverts. Un <ul> non ferme casse toute la page qui suit.
while ($ouverts > 0) {
    echo '</ul></li>';
    $ouverts--;
}
?>
</ul>
