
// Legend
jQuery(document).ready(function($){
	// group index for legend
	var $legends = $('h3.legend'),
		group = 0;
	// $("fieldset.options-form").hide();

	$legends.each (function () {
		var $legend = $(this),
			$legendGroup = $legend.closest('.control-group'),
			isSub = $legend.is('.sub-legend');
		// add legend class
		$legendGroup.addClass(isSub ? 'sub-legend-group' : 'top-legend-group');
		var	$params = $legendGroup.nextUntil (function() {
				var $next = $(this),
					$nextIsLegend = $next.has('h3.legend').length,
					$nextIsSubLegend = $nextIsLegend && $next.find('h3.legend').is('.sub-legend');
				if (!isSub && $nextIsLegend && $nextIsSubLegend) {
					$next.find('h3.legend').data('top-legend', $legend);
				} 

				return !$next.is('.control-group') || ($nextIsLegend && (isSub || !$nextIsSubLegend));
			});

		// store its legend
		$params.data('legend', $legend);
		$legend.data('params', $params);
	});

	/**
	 * Les champs media survivent a la reorganisation du formulaire.
	 *
	 * Ce script reorganise le formulaire en deplacant les groupes de champs
	 * existants dans de nouveaux conteneurs. Or tout deplacement d'un noeud le
	 * retire d'abord du document : pour un element personnalise, cela declenche
	 * disconnectedCallback puis connectedCallback. <joomla-field-media> n'est
	 * pas remontable — son connectedCallback levait « Misconfiguaration » avant
	 * d'avoir rattache le gestionnaire de clic du bouton « Selectionner », qui
	 * devenait inerte. Les treize champs image du template etaient inutilisables.
	 *
	 * Deux pistes ont ete essayees et abandonnees, elles sont notees ici pour
	 * qu'on ne les reprenne pas :
	 *
	 * 1. Recreer le bouton d'effacement manquant avant la reconnexion. Cela
	 *    faisait taire l'exception, mais le bouton « Selectionner » restait mort.
	 *
	 * 2. moveBefore(), le deplacement atomique. Il ne sert a rien ici : la
	 *    specification prevoit que sans connectedMoveCallback declare, le
	 *    navigateur retombe sur le couple deconnexion/reconnexion. Et declarer
	 *    ce rappel apres coup n'a aucun effet — le navigateur fige la liste des
	 *    rappels au moment du customElements.define(). Verifie par un element
	 *    d'essai : ajouter connectedMoveCallback sur le prototype apres la
	 *    definition ne change rien, le couple est toujours declenche.
	 *
	 * La solution retenue tient en deux gestes, indissociables :
	 *
	 * a. Mettre les champs media de cote AVANT toute reorganisation, puis les
	 *    RECREER une fois la mise en page terminee, a leur emplacement
	 *    definitif. Un element neuf voit son connectedCallback s'executer une
	 *    seule fois, la ou il restera.
	 *
	 * b. Retablir au passage le bouton d'effacement. Joomla le retire lui-meme
	 *    quand le champ est vide, or son connectedCallback exige de le trouver.
	 *    Sans ce geste, l'element recree leve la meme exception que l'ancien.
	 *
	 * Verifie dans le navigateur : le premier geste seul ne suffit pas, les deux
	 * ensemble ouvrent la mediatheque.
	 */
	var champsMediaMisDeCote = [];

	var mettreDeCoteChampsMedia = function ($racine) {
		$racine.find('joomla-field-media').each(function () {
			var marque = document.createElement('span');
			marque.className = 'corpus-marque-media';
			marque.setAttribute('aria-hidden', 'true');

			champsMediaMisDeCote.push({ marque: marque, html: this.outerHTML });

			this.parentNode.replaceChild(marque, this);
		});
	};

	var retablirChampsMedia = function () {
		champsMediaMisDeCote.forEach(function (champ) {
			if (!champ.marque.parentNode) {
				return;
			}

			var gabarit = document.createElement('div');
			gabarit.innerHTML = champ.html;

			var neuf = gabarit.firstElementChild;

			if (!neuf) {
				return;
			}

			// Bouton d'effacement : Joomla le retire quand le champ est vide,
			// mais son connectedCallback exige de le retrouver. On le remet.
			var selecteur = neuf.getAttribute('button-clear') || '.button-clear',
				groupe = neuf.querySelector('.input-group');

			if (groupe && !neuf.querySelector(selecteur)) {
				var bouton = document.createElement('button');
				bouton.type = 'button';
				bouton.className = 'btn btn-secondary ' + selecteur.replace(/^\./, '');
				bouton.setAttribute('aria-hidden', 'true');
				groupe.appendChild(bouton);
			}

			champ.marque.parentNode.replaceChild(neuf, champ.marque);
		});

		champsMediaMisDeCote = [];
	};

	/**
	 * LES EDITEURS EN DOUBLE — mesure du 2 aout 2026 sur le banc.
	 *
	 * Le champ « CSS personnalise » affichait DEUX zones CodeMirror l'une sous
	 * l'autre, pour un seul <textarea>.
	 *
	 * MEME CAUSE QUE LES CHAMPS MEDIA, plus haut : la reorganisation deplace
	 * les noeuds, et deplacer un element personnalise, c'est le deconnecter
	 * puis le reconnecter. `joomla-field-media` s'en trouvait casse ; le
	 * `joomla-editor-codemirror`, lui, ne se protege pas contre une seconde
	 * initialisation : il construit un deuxieme editeur a cote du premier.
	 *
	 * Le remede n'est pas le meme parce que le symptome n'est pas le meme. On
	 * ne peut PAS recreer l'element depuis son outerHTML : il contient deja
	 * l'editeur construit, on en obtiendrait un troisieme. On supprime donc les
	 * exemplaires en trop.
	 *
	 * PREMIERE TENTATIVE FAUSSE, ET MESUREE COMME TELLE : elle cherchait des
	 * `joomla-editor-codemirror` en double. Il n'y en a qu'UN — c'est LUI qui
	 * contient deux `.cm-editor`, parce que son connectedCallback s'est
	 * execute deux fois sur le meme element. Le nettoyage doit donc se faire
	 * A L'INTERIEUR de l'element, pas a cote.
	 *
	 * On garde la DERNIERE vue : celle que la derniere execution a construite,
	 * donc celle que l'element reference et qui recopiera le texte dans le
	 * <textarea> au moment d'enregistrer.
	 *
	 * A appeler APRES toute la reorganisation, comme retablirChampsMedia().
	 */
	var dedupliquerEditeurs = function () {
		var elements = document.querySelectorAll('joomla-editor-codemirror');

		var elaguer = function (el) {
			var vues = el.querySelectorAll('.cm-editor');

			// On garde LA DERNIERE : c'est celle que la derniere construction
			// a produite, donc celle que l'element reference et qui recopiera
			// le texte dans le <textarea> au moment d'enregistrer.
			for (var i = 0; i < vues.length - 1; i++) {
				vues[i].parentNode.removeChild(vues[i]);
			}
		};

		Array.prototype.forEach.call(elements, function (el) {
			elaguer(el);

			// UN OBSERVATEUR, PAS UN PASSAGE UNIQUE — et c'est le coeur du
			// correctif. Mesure du 2 aout : au moment ou cette fonction
			// s'execute, le second editeur N'EXISTE PAS ENCORE. Le plugin
			// construit sa vue de facon asynchrone — il importe son module
			// CodeMirror — et elle apparait apres notre passage.
			//
			// Deux versions ont ete livrees avant de mesurer ce point, et
			// aucune ne pouvait marcher : elles nettoyaient un desordre qui
			// n'etait pas encore la. C'est la faute du § 3 du referentiel,
			// « une instrumentation posee apres coup ne se declenche jamais »,
			// dans sa version symetrique — une correction posee AVANT la cause.
			new MutationObserver(function () {
				elaguer(el);
			}).observe(el, { childList: true, subtree: true });
		});
	};

	var deplacer = function ($parent, $enfants) {
		$parent.append($enfants);
		return $parent;
	};

	var j3TabPane = $('.tab-pane');
	var j4TabPane = "[role='tabpanel']";
	var $tabPane = j3TabPane.length !== 0 ? j3TabPane : $(j4TabPane);
	// grouping legend and params
	$tabPane.each(function(){
		var $pane = $(this),
			$topLegends = $pane.find('.top-legend-group');

		// Doit passer AVANT tout deplacement.
		mettreDeCoteChampsMedia($pane);

		var fieldSet = $pane.find("fieldset.options-form").length === 0
			? $pane : $pane.find("fieldset.options-form");
		// Les conteneurs sont crees ET rattaches au document AVANT d'y deplacer
		// quoi que ce soit : moveBefore exige un parent connecte.
		deplacer($('<div />').addClass('group-legends').appendTo(fieldSet), $topLegends);

		$topLegends.each(function(){
			var $legend = $(this).find('h3'),
				$params = $legend.data('params'),
				$subLegends = $params.filter('.sub-legend-group'),
				$topGroup = $('<div />');

			$topGroup.addClass('top-group').appendTo(fieldSet);

			var $subGroupDirect = $('<div />').addClass('sub-group sub-group-direct').appendTo($topGroup);
			var $inner = $('<div />').addClass('sub-group-inner').appendTo($subGroupDirect);
			deplacer($inner, $params);

			$subLegends.each(function() {
				var $subLegendGroup = $(this),
					$subLegend = $subLegendGroup.find('h3'),
					$params = $subLegend.data('params');

				var $sousGroupe = $('<div />').addClass('sub-group').appendTo($topGroup);
				var $sousInner = $('<div />').addClass('sub-group-inner').appendTo($sousGroupe);
				deplacer($sousInner, $subLegendGroup);
				deplacer($('<div />').addClass('sub-group-params').appendTo($sousInner), $params);
			});
			// remove empty group
			if (!$subGroupDirect.find('.sub-group-inner').children().length) $subGroupDirect.remove();
			// add sub-group-direct class to top-group-enabler
			$topGroup.find('.top-group-enabler').closest('.sub-group').addClass('sub-group-direct');
			// store for later use
			$(this).data('top-group', $topGroup);
		});
	});

	// La mise en page est terminee : les champs media peuvent etre recrees a
	// leur emplacement definitif. Ils ne seront plus deplaces ensuite.
	retablirChampsMedia();
	dedupliquerEditeurs();

	// Le formulaire est reorganise. layout.js, reecrit en JavaScript natif,
	// attend ce signal pour dessiner : jQuery 3 differe ses rappels « ready »
	// dans une micro-tache, donc APRES les ecouteurs DOMContentLoaded natifs.
	// Sans cet evenement, layout.js dessinerait sur un formulaire encore
	// dans son etat d'origine — il ne trouverait ni les groupes, ni le rail.
	document.documentElement.dataset.corpusFormulairePret = '1';
	document.dispatchEvent(new CustomEvent('corpus:formulaire-pret'));


	// show/hide top group
	var showTopGroup = function ($legendGroup) {
		var j3TabPane = $legendGroup.closest('.tab-pane');
		var $topGroup = $legendGroup.data('top-group'),
			$tabPane = j3TabPane.length !== 0
				? j3TabPane : $legendGroup.closest(j4TabPane);
			$otherLegendGroups = $tabPane.find('.top-legend-group').not($legendGroup),
			$otherTopGroups = $tabPane.find('.top-group').not($topGroup);
		if ($otherTopGroups){
			$otherTopGroups.removeClass('active').hide();
		}
		if ($topGroup){
			$topGroup.addClass('active').fadeIn();
		}
		$legendGroup.addClass('active');
		$otherLegendGroups.removeClass('active');

		$(document).trigger('switchLegendGroup', $legendGroup);

		// Pont vers le JavaScript natif. Un evenement declenche par
		// jQuery.trigger() ne reveille pas les ecouteurs poses par
		// addEventListener : sans ce second envoi, layout.js — reecrit sans
		// jQuery — ne verrait jamais le changement de groupe.
		document.dispatchEvent(new CustomEvent('corpus:groupe-actif', {
			detail: $legendGroup[0]
		}));
	}

	$('.top-legend-group').on('click', function(){
		showTopGroup($(this));
		if (localStorage && $(this).closest('.tab-pane').length !== 0) {
			localStorage.setItem('last_active_group','#' + $(this).closest('.tab-pane').attr('id')
													+ ' .top-legend-group:nth-child(' + ($(this).index() + 1) + ')');
		}else{
			localStorage.setItem('last_active_group','#' + $(this).closest(j4TabPane).attr('id')
				+ ' .top-legend-group:nth-child(' + ($(this).index() + 1) + ')');
		}
	});

	// last active
	var $lastActiveGroup;
	if (localStorage && localStorage.getItem('last_active_group')) {
		$lastActiveGroup = $(localStorage.getItem('last_active_group'));
	}

	setTimeout(function(){
		var $j3TabPane = $('.tab-pane .top-legend-group:first-child');
		var $tabPane = $j3TabPane.length !== 0
			? $j3TabPane
			: $("[role='tabpanel'] .top-legend-group:first-child");
		$tabPane.trigger('click');
		if ($lastActiveGroup){
			$lastActiveGroup.trigger('click');
		}
	}, 500);

	// Enabler
	var toggleEnablerGroup = function ($enabler) {
		var enabled = $enabler.find('input:checked').val(),
			isTopEnabler = $enabler.is('.top-group-enabler'),
			$legendGroup = $enabler.closest('.control-group'),
			$groupParams = $legendGroup.next();
		if (enabled == '1') {
			if (isTopEnabler) {
				$legendGroup.closest('.top-group').find('.sub-group').show();
			}
			$groupParams.show();
		} else {
			if (isTopEnabler) {
				$legendGroup.closest('.top-group').find('.sub-group').slice(1).hide();
			}
			$groupParams.hide();
		}
	}
	$('.group-enabler, .top-group-enabler').on ('click', function(e) {
		toggleEnablerGroup($(this));
		e.stopPropagation();
	});

	// first enabler
	$('.group-enabler, .top-group-enabler').each (function () {
		toggleEnablerGroup ($(this));
	});

});



// tracking change for group
jQuery(document).ready(function($) {
	var j4TabPane = "[role='tabpanel']";
	var j3TabContent = $('#myTabContent').find('input, textarea, select');
	var j4TabContent = $('.main-card').find('input, textarea, select');
	var $inputs = j3TabContent.length !== 0 ? j3TabContent : j4TabContent,
		tplhelperValue = $('#tplhelper').val(),
		tplhelper = null;
	try {
		tplhelper = JSON.parse (tplhelperValue);
	} catch (e) {

	}

	if (tplhelper === null || typeof tplhelper !== 'object') tplhelper = {};
	// get origin value
	$inputs.each (function() {
		var $input = $(this),
			$val = $input.attr('type') == 'radio' ? $input.closest('fieldset').find('input:checked').val() : $input.val();
		$input.data('org-value', $val);
	});

	//tracking change
	$inputs.on('change', function () {
		var $input = $(this), val = $input.val(),
			groupid = $input.closest('.tab-pane').length !== 0
				? $input.closest('.tab-pane').attr('id').substr()
				: $input.closest(j4TabPane).attr('id').substr(),
			group = groupid.substr(0, 7) == 'attrib-' ? groupid.substr(7) : null;
		// track change
		if ($input.data('org-value') != val) {
			var $legend = $input.closest('.control-group').addClass('modified').data('legend');
			$legend.closest('.control-group').addClass('modified');
			// if sub legend, add modified to top legend
			if ($legend.is('.sub-legend')) {
				$legend.data('top-legend').closest('.control-group').addClass('modified');
			}
			// add change for legend

			// update change status for hidden tplhelper
			if (group) {
				tplhelper[group] = 1;
				$('#tplhelper').val(JSON.stringify(tplhelper));
			}
		} else {
			var $legend = $input.closest('.control-group').removeClass('modified').data('legend');
			// detect legend changed
			if ($legend.data('params').filter('.modified').length == 0) {
				$legend.closest('.control-group').removeClass('modified');
				// if sub-legend, check for top-legend
				if ($legend.is('.sub-legend')) {
					if ($legend.data('top-legend').data('params').filter('.modified').length == 0) {
						$legend.data('top-legend').closest('.control-group').removeClass('modified');
					}
				}
			}
			if (group) {
				if ($input.closest('.tab-pane').find('.control-group').filter('.modified').length == 0) {
					// turn off change
					tplhelper[group] = 0;
					$('#tplhelper').val(JSON.stringify(tplhelper));
				}
			}
		}
	})
});
