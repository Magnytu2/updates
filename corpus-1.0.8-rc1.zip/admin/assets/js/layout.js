/**
 * Schema des positions de modules — onglet Layout.
 *
 * Reecriture en JavaScript natif de la version jQuery d'origine. Trois
 * raisons a cette reecriture, dans l'ordre d'importance :
 *
 * 1. L'ancienne version posait la largeur des colonnes en classes de grille
 *    Bootstrap 2 (« span4 », « col-md-4 ») heritees d'un CSS qui n'existe plus
 *    dans Joomla 6, et l'ombre du reste en styles en ligne. Aucune regle de
 *    notre feuille ne pouvait reprendre la main dessus. Ici, une seule valeur
 *    part du JavaScript, la part de largeur, et elle passe par la variable
 *    « --part » : la feuille garde le dernier mot.
 * 2. Elle dependait de jQuery pour tout, y compris pour lire les valeurs du
 *    formulaire. Plus rien ici n'en depend.
 * 3. Elle mettait a jour le schema par retouches partielles, chaque reglage
 *    ayant sa fonction. On redessine desormais l'ensemble a chaque changement :
 *    le schema ne peut plus deriver de l'etat reel du formulaire.
 *
 * Le seul point de contact avec legend.js reste l'evenement
 * « corpus:groupe-actif », que legend.js emet nativement a cote de son
 * evenement jQuery. Un evenement declenche par jQuery.trigger() ne reveille
 * pas les ecouteurs poses par addEventListener : le pont est indispensable.
 */
(function () {
	'use strict';

	var PANNEAU = 'attrib-layouts';
	var COLONNES = 12;

	/**
	 * Description du schema.
	 *
	 * Chaque bande correspond a une section du gabarit. « temoin » est le
	 * champ qui sert a retrouver, dans le formulaire deja reorganise par
	 * legend.js, le libelle traduit de la section et son entree dans le rail.
	 *
	 * type « colonnes »   : les cases sont decrites une a une.
	 * type « projecteur » : les cases sont deduites du champ de largeur, qui
	 *                       contient une suite du genre « 4:4:4 ».
	 */
	var SCHEMA = [
		{
			cle: 'topbar', type: 'colonnes', temoin: 'layoutEnable_topbar',
			cases: [
				{ cle: 'topbar_left', temoin: 'layoutPos_topbar_left', position: 'layoutPos_topbar_left' },
				{ cle: 'topbar_right', temoin: 'layoutPos_topbar_right', position: 'layoutPos_topbar_right', activable: true }
			]
		},
		{
			cle: 'header', type: 'colonnes', temoin: 'layoutContainer_header',
			cases: [
				{ cle: 'header_left', temoin: 'layoutWidth_header_left', largeur: 'layoutWidth_header_left' },
				{ cle: 'header_right', temoin: 'layoutPos_header_right', largeur: 'layoutWidth_header_right', position: 'layoutPos_header_right', activable: true }
			]
		},
		{
			cle: 'nav', type: 'colonnes', temoin: 'layoutContainer_nav',
			cases: [
				{ cle: 'nav_left', temoin: 'layoutPos_nav_left', largeur: 'layoutWidth_nav_left', position: 'layoutPos_nav_left' },
				{ cle: 'nav_right', temoin: 'layoutPos_nav_right', largeur: 'layoutWidth_nav_right', position: 'layoutPos_nav_right', activable: true }
			]
		},
		{ cle: 'top_1', type: 'projecteur', temoin: 'layoutPos_top_1' },
		{ cle: 'top_2', type: 'projecteur', temoin: 'layoutPos_top_2' },
		{ cle: 'top_3', type: 'projecteur', temoin: 'layoutPos_top_3' },
		{ cle: 'top_4', type: 'projecteur', temoin: 'layoutPos_top_4' },
		{
			cle: 'content', type: 'colonnes', temoin: 'layoutPosition_content',
			cases: [
				{ cle: 'main_top', temoin: 'layoutPos_main_top', position: 'layoutPos_main_top', activable: true, rangee: 'haut' },
				{ cle: 'content', temoin: 'layoutPosition_content', principale: true },
				{ cle: 'col_1', temoin: 'layoutPos_col_1', largeur: 'layoutWidth_col_1', position: 'layoutPos_col_1', activable: true },
				{ cle: 'col_2', temoin: 'layoutPos_col_2', largeur: 'layoutWidth_col_2', position: 'layoutPos_col_2', activable: true },
				{ cle: 'main_bottom', temoin: 'layoutPos_main_bottom', position: 'layoutPos_main_bottom', activable: true, rangee: 'bas' }
			]
		},
		{ cle: 'bot_1', type: 'projecteur', temoin: 'layoutPos_bot_1' },
		{ cle: 'bot_2', type: 'projecteur', temoin: 'layoutPos_bot_2' },
		{ cle: 'bot_3', type: 'projecteur', temoin: 'layoutPos_bot_3' },
		{ cle: 'bot_4', type: 'projecteur', temoin: 'layoutPos_bot_4' },
		{ cle: 'footer', type: 'projecteur', temoin: 'layoutPos_footer' }
	];

	var panneau, schema, bandes, railParBande = {};

	/** Chaine traduite, publiee par tplhelper.php, avec repli en clair. */
	function traduire (cle, repli) {
		var texte = window.Joomla && Joomla.Text ? Joomla.Text._(cle, repli) : repli;

		return texte === cle ? repli : texte;
	}

	/* --- Lecture du formulaire ---------------------------------------------
	   Aucune valeur n'est memorisee : on relit le formulaire a chaque dessin.
	   C'est ce qui garantit que le schema ne peut pas deriver. */

	function champ (nom) {
		return panneau.querySelector('[name="jform[params][' + nom + ']"]');
	}

	function valeur (nom) {
		var coche = panneau.querySelector('[name="jform[params][' + nom + ']"]:checked');

		if (coche) {
			return coche.value;
		}

		var unique = champ(nom);

		// Un groupe de radios dont aucune option n'est cochee n'a pas de valeur :
		// ne pas confondre avec la premiere option.
		if (!unique || unique.type === 'radio' || unique.type === 'checkbox') {
			return '';
		}

		return unique.value;
	}

	function actif (cle) {
		return valeur('layoutEnable_' + cle) === '1';
	}

	/**
	 * Libelle traduit d'une section : celui de son sous-groupe dans le
	 * formulaire. On le lit dans le document plutot que de le figer ici, pour
	 * qu'il suive la langue de l'administration.
	 */
	function libelle (temoin, repli) {
		var element = champ(temoin) || panneau.querySelector('#jform_params_' + temoin);
		var groupe = element && element.closest('.sub-group');
		var titre = groupe && groupe.querySelector('h3.legend span');

		return titre && titre.textContent.trim() ? titre.textContent.trim() : repli;
	}

	/** Le conteneur d'une section : reglage propre, ou reglage general. */
	function conteneur (cle) {
		var propre = valeur('layoutContainer_' + cle);

		return (propre === '' ? valeur('layoutContainer') : propre) === '1';
	}

	/* --- Construction ------------------------------------------------------ */

	function element (balise, classe, texte) {
		var noeud = document.createElement(balise);

		if (classe) {
			noeud.className = classe;
		}

		if (texte != null) {
			noeud.textContent = texte;
		}

		return noeud;
	}

	function dessinerCase (description) {
		var boite = element('div', 'case');

		boite.dataset.cle = description.cle;
		boite.style.setProperty('--part', description.part);

		if (description.principale) {
			boite.classList.add('principale');
		}

		if (description.position) {
			boite.appendChild(element('span', 'jeton', description.position));
		}

		boite.appendChild(element('span', 'case-nom', description.nom));

		return boite;
	}

	/** Cases d'une bande a colonnes, largeur automatique comprise. */
	/**
	 * Les cases d'une bande a colonnes, pour UNE rangee donnee.
	 *
	 * `rangee` vaut null pour la rangee principale, 'haut' ou 'bas' pour les
	 * rangees pleine largeur — main-top et main-bottom, qui sont dans la colonne
	 * de contenu et non a cote d'elle. Les dessiner comme des colonnes les aurait
	 * montrees a cote du composant, ce qui est faux.
	 */
	function casesColonnes (bande, rangee) {
		rangee = rangee || null;

		var restant = COLONNES;
		var auto = [];

		var cases = bande.cases.filter(function (c) {
			return (c.rangee || null) === rangee && (!c.activable || actif(c.cle));
		}).map(function (c) {
			var description = {
				cle: c.cle,
				nom: libelle(c.temoin, c.cle),
				position: c.position ? valeur(c.position) : '',
				principale: !!c.principale,
				part: 0
			};

			// Une rangee pleine largeur ne partage rien : elle prend tout.
			if (rangee) {
				description.part = COLONNES;

				return description;
			}

			var largeur = c.largeur ? parseInt(valeur(c.largeur), 10) : NaN;

			if (isNaN(largeur)) {
				auto.push(description);
			} else {
				description.part = largeur;
				restant -= largeur;
			}

			return description;
		});

		/*
		 * LES CASES SANS LARGEUR DECLAREE SE PARTAGENT LE RESTE.
		 *
		 * L'ancienne version n'en gardait qu'UNE — la derniere rencontree —, les
		 * precedentes restaient a une part de zero et disparaissaient sans
		 * explication. Sans consequence tant qu'une seule case etait dans ce cas ;
		 * la barre d'information, qui a deux cotes et aucune largeur a regler, l'a
		 * rendu visible.
		 */
		if (auto.length) {
			var part = Math.floor(restant / auto.length);

			auto.forEach(function (description) {
				description.part = part > 0 ? part : 1;
			});
		}

		return cases.map(dessinerCase);
	}

	/**
	 * Cases d'un projecteur : une par largeur declaree dans le champ.
	 *
	 * Champ vide, le gabarit repartit les modules sur douze colonnes selon
	 * leur nombre — nombre que le schema ignore, puisqu'il depend des modules
	 * publies. On le dit, plutot que d'inventer une repartition. L'ancienne
	 * version affichait « 4:4:4 » dans ce cas, ce qui etait faux la plupart
	 * du temps.
	 */
	function casesProjecteur (bande) {
		var brut = valeur('layoutWidth_' + bande.cle).replace(/\s/g, '');

		if (!/^[0-9]+([:,-][0-9]+)*$/.test(brut)) {
			return [dessinerCase({
				cle: bande.cle + '_auto',
				nom: traduire('TPL_CORPUS_SCHEMA_AUTO', 'Repartition automatique'),
				position: '',
				part: COLONNES
			})];
		}

		return brut.split(/[:,-]/).map(function (part, rang) {
			var largeur = parseInt(part, 10);

			return dessinerCase({
				cle: bande.cle + '_' + (rang + 1),
				nom: traduire('TPL_CORPUS_SCHEMA_MODULE', 'Module') + ' ' + (rang + 1),
				position: '',
				part: isNaN(largeur) ? 1 : largeur
			});
		});
	}

	function dessinerBande (bande) {
		var noeud = element('div', 'bande');
		var allumee = actif(bande.cle);

		noeud.dataset.cle = bande.cle;

		if (!allumee) {
			noeud.classList.add('eteinte');
		}

		if (!conteneur(bande.cle)) {
			noeud.classList.add('sans-conteneur');
		}

		// Le nom personnalise d'un projecteur l'emporte sur le libelle du
		// formulaire : c'est celui que l'auteur du site lira dans son gabarit.
		var nom = (bande.type === 'projecteur' ? valeur('layoutName_' + bande.cle).trim() : '')
			|| libelle(bande.temoin, bande.cle);

		var entete = element('button', 'bande-entete');

		entete.type = 'button';
		entete.appendChild(element('span', 'bande-nom', nom));

		if (bande.type === 'projecteur') {
			var position = valeur('layoutPos_' + bande.cle);

			if (position) {
				entete.appendChild(element('span', 'jeton', position));
			}
		}

		noeud.appendChild(entete);

		if (allumee) {
			// Contenu a droite : le bloc principal passe apres les colonnes.
			if (bande.cle === 'content' && valeur('layoutPosition_content') === 'right') {
				noeud.classList.add('contenu-a-droite');
			}

			if (bande.type === 'projecteur') {
				var cases = element('div', 'cases');

				casesProjecteur(bande).forEach(function (boite) {
					cases.appendChild(boite);
				});

				noeud.appendChild(cases);
			} else {
				/*
				 * MAIN-TOP ET MAIN-BOTTOM SONT DANS LA COLONNE, PAS SOUS LA PAGE.
				 *
				 * Premiere version fausse, et Cyrille l'a dessinee a la main sur une
				 * capture : je les avais posees en rangees pleine largeur, donc elles
				 * passaient SOUS la colonne laterale. La carte racontait une autre
				 * page que le gabarit, ou elles vivent a l'interieur du <main>.
				 *
				 * La case principale devient donc une PILE : rangee haute, composant,
				 * rangee basse, empilees dans la largeur du contenu. Les colonnes
				 * laterales restent a cote et montent sur toute la hauteur, ce qui est
				 * exactement ce que fait la grille du site.
				 */
				var cases = element('div', 'cases');
				var haut = casesColonnes(bande, 'haut');
				var bas = casesColonnes(bande, 'bas');

				casesColonnes(bande, null).forEach(function (boite) {
					if (!boite.classList.contains('principale') || (!haut.length && !bas.length)) {
						cases.appendChild(boite);

						return;
					}

					var pile = element('div', 'pile');

					// La pile herite de la part de la case principale : c'est elle qui
					// occupe desormais sa place dans la rangee.
					pile.style.setProperty('--part', boite.style.getPropertyValue('--part'));

					haut.forEach(function (b) { pile.appendChild(b); });
					pile.appendChild(boite);
					bas.forEach(function (b) { pile.appendChild(b); });

					cases.appendChild(pile);
				});

				noeud.appendChild(cases);
			}
		}

		return noeud;
	}

	function dessiner () {
		bandes.textContent = '';

		SCHEMA.forEach(function (bande) {
			bandes.appendChild(dessinerBande(bande));
		});

		marquerActive();
	}

	/* --- Rail : lien dans les deux sens -------------------------------------
	   legend.js range les groupes de reglages (.top-group) dans le meme ordre
	   que les entrees du rail (.group-legends .control-group). On retrouve donc
	   l'entree d'une bande par le rang de son groupe, sans avoir a lire les
	   donnees privees que jQuery attache aux elements. */

	function apparierRail () {
		var groupes = Array.prototype.slice.call(panneau.querySelectorAll('.top-group'));
		var entrees = panneau.querySelectorAll('.group-legends .control-group');

		SCHEMA.forEach(function (bande) {
			var temoin = champ(bande.temoin) || panneau.querySelector('#jform_params_' + bande.temoin);
			var groupe = temoin && temoin.closest('.top-group');
			var rang = groupe ? groupes.indexOf(groupe) : -1;

			if (rang >= 0 && entrees[rang]) {
				railParBande[bande.cle] = entrees[rang];
			}
		});
	}

	function marquerActive () {
		var entree = panneau.querySelector('.group-legends .control-group.active');

		bandes.querySelectorAll('.bande').forEach(function (noeud) {
			var lien = railParBande[noeud.dataset.cle];
			var active = !!entree && lien === entree;

			noeud.classList.toggle('active', active);
			noeud.querySelector('.bande-entete').setAttribute('aria-current', active ? 'true' : 'false');
		});
	}

	/* --- Mise en place ----------------------------------------------------- */

	function demarrer () {
		panneau = document.getElementById(PANNEAU);

		if (!panneau || panneau.querySelector('#layout-preview')) {
			return;
		}

		schema = element('div', 'schema');
		schema.id = 'layout-preview';

		var titre = element('div', 'schema-titre');

		titre.appendChild(element('span', null, traduire('TPL_CORPUS_SCHEMA_TITLE', 'Positions de modules')));
		schema.appendChild(titre);

		bandes = element('div', 'bandes');
		schema.appendChild(bandes);

		// Le schema prend place dans le formulaire lui-meme, a cote de la
		// colonne des reglages : c'est la feuille qui les met en vis-a-vis,
		// par une simple boite flexible. L'ancienne version le detachait du
		// flux, ce qui obligeait a lui reserver sa place a la main.
		var hote = panneau.querySelector('fieldset.options-form') || panneau;

		hote.insertBefore(schema, hote.firstChild);

		apparierRail();
		dessiner();

		// Un clic sur une bande ouvre les reglages de sa section. legend.js
		// ecoute par jQuery, qui pose de vrais ecouteurs : un clic natif suffit.
		bandes.addEventListener('click', function (evenement) {
			var entete = evenement.target.closest('.bande-entete');
			var lien = entete && railParBande[entete.parentNode.dataset.cle];

			if (lien) {
				lien.click();
			}
		});

		document.addEventListener('corpus:groupe-actif', marquerActive);

		panneau.addEventListener('change', dessiner);

		// Le reglage general du conteneur vit dans le meme panneau, mais un
		// champ media peut annoncer sa valeur par jQuery, dont l'evenement ne
		// remonte pas jusqu'a l'ecouteur natif. Le pont ne coute qu'un redessin
		// de plus, et le dessin est idempotent.
		if (window.jQuery) {
			window.jQuery(panneau).on('change', dessiner);
		}
	}

	// On ne dessine qu'une fois le formulaire reorganise par legend.js, qui
	// annonce l'avoir fait. DOMContentLoaded ne suffirait pas : jQuery 3
	// differe ses rappels « ready » dans une micro-tache, donc apres les
	// ecouteurs natifs. demarrer() est sans effet s'il est appele deux fois.
	if (document.documentElement.dataset.corpusFormulairePret) {
		demarrer();
	} else {
		document.addEventListener('corpus:formulaire-pret', demarrer);
	}
}());
