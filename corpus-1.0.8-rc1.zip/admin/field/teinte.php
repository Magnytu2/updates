<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE CHAMP DE TEINTE — 0 a 359.
 *
 * Le reglage de teinte du site. Deux representations de la MEME valeur :
 *
 *   - un champ nombre, qui PORTE le nom : c'est lui qui est envoye. Sans
 *     JavaScript il reste saisissable au clavier, et le champ fonctionne.
 *     C'est la raison du choix : un curseur seul ne se regle pas au clavier
 *     avec precision, et n'affiche pas sa valeur.
 *   - un curseur, dont le degrade EST le cercle chromatique aux saturation et
 *     clarte du site : ce que l'on choisit est ce que l'on voit.
 *
 * Une pastille doublait le curseur, et le champ portait un symbole « degre » :
 * retires le 31 juillet 2026 a la demande de Cyrille. Ils encombraient la
 * ligne sans rien apprendre de plus que le degrade.
 *
 * JavaScript natif, sans jQuery — contrairement a legend.js et script.js, qui
 * restent a porter.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormField;

class JFormFieldTeinte extends FormField
{
    protected $type = 'Teinte';

    /**
     * Le script qui tient les deux representations d'accord.
     *
     * Pose une seule fois, quel que soit le nombre de champs : la delegation
     * sur document evite d'attacher un ecouteur par champ, et fonctionne meme
     * si legend.js deplace le champ dans le formulaire — ce qu'il fait.
     */
    public function setup(SimpleXMLElement $element, $value, $group = null)
    {
        Factory::getDocument()->addScriptDeclaration(<<<'JS'
(function () {
	'use strict';

	if (window.corpusTeinteInitialise) { return; }
	window.corpusTeinteInitialise = true;

	var borner = function (v) {
		v = parseInt(v, 10);
		if (isNaN(v)) { return 90; }
		return Math.max(0, Math.min(359, v));
	};

	var accorder = function (champ, valeur, sauf) {
		var nombre  = champ.querySelector('[name]'),
			curseur = champ.querySelector('[data-corpus-teinte-curseur]');

		if (nombre && nombre !== sauf)   { nombre.value = valeur; }
		if (curseur && curseur !== sauf) { curseur.value = valeur; }
	};

	document.addEventListener('input', function (e) {
		var champ = e.target.closest && e.target.closest('[data-corpus-teinte]');
		if (!champ) { return; }
		accorder(champ, borner(e.target.value), e.target);
	});

	// Une valeur hors bornes saisie au clavier n'est ramenee qu'a la sortie du
	// champ : la corriger a chaque frappe empecherait de taper « 120 », le
	// « 1 » devenant aussitot valide et le curseur sautant.
	document.addEventListener('change', function (e) {
		var champ = e.target.closest && e.target.closest('[data-corpus-teinte]');
		if (!champ) { return; }
		var v = borner(e.target.value);
		e.target.value = v;
		accorder(champ, v, null);
	});
})();
JS);

        return parent::setup($element, $value, $group);
    }

    protected function getInput()
    {
        $valeur = (string) $this->value;

        if ($valeur === '' || !is_numeric($valeur)) {
            $valeur = (string) ($this->element['default'] ?? 90);
        }

        $valeur = max(0, min(359, (int) $valeur));
        $id     = $this->id;
        $nom    = $this->name;

        // Le degrade du cercle chromatique, aux memes saturation et clarte que
        // l'accent du site. Douze arrets suffisent a le rendre continu.
        $arrets = [];

        for ($h = 0; $h <= 360; $h += 30) {
            $arrets[] = 'hsl(' . ($h % 360) . ' 40% 32%) ' . round($h / 3.6, 2) . '%';
        }

        $degrade = implode(', ', $arrets);

        $html = '<div class="corpus-teinte" data-corpus-teinte>'

            . '<input type="number" class="form-control corpus-teinte__nombre"'
            . ' name="' . $nom . '" id="' . $id . '"'
            . ' min="0" max="359" step="1" inputmode="numeric"'
            . ' value="' . $valeur . '">'

            // Le curseur double le champ nombre : il ne porte pas de nom, donc
            // il n'envoie rien, et aria-hidden l'ecarte des lecteurs d'ecran.
            // Sans cela, la meme valeur serait annoncee deux fois.
            . '<input type="range" class="corpus-teinte__curseur" data-corpus-teinte-curseur'
            . ' min="0" max="359" step="1" value="' . $valeur . '"'
            . ' tabindex="-1" aria-hidden="true"'
            . ' style="background: linear-gradient(to right, ' . $degrade . ');">'

            . '</div>';

        return $html;
    }
}
