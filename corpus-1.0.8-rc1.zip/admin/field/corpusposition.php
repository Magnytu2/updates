<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\Component\Modules\Administrator\Field\ModulesPositionField;

/**
 * Selecteur de position de module.
 *
 * Le champ de Joomla ne propose que les positions ou un module est deja
 * publie : impossible d'assigner un emplacement vide comme sidebar-left tant
 * qu'aucun module n'y figure. On complete donc la liste avec les positions
 * declarees par le template dans son manifeste.
 *
 * Le nom de classe reste au format historique JFormField* : c'est celui que
 * cherche le chargeur de champs de Joomla lorsqu'un fieldset declare
 * addfieldpath.
 */
class JFormFieldCorpusPosition extends ModulesPositionField
{
    /**
     * @var string
     */
    protected $type = 'CorpusPosition';

    /**
     * Liste des positions : celles en service, plus celles du manifeste.
     *
     * La visibilite doit rester publique : c'est celle de ModulesPositionField,
     * et PHP interdit de la restreindre dans une classe fille.
     *
     * @return array
     */
    public function getOptions()
    {
        $options = parent::getOptions();

        $connues = [];

        foreach ($options as $option) {
            if (isset($option->value)) {
                $connues[] = (string) $option->value;
            }
        }

        foreach ($this->getTemplatePositions() as $position) {
            if (in_array($position, $connues, true)) {
                continue;
            }

            $options[] = HTMLHelper::_('select.option', $position, $position);
        }

        return $options;
    }

    /**
     * Positions declarees dans le templateDetails.xml du template edite.
     *
     * @return string[]
     */
    private function getTemplatePositions(): array
    {
        $template = $this->form ? $this->form->getValue('template') : null;

        if (!$template) {
            $template = Factory::getApplication()->getInput()->getCmd('template', '');
        }

        $template = preg_replace('/[^a-z0-9_-]/i', '', (string) $template);

        if ($template === '') {
            return [];
        }

        $manifeste = JPATH_SITE . '/templates/' . $template . '/templateDetails.xml';

        if (!is_file($manifeste)) {
            return [];
        }

        $xml = @simplexml_load_file($manifeste);

        if (!$xml || !isset($xml->positions)) {
            return [];
        }

        $positions = [];

        foreach ($xml->positions->position as $position) {
            $valeur = trim((string) $position);

            if ($valeur !== '') {
                $positions[] = $valeur;
            }
        }

        return $positions;
    }
}
