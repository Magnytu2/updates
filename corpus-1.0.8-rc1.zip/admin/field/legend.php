<?php
/**
 * @package     Joomla.Libraries
 * @subpackage  Form
 *
 * @copyright   Copyright (C) 2005 - 2009 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormField;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

/**
 * Form Field class for the Joomla Framework.
 *
 * @since  2.5
 */
class JFormFieldLegend extends FormField
{
	/**
	 * The field type.
	 *
	 * @var		string
	 */
	protected $type = 'Legend';

	/**
	 * Les icones du rail, dessinees dans le template.
	 *
	 * Elles remplacent FontAwesome, qui coutait une fonte entiere — plus de
	 * 70 ko — pour une quinzaine de pictogrammes, et dont le jeu ne proposait
	 * rien de juste pour nos sections : une carte bancaire faisait l'en-tete,
	 * et le meme trait de menu servait pour l'en-tete et pour les deux
	 * groupes de sections.
	 *
	 * Ce sont celles de la maquette validee, au meme trait de 2, sur une
	 * grille de 24. Elles heritent de la couleur du texte : le rail les
	 * teinte donc tout seul, en clair comme en sombre.
	 *
	 * @var array
	 */
	protected static $icones = [
		// Reglages generaux
		'general'      => '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
		// Zones du gabarit
		'entete'       => '<path d="M4 5h16v14H4z"/><path d="M4 10h16"/>',
		'navigation'   => '<path d="M4 7h16M4 12h16M4 17h16"/>',
		'sections-hautes' => '<path d="M4 5h16v5H4z"/><path d="M4 14h16M4 18h10"/>',
		'contenu'      => '<path d="M4 4h16v16H4z"/><path d="M9 4v16M15 4v16"/>',
		'sections-basses' => '<path d="M4 14h16v5H4z"/><path d="M4 6h16M4 10h10"/>',
		'pied'         => '<path d="M4 5h16v14H4z"/><path d="M4 14h16"/>',
		// Apparence
		'couleurs'     => '<circle cx="12" cy="12" r="8"/><path d="M12 4a8 8 0 0 0 0 16 2 2 0 0 0 0-4 1.5 1.5 0 0 1 1.5-1.5H17a3 3 0 0 0 3-3A8 8 0 0 0 12 4z"/><circle cx="8.5" cy="10" r="1"/><circle cx="12" cy="8" r="1"/><circle cx="15.5" cy="10" r="1"/>',
		'typographie'  => '<path d="M5 6V4h14v2M12 4v16M9 20h6"/>',
		'police-web'   => '<circle cx="12" cy="12" r="8"/><path d="M4 12h16M12 4c2.5 2.5 2.5 13 0 16-2.5-3-2.5-13.5 0-16z"/>',
		'recherche'    => '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4-4"/>',
		'modules'      => '<path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z"/>',
		// Divers
		'prereglages'  => '<path d="M6 4h9l3 3v13H6z"/><path d="M9 12h6M9 16h6"/>',
		'informations' => '<circle cx="12" cy="12" r="8"/><path d="M12 11v5M12 8h.01"/>',
		'code'         => '<path d="M9 7l-5 5 5 5M15 7l5 5-5 5"/>',
		// Le consentement : un cadenas ferme. Ajoutee le 6 aout 2026 avec le
		// groupe « Consentement aux cookies ».
		//
		// UNE ENTREE SANS ICONE EST UNE ENTREE INVISIBLE. Le groupe avait ete
		// declare avec `icon="lock"`, qui n'existait pas ici : `icone()` rend
		// alors une chaine vide, sans erreur, et le rail n'affichait rien —
		// le panneau existait dans le DOM, mais aucun bouton n'y menait.
		// C'est le PIEGE 2 du 3 aout dans une autre piece du batiment : ce
		// qu'on ajoute a un endroit doit etre declare a l'autre.
		'consentement' => '<path d="M5 11h14v9H5z"/><path d="M8 11V7.5a4 4 0 0 1 8 0V11"/>',
		// L'etiquette : le meme dessin que le pictogramme `i-etiquette` du front,
		// mais au trait — les icones du rail sont en `fill: none`, celles du site
		// sont pleines. Meme objet, deux techniques.
		'etiquette'    => '<path d="M3.5 12.5 11.5 4.5h8v8l-8 8z"/><circle cx="16" cy="8" r="1.4"/>',
		// Le CSS : l'ecusson des feuilles de style, au trait.
		'css'          => '<path d="M5 3h14l-1.4 16.2L12 21l-5.6-1.8z"/><path d="M8.5 8h7M15.2 8l-.4 7.2-2.8 1-2.8-1-.15-2.4"/>',
	];

	/**
	 * Renvoie le SVG d'une icone, ou une chaine vide si la cle est inconnue.
	 * Une cle inconnue ne doit pas casser la page : elle laisse seulement le
	 * libelle sans pictogramme.
	 */
	protected function icone ($cle)
	{
		if (!isset(self::$icones[$cle])) {
			return '';
		}

		return '<svg class="legend-icone" viewBox="0 0 24 24" width="16" height="16"'
			. ' fill="none" stroke="currentColor" stroke-width="2"'
			. ' stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'
			. self::$icones[$cle] . '</svg>';
	}
	protected function getInput()
	{
		$html = '';
		if ($this->element['enabler']) {
			$html .= '<fieldset class="btn-group btn-group-yesno ' . ($this->element['enabler'] == 'top' ? 'top-group-enabler' : 'group-enabler') . ' radio" id="' . $this->id . '">';
			$html .= '<input type="radio" ' . ($this->value == 1 ? 'checked="checked" ' : '') . 'value="1" name="' . $this->name . '" id="' . $this->id . '0">';
			$html .= '<label for="' . $this->id . '0" class="btn">' . Text::_('JON') . '</label>';
			$html .= '<input type="radio" ' . ($this->value == 0 ? 'checked="checked" ' : '') . 'value="0" name="' . $this->name . '" id="' . $this->id . '1">';
			$html .= '<label for="' . $this->id . '1" class="btn">' . Text::_('JOFF') . '</label>';
			$html .= '</fieldset>';
		}
		return $html;
	}

	/**
	 * Method to get the field label markup for a spacer.
	 * Use the label text or name from the XML element as the spacer or
	 * Use a hr="true" to automatically generate plain hr markup
	 *
	 * @return  string  The field label markup.
	 *
	 * @since   11.1
	 */
	protected function getLabel()
	{
		
		// Get the label text from the XML element, defaulting to the element name.
		$text = $this->element['label'] ? (string) $this->element['label'] : (string) $this->element['name'];
		$text = $this->translateLabel ? Text::_($text) : $text;
		$desc = $this->element['description'] ? (string) $this->element['description'] : '';
		$desc = $this->translateLabel ? Text::_($desc) : $desc;
		$class = 'legend';
		$class .= !empty($this->class) ? ' ' . $this->class : '';
		$class .= $this->element['subgroup'] ? ' sub-legend' : '';
		$class = 'class="' . $class . '"';
		$icon = $this->element['icon'] ? $this->icone((string) $this->element['icon']) : '';
		// 
		$expend = $this->element['expend'] ? ' data-expend="' . $this->element['expend'] . '"' : ''; 

		$tooltip = $desc ? ' class="hasTooltip" title="' . htmlentities($desc) . '"' : '';

		// Le libelle est enveloppe dans son propre element. Sans cela, c'est un
		// simple noeud de texte pose a cote du pictogramme, et CSS ne sait pas
		// designer un noeud de texte : impossible de le transformer en
		// infobulle dans le rail, ni de le styler independamment du
		// pictogramme dans les titres de sous-groupe.
		//
		// Le texte reste dans le document meme quand il est masque a l'oeil :
		// les lecteurs d'ecran le lisent, et le rail reste donc utilisable
		// sans voir les infobulles.
		$html = "<h3 $class$expend><span$tooltip>$icon<span class=\"legend-texte\">$text</span></span></h3>";

		return $html;
	}

	/**
	 * Renvoie « ?<date de modification> » pour un chemin relatif a la racine du
	 * site, ou une chaine vide si le fichier est introuvable.
	 */
	protected function version ($cheminRelatif)
	{
		$fichier = JPATH_ROOT . '/' . ltrim($cheminRelatif, '/');

		return is_file($fichier) ? '?' . filemtime($fichier) : '';
	}

	public function setup(SimpleXMLElement $element, $value, $group = null)
	{
		// get template name
		$path = str_replace (JPATH_ROOT, '', dirname(__DIR__));
		$path = str_replace ('\\', '/', substr($path, 1));

		$doc = Factory::getDocument();

		// jQuery, EXPLICITEMENT. legend.js en depend encore, et jusqu'au
		// 31 juillet 2026 il ne marchait que par accident : les 37 champs
		// type="color" chargeaient minicolors, qui tire jQuery. En remplacant
		// ces champs par la teinte unique, jQuery a disparu de la page et
		// l'administration est tombee sur « jQuery is not defined ».
		// Une dependance qui n'est pas declaree n'est pas une dependance :
		// c'est une coincidence. A supprimer quand legend.js sera porte en
		// JavaScript natif, comme layout.js l'a ete.
		$doc->getWebAssetManager()->useScript('jquery');

		// La date de modification sert de numero de version. Sans elle, le
		// navigateur garde indefiniment sa copie : legend.js a beau etre mis a
		// jour sur le serveur, l'administration continue d'executer l'ancien.
		// Meme piege que pour style.css et pour la feuille du site.
		$doc->addStyleSheet (Uri::root() . $path . '/assets/css/legend.css' . $this->version($path . '/assets/css/legend.css'));
		$doc->addScript (Uri::root() . $path . '/assets/js/legend.js' . $this->version($path . '/assets/js/legend.js'));
		//$doc->addScript ('http://livejs.com/live.js#css');
		return parent::setup($element, $value, $group);
	}

}
