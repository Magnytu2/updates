<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LES CLASSES D'UNE BANDE DE MODULES
 *
 * Reecrit le 31 juillet 2026. Le champ herite du template d'origine sortait un
 * <select multiple> : la liste s'affichait, mais RIEN ne disait qu'il fallait
 * cliquer dedans, ni que plusieurs choix etaient possibles. Cyrille a cherche
 * comment poser un fond alterne sur Top B en regardant le champ en face de
 * lui. Un reglage qu'on ne trouve pas est un reglage qui n'existe pas.
 *
 * Des cases a cocher, donc : on voit ce qui est coche, on voit ce qui ne
 * l'est pas, et un clic suffit.
 *
 * Les valeurs viennent toujours de etc/supported-classes.ini, source unique.
 * Une classe n'y entre qu'apres que sa regle est ecrite dans le SCSS.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Form\FormField;
use Joomla\CMS\Language\Text;

class JFormFieldClasses extends FormField
{
    protected $type = 'Classes';

    /**
     * TRADUIRE UN INTITULE VENU DU FICHIER — 7 aout 2026.
     *
     * Les intitules de `etc/supported-classes.ini` etaient ecrits en clair, et
     * sortaient donc EN FRANCAIS sur une administration anglaise, allemande ou
     * espagnole. Le defaut ne se voyait pas : le champ affichait bien quelque
     * chose.
     *
     * Un intitule qui a la forme d'une clef de langue est traduit ; tout autre
     * texte est rendu tel quel. Un fichier ecrit a la main avec des libelles en
     * clair continue donc de fonctionner, et une classe ajoutee par un
     * integrateur n'oblige personne a toucher aux quatre langues.
     */
    private static function traduire(string $texte): string
    {
        if (!preg_match('/^TPL_[A-Z0-9_]+$/', $texte)) {
            return $texte;
        }

        return Text::_($texte);
    }

    protected function getInput()
    {
        $fichier = dirname(dirname(__DIR__)) . '/etc/supported-classes.ini';

        if (!is_file($fichier)) {
            return '';
        }

        $groupes = parse_ini_file($fichier, true);

        if (!$groupes) {
            return '';
        }

        // Filtre facultatif : groups="Fond+Espacement"
        if ($this->element['groups']) {
            $demandes = array_map('trim', explode('+', (string) $this->element['groups']));
            $groupes  = array_intersect_key($groupes, array_flip($demandes));
        }

        // La valeur enregistree est un tableau, mais peut arriver en chaine.
        $choisies = $this->value;

        // Un groupe exclusif poste `…[fond]` : la valeur revient donc en OBJET
        // depuis le JSON des parametres, la ou les cases a cocher donnent un
        // tableau. Les deux doivent etre lisibles.
        if (is_object($choisies)) {
            $choisies = get_object_vars($choisies);
        }

        if (is_string($choisies)) {
            $choisies = $choisies === '' ? [] : preg_split('/[\s,]+/', $choisies);
        }

        $choisies = (array) $choisies;

        // Plusieurs cases pour un seul champ : le nom doit finir par []. Joomla
        // l'ajoute deja quand multiple="1", mais on ne le presume pas — un
        // nom sans crochets ne garderait que la derniere case cochee, en
        // silence.
        $nom = str_ends_with($this->name, '[]') ? $this->name : $this->name . '[]';

        // La racine du nom, sans les crochets : les groupes exclusifs ont besoin
        // d'une CLE, pas d'un rang.
        $racine = substr($nom, 0, -2);

        $html = '<div class="corpus-classes" id="' . $this->id . '">';

        foreach ($groupes as $groupe => $classes) {
            // UN GROUPE DONT LE NOM FINIT PAR « * » EST EXCLUSIF.
            //
            // Ajoute le 3 aout 2026 avec le second fond de bande. Une bande n'a
            // qu'UN fond : cochees ensemble, `section--alt` et `section--teinte`
            // s'appliqueraient toutes les deux et c'est l'ordre de la feuille qui
            // trancherait, en silence. Le champ doit dire la verite sur ce que le
            // rendu sait faire.
            $exclusif = str_ends_with($groupe, '*');
            $titre    = $exclusif ? rtrim($groupe, ' *') : $groupe;
            $cle      = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $titre));

            /*
             * CHAQUE GROUPE EXCLUSIF A SON PROPRE NOM, et c'est le defaut le plus
             * betement visible qu'on ait produit : le 3 aout 2026, les deux
             * groupes « Fond » et « Theme » partageaient `…[]`. Or un navigateur
             * groupe les boutons radio PAR NOM. Les six boutons n'en formaient
             * donc qu'un seul groupe : cocher « Toujours sombre » decochait le
             * fond, en silence.
             *
             * Une CLE plutot qu'un rang — `…[fond]`, `…[theme]` — separe les
             * groupes tout en arrivant dans le meme tableau. Les cases a cocher
             * gardent `[]`, qui est fait pour ca. PHP accepte les deux formes
             * dans une meme requete, et `implode` joint les valeurs sans se
             * soucier des cles.
             */
            $nomGroupe = $exclusif ? $racine . '[' . $cle . ']' : $nom;

            /*
             * LE TITRE DU GROUPE EST TRADUISIBLE — 7 aout 2026.
             *
             * Le nom de section sert de CLE DE STOCKAGE (`…[fond]`) : le
             * traduire changerait la clef enregistree et perdrait les reglages
             * des sites deja en place. Le fichier porte donc, en plus, une
             * entree reservee `.legende` qui ne designe aucune classe.
             *
             * Les entrees commencant par un point sont des metadonnees : elles
             * ne sortent jamais de bouton.
             */
            $legende = $classes['.legende'] ?? $titre;

            foreach (array_keys($classes) as $reservee) {
                if (str_starts_with($reservee, '.')) {
                    unset($classes[$reservee]);
                }
            }

            // UN FIELDSET PAR GROUPE, pas un pour tous. Un `<fieldset>` ne porte
            // qu'une `<legend>`, et elle doit etre son premier enfant : empiler
            // les legendes produisait un balisage invalide, et une aide technique
            // n'annoncait pas le groupe. C'est visible sur la capture — le titre
            // « Theme » flottait a l'interieur du cadre du fond.
            $html .= '<fieldset class="corpus-classes__groupe">'
                . '<legend>' . htmlspecialchars(self::traduire($legende), ENT_QUOTES, 'UTF-8') . '</legend>';

            // Un groupe exclusif a besoin d'un moyen de REVENIR EN ARRIERE : un
            // bouton radio ne se decoche pas. Sans ce choix, poser un fond par
            // erreur serait definitif.
            if ($exclusif) {
                $idAucun = $this->id . '-aucun-' . $cle;
                $pris    = (bool) array_intersect(array_keys($classes), $choisies);

                $html .= '<div class="corpus-classes__ligne">'
                    . '<input type="radio" id="' . $idAucun . '"'
                    . ' name="' . $nomGroupe . '" value=""'
                    . ($pris ? '' : ' checked') . '>'
                    . '<label for="' . $idAucun . '">'
                    . Text::_('TPL_CORPUS_CLASSES_AUCUN')
                    . '</label>'
                    . '</div>';
            }

            foreach ($classes as $classe => $libelle) {
                $id = $this->id . '-' . preg_replace('/[^a-z0-9]+/i', '-', $classe);

                $html .= '<div class="corpus-classes__ligne">'
                    . '<input type="' . ($exclusif ? 'radio' : 'checkbox') . '" id="' . $id . '"'
                    . ' name="' . $nomGroupe . '"'
                    . ' value="' . htmlspecialchars($classe, ENT_QUOTES, 'UTF-8') . '"'
                    . (in_array($classe, $choisies, true) ? ' checked' : '') . '>'
                    // LE NOM DE CLASSE PASSE EN INFOBULLE — 5 aout 2026.
                    //
                    // Il s'affichait en `<code>` a cote de l'intitule. C'est lui
                    // qui interdisait de mettre les choix EN LIGNE : trois
                    // intitules suivis de leur classe font une centaine de
                    // caracteres, et le champ repartait sur trois lignes par
                    // groupe.
                    //
                    // Il reste accessible au survol et il est ecrit dans le
                    // manuel. Ce n'est pas une information dont l'administrateur
                    // a besoin pour cocher : il en a besoin quand il ouvre
                    // l'inspecteur, et la il l'a sous les yeux.
                    . '<label for="' . $id . '" title="' . htmlspecialchars($classe, ENT_QUOTES, 'UTF-8') . '">'
                    . htmlspecialchars(self::traduire($libelle), ENT_QUOTES, 'UTF-8')
                    . '</label>'
                    . '</div>';
            }

            $html .= '</fieldset>';
        }

        return $html . '</div>';
    }
}
