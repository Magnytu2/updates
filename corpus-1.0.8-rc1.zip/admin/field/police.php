<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE CHAMP DE POLICE — une liste, et un aperçu sous elle.
 *
 * Écrit le 2 août 2026, à la demande de Cyrille : « pourrait-on visualiser les
 * polices avant de les choisir ? »
 *
 * LA VALEUR DE CHAQUE OPTION EST UNE PILE CSS COMPLÈTE. L'aperçu n'a donc rien
 * à traduire : il recopie la valeur choisie dans `font-family`, et le
 * navigateur fait le reste. Ajouter une pile ne demande pas une ligne de PHP,
 * seulement une ligne dans le manifeste.
 *
 * LA PHRASE D'EXEMPLE N'EST PAS DU LOREM, ET C'EST VOULU. Un texte latin ne
 * montre ni accent ni chiffre — or c'est exactement là que les polices se
 * distinguent, et là qu'elles ratent. On affiche donc un pangramme français,
 * des chiffres, un montant, et surtout le groupe `0 O 1 l I` : quatre signes
 * qui se confondent dans les mauvaises polices, et que les bonnes séparent.
 *
 * DEUX AVERTISSEMENTS SOUS L'APERÇU, sans quoi il ment :
 *
 * 1. Une pile système montre ce que rend CET ordinateur-ci. L'administrateur
 *    est sous Windows, il voit Segoe UI ; son visiteur sous macOS verra San
 *    Francisco. L'aperçu est indicatif, pas contractuel.
 * 2. Une police externe ne s'affiche que si elle est chargée dans cette page
 *    d'administration — donc au prix d'une requête vers un tiers. On ne la
 *    fait JAMAIS d'office : il faut cliquer. L'administrateur choisit la
 *    requête, il ne la subit pas en ouvrant l'onglet.
 *
 * JavaScript natif, sans jQuery, et une seule fois quel que soit le nombre de
 * champs : la délégation sur `document` survit au déplacement des champs par
 * legend.js — ce qu'il fait.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\ListField;
use Joomla\CMS\Language\Text;

class JFormFieldPolice extends ListField
{
    protected $type = 'Police';

    public function setup(SimpleXMLElement $element, $value, $group = null)
    {
        Factory::getDocument()->addScriptDeclaration(<<<'JS'
(function () {
	'use strict';

	if (window.corpusPoliceInitialise) { return; }
	window.corpusPoliceInitialise = true;

	var rafraichir = function (select) {
		var bloc = select.closest('[data-corpus-police]');
		if (!bloc) { return; }

		var apercu = bloc.querySelector('[data-corpus-police-apercu]');
		if (!apercu) { return; }

		// La valeur EST la pile. Vide — cas des titres qui suivent le texte —
		// on laisse l'aperçu hériter, ce qui montre justement ce qui se
		// passera.
		apercu.style.fontFamily = select.value || '';
	};

	document.addEventListener('change', function (e) {
		if (e.target.matches('[data-corpus-police] select')) { rafraichir(e.target); }
	});

	document.addEventListener('DOMContentLoaded', function () {
		Array.prototype.forEach.call(
			document.querySelectorAll('[data-corpus-police] select'),
			rafraichir
		);
	});
}());
JS);

        return parent::setup($element, $value, $group);
    }

    protected function getInput()
    {
        $liste = parent::getInput();

        $exemple = Text::_('TPL_CORPUS_TYPO_APERCU_EXEMPLE');
        $note    = Text::_('TPL_CORPUS_TYPO_APERCU_NOTE');

        return '<div class="corpus-police" data-corpus-police>'
            . $liste
            . '<p class="corpus-police__apercu" data-corpus-police-apercu'
            . ' style="font-family: ' . htmlspecialchars((string) $this->value, ENT_QUOTES, 'UTF-8') . ';">'
            . htmlspecialchars($exemple, ENT_QUOTES, 'UTF-8')
            . '</p>'
            // L'avertissement est du texte, pas une infobulle : il doit être lu
            // sans avoir à le chercher.
            . '<p class="corpus-police__note">' . htmlspecialchars($note, ENT_QUOTES, 'UTF-8') . '</p>'
            . '</div>';
    }
}
