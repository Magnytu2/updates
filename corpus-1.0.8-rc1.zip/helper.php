<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Uri\Uri;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;
use Joomla\Filesystem\File;
use Joomla\Filesystem\Folder;
use Joomla\Registry\Registry;

if (!class_exists('CorpusHelper')) {
    /**
     * Assistant du template : lecture des parametres, construction des classes de
     * grille, compilation de la feuille de style personnalisee et rendu des
     * rangees de modules.
     */
    class CorpusHelper
    {
        /** @var Registry|null Parametres du style courant */
        private $params = null;

        /** @var string|null Nom du template */
        private $template = null;

        /** @var int Identifiant du style de template */
        private $style_id = 0;

        /** @var array Donnees calculees pour la mise en page */
        private $data = [];

        /** @var bool Le style courant est-il le style par defaut ? */
        private $isHome = false;
        private $parentTemplate = null;

        /** @var Registry|null Parametres du style par defaut */
        private $defaultParams = null;

        public function __construct()
        {
        }

        /**
         * Retourne l'objet base de donnees.
         */
        private function getDb(): DatabaseInterface
        {
            return Factory::getContainer()->get(DatabaseInterface::class);
        }

        /**
         * Charge un style de template par son identifiant.
         */
        public function loadStyle($id)
        {
            $id    = (int) $id;
            $db    = $this->getDb();
            $query = $db->getQuery(true)
                ->select('*')
                ->from($db->quoteName('#__template_styles'))
                ->where($db->quoteName('id') . ' = :id')
                ->bind(':id', $id, ParameterType::INTEGER);

            $db->setQuery($query);
            $tpl = $db->loadObject();

            if (!$tpl) {
                return;
            }

            $this->params = new Registry();
            $this->params->loadString($tpl->params);
            $this->style_id = $tpl->id;
            $this->template = $tpl->template;
            $this->isHome   = $tpl->home;

            $this->data['tplhelper'] = !empty($this->getParam('tplhelper'))
                ? json_decode($this->getParam('tplhelper'), true)
                : [];

            $this->params->set('baseUrl', Uri::root(true) . '/');
        }

        /**
         * Charge les parametres du style par defaut, utilises comme repli.
         */
        public function loadDefaultStyleParams()
        {
            if ($this->isHome) {
                $this->defaultParams = $this->params;

                return;
            }

            $db    = $this->getDb();
            $query = $db->getQuery(true)
                ->select('*')
                ->from($db->quoteName('#__template_styles'))
                ->where($db->quoteName('home') . ' = ' . $db->quote('1'))
                ->where($db->quoteName('client_id') . ' = 0');

            $db->setQuery($query);
            $tpl = $db->loadObject();

            if ($tpl) {
                $this->defaultParams = new Registry();
                $this->defaultParams->loadString($tpl->params);
            }
        }

        /**
         * Initialise l'assistant a partir du document du template.
         */
        public function init($template = null)
        {
            $app = Factory::getApplication();
            $doc = $app->getDocument();

            if ($template !== null) {
                $this->params   = $template->params;
                $tpl            = $app->getTemplate(true);
                $this->style_id = $tpl->id;
                $this->template = $tpl->template;
                $this->isHome   = $tpl->home;
            }

            $input = $app->getInput();

            $this->data['option'] = $input->getCmd('option', '');
            $this->data['view']   = $input->getCmd('view', '');

            $menu                     = $app->getMenu()->getActive() ?: $app->getMenu()->getDefault();
            $this->data['page-class'] = $menu ? $menu->getParams()->get('pageclass_sfx') : '';

            $this->data['tplhelper'] = !empty($this->getParam('tplhelper'))
                ? json_decode($this->getParam('tplhelper'), true)
                : [];

            $this->params->set('baseUrl', Uri::base(true) . '/');

            /*
             * LA BARRE D'INFORMATION — 3 aout 2026.
             *
             * Deux colonnes, exactement comme l'en-tete et la navigation :
             * `topbar-left` pour les reseaux sociaux, `topbar-right` pour le
             * telephone, le courriel ou les horaires. C'est la repartition que
             * font tous les templates du marche, et deux positions valent mieux
             * qu'une seule etalee : l'administrateur choisit ce qui va de chaque
             * cote au lieu de dependre de l'ordre de publication.
             *
             * La position `topbar` de Cassiopeia reste declaree au manifeste : un
             * site qui migre ne perd pas ses modules, il les repointe.
             *
             * Un cote sans module ne compte pas — la barre ne s'affiche que si
             * l'un des deux a quelque chose a montrer.
             */
            $this->data['topbar-enabled']   = $this->getParam('layoutEnable_topbar', 1);
            $this->data['topbar-left-pos']  = '';
            $this->data['topbar-right-pos'] = '';

            if ($this->data['topbar-enabled']) {
                $gauche = $this->getParam('layoutPos_topbar_left', 'topbar-left');
                $droite = $this->getParam('layoutPos_topbar_right', 'topbar-right');

                if ($doc->countModules($gauche)) {
                    $this->data['topbar-left-pos'] = $gauche;
                }

                if ($doc->countModules($droite)) {
                    $this->data['topbar-right-pos'] = $droite;
                }
            }

            // En-tete
            $this->data['header-enabled']     = $this->getParam('layoutEnable_header', 1);
            $this->data['header-left-class']  = '';
            $this->data['header-right-class'] = '';
            $this->data['header-right-pos']   = '';

            if ($this->data['header-enabled']) {
                $this->data['header-left-class'] = 'col-lg-' . $this->getParam('layoutWidth_header_left', 3);

                if ($this->getParam('layoutEnable_header_right', 1)) {
                    // Le repli n'est plus `topbar` : cette position appartient a
                    // la barre d'information. Le manifeste dit `banner`, le code
                    // doit dire la meme chose — deux defauts qui divergent, c'est
                    // une panne qui n'arrive que chez le client.
                    $this->data['header-right-pos'] = $this->getParam('layoutPos_header_right', 'banner');

                    if ($doc->countModules($this->data['header-right-pos'])) {
                        $width = $this->getParam('layoutWidth_header_right')
                            ?: 12 - $this->getParam('layoutWidth_header_left', 3);
                        $this->data['header-right-class'] = 'col-lg-' . $width;
                    }
                }
            }

            // Navigation principale
            $this->data['nav-enabled']     = $this->getParam('layoutEnable_nav', 1);
            $this->data['nav-left-class']  = '';
            $this->data['nav-right-class'] = '';
            $this->data['nav-left-pos']    = '';
            $this->data['nav-right-pos']   = '';

            if ($this->data['nav-enabled']) {
                $this->data['nav-left-pos']   = $this->getParam('layoutPos_nav_left', 'menu');
                $this->data['nav-left-class'] = 'col-lg-' . $this->getParam('layoutWidth_nav_left', 9);

                if ($this->getParam('layoutEnable_nav_right', 1)) {
                    $this->data['nav-right-pos'] = $this->getParam('layoutPos_nav_right', 'search');

                    if ($doc->countModules($this->data['nav-right-pos'])) {
                        $width = $this->getParam('layoutWidth_nav_right')
                            ?: 12 - $this->getParam('layoutWidth_nav_left', 9);
                        $this->data['nav-right-class'] = 'col-lg-' . $width;
                    }
                }
            }

            /*
             * LE CORPS DE PAGE SE RALLUME POUR UNE PAGE ORPHELINE — 12 aout 2026.
             *
             * LE DEFAUT. Une page sans element de menu a elle retombe sur le
             * style PAR DEFAUT du template. Si ce style est une landing — corps
             * de page desactive, la page faite de bandes de modules — le
             * composant n'a nulle part ou sortir et disparait en silence.
             *
             * Cyrille l'a rencontre deux fois : « mot de passe perdu » qui ne
             * menait nulle part le 10 aout, puis la recherche le 12, ou taper
             * « lapin » rendait une page vide avec le mot dans le fil d'Ariane.
             * Deux composants, une seule cause. Le gabarit portait deja une
             * exception ecrite a la main pour com_config : la preuve que le
             * probleme etait connu, et rustine pour un cas sur dix.
             *
             * LA REGLE. Le corps se rallume des que la page courante ne
             * correspond PAS a l'element de menu actif. On compare ce que la
             * requete demande a ce que l'element de menu promet — composant,
             * vue, identifiant, mise en page. Une landing garde donc son
             * gabarit pour SA propre adresse, et cesse d'avaler les autres.
             *
             * L'identifiant est compare lui aussi : sans cela, un article
             * atteint par un lien direct — meme composant, meme vue que
             * l'accueil — serait reste invisible.
             */
            $corpusMenu    = $app->getMenu() ? $app->getMenu()->getActive() : null;
            $corpusOrpheline = true;

            if ($corpusMenu) {
                $corpusOrpheline = false;

                foreach (['option', 'view', 'id', 'layout'] as $corpusCle) {
                    $corpusAttendu = $corpusMenu->query[$corpusCle] ?? null;

                    if ($corpusAttendu === null) {
                        continue;
                    }

                    if ((string) $input->get($corpusCle, '') !== (string) $corpusAttendu) {
                        $corpusOrpheline = true;
                        break;
                    }
                }
            }

            // Corps de page
            $this->data['content-enabled'] = $this->getParam('layoutEnable_content', 1)
                || $corpusOrpheline;
            $this->data['main-class']      = null;
            $this->data['col1-class']      = null;
            $this->data['col2-class']      = null;

            $this->data['main-top-pos']    = '';
            $this->data['main-bottom-pos'] = '';

            if ($this->data['content-enabled']) {
                /*
                 * LES DEUX RANGEES DE LA COLONNE DE CONTENU — `main-top` et
                 * `main-bottom`, 3 aout 2026.
                 *
                 * Ce sont les positions de Cassiopeia, au meme endroit et avec le
                 * meme sens : DANS la colonne principale, au-dessus et au-dessous
                 * du composant. Un site qui migre depuis Cassiopeia retrouve donc
                 * ses modules a leur place, sans rien republier.
                 *
                 * Elles etaient declarees au manifeste depuis le portage et
                 * n'etaient rendues nulle part — pire, `layoutPos_top_3` ET
                 * `layoutPos_top_4` pointaient toutes deux dessus, ce qui affichait
                 * un module deux fois. Corrige, et migre par script.php.
                 *
                 * Elles dependent de Contenu : desactiver le corps de page les
                 * emporte, ce qui est la seule lecture coherente — une rangee du
                 * contenu n'existe pas sans contenu.
                 */
                if ($this->getParam('layoutEnable_main_top', 1)) {
                    $this->data['main-top-pos'] = $this->getParam('layoutPos_main_top', 'main-top');
                }

                if ($this->getParam('layoutEnable_main_bottom', 1)) {
                    $this->data['main-bottom-pos'] = $this->getParam('layoutPos_main_bottom', 'main-bottom');
                }

                $col1 = 0;
                $col2 = 0;

                if ($this->getParam('layoutEnable_col_1', 1)) {
                    $this->data['col1-pos'] = $this->getParam('layoutPos_col_1', 'sidebar-left');

                    if ($doc->countModules($this->data['col1-pos'])) {
                        $col1                     = $this->getParam('layoutWidth_col_1', 3);
                        $this->data['col1-class'] = 'col-lg-' . $col1;
                    }
                }

                if ($this->getParam('layoutEnable_col_2', 1)) {
                    $this->data['col2-pos'] = $this->getParam('layoutPos_col_2', 'sidebar-right');

                    if ($doc->countModules($this->data['col2-pos'])) {
                        $col2                     = $this->getParam('layoutWidth_col_2', 3);
                        $this->data['col2-class'] = 'col-lg-' . $col2;
                    }
                }

                $main = 12 - $col1 - $col2;

                if ($main < 3) {
                    $main = 12;
                }

                $this->data['main-class'] = 'col-lg-' . $main;

                if ($this->getParam('layoutPosition_content', 'left') === 'right') {
                    $this->data['main-class'] .= ' order-lg-last';
                }
            }

            // Recompilation differee, declenchee apres un enregistrement des parametres.
            $this->afterSave();
        }

        public function get($name, $default = null)
        {
            return $this->data[$name] ?? $this->getParam($name, $default);
        }

        public function getParam($name, $default = null)
        {
            $val = $this->params->get($name, $default);

            if ($val === 'use-default' && !$this->isHome) {
                if (!$this->defaultParams) {
                    $this->loadDefaultStyleParams();
                }

                $val = $this->defaultParams ? $this->defaultParams->get($name, $default) : $default;
            }

            if ($val === 'use-default') {
                $val = $default;
            }

            return $val;
        }

        public function setParam($name, $value)
        {
            $this->params->set($name, $value);
        }

        public function _($name, $glue = ' ', $separator = '')
        {
            $val = $this->get($name);

            if (is_array($val)) {
                $val = implode($glue, $val);
            }

            echo $val ? $separator . $val : '';
        }

        /**
         * Nom affiche dans l'en-tete.
         *
         * Le champ du template n'est qu'une surcharge : laisse vide, c'est le
         * nom du site defini dans la configuration globale de Joomla qui sert.
         * Sans ce repli, l'en-tete affichait un <strong> vide et le site
         * n'avait tout simplement pas de nom visible.
         */
        public function siteName()
        {
            $nom = trim((string) $this->getParam('logoText'));

            return $nom !== '' ? $nom : (string) Factory::getApplication()->get('sitename');
        }

        /**
         * Accroche affichee sous le nom. Repli sur la metadonnee de description
         * du site, elle aussi definie dans la configuration globale.
         */
        public function siteSlogan()
        {
            $slogan = trim((string) $this->getParam('logoSlogan'));

            return $slogan !== '' ? $slogan : (string) Factory::getApplication()->get('MetaDesc');
        }

        public function is($name)
        {
            return (bool) $this->get($name);
        }

        public function has($name)
        {
            return $this->is($name);
        }

        public function hasContainer($section)
        {
            return $this->getParam('layoutContainer_' . $section) == 1
                || ($this->getParam('layoutContainer_' . $section, '') === '' && $this->getParam('layoutContainer', 1) == 1);
        }

        /*
         * Le conteneur de Corpus s'appelle `.page` : 1140 px, centre, avec les
         * gouttieres. `container` et `container-fluid` sont ceux de Bootstrap,
         * et le corps de page dans index.php n'a jamais utilise que `.page`.
         * Une rangee de modules doit se caler dessus, sinon deux bandes
         * successives n'ont pas la meme largeur utile.
         *
         * « Pleine largeur » ne prend aucune classe : c'est l'absence de
         * plafond, pas une classe qui en poserait un autre.
         */
        public function _container_open($section)
        {
            echo $this->hasContainer($section) ? '<div class="page">' : '<div>';
        }

        public function _container_close($section)
        {
            echo '</div>';
        }

        public function _bg($section)
        {
            $background = self::cheminMedia($this->getParam('layoutBackground_' . $section));

            if (!$background) {
                return;
            }

            echo ' style="background-image:url(' . htmlspecialchars($background, ENT_QUOTES, 'UTF-8') . ');"';
        }

        /**
         * Le chemin nu d'un champ media.
         *
         * Joomla enregistre « images/logo.svg#joomlaImage://local-images/logo.svg?width=205&height=90 » :
         * le chemin, puis une fiche d'identite accrochee par un diese. Le fragment
         * n'est pas envoye au serveur, donc l'image finit par charger — mais il
         * traine dans chaque url() produite, et error.php le nettoyait pendant que
         * le helper le laissait passer. Deux endroits, deux comportements : c'est
         * ainsi qu'on decouvre un jour que l'un des deux avait tort.
         *
         * Vaut pour les treize champs media du template, pas seulement le logo.
         */
        private static function cheminMedia($valeur)
        {
            $valeur = trim((string) $valeur);
            $diese  = strpos($valeur, '#joomlaImage');

            return $diese === false ? $valeur : substr($valeur, 0, $diese);
        }

        /*
         * La rangee est notre grille de douze colonnes, pas le `row` de
         * Bootstrap. Mesure du 31 juillet : `.row` pose `display: flex` et des
         * marges negatives, ce qui annule `grid-column: span N` — les colonnes
         * se rangeaient a l'ancienne et la gouttiere n'etait plus la notre.
         */
        public function _row_class($section)
        {
            echo 'grille';
        }

        /**
         * Lit un reglage qui appartient au SITE, pas au style.
         *
         * POURQUOI CETTE METHODE EXISTE — 6 aout 2026, question de Cyrille.
         *
         * Les parametres de Joomla vivent dans le style, et c'est juste pour
         * la plupart : la teinte, la variante de forme, la largeur de page
         * peuvent differer d'une page a l'autre, c'est meme leur raison
         * d'etre. Mais certains reglages n'ont qu'une reponse juste par
         * site. Les traceurs deposes ne changent pas selon que le visiteur
         * est sur l'accueil ou sur une page d'atterrissage.
         *
         * Les ranger dans le style obligeait a les ressaisir dans chacun —
         * trois styles sur le banc, et autant de fois trois qu'on en creera.
         * Une saisie repetee est une saisie qui divergera : le jour ou l'un
         * des styles oublie un traceur, le site est moins conforme sur
         * certaines pages seulement, et rien ne le signale.
         *
         * UN TEMPLATE ENFANT N'Y CHANGERAIT RIEN, ET AGGRAVERAIT LA CHOSE :
         * un enfant est un template distinct, avec ses propres styles.
         *
         * La reponse est le repli, pas la duplication : le style par defaut
         * porte la valeur, les autres la lisent s'ils n'en ont pas. Un style
         * peut donc encore surcharger — une page d'atterrissage avec un
         * traceur de plus — mais il n'y est pas oblige. C'est la « valeur de
         * repli » du 3 aout, transposee des jetons aux reglages.
         */
        public function getSite($name, $default = null)
        {
            $val = $this->params->get($name, null);

            if ($val !== null && $val !== '') {
                return $val;
            }

            if (!$this->defaultParams) {
                $this->loadDefaultStyleParams();
            }

            if (!$this->defaultParams) {
                return $default;
            }

            $val = $this->defaultParams->get($name, null);

            return ($val === null || $val === '') ? $default : $val;
        }

        public function getStyleId()
        {
            return $this->style_id;
        }

        /**
         * Le champ cache tplhelper indique quels groupes de parametres ont ete
         * modifies. Il est stocke sous forme de chaine JSON, pas de tableau :
         * l'ancien test is_array() renvoyait donc toujours faux, et plus rien
         * n'etait jamais recompile. On decode explicitement.
         */
        public function groupNeedUpdate($group)
        {
            $tplhelper = $this->get('tplhelper');

            if (is_string($tplhelper)) {
                $tplhelper = json_decode($tplhelper, true);
            } elseif (is_object($tplhelper)) {
                $tplhelper = (array) $tplhelper;
            }

            return is_array($tplhelper) && isset($tplhelper[$group]) && $tplhelper[$group] == 1;
        }

        /**
         * Enregistre une revision des parametres pour permettre un retour arriere.
         */
        public function saveRevision($prefix, $group)
        {
            $path       = JPATH_ROOT . $this->getMediaLocation() . '/revisions/' . $group . '/';
            $needUpdate = $this->groupNeedUpdate($group);

            if (!is_dir($path)) {
                if (!Folder::create($path)) {
                    return false;
                }

                $needUpdate = true;
            }

            if (!$needUpdate) {
                return false;
            }

            $lines = [];

            foreach ($this->params->toArray() as $name => $value) {
                if (is_array($value)) {
                    $value = implode(',', $value);
                }

                if (strpos($name, $prefix) === 0) {
                    $lines[] = $name . ': ' . preg_replace('/[\r\n]+/', '\\n', (string) $value);
                }
            }

            $filename = $this->getStyleId() . '-' . Factory::getDate()->format('Y.m.d-h.i.s') . '.nvp';

            file_put_contents($path . $filename, implode("\n", $lines));

            return true;
        }

        /**
         * Emplacement de la feuille personnalisee du style courant.
         *
         * En mode adresse, on ajoute la date de derniere modification du
         * fichier. Sans elle, le navigateur garde indefiniment sa copie en
         * cache : le fichier avait beau etre regenere sur le serveur, le
         * visiteur continuait de voir l'ancien logo et l'ancienne couleur.
         */
        public function getCustomCssPath($url = false)
        {
            $path = $this->getMediaLocation() . '/css/custom-styles/' . $this->getStyleId() . '.css';

            if (!$url) {
                return JPATH_ROOT . $path;
            }

            $adresse = Uri::root(true) . $path;
            $fichier = JPATH_ROOT . $path;

            if (is_file($fichier)) {
                $adresse .= '?' . filemtime($fichier);
            }

            return $adresse;
        }

        /**
         * Emplacement des fichiers du template dans le dossier media.
         *
         * C'est le dossier du template ACTIF, et c'est voulu : c'est la qu'on
         * ECRIT. La feuille personnalisee d'un style enfant appartient a
         * l'enfant, pas au parent. Pour LIRE un fichier livre, voir
         * getMediaFichier().
         */
        public function getMediaLocation()
        {
            return '/media/templates/site/' . $this->template;
        }

        /**
         * Le template parent, quand le template actif est un enfant.
         *
         * MESURE DU 6 AOUT 2026, sur le banc, en Joomla 6.1 : le manifeste
         * d'un enfant porte `<parent>corpus</parent>`. C'est la source de
         * verite, et la seule qui ne depende pas du schema de la base.
         *
         * La lecture n'a lieu QU'UNE FOIS, et seulement si un fichier a
         * manque chez l'actif — donc jamais sur un site qui n'utilise pas
         * l'heritage, c'est-a-dire presque tous.
         *
         * @return string|false
         */
        public function getParentTemplate()
        {
            if ($this->parentTemplate !== null) {
                return $this->parentTemplate;
            }

            $this->parentTemplate = false;
            $manifeste = JPATH_THEMES . '/' . $this->template . '/templateDetails.xml';

            if (is_file($manifeste)) {
                $xml = @simplexml_load_file($manifeste);

                if ($xml !== false && isset($xml->parent) && (string) $xml->parent !== '') {
                    $this->parentTemplate = (string) $xml->parent;
                }
            }

            return $this->parentTemplate;
        }

        /**
         * Adresse d'un fichier livre, avec repli sur le parent.
         *
         * POURQUOI CETTE METHODE EXISTE — 6 aout 2026, mesure sur le banc.
         *
         * `TemplateModel::child()` cree le dossier media d'un enfant VIDE :
         * rien n'est copie du parent. Verifie a l'ecran, en Joomla 6.1, sur
         * un enfant reel — `media/templates/site/tron_essai/css/template-j4.css`
         * repondait 404 quand celui du parent repondait 200. Un site sous un
         * style enfant n'avait donc NI FEUILLE NI SCRIPT.
         *
         * Joomla sait faire ce repli tout seul, mais seulement pour les URI
         * relatives declarees dans `joomla.asset.json`, et seulement dans
         * `css/` et `js/` — la convention de Cassiopeia. Elle ne couvre ni le
         * dossier `orejime/`, ni la feuille personnalisee, dont le nom depend
         * du style. Une seule mecanique pour tous les fichiers vaut mieux que
         * deux qui se ressemblent.
         *
         * @param   string  $relatif  chemin depuis le dossier media, ex. « css/template-j4.css »
         * @return  string  chemin depuis la racine du site, sans slash initial
         */
        public function getMediaFichier($relatif)
        {
            $relatif = ltrim($relatif, '/');
            $chemin  = 'media/templates/site/' . $this->template . '/' . $relatif;

            if (is_file(JPATH_ROOT . '/' . $chemin)) {
                return $chemin;
            }

            $parent = $this->getParentTemplate();

            if ($parent) {
                $cheminParent = 'media/templates/site/' . $parent . '/' . $relatif;

                if (is_file(JPATH_ROOT . '/' . $cheminParent)) {
                    return $cheminParent;
                }
            }

            // Ni chez l'enfant ni chez le parent : on rend le chemin de
            // l'actif. Le 404 qui suivra nomme le bon fichier, ce qui est plus
            // utile qu'un chemin de parent qui n'existe pas davantage.
            return $chemin;
        }

        /**
         * Ecrit la feuille personnalisee du style courant.
         *
         * L'ancienne version ne reecrivait le fichier que s'il etait absent ou
         * si tplhelper signalait une modification — or ce signal ne parvenait
         * jamais. Resultat : le fichier etait ecrit une seule fois, a la
         * premiere visite, puis servi tel quel indefiniment. Choisir un logo ou
         * une couleur de fond n'avait aucun effet visible sur le site.
         *
         * On compare desormais la feuille reconstruite au contenu du fichier :
         * s'ils different, on reecrit. C'est infaillible et cela ne coute qu'une
         * lecture de fichier, la construction etant de toute facon faite en
         * memoire une fois par requete.
         */
        public function saveCustomStyle()
        {
            $customCssFile = $this->getCustomCssPath();
            $css           = $this->buildCustomStyle();

            if ($css === '') {
                return false;
            }

            if (is_file($customCssFile) && file_get_contents($customCssFile) === $css) {
                return false;
            }

            // LE DOSSIER D'UN ENFANT EST CREE VIDE : `css/custom-styles/`
            // n'y existe pas, et File::write ne cree pas l'arborescence. Sans
            // ces deux lignes, l'ecriture echoue et le style enfant reste sans
            // feuille de reglages — meme panne silencieuse que ci-dessus, a
            // l'autre bout de la chaine.
            $dossier = dirname($customCssFile);

            if (!is_dir($dossier)) {
                Folder::create($dossier);
            }

            $ecrit = File::write($customCssFile, $css);

            // PHP garde en memoire les informations du fichier : sans ce vidage,
            // filemtime renverrait la date d'avant l'ecriture et l'adresse de la
            // feuille ne changerait pas, donc le navigateur garderait son cache.
            clearstatcache(true, $customCssFile);

            return $ecrit;
        }

        /**
         * Remet a zero l'indicateur de modification pour eviter une recompilation.
         */
        public function clearTplStatus()
        {
            $tplhelper = $this->get('tplhelper');

            if (!is_array($tplhelper)) {
                return;
            }

            $needUpdate = false;

            foreach ($tplhelper as $val) {
                if ($val) {
                    $needUpdate = true;
                }
            }

            if (!$needUpdate) {
                return;
            }

            $tplParams = $this->params;
            $tplParams->set('tplhelper', '');

            $db      = $this->getDb();
            $params  = json_encode($tplParams->toArray());
            $styleId = (int) $this->getStyleId();

            $query = $db->getQuery(true)
                ->update($db->quoteName('#__template_styles'))
                ->set($db->quoteName('params') . ' = :params')
                ->where($db->quoteName('id') . ' = :id')
                ->bind(':params', $params)
                ->bind(':id', $styleId, ParameterType::INTEGER);

            $db->setQuery($query);
            $db->execute();
        }

        /**
         * Compile les parametres de style en feuille CSS.
         */
        public function buildCustomStyle()
        {
            static $customStyleCss = null;

            if ($customStyleCss !== null) {
                return $customStyleCss;
            }

            // LE GABARIT SE LIT — il vient donc du parent quand le template
            // actif est un enfant. Sans ce repli, `is_file` echouait chez
            // l'enfant, la methode rendait une chaine vide, et AUCUN des
            // 146 reglages n'agissait plus. En silence : pas d'erreur, pas de
            // message, juste un site qui ignore ses propres parametres.
            $customCssTplFile = JPATH_ROOT . '/' . $this->getMediaFichier('css/custom-styles.tpl.css');

            if (!is_file($customCssTplFile)) {
                return '';
            }

            $customStyleCss = file_get_contents($customCssTplFile);

            // Resolution des blocs conditionnels : /* ?variable */ ... /* /variable */
            $arr    = preg_split('/\/\* \?([^\s]+) \*\//m', $customStyleCss, -1, PREG_SPLIT_DELIM_CAPTURE);
            $i      = 0;
            $chunks = [$arr[0]];

            while ($i < count($arr) - 2) {
                $checkVar   = $arr[++$i];
                $tmp        = explode(':', $checkVar, 2);
                $checkVar   = $tmp[0];
                $checkValue = count($tmp) > 1 ? $tmp[1] : null;
                $checkArr   = preg_split('/\/\* \/' . preg_quote($checkVar, '/') . ' \*\//', $arr[++$i]);
                $checkStr   = count($checkArr) > 1 ? $checkArr[0] : null;

                if ($checkStr) {
                    $matchesValue = $checkValue !== null && $this->getParam($checkVar) == $checkValue;
                    $isTruthy     = $checkValue === null && $this->getParam($checkVar);

                    if ($matchesValue || $isTruthy) {
                        $chunks[] = $this->replaceStyleVars($checkStr);
                    }

                    if (count($checkArr) > 1) {
                        $chunks[] = $checkArr[1];
                    }
                } else {
                    $chunks[] = $arr[$i];
                }
            }

            if (count($chunks) > 1) {
                $customStyleCss = implode('', $chunks);
            }

            $customStyleCss = $this->replaceStyleVars($customStyleCss);

            return $customStyleCss;
        }

        /**
         * Remplace les jetons __variable par la valeur du parametre correspondant.
         */
        private function replaceStyleVars($css)
        {
            $tplParams = $this->params;

            /*
             * LE JETON NE DOIT PAS POUVOIR ETRE UN NOM DE CLASSE — 10 aout 2026.
             *
             * Le motif etait `\{?__([0-9a-zA-Z_]+)\}?`, sans rien devant. Il
             * attrapait donc le `__nom` de `.marque__nom` : le double tiret bas
             * du BEM est exactement celui qui prefixe nos jetons. Le selecteur
             * du logo partait en `.marque--image .marqueinherit`, parce que le
             * parametre « nom » n'existe pas et que le repli vaut `inherit`.
             *
             * Resultat mesure sur corpus.joomanji.eu : la regle etait dans la
             * feuille, complete et valide — largeur, hauteur, image, retrait —
             * mais ne designait aucun element de la page. Le logo n'apparaissait
             * pas, et rien nulle part ne le signalait.
             *
             * Le lookbehind exige que le `__` ne suive pas un caractere de mot.
             * `.marque__nom` est donc epargne, `{__baseUrl}` et ` __styleTeinte`
             * sont toujours pris. Verifie sur le gabarit entier : `.marque__nom`
             * est la SEULE occurrence de `__` precedee d'une lettre.
             *
             * La valeur est nettoyee de son fragment `#joomlaImage://...` :
             * sans cela il finissait dans chaque url() produite.
             */
            return preg_replace_callback(
                '/(?<![0-9a-zA-Z_])\{?__([0-9a-zA-Z_]+)\}?/',
                static function ($matches) use ($tplParams) {
                    $valeur = $tplParams->get($matches[1], 'inherit');

                    return is_string($valeur) ? self::cheminMedia($valeur) : $valeur;
                },
                $css
            );
        }

        /**
         * Recompile la feuille personnalisee apres un enregistrement des parametres.
         */
        public function afterSave()
        {
            $this->saveRevision('style', 'styles');
            $this->saveRevision('layout', 'layouts');
            $this->saveCustomStyle();
            $this->clearTplStatus();
        }

        /**
         * Injecte la feuille de style personnalisee.
         *
         * Le chargement des polices Google a ete retire le 31 juillet 2026 avec
         * le champ styleGoogleFonts. Corpus utilise la pile de polices systeme :
         * c'est a la fois le choix juridique — Marianne et Spectral sont sous
         * modalites separees, et le DSFR interdit la recherche de ressemblance —
         * celui de l'eco-conception et celui de la performance.
         *
         * Ce sont ces deux <link> qui chargeaient PT Sans et Indie Flower, et la
         * feuille produite ici qui imposait « PT Sans » au body : notre propre
         * regle de police etait ecrite mais PERDANTE, cette feuille passant
         * apres template-j4.css. Mesure dans l'inspecteur le 31 juillet.
         */
        public function addCustomStyle()
        {
            $html = '';

            if (is_file($this->getCustomCssPath())) {
                $html .= '<link id="custom-style-css" href="' . $this->getCustomCssPath(true) . '" rel="stylesheet">' . "\n";
            } else {
                $html .= '<style id="custom-style-css">' . "\n" . $this->buildCustomStyle() . "\n" . '</style>' . "\n";
            }

            echo $html;
        }

        /**
         * Rendu d'une rangee de modules.
         */
        public function spotlight($pos, $options = [])
        {
            // LE DEFAUT EST « ACTIVE » — 6 aout 2026, demande de Cyrille.
            //
            // Il etait absent, donc `null`, donc faux : les huit rangees et le
            // pied etaient ETEINTS a l'installation. Un site venu de
            // Cassiopeia, avec ses modules dans `top-a` ou `bottom-b`, ne
            // montrait rien — et rien n'expliquait pourquoi.
            //
            // Allumer par defaut ne coute rien : quelques lignes plus bas,
            // `if (!count($modules)) return;` fait qu'une zone vide ne produit
            // aucun balisage. C'est le comportement de Cassiopeia, et c'est
            // une contrainte de vente.
            if (!$this->getParam('layoutEnable_' . $pos, 1)) {
                return;
            }

            $position = $this->getParam('layoutPos_' . $pos);
            $posWidth = $this->getParam('layoutWidth_' . $pos);
            $modules  = ModuleHelper::getModules($position);

            if (!count($modules)) {
                return;
            }

            $widths   = [];
            $posWidth = preg_replace('/\s/', '', $posWidth ?? '');

            if (preg_match('/^[0-9,:-]+$/', $posWidth)) {
                $widths = preg_split('/[,:-]/', $posWidth);
            } elseif ($posWidth === 'none') {
                $widths[] = '';
            } else {
                // Repartition automatique sur douze colonnes.
                $col       = count($modules);
                $width     = $col < 6 ? floor(12 / $col) : 2;
                $lastWidth = $col < 6 ? 12 - $width * ($col - 1) : 2;
                $widths    = $col > 1 ? array_fill(0, $col - 1, $width) : [];
                $widths[]  = $lastWidth;
            }

            $columns = [];
            $mod     = round(count($modules) / count($widths));
            $c       = 0;

            $app          = Factory::getApplication();
            $user         = $app->getIdentity();
            $frontediting = $app->isClient('site') && $app->get('frontediting', 1) && $user && !$user->guest;
            $menusEditing = $app->get('frontediting', 1) == 2 && $user && $user->authorise('core.edit', 'com_menus');

            for ($i = 0; $i < count($widths); $i++) {
                $col        = new stdClass();
                // `colonne-N`, jamais `col-lg-N` : voir la collision mesuree en
                // tete de _mise-en-page.scss. La valeur est bornee a 1-12 —
                // « 8,4 » saisi a la main ne doit pas pouvoir sortir de la grille.
                $largeur    = max(1, min(12, (int) $widths[$i]));
                $col->width = $widths[$i] === '' ? '' : 'colonne-' . $largeur;
                $col->html  = '';

                while ($c < count($modules) && $c < ($i + 1) * $mod) {
                    // LE CHROME EST CHOISI PAR L'APPELANT — 4 aout 2026.
                    //
                    // Il etait `encadre` en dur pour toutes les zones. Le pied
                    // de page en heritait donc, et Cyrille a vu ses deux blocs
                    // sortir en cartes blanches posees sur le fond du pied, la
                    // ou la maquette les montre a plat. Le cadre a du sens dans
                    // une colonne laterale, ou il separe des modules voisins ;
                    // dans un pied, il ne separe rien et alourdit tout.
                    $chrome = $options['style'] ?? 'encadre';
                    $moduleHtml = ModuleHelper::renderModule($modules[$c], ['style' => $chrome]);

                    if ($frontediting && trim($moduleHtml) !== ''
                        && $user->authorise('module.edit.frontend', 'com_modules.module.' . $modules[$c]->id)) {
                        $displayData = [
                            'moduleHtml'   => &$moduleHtml,
                            'module'       => $modules[$c],
                            'position'     => $modules[$c]->position,
                            'menusediting' => $menusEditing,
                        ];
                        LayoutHelper::render('joomla.edit.frontediting_modules', $displayData);
                    }

                    $col->html .= $moduleHtml . "\n";
                    $c++;
                }

                $columns[] = $col;
            }

            // Le choix « Aucun » d'un groupe exclusif est un bouton radio de
            // valeur vide : il arrive donc ici comme une chaine vide dans le
            // tableau. On l'ecarte plutot que de laisser `implode` produire une
            // double espace dans l'attribut.
            /*
             * La valeur arrive sous trois formes selon l'age du style et le
             * groupe qui l'a produite : une CHAINE (styles d'avant les cases a
             * cocher), un TABLEAU a rangs (les cases), ou un OBJET a cles (les
             * groupes exclusifs, qui postent `…[fond]` et `…[theme]` pour que le
             * navigateur ne confonde pas leurs boutons radio).
             *
             * On les ramene toutes a un tableau avant de joindre. Le choix
             * « Aucun » d'un groupe exclusif vaut la chaine vide : on l'ecarte,
             * sinon l'attribut porterait une double espace.
             */
            $layoutClass = $this->getParam('layoutClass_' . $pos);

            if (is_object($layoutClass)) {
                $layoutClass = get_object_vars($layoutClass);
            }

            $layoutClass = is_array($layoutClass)
                ? implode(' ', array_filter($layoutClass, static fn($c) => trim((string) $c) !== ''))
                : (string) $layoutClass;

            $class = isset($options['class']) ? $options['class'] . ' section ' : 'section ';
            $class .= $layoutClass;

            $options['key']   = $pos;
            $options['id']    = $this->getParam('layoutName_' . $pos) ?: $pos;
            $options['class'] = $class ? ' class="' . trim($class) . '"' : '';
            $options['row']   = $posWidth !== 'none';

            echo LayoutHelper::render('corpus.position', [
                'columns' => $columns,
                'options' => $options,
                'helper'  => $this,
            ]);
        }
    }
}

return new CorpusHelper();
