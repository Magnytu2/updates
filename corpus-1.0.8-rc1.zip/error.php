<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LA PAGE D'ERREUR
 *
 * Reecrite le 3 aout 2026 au soir, a la demande de Cyrille : elle doit
 * ressembler au site, porter sa marque, et sa couleur.
 *
 * QUATRE FAMILLES, QUATRE MESSAGES. 404, 403, 5xx, et le reste. Chacune dit
 * ce qui s'est passe en une phrase, puis ce qu'on peut faire. Le ton est
 * leger sur le 404 seulement — « Oups » : on ne plaisante pas avec un acces
 * refuse ni avec une panne. Vouvoiement partout.
 *
 * ELLE PORTE LA TEINTE DU SITE, ET RESTE POURTANT AUTONOME.
 *
 * L'ancienne version chargeait error.css seule, sans jeton : d'ou un bouton
 * noir et aucune trace du theme. Les trois feuilles sont maintenant liees
 * DANS CET ORDRE — template-j4.css, la feuille personnalisee du style, puis
 * error.css. La derniere lit les jetons AVEC UN REPLI ecrit en dur :
 *
 *     --e-encre: var(--encre, #16180f);
 *
 * Si les deux premieres manquent — le jour ou le site est vraiment casse — la
 * page garde son neutre et s'affiche quand meme. C'est la reponse a
 * l'objection que portait l'ancien commentaire : on ne choisit plus entre
 * « jolie » et « robuste ».
 *
 * LE MESSAGE TECHNIQUE N'EST PLUS AFFICHE AU VISITEUR. Le coeur le mettait
 * dans le <h1>. Sur un 404 il est inoffensif ; sur une erreur serveur il peut
 * livrer un nom de table ou un chemin. Il n'apparait qu'en mode debogage.
 *
 * LES POSITIONS error-403 ET error-404 SONT ENFIN RENDUES. Declarees dans le
 * manifeste depuis le portage et lues nulle part. Quand elles sont vides, la
 * page le DIT au lieu de laisser un bouton seul sans explication.
 *
 * Le rendu des modules est enveloppe : c'est la page qui s'affiche quand
 * quelque chose est deja casse, elle n'a pas le droit de tomber a son tour.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

/** @var Joomla\CMS\Document\ErrorDocument $this */

$app = Factory::getApplication();
$doc = $app->getDocument();

$this->language  = $doc->language;
$this->direction = $doc->direction;

$modele = $app->getTemplate(true);
$params = $modele->params;
$input  = $app->getInput();

// Les chaines du template ne sont pas chargees d'office sur un document
// d'erreur. Sans cette ligne, la page afficherait ses propres cles en clair —
// exactement le defaut qu'on reproche au pack de langue du coeur.
$app->getLanguage()->load('tpl_' . $this->template, JPATH_THEMES . '/' . $this->template, null, false, true);

$code = (int) $this->error->getCode();

/*
 * APERCU D'UNE FAMILLE, EN MODE DEBOGAGE SEULEMENT.
 *
 * Une erreur 500 ne se provoque pas a la demande : il faudrait casser le site
 * pour voir la page qui s'affiche quand il est casse. Avec le debogage actif,
 * `?corpus-erreur=500` sur n'importe quelle adresse introuvable affiche la
 * famille demandee, sans qu'aucune erreur reelle ne survienne.
 *
 * Le garde-fou est le mode debogage du site, pas un reglage du template : chez
 * un client, le parametre est ignore et ne peut donc rien montrer de faux.
 */
$apercu = (int) $input->getInt('corpus-erreur', 0);

if ($apercu > 0 && $app->get('debug')) {
    $code = $apercu;
}

if ($code === 404) {
    // LE VISAGE SURPRIS, ET LE TON DE L'AVERTISSEMENT.
    //
    // Choix de Cyrille, 3 aout 2026, apres avoir vu le vert : le sourire va a
    // la page de connexion, qui accueille ; une adresse introuvable, elle,
    // surprend. D'ou un visage a la bouche ronde — « ho ! » — sur la couleur
    // de l'avertissement.
    //
    // La couleur ne porte AUCUNE information a elle seule : le code, le titre
    // et l'explication le font tous les trois. C'est ce qui permet de la
    // choisir sur un critere de ton sans contrevenir a WCAG 1.4.1.
    $famille = '404';
    $ton     = 'alerte';
    $picto   = 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm0 2a8 8 0 1 1 0 16 8 8 0 0 1 0-16ZM8.9 8.6a1.15 1.15 0 1 1 0 2.3 1.15 1.15 0 0 1 0-2.3Zm6.2 0a1.15 1.15 0 1 1 0 2.3 1.15 1.15 0 0 1 0-2.3ZM12 13.4a2.3 2.3 0 1 1 0 4.6 2.3 2.3 0 0 1 0-4.6Z';
} elseif ($code === 403 || $code === 401) {
    $famille = '403';
    $ton     = 'alerte';
    $picto   = 'M12 2a5 5 0 0 0-5 5v3H5v12h14V10h-2V7a5 5 0 0 0-5-5Zm0 2a3 3 0 0 1 3 3v3H9V7a3 3 0 0 1 3-3Zm-5 8h10v8H7v-8Zm5 2a1.6 1.6 0 0 0-.8 3v1.6h1.6V17a1.6 1.6 0 0 0-.8-3Z';
} elseif ($code >= 500) {
    $famille = '500';
    $ton     = 'erreur';
    $picto   = 'M12 2 1 21h22L12 2Zm0 4.2L19.4 19H4.6L12 6.2ZM11 10h2v5h-2v-5Zm0 6h2v2h-2v-2Z';
} else {
    $famille = 'AUTRE';
    $ton     = 'info';
    $picto   = 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm0 2a8 8 0 1 1 0 16 8 8 0 0 1 0-16Zm0 3a3 3 0 0 0-3 3h2a1 1 0 1 1 2 0c0 .8-.4 1.2-1 1.7-.8.6-1 1.3-1 2.3h2c0-.6.2-.9.8-1.4.8-.6 1.2-1.3 1.2-2.6a3 3 0 0 0-3-3Zm-1 9h2v2h-2v-2Z';
}

// LA POSITION SE DEDUIT DU CODE, PAS DE LA FAMILLE.
//
// Verifie le 3 aout 2026 contre la documentation de Joomla (manual.joomla.org,
// « Custom Error Pages ») : la convention du coeur est `error-<code>`, lue par
// `countModules()` puis rendue par un `<jdoc:include>`. Cassiopeia declare
// `error-403` et `error-404` depuis Joomla 5 — ce ne sont donc pas des
// positions heritees de JA Simpli, mais un usage etabli qu'il faut suivre.
//
// LA PREMIERE ECRITURE SE TROMPAIT : elle repliait tout ce qui n'etait pas un
// 403 sur `error-404`. Un module pose pour dire « page introuvable, essayez la
// recherche » se serait donc affiche sur une PANNE SERVEUR, ou il n'a aucun
// sens. Avec le code, une erreur 500 ne trouve rien tant que personne n'a pose
// de module sur `error-500`, et la page s'en excuse — ce qui est juste.
$position = 'error-' . $code;

// La marque du site, comme dans index.php : une image de logo remplace le
// texte, mais le nom reste dans le balisage — il porte le lien pour les
// lecteurs d'ecran. RGAA 1.1
$nom = trim((string) $params->get('logoText'));
$nom = $nom !== '' ? $nom : (string) $app->get('sitename');

$slogan = trim((string) $params->get('logoSlogan'));
$slogan = $slogan !== '' ? $slogan : (string) $app->get('MetaDesc');

$logo = trim((string) $params->get('styleLogoImage'));

// Un champ media enregistre « chemin#joomlaImage://... » : seul le chemin
// nous interesse.
if ($logo !== '' && strpos($logo, '#') !== false) {
    $logo = substr($logo, 0, strpos($logo, '#'));
}

$mediaUrl = $this->baseurl . '/media/templates/site/' . $this->template;
$styleId  = (int) ($modele->id ?? 0);

/*
 * LE REPLI VERS LE TEMPLATE PARENT — 6 aout 2026.
 *
 * Le dossier media d'un template enfant est cree VIDE par Joomla. Sans repli,
 * une page d'erreur servie sous un style enfant arrive SANS AUCUNE FEUILLE :
 * du texte noir sur fond blanc, au moment precis ou le visiteur a besoin
 * d'etre rassure.
 *
 * CES QUINZE LIGNES REFONT CE QUE `helper::getMediaFichier()` SAIT DEJA
 * FAIRE, ET C'EST VOULU. `error.php` ne charge pas le helper : une page
 * d'erreur doit tenir quand le reste ne tient plus, et une 500 vient souvent
 * de la base de donnees — que le helper interroge des son init(). Introduire
 * ici une dependance qui peut etre la cause meme de l'erreur, c'est se
 * garantir une page blanche le jour ou tout va mal.
 *
 * Duplication assumee, donc, et signalee aux deux endroits : si la regle du
 * repli change, elle change ici aussi.
 */
$corpusParent = null;
$corpusFichier = function ($relatif) use (&$corpusParent) {
    $actif = $this->template;
    $base  = 'media/templates/site/' . $actif . '/' . ltrim($relatif, '/');

    if (is_file(JPATH_ROOT . '/' . $base)) {
        return $this->baseurl . '/' . $base;
    }

    if ($corpusParent === null) {
        $corpusParent = false;
        $manifeste  = JPATH_THEMES . '/' . $actif . '/templateDetails.xml';

        if (is_file($manifeste)) {
            $xml = @simplexml_load_file($manifeste);

            if ($xml !== false && isset($xml->parent) && (string) $xml->parent !== '') {
                $corpusParent = (string) $xml->parent;
            }
        }
    }

    if ($corpusParent) {
        $chemin = 'media/templates/site/' . $corpusParent . '/' . ltrim($relatif, '/');

        if (is_file(JPATH_ROOT . '/' . $chemin)) {
            return $this->baseurl . '/' . $chemin;
        }
    }

    return $this->baseurl . '/' . $base;
};

// Ce que l'administrateur a pose sur la position : un menu, une recherche, un
// lien de contact. Si rien n'y est, la page s'en excuse plutot que de laisser
// un bouton seul.
//
// `countModules()` COMPTE SANS RENDRE : c'est ce que la documentation
// recommande, et ca permet de decider du texte avant d'ecrire le balisage. Le
// rendu, lui, passe par `<jdoc:include>` plus bas — la voie que Cassiopeia
// emprunte, donc celle qui est eprouvee sur une page d'erreur.
try {
    $sorties = (bool) $this->countModules($position);
} catch (Throwable $e) {
    $sorties = false;
}
?>
<!DOCTYPE html>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $code; ?> — <?php echo Text::_('TPL_CORPUS_ERR_' . $famille . '_TITRE'); ?></title>

	<link href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon">
	<link href="<?php echo $corpusFichier('css/template-j4.css'); ?>" rel="stylesheet">
	<?php if ($styleId > 0) : ?>
	<link href="<?php echo $mediaUrl; ?>/css/custom-styles/<?php echo $styleId; ?>.css" rel="stylesheet">
	<?php endif; ?>
	<link href="<?php echo $corpusFichier('css/error.css'); ?>" rel="stylesheet">
</head>

<body class="site erreur erreur--<?php echo strtolower($famille); ?>">

	<main class="erreur__corps">

		<?php
		// LA MARQUE OUVRE LA PAGE, au-dessus du message. Pas de menu : les
		// liens du site sont peut-etre justement ceux qui ont echoue. La
		// marque suffit a dire ou l'on est, et elle ramene a l'accueil.
		?>
		<a class="erreur__marque" href="<?php echo $this->baseurl; ?>/">
			<?php if ($logo !== '') : ?>
			<img src="<?php echo $this->baseurl . '/' . htmlspecialchars($logo, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($nom, ENT_QUOTES, 'UTF-8'); ?>">
			<?php else : ?>
			<span class="erreur__nom"><?php echo htmlspecialchars($nom, ENT_QUOTES, 'UTF-8'); ?></span>
			<?php if ($slogan !== '') : ?>
			<span class="erreur__slogan"><?php echo htmlspecialchars($slogan, ENT_QUOTES, 'UTF-8'); ?></span>
			<?php endif; ?>
			<?php endif; ?>
		</a>

		<?php
		// LE MESSAGE EST CELUI DE CORPUS. Meme balisage que
		// html/layouts/joomla/system/message.php — `.message`, sa famille, le
		// filet, le pictogramme et l'intitule ecrit. Une erreur de navigation
		// EST un message systeme : elle n'a pas besoin d'un dessin a elle.
		//
		// Le pictogramme est trace ICI et non appele par <use> : la page ne
		// charge pas nos symboles, qui sont injectes par index.php.
		//
		// role="alert" parce que la page interrompt : c'est la regle deja
		// posee dans le gabarit des messages.
		?>
		<div class="message message--<?php echo $ton; ?> filet erreur__bloc" role="alert">
			<svg class="i" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="<?php echo $picto; ?>"/></svg>

			<div>
				<p class="erreur__code"><?php echo Text::_('TPL_CORPUS_ERR_CODE'); ?> <?php echo $code; ?></p>
				<h1 class="message__titre"><?php echo Text::_('TPL_CORPUS_ERR_' . $famille . '_TITRE'); ?></h1>
				<p class="erreur__explication"><?php echo Text::_('TPL_CORPUS_ERR_' . $famille . '_TEXTE'); ?></p>

				<?php if ($famille === '404') : ?>
				<?php // La liste des causes n'a de sens que sur une adresse introuvable. ?>
				<ul class="erreur__causes">
					<li><?php echo Text::_('TPL_CORPUS_ERR_CAUSE_ADRESSE'); ?></li>
					<li><?php echo Text::_('TPL_CORPUS_ERR_CAUSE_DEPLACEE'); ?></li>
					<li><?php echo Text::_('TPL_CORPUS_ERR_CAUSE_LIEN'); ?></li>
				</ul>
				<?php endif; ?>
			</div>
		</div>

		<div class="erreur__sorties">
			<?php if ($sorties) : ?>
			<h2><?php echo Text::_('TPL_CORPUS_ERR_QUE_FAIRE'); ?></h2>
			<?php else : ?>
			<p class="erreur__seule-sortie"><?php echo Text::_('TPL_CORPUS_ERR_SEULE_SORTIE'); ?></p>
			<?php endif; ?>

			<p>
				<a class="bouton" href="<?php echo $this->baseurl; ?>/index.php"><svg class="i" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 3 2 12h3v9h6v-6h2v6h6v-9h3L12 3Z"/></svg> <?php echo Text::_('TPL_CORPUS_ERR_ACCUEIL'); ?></a>
			</p>

			<?php if ($sorties) : ?>
			<?php // style="none" comme le coeur : notre chrome de module n'est
			      // pas garanti sur un document d'erreur. ?>
			<div class="erreur__modules">
				<jdoc:include type="modules" name="<?php echo $position; ?>" style="none" />
			</div>
			<?php endif; ?>
		</div>

		<?php if ($app->get('debug')) : ?>
		<?php // Le detail technique : en debogage seulement. ?>
		<p class="erreur__technique"><?php echo htmlspecialchars($this->error->getMessage(), ENT_QUOTES, 'UTF-8'); ?></p>
		<?php endif; ?>
	</main>

	<?php echo $doc->getBuffer('modules', 'debug', ['style' => 'none']); ?>
</body>
</html>
