<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

/** @var Joomla\CMS\Document\HtmlDocument $this */

$app = Factory::getApplication();

/*
 * LA PAGE HORS LIGNE PORTE LA TEINTE DU SITE — 3 aout 2026.
 *
 * Elle ne chargeait qu'offline.css, autonome, avec ses propres couleurs. Deux
 * consequences : aucune trace du theme, et surtout un TROISIEME jeu de regles
 * pour les champs et les boutons — `.champ`, `.champ--case`, `.bouton` y
 * etaient recopies, la ou _formulaires.scss les tient deja. Trois copies qui
 * divergeraient a la premiere retouche.
 *
 * L'ARGUMENT DE L'AUTONOMIE NE TIENT PAS ICI, contrairement a error.php. Un
 * site hors ligne est un ETAT ADMINISTRATIF, pas une panne : Joomla tourne, le
 * gestionnaire d'assets aussi, et rien n'empeche de servir la feuille du site.
 * On charge donc la meme chaine que le site — Bootstrap, template-j4.css, la
 * feuille personnalisee du style — et offline.css ne garde que la mise en page
 * qui lui est propre.
 */
$helper = require __DIR__ . '/helper.php';
$helper->init($this);

$wa       = $this->getWebAssetManager();
$mediaUrl = 'media/templates/site/' . $this->template;

$wa->registerAndUseStyle('corpus.bootstrap', 'media/vendor/bootstrap/css/bootstrap.min.css');
$wa->registerAndUseStyle('template.corpus', $helper->getMediaFichier('css/template-j4.css'), [], [], ['corpus.bootstrap']);
// error.css PORTE LA MISE EN PAGE DES PAGES D'ETAT, pas seulement des
// erreurs : la colonne centree, la marque, le bloc de message, les sorties.
// La maintenance est la quatrieme de la famille — meme forme, meme rythme.
// offline.css ne garde apres elle que le formulaire de connexion.
$wa->registerAndUseStyle('corpus.etat', $helper->getMediaFichier('css/error.css'), [], [], ['template.corpus']);
$wa->registerAndUseStyle('corpus.offline', $helper->getMediaFichier('css/offline.css'), [], [], ['corpus.etat']);
?>
<!DOCTYPE html>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<jdoc:include type="head" />
	<?php $helper->addCustomStyle(); ?>
</head>
<body class="site erreur erreur--maintenance">
<jdoc:include type="message" />

<main class="erreur__corps">

	<?php
	// LA MARQUE OUVRE LA PAGE, comme sur la page d'erreur. L'image hors ligne
	// de la configuration globale la remplace si elle est posee.
	?>
	<a class="erreur__marque" href="<?php echo Uri::root(true); ?>/">
		<?php if ($app->get('offline_image')) : ?>
		<img src="<?php echo $app->get('offline_image'); ?>" alt="<?php echo htmlspecialchars($app->get('sitename'), ENT_QUOTES, 'UTF-8'); ?>">
		<?php else : ?>
		<span class="erreur__nom"><?php echo htmlspecialchars($app->get('sitename'), ENT_QUOTES, 'UTF-8'); ?></span>
		<?php endif; ?>
	</a>

	<?php
	// LE MEME BLOC QUE LES ERREURS, dans la famille « information ».
	//
	// Une maintenance n'est ni une faute ni une panne : c'est un etat annonce,
	// et l'information est exactement ce que la famille dit. `role="status"`
	// et non `role="alert"` pour la meme raison — rien n'interrompt, on
	// previent.
	//
	// Le pictogramme est une cle plate, tracee ici : la page n'a pas les
	// symboles d'index.php.
	?>
	<div class="message message--info filet erreur__bloc" role="status">
		<svg class="i" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M17.5 2a5.5 5.5 0 0 0-5.2 7.3l-8.1 8.1a2.4 2.4 0 0 0 3.4 3.4l8.1-8.1A5.5 5.5 0 0 0 23 7.5c0-.7-.1-1.3-.4-1.9l-3.4 3.4-2.2-2.2 3.4-3.4c-.6-.3-1.2-.4-1.9-.4Z"/></svg>

		<div>
			<p class="erreur__code"><?php echo Text::_('TPL_CORPUS_OFFLINE_MENTION'); ?></p>
			<h1 class="message__titre"><?php echo Text::_('TPL_CORPUS_OFFLINE_TITRE'); ?></h1>

			<?php if ($app->get('display_offline_message', 1) == 1 && str_replace(' ', '', $app->get('offline_message')) !== '') : ?>
			<div class="erreur__explication"><?php echo $app->get('offline_message'); ?></div>
			<?php elseif ($app->get('display_offline_message', 1) == 2 && str_replace(' ', '', Text::_('JOFFLINE_MESSAGE')) !== '') : ?>
			<div class="erreur__explication"><?php echo Text::_('JOFFLINE_MESSAGE'); ?></div>
			<?php endif; ?>
		</div>
	</div>

	<div class="erreur__sorties">
		<h2><?php echo Text::_('JLOGIN'); ?></h2>

	<?php
	// Le formulaire est ecrit sur le vocabulaire de Corpus : `.champ` et
	// `.bouton`, comme partout. L'ancien sortait `.inputbox`, `.button login`
	// et des <p> porteurs d'identifiants — du balisage de Joomla 1.5, herite
	// tel quel, et dont le seul <label>&nbsp;</label> disait deja tout.
	?>
	<form action="<?php echo Route::_('index.php', true); ?>" method="post" id="form-login">
		<?php
		// PAS DE <fieldset> NI DE <legend> : le titre « Connexion » ci-dessus
		// groupe deja le formulaire, et un fieldset ajouterait un cadre autour
		// de deux champs — plus une legende qui repeterait le titre, donc lue
		// deux fois par un lecteur d'ecran.
		?>
			<div class="champ">
				<label for="username"><?php echo Text::_('JGLOBAL_USERNAME'); ?></label>
				<input name="username" id="username" type="text" autocomplete="username">
			</div>

			<div class="champ">
				<label for="passwd"><?php echo Text::_('JGLOBAL_PASSWORD'); ?></label>
				<input type="password" name="password" id="passwd" autocomplete="current-password">
			</div>

			<button type="submit" name="Submit" class="bouton"><?php echo Text::_('JLOGIN'); ?></button>

			<input type="hidden" name="option" value="com_users">
			<input type="hidden" name="task" value="user.login">
			<input type="hidden" name="return" value="<?php echo base64_encode(Uri::base()); ?>">
			<?php echo HTMLHelper::_('form.token'); ?>
	</form>
	</div>
</main>
</body>
</html>
