/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * REECRIT le 31 juillet 2026 depuis le script de maquettes/front-corpus.html.
 * L'ancien fichier pilotait le balisage d'origine — barres epinglees,
 * .nav-collapse, dropdowns Bootstrap — qui n'existe plus.
 *
 * JavaScript natif, sans jQuery. Aucune dependance a Bootstrap.
 *
 * Le code ne connait AUCUN niveau de menu : il lit aria-expanded et
 * aria-controls, et la meme fonction sert au deuxieme comme au troisieme.
 */

(function () {
	'use strict';

	var racine = document.documentElement;
	var media  = window.matchMedia('(prefers-color-scheme: dark)');

	// ---- Theme -------------------------------------------------------------
	// Memorise dans un try/catch : un navigateur qui refuse le stockage ne doit
	// pas casser la page. « systeme » suit prefers-color-scheme et reagit EN
	// DIRECT, pas seulement au chargement.

	function lire() {
		try { return localStorage.getItem('corpus-theme') || 'systeme'; } catch (e) { return 'systeme'; }
	}

	function ecrire(v) {
		try { localStorage.setItem('corpus-theme', v); } catch (e) { /* stockage refuse */ }
	}

	function appliquer(v) {
		racine.setAttribute('data-theme', v === 'systeme' ? (media.matches ? 'sombre' : 'clair') : v);
	}

	var choix = lire();
	appliquer(choix);

	var coche = document.querySelector('input[name="corpus-theme"][value="' + choix + '"]');
	if (coche) {
		coche.checked = true;
	}

	media.addEventListener('change', function () {
		if (lire() === 'systeme') {
			appliquer('systeme');
		}
	});

	Array.prototype.forEach.call(document.querySelectorAll('input[name="corpus-theme"]'), function (r) {
		r.addEventListener('change', function () {
			ecrire(r.value);
			appliquer(r.value);
		});
	});

	// ---- Panneau d'affichage -----------------------------------------------

	var panneau = document.getElementById('corpus-affichage');
	var retour  = null;

	function ouvrirPanneau(e) {
		retour = e.currentTarget;
		retour.setAttribute('aria-expanded', 'true');
		panneau.hidden = false;
		(panneau.querySelector('input:checked') || panneau.querySelector('input')).focus();
	}

	function fermerPanneau() {
		if (!panneau || panneau.hidden) {
			return;
		}

		panneau.hidden = true;

		// Le focus revient d'ou il venait. RGAA 10.13.
		if (retour) {
			retour.setAttribute('aria-expanded', 'false');
			retour.focus();
		}
	}

	if (panneau) {
		Array.prototype.forEach.call(document.querySelectorAll('[data-corpus-affichage]'), function (b) {
			b.addEventListener('click', ouvrirPanneau);
		});

		Array.prototype.forEach.call(panneau.querySelectorAll('[data-corpus-fermer]'), function (b) {
			b.addEventListener('click', fermerPanneau);
		});

		// Un clic sur le voile referme, un clic dans la boite non.
		panneau.addEventListener('click', function (e) {
			if (e.target === panneau) {
				fermerPanneau();
			}
		});

		// Piege a focus.
		document.addEventListener('keydown', function (e) {
			if (e.key !== 'Tab' || panneau.hidden) {
				return;
			}

			var f = panneau.querySelectorAll('input, button');
			var premier = f[0];
			var dernier = f[f.length - 1];

			if (e.shiftKey && document.activeElement === premier) {
				e.preventDefault();
				dernier.focus();
			} else if (!e.shiftKey && document.activeElement === dernier) {
				e.preventDefault();
				premier.focus();
			}
		});
	}

	// ---- Le bouton de repli du menu principal ------------------------------
	//
	// Ecrit le 7 aout 2026. Sous 48 rem, la liste passait en colonne et restait
	// depliee : tenable a quatre entrees, intenable a dix.
	//
	// Le bouton est pose `hidden` dans index.php et revele ici. Sans
	// JavaScript il n'apparait jamais et la liste reste depliee : un menu
	// deplie se parcourt, un bouton mort ne fait rien.

	Array.prototype.forEach.call(document.querySelectorAll('.navigation'), function (barre) {
		var bascule = barre.querySelector('.nav__bascule');
		var liste = barre.querySelector('.nav__liste');

		// Pas de menu publie dans la barre : le bouton reste cache, il n'aurait
		// rien a commander.
		if (!bascule || !liste) {
			return;
		}

		// `aria-controls` se pose ici, pas dans le balisage : le bouton vit
		// dans index.php et la liste sort de mod_menu, qui ne sait rien de lui.
		// L'identifiant du module est repris s'il existe, sinon on en forge un.
		if (!liste.id) {
			liste.id = 'corpus-menu-' + Math.random().toString(36).slice(2, 8);
		}
		bascule.setAttribute('aria-controls', liste.id);

		// La MEME coupure que la feuille de style, en rem et non en pixels :
		// ecrire 768px marcherait tant que personne ne change la taille de
		// police de la racine — et Corpus propose justement de la changer.
		var petit = window.matchMedia('(max-width: 48rem)');
		var ouvert = false;

		var appliquer = function () {
			if (petit.matches) {
				bascule.hidden = false;
				liste.hidden = !ouvert;
			} else {
				// Au-dessus de la coupure la liste est toujours visible. Sans
				// cette remise a plat, un menu ferme sur telephone resterait
				// ferme apres une rotation en paysage, sans bouton pour le
				// rouvrir : le bouton, lui, aurait disparu.
				bascule.hidden = true;
				liste.hidden = false;
			}

			bascule.setAttribute('aria-expanded', String(ouvert && petit.matches));
		};

		bascule.addEventListener('click', function () {
			ouvert = !ouvert;
			appliquer();
		});

		// Echap referme, mais SEULEMENT si aucun sous-menu n'est ouvert : le
		// gestionnaire des sous-menus ferme d'abord le plus profond, un cran a
		// la fois. On ne replie le menu entier qu'une fois les crans remontes.
		document.addEventListener('keydown', function (e) {
			if (e.key !== 'Escape' || !ouvert || !petit.matches) {
				return;
			}

			if (liste.querySelector('[aria-expanded="true"]')) {
				return;
			}

			ouvert = false;
			appliquer();
			bascule.focus();
		});

		petit.addEventListener('change', appliquer);
		appliquer();
	});

	// ---- Sous-menus, a toutes les profondeurs ------------------------------
	// Motif « divulgation » : un bouton, un panneau. Jamais un lien qui ne mene
	// nulle part. Le balisage vient de html/mod_menu/default.php.

	// IL Y A PLUSIEURS MENUS DANS UNE PAGE, et il a fallu le mesurer pour le
	// voir. Ce code cherchait `.navigation`, AU SINGULIER : le menu de l'entete
	// fonctionnait, celui publie en colonne laterale avait ses chevrons inertes.
	// Le balisage etait pourtant identique — mod_menu sort le meme partout, et
	// c'est justement pour ca qu'aucun defaut n'etait visible dans le HTML.
	//
	// Le module lui-meme n'a pas de classe a nous : on prend donc la liste,
	// qui en a une. Tout le reste du code s'ancre sur ce conteneur et n'a pas
	// change.
	Array.prototype.forEach.call(document.querySelectorAll('.navigation, .module .nav__liste'), function (nav) {
		/*
		 * ON ENUMERE CE QUI APPARTIENT AU MENU, PAS CE QU'IL FAUT EXCLURE.
		 *
		 * Le 7 aout, ce selecteur valait `[aria-expanded]:not(.nav__bascule)` :
		 * tout declencheur de la barre, sauf le bouton de repli du menu. Il
		 * fallait bien cette exclusion — sans elle, `fermerLesAutres` refermait
		 * le bouton au premier clic ailleurs et `panneauDe` cherchait un
		 * panneau `[id="null"]`.
		 *
		 * LE 12 AOUT, LE MEME DEFAUT EST REVENU. Le bouton de la recherche
		 * repliee est publie dans « Nav droite », donc DANS `.navigation` : il
		 * portait un `aria-expanded`, il a ete ramasse, et le clic sur la loupe
		 * n'ouvrait rien. Une liste d'exclusions se perime a chaque bouton
		 * qu'on ajoute ailleurs dans la barre — et rien ne le signale, le
		 * bouton se contente de ne plus repondre.
		 *
		 * La liste est donc POSITIVE : les trois classes que le gabarit du menu
		 * produit, et elles seules. Un bouton etranger publie dans la barre ne
		 * peut plus y entrer, qu'on y ait pense ou non.
		 *
		 *   .nav__lien[aria-expanded]        une entree « Titre », sans page
		 *   .nav__chevron                    le chevron d'une entree qui a sa page
		 *   .nav__sous__bouton               les niveaux 2 et 3
		 *
		 * ET LES TROIS DU MEGA-MENU, ajoutees le 12 aout 2026.
		 *
		 * Le panneau, lui, s'ouvrait deja : il est commande par `.nav__chevron`,
		 * qui etait deja dans la liste. Ce qui manquait, ce sont les commandes A
		 * L'INTERIEUR du panneau. Releve au banc AVANT de toucher a cette ligne :
		 * le panneau s'ouvrait, ses trois colonnes s'affichaient, et cliquer une
		 * bascule ne faisait rien. Le bouton sortait du gabarit, se dessinait
		 * correctement, et ne repondait pas — la panne muette annoncee.
		 *
		 *   .mega__bascule                   le chevron d'une page qui a un volet
		 *   .mega__bouton                    un « Titre de sous-menu » dans une colonne
		 *   .mega__replier                   le repli d'une colonne, sous 48 rem
		 */
		var declencheurs = Array.prototype.slice.call(
			nav.querySelectorAll(
				'.nav__lien[aria-expanded], .nav__chevron[aria-expanded], .nav__sous__bouton[aria-expanded],'
				+ ' .mega__bascule[aria-expanded], .mega__bouton[aria-expanded], .mega__replier[aria-expanded]'
			)
		);

		// Le panneau se cherche DANS CE MENU, pas dans tout le document.
		// getElementById rendait le panneau du premier menu de la page quand
		// deux modules affichaient le meme menu. Les identifiants sont
		// desormais uniques par module, et cette recherche locale fait la
		// deuxieme barriere : elle ne peut pas sortir du conteneur.
		var panneauDe = function (b) {
			return nav.querySelector('[id="' + b.getAttribute('aria-controls') + '"]');
		};

		// LE BOUTON QUI COMMANDE UN PANNEAU, retrouve par aria-controls.
		//
		// On ne peut plus le chercher avec previousElementSibling : depuis le
		// 1er aout, une entree parente qui a sa propre page sort un
		// <span class="nav__paire"> contenant le lien ET le bouton. Le frere
		// qui precede le panneau est donc ce span, pas le bouton.
		//
		// aria-controls dit deja qui commande quoi. On le lit, plutot que de
		// deduire d'une position dans le document — qui rebougera.
		var commandeDe = function (panneau) {
			return nav.querySelector('[aria-controls="' + panneau.id + '"]');
		};

		// Le niveau se deduit du DOM, il n'est jamais ecrit en dur.
		var niveau = function (b) {
			return b.closest('.nav__sous') ? 2 : 1;
		};

		// Fermer un declencheur ferme aussi, recursivement, tout ce qu'il contient.
		var fermer = function (b) {
			b.setAttribute('aria-expanded', 'false');

			var sous = panneauDe(b);
			if (sous) {
				Array.prototype.forEach.call(sous.querySelectorAll('[aria-expanded="true"]'), fermer);
			}
		};

		// Les freres et les oncles se referment ; les ANCETRES restent ouverts.
		// Sans cette exception, ouvrir le troisieme niveau refermait le
		// deuxieme et faisait disparaitre le premier.
		//
		// ...ET LES COMMANDES D'UN MEME PANNEAU MEGA COHABITENT — 12 aout 2026.
		//
		// Dans un sous-menu ordinaire, deux panneaux ouverts se recouvriraient :
		// l'exclusion est donc juste. Dans un mega, les colonnes sont cote a
		// cote et ne se disputent aucune place. Sans l'exception ci-dessous,
		// ouvrir « Petite Enfance » refermait « Ordures menageres », qui est
		// dans une AUTRE colonne, sans rapport et sans gene. Et sur telephone,
		// deplier une rubrique repliait la precedente.
		//
		// Ce qui reste exclusif : les panneaux de PREMIER niveau entre eux —
		// deux mega ouverts en meme temps se recouvriraient, eux.
		var fermerLesAutres = function (b) {
			var mega = b.closest ? b.closest('.nav__mega') : null;

			declencheurs.forEach(function (autre) {
				if (autre === b || autre.getAttribute('aria-expanded') !== 'true') {
					return;
				}

				var sous = panneauDe(autre);
				if (sous && sous.contains(b)) {
					return;
				}

				if (mega && mega.contains(autre)) {
					return;
				}

				fermer(autre);
			});
		};

		var ouvrirEtEntrer = function (b) {
			fermerLesAutres(b);
			b.setAttribute('aria-expanded', 'true');

			var sous = panneauDe(b);
			var premier = sous && sous.querySelector('a, button');
			if (premier) {
				premier.focus();
			}
		};

		declencheurs.forEach(function (b) {
			b.addEventListener('click', function () {
				if (b.getAttribute('aria-expanded') === 'true') {
					fermer(b);
				} else {
					fermerLesAutres(b);
					b.setAttribute('aria-expanded', 'true');
				}
			});

			b.addEventListener('keydown', function (e) {
				// Niveau 1 : le panneau tombe vers le bas. Plus bas : il sort a
				// droite, parce qu'un panneau sous un sous-menu deja deroule
				// quitterait l'ecran.
				var ouvrant = niveau(b) === 1 ? 'ArrowDown' : 'ArrowRight';

				if (e.key === ouvrant) {
					e.preventDefault();
					ouvrirEtEntrer(b);
				}
			});
		});

		// Deplacement dans un panneau : haut, bas, retour au parent par la gauche.
		nav.addEventListener('keydown', function (e) {
			var sous = e.target.closest && e.target.closest('.nav__sous');
			if (!sous) {
				return;
			}

			// Une entree du panneau peut etre un lien seul, un bouton seul, ou
			// une paire lien + chevron. On prend le PREMIER element focalisable
			// de chaque entree : c'est le lien quand il existe, et c'est lui
			// qu'on veut atteindre a la fleche.
			var items = Array.prototype.slice.call(sous.children).map(function (li) {
				return li.querySelector(':scope > a, :scope > button, :scope > .nav__paire > a');
			}).filter(Boolean);

			var i = items.indexOf(document.activeElement);
			if (i === -1) {
				return;
			}

			if (e.key === 'ArrowDown') {
				e.preventDefault();
				items[(i + 1) % items.length].focus();
			} else if (e.key === 'ArrowUp') {
				e.preventDefault();
				items[(i - 1 + items.length) % items.length].focus();
			} else if (e.key === 'ArrowLeft') {
				var parent = commandeDe(sous);

				if (parent) {
					e.preventDefault();
					fermer(parent);
					parent.focus();
				}
			} else if (e.key === 'Tab' && !e.shiftKey && i === items.length - 1) {
				var b = commandeDe(sous);

				if (b) {
					fermer(b);
				}
			}
		});

		/*
		 * LE PANNEAU MEGA SE REFERME QUAND LE FOCUS EN SORT — 12 aout 2026.
		 *
		 * Releve au banc : depuis la derniere entree du panneau, une tabulation
		 * emmenait le focus sur l'entree suivante de la barre... et le panneau
		 * restait ouvert, en grand, par-dessus le contenu de la page. Rien ne le
		 * refermait : le clic au-dehors n'a pas lieu, et Echap suppose qu'on
		 * sache qu'il y a quelque chose a fermer.
		 *
		 * Un sous-menu ordinaire, lui, a deja son traitement quelques lignes
		 * plus haut, sur la derniere entree. ON NE LE TOUCHE PAS : cette
		 * mecanique ne s'attache qu'aux panneaux mega, pour ne rien changer a
		 * ce qui marche.
		 *
		 * `relatedTarget` nul veut dire que le focus a quitte la fenetre —
		 * l'usager n'est pas alle ailleurs dans la page, on ne referme rien.
		 */
		Array.prototype.forEach.call(nav.querySelectorAll('.nav__mega'), function (mega) {
			mega.addEventListener('focusout', function (e) {
				var vers = e.relatedTarget;

				if (!vers) {
					return;
				}

				var b = commandeDe(mega);

				if (!b || mega.contains(vers) || vers === b || b.contains(vers)) {
					return;
				}

				fermer(b);
			});
		});

		// Un clic hors de CE menu referme ses sous-menus. On teste l'appartenance
		// au conteneur, pas la classe `.navigation` : sinon un clic dans le menu
		// de la colonne refermerait le menu de la colonne.
		document.addEventListener('click', function (e) {
			if (nav.contains(e.target)) {
				return;
			}

			Array.prototype.forEach.call(nav.querySelectorAll('[aria-expanded="true"]'), fermer);
		});

		// Echap : le panneau d'affichage d'abord, sinon le sous-menu LE PLUS
		// PROFOND, un cran a la fois.
		document.addEventListener('keydown', function (e) {
			if (e.key !== 'Escape') {
				return;
			}

			if (panneau && !panneau.hidden) {
				fermerPanneau();
				return;
			}

			var ouverts = nav.querySelectorAll('[aria-expanded="true"]');
			var dernier = ouverts[ouverts.length - 1];

			if (dernier) {
				fermer(dernier);
				dernier.focus();
			}
		});
	});

	// ---- Onglets — <joomla-tab> et les groupes marques [data-onglets] ------

	Array.prototype.forEach.call(document.querySelectorAll('[data-onglets]'), function (groupe) {
		var boutons = Array.prototype.slice.call(groupe.querySelectorAll('.onglets__bouton'));

		boutons.forEach(function (b, i) {
			b.addEventListener('click', function () {
				boutons.forEach(function (autre) {
					var actif = autre === b;
					autre.setAttribute('aria-selected', String(actif));
					autre.tabIndex = actif ? 0 : -1;

					var volet = document.getElementById(autre.getAttribute('aria-controls'));
					if (volet) {
						volet.hidden = !actif;
					}
				});
			});

			b.addEventListener('keydown', function (e) {
				var j = e.key === 'ArrowRight' ? i + 1 : (e.key === 'ArrowLeft' ? i - 1 : -1);
				if (j === -1) {
					return;
				}

				e.preventDefault();
				var cible = boutons[(j + boutons.length) % boutons.length];
				cible.focus();
				cible.click();
			});
		});
	});

	// ---- Accordeon — com_content/categories --------------------------------

	Array.prototype.forEach.call(document.querySelectorAll('.accordeon__bouton'), function (b) {
		b.addEventListener('click', function () {
			var ouvert = b.getAttribute('aria-expanded') === 'true';
			b.setAttribute('aria-expanded', String(!ouvert));

			var volet = document.getElementById(b.getAttribute('aria-controls'));
			if (volet) {
				volet.hidden = ouvert;
			}
		});
	});

	// ---- Les outils sous l'article -----------------------------------------
	//
	// Imprimer et Partager sont ECRITS PAR LE SCRIPT, et c'est voulu : sans
	// JavaScript ils n'existent pas du tout, plutot que d'exister sans rien
	// faire. Un bouton mort promet une action qu'il ne rend pas. Le lien
	// courriel, lui, est dans le document : un mailto: n'a besoin de personne.
	//
	// Les libelles viennent du document, jamais d'une chaine ecrite ici : le
	// JavaScript ne doit pas porter de texte a traduire.

	Array.prototype.forEach.call(document.querySelectorAll('[data-corpus-outils]'), function (zone) {

		var fabriquer = function (picto, libelle, action) {
			var b = document.createElement('button');
			b.type = 'button';
			b.className = 'bouton bouton--petit bouton--second';
			b.innerHTML = '<svg class="i--sm" aria-hidden="true" focusable="false">'
				+ '<use href="#' + picto + '" /></svg>';
			b.appendChild(document.createTextNode(' ' + libelle));
			b.addEventListener('click', action);
			return b;
		};

		// Partager. navigator.share n'existe que sur les navigateurs qui ont un
		// partage systeme — surtout mobiles. Ailleurs on bascule sur la copie
		// du lien, qui rend le meme service sans traceur ni script tiers.
		var libPartager = zone.getAttribute('data-partager');
		var libCopier   = zone.getAttribute('data-copier');
		var libCopie    = zone.getAttribute('data-copie');

		if (libPartager && navigator.share) {
			zone.insertBefore(fabriquer('i-partage', libPartager, function () {
				navigator.share({
					title: document.title,
					url: location.href
				}).catch(function () { /* partage annule : rien a signaler */ });
			}), zone.firstChild);

		} else if (libCopier && navigator.clipboard) {
			zone.insertBefore(fabriquer('i-lien', libCopier, function () {
				var b = this;

				navigator.clipboard.writeText(location.href).then(function () {
					// La confirmation est ECRITE, pas seulement coloree, et elle
					// est annoncee : le bloc porte aria-live plus bas.
					var avant = b.lastChild.nodeValue;
					b.lastChild.nodeValue = ' ' + (libCopie || avant);
					setTimeout(function () { b.lastChild.nodeValue = avant; }, 2500);
				});
			}), zone.firstChild);
		}

		// Imprimer.
		var libImprimer = zone.getAttribute('data-imprimer');

		if (libImprimer) {
			zone.insertBefore(fabriquer('i-imprimer', libImprimer, function () {
				window.print();
			}), zone.firstChild);
		}
	});

	// ---- Une seule voix pour dire qu'un champ est vide ----------------------
	//
	// DEFAUT MESURE LE 3 AOUT 2026 sur le formulaire de contact. Deux
	// validateurs parlaient en meme temps : celui de Joomla, qui ecrit son
	// message sous le libelle, et CELUI DU NAVIGATEUR, qui affiche sa propre
	// bulle. Deux dessins pour la meme erreur, et le premier champ n'avait
	// jamais le notre — la validation native s'arrete au premier champ fautif
	// et bloque la suite.
	//
	// Verifie dans les sources : ni le gabarit de contact du coeur ni
	// validate.js ne posent `novalidate`. Les champs portent `required`, donc
	// le navigateur valide d'abord. C'est le comportement de Joomla d'origine,
	// pas un defaut du portage.
	//
	// POURQUOI DEPUIS LE JAVASCRIPT ET NON DANS LE GABARIT. Poser
	// `novalidate` dans le HTML desarmerait le navigateur meme quand le
	// script de Joomla ne tourne pas — plus aucune validation avant l'envoi.
	// Pose ici, l'attribut n'apparait QUE si notre script s'execute, donc que
	// si celui de Joomla s'execute aussi. Sans JavaScript, le navigateur
	// reprend la main et rien n'est perdu.
	//
	// On ne vise que `.form-validate` : les formulaires que Joomla se charge
	// lui-meme de valider. Un formulaire tiers garde son comportement.

	Array.prototype.forEach.call(document.querySelectorAll('form.form-validate'), function (f) {
		f.setAttribute('novalidate', '');
	});

	// ---- Le nombre par page, dans une rangee de filtres --------------------
	//
	// DEFAUT RELEVE PAR CYRILLE LE 3 AOUT 2026 sur la vue « archive » : entre
	// « Mois » et « Annee », une troisieme liste n'affichait qu'un « 10 ». Les
	// deux premieres portent leur nom dans leur option de tete ; celle-ci
	// montre sa valeur. A l'ecran, rien ne dit ce qu'elle regle.
	//
	// Le libelle EXISTE — le coeur l'ecrit avec le bon `for` — mais en
	// `visually-hidden`. Un lecteur d'ecran l'annonce, un oeil ne le voit pas.
	//
	// POURQUOI ICI ET NON DANS UNE SURCHARGE. Reveler la classe en CSS
	// demanderait un `!important`, puisque `.visually-hidden` en porte un.
	// Surcharger le gabarit ferait entrer 2,5 ko de mise en page du coeur dans
	// le template, a maintenir a chaque version de Joomla — le projet a deja
	// refuse ce marche pour com_contact. Retirer une classe est ce que la
	// surcharge ferait, sans la dette.
	//
	// Sans JavaScript, le libelle reste masque : la page demeure utilisable et
	// accessible, elle perd seulement une precision visuelle. C'est une
	// degradation acceptable ; l'inverse — un libelle qui n'existe que dans le
	// script — ne le serait pas.

	Array.prototype.forEach.call(
		document.querySelectorAll('.form-inline label[for="limit"].visually-hidden'),
		function (l) {
			l.classList.remove('visually-hidden');
			l.classList.add('mention-filtre');

			// La chaine du coeur finit par un croisillon — « Afficher # »,
			// « Display # ». C'etait une convention typographique pour « nombre
			// de », et elle ne se lit plus. Il ne disparait qu'a l'affichage,
			// la traduction n'est pas touchee.
			l.textContent = l.textContent.replace(/\s*#\s*$/, '');
		}
	);

	// ---- Fermeture des messages systeme ------------------------------------
	//
	// PAR DELEGATION, et non un ecouteur par bouton. Les messages fabriques
	// apres le chargement — voir plus bas — n'existaient pas quand la page
	// s'est chargee : un ecouteur pose bouton par bouton les aurait manques.

	document.addEventListener('click', function (e) {
		var b = e.target.closest ? e.target.closest('.message__fermer') : null;

		if (b) {
			b.closest('.message').remove();
		}
	});

	// ---- Les messages fabriques en JavaScript ------------------------------
	//
	// LE PROBLEME, mesure le 3 aout 2026. Tout message ajoute APRES le
	// chargement — l'echec de validation d'un formulaire, une reponse en
	// Ajax — ne passe pas par notre gabarit PHP. Il est construit par
	// Joomla.renderMessages, qui sort un <joomla-alert> :
	//
	//   <joomla-alert type="danger">
	//     <div class="alert-heading">
	//       <span class="danger"></span>                 <- icone de fonte
	//       <span class="visually-hidden">Erreur</span>  <- intitule MASQUE
	//
	// Deux defauts, et le second est grave. L'habillage vient de Bootstrap,
	// donc le message ne ressemble a rien d'autre sur la page. Et surtout
	// L'INTITULE EST MASQUE tandis que le pictogramme attend une fonte que
	// Corpus ne charge pas : a l'ecran, il ne reste que le texte du message.
	// Seule la couleur dit si c'est un succes ou une erreur — exactement ce
	// que WCAG 1.4.1 interdit, et exactement ce que notre gabarit PHP prend
	// soin d'eviter en ecrivant toujours le mot.
	//
	// POURQUOI REMPLACER LA FONCTION PLUTOT QUE D'HABILLER LE COMPOSANT.
	// Rendre l'intitule visible demanderait de battre `.visually-hidden`, qui
	// est en `!important` — donc d'empiler un `!important` de plus. On corrige
	// a la source : Joomla expose cette fonction, on la remplace, et le motif
	// devient le meme des deux cotes. Le gabarit PHP reste la reference ; ce
	// qui suit en est la traduction, a l'identique.
	//
	// La signature est celle du coeur : (messages, selecteur, garder, delai).

	if (window.Joomla) {
		var familles = {
			message: ['succes', 'i-succes', 'TPL_CORPUS_MSG_SUCCES'],
			success: ['succes', 'i-succes', 'TPL_CORPUS_MSG_SUCCES'],
			notice:  ['info',   'i-info',   'TPL_CORPUS_MSG_INFO'],
			info:    ['info',   'i-info',   'TPL_CORPUS_MSG_INFO'],
			warning: ['alerte', 'i-alerte', 'TPL_CORPUS_MSG_ALERTE'],
			error:   ['erreur', 'i-erreur', 'TPL_CORPUS_MSG_ERREUR'],
			danger:  ['erreur', 'i-erreur', 'TPL_CORPUS_MSG_ERREUR']
		};

		var conteneurMessages = function (selecteur) {
			return document.querySelector(selecteur || '#system-message-container');
		};

		Joomla.removeMessages = function (conteneur) {
			var c = conteneur || conteneurMessages();

			if (c) {
				c.innerHTML = '';
			}
		};

		Joomla.renderMessages = function (messages, selecteur, garder, delai) {
			var c = conteneurMessages(selecteur);

			if (!c) {
				return;
			}

			if (garder !== true) {
				Joomla.removeMessages(c);
			}

			Object.keys(messages).forEach(function (type) {
				var f = familles[String(type).toLowerCase()] || familles.info;

				var bloc = document.createElement('div');
				bloc.className = 'message message--' + f[0] + ' filet';

				// Meme regle que le gabarit PHP : role="alert" pour ce qui
				// interrompt, role="status" pour le reste. Un succes ne doit
				// pas couper la lecture d'un lecteur d'ecran.
				bloc.setAttribute('role', f[0] === 'erreur' || f[0] === 'alerte' ? 'alert' : 'status');

				var corps = '<svg class="i" aria-hidden="true" focusable="false">'
					+ '<use href="#' + f[1] + '" /></svg><div>'
					+ '<p class="message__titre">' + Joomla.Text._(f[2], f[2]) + '</p>';

				messages[type].forEach(function (m) {
					corps += '<p>' + Joomla.sanitizeHtml(m) + '</p>';
				});

				corps += '</div><button type="button" class="message__fermer" aria-label="'
					+ Joomla.Text._('TPL_CORPUS_MSG_FERMER', 'TPL_CORPUS_MSG_FERMER')
					+ '"><svg class="i" aria-hidden="true" focusable="false">'
					+ '<use href="#i-fermer" /></svg></button>';

				bloc.innerHTML = corps;
				c.appendChild(bloc);

				if (delai && parseInt(delai, 10) > 0) {
					setTimeout(function () { bloc.remove(); }, parseInt(delai, 10));
				}
			});
		};
	}
	// =====================================================================
	// LES ZONES EPINGLEES — 3 aout 2026
	//
	// Le CSS sait epingler, il ne sait pas A QUELLE HAUTEUR. Deux mesures
	// manquent, et aucune ne s'ecrit a la main :
	//
	//   --epingle-decalage : ou une zone se pose. La navigation doit s'arreter
	//                        SOUS l'en-tete quand les deux sont epingles, et la
	//                        hauteur de l'en-tete depend du logo, de la taille
	//                        de texte choisie par l'usager et de la largeur.
	//
	//   --epingle-hauteur  : la hauteur totale epinglee, reportee en
	//                        `scroll-padding-top` sur la racine. SANS ELLE, une
	//                        ancre interne ou un element atteint au clavier se
	//                        pose sous la barre : le focus existe et ne se voit
	//                        pas. C'est un defaut d'accessibilite, pas un defaut
	//                        d'aspect.
	//
	// ON MESURE, ON NE CALCULE PAS. `getBoundingClientRect` rend la hauteur
	// reellement peinte, bordure comprise ; une addition de valeurs lues dans la
	// feuille se tromperait des qu'un module s'ajoute dans l'en-tete.
	//
	// ResizeObserver plutot qu'un evenement `resize` : la hauteur change aussi
	// sans que la fenetre bouge — un menu qui passe sur deux lignes, une image
	// de logo qui arrive en retard, un changement de taille de texte.
	// =====================================================================

	(function () {
		var zones = [
			document.querySelector('.entete--epingle'),
			document.querySelector('.navigation--epinglee')
		].filter(Boolean);

		if (!zones.length) {
			return;
		}

		var mesurer = function () {
			// Une zone decrochee par la requete media des fenetres basses ne
			// compte plus : on lit sa position calculee plutot que de dupliquer
			// le seuil ici. Deux endroits qui decident du meme seuil finissent
			// toujours par diverger.
			var cumul = 0;

			zones.forEach(function (zone) {
				if (getComputedStyle(zone).position !== 'sticky') {
					zone.style.removeProperty('--epingle-decalage');
					return;
				}

				zone.style.setProperty('--epingle-decalage', cumul + 'px');
				cumul += zone.getBoundingClientRect().height;
			});

			document.documentElement.style.setProperty('--epingle-hauteur', cumul + 'px');
			document.documentElement.style.scrollPaddingTop = cumul + 'px';
		};

		mesurer();

		if (window.ResizeObserver) {
			var observateur = new ResizeObserver(mesurer);
			zones.forEach(function (zone) { observateur.observe(zone); });
		}

		window.addEventListener('resize', mesurer);
	})();

	// =====================================================================
	// LE RETOUR EN HAUT — 4 aout 2026.
	//
	// Le lien existe dans le document ; ce bloc ne fait qu'une chose, decider
	// QUAND il se voit. Un controle « remonter » affiche alors qu'on est deja
	// en haut ne fait rien, et un controle qui ne fait rien est un controle de
	// trop.
	//
	// `hidden` PLUTOT QU'UNE CLASSE : l'attribut retire l'element de l'arbre
	// d'accessibilite en meme temps que de l'ecran. Une simple classe qui
	// masque a l'oeil laisserait un lien tabulable invisible — le pire des
	// deux mondes.
	//
	// Le defilement doux n'est PAS ici : il vient de `scroll-behavior: smooth`
	// en CSS, annule par la requete `prefers-reduced-motion`. Le reprogrammer
	// en JavaScript obligerait a redetecter cette preference a la main.
	// =====================================================================
	(function () {
		var lien = document.querySelector('.retour-haut');

		if (!lien) {
			return;
		}

		// 300 PIXELS, PAS UN ECRAN. Premier reglage le 4 aout : un ecran
		// entier. Cyrille n'a jamais vu le bouton, et pour cause — mesure sur
		// la page d'accueil, document 1963 px, fenetre 1137 px : le defilement
		// maximal etait de 826 px, sous le seuil. Le bouton ne pouvait
		// apparaitre sur AUCUNE page courte.
		//
		// 300 px, c'est le moment ou l'en-tete a disparu de l'ecran : a partir
		// de la, remonter n'est plus un geste de rien.
		var seuil = function () { return 300; };
		var visible = false;

		var basculer = function () {
			var doitVoir = window.scrollY > seuil();

			if (doitVoir !== visible) {
				visible = doitVoir;
				lien.hidden = !doitVoir;
			}
		};

		// Le defilement declenche beaucoup d'evenements ; on ne travaille
		// qu'une fois par image affichee.
		var enAttente = false;
		var auDefilement = function () {
			if (enAttente) {
				return;
			}

			enAttente = true;
			window.requestAnimationFrame(function () {
				enAttente = false;
				basculer();
			});
		};

		basculer();
		window.addEventListener('scroll', auDefilement, { passive: true });
		window.addEventListener('resize', auDefilement);
	})();

	// =====================================================================
	// LA NAVIGATION D'ANCRES — pages d'atterrissage. 4 aout 2026.
	//
	// Objectif de Cyrille : monter des landing pages avec Corpus. JA Simpli le
	// fait avec huit positions dediees, `lp-top-1` a `lp-bot-4`. On ne les
	// copie pas : Corpus a DEJA ses bandes de modules, et le constructeur de
	// layout donne DEJA un identifiant a chacune. Ajouter huit positions
	// paralleles, ce serait deux jeux de zones a expliquer et a maintenir pour
	// le meme resultat.
	//
	// LE DECLENCHEUR EST LA CLASSE DE PAGE `landing`, posee sur l'element de
	// menu (onglet Affichage de la page). Rien a activer dans le template :
	// une page d'atterrissage se decide page par page, pas site par site.
	//
	// CE QUI EST LU : toute section portant un `id` ET un titre. Le titre
	// devient l'intitule du lien — c'est ce qui fait qu'un lecteur d'ecran
	// annonce « Nos missions », et non « lien, point ». Une section sans titre
	// est ignoree : on ne fabrique pas un nom a partir de rien.
	//
	// POURQUOI IntersectionObserver ET PAS UN CALCUL AU DEFILEMENT : le
	// navigateur fait le travail hors du fil principal, et il n'y a rien a
	// recalculer quand la page grandit. Sans lui, on ne fait rien — la page
	// reste parfaitement utilisable, elle n'a simplement pas de raccourcis.
	// =====================================================================
	(function () {
		if (!document.body.classList.contains('landing')) {
			return;
		}

		if (!window.IntersectionObserver) {
			return;
		}

		var sections = [].slice.call(document.querySelectorAll('.section[id], section[id]'))
			.filter(function (section) {
				return section.querySelector('h1, h2, h3');
			});

		if (sections.length < 2) {
			return;
		}

		var nav = document.createElement('nav');
		nav.className = 'ancres';
		nav.setAttribute('aria-label', document.body.dataset.corpusAncres || 'Sections de la page');

		var liste = document.createElement('ol');
		var liens = {};

		sections.forEach(function (section) {
			var titre = section.querySelector('h1, h2, h3').textContent.trim();
			var item  = document.createElement('li');
			var lien  = document.createElement('a');

			lien.href = '#' + section.id;
			lien.className = 'ancres__lien';

			// LE POINT EST DECORATIF, LE NOM EST DU TEXTE. Un lien dont
			// l'intitule serait vide est annonce par son adresse — « diese top
			// a » — ce qui ne dit rien a personne.
			var point = document.createElement('span');
			point.className = 'ancres__point';
			point.setAttribute('aria-hidden', 'true');

			var nom = document.createElement('span');
			nom.className = 'ancres__nom';
			nom.textContent = titre;

			// LE NOM AVANT LE POINT — 4 aout 2026, Cyrille a vu l'etiquette
			// sortir de l'ecran par la droite. Le point est colle au bord ; le
			// nom deplie a sa droite n'avait nulle part ou aller.
			//
			// Il se deplie donc vers la GAUCHE, du cote ou il y a de la place.
			// Et l'ordre du document y gagne : un lecteur d'ecran rencontre
			// l'intitule d'abord, le point etant `aria-hidden`.
			lien.appendChild(nom);
			lien.appendChild(point);
			item.appendChild(lien);
			liste.appendChild(item);

			liens[section.id] = lien;

			// La cible du saut doit pouvoir recevoir le focus, sinon suivre
			// l'ancre deplace la vue sans deplacer le clavier.
			if (!section.hasAttribute('tabindex')) {
				section.setAttribute('tabindex', '-1');
			}
		});

		nav.appendChild(liste);
		document.body.appendChild(nav);

		// La section courante est celle dont la plus grande part est visible.
		// `aria-current` la dit ; la classe la dessine.
		var observateur = new IntersectionObserver(function (entrees) {
			entrees.forEach(function (entree) {
				var lien = liens[entree.target.id];

				if (!lien) {
					return;
				}

				if (entree.isIntersecting) {
					Object.keys(liens).forEach(function (id) {
						liens[id].removeAttribute('aria-current');
						liens[id].classList.remove('ancres__lien--courant');
					});

					// `location`, PAS `true`. `aria-current="true"` dit « c'est
					// l'element courant » sans dire de quoi ; `location` dit
					// precisement « vous etes ici dans la page ». C'est la
					// valeur que porte deja notre menu vertical, et deux
					// conventions differentes pour la meme idee, c'est une de
					// trop.
					lien.setAttribute('aria-current', 'location');
					lien.classList.add('ancres__lien--courant');
				}
			});
		}, { rootMargin: '-45% 0px -45% 0px' });

		sections.forEach(function (section) { observateur.observe(section); });
	})();

	// =====================================================================
	// LE BANDEAU DE CONSENTEMENT NE VOLE PAS LE FOCUS — 6 aout 2026
	//
	// Releve par Cyrille : « peux-tu supprimer l'encadrement du lien politique
	// de confidentialite ? » Ce n'etait pas un encadrement decoratif, c'etait
	// L'ANNEAU DE FOCUS. Mesure : au chargement, sans que personne n'ait rien
	// touche, `document.activeElement` etait deja le lien du bandeau.
	//
	// Orejime pose le focus sur le premier element focalisable de son bandeau
	// des qu'il l'affiche. C'est ecrit en dur dans son JS, aucune option ne le
	// desactive.
	//
	// ON NE SUPPRIME PAS L'ANNEAU : un indicateur de focus invisible est un
	// defaut d'accessibilite, et c'est l'inverse de ce que Corpus fait partout.
	// On retire la CAUSE — le focus vole — et l'anneau disparait de lui-meme.
	//
	// Et c'est un gain, pas un compromis : un bandeau non bloquant qui prend
	// le focus ejecte le lecteur du debut de la page et projette un lecteur
	// d'ecran en bas du document sans qu'il l'ait demande. Le bandeau reste
	// dans l'ordre de tabulation, on l'atteint normalement.
	//
	// UNE SEULE FOIS, AU CHARGEMENT. Quand l'usager ouvre lui-meme le panneau
	// par le bouton du pied, le focus DOIT y aller — c'est lui qui l'a
	// demande. On ne desarme donc que la prise automatique du depart.
	// =====================================================================
	(function () {
		var rendu = false;

		var rendreLeFocus = function () {
			if (rendu) {
				return;
			}

			rendu = true;

			var actif = document.activeElement;

			if (actif && actif.closest && actif.closest('.orejime-Env')) {
				actif.blur();
			}
		};

		// Deux rendez-vous : la fin du chargement, et la seconde qui suit —
		// le bandeau d'Orejime est monte apres `load`, et une correction posee
		// avant la cause ne corrige rien.
		window.addEventListener('load', function () {
			window.setTimeout(rendreLeFocus, 50);
			window.setTimeout(rendreLeFocus, 600);
		});
	})();

	// =====================================================================
	// LE RETRAIT DU CONSENTEMENT — 6 aout 2026
	//
	// Le bouton est ecrit dans index.php, pas ajoute ici : un moyen de
	// retrait qui dependrait du chargement d'un fichier tiers disparaitrait
	// le jour ou ce fichier manque, et l'obligation avec lui.
	//
	// Ce qui suit ne fait que le brancher. Si Orejime n'est pas la — fichier
	// absent, chemin faux, script bloque — le bouton se retire de lui-meme :
	// mieux vaut pas de bouton qu'un bouton qui ne repond pas. C'est la seule
	// facon honnete de traiter une dependance qu'on ne livre pas.
	// =====================================================================
	(function () {
		var boutons = document.querySelectorAll('[data-corpus-consentement]');

		if (!boutons.length) {
			return;
		}

		var brancher = function () {
			Array.prototype.forEach.call(boutons, function (bouton) {
				bouton.addEventListener('click', function () {
					window.orejime.prompt();
				});
			});
		};

		var retirer = function () {
			Array.prototype.forEach.call(boutons, function (bouton) {
				bouton.hidden = true;
			});
		};

		// Le script d'Orejime porte `defer` : il s'execute apres celui-ci.
		// On attend donc la fin du chargement, puis on laisse deux essais —
		// une instrumentation posee avant la cause ne mesure rien.
		var essais = 0;
		var attendre = function () {
			if (window.orejime && typeof window.orejime.prompt === 'function') {
				brancher();
				return;
			}

			essais += 1;

			if (essais > 20) {
				retirer();
				return;
			}

			window.setTimeout(attendre, 100);
		};

		window.addEventListener('load', attendre);
	})();

	/* ====================================================================
	   LE REPLI DE LA RECHERCHE — 12 aout 2026

	   Le meme motif de divulgation que le menu, et pour la meme raison : le
	   bouton sort `hidden` du gabarit et n'est revele qu'ici. Sans script, le
	   bouton n'apparait jamais et le champ reste deplie — un champ deplie se
	   remplit, un bouton mort ne fait rien.

	   Le volet n'est pas masque en JavaScript : c'est la feuille qui le cache,
	   et seulement lorsque le bouton est revele. Une seule source de verite.
	   ==================================================================== */
	(function () {
		var replis = document.querySelectorAll('.recherche-repli');

		if (!replis.length) {
			return;
		}

		Array.prototype.forEach.call(replis, function (repli) {
			var bouton = repli.querySelector('.recherche-repli__bouton');
			var volet  = repli.querySelector('.recherche-repli__volet');

			if (!bouton || !volet) {
				return;
			}

			bouton.hidden = false;

			var poser = function (ouvert) {
				bouton.setAttribute('aria-expanded', ouvert ? 'true' : 'false');

				if (!ouvert) {
					return;
				}

				// Le focus entre dans le champ : ouvrir un volet pour laisser
				// l'usager le chercher au clavier ne sert a rien.
				var champ = volet.querySelector('input');

				if (champ) {
					champ.focus();
				}
			};

			bouton.addEventListener('click', function () {
				poser(bouton.getAttribute('aria-expanded') !== 'true');
			});

			// Echap referme et REND LE FOCUS au bouton : sinon il reste sur un
			// champ qui vient de disparaitre, et le clavier repart du debut.
			repli.addEventListener('keydown', function (e) {
				if (e.key !== 'Escape' || bouton.getAttribute('aria-expanded') !== 'true') {
					return;
				}

				poser(false);
				bouton.focus();
			});

			// Un clic ailleurs referme. Le focus n'est PAS deplace dans ce cas :
			// l'usager est deja parti ailleurs, le lui reprendre serait pire.
			document.addEventListener('click', function (e) {
				if (bouton.getAttribute('aria-expanded') !== 'true' || repli.contains(e.target)) {
					return;
				}

				bouton.setAttribute('aria-expanded', 'false');
			});
		});
	})();

})();
