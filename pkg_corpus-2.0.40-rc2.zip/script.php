<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

/**
 * LE SCRIPT DU PAQUET
 *
 * Il fait UNE chose apres l'installation : activer le plugin.
 *
 * Sans cela, l'installation reussit, le template s'affiche, et le champ
 * « Gabarit d'article » n'apparait nulle part dans les categories. Personne ne
 * fait le rapprochement avec un plugin desactive : on cherche la panne dans le
 * template. Une extension qui a besoin d'etre activee pour fonctionner
 * s'active elle-meme, ou elle n'aurait pas du etre livree ensemble.
 */
return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            InstallerScriptInterface::class,
            new class () implements InstallerScriptInterface {
                public function install(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function update(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function uninstall(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function preflight(string $type, InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function postflight(string $type, InstallerAdapter $adapter): bool
                {
                    if ($type === 'uninstall') {
                        return true;
                    }

                    $db    = Factory::getContainer()->get(DatabaseInterface::class);
                    $query = $db->getQuery(true)
                        ->update($db->quoteName('#__extensions'))
                        ->set($db->quoteName('enabled') . ' = 1')
                        ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                        ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
                        ->where($db->quoteName('element') . ' = ' . $db->quote('corpus'));

                    try {
                        $db->setQuery($query)->execute();
                    } catch (\Throwable $e) {
                        // On ne fait pas echouer une installation reussie pour
                        // ca : on le dit, et l'administrateur active a la main.
                        Factory::getApplication()->enqueueMessage(
                            Text::_('PKG_CORPUS_PLUGIN_NON_ACTIVE'),
                            'warning'
                        );
                    }

                    return true;
                }
            }
        );
    }
};
