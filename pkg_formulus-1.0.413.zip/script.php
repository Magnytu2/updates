<?php

/**
 * @package     Formulus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Mail\MailTemplate;
use Joomla\CMS\Table\Asset;
use Joomla\Database\DatabaseInterface;

/**
 * Le script du paquet.
 *
 * Avant : refuse un Joomla ou un PHP trop anciens (ListView et FormView
 * arrivent avec Joomla 6.0). Apres : met en place ce que Joomla ne fait pas
 * seul, et le DIT a chaque fois, jamais en silence.
 */
return new class () implements InstallerScriptInterface {
    private string $joomlaMinimum = '6.0.0';

    private string $phpMinimum = '8.3.0';

    /**
     * Les plugins du paquet (groupe => cle du message d'activation).
     */
    private const PLUGINS = [
        'fields'  => 'PKG_FORMULUS_PLUGIN_ACTIVE',
        'task'    => 'PKG_FORMULUS_PLUGIN_TACHE_ACTIVE',
        'privacy' => 'PKG_FORMULUS_PLUGIN_PRIVACY_ACTIVE',
    ];

    /**
     * Les deux modeles de mails et leurs balises. Sujet et corps sont des
     * CLES DE LANGUE : Joomla les traduit a l'envoi dans la langue du site ;
     * un administrateur qui les modifie dans com_mails les remplace par son
     * propre texte, pour une langue donnee.
     */
    private const MODELES = [
        'com_formulus.notification' => ['formulaire', 'nom', 'email', 'tous_les_champs', 'lien_reponse', 'date', 'sitename'],
        'com_formulus.accuse'       => ['formulaire', 'nom', 'email', 'tous_les_champs', 'date', 'sitename'],
    ];

    /**
     * Les plugins deja installes AVANT cette installation, lus au preflight,
     * avant que le paquet n'installe ses extensions.
     */
    private array $existaient = [];

    public function preflight(string $type, InstallerAdapter $adapter): bool
    {
        if ($type === 'uninstall') {
            return true;
        }

        // Les messages sont dans la langue du paquet, pas encore installee a
        // ce stade : on la lit dans l'archive.
        Factory::getLanguage()->load('pkg_formulus.sys', $adapter->getParent()->getPath('source'));

        foreach (array_keys(self::PLUGINS) as $groupe) {
            $this->existaient[$groupe] = $this->idPlugin($groupe) > 0;
        }

        if (version_compare(JVERSION, $this->joomlaMinimum, '<')) {
            Factory::getApplication()->enqueueMessage(Text::sprintf('PKG_FORMULUS_JOOMLA_TROP_ANCIEN', $this->joomlaMinimum), 'error');

            return false;
        }

        if (version_compare(PHP_VERSION, $this->phpMinimum, '<')) {
            Factory::getApplication()->enqueueMessage(Text::sprintf('PKG_FORMULUS_PHP_TROP_ANCIEN', $this->phpMinimum), 'error');

            return false;
        }

        return true;
    }

    public function install(InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function update(InstallerAdapter $adapter): bool
    {
        return true;
    }

    /**
     * Ce que l'installateur ne retire pas avec les extensions : les modeles
     * de mails (com_mails), la tache planifiee, la ligne du journal.
     */
    public function uninstall(InstallerAdapter $adapter): bool
    {
        foreach (array_keys(self::MODELES) as $modele) {
            MailTemplate::deleteTemplate($modele);
        }

        $db = $this->db();
        $db->setQuery($db->createQuery()->delete($db->quoteName('#__scheduler_tasks'))->where($db->quoteName('type') . ' = ' . $db->quote('formulus.purge')))->execute();
        $db->setQuery($db->createQuery()->delete($db->quoteName('#__action_logs_extensions'))->where($db->quoteName('extension') . ' = ' . $db->quote('com_formulus')))->execute();

        return true;
    }

    public function postflight(string $type, InstallerAdapter $adapter): bool
    {
        if ($type !== 'install' && $type !== 'update') {
            return true;
        }

        $this->activerPlugins();

        if ($type === 'install') {
            $this->activerCaptchaNatif();
        }

        $this->creerModelesDeMails();
        $this->creerTachePurge();
        $this->declarerAuJournal();
        $this->donnerDroitPublic();

        return true;
    }

    /**
     * Joomla installe un plugin DESACTIVE. On active chaque plugin de Formulus
     * a sa PREMIERE arrivee seulement : un administrateur qui l'a desactive
     * ensuite garde son choix.
     */
    private function activerPlugins(): void
    {
        $db = $this->db();

        foreach (self::PLUGINS as $groupe => $message) {
            if (!empty($this->existaient[$groupe]) || !($id = $this->idPlugin($groupe))) {
                continue;
            }

            $db->setQuery(
                $db->createQuery()
                    ->update($db->quoteName('#__extensions'))
                    ->set($db->quoteName('enabled') . ' = 1')
                    ->where($db->quoteName('extension_id') . ' = ' . (int) $id)
            )->execute();

            Factory::getApplication()->enqueueMessage(Text::_($message), 'info');
        }
    }

    /**
     * Les modeles de mails, s'ils n'existent pas encore. Un modele deja la,
     * peut-etre modifie par l'administrateur, n'est pas touche.
     */
    /**
     * LE CAPTCHA NATIF DE JOOMLA 6, active a la premiere installation.
     *
     * Demande de Cyrille : chaque modele pose un CAPTCHA, et il faut qu'il
     * existe. Joomla 6 n'embarque plus reCAPTCHA ; son CAPTCHA natif est
     * « Captcha - Proof of Work » (powcaptcha) : ni cle, ni service tiers, ni
     * cookie, donc rien a declarer au titre du RGPD. Installe desactive, il
     * est active ici UNE fois ; un administrateur qui le coupe ensuite garde
     * son choix, et l'ecran d'un formulaire le lui signale.
     */
    private function activerCaptchaNatif(): void
    {
        $db = $this->db();
        $db->setQuery(
            $db->createQuery()
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('enabled') . ' = 1')
                ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                ->where($db->quoteName('folder') . ' = ' . $db->quote('captcha'))
                ->where($db->quoteName('element') . ' = ' . $db->quote('powcaptcha'))
        )->execute();
    }

    private function creerModelesDeMails(): void
    {
        foreach (self::MODELES as $modele => $balises) {
            $cle = strtoupper(str_replace('com_formulus.', 'COM_FORMULUS_MAIL_', $modele));

            if (MailTemplate::getTemplate($modele, '') === null) {
                MailTemplate::createTemplate($modele, $cle . '_SUBJECT', $cle . '_BODY', $balises);
            }
        }
    }

    /**
     * LA TACHE DE PURGE (RGPD). Une duree de conservation sans tache qui
     * l'applique est un reglage qui ne fait rien : on la cree, une fois par
     * jour, sur le modele des taches que l'installation de Joomla cree
     * elle-meme (installation/sql/mysql/extensions.sql). Si l'administrateur
     * la supprime, elle ne revient pas : on ne la cree que si le plugin
     * arrive pour la premiere fois.
     */
    private function creerTachePurge(): void
    {
        if (!empty($this->existaient['task'])) {
            return;
        }

        $db = $this->db();

        $existe = (int) $db->setQuery(
            $db->createQuery()
                ->select('COUNT(*)')
                ->from($db->quoteName('#__scheduler_tasks'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('formulus.purge'))
        )->loadResult();

        if ($existe) {
            return;
        }

        $maintenant = Factory::getDate();
        $demain     = Factory::getDate('tomorrow 03:00');

        $tache = (object) [
            'asset_id'        => 0,
            'title'           => Text::_('PKG_FORMULUS_TACHE_TITRE'),
            'type'            => 'formulus.purge',
            'execution_rules' => json_encode(['rule-type' => 'interval-days', 'interval-days' => '1', 'exec-day' => '1', 'exec-time' => '03:00']),
            'cron_rules'      => json_encode(['type' => 'interval', 'exp' => 'P1D']),
            'state'           => 1,
            'next_execution'  => $demain->toSql(),
            'params'          => json_encode([
                'individual_log' => false,
                'log_file'       => '',
                'notifications'  => ['success_mail' => '0', 'failure_mail' => '1', 'fatal_failure_mail' => '1', 'orphan_mail' => '1'],
            ]),
            'created'         => $maintenant->toSql(),
            'created_by'      => (int) Factory::getApplication()->getIdentity()?->id,
        ];

        try {
            $db->insertObject('#__scheduler_tasks', $tache);
            Factory::getApplication()->enqueueMessage(Text::_('PKG_FORMULUS_TACHE_CREEE'), 'info');
        } catch (\RuntimeException) {
            Factory::getApplication()->enqueueMessage(Text::_('PKG_FORMULUS_TACHE_ECHEC'), 'warning');
        }
    }

    /**
     * Formulus dans la liste des extensions du journal des actions, pour que
     * le filtre « Extension » le propose.
     */
    private function declarerAuJournal(): void
    {
        $db = $this->db();

        $existe = (int) $db->setQuery(
            $db->createQuery()
                ->select('COUNT(*)')
                ->from($db->quoteName('#__action_logs_extensions'))
                ->where($db->quoteName('extension') . ' = ' . $db->quote('com_formulus'))
        )->loadResult();

        if (!$existe) {
            // Une VARIABLE, pas un objet ecrit sur place : insertObject() prend
            // son objet par reference. Releve a l'installation de la 1.0.206.
            $ligne = (object) ['extension' => 'com_formulus'];
            $db->insertObject('#__action_logs_extensions', $ligne);
        }
    }

    /**
     * LE DROIT « MODIFIER LA VALEUR DU CHAMP » POUR LE PUBLIC.
     *
     * Mesure dans la source (FieldsPlugin::onCustomFieldsPrepareDom) : un champ
     * dont l'utilisateur n'a pas `core.edit.value` sort DESACTIVE. Sans ce droit,
     * un visiteur verrait le formulaire public et ne pourrait rien y saisir.
     *
     * On ne le pose que s'il n'a jamais ete regle : un administrateur qui l'a
     * change dans Options, Droits garde son choix.
     */
    private function donnerDroitPublic(): void
    {
        $asset = new Asset($this->db());

        if (!$asset->loadByName('com_formulus')) {
            return;
        }

        $regles = json_decode((string) $asset->rules, true) ?: [];

        if (\array_key_exists('core.edit.value', $regles)) {
            return;
        }

        $regles['core.edit.value'] = ['1' => 1];
        $asset->rules              = json_encode($regles);

        if ($asset->store()) {
            Factory::getApplication()->enqueueMessage(Text::_('PKG_FORMULUS_DROIT_PUBLIC_POSE'), 'info');
        }
    }

    private function idPlugin(string $groupe): int
    {
        $db = $this->db();

        return (int) $db->setQuery(
            $db->createQuery()
                ->select($db->quoteName('extension_id'))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                ->where($db->quoteName('folder') . ' = ' . $db->quote($groupe))
                ->where($db->quoteName('element') . ' = ' . $db->quote('formulus'))
        )->loadResult();
    }

    private function db(): DatabaseInterface
    {
        return Factory::getContainer()->get(DatabaseInterface::class);
    }
};
