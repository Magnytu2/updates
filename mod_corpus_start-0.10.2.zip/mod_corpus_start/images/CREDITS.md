# Images du contenu de démonstration

Douze photographies, redimensionnées à 1000 px de large et converties en WebP
(qualité 0,62). Source : Pexels. Poids total : environ 640 Ko.

| Fichier | Auteur | Pexels |
| --- | --- | --- |
| veloute-de-potimaron.webp | Loren Castillo | 9124024 |
| fondue-de-poireaux.webp | Pixabay | 50585 |
| ratatouille-mediterraneenne.webp | Edita Brus | 36040965 |
| tarte-fine-tomate-olives.webp | Pixabay | 162744 |
| petits-pois-a-la-francaise.webp | Engin Akyurt | 9399981 |
| gateau-courgette-citron.webp | Ebru DOĞAN | 24742649 |
| legume-aubergine.webp | Doğan Alpaslan Demir | 19390533 |
| legume-tomate.webp | Dmitry Kharitonov | 33499935 |
| legume-potimaron.webp | MrGajowy3 Teodor | 35815194 |
| legume-poireau.webp | Chixpix | 33715797 |
| legume-petit-pois.webp | Mateusz Feliksik | 13428187 |
| legume-courgette.webp | Les Bourgeonniers | 237635 |

## Point de licence à trancher avant toute diffusion publique

La licence Pexels autorise l'usage commercial et la modification, sans
attribution obligatoire. Elle interdit en revanche de revendre des copies non
modifiées des photos, et de les redistribuer sur une autre plateforme de
photos.

Un module de démonstration qui embarque des photos redimensionnées n'entre
clairement dans aucun des deux cas, mais ce n'est pas un avis juridique : le
point reste à valider avant la mise en vente de Corpus.
