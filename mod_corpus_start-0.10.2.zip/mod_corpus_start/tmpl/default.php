<?php
/**
 * Gabarit d'affichage du module de démarrage Corpus.
 *
 * Structure calquée sur mod_sampledata (cœur Joomla) : liste .list-group,
 * bouton .btn.btn-primary.btn-sm, barre de progression masquée par défaut.
 * Aucune couleur n'est déclarée ici : tout vient des classes Bootstrap/Atum
 * déjà chargées par l'administration.
 *
 * Variables reçues de mod_corpus_start.php : $scenarios, $params, $module.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;

// LA FENÊTRE EST CELLE DE JOOMLA, celle de la visite guidée et des traitements
// par lot : le composant <joomla-dialog>, pas une modale Bootstrap. On demande
// donc son script, sinon `data-joomla-dialog` n'a personne pour l'écouter et le
// bouton reste mort, sans erreur et sans message.
Factory::getApplication()->getDocument()->getWebAssetManager()
	->useScript('joomla.dialog-autocreate');

// Uri::root() renvoie toujours la racine du SITE, jamais /administrator :
// il faut l'ajouter explicitement, sinon com_ajax cherche le module côté site.
$ajaxUrl   = Uri::root(true) . '/administrator/index.php?option=com_ajax&module=corpus_start&format=json';
$csrf      = Session::getFormToken();
$wrapperId = 'corpus-start-' . (int) $module->id;
$modalId   = $wrapperId . '-reset-modal';

// Les réglages de la fenêtre, au format qu'attend joomla-dialog-autocreate.js.
$dialogConfig = json_encode([
	'popupType'    => 'inline',
	// 'src' et non 'popupContent' : joomla-dialog.js ne fait un querySelector que
	// sur 'src' (ligne 352). Un sélecteur passé dans 'popupContent' serait inséré
	// tel quel, en texte, et la fenêtre afficherait « #corpus-start-… ».
	'src'          => '#' . $modalId,
	'textHeader'   => Text::_('MOD_CORPUS_START_RESET_CONFIRM_TITLE'),
	'width'        => '600px',
	'height'       => 'fit-content',
], JSON_UNESCAPED_UNICODE);
?>
<div id="<?php echo $wrapperId; ?>" class="corpus-start" data-ajax-url="<?php echo $ajaxUrl; ?>" data-csrf="<?php echo $csrf; ?>">

	<div class="corpus-start__alert" role="status" aria-live="polite"></div>

	<ul class="list-group list-group-flush corpus-start">
		<?php foreach ($scenarios as $key => $scenario) : ?>
			<li class="list-group-item corpusstart-<?php echo $key; ?>">
				<div class="d-flex justify-content-between align-items-center">
					<div class="corpus-start__title">
						<span class="corpus-start__icon <?php echo $scenario['icon']; ?> me-1" aria-hidden="true"></span>
						<?php echo Text::_($scenario['langPrefix'] . '_TITLE'); ?>
					</div>
					<button type="button" class="btn btn-primary btn-sm corpus-start__install" data-task="<?php echo $key; ?>">
						<span class="icon-upload" aria-hidden="true"></span>
						<?php echo Text::_('MOD_CORPUS_START_BTN_INSTALL'); ?>
						<span class="visually-hidden"><?php echo Text::_($scenario['langPrefix'] . '_TITLE'); ?></span>
					</button>
				</div>
				<p class="corpus-start__desc small mt-1">
					<?php echo Text::_($scenario['langPrefix'] . '_DESC'); ?>
				</p>
			</li>
			<li class="list-group-item corpusstart-progress-<?php echo $key; ?> d-none">
				<div class="progress mb-1">
					<div class="progress-bar progress-bar-striped progress-bar-animated" style="width: 100%"></div>
				</div>
			</li>
		<?php endforeach; ?>

		<li class="list-group-item corpusstart-reset">
			<div class="d-flex justify-content-between align-items-center">
				<div class="corpus-start__title">
					<span class="corpus-start__icon icon-trash me-1" aria-hidden="true"></span>
					<?php echo Text::_('MOD_CORPUS_START_RESET_TITLE'); ?>
				</div>
				<button type="button" class="btn btn-danger btn-sm corpus-start__reset-open" data-joomla-dialog="<?php echo htmlspecialchars($dialogConfig, ENT_QUOTES, 'UTF-8'); ?>">
					<span class="icon-trash" aria-hidden="true"></span>
					<?php echo Text::_('MOD_CORPUS_START_RESET_BTN'); ?>
				</button>
			</div>
			<p class="corpus-start__desc small mt-1">
				<?php echo Text::_('MOD_CORPUS_START_RESET_DESC'); ?>
			</p>
		</li>
		<li class="list-group-item corpusstart-progress-reset d-none">
			<div class="progress mb-1">
				<div class="progress-bar progress-bar-striped progress-bar-animated" style="width: 100%"></div>
			</div>
		</li>
	</ul>

	<!--
		Confirmation de réinitialisation.

		Le contenu vit dans un <template> : JoomlaDialog en CLONE le contenu au
		lieu de le déplacer (joomla-dialog.js, ligne 358). Les écouteurs posés
		sur les nœuds d'origine ne suivraient donc pas la copie. D'où la
		délégation sur `document` plus bas, et non un addEventListener direct.
	-->
	<template id="<?php echo $modalId; ?>">
		<!-- p-3 : le corps de <joomla-dialog> ne pose aucune marge intérieure.
		     Classe utilitaire Bootstrap, déjà chargée par Atum, aucun style ajouté. -->
		<div class="p-3">
		<p class="mb-0"><?php echo Text::_('MOD_CORPUS_START_RESET_CONFIRM_BODY'); ?></p>
		<div class="d-flex justify-content-end gap-2 mt-4">
			<button type="button" class="btn btn-secondary btn-sm corpus-start__reset-cancel">
				<?php echo Text::_('MOD_CORPUS_START_CANCEL'); ?>
			</button>
			<button type="button" class="btn btn-danger btn-sm corpus-start__reset-confirm" data-wrapper="<?php echo $wrapperId; ?>">
				<span class="icon-trash" aria-hidden="true"></span>
				<?php echo Text::_('MOD_CORPUS_START_RESET_CONFIRM_BTN'); ?>
			</button>
		</div>
		</div>
	</template>
</div>

<script>
(function () {
	'use strict';

	var wrapper = document.getElementById('<?php echo $wrapperId; ?>');
	if (!wrapper) {
		return;
	}

	var ajaxUrl = wrapper.dataset.ajaxUrl;
	var csrf    = wrapper.dataset.csrf;
	var alertEl = wrapper.querySelector('.corpus-start__alert');

	function showMessage(text, isError) {
		alertEl.textContent = text;
		alertEl.className = 'corpus-start__alert alert ' + (isError ? 'alert-danger' : 'alert-info') + ' mb-3';
	}

	function callTask(task, button, progressSelector) {
		var body = new URLSearchParams();
		body.set('task', task);
		body.set(csrf, '1');

		var progress = wrapper.querySelector(progressSelector);
		if (button) {
			button.disabled = true;
		}
		if (progress) {
			progress.classList.remove('d-none');
		}

		fetch(ajaxUrl, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' },
			body: body.toString(),
			credentials: 'same-origin'
		})
			.then(function (response) { return response.json(); })
			.then(function (json) {
				if (json && json.success) {
					var msg = (json.data && json.data.message) || <?php echo json_encode(Text::_('MOD_CORPUS_START_SKELETON_OK')); ?>;
					showMessage(msg, false);
				} else {
					var errMsg = (json && json.message) || <?php echo json_encode(Text::_('MOD_CORPUS_START_ERROR')); ?>;
					showMessage(errMsg, true);
				}
			})
			.catch(function () {
				showMessage(<?php echo json_encode(Text::_('MOD_CORPUS_START_ERROR')); ?>, true);
			})
			.finally(function () {
				if (button) {
					button.disabled = false;
				}
				if (progress) {
					progress.classList.add('d-none');
				}
			});
	}

	wrapper.querySelectorAll('.corpus-start__install').forEach(function (btn) {
		btn.addEventListener('click', function () {
			callTask(btn.dataset.task, btn, '.corpusstart-progress-' + btn.dataset.task);
		});
	});

	/*
	 * Les boutons de la fenêtre sont des COPIES : JoomlaDialog clone le contenu
	 * du <template>. On écoute donc sur `document`, et on reconnaît les nôtres
	 * par l'identifiant du module qu'ils portent. Deux instances du module sur
	 * la même page ne se marchent pas dessus.
	 */
	document.addEventListener('click', function (event) {
		var confirmer = event.target.closest('.corpus-start__reset-confirm[data-wrapper="<?php echo $wrapperId; ?>"]');
		var annuler   = event.target.closest('.corpus-start__reset-cancel');

		if (!confirmer && !annuler) {
			return;
		}

		var fenetre = event.target.closest('joomla-dialog');
		if (fenetre && typeof fenetre.close === 'function') {
			fenetre.close();
		}

		if (confirmer) {
			callTask('reset', null, '.corpusstart-progress-reset');
		}
	});
})();
</script>
