<?php
/**
 * Module de démarrage Corpus : le point d'entrée.
 *
 * Phase 1 : squelette seulement. La liste des scénarios vient du helper,
 * aucune écriture en base n'a lieu ici ni dans le helper à ce stade.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

require_once __DIR__ . '/helper.php';

$scenarios = ModCorpusStartHelper::getScenarios();

require ModuleHelper::getLayoutPath('mod_corpus_start', $params->get('layout', 'default'));
