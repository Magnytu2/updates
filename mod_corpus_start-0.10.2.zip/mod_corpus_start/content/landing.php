<?php
/**
 * Scénario « Page d'atterrissage ».
 *
 * Celui-ci ne présente PAS le livre de recettes : il présente Corpus. Le
 * contenu commun est quand même installé, parce que les liens de la page et
 * du menu doivent mener quelque part, mais la page d'accueil ne parle que du
 * template.
 *
 * LE PRÉRÉGLAGE `landing` ÉTEINT LE COMPOSANT (`layoutEnable_content: 0`) :
 * la page n'est plus faite que de rangées de modules. C'est ce qui distingue
 * vraiment ce scénario des deux autres, et c'est aussi pourquoi il faut
 * garnir chaque rangée allumée, sous peine d'une page trouée.
 *
 * Les deux premières rangées reprennent EXACTEMENT celles de la maquette du
 * banc 8090, relevées à l'écran : le hero et son sommaire en vis-à-vis, puis
 * les trois tuiles. Les classes ont été portées au vocabulaire d'aujourd'hui,
 * `rule` et non `filet`, `btn` et non `bouton`, `card` et non `carte`.
 */

defined('_JEXEC') or die;

/*
 * TROIS PETITS ASSEMBLEURS, pour ne pas recopier vingt fois le même balisage.
 *
 * Des FERMETURES et non des fonctions nommées : ce fichier peut être lu
 * plusieurs fois dans la même requête, et une fonction déclarée deux fois
 * arrête PHP net.
 */

// Une carte à pastille d'état, du tampon « Grille - Cartes avec etat ». La
// couleur vient d'un jeton du template, avec le repli en dur du tampon.
$carte = static function (string $titre, string $texte, string $jeton, string $repli, string $etat): string {
	return '<div class="col-md-3"><article class="card h-100"><div class="card-body">'
		. '<p class="lead fw-semibold mb-2">' . $titre . '</p>'
		. '<p>' . $texte . '</p>'
		. '<p class="mb-0" style="color:var(--' . $jeton . ',' . $repli . ')">'
		. '<span aria-hidden="true" style="display:inline-block;width:.6em;height:.6em;'
		. 'border-radius:50%;background:currentColor;margin-right:.4em"></span>'
		. '<strong>' . $etat . '</strong></p>'
		. '</div></article></div>';
};

// Un point numéroté, du tampon « Page - Points cles avec visuel ».
$point = static function (int $rang, string $titre, string $texte): string {
	return '<li class="d-flex gap-3 mb-4">'
		. '<span class="badge rounded-circle" aria-hidden="true">' . $rang . '</span><div>'
		. '<p class="lead fw-semibold mb-2">' . $titre . '</p>'
		. '<p class="mb-0">' . $texte . '</p>'
		. '</div></li>';
};

// Un volet d'accordéon, du tampon « FAQ - Accordeon ».
$volet = static function (string $id, bool $ouvert, string $question, string $reponse): string {
	return '<h3 class="accordeon__titre">'
		. '<button type="button" class="accordeon__bouton" aria-expanded="' . ($ouvert ? 'true' : 'false')
		. '" aria-controls="' . $id . '">' . $question . '</button></h3>'
		. '<div class="accordeon__volet" id="' . $id . '"' . ($ouvert ? '' : ' hidden') . '>'
		. '<p>' . $reponse . '</p></div>';
};

$contenu = require __DIR__ . '/commun.php';

$contenu['preset'] = 'landing';

// --- Les réglages du style, posés par-dessus le préréglage -----------------
$contenu['styleParams'] = [
	// Plus large que le blog et le magazine, demandé par Cyrille : une page
	// d'atterrissage respire, elle n'a pas de colonne de texte à contenir.
	'layoutMaxWidth' => '1420px',

	// La première rangée en deux moitiés : le hero à gauche, le sommaire à
	// droite. C'est la disposition de la maquette du 8090.
	'layoutWidth_top_1' => '6:6',

	// LES CLASSES DE BANDE DU PRÉRÉGLAGE SONT PÉRIMÉES. Il porte `blue-bg` et
	// `grey-bg`, héritées du template d'origine, que Corpus ne déclare pas.
	// On les remplace par les siennes, celles d'`etc/aide-classes.ini`.
	'layoutClass_top_1' => '',
	'layoutClass_top_2' => 'section--alt',
	'layoutClass_top_3' => '',
	'layoutClass_top_4' => 'section--tint',

	// Les quatre rangées basses, qui portent la seconde moitié de la page.
	// Le préréglage colle `no-repeat,full-width` sur la première : encore une
	// classe du template d'origine, que Corpus ne déclare pas.
	'layoutEnable_bot_1' => '1',
	'layoutPos_bot_1'    => 'bottom-a',
	'layoutClass_bot_1'  => '',
	'layoutEnable_bot_2' => '1',
	'layoutPos_bot_2'    => 'bottom-b',
	'layoutClass_bot_2'  => 'section--alt',
	'layoutEnable_bot_3' => '1',
	'layoutPos_bot_3'    => 'bottom-c',
	'layoutClass_bot_3'  => '',

	// Sans composant, deux colonnes latérales n'ont plus rien à encadrer.
	'layoutEnable_col_1' => '0',
	'layoutEnable_col_2' => '0',

	// La recherche à droite du menu, comme dans les deux autres scénarios.
	'layoutEnable_nav_right' => '1',
	'layoutPos_nav_right'    => 'search',
	'layoutWidth_nav_left'   => '9',
];

// Aucun article en vedette : le composant est éteint, personne ne les verrait.
$contenu['featured'] = [];

// --- Les modules ----------------------------------------------------------
$contenu['modules'] = [

	// ---- RANGÉE 1, moitié gauche : le hero -------------------------------
	[
		'title'     => 'Corpus, en une phrase',
		'module'    => 'mod_custom',
		'position'  => 'top-a',
		'showtitle' => 0,
		'pages'     => 'all',
		'content'   => '<h1 class="mt-0">Un site public sobre, lisible et solide</h1>'
			. '<p class="lead">Corpus reprend le niveau d\'exigence des sites de l\'État, accessibilité,'
			. ' contrastes tenus, structure prévisible, sans emprunter leur identité visuelle, qui leur'
			. ' est juridiquement réservée.</p>'
			. '<p class="boutons">'
			. '<a class="btn" href="{lien:les-tampons}">Voir les tampons</a> '
			. '<a class="btn btn-secondary" href="{lien:typographie}">La typographie</a>'
			. '</p>'
			. '<p class="note">Tout ce que montre cette page a été posé en un clic par le module de'
			. ' démarrage, et le bouton « Tout réinitialiser » le retire.</p>',
		'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
	],

	// ---- RANGÉE 1, moitié droite : l'alerte et le sommaire ---------------
	[
		'title'     => 'Sommaire',
		'module'    => 'mod_custom',
		'position'  => 'top-a',
		'showtitle' => 0,
		'pages'     => 'all',
		'content'   => '<div class="message rule message--info" role="note"><div>'
			. '<p class="message__titre">Une démonstration, pas un thème</p>'
			. '<p>Ces pages servent à montrer ce que le template sait faire. Vous pouvez tout'
			. ' effacer et repartir d\'un Joomla vierge.</p>'
			. '</div></div>'
			. '<div class="sommaire">'
			. '<p class="message__titre">Sommaire</p>'
			. '<ol>'
			. '<li><a href="{lien:typographie}">La typographie</a></li>'
			. '<li><a href="{lien:les-tampons}">Les tampons</a></li>'
			. '<li><a href="{lien:recettes}">Le gabarit d\'article</a></li>'
			. '<li><a href="{lien:potager}">Une catégorie en mise en page native</a></li>'
			. '<li><a href="index.php?option=com_finder&view=search">La recherche</a></li>'
			. '<li><a href="index.php?option=com_users&view=login">La connexion</a></li>'
			. '<li><a href="index.php?option=com_contact&view=categories&id=0">Les contacts</a></li>'
			. '<li><a href="{lien:aubergine}">Un article, mise en page native</a></li>'
			. '</ol>'
			. '</div>',
		'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
	],

	// ---- RANGÉE 2 : les trois tuiles -------------------------------------
	[
		'title'     => 'Trois entrées',
		'module'    => 'mod_custom',
		'position'  => 'top-b',
		'showtitle' => 0,
		'pages'     => 'all',
		'content'   => '<div class="row g-4">'
			. '<div class="col-md-4"><article class="card"><div class="card-body">'
			. '<p class="lead fw-semibold mb-2"><a href="{lien:typographie}">Le texte avant tout</a></p>'
			. '<p>Titres, listes, citations, tableaux et messages : le template habille le texte'
			. ' courant sans qu\'on ait une classe à écrire.</p>'
			. '</div></article></div>'
			. '<div class="col-md-4"><article class="card"><div class="card-body">'
			. '<p class="lead fw-semibold mb-2"><a href="{lien:les-tampons}">Cinquante-cinq tampons</a></p>'
			. '<p>Des blocs tout prêts que l\'éditeur insère en deux clics, du hero à l\'accordéon,'
			. ' et qui restent modifiables à la main.</p>'
			. '</div></article></div>'
			. '<div class="col-md-4"><article class="card"><div class="card-body">'
			. '<p class="lead fw-semibold mb-2"><a href="{lien:recettes}">Un gabarit par catégorie</a></p>'
			. '<p>Chaque catégorie peut avoir sa propre mise en page d\'article, montée en rangées'
			. ' et en briques, sans une ligne de code.</p>'
			. '</div></article></div>'
			. '</div>',
		'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
	],

	// ---- RANGÉE 3 : les quatre cartes à pastille -------------------------
	// Le tampon « Grille - Cartes avec etat », celui de la maquette de la
	// boutique. Sa pastille prend sa couleur d'un jeton du template, avec un
	// repli en dur : rien n'est inventé ici. Quatre colonnes au lieu de trois.
	[
		'title'     => 'Ce que fait Corpus',
		'module'    => 'mod_custom',
		'position'  => 'top-c',
		'showtitle' => 0,
		'pages'     => 'all',
		'content'   => '<h2 class="rule">Ce que fait Corpus</h2>'
			. '<p>Quatre chantiers, et où chacun en est.</p>'
			. '<div class="row g-4">'
			. $carte(
				'La typographie',
				"Titres, listes, citations, tableaux et messages, habillés sans qu'on ait une classe à écrire.",
				'succes', '#136c3a', 'Livré'
			)
			. $carte(
				'Les tampons',
				"Cinquante-cinq blocs tout prêts, insérés depuis l'éditeur et modifiables à la main.",
				'succes', '#136c3a', 'Livré'
			)
			. $carte(
				"Le gabarit d'article",
				"Une mise en page par catégorie, montée en rangées et en briques, sans une ligne de code.",
				'succes', '#136c3a', 'Livré'
			)
			. $carte(
				'Les préréglages',
				"Quatre ossatures de site, du blog à la page d'atterrissage, en un seul choix.",
				'alerte', '#8a5300', 'En cours'
			)
			. '</div>',
		'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
	],

	// ---- RANGÉE 4 : les quatre partis pris, avec leurs pastilles ---------
	[
		'title'     => 'Quatre partis pris',
		'module'    => 'mod_custom',
		'position'  => 'top-d',
		'showtitle' => 0,
		'pages'     => 'all',
		'content'   => '<div class="row align-items-center">'
			. '<div class="col-lg-6 mb-4">'
			. '<img class="img-fluid" src="images/corpus-start/legume-tomate.webp"'
			. ' alt="Des tomates cerises photographiées de près" width="1000" height="773">'
			. '</div>'
			. '<div class="col-lg-6">'
			. '<h2 class="rule mt-0">Quatre partis pris</h2>'
			. '<ol class="list-unstyled">'
			. $point(1, "L'accessibilité n'est pas une option",
				"Contrastes tenus, ordre de lecture stable, tout au clavier. La couleur n'est jamais le seul indice, et rien d'utile n'est caché par la feuille de style.")
			. $point(2, 'Ce qui marche sous Cassiopeia marche sous Corpus',
				"Les positions, les classes de vignette, les mots-clés du blog : le vocabulaire de Joomla est repris tel quel, il n'y a rien à réapprendre.")
			. $point(3, 'Des réglages, pas du code',
				"La mise en page, les gabarits d'article et les bandes se règlent dans le style du template. Un préréglage change toute l'ossature d'un site en une fois.")
			. $point(4, "Rien d'irréversible",
				"Cette démonstration s'installe et se retire d'un clic. Vos réglages d'avant sont notés, et ils vous sont rendus.")
			. '</ol>'
			. '</div></div>',
		'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
	],

	// ---- RANGÉE BASSE 1 : ce qui est mesuré ------------------------------
	// La règle de la maquette de la boutique, reprise telle quelle : un nombre
	// qu'on ne peut pas aller vérifier n'entre pas dans ce bloc.
	[
		'title'     => 'Vérifié, pas promis',
		'module'    => 'mod_custom',
		'position'  => 'bottom-a',
		'showtitle' => 0,
		'pages'     => 'all',
		'content'   => '<h2 class="rule">Vérifié, pas promis</h2>'
			. '<p>Pas d\'années d\'existence ni de millions de téléchargements à afficher. Des'
			. ' contrôles, et ils tournent à chaque livraison.</p>'
			. '<div class="row text-center">'
			. '<div class="col-md-4"><p><strong style="font-size:2.5rem;line-height:1.1;display:block">55</strong>'
			. ' Tampons livrés avec le template</p></div>'
			. '<div class="col-md-4"><p><strong style="font-size:2.5rem;line-height:1.1;display:block">19</strong>'
			. ' Briques pour composer un gabarit d\'article</p></div>'
			. '<div class="col-md-4"><p><strong style="font-size:2.5rem;line-height:1.1;display:block">4</strong>'
			. ' Langues, et autant de préréglages de mise en page</p></div>'
			. '</div>',
		'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
	],

	// ---- RANGÉE BASSE 2 : les questions ----------------------------------
	[
		'title'     => 'Les questions qu\'on nous pose',
		'module'    => 'mod_custom',
		'position'  => 'bottom-b',
		'showtitle' => 0,
		'pages'     => 'all',
		'content'   => '<h2 class="rule">Les questions qu\'on nous pose</h2>'
			. '<div class="accordeon">'
			. $volet('landing-q1', true, 'Puis-je tout effacer ensuite ?',
				"Oui. Le bouton « Tout réinitialiser » retire les articles, les catégories, les menus et les modules posés par le module de démarrage, et rend vos réglages d'avant. Rien d'autre n'est touché.")
			. $volet('landing-q2', false, 'Faut-il savoir coder ?',
				"Non. Tout ce que montre cette page se règle dans l'administration de Joomla : le style du template, les paramètres d'un lien de menu, et le champ « Classe du module ».")
			. $volet('landing-q3', false, 'Est-ce que ça marche avec mon site existant ?',
				"Le principe de Corpus est que ce qui marche sous Cassiopeia marche sous Corpus : mêmes positions, même vocabulaire de classes. Un site existant se retrouve donc en terrain connu.")
			. '</div>',
		'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
	],

	// ---- RANGÉE BASSE 3 : l'appel final ----------------------------------
	[
		'title'     => 'Voir avant de décider',
		'module'    => 'mod_custom',
		'position'  => 'bottom-c',
		'showtitle' => 0,
		'pages'     => 'all',
		'content'   => '<div class="panneau__boite">'
			. '<h2>Voir avant de décider</h2>'
			. '<p>Les mêmes articles existent en blog et en magazine. Installez l\'un puis l\'autre :'
			. ' le contenu ne change pas, seule la mise en page change.</p>'
			. '<p><a class="btn" href="{lien:recettes}">Ouvrir la démonstration</a>'
			. ' <a class="btn btn-secondary" href="{lien:les-tampons}">Voir les tampons</a></p>'
			. '</div>',
		'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
	],

	// ---- La recherche, comme dans les deux autres scénarios --------------
	[
		'title'     => 'Rechercher',
		'module'    => 'mod_finder',
		'position'  => 'search',
		'showtitle' => 0,
		'pages'     => 'all',
		'params'    => [
			'searchfilter' => '',
			'show_label'   => '0',
			'alt_label'    => '',
			'show_button'  => '1',
			'opensearch'   => '1',
			'field_size'   => '20',
			'maxlength'    => '200',
			'set_itemid'   => '',
		],
	],
];

// --- Le menu --------------------------------------------------------------
$contenu['menu'] = require __DIR__ . '/menu.php';

foreach ($contenu['menu'] as &$entree) {
	if (!empty($entree['home'])) {
		// Le composant est éteint : cette entrée ne sert plus qu'à porter la
		// page par défaut et à donner leur adresse aux modules.
		$entree['title'] = 'Corpus';
	}
}

unset($entree);

return $contenu;
