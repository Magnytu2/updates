<?php
/**
 * Le menu, commun au blog et au magazine.
 *
 * Un scénario le reprend tel quel et n'ajuste que son entrée d'accueil, qui
 * porte les réglages de la une et diffère donc d'une mise en page à l'autre.
 *
 * `key` sert de référence pour les entrées filles. `mega` pose le mot dans le
 * champ natif « Style CSS du lien », ce qui suffit à déclencher le méga-menu
 * de Corpus sur une entrée de premier niveau.
 */

defined('_JEXEC') or die;

// LES PAGES DE CATÉGORIE DES RECETTES, réglées une fois pour toutes.
//
// « Le potager » ne les reçoit PAS : Cyrille le veut en mise en page native de
// Joomla, pour qu'on voie la différence entre une page habillée et une page
// que le template laisse tranquille.
//
// Demande de Cyrille : tous les articles de la catégorie, à l'horizontale,
// l'image d'un côté puis de l'autre. Corpus porte exactement cela dans le
// champ natif « Classe d'article » du lien de menu, avec le vocabulaire de
// Cassiopeia repris volontairement (voir `etc/aide-classes.ini`) :
//
//   image-left        l'image à gauche, le texte à droite
//   image-alternate   à combiner avec l'un des deux : un côté sur deux
//   no-card           la vignette sans cadre
//
// UNE SEULE COLONNE, et aucun article de tête : une vignette horizontale n'a
// pas la place de se déployer dans une colonne de six douzièmes, et un article
// de tête casserait l'alternance dès la première ligne.
$pagesCategorie = [
	'num_leading_articles' => '0',
	'num_intro_articles'   => '20',
	'num_columns'          => '1',
	'num_links'            => '0',
	'blog_class'           => 'image-left image-alternate no-card',
	'blog_class_leading'   => 'image-left no-card',
	'show_intro'           => '1',
	'orderby_sec'          => 'rdate',

	// « Recettes » ne porte aucun article en propre : ils sont dans Entrées,
	// Plats et Desserts. Sans cette ligne, sa page serait vide.
	'show_subcategory_content' => '-1',
	'maxLevel'                 => '-1',
];


return [

	[
		'key'    => 'accueil',
		'title'  => 'Accueil',
		'type'   => 'featured',
		'home'   => true,
	],

	// Les entrées ordinaires d'abord.
	['title' => 'Recettes', 'type' => 'category', 'params' => $pagesCategorie, 'category' => 'recettes'],
	['title' => 'Le potager', 'type' => 'category', 'category' => 'potager'],

	// LE MÉGA-MENU EN DERNIER, demandé par Cyrille : un panneau large ouvert
	// sous la dernière entrée reste dans la page, alors qu'ouvert sous la
	// première il pousse tout le reste vers la droite.
	// Type « heading » : l'entrée n'ouvre aucune page, elle ne sert qu'à
	// porter le panneau.
	['key' => 'decouvrir', 'title' => 'Découvrir', 'type' => 'heading', 'mega' => true],

	// Colonne 1
	['key' => 'col-recettes', 'title' => 'Recettes', 'type' => 'heading', 'parent' => 'decouvrir'],
	['title' => 'Toutes les recettes', 'type' => 'category', 'params' => $pagesCategorie, 'category' => 'recettes', 'parent' => 'col-recettes'],
	['title' => 'Entrées', 'type' => 'category', 'params' => $pagesCategorie, 'category' => 'entrees', 'parent' => 'col-recettes'],
	['title' => 'Plats', 'type' => 'category', 'params' => $pagesCategorie, 'category' => 'plats', 'parent' => 'col-recettes'],
	['title' => 'Desserts', 'type' => 'category', 'params' => $pagesCategorie, 'category' => 'desserts', 'parent' => 'col-recettes'],

	// Colonne 2
	['key' => 'col-potager', 'title' => 'Le potager', 'type' => 'heading', 'parent' => 'decouvrir'],
	['title' => 'Tous les légumes', 'type' => 'category', 'category' => 'potager', 'parent' => 'col-potager'],
	['title' => "L'aubergine", 'type' => 'article', 'article' => 'aubergine', 'parent' => 'col-potager'],
	['title' => 'La tomate', 'type' => 'article', 'article' => 'la-tomate', 'parent' => 'col-potager'],
	['title' => 'Le potimaron', 'type' => 'article', 'article' => 'le-potimaron', 'parent' => 'col-potager'],
	['title' => 'Le poireau', 'type' => 'article', 'article' => 'le-poireau', 'parent' => 'col-potager'],

	// Colonne 3. Elle porte les pages du template ET celles que Joomla sait
	// rendre tout seul : d'où son intitulé, « Le site », qui vaut pour les
	// deux. Quatre colonnes faisaient un panneau trop large.
	['key' => 'col-site', 'title' => 'Le site', 'type' => 'heading', 'parent' => 'decouvrir'],
	['title' => 'Typographie', 'type' => 'article', 'article' => 'typographie', 'parent' => 'col-site'],
	['title' => 'Les tampons', 'type' => 'article', 'article' => 'les-tampons', 'parent' => 'col-site'],
	['title' => 'Connexion', 'type' => 'url', 'link' => 'index.php?option=com_users&view=login', 'component' => 'com_users', 'parent' => 'col-site'],
	['title' => 'Créer un compte', 'type' => 'url', 'link' => 'index.php?option=com_users&view=registration', 'component' => 'com_users', 'parent' => 'col-site'],
	['title' => 'Mot de passe oublié', 'type' => 'url', 'link' => 'index.php?option=com_users&view=reset', 'component' => 'com_users', 'parent' => 'col-site'],
	['title' => 'Recherche', 'type' => 'url', 'link' => 'index.php?option=com_finder&view=search', 'component' => 'com_finder', 'parent' => 'col-site'],
	['title' => 'Contacts', 'type' => 'url', 'link' => 'index.php?option=com_contact&view=categories&id=0', 'component' => 'com_contact', 'parent' => 'col-site'],

];
