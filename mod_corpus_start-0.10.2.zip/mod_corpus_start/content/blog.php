<?php
/**
 * Scénario « Blog + gabarit d'articles ».
 *
 * Reprend tout le contenu commun, et n'ajoute que ce qui fait la mise en page :
 * la page d'accueil, le menu, et les modules.
 *
 * La structure est calquée sur la donnée d'exemple « Blog » de Joomla sur
 * Cassiopeia : un module de contenu en haut de l'accueil, les articles en
 * vedette en dessous, et une page qui montre la typographie du template. Le
 * but est qu'une personne qui débute avec Joomla comprenne d'où vient chaque
 * morceau de la page.
 */

defined('_JEXEC') or die;

$contenu = require __DIR__ . '/commun.php';

// --- Les articles qui remplissent la page d'accueil -----------------------
// Ce sont les six recettes : l'accueil affiche les articles EN VEDETTE, comme
// la page d'accueil par défaut de Joomla.
$contenu['featured'] = [
	'veloute-de-potimaron',
	'fondue-de-poireaux',
	'ratatouille-mediterraneenne',
	'tarte-fine-tomate-olives',
	'petits-pois-a-la-francaise',
	'gateau-courgette-citron',
];

// --- Les réglages du style ------------------------------------------------
// Le blog n'applique aucun préréglage : il garde l'ossature du site. Il pose
// seulement deux réglages, et la réinitialisation rend les valeurs d'avant.
$contenu['styleParams'] = [
	// La largeur de page. Vide, le champ laisse gagner le jeton du template.
	'layoutMaxWidth' => '1280px',

	// La zone à droite du menu, éteinte par le préréglage par défaut. Sans
	// elle, un module publié en position `search` ne sortirait nulle part.
	'layoutEnable_nav_right' => '1',
	'layoutPos_nav_right'    => 'search',
	'layoutWidth_nav_left'   => '9',
];

// --- Les modules ----------------------------------------------------------
// Un seul, en position `top-a` : le bandeau d'ouverture de l'accueil. Joomla
// fait exactement cela dans sa donnée d'exemple, avec un module de contenu
// personnalisé qui porte un titre et un bouton.
//
// PAS `banner` : le préréglage de Corpus range cette position dans la partie
// droite de l'en-tête, où un grand titre n'a pas la place. `top-a` est une
// vraie rangée pleine largeur, allumée par le préréglage par défaut.
$contenu['modules'] = [
	[
		'title'     => "Bienvenue dans le livre de recettes",
		'module'    => 'mod_custom',
		'position'  => 'top-a',
		'showtitle' => 0,
		'pages'     => 'home',
		'content'   => '<div class="text-center">'
			. '<h1>Un livre de recettes pour découvrir Corpus</h1>'
			. '<p class="lead">Six recettes, six légumes, et de quoi comprendre comment le template met'
			. ' en page un article. Tout ce que vous voyez ici a été posé par le module de démarrage,'
			. ' et le bouton « Tout réinitialiser » le retire.</p>'
			. '<p><a class="btn" href="{lien:recettes}">Voir les recettes</a>'
			. ' <a class="btn" href="{lien:typographie}">La typographie</a></p>'
			. '</div>',
		'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
	],

	// La recherche, à droite du menu. Corpus attend `mod_finder` en position
	// `search` : son propre gabarit y sort déjà une balise <search>, ce que le
	// gabarit du cœur ne fait pas.
	[
		'title'     => 'Rechercher',
		'module'    => 'mod_finder',
		'position'  => 'search',
		'showtitle' => 0,
		'pages'     => 'all',
		'params'    => [
			'searchfilter'   => '',
			'show_label'     => '0',
			'alt_label'      => '',
			'show_button'    => '1',
			'opensearch'     => '1',
			'field_size'     => '20',
			'maxlength'      => '200',
			'set_itemid'     => '',
		],
	],
];

// --- Le menu --------------------------------------------------------------
// `key` sert de référence pour les entrées filles. `mega` pose le mot dans le
// champ natif « Style CSS du lien », ce qui suffit à déclencher le méga-menu
// de Corpus sur une entrée de premier niveau.
$contenu['menu'] = require __DIR__ . '/menu.php';

// L'entrée d'accueil porte les réglages de la une, qui changent d'un scénario
// à l'autre : un article de tête, puis les cinq autres sur DEUX colonnes.
foreach ($contenu['menu'] as &$entree) {
	if (!empty($entree['home'])) {
		$entree['params'] = [
			'num_leading_articles' => '1',
			'num_intro_articles'   => '5',
			'num_columns'          => '2',
			'num_links'            => '0',
			'multi_column_order'   => '1',
		];
	}
}

unset($entree);

return $contenu;
