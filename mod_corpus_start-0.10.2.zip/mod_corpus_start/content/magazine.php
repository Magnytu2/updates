<?php
/**
 * Scénario « Magazine ».
 *
 * Même contenu que le blog, autre ossature. Il reprend `commun.php` sans y
 * toucher, et ne change que trois choses : le préréglage de mise en page, la
 * page d'accueil, et les modules qui garnissent les zones que ce préréglage
 * ouvre.
 *
 * C'est là tout l'intérêt d'avoir séparé le contenu commun : une personne qui
 * installe les deux scénarios l'un après l'autre voit le MÊME contenu prendre
 * deux allures, ce qui montre bien que la mise en page ne tient pas aux
 * articles.
 */

defined('_JEXEC') or die;

$contenu = require __DIR__ . '/commun.php';

// --- Le préréglage de mise en page ----------------------------------------
// Lu dans le template installé, pas recopié ici. Il ouvre une colonne latérale
// gauche de 4/12, met la recherche dans la barre de navigation, et allume deux
// rangées basses. Les modules ci-dessous vont garnir ces zones : un préréglage
// qui ouvre des zones vides donne une page trouée.
$contenu['preset'] = 'magazine';

// --- Les réglages du style, posés par-dessus le préréglage -----------------
$contenu['styleParams'] = [
	// Même largeur de page que le blog : ce qui change entre les deux
	// scénarios est l'ossature, pas l'encombrement.
	'layoutMaxWidth' => '1280px',

];

// --- Les articles de la une -----------------------------------------------
$contenu['featured'] = [
	'ratatouille-mediterraneenne',
	'tarte-fine-tomate-olives',
	'veloute-de-potimaron',
	'gateau-courgette-citron',
	'petits-pois-a-la-francaise',
	'fondue-de-poireaux',
];

// --- Les modules ----------------------------------------------------------
$contenu['modules'] = [
	// La une, en haut de l'accueil. En `top-a` et non en `banner` : le
	// préréglage magazine range `banner` dans la partie droite de l'en-tête,
	// où un grand titre serait à l'étroit.
	[
		'title'     => 'La une',
		'module'    => 'mod_custom',
		'position'  => 'top-a',
		'showtitle' => 0,
		'pages'     => 'home',
		'content'   => '<div class="text-center">'
			. '<h1>Le potager de saison</h1>'
			. '<p class="lead">Six recettes et six légumes racontés. La même matière que le'
			. ' scénario blog, dans une autre ossature : c\'est le préréglage de mise en page'
			. ' qui change, pas le contenu.</p>'
			. '</div>',
		'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
	],

	// La recherche, à droite du menu. Corpus attend `mod_finder` en position
	// `search` : son propre gabarit y sort déjà une balise <search>, ce que le
	// gabarit du cœur ne fait pas.
	[
		'title'     => 'Rechercher',
		'module'    => 'mod_finder',
		'position'  => 'search',
		'showtitle' => 0,
		'pages'     => 'all',
		'params'    => [
			'searchfilter'   => '',
			'show_label'     => '0',
			'alt_label'      => '',
			'show_button'    => '1',
			'opensearch'     => '1',
			'field_size'     => '20',
			'maxlength'      => '200',
			'set_itemid'     => '',
		],
	],

	// LA UNE : une grande vignette à gauche, deux petites à droite.
	//
	// C'EST UN SEUL MODULE, et rien n'est écrit à la main. Corpus porte pour
	// cela la classe `corpus-magazine`, écrite le 4 août 2026 dans
	// `_modules.scss` : le champ natif « Classe du module » suffit à
	// déclencher la grille, et la feuille fait le reste. Réglages relevés
	// sur le banc 8090, où la mise en page tourne déjà.
	//
	// La feuille attend un module réglé ainsi : les images ALLUMÉES, et tout
	// le reste éteint. On ne masque rien par le CSS, parce qu'un contenu caché
	// en CSS reste lu par un lecteur d'écran et fausse la page.
	[
		'title'     => 'À la une',
		'module'    => 'mod_articles',
		'position'  => 'main-top',
		'showtitle' => 0,
		'pages'     => 'home',
		'params'    => [
			'mode'                         => 'normal',
			'count'                        => '3',
			'category_filtering_type'      => '1',
			'catid'                        => ['{cat:recettes}'],
			'show_child_category_articles' => '1',
			'levels'                       => '2',
			'show_featured'                => 'show',
			'show_archived'                => 'hide',
			'article_ordering'             => 'a.publish_up',
			'article_ordering_direction'   => 'DESC',
			'article_grouping'             => 'none',
			'moduleclass_sfx'              => 'corpus-magazine',
			'articles_layout'              => '1',
			'layout_columns'               => '3',
			'title_only'                   => '0',
			'item_title'                   => '1',
			'link_titles'                  => '1',
			'item_heading'                 => 'h4',
			'image'                        => '1',
			'img_intro_full'               => 'intro',
			'show_introtext'               => '0',
			'show_date'                    => '0',
			'show_author'                  => '0',
			'show_category'                => '0',
			'show_hits'                    => '0',
			'show_tags'                    => '0',
			'show_readmore'                => '0',
			'style'                        => 'corpus-no-card',
		],
	],

	// Les deux listes de la colonne latérale, ouverte par le préréglage à 4/12.
	//
	// LES RÉGLAGES D'AFFICHAGE SONT ÉNUMÉRÉS EN ENTIER, et ce n'est pas du
	// zèle : un module écrit sans passer par le formulaire ne reçoit aucune
	// valeur par défaut. Sans `item_title`, le gabarit de Joomla saute chaque
	// entrée et la liste sort vide, sans la moindre erreur.
	[
		'title'     => 'Au potager',
		'module'    => 'mod_articles',
		'position'  => 'sidebar-left',
		'showtitle' => 1,
		'pages'     => 'all',
		'params'    => [
			'mode'                         => 'normal',
			'count'                        => '6',
			'category_filtering_type'      => '1',
			'catid'                        => ['{cat:potager}'],
			'show_child_category_articles' => '0',
			'show_featured'                => 'show',
			'article_ordering'             => 'a.title',
			'article_ordering_direction'   => 'ASC',
			'article_grouping'             => 'none',
			'item_title'                   => '1',
			'link_titles'                  => '1',
			'item_heading'                 => 'h4',
			// Titres seuls : `title_only` bascule sur le gabarit `_titles` de
			// Joomla, une simple liste de liens, sans vignette ni accroche.
			'title_only'                   => '1',
			'show_introtext'               => '0',
			'show_date'                    => '0',
			'show_author'                  => '0',
			'show_category'                => '0',
			'show_hits'                    => '0',
			'show_tags'                    => '0',
			'show_readmore'                => '0',
			'img_intro_full'               => 'none',
			'articles_layout'              => '0',
		],
	],
	[
		'title'     => 'Dernières recettes',
		'module'    => 'mod_articles',
		'position'  => 'sidebar-left',
		'showtitle' => 1,
		'pages'     => 'all',
		'params'    => [
			'mode'                         => 'normal',
			'count'                        => '5',
			'category_filtering_type'      => '1',
			'catid'                        => ['{cat:recettes}'],
			'show_child_category_articles' => '1',
			'levels'                       => '2',
			'show_featured'                => 'show',
			'article_ordering'             => 'a.publish_up',
			'article_ordering_direction'   => 'DESC',
			'article_grouping'             => 'none',
			'item_title'                   => '1',
			'link_titles'                  => '1',
			'item_heading'                 => 'h4',
			// Titres seuls : `title_only` bascule sur le gabarit `_titles` de
			// Joomla, une simple liste de liens, sans vignette ni accroche.
			'title_only'                   => '1',
			'show_introtext'               => '0',
			'show_date'                    => '0',
			'show_author'                  => '0',
			'show_category'                => '1',
			'show_category_link'           => '0',
			'show_hits'                    => '0',
			'show_tags'                    => '0',
			'show_readmore'                => '0',
			'img_intro_full'               => 'none',
			'articles_layout'              => '0',
		],
	],

	// Les deux rangées basses que le préréglage allume.
	[
		'title'     => 'À propos de ce site',
		'module'    => 'mod_custom',
		'position'  => 'bottom-b',
		'showtitle' => 1,
		'pages'     => 'all',
		'content'   => '<p>Ce site a été monté en une fois par le module de démarrage de'
			. ' Corpus. Rien n\'y a été saisi à la main : les catégories, les articles, les'
			. ' champs de la recette, le menu et ce module lui-même ont été créés d\'un clic,'
			. ' et le bouton « Tout réinitialiser » les retire tous.</p>'
			. '<p><a class="btn" href="{lien:les-tampons}">Voir les tampons</a></p>',
		'params'    => ['prepare_content' => 1],
	],
	[
		'title'     => 'Pour aller plus loin',
		'module'    => 'mod_custom',
		'position'  => 'bottom-c',
		'showtitle' => 1,
		'pages'     => 'all',
		'content'   => '<p>La page <a href="{lien:typographie}">Typographie</a> montre comment'
			. ' Corpus habille le texte courant. La page <a href="{lien:les-tampons}">Les tampons</a>'
			. ' montre les blocs tout prêts que l\'éditeur sait insérer.</p>',
		'params'    => ['prepare_content' => 1],
	],
];

// --- Le menu --------------------------------------------------------------
// Le même que celui du blog. Seule l'entrée d'accueil change : elle s'appelle
// « La une », et elle affiche en plus quatre titres en liens sous les articles,
// ce qui est le propre d'un magazine.
$contenu['menu'] = require __DIR__ . '/menu.php';

foreach ($contenu['menu'] as &$entree) {
	if (!empty($entree['home'])) {
		$entree['title'] = 'La une';
		$entree['params'] = [
			'num_leading_articles' => '1',
			'num_intro_articles'   => '4',
			'num_columns'          => '2',
			'num_links'            => '4',
			'multi_column_order'   => '1',
		];
	}
}

unset($entree);

return $contenu;
