<?php
/**
 * Aide du module de démarrage Corpus.
 *
 * Phase 3 : installation réelle du scénario « blog » et réinitialisation.
 *
 * MARQUAGE. Tout ce que ce module crée porte la note « corpus_start » dans
 * la colonne `note` de sa table (contenu, catégories, tags, champs, menus).
 * La réinitialisation ne supprime QUE ce qui porte cette note : rien d'autre
 * n'est touché, et surtout pas les réglages du template.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;
use Joomla\Database\ParameterType;

class ModCorpusStartHelper
{
	/**
	 * Note posée sur chaque élément créé. Seule clé de la réinitialisation.
	 */
	public const MARKER = 'corpus_start';

	/**
	 * Les quatre scénarios de démarrage.
	 *
	 * 'langPrefix' pointe vers les clés MOD_CORPUS_START_SCENARIO_xxx_TITLE
	 * et _DESC des fichiers de langue. 'icon' est une classe de l'icône
	 * d'administration native de Joomla (préfixe icon-), jamais Font Awesome.
	 *
	 * @return array<string, array{icon: string, langPrefix: string}>
	 */
	public static function getScenarios(): array
	{
		return [
			'blog' => [
				'icon'       => 'icon-book',
				'langPrefix' => 'MOD_CORPUS_START_SCENARIO_BLOG',
			],
			'magazine' => [
				'icon'       => 'icon-grid-2',
				'langPrefix' => 'MOD_CORPUS_START_SCENARIO_MAGAZINE',
			],
			'landing' => [
				'icon'       => 'icon-flag',
				'langPrefix' => 'MOD_CORPUS_START_SCENARIO_LANDING',
			],
			'multilingue' => [
				'icon'       => 'icon-language',
				'langPrefix' => 'MOD_CORPUS_START_SCENARIO_MULTILINGUE',
			],
		];
	}

	/**
	 * Point d'entrée Ajax du module.
	 *
	 * Appelé via index.php?option=com_ajax&module=corpus_start&format=json,
	 * avec 'task' = une clé de getScenarios() ou 'reset', et le jeton CSRF
	 * en paramètre de requête (Joomla.getOptions('csrf.token')=1).
	 *
	 * @return array
	 * @throws Exception
	 */
	public static function getAjax()
	{
		if (!Session::checkToken('request')) {
			throw new Exception(Text::_('JINVALID_TOKEN'), 403);
		}

		$app  = Factory::getApplication();
		$task = $app->getInput()->getCmd('task', '');

		$known   = array_keys(self::getScenarios());
		$known[] = 'reset';

		if (!in_array($task, $known, true)) {
			throw new Exception('Tâche inconnue : ' . $task, 400);
		}

		// com_ajax ne charge pas la langue du module : il faut le faire ici.
		$app->getLanguage()->load('mod_corpus_start', JPATH_ADMINISTRATOR);

		if ($task === 'reset') {
			return self::reset();
		}

		$file = __DIR__ . '/content/' . $task . '.php';

		if (!is_file($file)) {
			// Scénario prévu mais pas encore écrit (magazine, landing, multilingue).
			return [
				'task'    => $task,
				'message' => Text::_('MOD_CORPUS_START_NOT_YET'),
			];
		}

		return self::install($task, require $file);
	}

	// =====================================================================
	// INSTALLATION
	// =====================================================================

	/**
	 * Installe un scénario à partir de son tableau de contenu.
	 *
	 * @param  string $task
	 * @param  array  $content
	 *
	 * @return array
	 * @throws Exception
	 */
	protected static function install(string $task, array $content): array
	{
		if (self::countMarked('#__content') > 0) {
			throw new Exception(Text::_('MOD_CORPUS_START_ALREADY_INSTALLED'), 409);
		}

		$counts = ['categories' => 0, 'fields' => 0, 'articles' => 0, 'menu' => 0];

		// --- 1. Catégories -------------------------------------------------
		$catIds = [];

		foreach ($content['categories'] as $key => $cat) {
			$parentId = 1;

			if (!empty($cat['parent'])) {
				if (empty($catIds[$cat['parent']])) {
					throw new Exception('Catégorie parente absente : ' . $cat['parent'], 500);
				}

				$parentId = $catIds[$cat['parent']];
			}

			$catIds[$key] = self::createCategory($cat['title'], $cat['alias'], $parentId);
			$counts['categories']++;
		}

		// --- 2. Groupe de champs et champs personnalisés --------------------
		$groupId  = self::createFieldGroup($content['fieldgroup']['title']);
		$fieldIds = [];

		foreach ($content['fields'] as $name => $field) {
			$fieldIds[$name] = self::createField(
				$name,
				$field['title'],
				$field['type'],
				!empty($field['group']) ? $groupId : 0,
				$field['options'] ?? [],
				$field['suffix'] ?? ''
			);
			$counts['fields']++;
		}

		// --- 2 bis. Le gabarit d'article, et son affectation ----------------
		// Il porte les identifiants réels des champs qu'on vient de créer :
		// il ne peut donc s'écrire qu'ici, une fois les champs en base.
		$gabarit = self::createGabarit($fieldIds, $groupId);

		if ($gabarit !== '') {
			self::assignGabarit($catIds[$content['gabarit']['categorie']], $gabarit);

			// Les catégories qui doivent garder la mise en page classique de
			// Joomla. Sans cette affectation explicite elles retomberaient sur
			// le premier gabarit déclaré, faute d'en hériter d'une parente.
			foreach ($content['gabarit']['natif'] ?? [] as $cle) {
				if (!empty($catIds[$cle])) {
					self::assignGabarit($catIds[$cle], 'natif');
				}
			}

			// Le gabarit place les champs lui-même : l'affichage automatique
			// de Joomla les sortirait une seconde fois.
			self::hideFieldsFromAutoDisplay(array_values($fieldIds));

		}

		// --- 2 quater. Le préréglage de mise en page ------------------------
		$counts['preset'] = !empty($content['preset']) ? self::applyPreset($content['preset']) : 0;

		// Les réglages de style propres au scénario, posés APRÈS le préréglage
		// pour pouvoir le corriger : la largeur de page, la zone de recherche.
		$counts['preset'] += self::applyStyleParams($content['styleParams'] ?? []);

		// --- 2 ter. Les images ---------------------------------------------
		$counts['images'] = self::copyImages();

		// --- 3. Articles, valeurs de champs et tags -------------------------
		$articleIds = [];

		foreach ($content['articles'] as $article) {
			if (empty($catIds[$article['category']])) {
				throw new Exception('Catégorie inconnue : ' . $article['category'], 500);
			}

			$articleId = self::createArticle($article, $catIds[$article['category']]);
			$articleIds[$article['alias']] = $articleId;
			$counts['articles']++;

			if (!empty($article['fields'])) {
				self::saveFieldValues($articleId, $article['fields'], $fieldIds);
			}
		}

		// --- 4. Mises en avant ---------------------------------------------
		$counts['featured'] = self::setFeatured($content['featured'] ?? [], $articleIds);

		// --- 5. Éléments de menu -------------------------------------------
		$menutype  = self::getSiteMenutype();
		$menuIds   = [];
		$accueilId = 0;

		if ($menutype !== '') {
			foreach ($content['menu'] ?? [] as $item) {
				$id = self::createMenuItem($menutype, $item, $catIds, $articleIds, $menuIds);

				if (!$id) {
					continue;
				}

				if (!empty($item['key'])) {
					$menuIds[$item['key']] = $id;
				}

				if (!empty($item['home'])) {
					$accueilId = $id;
				}

				$counts['menu']++;
			}

			// Sans module de menu en position « menu », les entrées créées
			// n'apparaissent nulle part dans la navigation de Corpus.
			self::forceMenuPosition($menutype);
		}

		// --- 6. Modules -----------------------------------------------------
		$counts['modules'] = 0;

		foreach ($content['modules'] ?? [] as $module) {
			self::createModule($module, $catIds, $articleIds, $accueilId);
			$counts['modules']++;
		}

		// --- 7. La page d'accueil -------------------------------------------
		// En dernier : elle déloge celle de l'utilisateur, et on ne veut pas
		// le faire si quelque chose a échoué avant.
		$counts['accueil'] = $accueilId ? self::setHome($accueilId) : 0;

		return [
			'task'    => $task,
			'counts'  => $counts,
			'gabarit' => $gabarit,
			'message' => Text::sprintf(
				'MOD_CORPUS_START_INSTALL_DONE',
				$counts['articles'],
				$counts['categories'],
				$counts['fields'],
				$counts['menu'],
				$counts['modules'] ?? 0
			) . ($gabarit === '' ? ' ' . Text::_('MOD_CORPUS_START_NO_CORPUS') : ''),
		];
	}

	// =====================================================================
	// LE GABARIT D'ARTICLE
	// =====================================================================

	/**
	 * Nom du gabarit écrit par ce module. Sert aussi de témoin : c'est ce
	 * nom, et lui seul, que la réinitialisation retire des réglages.
	 */
	public const GABARIT_NOM = 'Recette';

	/**
	 * Écrit un gabarit « Recette » dans les réglages du style Corpus.
	 *
	 * Le gabarit référence les champs par leur IDENTIFIANT, c'est ce
	 * qu'attendent les briques `champ` et `groupe-champs` de Corpus. Il ne
	 * peut donc pas être écrit avant que les champs n'existent.
	 *
	 * Rend '' si Corpus n'est pas le template du site : le module reste
	 * utilisable, il installe simplement le contenu sans gabarit.
	 *
	 * @param  array $fieldIds
	 * @param  int   $groupId
	 *
	 * @return string La clé du gabarit, ou '' si rien n'a été écrit
	 */
	protected static function createGabarit(array $fieldIds, int $groupId): string
	{
		$style = self::getCorpusStyle();

		if (!$style) {
			return '';
		}

		$briques = [];
		$n       = 0;

		$poser = static function (string $brique, int $rangee, string $colonne, string $option = '') use (&$briques, &$n) {
			$briques['briques' . $n] = [
				'brique'      => $brique,
				'rangee'      => (string) $rangee,
				'colonne'     => $colonne,
				'option'      => $option,
				'classe'      => '',
				'identifiant' => '',
			];
			$n++;
		};

		// Rangée 1 : le titre, avec les icônes d'impression et d'envoi.
		$poser('titre', 1, 'p');
		$poser('icones', 1, 'p');

		// Rangée 2 : la fiche d'état civil et les étiquettes.
		$poser('plugins-apres-titre', 2, 'p');
		$poser('info', 2, 'p');
		$poser('etiquettes', 2, 'p');

		// Rangée 3 : l'image à gauche, « En bref » à droite sur un aplat teinté.
		$poser('image-pleine', 3, 'g');
		$poser('groupe-champs', 3, 'd', $groupId . ':titre');

		// Rangée 4 : l'accroche, pleine largeur.
		$poser('introduction', 4, 'p');

		// Rangée 5 : les ingrédients sur un aplat à gauche, les étapes à droite.
		// Le corps est réglé sur « sans-intro » : l'accroche est déjà posée en
		// rangée 4, il ne doit pas la répéter.
		if (!empty($fieldIds['liste-ingredients'])) {
			$poser('champ', 5, 'g', (string) $fieldIds['liste-ingredients']);
		}

		$poser('corps', 5, 'd', 'sans-intro');

		// Rangée 6 : les liens de l'article, puis le conseil du chef.
		$poser('liens', 6, 'p');

		if (!empty($fieldIds['conseil-du-chef'])) {
			$poser('champ', 6, 'p', (string) $fieldIds['conseil-du-chef']);
		}

		// Rangée 7 : la fin d'article. « Article précédent / suivant » sort du
		// plugin Pagenavigation, qui écoute onContentBeforeDisplay : c'est donc
		// la brique « plugins avant contenu » qui le porte, et c'est en la
		// posant ICI qu'on obtient la navigation en bas de page.
		$poser('plugins-avant-contenu', 7, 'p');
		$poser('plugins-apres-contenu', 7, 'p');
		$poser('outils', 7, 'p');
		$poser('pagination', 7, 'p');

		$gabarit = [
			'nom'     => self::GABARIT_NOM,
			'rangees' => [
				'rangees0' => ['colonnes' => '1', 'rapport' => '', 'fond' => '', 'fondSur' => ''],
				'rangees1' => ['colonnes' => '1', 'rapport' => '', 'fond' => '', 'fondSur' => ''],
				'rangees2' => ['colonnes' => '2', 'rapport' => '8-4', 'fond' => self::fondTeinte(), 'fondSur' => 'd'],
				'rangees3' => ['colonnes' => '1', 'rapport' => '', 'fond' => '', 'fondSur' => ''],
				'rangees4' => ['colonnes' => '2', 'rapport' => '3-9', 'fond' => 'section--alt', 'fondSur' => 'g'],
				'rangees5' => ['colonnes' => '1', 'rapport' => '', 'fond' => '', 'fondSur' => ''],
				'rangees6' => ['colonnes' => '1', 'rapport' => '', 'fond' => '', 'fondSur' => ''],
			],
			'briques' => $briques,
		];

		$params = self::decodeParams($style->params);
		$liste  = self::gabaritList($params);

		// Un gabarit du même nom déjà présent est remplacé, jamais doublé.
		foreach ($liste as $k => $existant) {
			if (isset($existant['nom']) && $existant['nom'] === self::GABARIT_NOM) {
				unset($liste[$k]);
			}
		}

		$liste[] = $gabarit;

		$params['gabaritsArticle'] = array_values($liste);

		self::saveStyleParams((int) $style->id, $params);

		// La clé est calculée par Corpus à partir du nom, à l'identique.
		return self::gabaritCle(self::GABARIT_NOM);
	}

	/**
	 * Position de gabarit qui reçoit le module « Recettes de saison ».
	 */
	public const MODULE_POSITION = 'article-2';

	/**
	 * La valeur du fond teinté, telle que la comprend le Corpus INSTALLÉ.
	 *
	 * Elle a changé de nom au renommage des classes en anglais : les versions
	 * antérieures attendent « section--teinte », les suivantes « section--tint ».
	 * Écrire la mauvaise ne produit aucun aplat, et sans message. On lit donc
	 * les options réellement déclarées par le template en place plutôt que d'en
	 * supposer une.
	 *
	 * @return string
	 */
	protected static function fondTeinte(): string
	{
		$manifeste = JPATH_SITE . '/templates/corpus/templateDetails.xml';

		if (is_file($manifeste)) {
			$xml = @file_get_contents($manifeste);

			if ($xml !== false && strpos($xml, 'section--tint') !== false) {
				return 'section--tint';
			}

			if ($xml !== false && strpos($xml, 'section--teinte') !== false) {
				return 'section--teinte';
			}
		}

		return 'section--tint';
	}

	/**
	 * Retire du style le gabarit écrit par ce module, et lui seul.
	 *
	 * @return int
	 */
	protected static function removeGabarit(): int
	{
		$style = self::getCorpusStyle();

		if (!$style) {
			return 0;
		}

		$params = self::decodeParams($style->params);
		$liste  = self::gabaritList($params);
		$avant  = count($liste);

		foreach ($liste as $k => $gabarit) {
			if (isset($gabarit['nom']) && $gabarit['nom'] === self::GABARIT_NOM) {
				unset($liste[$k]);
			}
		}

		if (count($liste) === $avant) {
			return 0;
		}

		$params['gabaritsArticle'] = array_values($liste);

		self::saveStyleParams((int) $style->id, $params);

		return $avant - count($liste);
	}

	/**
	 * La clé d'un gabarit, calculée exactement comme CorpusGabarits::cle().
	 *
	 * @param  string $nom
	 *
	 * @return string
	 */
	protected static function gabaritCle(string $nom): string
	{
		$cle = strtolower(trim($nom));
		$cle = preg_replace('/[^a-z0-9]+/', '-', $cle);
		$cle = trim((string) $cle, '-');

		return $cle !== '' ? $cle : 'gabarit-1';
	}

	/**
	 * Le style de site du template Corpus, ou null.
	 *
	 * Même règle de repli que CorpusGabarits::listeDepuisBase() : le style
	 * par défaut d'abord (home décroissant).
	 *
	 * @return object|null
	 */
	protected static function getCorpusStyle()
	{
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName(['id', 'params']))
			->from($db->quoteName('#__template_styles'))
			->where($db->quoteName('client_id') . ' = 0')
			->where($db->quoteName('template') . ' = ' . $db->quote('corpus'))
			->order($db->quoteName('home') . ' DESC');

		$db->setQuery($query, 0, 1);

		return $db->loadObject();
	}

	/**
	 * Les réglages d'un style, en tableau.
	 *
	 * @param  string $raw
	 *
	 * @return array
	 */
	protected static function decodeParams($raw): array
	{
		$params = json_decode((string) $raw, true);

		return is_array($params) ? $params : [];
	}

	/**
	 * La liste des gabarits déjà déclarés, en tableau indexé.
	 *
	 * Le sous-formulaire peut être enregistré en objet ou en chaîne JSON
	 * selon le chemin d'écriture : les deux sont acceptés.
	 *
	 * @param  array $params
	 *
	 * @return array
	 */
	protected static function gabaritList(array $params): array
	{
		$brut = $params['gabaritsArticle'] ?? [];

		if (is_string($brut)) {
			$brut = $brut !== '' ? json_decode($brut, true) : [];
		}

		return is_array($brut) ? array_values($brut) : [];
	}

	/**
	 * Réécrit les réglages d'un style.
	 *
	 * @param  int   $styleId
	 * @param  array $params
	 *
	 * @return void
	 */
	protected static function saveStyleParams(int $styleId, array $params): void
	{
		$db   = Factory::getContainer()->get('DatabaseDriver');
		$json = json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

		$query = $db->getQuery(true)
			->update($db->quoteName('#__template_styles'))
			->set($db->quoteName('params') . ' = :params')
			->where($db->quoteName('id') . ' = :id')
			->bind(':params', $json)
			->bind(':id', $styleId, ParameterType::INTEGER);

		$db->setQuery($query)->execute();
	}

	/**
	 * Affecte un gabarit à une catégorie, par ses paramètres.
	 *
	 * On écrit dans la table plutôt que par le modèle : le champ
	 * `corpusGabarit` est greffé dans le formulaire par le plugin de Corpus,
	 * et un enregistrement sans requête ne le porterait pas.
	 *
	 * @param  int    $catId
	 * @param  string $cle
	 *
	 * @return void
	 */
	protected static function assignGabarit(int $catId, string $cle): void
	{
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName('params'))
			->from($db->quoteName('#__categories'))
			->where($db->quoteName('id') . ' = :id')
			->bind(':id', $catId, ParameterType::INTEGER);

		$db->setQuery($query);

		$params = self::decodeParams($db->loadResult());

		$params['corpusGabarit'] = $cle;

		$json  = json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
		$query = $db->getQuery(true)
			->update($db->quoteName('#__categories'))
			->set($db->quoteName('params') . ' = :params')
			->where($db->quoteName('id') . ' = :id')
			->bind(':params', $json)
			->bind(':id', $catId, ParameterType::INTEGER);

		$db->setQuery($query)->execute();
	}

	/**
	 * Coupe l'affichage automatique des champs placés par le gabarit.
	 *
	 * Sans cela Joomla les sort une seconde fois, en bas de l'article :
	 * c'est l'avertissement porté par la brique `champ` de Corpus.
	 *
	 * @param  int[] $ids
	 *
	 * @return void
	 */
	protected static function hideFieldsFromAutoDisplay(array $ids): void
	{
		$db = Factory::getContainer()->get('DatabaseDriver');

		foreach ($ids as $id) {
			$id = (int) $id;

			$query = $db->getQuery(true)
				->select($db->quoteName('params'))
				->from($db->quoteName('#__fields'))
				->where($db->quoteName('id') . ' = :id')
				->bind(':id', $id, ParameterType::INTEGER);

			$db->setQuery($query);

			$params = self::decodeParams($db->loadResult());

			$params['display'] = '0';

			$json  = json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
			$query = $db->getQuery(true)
				->update($db->quoteName('#__fields'))
				->set($db->quoteName('params') . ' = :params')
				->where($db->quoteName('id') . ' = :id')
				->bind(':params', $json)
				->bind(':id', $id, ParameterType::INTEGER);

			$db->setQuery($query)->execute();
		}
	}

	/**
	 * Crée le module « Recettes de saison », en position article-2.
	 *
	 * Sans lui, la troisième colonne de la rangée des étapes reste vide et la
	 * mise en page paraît cassée. Il porte la note du module : la
	 * réinitialisation le supprimera comme le reste.
	 *
	 * @param  int $catId Catégorie des recettes
	 *
	 * @return int
	 * @throws Exception
	 */
	protected static function createArticlesModule(int $catId): int
	{
		$model = self::getModel('com_modules', 'Module');

		$data = [
			'id'        => 0,
			'title'     => Text::_('MOD_CORPUS_START_MODULE_TITLE'),
			'module'    => 'mod_articles',
			'position'  => self::MODULE_POSITION,
			'published' => 1,
			'access'    => 1,
			'showtitle' => 1,
			'language'  => '*',
			'note'      => self::MARKER,
			'client_id' => 0,
			'assignment' => 0,
			'params'    => [
				'mode'                        => 'normal',
				'count'                       => '5',
				'category_filtering_type'     => '1',
				'catid'                       => [$catId],
				'show_child_category_articles' => '1',
				'levels'                      => '2',
				'show_front'                  => 'show',
				'show_introtext'              => '0',
				'item_heading'                => '4',
				'article_grouping'            => 'none',
				'ordering'                    => 'a.publish_up',
				'direction'                   => '1',
			],
		];

		if (!$model->save($data)) {
			throw new Exception('Module « Recettes de saison » : ' . $model->getError(), 500);
		}

		$id = (int) $model->getState('module.id');

		// Un module neuf n'est affecté à aucune page : sans cette ligne dans
		// #__modules_menu, il ne sort nulle part. 0 = toutes les pages.
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select('COUNT(*)')
			->from($db->quoteName('#__modules_menu'))
			->where($db->quoteName('moduleid') . ' = :id')
			->bind(':id', $id, ParameterType::INTEGER);

		$db->setQuery($query);

		if (!(int) $db->loadResult()) {
			$query = $db->getQuery(true)
				->insert($db->quoteName('#__modules_menu'))
				->columns($db->quoteName(['moduleid', 'menuid']))
				->values(':id, 0')
				->bind(':id', $id, ParameterType::INTEGER);

			$db->setQuery($query)->execute();
		}

		return $id;
	}

	// =====================================================================
	// LE MODULE DE MENU
	// =====================================================================

	/**
	 * Position de navigation de Corpus, déclarée dans templateDetails.xml.
	 */
	public const MENU_POSITION = 'menu';

	/**
	 * Pose le module de menu du site en position « menu », et le publie.
	 *
	 * CE MODULE N'EST PAS LE NÔTRE : on ne le marque donc pas, et on ne le
	 * supprimera jamais. On note son état d'avant dans les réglages de
	 * l'extension, et la réinitialisation le remet exactement comme il était.
	 *
	 * @param  string $menutype
	 *
	 * @return bool
	 */
	protected static function forceMenuPosition(string $menutype): bool
	{
		$db = Factory::getContainer()->get('DatabaseDriver');

		$query = $db->getQuery(true)
			->select($db->quoteName(['id', 'position', 'published', 'params']))
			->from($db->quoteName('#__modules'))
			->where($db->quoteName('client_id') . ' = 0')
			->where($db->quoteName('module') . ' = ' . $db->quote('mod_menu'))
			->order($db->quoteName('id') . ' ASC');

		$db->setQuery($query);

		$modules = (array) $db->loadObjectList();

		if (!$modules) {
			return false;
		}

		// Celui qui affiche le menu qu'on vient de garnir, sinon le premier.
		$cible = $modules[0];

		foreach ($modules as $module) {
			$params = self::decodeParams($module->params);

			if (($params['menutype'] ?? '') === $menutype) {
				$cible = $module;

				break;
			}
		}

		if ($cible->position === self::MENU_POSITION && (int) $cible->published === 1) {
			return true;
		}

		self::setExtensionParam('menuBackup', [
			'id'        => (int) $cible->id,
			'position'  => (string) $cible->position,
			'published' => (int) $cible->published,
		]);

		$id       = (int) $cible->id;
		$position = self::MENU_POSITION;

		$query = $db->getQuery(true)
			->update($db->quoteName('#__modules'))
			->set($db->quoteName('position') . ' = :position')
			->set($db->quoteName('published') . ' = 1')
			->where($db->quoteName('id') . ' = :id')
			->bind(':position', $position)
			->bind(':id', $id, ParameterType::INTEGER);

		$db->setQuery($query)->execute();

		return true;
	}

	/**
	 * Remet le module de menu là où il était avant l'installation.
	 *
	 * @return int
	 */
	protected static function restoreMenuPosition(): int
	{
		$backup = self::getExtensionParam('menuBackup');

		if (!is_array($backup) || empty($backup['id'])) {
			return 0;
		}

		$db        = Factory::getContainer()->get('DatabaseDriver');
		$id        = (int) $backup['id'];
		$position  = (string) $backup['position'];
		$published = (int) $backup['published'];

		$query = $db->getQuery(true)
			->update($db->quoteName('#__modules'))
			->set($db->quoteName('position') . ' = :position')
			->set($db->quoteName('published') . ' = :published')
			->where($db->quoteName('id') . ' = :id')
			->bind(':position', $position)
			->bind(':published', $published, ParameterType::INTEGER)
			->bind(':id', $id, ParameterType::INTEGER);

		$db->setQuery($query)->execute();

		self::setExtensionParam('menuBackup', null);

		return 1;
	}

	/**
	 * Lit un réglage de l'extension mod_corpus_start.
	 *
	 * Les réglages de l'EXTENSION, pas ceux d'une instance de module : il peut
	 * y avoir plusieurs instances, il n'y a qu'une extension.
	 *
	 * @param  string $cle
	 *
	 * @return mixed
	 */
	protected static function getExtensionParam(string $cle)
	{
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName('params'))
			->from($db->quoteName('#__extensions'))
			->where($db->quoteName('element') . ' = ' . $db->quote('mod_corpus_start'))
			->where($db->quoteName('type') . ' = ' . $db->quote('module'));

		$db->setQuery($query);

		$params = self::decodeParams($db->loadResult());

		return $params[$cle] ?? null;
	}

	/**
	 * Écrit un réglage de l'extension. Une valeur null l'efface.
	 *
	 * @param  string $cle
	 * @param  mixed  $valeur
	 *
	 * @return void
	 */
	protected static function setExtensionParam(string $cle, $valeur): void
	{
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName(['extension_id', 'params']))
			->from($db->quoteName('#__extensions'))
			->where($db->quoteName('element') . ' = ' . $db->quote('mod_corpus_start'))
			->where($db->quoteName('type') . ' = ' . $db->quote('module'));

		$db->setQuery($query);

		$ligne = $db->loadObject();

		if (!$ligne) {
			return;
		}

		$params = self::decodeParams($ligne->params);

		if ($valeur === null) {
			unset($params[$cle]);
		} else {
			$params[$cle] = $valeur;
		}

		$json = json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
		$id   = (int) $ligne->extension_id;

		$query = $db->getQuery(true)
			->update($db->quoteName('#__extensions'))
			->set($db->quoteName('params') . ' = :params')
			->where($db->quoteName('extension_id') . ' = :id')
			->bind(':params', $json)
			->bind(':id', $id, ParameterType::INTEGER);

		$db->setQuery($query)->execute();
	}

	// =====================================================================
	// LES PRÉRÉGLAGES DE MISE EN PAGE
	// =====================================================================

	/**
	 * Applique un préréglage de disposition de Corpus au style du site.
	 *
	 * LE PRÉRÉGLAGE EST LU DANS LE TEMPLATE INSTALLÉ, jamais recopié ici : ses
	 * quatre-vingt-seize clés changent d'une version de Corpus à l'autre, et
	 * une copie figée se périmerait sans prévenir. Le fichier vit dans
	 * templates/corpus/etc/presets/layouts/<nom>.nvp.
	 *
	 * Les valeurs d'avant sont notées dans les réglages de l'extension, clé
	 * par clé, y compris celles qui n'existaient pas : la réinitialisation
	 * doit pouvoir les retirer aussi bien que les rendre.
	 *
	 * @param  string $nom
	 *
	 * @return int Le nombre de clés écrites, 0 si le préréglage est absent
	 */
	protected static function applyPreset(string $nom): int
	{
		$fichier = JPATH_SITE . '/templates/corpus/etc/presets/layouts/' . $nom . '.nvp';

		if (!is_file($fichier)) {
			return 0;
		}

		$valeurs = self::lirePreset($fichier);

		if (!$valeurs) {
			return 0;
		}

		$style = self::getCorpusStyle();

		if (!$style) {
			return 0;
		}

		return self::applyStyleParams($valeurs);
	}

	/**
	 * Écrit des réglages dans le style du site, en notant ceux d'avant.
	 *
	 * La sauvegarde ne se laisse PAS écraser : si une clé y figure déjà, on
	 * garde la valeur la plus ancienne. Sans cela, un préréglage appliqué puis
	 * quelques réglages posés par-dessus feraient perdre l'état d'origine, et
	 * la réinitialisation rendrait un état intermédiaire qui n'a jamais existé.
	 *
	 * @param  array<string, mixed> $valeurs
	 *
	 * @return int
	 */
	protected static function applyStyleParams(array $valeurs): int
	{
		if (!$valeurs) {
			return 0;
		}

		$style = self::getCorpusStyle();

		if (!$style) {
			return 0;
		}

		$params     = self::decodeParams($style->params);
		$sauvegarde = self::getExtensionParam('presetBackup');
		$sauvegarde = is_array($sauvegarde) ? $sauvegarde : [];

		foreach ($valeurs as $cle => $valeur) {
			if (!array_key_exists($cle, $sauvegarde)) {
				// null note une clé qui n'existait pas : il faudra la retirer.
				$sauvegarde[$cle] = array_key_exists($cle, $params) ? $params[$cle] : null;
			}

			$params[$cle] = $valeur;
		}

		self::setExtensionParam('presetBackup', $sauvegarde);
		self::saveStyleParams((int) $style->id, $params);

		return count($valeurs);
	}

	/**
	 * Rend au style ses réglages de disposition d'avant.
	 *
	 * @return int
	 */
	protected static function restorePreset(): int
	{
		$sauvegarde = self::getExtensionParam('presetBackup');

		if (!is_array($sauvegarde) || !$sauvegarde) {
			return 0;
		}

		$style = self::getCorpusStyle();

		if (!$style) {
			return 0;
		}

		$params = self::decodeParams($style->params);

		foreach ($sauvegarde as $cle => $valeur) {
			if ($valeur === null) {
				unset($params[$cle]);
			} else {
				$params[$cle] = $valeur;
			}
		}

		self::saveStyleParams((int) $style->id, $params);
		self::setExtensionParam('presetBackup', null);

		return count($sauvegarde);
	}

	/**
	 * Lit un fichier .nvp : des paires « clé: valeur », une par ligne.
	 *
	 * Les lignes qui commencent par # sont des commentaires, et la première
	 * ligne utile est l'intitulé du préréglage, sans deux-points. Une valeur
	 * peut être vide, ce qui a un sens : elle remet la clé au défaut.
	 *
	 * @param  string $fichier
	 *
	 * @return array<string, string>
	 */
	protected static function lirePreset(string $fichier): array
	{
		$lignes  = (array) @file($fichier, FILE_IGNORE_NEW_LINES);
		$valeurs = [];

		foreach ($lignes as $ligne) {
			$ligne = trim((string) $ligne);

			if ($ligne === '' || $ligne[0] === '#' || strpos($ligne, ':') === false) {
				continue;
			}

			[$cle, $valeur] = explode(':', $ligne, 2);

			$cle = trim($cle);

			if ($cle === '') {
				continue;
			}

			$valeurs[$cle] = trim($valeur);
		}

		return $valeurs;
	}

	// =====================================================================
	// LES IMAGES
	// =====================================================================

	/**
	 * Dossier d'arrivée des images, sous la racine du site.
	 */
	public const IMAGES_DIR = 'images/corpus-start';

	/**
	 * Copie les images livrées dans le module vers images/corpus-start.
	 *
	 * @return int Le nombre de fichiers copiés
	 */
	protected static function copyImages(): int
	{
		$source = __DIR__ . '/images';

		if (!is_dir($source)) {
			return 0;
		}

		$cible = JPATH_SITE . '/' . self::IMAGES_DIR;

		if (!is_dir($cible) && !@mkdir($cible, 0755, true) && !is_dir($cible)) {
			return 0;
		}

		$copies = 0;

		foreach ((array) glob($source . '/*.webp') as $fichier) {
			if (@copy($fichier, $cible . '/' . basename($fichier))) {
				$copies++;
			}
		}

		return $copies;
	}

	/**
	 * Supprime les images copiées, et le dossier s'il ne reste rien.
	 *
	 * Ne supprime QUE les fichiers livrés par le module : une image que
	 * l'utilisateur aurait déposée dans ce dossier reste en place, et le
	 * dossier avec elle.
	 *
	 * @return int
	 */
	protected static function removeImages(): int
	{
		$source = __DIR__ . '/images';
		$cible  = JPATH_SITE . '/' . self::IMAGES_DIR;

		if (!is_dir($source) || !is_dir($cible)) {
			return 0;
		}

		$supprimes = 0;

		foreach ((array) glob($source . '/*.webp') as $fichier) {
			$chemin = $cible . '/' . basename($fichier);

			if (is_file($chemin) && @unlink($chemin)) {
				$supprimes++;
			}
		}

		$reste = array_diff((array) scandir($cible), ['.', '..']);

		if (!$reste) {
			@rmdir($cible);
		}

		return $supprimes;
	}

	/**
	 * Crée une catégorie de contenu marquée.
	 *
	 * @param  string $title
	 * @param  string $alias
	 * @param  int    $parentId
	 *
	 * @return int
	 * @throws Exception
	 */
	protected static function createCategory(string $title, string $alias, int $parentId): int
	{
		$model = self::getModel('com_categories', 'Category');

		$data = [
			'id'          => 0,
			'title'       => $title,
			'alias'       => $alias,
			'parent_id'   => $parentId,
			'extension'   => 'com_content',
			'published'   => 1,
			'access'      => 1,
			'language'    => '*',
			'description' => '',
			'note'        => self::MARKER,
			'params'      => '{}',
			'metadata'    => '{}',
		];

		if (!$model->save($data)) {
			throw new Exception('Catégorie « ' . $title . " » : " . $model->getError(), 500);
		}

		return (int) $model->getState('category.id');
	}

	/**
	 * Crée le groupe de champs qui porte le bloc « En bref ».
	 *
	 * @param  string $title
	 *
	 * @return int
	 * @throws Exception
	 */
	protected static function createFieldGroup(string $title): int
	{
		$model = self::getModel('com_fields', 'Group');

		$data = [
			'id'          => 0,
			'title'       => $title,
			'context'     => 'com_content.article',
			'state'       => 1,
			'access'      => 1,
			'language'    => '*',
			'description' => '',
			'note'        => self::MARKER,
			'params'      => '{}',
		];

		if (!$model->save($data)) {
			throw new Exception('Groupe de champs : ' . $model->getError(), 500);
		}

		return (int) $model->getState('group.id');
	}

	/**
	 * Crée un champ personnalisé marqué.
	 *
	 * @param  string   $name
	 * @param  string   $title
	 * @param  string   $type
	 * @param  int      $groupId
	 * @param  string[] $options
	 *
	 * @return int
	 * @throws Exception
	 */
	protected static function createField(string $name, string $title, string $type, int $groupId, array $options = [], string $suffix = ''): int
	{
		$model = self::getModel('com_fields', 'Field');

		$params = [
			'hint'                => '',
			'class'               => '',
			'label_class'         => '',
			'show_on'             => '',
			'render_class'        => '',
			'showlabel'           => '1',
			'label_render_class'  => '',
			'display'             => '2',
			'prefix'              => '',
			'suffix'              => $suffix,
			'layout'              => '',
			'display_readonly'    => '2',
		];

		$fieldparams = [];

		if ($type === 'list' && $options) {
			$values = [];
			$i      = 0;

			foreach ($options as $option) {
				$values['options' . $i] = [
					'name'  => $option,
					'value' => $option,
				];
				$i++;
			}

			$fieldparams['options'] = $values;
		}

		if ($type === 'textarea') {
			$fieldparams['rows']   = '5';
			$fieldparams['cols']   = '30';
			$fieldparams['filter'] = 'safehtml';
		}

		$data = [
			'id'          => 0,
			'title'       => $title,
			'name'        => $name,
			'label'       => $title,
			'type'        => $type,
			'context'     => 'com_content.article',
			'group_id'    => $groupId,
			'state'       => 1,
			'access'      => 1,
			'language'    => '*',
			'required'    => 0,
			'description' => '',
			'note'        => self::MARKER,
			'params'      => $params,
			'fieldparams' => $fieldparams,
		];

		if (!$model->save($data)) {
			throw new Exception('Champ « ' . $title . " » : " . $model->getError(), 500);
		}

		return (int) $model->getState('field.id');
	}

	/**
	 * Crée un article marqué.
	 *
	 * Le corps suit le gabarit recette : introduction, coupure « lire la
	 * suite », puis le bloc des étapes. Un article sans étapes (les articles
	 * du potager) n'a pas de texte complet.
	 *
	 * @param  array $article
	 * @param  int   $catId
	 *
	 * @return int
	 * @throws Exception
	 */
	protected static function createArticle(array $article, int $catId): int
	{
		$model = self::getModel('com_content', 'Article');

		$fulltext = '';

		if (!empty($article['body'])) {
			// Une page rédigée d'un bloc : pas de titre « Les étapes ».
			$fulltext = $article['body'];
		} elseif (!empty($article['steps'])) {
			$fulltext = '<h2>' . Text::_('MOD_CORPUS_START_STEPS') . "</h2>\n<ol class=\"etapes\">\n";

			foreach ($article['steps'] as $step) {
				$fulltext .= "\t<li>" . $step . "</li>\n";
			}

			$fulltext .= '</ol>';
		}

		$data = [
			'id'        => 0,
			'title'     => $article['title'],
			'alias'     => $article['alias'],
			'catid'     => $catId,
			'articletext' => $article['intro'] . ($fulltext !== '' ? '<hr id="system-readmore">' . $fulltext : ''),
			'state'     => 1,
			'access'    => 1,
			'language'  => $article['language'] ?? '*',
			'featured'  => (int) ($article['featured'] ?? 0),
			'note'      => self::MARKER,
			'metadesc'  => '',
			'metakey'   => '',
			'images'    => self::imagesJson($article),
			'urls'      => '{}',
			'attribs'   => '{}',
			'metadata'  => '{}',
		];

		if (!empty($article['tags'])) {
			// « #new# » crée le tag au passage s'il n'existe pas encore.
			$data['tags'] = array_map(
				static fn ($tag) => '#new#' . $tag,
				$article['tags']
			);
		}

		if (!$model->save($data)) {
			throw new Exception('Article « ' . $article['title'] . " » : " . $model->getError(), 500);
		}

		return (int) $model->getState('article.id');
	}

	/**
	 * Le champ `images` d'un article, au format de Joomla.
	 *
	 * L'image n'est posée que si le fichier a bien été copié : un chemin
	 * vers une image absente afficherait un cadre cassé sur le site.
	 *
	 * @param  array $article
	 *
	 * @return string
	 */
	protected static function imagesJson(array $article): string
	{
		if (empty($article['image'])) {
			return '{}';
		}

		$chemin = self::IMAGES_DIR . '/' . $article['image'];

		if (!is_file(JPATH_SITE . '/' . $chemin)) {
			return '{}';
		}

		$alt = $article['imageAlt'] ?? $article['title'];

		return json_encode(
			[
				'image_intro'             => $chemin,
				'image_intro_alt'         => $alt,
				'float_intro'             => 'none',
				'image_intro_caption'     => '',
				'image_fulltext'          => $chemin,
				'image_fulltext_alt'      => $alt,
				// « none » et non '' : une valeur vide laisse le réglage global du
				// composant décider, et il vaut « left ». L'image flotterait alors à
				// gauche, à sa taille naturelle, au lieu de remplir sa colonne.
				'float_fulltext'          => 'none',
				'image_fulltext_caption'  => '',
			],
			JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
		);
	}

	/**
	 * Enregistre les valeurs des champs personnalisés d'un article.
	 *
	 * @param  int   $articleId
	 * @param  array $values
	 * @param  array $fieldIds
	 *
	 * @return void
	 */
	protected static function saveFieldValues(int $articleId, array $values, array $fieldIds): void
	{
		$model = self::getModel('com_fields', 'Field');

		foreach ($values as $name => $value) {
			if (empty($fieldIds[$name])) {
				continue;
			}

			if (is_array($value)) {
				// Liste d'ingrédients : une ligne par ingrédient.
				$value = '<ul>' . implode('', array_map(static fn ($v) => '<li>' . $v . '</li>', $value)) . '</ul>';
			}

			$model->setFieldValue($fieldIds[$name], $articleId, $value);
		}
	}

	/**
	 * Renvoie le menutype du menu de site à garnir, ou '' si aucun.
	 *
	 * On garnit un menu existant plutôt que d'en créer un : un menu neuf
	 * serait invisible sans module de menu à créer en plus.
	 *
	 * @return string
	 */
	protected static function getSiteMenutype(): string
	{
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName('menutype'))
			->from($db->quoteName('#__menu_types'))
			->where($db->quoteName('client_id') . ' = 0')
			->order($db->quoteName('id') . ' ASC');

		$db->setQuery($query, 0, 1);

		return (string) $db->loadResult();
	}

	/**
	 * Crée un élément de menu « Blog d'une catégorie » marqué.
	 *
	 * @param  string $menutype
	 * @param  string $title
	 * @param  string $alias
	 * @param  int    $catId
	 *
	 * @return int
	 * @throws Exception
	 */
	protected static function createMenuItem(string $menutype, array $item, array $catIds, array $articleIds, array $menuIds): int
	{
		$type      = $item['type'] ?? 'category';
		$link      = '';
		$component = 'com_content';

		switch ($type) {
			case 'featured':
				$link = 'index.php?option=com_content&view=featured';
				break;

			case 'category':
				if (empty($catIds[$item['category']])) {
					return 0;
				}

				$link = 'index.php?option=com_content&view=category&layout=blog&id=' . (int) $catIds[$item['category']];
				break;

			case 'article':
				if (empty($articleIds[$item['article']])) {
					return 0;
				}

				$link = 'index.php?option=com_content&view=article&id=' . (int) $articleIds[$item['article']];
				break;

			case 'url':
				$link      = (string) ($item['link'] ?? '');
				$component = (string) ($item['component'] ?? 'com_content');
				break;

			case 'heading':
				// Type natif de Joomla : une entrée qui n'ouvre rien. C'est
				// elle qui porte une colonne du méga-menu.
				$link = '';
				break;
		}

		$parentId = 1;

		if (!empty($item['parent'])) {
			if (empty($menuIds[$item['parent']])) {
				return 0;
			}

			$parentId = (int) $menuIds[$item['parent']];
		}

		$params = [];

		if (!empty($item['mega'])) {
			/*
			 * LE DÉCLENCHEUR DU MÉGA-MENU DE CORPUS : le mot « mega » dans le
			 * champ natif « Style CSS du lien », sur une entrée de PREMIER
			 * niveau. Pas dans « Classe d'icône de lien », qui porte déjà les
			 * pictogrammes. Les entrées filles deviennent les colonnes.
			 */
			$params['menu-anchor_css'] = 'mega';
		}

		if (!empty($item['params'])) {
			$params = array_merge($params, $item['params']);
		}

		$data = [
			'id'           => 0,
			'title'        => $item['title'],
			'alias'        => $item['alias'] ?? self::alias($item['title']),
			'menutype'     => $menutype,
			'type'         => $type === 'heading' ? 'heading' : 'component',
			'link'         => $link,
			'component_id' => $type === 'heading' ? 0 : self::getComponentId($component),
			'parent_id'    => $parentId,
			'published'    => 1,
			'access'       => 1,
			'language'     => '*',
			'note'         => self::MARKER,
			'params'       => $params,
			'client_id'    => 0,
		];

		$model = self::getModel('com_menus', 'Item');

		if (!$model->save($data)) {
			throw new Exception('Élément de menu « ' . $item['title'] . " » : " . $model->getError(), 500);
		}

		return (int) $model->getState('item.id');
	}

	/**
	 * Un alias d'URL à partir d'un intitulé.
	 *
	 * @param  string $titre
	 *
	 * @return string
	 */
	protected static function alias(string $titre): string
	{
		return \Joomla\CMS\Filter\OutputFilter::stringUrlSafe($titre);
	}

	// =====================================================================
	// MISES EN AVANT, MODULES, PAGE D'ACCUEIL
	// =====================================================================

	/**
	 * Met des articles en vedette, par leur alias.
	 *
	 * On passe par le modèle et non par une requête : la mise en vedette
	 * s'écrit dans DEUX tables, `#__content` et `#__content_frontpage`, et
	 * n'écrire que la première laisse un article invisible sur l'accueil.
	 *
	 * @param  string[] $aliases
	 * @param  array    $articleIds
	 *
	 * @return int
	 */
	protected static function setFeatured(array $aliases, array $articleIds): int
	{
		$ids = [];

		foreach ($aliases as $alias) {
			if (!empty($articleIds[$alias])) {
				$ids[] = (int) $articleIds[$alias];
			}
		}

		if (!$ids) {
			return 0;
		}

		$model = self::getModel('com_content', 'Article');

		if (method_exists($model, 'featured')) {
			$model->featured($ids, 1);
		}

		return count($ids);
	}

	/**
	 * Crée un module de site marqué.
	 *
	 * ÉCRIRE LES PARAMÈTRES À LA MAIN NE DONNE AUCUN DÉFAUT. Un module créé
	 * par le formulaire reçoit les valeurs par défaut déclarées dans son
	 * manifeste ; un module créé ici ne reçoit QUE ce qu'on lui donne, et
	 * toute clé absente vaut null. C'est ce qui a vidé les listes d'articles :
	 * `item_title` valait null au lieu de 1, et le gabarit de Joomla saute
	 * l'entrée quand aucune option d'affichage n'est allumée. Il faut donc
	 * énumérer les réglages d'affichage, sans en supposer aucun.
	 *
	 * @param  array $module
	 * @param  array $catIds
	 * @param  array $articleIds
	 *
	 * @return int
	 * @throws Exception
	 */
	protected static function createModule(array $module, array $catIds, array $articleIds, int $accueilId = 0): int
	{
		// Les identifiants n'existent pas quand le fichier de contenu est lu :
		// il y écrit des repères, {lien:…}, {cat:…} et {art:…}, qu'on remplace
		// ici par les vraies valeurs. La résolution parcourt TOUS les
		// paramètres, et pas seulement le contenu : `catid` d'un module
		// d'articles en a besoin autant qu'un lien dans du HTML.
		$params = self::resoudreParams($module['params'] ?? [], $catIds, $articleIds);

		/*
		 * LE CONTENU D'UN MODULE PERSONNALISÉ N'EST PAS UN PARAMÈTRE.
		 * mod_custom affiche `$module->content`, une COLONNE de la table, et
		 * ignore complètement un `content` rangé dans les paramètres. Le
		 * module s'affichait donc, vide, sans la moindre erreur.
		 */
		$contenu = (string) self::resoudreParams($module['content'] ?? '', $catIds, $articleIds);

		$data = [
			'id'        => 0,
			'title'     => $module['title'],
			'module'    => $module['module'],
			'position'  => $module['position'],
			'content'   => $contenu,
			'published' => 1,
			'access'    => 1,
			'showtitle' => (int) ($module['showtitle'] ?? 1),
			'language'  => '*',
			'note'      => self::MARKER,
			'client_id' => 0,
			'params'    => $params,
		];

		$model = self::getModel('com_modules', 'Module');

		if (!$model->save($data)) {
			throw new Exception('Module « ' . $module['title'] . " » : " . $model->getError(), 500);
		}

		$id = (int) $model->getState('module.id');

		self::affecterModuleAuxPages($id, $module['pages'] ?? 'all', $accueilId);

		return $id;
	}

	/**
	 * Résout les repères dans un arbre de paramètres, à toute profondeur.
	 *
	 * {cat:cle} et {art:cle} rendent un identifiant, et non une adresse : ce
	 * sont des valeurs de champs, pas du texte. Un paramètre qui vaut
	 * exactement un repère devient donc un entier, alors qu'un repère au
	 * milieu d'une phrase reste dans sa chaîne.
	 *
	 * @param  mixed $valeur
	 * @param  array $catIds
	 * @param  array $articleIds
	 *
	 * @return mixed
	 */
	protected static function resoudreParams($valeur, array $catIds, array $articleIds)
	{
		if (is_array($valeur)) {
			foreach ($valeur as $cle => $sous) {
				$valeur[$cle] = self::resoudreParams($sous, $catIds, $articleIds);
			}

			return $valeur;
		}

		if (!is_string($valeur) || strpos($valeur, '{') === false) {
			return $valeur;
		}

		if (preg_match('/^\{(cat|art):([a-z0-9\-]+)\}$/i', $valeur, $trouve)) {
			$table = $trouve[1] === 'cat' ? $catIds : $articleIds;

			return (int) ($table[$trouve[2]] ?? 0);
		}

		return self::resoudreLiens($valeur, $catIds, $articleIds);
	}

	/**
	 * Remplace {lien:cle} par une vraie adresse.
	 *
	 * @param  string $html
	 * @param  array  $catIds
	 * @param  array  $articleIds
	 *
	 * @return string
	 */
	protected static function resoudreLiens(string $html, array $catIds, array $articleIds): string
	{
		// {cat:x} et {art:x} rendent un identifiant nu, utile dans une liste
		// d'identifiants séparés par des virgules.
		$html = (string) preg_replace_callback(
			'/\{(cat|art):([a-z0-9\-]+)\}/i',
			static function ($trouve) use ($catIds, $articleIds) {
				$table = $trouve[1] === 'cat' ? $catIds : $articleIds;

				return (string) (int) ($table[$trouve[2]] ?? 0);
			},
			$html
		);

		return (string) preg_replace_callback(
			'/\{lien:([a-z0-9\-]+)\}/i',
			static function ($trouve) use ($catIds, $articleIds) {
				$cle = $trouve[1];

				if (!empty($articleIds[$cle])) {
					return 'index.php?option=com_content&view=article&id=' . (int) $articleIds[$cle];
				}

				if (!empty($catIds[$cle])) {
					return 'index.php?option=com_content&view=category&layout=blog&id=' . (int) $catIds[$cle];
				}

				return '#';
			},
			$html
		);
	}

	/**
	 * Dit sur quelles pages un module sort.
	 *
	 * SANS LIGNE DANS `#__modules_menu`, UN MODULE NE SORT NULLE PART. Un
	 * module neuf n'est affecté à aucune page, et rien ne le signale.
	 * menuid 0 vaut « toutes les pages ».
	 *
	 * @param  int    $moduleId
	 * @param  string $pages  'all' ou 'home'
	 *
	 * @return void
	 */
	protected static function affecterModuleAuxPages(int $moduleId, string $pages, int $accueilId = 0): void
	{
		$db = Factory::getContainer()->get('DatabaseDriver');

		$query = $db->getQuery(true)
			->delete($db->quoteName('#__modules_menu'))
			->where($db->quoteName('moduleid') . ' = :id')
			->bind(':id', $moduleId, ParameterType::INTEGER);

		$db->setQuery($query)->execute();

		// 0 vaut « toutes les pages ». Sinon, la seule entrée d'accueil.
		$cibles = ($pages === 'home' && $accueilId) ? [$accueilId] : [0];

		foreach ($cibles as $cible) {
			$cible = (int) $cible;

			$query = $db->getQuery(true)
				->insert($db->quoteName('#__modules_menu'))
				->columns($db->quoteName(['moduleid', 'menuid']))
				->values(':module, :menu')
				->bind(':module', $moduleId, ParameterType::INTEGER)
				->bind(':menu', $cible, ParameterType::INTEGER);

			$db->setQuery($query)->execute();
		}
	}

	/**
	 * Passe une entrée de menu en page d'accueil du site.
	 *
	 * CELLE DE L'UTILISATEUR N'EST PAS LA NÔTRE : on la rétrograde, on note
	 * son identifiant dans les réglages de l'extension, et la
	 * réinitialisation la remet en place. Joomla n'accepte qu'une seule page
	 * par défaut par langue, il faut donc bien déloger l'ancienne.
	 *
	 * @param  int $itemId
	 *
	 * @return int
	 */
	protected static function setHome(int $itemId): int
	{
		$db = Factory::getContainer()->get('DatabaseDriver');

		$query = $db->getQuery(true)
			->select($db->quoteName('id'))
			->from($db->quoteName('#__menu'))
			->where($db->quoteName('home') . ' = 1')
			->where($db->quoteName('client_id') . ' = 0')
			->where($db->quoteName('language') . ' = ' . $db->quote('*'));

		$db->setQuery($query);

		$ancienne = (int) $db->loadResult();

		if ($ancienne === $itemId) {
			return 0;
		}

		if ($ancienne) {
			self::setExtensionParam('homeBackup', $ancienne);

			/*
			 * ON LA DÉPUBLIE AUSSI, et pas seulement rétrograde. Rétrogradée
			 * seule, elle reste dans le menu : le site affiche alors deux
			 * entrées d'accueil côte à côte, « Home » et « Accueil ». La
			 * réinitialisation la republie.
			 */
			$query = $db->getQuery(true)
				->update($db->quoteName('#__menu'))
				->set($db->quoteName('home') . ' = 0')
				->set($db->quoteName('published') . ' = 0')
				->where($db->quoteName('id') . ' = :id')
				->bind(':id', $ancienne, ParameterType::INTEGER);

			$db->setQuery($query)->execute();
		}

		$query = $db->getQuery(true)
			->update($db->quoteName('#__menu'))
			->set($db->quoteName('home') . ' = 1')
			->where($db->quoteName('id') . ' = :id')
			->bind(':id', $itemId, ParameterType::INTEGER);

		$db->setQuery($query)->execute();

		return 1;
	}

	/**
	 * Rend à l'utilisateur sa page d'accueil.
	 *
	 * Appelée AVANT la suppression des entrées de menu : sinon Joomla se
	 * retrouve un instant sans aucune page par défaut.
	 *
	 * @return int
	 */
	protected static function restoreHome(): int
	{
		$ancienne = (int) self::getExtensionParam('homeBackup');

		if (!$ancienne) {
			return 0;
		}

		$db = Factory::getContainer()->get('DatabaseDriver');

		$query = $db->getQuery(true)
			->update($db->quoteName('#__menu'))
			->set($db->quoteName('home') . ' = 0')
			->where($db->quoteName('client_id') . ' = 0')
			->where($db->quoteName('language') . ' = ' . $db->quote('*'));

		$db->setQuery($query)->execute();

		$query = $db->getQuery(true)
			->update($db->quoteName('#__menu'))
			->set($db->quoteName('home') . ' = 1')
			->set($db->quoteName('published') . ' = 1')
			->where($db->quoteName('id') . ' = :id')
			->bind(':id', $ancienne, ParameterType::INTEGER);

		$db->setQuery($query)->execute();

		self::setExtensionParam('homeBackup', null);

		return 1;
	}

	// =====================================================================
	// RÉINITIALISATION
	// =====================================================================

	/**
	 * Supprime tout ce que le module a créé, et rien d'autre.
	 *
	 * L'ordre compte : articles avant catégories (une catégorie non vide ne
	 * se supprime pas), éléments de menu avant catégories aussi.
	 *
	 * @return array
	 * @throws Exception
	 */
	protected static function reset(): array
	{
		$counts = [];

		// D'ABORD rendre sa page d'accueil : supprimer nos entrées de menu
		// alors que l'une d'elles est encore la page par défaut laisserait
		// Joomla sans aucune page d'accueil.
		$counts['accueil']    = self::restoreHome();
		$counts['menu']       = self::deleteMarked('com_menus', 'Item', '#__menu', 'published');
		$counts['modules']    = self::deleteMarked('com_modules', 'Module', '#__modules', 'published');
		$counts['articles']   = self::deleteMarked('com_content', 'Article', '#__content', 'state');
		$counts['categories'] = self::deleteMarkedCategories();
		$counts['fields']     = self::deleteMarked('com_fields', 'Field', '#__fields', 'state');
		$counts['groups']     = self::deleteMarked('com_fields', 'Group', '#__fields_groups', 'state');
		$counts['gabarit']    = self::removeGabarit();
		$counts['preset']     = self::restorePreset();
		$counts['images']     = self::removeImages();
		$counts['menuModule'] = self::restoreMenuPosition();

		return [
			'task'    => 'reset',
			'counts'  => $counts,
			'message' => Text::sprintf(
				'MOD_CORPUS_START_RESET_DONE',
				$counts['articles'],
				$counts['categories'],
				$counts['fields'] + $counts['groups'],
				$counts['menu']
			),
		];
	}

	/**
	 * Supprime les éléments marqués d'une table via son modèle.
	 *
	 * Joomla refuse de supprimer un élément qui n'est pas à la corbeille :
	 * on le passe donc en état -2 avant.
	 *
	 * @param  string $component
	 * @param  string $modelName
	 * @param  string $table
	 * @param  string $stateColumn
	 *
	 * @return int
	 */
	protected static function deleteMarked(string $component, string $modelName, string $table, string $stateColumn): int
	{
		$ids = self::getMarkedIds($table);

		if (!$ids) {
			return 0;
		}

		$model = self::getModel($component, $modelName);

		self::trash($table, $stateColumn, $ids);

		$pks = $ids;
		$model->delete($pks);

		return count($ids) - count(self::getMarkedIds($table));
	}

	/**
	 * Supprime les catégories marquées, enfants d'abord.
	 *
	 * @return int
	 */
	protected static function deleteMarkedCategories(): int
	{
		$db     = Factory::getContainer()->get('DatabaseDriver');
		$marker = self::MARKER;

		$query = $db->getQuery(true)
			->select($db->quoteName('id'))
			->from($db->quoteName('#__categories'))
			->where($db->quoteName('note') . ' = :note')
			->order($db->quoteName('level') . ' DESC')
			->bind(':note', $marker);

		$db->setQuery($query);

		$ids = (array) $db->loadColumn();

		if (!$ids) {
			return 0;
		}

		$model   = self::getModel('com_categories', 'Category');
		$deleted = 0;

		foreach ($ids as $id) {
			self::trash('#__categories', 'published', [(int) $id]);

			$pks = [(int) $id];

			if ($model->delete($pks)) {
				$deleted++;
			}
		}

		return $deleted;
	}

	/**
	 * Passe des lignes à l'état corbeille (-2), condition de suppression.
	 *
	 * @param  string $table
	 * @param  string $column
	 * @param  int[]  $ids
	 *
	 * @return void
	 */
	protected static function trash(string $table, string $column, array $ids): void
	{
		$ids = array_map('intval', $ids);

		if (!$ids) {
			return;
		}

		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->update($db->quoteName($table))
			->set($db->quoteName($column) . ' = -2')
			->whereIn($db->quoteName('id'), $ids);

		$db->setQuery($query)->execute();
	}

	/**
	 * Identifiants des lignes marquées d'une table.
	 *
	 * @param  string $table
	 *
	 * @return int[]
	 */
	protected static function getMarkedIds(string $table): array
	{
		$db     = Factory::getContainer()->get('DatabaseDriver');
		$marker = self::MARKER;

		$query = $db->getQuery(true)
			->select($db->quoteName('id'))
			->from($db->quoteName($table))
			->where($db->quoteName('note') . ' = :note')
			->bind(':note', $marker);

		$db->setQuery($query);

		return array_map('intval', (array) $db->loadColumn());
	}

	/**
	 * Nombre de lignes marquées d'une table.
	 *
	 * @param  string $table
	 *
	 * @return int
	 */
	protected static function countMarked(string $table): int
	{
		return count(self::getMarkedIds($table));
	}

	// =====================================================================
	// OUTILS
	// =====================================================================

	/**
	 * Renvoie un modèle d'administration d'un composant.
	 *
	 * @param  string $component
	 * @param  string $name
	 *
	 * @return \Joomla\CMS\MVC\Model\AdminModel
	 * @throws Exception
	 */
	protected static function getModel(string $component, string $name)
	{
		$model = Factory::getApplication()
			->bootComponent($component)
			->getMVCFactory()
			->createModel($name, 'Administrator', ['ignore_request' => true]);

		if (!$model) {
			throw new Exception('Modèle introuvable : ' . $component . '/' . $name, 500);
		}

		return $model;
	}

	/**
	 * Identifiant d'extension d'un composant, pour les éléments de menu.
	 *
	 * @param  string $element
	 *
	 * @return int
	 */
	protected static function getComponentId(string $element): int
	{
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName('extension_id'))
			->from($db->quoteName('#__extensions'))
			->where($db->quoteName('element') . ' = :element')
			->where($db->quoteName('type') . ' = ' . $db->quote('component'))
			->bind(':element', $element);

		$db->setQuery($query);

		return (int) $db->loadResult();
	}
}
