<?php

/**
 * @package     plg_system_iris
 * @copyright   (C) 2026 Cyrille
 * @license     GPL v2 or later
 *
 * Affiche une pastille "utilisé / non utilisé" sur les miniatures du
 * gestionnaire de média, des compteurs sur les dossiers, et fournit
 * un rapport des fichiers inutilisés.
 */

namespace Cyrille\Plugin\System\Iris\Extension;

\defined('_JEXEC') or die;

use Cyrille\Plugin\System\Iris\Veille\Noyau;
use Joomla\CMS\Document\HtmlDocument;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Event\Event;
use Joomla\Event\SubscriberInterface;

final class Iris extends CMSPlugin implements SubscriberInterface
{
    use DatabaseAwareTrait;

    /** Version installée, affichée dans l'écran de configuration. */
    public const VERSION = '1.7.1';

    /**
     * Colonnes de la base scannées par défaut (table => colonnes).
     * Toutes sont facultatives : une table absente est ignorée.
     */
    private const DEFAULT_COLUMNS = [
        '#__content'         => ['introtext', 'fulltext', 'images'],
        '#__categories'      => ['description', 'params'],
        '#__modules'         => ['content', 'params'],
        '#__menu'            => ['params'],
        '#__fields_values'   => ['value'],
        '#__fields'          => ['default_value'],
        '#__contact_details' => ['image', 'misc'],
        '#__banners'         => ['params', 'description'],
        '#__newsfeeds'       => ['params', 'images', 'description'],
        '#__tags'            => ['description', 'images', 'params'],
        '#__template_styles' => ['params'],
        '#__users'           => ['params'],
        // Droptables (JoomUnited) : contenu des tableaux, images en chemins classiques
        '#__droptables'      => ['datas', 'params'],
        // SP Page Builder (JoomShaper) : pages, sections et médiathèque
        '#__sppagebuilder'          => ['text', 'content', 'css'],
        '#__sppagebuilder_sections' => ['section', 'content'],
        '#__spmedia'                => ['path', 'thumbnail'],
    ];

    private const IGNORE_NAMES = ['index.html', '.htaccess', 'web.config'];

    public static function getSubscribedEvents(): array
    {
        return [
            'onBeforeCompileHead' => 'injectAssets',
            'onAjaxIris'    => 'handleAjax',
            'onBeforeRender' => 'veillerSurLeNoyau',
        ];
    }

    /**
     * LA VEILLE SUR LE NOYAU, le 13 septembre 2026, demandée par Cyrille.
     *
     * Iris n'est suivi que sur la dernière version de la branche 6 de Joomla. Un
     * client qui laisse son site en arrière ne le sait pas : rien, dans Joomla,
     * ne lui dit que l'extension qu'il a payée n'est plus couverte. On le lui
     * dit donc ici, une fois, là où il peut agir.
     *
     * L'ÉTAT EST CALCULÉ AILLEURS (Veille\Noyau), parce que ce fichier-là se
     * recopie tel quel dans les autres produits. Ici, il ne reste que le choix
     * du moment et celui du destinataire.
     *
     * ON NE PARLE QU'À QUI PEUT AGIR. Un rédacteur qui n'a pas le droit
     * d'installer une mise à jour n'y peut rien : lui afficher l'alerte
     * l'inquiète et ne répare pas le site.
     *
     * UNE FOIS PAR SESSION, PAS PAR PAGE. Un message répété à chaque écran cesse
     * d'être lu au troisième, et c'est pire que pas de message.
     *
     * PAS SUR L'ÉCRAN DE MISE À JOUR DU CŒUR : il affiche déjà, en grand, ce que
     * nous dirions en petit. Pas dans une fenêtre modale non plus (`tmpl=component`),
     * où la file des messages s'affiche par-dessus le contenu.
     *
     * AUCUN RÉGLAGE POUR L'ÉTEINDRE, et c'est voulu : un avertissement qu'on peut
     * taire finit toujours tu, et le jour où le site casse, personne n'aura été
     * prévenu.
     */
    public function veillerSurLeNoyau(): void
    {
        $app = $this->getApplication();

        if (!$app->isClient('administrator')) {
            return;
        }

        $input = $app->getInput();

        if ($input->getCmd('option') === 'com_joomlaupdate' || $input->getCmd('tmpl') === 'component') {
            return;
        }

        if (!$app->getDocument() instanceof HtmlDocument) {
            return;
        }

        $session = $app->getSession();

        if ($session->get('iris.veille.dite', false)) {
            return;
        }

        $utilisateur = $app->getIdentity();

        if (!$utilisateur || !$utilisateur->authorise('core.manage', 'com_installer')) {
            return;
        }

        $etat = Noyau::etat($this->getDatabase());

        if ($etat === null) {
            return;
        }

        $session->set('iris.veille.dite', true);

        // Le fichier de langue du plugin n'est pas chargé d'office dans
        // l'administration : sans cette ligne, le client lit la clef brute.
        $this->loadLanguage();

        if ($etat['code'] === 'branche') {
            $app->enqueueMessage(
                Text::sprintf('PLG_SYSTEM_IRIS_VEILLE_BRANCHE', Noyau::BRANCHE, $etat['installee']),
                'error'
            );

            return;
        }

        $app->enqueueMessage(
            Text::sprintf('PLG_SYSTEM_IRIS_VEILLE_RETARD', $etat['installee'], $etat['cible']),
            'warning'
        );
    }

    /**
     * Injecte JS/CSS sur la page du gestionnaire de média (admin).
     */
    public function injectAssets(): void
    {
        $app = $this->getApplication();

        if (!$app->isClient('administrator') || $app->getInput()->getCmd('option') !== 'com_media') {
            return;
        }

        $doc = $app->getDocument();

        if (!$doc instanceof HtmlDocument) {
            return;
        }

        $this->loadLanguage();

        $wa = $doc->getWebAssetManager();
        $wa->registerAndUseStyle('plg_system_iris', 'plg_system_iris/iris.css');
        $wa->registerAndUseScript('plg_system_iris', 'plg_system_iris/iris.js', [], ['defer' => true]);

        $doc->addScriptOptions('plg_system_iris', [
            'ajaxUrl'   => Uri::base(true) . '/index.php?option=com_ajax&group=system&plugin=iris&format=json',
            'token'     => Session::getFormToken(),
            'badgeUsed' => (bool) $this->params->get('badge_used', 1),
            'text'      => [
                'used'          => Text::_('PLG_SYSTEM_IRIS_JS_USED'),
                'unused'        => Text::_('PLG_SYSTEM_IRIS_JS_UNUSED'),
                'managed'       => Text::_('PLG_SYSTEM_IRIS_JS_MANAGED'),
                'folderUsed'    => Text::_('PLG_SYSTEM_IRIS_JS_FOLDER_USED'),
                'folderUnused'  => Text::_('PLG_SYSTEM_IRIS_JS_FOLDER_UNUSED'),
                'folderManaged' => Text::_('PLG_SYSTEM_IRIS_JS_FOLDER_MANAGED'),
                'reportBtn'     => Text::_('PLG_SYSTEM_IRIS_JS_REPORT_BTN'),
                'reportTitle'   => Text::_('PLG_SYSTEM_IRIS_JS_REPORT_TITLE'),
                'loading'       => Text::_('PLG_SYSTEM_IRIS_JS_LOADING'),
                'summary'       => Text::_('PLG_SYSTEM_IRIS_JS_SUMMARY'),
                'summaryManaged' => Text::_('PLG_SYSTEM_IRIS_JS_SUMMARY_MANAGED'),
                'noUnused'      => Text::_('PLG_SYSTEM_IRIS_JS_NO_UNUSED'),
                'csv'           => Text::_('PLG_SYSTEM_IRIS_JS_CSV'),
                'close'         => Text::_('PLG_SYSTEM_IRIS_JS_CLOSE'),
                'caveat'        => Text::_('PLG_SYSTEM_IRIS_JS_CAVEAT'),
                'error'         => Text::_('PLG_SYSTEM_IRIS_JS_ERROR'),
                'file'          => Text::_('PLG_SYSTEM_IRIS_JS_FILE'),
                'actions'       => Text::_('PLG_SYSTEM_IRIS_JS_ACTIONS'),
                'preview'       => Text::_('PLG_SYSTEM_IRIS_JS_PREVIEW'),
                'download'      => Text::_('PLG_SYSTEM_IRIS_JS_DOWNLOAD'),
                'edit'          => Text::_('PLG_SYSTEM_IRIS_JS_EDIT'),
                'rename'        => Text::_('PLG_SYSTEM_IRIS_JS_RENAME'),
                'renamePrompt'  => Text::_('PLG_SYSTEM_IRIS_JS_RENAME_PROMPT'),
                'remove'        => Text::_('PLG_SYSTEM_IRIS_JS_DELETE'),
                'deleteConfirm' => Text::_('PLG_SYSTEM_IRIS_JS_DELETE_CONFIRM'),
                'getLink'       => Text::_('PLG_SYSTEM_IRIS_JS_GET_LINK'),
                'linkCopied'    => Text::_('PLG_SYSTEM_IRIS_JS_LINK_COPIED'),
                'size'          => Text::_('PLG_SYSTEM_IRIS_JS_SIZE'),
            ],
        ]);
    }

    /**
     * Point d'entrée com_ajax :
     * index.php?option=com_ajax&group=system&plugin=iris&format=json
     * task=check   : paths[]   -> { results: { chemin: true|false|"managed" } }
     * task=folders : paths[]   -> { results: { dossier: {used, unused, managed} | {managed:true} } }
     * task=report  : liste des fichiers de /images absents de l'index d'utilisation
     */
    public function handleAjax(Event $event): void
    {
        $app = $this->getApplication();

        if (!$app->isClient('administrator')) {
            return;
        }

        if (!Session::checkToken('request')) {
            $this->addResult($event, ['error' => 'Invalid token']);

            return;
        }

        $input = $app->getInput();
        $task  = $input->getCmd('task', 'check');

        if ($task === 'report') {
            $this->addResult($event, $this->buildReport((bool) $input->getInt('refresh', 0)));

            return;
        }

        $paths = (array) $input->get('paths', [], 'array');
        $paths = array_values(array_filter(array_map('strval', $paths)));

        if ($task === 'folders') {
            $this->addResult($event, ['results' => $this->folderCounts(\array_slice($paths, 0, 60))]);

            return;
        }

        $index   = $this->getIndex();
        $results = [];

        foreach (\array_slice($paths, 0, 1000) as $path) {
            $norm  = $this->normalize($path);
            $entry = [
                'used' => $this->isManaged($norm) ? 'managed' : $this->isUsed($norm, $index),
            ];

            // Poids et, pour les images, dimensions en pixels
            $abs = JPATH_ROOT . '/' . $this->cleanRelative($path);

            if (is_file($abs)) {
                $entry['size'] = (int) @filesize($abs);

                $ext = strtolower(pathinfo($abs, PATHINFO_EXTENSION));

                if (\in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'bmp'], true)) {
                    $dims = @getimagesize($abs);

                    if ($dims !== false) {
                        $entry['w'] = (int) $dims[0];
                        $entry['h'] = (int) $dims[1];
                    }
                }
            }

            $results[$path] = $entry;
        }

        $this->addResult($event, ['results' => $results]);
    }

    private function addResult(Event $event, array $result): void
    {
        if (method_exists($event, 'addResult')) {
            $event->addResult($result);

            return;
        }

        $known   = $event->getArgument('result') ?: [];
        $known[] = $result;
        $event->setArgument('result', $known);
    }

    /**
     * Normalise un chemin pour comparaison : slashes, urldecode,
     * suppression query/fragment, minuscules.
     */
    private function normalize(string $path): string
    {
        $path = str_replace('\\/', '/', $path);
        $path = urldecode($path);
        $path = preg_split('~[?#]~', $path)[0];
        $path = ltrim($path, '/');

        return mb_strtolower(trim($path));
    }

    /**
     * Nettoie un chemin relatif pour un accès disque (garde la casse).
     */
    private function cleanRelative(string $path): string
    {
        $path = str_replace(['\\', "\0"], ['/', ''], urldecode($path));
        $path = preg_split('~[?#]~', $path)[0];

        // Neutralise toute tentative de remontée de répertoire
        $parts = array_filter(
            explode('/', $path),
            static fn ($p) => $p !== '' && $p !== '.' && $p !== '..'
        );

        return implode('/', $parts);
    }

    /**
     * Segments de dossiers créés par les outils de redimensionnement
     * (JoomShaper : Helix, SP Page Builder, SP Simple Portfolio, SP Easy Image Gallery…).
     */
    private const VARIANT_SEGMENTS = [
        'thumbnail', 'thumbnails', '_thumbnail', 'thumb', 'thumbs', '_thumbs',
        '_spmedia_thumbs', 'medium', '_medium', 'small', '_small',
        'large', '_large', 'mini', '_mini', 'big', '_big',
    ];

    /**
     * Ramène un chemin normalisé à sa forme canonique : segments de dossiers
     * de variantes retirés, suffixes de taille supprimés, double extension
     * webp/avif repliée. Ex. : images/x/thumbnail/photo_medium.jpg.webp
     * -> images/x/photo.jpg
     */
    private function canonical(string $norm): string
    {
        $parts = explode('/', $norm);
        $file  = array_pop($parts);
        $parts = array_values(array_filter(
            $parts,
            static fn ($p) => !\in_array($p, self::VARIANT_SEGMENTS, true)
        ));

        // photo.jpg.webp -> photo.jpg
        $file = preg_replace('~\.(jpe?g|png|gif)\.(webp|avif)$~', '.$1', $file);

        // photo_thumbnail.jpg, photo-800x600.jpg -> photo.jpg
        $file = preg_replace(
            '~(?:[-_](?:thumbnail|thumb|medium|small|large|big|mini)|[-_]\d{2,4}x\d{2,4})(\.[a-z0-9]+)$~',
            '$1',
            $file
        );

        $parts[] = $file;

        return implode('/', $parts);
    }

    private function stem(string $canonical): string
    {
        return (string) preg_replace('~\.[a-z0-9]+$~', '', $canonical);
    }

    /**
     * Un fichier est utilisé s'il est référencé directement, ou si sa forme
     * canonique (original d'une variante redimensionnée) l'est.
     */
    private function isUsed(string $norm, array $index): bool
    {
        if (isset($index['set'][$norm])) {
            return true;
        }

        if ((int) $this->params->get('variants', 1) !== 1) {
            return false;
        }

        $canon = $this->canonical($norm);

        return isset($index['canon'][$canon]) || isset($index['stems'][$this->stem($canon)]);
    }

    /**
     * Racines du gestionnaire de média à couvrir (relatives à la racine du site),
     * en minuscules. Par défaut : images et files.
     *
     * @return string[]
     */
    private function roots(): array
    {
        static $roots = null;

        if ($roots !== null) {
            return $roots;
        }

        $roots = [];

        foreach (preg_split('~[\r\n,]+~', (string) $this->params->get('roots', 'images, files')) as $line) {
            $line = mb_strtolower(trim(str_replace('\\', '/', $line), " /\t"));

            if ($line !== '' && !\in_array($line, $roots, true)) {
                $roots[] = $line;
            }
        }

        return $roots ?: ['images'];
    }

    private function extractPattern(): string
    {
        $alts = array_map(static fn ($r) => preg_quote($r, '~'), $this->roots());

        return '~(?<![a-z0-9_\-])(?:' . implode('|', $alts) . ')/[^"\'<>\s?#*|`]+~iu';
    }

    /**
     * Préfixes de dossiers (sous chaque racine) gérés par des extensions
     * (Droppics, Dropfiles…), en minuscules.
     *
     * @return string[]
     */
    private function managedPrefixes(): array
    {
        static $prefixes = null;

        if ($prefixes !== null) {
            return $prefixes;
        }

        $prefixes = [];

        $raw = (string) $this->params->get('managed_folders', "com_droppics, dropfiles");

        foreach (preg_split('~[\r\n,]+~', $raw) as $line) {
            $line = mb_strtolower(trim(str_replace('\\', '/', $line), " /\t"));

            if ($line !== '') {
                $prefixes[] = $line;
            }
        }

        return $prefixes;
    }

    /**
     * Le chemin normalisé est-il dans un dossier géré par une extension ?
     */
    private function isManaged(string $normPath): bool
    {
        foreach ($this->managedPrefixes() as $prefix) {
            $bases = [$prefix];

            if (!str_contains($prefix, '/')) {
                $bases = [];

                foreach ($this->roots() as $rootName) {
                    $bases[] = $rootName . '/' . $prefix;
                }
            }

            foreach ($bases as $base) {
                if ($normPath === $base || str_starts_with($normPath, $base . '/')) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Compte récursivement, pour chaque dossier demandé, les fichiers
     * utilisés / inutilisés / gérés par extension.
     */
    private function folderCounts(array $folders): array
    {
        $index   = $this->getIndex();
        $results = [];

        foreach ($folders as $folder) {
            $rel = $this->cleanRelative($folder);

            $first = strtolower(explode('/', $rel)[0]);

            if ($rel === '' || !\in_array($first, $this->roots(), true)) {
                continue;
            }

            $abs = JPATH_ROOT . '/' . $rel;

            $fullyManaged = $this->isManaged($this->normalize($rel));

            $used = $unused = $managed = 0;
            $size = 0;

            if (is_dir($abs)) {
                $iterator = new \RecursiveIteratorIterator(
                    new \RecursiveDirectoryIterator($abs, \FilesystemIterator::SKIP_DOTS)
                );

                foreach ($iterator as $file) {
                    if (!$file->isFile() || \in_array(strtolower($file->getFilename()), self::IGNORE_NAMES, true)) {
                        continue;
                    }

                    $size += (int) $file->getSize();

                    $relative = $rel . '/' . str_replace('\\', '/', substr($file->getPathname(), \strlen($abs) + 1));
                    $norm     = $this->normalize($relative);

                    if ($this->isManaged($norm)) {
                        $managed++;
                    } elseif ($this->isUsed($norm, $index)) {
                        $used++;
                    } else {
                        $unused++;
                    }
                }
            }

            $results[$folder] = $fullyManaged
                ? ['managed' => true, 'size' => $size]
                : ['used' => $used, 'unused' => $unused, 'managed' => $managed, 'size' => $size];
        }

        return $results;
    }

    /**
     * Index (mis en cache fichier) des chemins référencés dans la base et les
     * templates : chemins exacts, formes canoniques et radicaux sans extension.
     */
    private function getIndex(bool $force = false): array
    {
        static $memory = null;

        if ($memory !== null && !$force) {
            return $memory;
        }

        $cacheFile = JPATH_CACHE . '/plg_system_iris_index.json';
        $lifetime  = 60 * max(1, (int) $this->params->get('cache_lifetime', 15));

        if (!$force && is_file($cacheFile) && (time() - filemtime($cacheFile)) < $lifetime) {
            $data = json_decode((string) file_get_contents($cacheFile), true);

            if (\is_array($data) && isset($data['set'], $data['canon'], $data['stems'])) {
                return $memory = $data;
            }
        }

        $set   = $this->buildUsedSet();
        $canon = [];
        $stems = [];

        foreach ($set as $path => $unused) {
            $c = $this->canonical((string) $path);
            $canon[$c] = true;
            $stems[$this->stem($c)] = true;
        }

        $index = ['set' => $set, 'canon' => $canon, 'stems' => $stems];

        @file_put_contents($cacheFile, json_encode($index));

        return $memory = $index;
    }

    /**
     * @return array<string, true>
     */
    private function buildUsedSet(): array
    {
        $set = [];
        $db  = $this->getDatabase();

        $columns = self::DEFAULT_COLUMNS;

        // Colonnes supplémentaires configurées : une ligne "table:colonne"
        foreach (preg_split('~\R+~', (string) $this->params->get('extra_columns', '')) as $line) {
            $line = trim($line);

            if ($line === '' || !str_contains($line, ':')) {
                continue;
            }

            [$table, $column] = array_map('trim', explode(':', $line, 2));

            if ($table !== '' && $column !== '') {
                $columns[$table][] = $column;
            }
        }

        foreach ($columns as $table => $cols) {
            foreach (array_unique($cols) as $col) {
                try {
                    $likes = [];

                    foreach ($this->roots() as $rootName) {
                        $likes[] = $db->quoteName($col) . ' LIKE ' . $db->quote('%' . $rootName . '%');
                    }

                    $query = $db->getQuery(true)
                        ->select($db->quoteName($col))
                        ->from($db->quoteName($table))
                        ->where('(' . implode(' OR ', $likes) . ')');

                    foreach ((array) $db->setQuery($query)->loadColumn() as $value) {
                        $this->extractPaths((string) $value, $set);
                    }
                } catch (\Throwable $e) {
                    // Table ou colonne absente : on ignore.
                    continue;
                }
            }
        }

        if ((int) $this->params->get('scan_templates', 1) === 1) {
            $this->scanTemplateFiles($set);
        }

        return $set;
    }

    /**
     * Extrait toutes les occurrences de chemins images/... d'un texte.
     *
     * @param array<string, true> $set
     */
    private function extractPaths(string $text, array &$set): void
    {
        if ($text === '') {
            return;
        }

        $found = false;

        foreach ($this->roots() as $rootName) {
            if (stripos($text, $rootName) !== false) {
                $found = true;
                break;
            }
        }

        if (!$found) {
            return;
        }

        // Slashes échappés en JSON et entités
        $text = str_replace(['\\/', '&#47;'], '/', $text);

        if (!preg_match_all($this->extractPattern(), $text, $matches)) {
            return;
        }

        foreach ($matches[0] as $match) {
            $match = rtrim($match, '.,;:)]}&');

            if (!str_contains($match, '.')) {
                continue;
            }

            $set[$this->normalize($match)] = true;
        }
    }

    /**
     * Scanne les fichiers des templates (site + admin + media/templates)
     * pour les références en dur à des fichiers de /images.
     *
     * @param array<string, true> $set
     */
    private function scanTemplateFiles(array &$set): void
    {
        $roots = [
            JPATH_SITE . '/templates',
            JPATH_ADMINISTRATOR . '/templates',
            JPATH_SITE . '/media/templates',
        ];

        $extensions = ['php', 'css', 'js', 'scss', 'less', 'html', 'xml', 'json', 'ini'];

        foreach ($roots as $root) {
            if (!is_dir($root)) {
                continue;
            }

            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS)
            );

            foreach ($iterator as $file) {
                if (!$file->isFile()
                    || !\in_array(strtolower($file->getExtension()), $extensions, true)
                    || $file->getSize() > 2097152
                ) {
                    continue;
                }

                $content = @file_get_contents($file->getPathname());

                if ($content !== false) {
                    $this->extractPaths($content, $set);
                }
            }
        }
    }

    /**
     * Rapport : fichiers de /images non référencés + espace récupérable.
     * Les dossiers gérés par des extensions sont comptés à part.
     */
    private function buildReport(bool $refresh): array
    {
        $index = $this->getIndex($refresh);

        $excluded = array_filter(array_map(
            static fn ($v) => trim(str_replace('\\', '/', $v), " /\t"),
            preg_split('~[\r\n,]+~', (string) $this->params->get('exclude_folders', ''))
        ));

        $unused       = [];
        $totalCount   = 0;
        $totalSize    = 0;
        $unusedSize   = 0;
        $managedCount = 0;
        $managedSize  = 0;

        foreach ($this->roots() as $rootName) {
            $root = JPATH_ROOT . '/' . $rootName;

            if (!is_dir($root)) {
                continue;
            }

            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS)
            );

            foreach ($iterator as $file) {
                if (!$file->isFile() || \in_array(strtolower($file->getFilename()), self::IGNORE_NAMES, true)) {
                    continue;
                }

                $relative = $rootName . '/' . str_replace('\\', '/', substr($file->getPathname(), \strlen($root) + 1));

                $skip = false;

                foreach ($excluded as $folder) {
                    if ($folder !== '' && stripos($relative, $rootName . '/' . $folder . '/') === 0) {
                        $skip = true;
                        break;
                    }
                }

                if ($skip) {
                    continue;
                }

                $size = (int) $file->getSize();
                $norm = $this->normalize($relative);

                if ($this->isManaged($norm)) {
                    $managedCount++;
                    $managedSize += $size;
                    continue;
                }

                $totalCount++;
                $totalSize += $size;

                if (!$this->isUsed($norm, $index)) {
                    $unused[] = ['path' => $relative, 'size' => $size];
                    $unusedSize += $size;
                }
            }
        }

        usort($unused, static fn ($a, $b) => $b['size'] <=> $a['size']);

        return [
            'files'        => $unused,
            'unusedCount'  => \count($unused),
            'unusedSize'   => $unusedSize,
            'totalCount'   => $totalCount,
            'totalSize'    => $totalSize,
            'managedCount' => $managedCount,
            'managedSize'  => $managedSize,
        ];
    }
}
