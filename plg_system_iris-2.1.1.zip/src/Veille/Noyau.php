<?php

/**
 * @package     plg_system_iris
 * @copyright   (C) 2026 Cyrille
 * @license     GPL v2 or later
 *
 * LA VEILLE SUR LE NOYAU, le 13 septembre 2026.
 *
 * Iris n'est suivi, essayé et corrigé que sur la branche 6 de Joomla, et sur sa
 * DERNIÈRE version. Ce fichier est le seul endroit qui sait le dire, et il ne
 * sait que ça : il rend un état, il n'affiche rien.
 *
 * CE FICHIER EST FAIT POUR ÊTRE RECOPIÉ dans les autres produits. Une seule
 * ligne change, le `namespace`. Pas de classe partagée, pas de bibliothèque à
 * installer en plus : la règle posée par Cyrille est qu'aucun produit ne dépend
 * d'un autre.
 *
 * POURQUOI ON NE DEMANDE RIEN AU RÉSEAU. La version la plus récente de Joomla
 * est déjà sur place : le cœur la dépose dans `#__updates` quand il vérifie ses
 * mises à jour. Un appel réseau depuis une page d'administration la ferait
 * attendre, tomberait chez un client derrière un pare-feu, et il faudrait un
 * cache, donc un réglage. On lit donc ce que le site sait déjà.
 *
 * CE QUE ÇA COÛTE, ET C'EST ASSUMÉ : un site qui ne vérifie JAMAIS ses mises à
 * jour n'a pas de ligne dans `#__updates`, et la veille se taira. Elle ne dira
 * pas pour autant que tout va bien : elle ne parle que pour alerter, jamais pour
 * rassurer. Sur les sites du parc, Oculus force la vérification une fois par
 * jour, donc la ligne est fraîche.
 *
 * LE PIÈGE DES LIGNES FANTÔMES, mesuré dans Oculus : le cœur laisse parfois dans
 * `#__updates` une entrée dont la version n'est PAS supérieure à celle installée
 * (« 6.1.2 → 6.1.2 » juste après une mise à jour). On compare donc toujours à
 * `JVERSION` avant d'ouvrir la bouche, sinon la veille crie dans le vide.
 *
 * CE QU'ON A REFUSÉ D'ÉCRIRE : un message pour une branche PLUS RÉCENTE que la
 * nôtre (Joomla 7, un jour). « Mettez à jour » y serait faux, et « attendez »
 * serait une phrase qu'on ne peut pas écrire aujourd'hui sans deviner. Le jour
 * où cette branche existe, ce fichier gagnera son troisième état.
 */

namespace Cyrille\Plugin\System\Iris\Veille;

\defined('_JEXEC') or die;

use Joomla\Database\DatabaseInterface;

final class Noyau
{
    /** La branche de Joomla sur laquelle le produit est suivi. */
    public const BRANCHE = 6;

    /**
     * L'état du noyau, ou null quand il n'y a rien à signaler.
     *
     * @return array{code:string, installee:string, cible:string}|null
     *         code « branche » : le site n'est pas en branche self::BRANCHE.
     *         code « retard »  : bonne branche, mais une version plus récente attend.
     */
    public static function etat(DatabaseInterface $db): ?array
    {
        $installee = (string) JVERSION;

        if (version_compare($installee, self::BRANCHE . '.0', '<')) {
            return ['code' => 'branche', 'installee' => $installee, 'cible' => ''];
        }

        $cible = self::cible($db);

        if ($cible !== '' && version_compare($cible, $installee, '>')) {
            return ['code' => 'retard', 'installee' => $installee, 'cible' => $cible];
        }

        return null;
    }

    /**
     * La version du noyau que le site a lui-même vue proposée, ou '' s'il n'en
     * connaît aucune.
     *
     * Le cœur est l'extension de type `file` nommée `joomla`. On prend la plus
     * haute des lignes, et pas la première : rien ne garantit l'ordre, et une
     * base qui traîne deux propositions doit donner la plus récente.
     *
     * Une base qui refuse de répondre n'est pas une panne de la veille : on se
     * taît, le site continue.
     */
    private static function cible(DatabaseInterface $db): string
    {
        try {
            $versions = $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('version'))
                    ->from($db->quoteName('#__updates'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('joomla'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('file'))
            )->loadColumn();
        } catch (\Throwable $e) {
            return '';
        }

        $haute = '';

        foreach ((array) $versions as $version) {
            $version = (string) $version;

            if ($version !== '' && ($haute === '' || version_compare($version, $haute, '>'))) {
                $haute = $version;
            }
        }

        return $haute;
    }
}
