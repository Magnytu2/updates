<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE BLOC OUVERTURE : une pile d'elements, et rien d'autre.
 *
 * C'est le chapeau d'une page, l'appel a l'action, l'encart d'introduction.
 * Seul dans sa rangee il tient toute la largeur ; a cote d'un autre bloc il
 * prend sa part du rapport.
 *
 * PAS DE MESURE DE LIGNE ICI. Le reglage « Limiter la longueur des lignes » a
 * ete retire le 22 septembre 2026, a la demande de Cyrille : une ouverture
 * occupe la largeur qu'on lui donne, et c'est la rangee qui decide de cette
 * largeur. Qui veut un texte plus etroit coupe sa rangee en deux.
 */

\defined('_JEXEC') or die;

$classes = ['opus__ouverture'];

/*
 * LA POSITION DU BLOC DANS LA HAUTEUR DE SA COLONNE. « En haut » n'ecrit
 * rien : une colonne empile deja son contenu par le haut.
 *
 * « En haut » ecrit sa classe depuis le 2 octobre 2026 : sans elle, la
 * feuille ne pouvait pas savoir qu'il fallait etirer la colonne, et le
 * reglage ne faisait rien sous une rangee centree (voir blocs.css).
 */
$hauteur = (string) ($bloc->hauteur ?? 'center');

if (\in_array($hauteur, ['start', 'center', 'end'], true)) {
    $classes[] = 'opus__ouverture--v-' . $hauteur;
}

if ($bloc->classe !== '') {
    $classes[] = $bloc->classe;
}
?>
<div class="<?php echo implode(' ', $classes); ?>"<?php echo $bloc->attrId; ?>>
	<?php
	/*
	 * LES TROIS VARIABLES SE POSENT ICI, MEME VIDES.
	 *
	 * `_elements.php` est appele plusieurs fois dans la meme page, et les
	 * variables d un appel survivent au suivant : un bloc Cartes place avant
	 * cette ouverture lui passerait son lien de carte, et l ouverture verrait
	 * son premier titre devenir cliquable sans que rien ne l ait demande.
	 */
	$liste       = $bloc->elements;
	$classeImage = 'opus__image';
	$lienCarte   = [];
	?>
	<?php require \Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_opus', '_elements'); ?>
</div>
