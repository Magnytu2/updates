<?php

/**
 * @package     Astus
 * @subpackage  pkg_astus
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;

/**
 * Joomla installe tout plugin DESACTIVE. Sans le plugin, Astus n'a ni panneau,
 * ni traductions dans ses modules (ils affichaient les cles brutes
 * PLG_SYSTEM_ASTUS_AUDIT_...). On l'active donc a la premiere installation.
 * Une mise a jour ne touche pas a l'etat choisi par l'administrateur.
 */
class Pkg_AstusInstallerScript
{
    /**
     * Verrou du 16 octobre 2026 (CLAUDE.md commun, paragraphe 10, « Quelles
     * versions de Joomla nous suivons ») : Astus suit la derniere version
     * mineure de Joomla. Sur un Joomla plus ancien que 6.2.0, l'installation
     * et la mise a jour sont refusees avec un message clair ; le site garde
     * la version d'Astus qu'il avait, intacte. La desinstallation reste libre.
     */
    private const JOOMLA_MINIMUM = '6.2.0';

    public function preflight(string $type, InstallerAdapter $parent): bool
    {
        if ($type === 'uninstall') {
            return true;
        }

        if (version_compare(JVERSION, self::JOOMLA_MINIMUM, '>=')) {
            return true;
        }

        $version = (string) ($parent->getManifest()->version ?? '');
        $cle     = 'PKG_ASTUS_ERREUR_JOOMLA_TROP_ANCIEN';
        $message = '';
        $app     = null;

        try {
            $app = Factory::getApplication();

            // Le fichier de langue du paquet n'est pas encore installe :
            // on le lit dans le paquet en cours d'installation.
            $source = $parent->getParent()->getPath('source');
            if ($source) {
                $app->getLanguage()->load('pkg_astus.sys', $source, null, false, true);
            }

            $message = Text::sprintf($cle, $version);
            // strpos et non str_starts_with : un vieux Joomla 4 peut tourner sous PHP 7.
            if ($message === '' || strpos($message, $cle) === 0) {
                $message = '';
            }
        } catch (\Throwable $e) {
            // Le message de secours ci-dessous prend le relais.
        }

        if ($message === '') {
            $message = sprintf("Astus %s demande Joomla 6.2 ou plus récent. Mettez d'abord Joomla à jour.", $version);
        }

        if ($app) {
            $app->enqueueMessage($message, 'error');
        }

        return false;
    }

    public function postflight(string $type, InstallerAdapter $parent): bool
    {
        if ($type !== 'install' && $type !== 'discover_install') {
            return true;
        }

        try {
            $db    = Factory::getContainer()->get(DatabaseInterface::class);
            $query = $db->getQuery(true)
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('enabled') . ' = 1')
                ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
                ->where($db->quoteName('element') . ' = ' . $db->quote('astus'));
            $db->setQuery($query)->execute();
        } catch (\Throwable $e) {
            // L'installation reste valide : le plugin s'active a la main.
        }

        return true;
    }
}
