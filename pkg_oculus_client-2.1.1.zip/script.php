<?php

/**
 * Oculus Client — script d'installation du paquet.
 *
 * Deux rôles :
 *
 * 1. Activer les deux plugins, pour ne pas avoir à les publier à la main sur
 *    chaque site surveillé.
 *
 * 2. Réécrire l'adresse du serveur de mise à jour du paquet. C'est le point
 *    important de cette version. Le parc installé pointe vers joomanji.eu, qui
 *    ne sert plus les fichiers d'Oculus ; les sites étaient donc figés, sans
 *    aucun moyen de voir une nouvelle version. Joomla ne garantit pas de
 *    corriger l'adresse d'un site de mise à jour existant lors d'une mise à
 *    jour, alors on le fait nous-mêmes, ici, une fois pour toutes.
 *
 * La reprise du token, elle, est faite par le script du plugin Oculus Client.
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\Database\DatabaseInterface;

class pkg_oculus_clientInstallerScript
{
    /** Adresse qui fait foi depuis le 15 août 2026. */
    private const SERVEUR = 'https://magnytu2.github.io/updates/pkg_oculus_client.xml';

    public function postflight($type, $parent): bool
    {
        try {
            $db = Factory::getContainer()->get(DatabaseInterface::class);

            $this->activerPlugins($db);
            $this->corrigerServeurDeMiseAJour($db);
        } catch (\Throwable $e) {
            // Non bloquant : l'installation reste valide, l'administrateur
            // activera les plugins à la main si besoin.
        }

        return true;
    }

    private function activerPlugins(DatabaseInterface $db): void
    {
        foreach ([['oculusclient', 'ajax'], ['oculusgate', 'system']] as [$element, $groupe]) {
            $db->setQuery(
                $db->getQuery(true)
                    ->update($db->quoteName('#__extensions'))
                    ->set($db->quoteName('enabled') . ' = 1')
                    ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote($element))
                    ->where($db->quoteName('folder') . ' = ' . $db->quote($groupe))
            )->execute();
        }
    }

    /**
     * Pointe le site de mise à jour du paquet vers la bonne adresse, et le
     * réactive s'il avait été désactivé après des échecs répétés.
     */
    private function corrigerServeurDeMiseAJour(DatabaseInterface $db): void
    {
        $extensionId = $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName('extension_id'))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('package'))
                ->where($db->quoteName('element') . ' = ' . $db->quote('pkg_oculus_client'))
        )->loadResult();

        if (!$extensionId) {
            return;
        }

        $ids = $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName('update_site_id'))
                ->from($db->quoteName('#__update_sites_extensions'))
                ->where($db->quoteName('extension_id') . ' = ' . (int) $extensionId)
        )->loadColumn();

        if (!$ids) {
            return;
        }

        $db->setQuery(
            $db->getQuery(true)
                ->update($db->quoteName('#__update_sites'))
                ->set($db->quoteName('location') . ' = ' . $db->quote(self::SERVEUR))
                ->set($db->quoteName('enabled') . ' = 1')
                ->set($db->quoteName('last_check_timestamp') . ' = 0')
                ->whereIn($db->quoteName('update_site_id'), array_map('intval', $ids))
        )->execute();
    }
}
