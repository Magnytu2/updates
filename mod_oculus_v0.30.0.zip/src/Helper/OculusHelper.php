<?php

/**
 * Oculus — Module tableau de bord (administration).
 * Interroge le plugin client "sitemonitor" de chaque site surveillé.
 * LECTURE SEULE : simples requêtes GET, aucune action à distance.
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

namespace Joomanji\Module\Oculus\Administrator\Helper;

\defined('_JEXEC') or die;

use Joomla\CMS\Cache\CacheControllerFactoryInterface;
use Joomla\CMS\Extension\ExtensionHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Http\HttpFactory;
use Joomla\Registry\Registry;

class OculusHelper
{
    /** Résultat de la dernière mise à jour déclenchée (null si aucune). */
    private ?array $updateResult = null;

    /** Vrai sur le rendu initial : le template doit lancer l'interrogation en tâche de fond. */
    private bool $autoLoad = false;

    /** Horodatage de l'instantané affiché (null si aucun / données fraîches). */
    private ?int $snapshotTime = null;

    public function getLastUpdateResult(): ?array
    {
        return $this->updateResult;
    }

    /** Le template doit-il déclencher l'interrogation différée des sites ? */
    public function shouldAutoLoad(): bool
    {
        return $this->autoLoad;
    }

    /** Horodatage (epoch) des données affichées si elles viennent du cache. */
    public function getSnapshotTime(): ?int
    {
        return $this->snapshotTime;
    }

    /**
     * User-Agent envoyé avec chaque requête de contrôle.
     * Identifiable par les hébergeurs : évite d'être pris pour un bot
     * malveillant (une requête sans UA = ban CrowdSec « http-bad-user-agent »),
     * et permet de whitelister proprement le monitoring.
     * ATTENTION : ne JAMAIS y mettre les mots « Joomla », « bot », « spider »
     * ou « crawler » — ils figurent dans les listes de User-Agents bannis
     * (cf. hub-data.crowdsec.net/web/bad_user_agents.regex.txt, \bJoomla\b).
     */
    private const USER_AGENT = 'OculusMonitor/1.0 (+https://oculus.joomnet.fr)';

    /**
     * Interroge chaque site configuré et renvoie son état.
     *
     * @return array[] Une entrée par site : name, url, ok, error, summary, generated, plugin_version.
     */
    public function getSitesStatus(Registry $params): array
    {
        $timeout = (int) $params->get('timeout', 10);
        $timeout = max(2, min(30, $timeout ?: 10));

        // « Interroger tous les sites » : force la vérification des mises à jour
        // côté chaque site avant d'en lire l'état (déclenché par le bouton).
        $input      = Factory::getApplication()->getInput();
        $force      = (bool) $input->getInt('oculus_refresh', 0);
        $doUpdate   = (bool) $input->getInt('oculus_update', 0);
        $updateSite = $input->getInt('usite', -1);
        $updateEid  = $input->getInt('ueid', 0);
        $doBackup   = (bool) $input->getInt('oculus_backup', 0);
        $backupSite = $input->getInt('usite', -1);
        $doLoad     = (bool) $input->getInt('oculus_load', 0);
        $doHarden   = (bool) $input->getInt('oculus_harden', 0);
        $hardenSite = $input->getInt('usite', -1);
        $doClean    = (bool) $input->getInt('oculus_clean', 0);
        $cleanSite  = $input->getInt('usite', -1);
        $cleanWhat  = $input->getCmd('target', 'tmp');
        $doOne      = (bool) $input->getInt('oculus_one', 0);
        $oneSite    = $input->getInt('usite', -1);

        // RENDU INITIAL (aucune action, aucun chargement demandé) : on N'INTERROGE
        // PAS les sites (ce serait ~20 requêtes HTTP synchrones = page lente). On
        // renvoie tout de suite le dernier instantané en cache, et le template
        // déclenchera l'interrogation réelle en tâche de fond (oculus_load=1).
        if (!$force && !$doUpdate && !$doBackup && !$doLoad && !$doHarden && !$doClean && !$doOne) {
            $this->autoLoad = true;
            $snap           = $this->readSnapshot();

            if ($snap !== null) {
                $this->snapshotTime = $snap['t'] ?? null;

                return $snap['sites'] ?? [];
            }

            return []; // pas encore d'instantané → le template affiche « chargement… »
        }

        // Parse des paramètres communs (requis/ignorés/référence/toujours-afficher).
        [$required, $ignore, $reference, $always] = $this->parseListParams($params);

        // ACTION SUR UN SEUL SITE (mise à jour, sauvegarde, durcissement, nettoyage).
        // Toutes passent l'index d'affichage via « usite ». On déclenche l'action,
        // puis on ne rafraîchit QUE ce site (rapide) — les 19 autres viennent du
        // cache. C'est ce qui rend l'enchaînement des MàJ groupées praticable.
        $actionSite = $updateSite; // même paramètre pour toutes les actions

        if (($doUpdate || $doBackup || $doHarden || $doClean) && $actionSite >= 0) {
            $target = $this->findValidSite($params, $actionSite);

            if ($target !== null) {
                if ($doUpdate && $updateEid > 0) {
                    $this->updateResult = $this->triggerUpdate($target['url'], $target['token'], $updateEid, $timeout);
                } elseif ($doBackup) {
                    $this->updateResult = $this->triggerBackup($target['url'], $target['token']);
                } elseif ($doHarden) {
                    $this->updateResult = $this->triggerHarden($target['url'], $target['token'], (string) $params->get('htaccess_block', ''), $timeout);
                } elseif ($doClean) {
                    $this->updateResult = $this->triggerClean($target['url'], $target['token'], $cleanWhat, $timeout);
                }

                if ($this->updateResult !== null) {
                    $this->updateResult['site'] = $target['name'];
                }
            }

            $one = $this->refreshOneSite($params, $actionSite, $timeout, $required, $ignore, $reference, $always);

            if ($one !== null) {
                return $one;
            }

            // Pas de cache exploitable : on désactive les déclencheurs (l'action a
            // déjà eu lieu) et on tombe sur l'interrogation complète pour le rendu.
            $doUpdate = $doBackup = $doHarden = $doClean = false;
        }

        // RAFRAÎCHISSEMENT INDIVIDUEL d'un site (bouton « Actualiser » d'une ligne).
        if ($doOne && $oneSite >= 0) {
            $one = $this->refreshOneSite($params, $oneSite, $timeout, $required, $ignore, $reference, $always);

            if ($one !== null) {
                return $one;
            }
            // pas de cache exploitable : on retombe sur l'interrogation complète.
        }

        $results = [];

        foreach ((array) $params->get('sites', []) as $site) {
            $site = (object) $site;

            $name  = trim((string) ($site->sitename ?? ''));
            $url   = trim((string) ($site->url ?? ''));
            $token = trim((string) ($site->token ?? ''));

            if ($url === '' || $token === '') {
                continue;
            }

            // Index STABLE de ce site (ordre de configuration), indépendant du tri
            // d'affichage : c'est lui qui relie un clic dans le tableau au bon site.
            // (Les actions par site sont gérées plus haut, hors de cette boucle.)
            $idx = \count($results);

            $status             = $this->checkSite($name !== '' ? $name : $url, $url, $token, $timeout, $required, $force, $ignore, $reference, $always);
            $status['category'] = trim((string) ($site->category ?? ''));
            $status['_idx']     = $idx;
            $status['frozen']   = !empty($site->frozen);

            $results[] = $status;
        }

        $results = $this->applyParcDeduction($results);

        // Interrogation réelle effectuée : on mémorise l'instantané pour que le
        // prochain affichage de la page soit instantané.
        $this->writeSnapshot($results);

        return $results;
    }

    /**
     * DÉDUCTION PARC : la version la plus récente d'une extension vue sur
     * N'IMPORTE quel site sert de référence aux autres. Si un site est en dessous
     * (et que Joomla n'a rien détecté), on le signale « (parc) ». Ré-applicable
     * après un rafraîchissement individuel.
     */
    private function applyParcDeduction(array $results): array
    {
        $parcMax = [];

        foreach ($results as $r) {
            foreach ((array) ($r['extensions_list'] ?? []) as $e) {
                $st = (string) ($e['stem'] ?? '');
                $v  = (string) ($e['version'] ?? '');

                if ($st === '' || $v === '') {
                    continue;
                }

                if (!isset($parcMax[$st]) || version_compare($v, $parcMax[$st], '>')) {
                    $parcMax[$st] = $v;
                }
            }
        }

        foreach ($results as &$r) {
            if (!\is_array($r['extensions_list'] ?? null)) {
                continue;
            }

            foreach ($r['extensions_list'] as &$e) {
                $st = (string) ($e['stem'] ?? '');
                $v  = (string) ($e['version'] ?? '');

                // On repart d'un état propre (utile en rafraîchissement individuel).
                unset($e['parc_new']);

                if ($st !== '' && $v !== '' && isset($parcMax[$st])
                    && empty($e['new']) && empty($e['ref_new'])
                    && version_compare($v, $parcMax[$st], '<')) {
                    $e['parc_new'] = $parcMax[$st];
                }
            }
            unset($e);

            // Re-tri : urgents (new / ref_new / parc_new) d'abord, puis par nom.
            usort($r['extensions_list'], static function ($a, $b) {
                $ua = (!empty($a['new']) || !empty($a['ref_new']) || !empty($a['parc_new'])) ? 0 : (empty($a['enabled']) ? 2 : 1);
                $ub = (!empty($b['new']) || !empty($b['ref_new']) || !empty($b['parc_new'])) ? 0 : (empty($b['enabled']) ? 2 : 1);

                if ($ua !== $ub) {
                    return $ua - $ub;
                }

                return strcasecmp((string) $a['name'], (string) $b['name']);
            });
        }
        unset($r);

        return $results;
    }

    /**
     * Retrouve le site de configuration correspondant à un index d'AFFICHAGE
     * (_idx = position parmi les sites valides). Renvoie [name, url, token] ou null.
     */
    private function findValidSite(Registry $params, int $index): ?array
    {
        $valid = 0;

        foreach ((array) $params->get('sites', []) as $site) {
            $site  = (object) $site;
            $url   = trim((string) ($site->url ?? ''));
            $token = trim((string) ($site->token ?? ''));

            if ($url === '' || $token === '') {
                continue;
            }

            if ($valid === $index) {
                return [
                    'name'  => trim((string) ($site->sitename ?? '')) ?: $url,
                    'url'   => $url,
                    'token' => $token,
                ];
            }

            $valid++;
        }

        return null;
    }

    /**
     * Rafraîchit UN SEUL site (bouton « Actualiser » d'une ligne) : repart de
     * l'instantané en cache, ré-interroge le site demandé en direct, ré-applique
     * la déduction parc, mémorise, et renvoie l'ensemble. Rapide : les 19 autres
     * sites ne sont pas recontactés.
     */
    private function refreshOneSite(Registry $params, int $target, int $timeout, array $required, array $ignore, array $reference, array $always): ?array
    {
        $snap = $this->readSnapshot();

        if ($snap === null || !\is_array($snap['sites'] ?? null)) {
            return null; // pas de cache : on laissera le flux normal tout interroger
        }

        $results = $snap['sites'];

        // Retrouver le site de configuration correspondant à cet index d'affichage
        // (_idx = position parmi les sites VALIDES, comme dans la boucle principale).
        $valid = 0;
        $done  = false;

        foreach ((array) $params->get('sites', []) as $site) {
            $site  = (object) $site;
            $url   = trim((string) ($site->url ?? ''));
            $token = trim((string) ($site->token ?? ''));

            if ($url === '' || $token === '') {
                continue;
            }

            if ($valid === $target) {
                $name   = trim((string) ($site->sitename ?? ''));
                $status = $this->checkSite($name !== '' ? $name : $url, $url, $token, $timeout, $required, false, $ignore, $reference, $always);
                $status['category'] = trim((string) ($site->category ?? ''));
                $status['_idx']     = $target;
                $status['frozen']   = !empty($site->frozen);

                // Remplace l'entrée correspondante dans les résultats en cache.
                $replaced = false;

                foreach ($results as $i => $row) {
                    if ((int) ($row['_idx'] ?? -1) === $target) {
                        $results[$i] = $status;
                        $replaced    = true;
                        break;
                    }
                }

                if (!$replaced) {
                    $results[] = $status;
                }

                $done = true;
                break;
            }

            $valid++;
        }

        if (!$done) {
            return $results; // index hors périmètre : on renvoie le cache tel quel
        }

        $results = $this->applyParcDeduction($results);
        $this->writeSnapshot($results);

        return $results;
    }

    /**
     * Analyse les listes de configuration partagées par l'interrogation complète
     * et le rafraîchissement individuel.
     *
     * @return array{0:array, 1:array, 2:array, 3:array} [required, ignore, reference, always]
     */
    private function parseListParams(Registry $params): array
    {
        $required = array_values(array_filter(array_map(
            'trim',
            preg_split('/[,;\n]+/', (string) $params->get('required_exts', ''))
        )));

        $ignore = array_values(array_filter(array_map(
            static fn ($v) => mb_strtolower(trim((string) $v)),
            preg_split('/[,;\n]+/', (string) $params->get('ignore_exts', 'pkg_search'))
        )));

        $always = array_values(array_filter(array_map(
            static fn ($v) => mb_strtolower(trim((string) $v)),
            preg_split('/[,;\n]+/', (string) $params->get('always_exts', ''))
        )));

        $reference = [];

        foreach (preg_split('/[\r\n]+/', (string) $params->get('reference_versions', '')) as $refLine) {
            if (strpos($refLine, '=') === false) {
                continue;
            }

            [$rk, $rv] = explode('=', $refLine, 2);
            $rk = mb_strtolower(trim($rk));
            $rv = trim($rv);

            if ($rk !== '' && $rv !== '') {
                $reference[$rk] = $rv;
            }
        }

        return [$required, $ignore, $reference, $always];
    }

    /**
     * Version installée + état de publication du plugin « Oculus Alerte »
     * (plg_task_oculus), pour la pastille verte/rouge du bandeau du module.
     *
     * @return array{found:bool, enabled:bool, version:string}
     */
    public function getAlertPluginStatus(): array
    {
        try {
            $db  = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
            $row = $db->setQuery(
                $db->getQuery(true)
                    ->select([$db->quoteName('enabled'), $db->quoteName('manifest_cache')])
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                    ->where($db->quoteName('folder') . ' = ' . $db->quote('task'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('oculus'))
            )->loadObject();

            if ($row === null) {
                return ['found' => false, 'enabled' => false, 'version' => ''];
            }

            $manifest = json_decode((string) $row->manifest_cache, true) ?: [];

            return [
                'found'   => true,
                'enabled' => (int) $row->enabled === 1,
                'version' => (string) ($manifest['version'] ?? ''),
            ];
        } catch (\Throwable $e) {
            return ['found' => false, 'enabled' => false, 'version' => ''];
        }
    }

    /** Chemin du fichier d'instantané (cache admin). */
    private function snapshotFile(): string
    {
        return rtrim(JPATH_CACHE, '/\\') . '/mod_oculus_snapshot.json';
    }

    /** Lit le dernier instantané, ou null s'il n'existe pas / est illisible. */
    private function readSnapshot(): ?array
    {
        $file = $this->snapshotFile();

        if (!is_file($file)) {
            return null;
        }

        $data = json_decode((string) @file_get_contents($file), true);

        if (!\is_array($data) || !isset($data['sites']) || !\is_array($data['sites'])) {
            return null;
        }

        return $data;
    }

    /** Enregistre l'instantané des résultats (avec horodatage). */
    private function writeSnapshot(array $sites): void
    {
        try {
            @file_put_contents(
                $this->snapshotFile(),
                (string) json_encode(
                    ['t' => time(), 'sites' => $sites],
                    \JSON_INVALID_UTF8_SUBSTITUTE | \JSON_UNESCAPED_UNICODE
                ),
                \LOCK_EX
            );
        } catch (\Throwable $e) {
            // best-effort : un échec de cache ne doit pas casser l'affichage
        }
    }

    /**
     * Calendrier de fin de vie d'un produit (php, mysql, mariadb, postgresql)
     * via l'API publique endoflife.date, mis en cache 24 h.
     * Renvoie cycle => date de fin (ou false si non planifiée), ou null si indisponible.
     */
    private function getEolCycles(string $product): ?array
    {
        try {
            $controller = Factory::getContainer()
                ->get(CacheControllerFactoryInterface::class)
                ->createCacheController('callback', [
                    'defaultgroup' => 'mod_oculus',
                    'lifetime'     => 1440,
                    'caching'      => true,
                ]);

            $cycles = $controller->get(
                static function (string $p) {
                    try {
                        $response = HttpFactory::getHttp()->get(
                            'https://endoflife.date/api/' . $p . '.json',
                            ['Accept' => 'application/json'],
                            5
                        );
                    } catch (\Throwable $e) {
                        return [];
                    }

                    if ($response->code !== 200) {
                        return [];
                    }

                    $rows = json_decode((string) $response->body, true);

                    if (!\is_array($rows)) {
                        return [];
                    }

                    $map = [];

                    foreach ($rows as $row) {
                        if (isset($row['cycle'])) {
                            $map[(string) $row['cycle']] = \array_key_exists('eol', $row) ? $row['eol'] : null;
                        }
                    }

                    return $map;
                },
                [$product],
                'oculus.eol.' . $product
            );

            return (\is_array($cycles) && $cycles !== []) ? $cycles : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Statut de fin de vie d'une version : eol, soon (< 90 jours), ok, unknown.
     */
    private function versionStatus(string $version, string $product): array
    {
        $unknown = ['status' => 'unknown', 'eol' => null];

        if ($version === '' || !preg_match('/^(\d+\.\d+)/', $version, $m)) {
            return $unknown;
        }

        $cycles = $this->getEolCycles($product);

        if ($cycles === null || !\array_key_exists($m[1], $cycles)) {
            return $unknown;
        }

        $eol = $cycles[$m[1]];

        if ($eol === false || $eol === null) {
            return ['status' => 'ok', 'eol' => null];
        }

        if ($eol === true) {
            return ['status' => 'eol', 'eol' => null];
        }

        $eol = (string) $eol;

        if ($eol <= date('Y-m-d')) {
            return ['status' => 'eol', 'eol' => $eol];
        }

        if ($eol <= date('Y-m-d', time() + 90 * 86400)) {
            return ['status' => 'soon', 'eol' => $eol];
        }

        return ['status' => 'ok', 'eol' => $eol];
    }

    /**
     * Requête GET en cURL direct — même comportement qu'un curl « nu », sans
     * la couche HttpFactory de Joomla. Capture au passage le certificat TLS
     * (CURLOPT_CERTINFO, donc zéro connexion de sonde supplémentaire) et un
     * diagnostic chronométré complet en cas d'échec.
     */
    private function curlRequest(string $url, int $timeout): array
    {
        $ch = curl_init($url);

        curl_setopt_array($ch, [
            \CURLOPT_RETURNTRANSFER => true,
            \CURLOPT_FOLLOWLOCATION => true,
            \CURLOPT_MAXREDIRS      => 5,
            \CURLOPT_TIMEOUT        => $timeout,
            \CURLOPT_CONNECTTIMEOUT => $timeout,
            \CURLOPT_HTTPHEADER     => ['Accept: application/json', 'Expect:'],
            \CURLOPT_USERAGENT      => self::USER_AGENT,
            \CURLOPT_CERTINFO       => true,
        ]);

        $body  = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $info  = curl_getinfo($ch);

        curl_close($ch);

        // Date d'expiration du certificat, extraite de la connexion elle-même.
        $expires = null;

        foreach ((array) ($info['certinfo'][0] ?? []) as $k => $v) {
            if (strcasecmp((string) $k, 'Expire date') === 0) {
                $ts = strtotime((string) $v);

                if ($ts !== false) {
                    $expires = $ts;
                }
            }
        }

        return [
            'errno'           => $errno,
            'error'           => $error,
            'code'            => (int) ($info['http_code'] ?? 0),
            'body'            => \is_string($body) ? $body : '',
            'ip'              => (string) ($info['primary_ip'] ?? ''),
            'time_dns'        => (float) ($info['namelookup_time'] ?? 0),
            'time_connect'    => (float) ($info['connect_time'] ?? 0),
            'time_tls'        => (float) ($info['appconnect_time'] ?? 0),
            'cert_expires_ts' => $expires,
        ];
    }

    /**
     * Détail technique ajouté aux messages d'échec : IP réellement contactée
     * et chronologie DNS → TCP → TLS, pour diagnostiquer sans rien deviner.
     */
    private function formatCurlDiag(array $c): string
    {
        $parts = [];

        if ($c['ip'] !== '') {
            $parts[] = 'IP ' . $c['ip'];
        }

        $parts[] = sprintf('DNS %.2fs', $c['time_dns']);
        $parts[] = sprintf('TCP %.2fs', $c['time_connect']);
        $parts[] = sprintf('TLS %.2fs', $c['time_tls']);

        return ' [' . implode(' · ', $parts) . ']';
    }

    /**
     * Traduit les erreurs cURL/HTTP brutes en diagnostic exploitable.
     * Trois familles bien distinctes :
     *  - la connexion TCP n'aboutit pas  → blocage réseau/pare-feu en amont ;
     *  - connectée mais 0 octet reçu     → serveur en difficulté (PHP muet) ;
     *  - données partielles puis timeout → site fonctionnel mais trop lent.
     */
    private function describeConnectionError(string $raw, int $timeout): string
    {
        if (preg_match('/connect/i', $raw) && preg_match('/timed out|timeout/i', $raw)) {
            return 'Connexion impossible : aucune réponse du serveur en ' . $timeout
                . ' s (IP probablement bloquée par un pare-feu en amont) — ' . $raw;
        }

        if (preg_match('/timed out|timeout/i', $raw)) {
            if (preg_match('/with\s+(\d+)\s+bytes received/i', $raw, $m) && (int) $m[1] > 0) {
                return 'Site trop lent : réponse incomplète après ' . $timeout
                    . ' s (' . $m[1] . ' octets reçus) — augmenter le délai d\'attente du module ?';
            }

            return 'Serveur muet : connexion établie mais aucune donnée reçue en '
                . $timeout . ' s (serveur web ou PHP en difficulté)';
        }

        if (preg_match('/resolve|getaddrinfo|name lookup/i', $raw)) {
            return 'DNS introuvable : le nom de domaine ne se résout pas — ' . $raw;
        }

        if (preg_match('/ssl|certificate|tls/i', $raw)) {
            return 'Problème SSL/TLS : ' . $raw;
        }

        return 'Injoignable : ' . $raw;
    }

    /**
     * Vide à distance le dossier tmp ou les caches d'un site.
     *
     * @return array{ok:bool, message:string}
     */
    private function triggerClean(string $url, string $token, string $target, int $timeout): array
    {
        $target = \in_array($target, ['tmp', 'cache'], true) ? $target : 'tmp';

        $endpoint = rtrim($url, '/')
            . '/index.php?option=com_ajax&plugin=sitemonitor&format=raw'
            . '&token=' . urlencode($token)
            . '&action=clean&target=' . $target;

        $curl = $this->curlRequest($endpoint, max($timeout, 300));

        if ($curl['errno'] !== 0) {
            return ['ok' => false, 'message' => 'Site injoignable ou délai dépassé : ' . $curl['error']];
        }

        $data = json_decode((string) $curl['body'], true);

        if (!\is_array($data)) {
            return ['ok' => false, 'message' => 'Réponse invalide du site (HTTP ' . $curl['code'] . ').'];
        }

        if (($data['status'] ?? '') === 'ok') {
            $mo   = round(((int) ($data['bytes'] ?? 0)) / 1048576, 1);
            $skip = (int) ($data['skipped'] ?? 0);

            return [
                'ok'      => true,
                'message' => ($target === 'cache' ? 'Caches vidés' : 'Dossier tmp vidé') . ' : '
                    . (int) ($data['deleted'] ?? 0) . ' fichier(s) supprimé(s), ' . $mo . ' Mo libérés.'
                    . ($skip > 0 ? ' ' . $skip . ' fichier(s) très récent(s) conservé(s) par précaution.' : '')
                    . ' Les fichiers de protection (index.html, .htaccess) ont été préservés.',
            ];
        }

        return ['ok' => false, 'message' => (string) ($data['message'] ?? 'Échec du nettoyage.')];
    }

    /**
     * Applique le bloc de durcissement .htaccess sur un site distant.
     * Le bloc est transmis en base64 (sauts de ligne et symboles Apache).
     *
     * @return array{ok:bool, message:string}
     */
    private function triggerHarden(string $url, string $token, string $block, int $timeout): array
    {
        $endpoint = rtrim($url, '/')
            . '/index.php?option=com_ajax&plugin=sitemonitor&format=raw'
            . '&token=' . urlencode($token)
            . '&action=htaccess'
            . '&block=' . urlencode(base64_encode(trim($block)));

        // Le client teste le site après écriture : on lui laisse le temps.
        $curl = $this->curlRequest($endpoint, max($timeout, 90));

        if ($curl['errno'] !== 0) {
            return ['ok' => false, 'message' => 'Site injoignable ou délai dépassé : ' . $curl['error']];
        }

        $data = json_decode((string) $curl['body'], true);

        if (!\is_array($data)) {
            return ['ok' => false, 'message' => 'Réponse invalide du site (HTTP ' . $curl['code'] . ').'];
        }

        if (($data['status'] ?? '') === 'ok') {
            if (empty($data['applied'])) {
                return ['ok' => true, 'message' => 'Bloc de durcissement Oculus retiré du .htaccess.'];
            }

            $probe  = $data['probe_code'] ?? null;
            $server = trim((string) ($data['server'] ?? ''));

            // Le test réel prime : écrire la règle ne prouve pas qu'elle s'applique.
            if (!empty($data['verified'])) {
                return [
                    'ok'      => true,
                    'message' => 'Oculus Bouclier appliqué et VÉRIFIÉ : un script PHP déposé dans images/ '
                        . 'est bien bloqué (HTTP ' . (int) $probe . ').'
                        . ($server !== '' ? ' Serveur : ' . $server . '.' : '')
                        . (!empty($data['backup']) ? ' Sauvegarde : ' . $data['backup'] : ''),
                ];
            }

            // Test IMPOSSIBLE (le site n'a pas pu s'appeler lui-même) : on ne peut
            // rien conclure sur l'efficacité de la règle. Ne pas confondre avec une
            // règle testée et inopérante.
            if ($probe === null) {
                return [
                    'ok'      => true,
                    'message' => 'Durcissement appliqué, mais la vérification automatique n\'a pas pu être réalisée'
                        . (($data['probe_reason'] ?? '') !== '' ? ' (' . $data['probe_reason'] . ')' : '') . '.'
                        . ($server !== '' ? ' Serveur : ' . $server . '.' : '')
                        . ' Cela ne signifie PAS que la protection est inopérante : il faut la contrôler à la main,'
                        . ' en déposant un fichier .php dans images/ et en l\'appelant dans le navigateur'
                        . ' (403 attendu).',
                ];
            }

            return [
                'ok'      => false,
                'message' => 'Bloc écrit, mais la protection N\'EST PAS EFFECTIVE : le test réel renvoie HTTP '
                    . (int) $probe . ' au lieu de 403.'
                    . ($server !== '' ? ' Serveur : ' . $server . '.' : '')
                    . ' Cet hébergement ignore vraisemblablement les fichiers .htaccess — la protection'
                    . ' des dossiers d\'upload doit y être obtenue autrement.',
            ];
        }

        return ['ok' => false, 'message' => (string) ($data['message'] ?? 'Échec du durcissement.')];
    }

    /**
     * Déclenche une sauvegarde Akeeba à distance via l'action « backup » du
     * plugin client. Délai très long : une sauvegarde peut durer plusieurs minutes.
     *
     * @return array{ok:bool, message:string}
     */
    private function triggerBackup(string $url, string $token): array
    {
        $endpoint = rtrim($url, '/')
            . '/index.php?option=com_ajax&plugin=sitemonitor&format=raw'
            . '&token=' . urlencode($token)
            . '&action=backup';

        // Sauvegarde = long. Délai généreux (10 min).
        $curl = $this->curlRequest($endpoint, 600);

        if ($curl['errno'] !== 0) {
            return ['ok' => false, 'message' => 'Site injoignable ou délai dépassé : ' . $curl['error']];
        }

        $data = json_decode((string) $curl['body'], true);

        if (!\is_array($data)) {
            return ['ok' => false, 'message' => 'Réponse invalide du site (HTTP ' . $curl['code'] . ').'];
        }

        if (($data['status'] ?? '') === 'ok') {
            return ['ok' => true, 'message' => 'Sauvegarde Akeeba effectuée (profil ' . (int) ($data['profile'] ?? 1) . ').'];
        }

        return ['ok' => false, 'message' => (string) ($data['message'] ?? 'Échec de la sauvegarde.')];
    }

    /**
     * Déclenche la mise à jour d'une extension sur un site distant, via l'action
     * « update » du plugin client (écriture, sécurisée par token côté site).
     *
     * @return array{ok:bool, message:string, name?:string, version?:string, code?:string}
     */
    private function triggerUpdate(string $url, string $token, int $eid, int $timeout): array
    {
        $endpoint = rtrim($url, '/')
            . '/index.php?option=com_ajax&plugin=sitemonitor&format=raw'
            . '&token=' . urlencode($token)
            . '&action=update&eid=' . $eid;

        // Une installation peut être longue : délai généreux.
        $curl = $this->curlRequest($endpoint, max($timeout, 120));

        if ($curl['errno'] !== 0) {
            return ['ok' => false, 'message' => 'Site injoignable : ' . $curl['error']];
        }

        $data = json_decode((string) $curl['body'], true);

        if (!\is_array($data)) {
            return ['ok' => false, 'message' => 'Réponse invalide du site (HTTP ' . $curl['code'] . ').'];
        }

        if (($data['status'] ?? '') === 'ok') {
            return [
                'ok'      => true,
                'name'    => (string) ($data['name'] ?? ''),
                'version' => (string) ($data['version'] ?? ''),
                'message' => 'Mise à jour effectuée : ' . trim(($data['name'] ?? '') . ' ' . ($data['version'] ?? '')),
            ];
        }

        return [
            'ok'      => false,
            'code'    => (string) ($data['code'] ?? ''),
            'message' => (string) ($data['message'] ?? 'Échec de la mise à jour.')
                . ' (réf. extension #' . $eid . ' sur ce site)',
        ];
    }

    /**
     * Radical d'une extension : élément en minuscules sans son préfixe de type
     * (com_/mod_/plg_/lib_/pkg_/tpl_). Relie un composant et les plugins/modules
     * qui l'accompagnent : com_cgsecure, plugin « cgsecure » -> « cgsecure ».
     */
    private function extStem(string $element): string
    {
        return (string) preg_replace('/^(com_|mod_|plg_|lib_|pkg_|tpl_)/i', '', strtolower(trim($element)));
    }

    private function checkSite(string $name, string $url, string $token, int $timeout, array $required = [], bool $force = false, array $ignore = [], array $reference = [], array $always = []): array
    {
        $result = [
            'name'              => $name,
            'url'               => $url,
            'ok'                => false,
            'error'             => null,
            'summary'           => null,
            'generated'         => null,
            'plugin_version'    => null,
            'joomla_update'     => null,
            'ext_updates'       => 0,
            'ext_updates_names' => [],
            'db'                => null,
            'auto_update'       => null,
            'backend_users'     => null,
            'backend_names'     => [],
            'suspect_files'     => [],
            'files_checked'     => false,
            'htaccess_suspect'  => [],
            'htaccess_state'    => null,
            // Durcissement Oculus : null = pas d'information (client trop ancien),
            // true/false = bloc présent ou non ; l'empreinte permet de détecter un
            // bloc appliqué mais devenu différent de celui configuré.
            'harden_present'    => null,
            'harden_hash'       => null,
            // Code HTTP du dernier test réel de la protection (403 = effective).
            'harden_verify'     => null,
            'server_soft'       => '',
            // Volumétrie nettoyable (client v0.15+) : null = non remonté.
            'tmp_files'         => null,
            'tmp_bytes'         => 0,
            'cache_files'       => null,
            'cache_bytes'       => 0,
            'htaccess_mode'     => null,
            'config_modified'   => null,
            'config_mode'       => null,
            'config_state'      => null,
            'present_required'  => [],
            'php_status'        => null,
            'db_status'         => null,
            'db_schema'         => null,
            'extensions_list'   => [],
            'maintenance'       => false,
            'backup'            => null,
            'missing_required'  => [],
            'backend_no_mfa'    => [],
            // Comptes dont la MFA est explicitement ACTIVE. Compté à part : une
            // liste backend_no_mfa vide ne prouve pas que tout le monde est
            // protégé (le statut peut être inconnu avec un ancien client).
            'backend_mfa'       => 0,
            'ssl'               => null,
        ];

        $endpoint = rtrim($url, '/')
            . '/index.php?option=com_ajax&plugin=sitemonitor&format=raw&token=' . urlencode($token);

        // Forçage : demande d'abord au site de revérifier ses mises à jour
        // (findUpdates), puis on lit l'état frais. Best-effort : on ignore le
        // résultat de cette première requête.
        if ($force) {
            $this->curlRequest($endpoint . '&refresh=updates', $timeout);
        }

        $curl = $this->curlRequest($endpoint, $timeout);

        // Certificat SSL : lu directement sur la connexion de contrôle
        // (CURLOPT_CERTINFO), plus aucune sonde TLS séparée.
        if (stripos($url, 'https://') === 0 && !empty($curl['cert_expires_ts'])) {
            $ts = (int) $curl['cert_expires_ts'];

            $result['ssl'] = [
                'expires' => date('d-m-Y H:i', $ts),
                'days'    => (int) floor(($ts - time()) / 86400),
            ];
        }

        if ($curl['errno'] !== 0) {
            $result['error'] = $this->describeConnectionError($curl['error'], $timeout)
                . $this->formatCurlDiag($curl);

            return $result;
        }

        $response = (object) ['code' => $curl['code'], 'body' => $curl['body']];

        if ($response->code !== 200) {
            // 503 = signature d'un Joomla en mode maintenance (site volontairement
            // hors ligne) : com_ajax est bloqué, on ne peut pas atteindre le plugin,
            // mais ce n'est PAS une panne. On le distingue d'une vraie indisponibilité.
            if ($response->code === 503) {
                $result['maintenance'] = true;
                $result['error']       = 'Site en maintenance (hors ligne) — réponse HTTP 503';

                return $result;
            }

            $result['error'] = 'Réponse HTTP ' . $response->code
                . ($response->code === 403 ? ' (token refusé ?)' : '');

            return $result;
        }

        $data = json_decode((string) $response->body, true);

        if (!\is_array($data) || ($data['status'] ?? '') !== 'ok') {
            $result['error'] = 'Réponse invalide (plugin sitemonitor absent ou désactivé ?)';

            return $result;
        }

        $result['ok']             = true;
        $result['summary']        = \is_array($data['summary'] ?? null) ? $data['summary'] : [];
        $result['generated']      = $data['generated'] ?? null;
        $result['plugin_version'] = $data['plugin_version'] ?? null;

        // Version de la base de données, en clair (ex. « MariaDB 10.6.21 »).
        $dbVersion = (string) ($data['core']['db_version'] ?? '');
        $dbType    = (string) ($data['core']['db_type'] ?? '');

        if ($dbVersion !== '') {
            if (stripos($dbVersion, 'mariadb') !== false) {
                $result['db'] = 'MariaDB ' . trim(str_ireplace(['-MariaDB', 'MariaDB'], '', $dbVersion), '- ');
            } else {
                $result['db'] = trim(ucfirst($dbType) . ' ' . $dbVersion);
            }
        }

        // Statuts de fin de vie (PHP / base de données) via endoflife.date.
        $result['php_status'] = $this->versionStatus((string) ($data['core']['php_version'] ?? ''), 'php');

        if ($dbVersion !== '') {
            $product = stripos($dbVersion, 'mariadb') !== false
                ? 'mariadb'
                : ($dbType === 'postgresql' ? 'postgresql' : 'mysql');

            $result['db_status'] = $this->versionStatus($dbVersion, $product);
        }

        // Surveillance du schéma BDD (plugin client v0.9.4+) : structures de
        // tables en erreur après une mise à jour (écran Maintenance : BDD).
        if (\is_array($data['db_schema'] ?? null) && !isset($data['db_schema']['error'])) {
            $problems = [];

            foreach ((array) ($data['db_schema']['problems'] ?? []) as $p) {
                if (!\is_array($p)) {
                    continue;
                }

                $label = trim((string) ($p['name'] ?? ''));

                // Certains noms restent sous forme de clé de langue non traduite
                // côté site (ex. « COM_FOO_XYZ ») : on retombe alors sur l'élément.
                if ($label === '' || preg_match('/^[A-Z0-9_]+$/', $label)) {
                    $label = (string) ($p['element'] ?? $label);
                }

                $problems[] = [
                    'name'   => $label !== '' ? $label : '?',
                    'errors' => (int) ($p['errors'] ?? 0),
                ];
            }

            $result['db_schema'] = [
                'checked'  => (int) ($data['db_schema']['checked'] ?? 0),
                'problems' => $problems,
            ];
        }

        // Mises à jour automatiques du cœur (plugin client v0.3+, Joomla 5.4+).
        if (\is_array($data['auto_update'] ?? null)) {
            $au = $data['auto_update'];

            $mapped = [
                'supported' => (bool) ($au['supported'] ?? false),
                'enabled'   => (bool) ($au['enabled'] ?? false),
            ];

            // « healthy » n'est renvoyé que par le client v0.18+. On ne le fixe que
            // s'il est réellement présent : ainsi un client plus ancien (qui ne sait
            // pas calculer la santé) ne déclenche PAS de faux orange côté module.
            if (\array_key_exists('healthy', $au)) {
                $mapped['healthy'] = (bool) $au['healthy'];
            }

            $result['auto_update'] = $mapped;
        }

        // Régression « options par article ignorées » (Joomla 5.4.7 / 6.1.2),
        // détectée par lecture du fichier du cœur (plugin client v0.19+).
        if (\is_array($data['article_bug'] ?? null) && !empty($data['article_bug']['checked'])) {
            $result['article_bug'] = [
                'affected' => (bool) ($data['article_bug']['affected'] ?? false),
                'articles' => (int) ($data['article_bug']['articles'] ?? 0),
            ];
        }

        // Fichiers .php suspects (plugin client v0.8+) : à la racine, tout .php
        // autre que index.php ; dans media/images/tmp, tout .php est anormal.
        if (\is_array($data['php_files'] ?? null) && !isset($data['php_files']['error'])) {
            $result['files_checked'] = true;

            foreach (array_keys($data['php_files']) as $path) {
                $isRoot = strpos($path, '/') === false;

                if ($isRoot) {
                    // À la racine, seuls index.php et configuration.php sont normaux.
                    if (!\in_array($path, ['index.php', 'configuration.php'], true)) {
                        $result['suspect_files'][] = $path;
                    }
                } else {
                    // Tout script remonté sous media/images/tmp/cache est suspect
                    // (le plugin a déjà écarté les fichiers de cache légitimes).
                    $result['suspect_files'][] = $path;
                }
            }
        }

        // Pièces maîtresses de sécurité (plugin client v0.10.4+) : configuration.php
        // (empreinte/date) et .htaccess (contenu dangereux hors bloc CG Secure).
        if (\is_array($data['security_files'] ?? null) && !isset($data['security_files']['error'])) {
            $sf = $data['security_files'];

            $result['htaccess_suspect'] = array_values((array) ($sf['htaccess_suspect'] ?? []));
            $result['htaccess_mode']    = $sf['htaccess_mode'] ?? null;

            // Durcissement Oculus (client v0.13.1+) : absent de la réponse d'un
            // client plus ancien → on reste sur null (« pas de communication »).
            if (\is_array($data['maintenance'] ?? null) && !isset($data['maintenance']['error'])) {
                $mt = $data['maintenance'];

                $result['tmp_files']   = (int) ($mt['tmp']['files'] ?? 0);
                $result['tmp_bytes']   = (int) ($mt['tmp']['bytes'] ?? 0);
                $result['cache_files'] = (int) ($mt['cache']['files'] ?? 0);
                $result['cache_bytes'] = (int) ($mt['cache']['bytes'] ?? 0);
            }

            if (\array_key_exists('htaccess_oculus', $sf)) {
                $result['harden_present'] = $sf['htaccess_oculus'] === null ? null : (bool) $sf['htaccess_oculus'];
                $result['harden_hash']    = $sf['htaccess_oculus_hash'] ?? null;
                $result['harden_verify']  = isset($sf['htaccess_verify']) ? (int) $sf['htaccess_verify'] : null;
                $result['server_soft']    = (string) ($sf['server_software'] ?? '');
            }
            $result['config_modified']  = $sf['config_modified'] ?? null;
            $result['config_mode']      = $sf['config_mode'] ?? null;

            // État .htaccess : absent / rouge (contenu dangereux) / orange
            // (permissions trop ouvertes) / vert (sain).
            if (empty($sf['htaccess_present'])) {
                $result['htaccess_state'] = 'absent';
            } elseif (!empty($result['htaccess_suspect'])) {
                $result['htaccess_state'] = 'red';
            } elseif ($result['htaccess_mode'] !== null && (octdec($result['htaccess_mode']) & 022)) {
                $result['htaccess_state'] = 'orange';
            } else {
                $result['htaccess_state'] = 'green';
            }

            // État configuration.php d'après ses permissions : vert = lecture seule,
            // orange = modifiable par le propriétaire, rouge = inscriptible par autrui.
            if ($result['config_mode'] !== null) {
                $m = (int) octdec($result['config_mode']);

                if ($m & 022) {
                    $result['config_state'] = 'red';
                } elseif ($m & 0200) {
                    $result['config_state'] = 'orange';
                } else {
                    $result['config_state'] = 'green';
                }
            }
        }

        // Dernière sauvegarde Akeeba (plugin client v0.6+).
        if (\is_array($data['backup'] ?? null) && !isset($data['backup']['error'])) {
            $last = $data['backup']['last_backup'] ?? null;
            $days = null;

            if ($last && ($ts = strtotime((string) $last)) !== false) {
                $days = (int) floor((time() - $ts) / 86400);
            }

            // Mise à jour Akeeba en attente ? (Akeeba est hors de la colonne
            // Extensions ; on rapatrie ici son eid + version cible pour rendre la
            // ligne Sauvegarde cliquable.)
            $akEid = 0;
            $akNew = null;

            foreach ((array) ($data['updates']['available'] ?? []) as $u) {
                if (!\is_array($u)) {
                    continue;
                }

                $uel = strtolower((string) ($u['element'] ?? ''));
                $unm = strtolower((string) ($u['name'] ?? ''));

                if (strpos($uel, 'akeeba') !== false || strpos($unm, 'akeeba') !== false) {
                    $akEid = (int) ($u['extension_id'] ?? 0);
                    $akNew = (string) ($u['new_version'] ?? '');

                    // Le paquet (pkg_akeebabackup) est l'entrée à mettre à jour.
                    if (strpos($uel, 'pkg_') === 0) {
                        break;
                    }
                }
            }

            $result['backup'] = [
                'installed'     => !empty($data['backup']['installed']),
                'last'          => $last,
                'days'          => $days,
                'edition'       => $data['backup']['edition'] ?? null,
                'version'       => $data['backup']['version'] ?? null,
                'update_eid'    => $akEid,
                'update_new'    => $akNew ?: null,
                'remote_ready'  => !empty($data['backup']['remote_ready']),
                'remote_reason' => (string) ($data['backup']['remote_reason'] ?? ''),
            ];
        }

        // Inventaire des extensions NON natives (tierces), avec état de mise à jour.
        if (\is_array($data['extensions'] ?? null) && !isset($data['extensions']['error'])) {
            // Correspondance extension_id -> nouvelle version disponible.
            $pending = [];

            foreach ((array) ($data['updates']['available'] ?? []) as $u) {
                if (\is_array($u) && !empty($u['extension_id'])) {
                    $pending[(int) $u['extension_id']] = (string) ($u['new_version'] ?? '');
                }
            }

            // Rang de « parenté » : pour un même produit, on garde le plus parent.
            $rank = ['package' => 0, 'component' => 1, 'template' => 2, 'plugin' => 3];

            // Nos propres agents : toujours affichés, même installés en plugin isolé
            // (sites où l'Agent n'est pas posé via le paquet), avec leur état de MàJ.
            // Nos agents Oculus + les extensions déclarées « à toujours afficher ».
            $ourAgents = array_merge(['sitemonitor', 'oculusgate', 'oculus'], $always);

            $groups = [];

            foreach ($data['extensions'] as $ext) {
                if (!\is_array($ext)) {
                    continue;
                }

                $type    = (string) ($ext['type'] ?? '');
                $element = (string) ($ext['element'] ?? '');
                $folder  = (string) ($ext['folder'] ?? '');
                $client  = (int) ($ext['client_id'] ?? 0);
                $rawName = trim((string) ($ext['name'] ?? ''));

                // Packs de langue : par type ET par nom (certains sont de type
                // « file »/« package » : « French (fr-FR) Language Pack for… »).
                if ($type === 'language' || preg_match('/language pack/i', $rawName)) {
                    continue;
                }

                // Cœur natif de Joomla.
                if (ExtensionHelper::checkIfCoreExtension($type, $element, $client, $folder)) {
                    continue;
                }

                $stem       = $this->extStem($element);
                $el         = strtolower($element);
                // Correspondance sur l'élément OU sur le radical (plg_system_iris → iris).
                $isOurAgent = \in_array($el, $ourAgents, true)
                    || \in_array($stem, $ourAgents, true)
                    || strpos($el, 'oculus') === 0;

                // RÈGLE DE CONFIANCE : si une mise à jour est EN ATTENTE pour cette
                // extension, on l'affiche TOUJOURS — même si elle serait normalement
                // masquée (plugin isolé, satellite…). Oculus ne cache jamais une MàJ.
                $eid       = (int) ($ext['id'] ?? 0);
                $hasUpdate = !empty($pending[$eid]);

                // Version de référence (MàJ manuelle, hors circuit Joomla) :
                // la version installée est-elle EN DESSOUS de la référence saisie ?
                $curVer      = (string) ($ext['version'] ?? '');
                $refTarget   = $reference[$el] ?? $reference[$stem] ?? ($reference[mb_strtolower($rawName)] ?? null);
                $refOutdated = $refTarget !== null && $curVer !== '' && version_compare($curVer, (string) $refTarget, '<');

                // Notre propre PAQUET (pkg_oculus_agent) est masqué : on montre plutôt
                // le PLUGIN Oculus Client qu'il embarque.
                if ($el === 'pkg_oculus_agent') {
                    continue;
                }

                // Sous-extension d'un paquet : masquée — SAUF nos agents, ou si elle
                // porte sa PROPRE mise à jour en attente.
                if (!$isOurAgent && !$hasUpdate && !$refOutdated && (int) ($ext['package_id'] ?? 0) > 0) {
                    continue;
                }

                // PRODUITS (composants/paquets/templates) + nos agents + TOUTE extension
                // ayant une MàJ en attente. Le reste (plugins/modules à jour, PRISM,
                // reCAPTCHA, satellites SP Page Builder…) est masqué.
                if (!$isOurAgent && !$hasUpdate && !$refOutdated && !\in_array($type, ['component', 'package', 'template'], true)) {
                    continue;
                }

                // Liste d'exclusion (réglages) : masque des produits résiduels
                // indésirables (ex. pkg_search publié par Joomla).
                if ($ignore !== []
                    && (\in_array(strtolower($element), $ignore, true)
                        || \in_array($stem, $ignore, true)
                        || \in_array(mb_strtolower($rawName), $ignore, true))) {
                    continue;
                }

                // Nom d'affichage : repli sur le radical si le nom est une clé de
                // langue non traduite ou un identifiant technique (com_/plg_/...).
                $label = $rawName;

                if ($label === ''
                    || preg_match('/^[A-Z0-9_]+$/', $label)
                    || preg_match('/^(com_|mod_|plg_|lib_|pkg_|tpl_)/i', $label)) {
                    $label = $stem;
                }

                // Retire le préfixe de GROUPE des plugins (« System - », « Content - »,
                // « CAPTCHA - »…) pour n'afficher que le nom du produit.
                $label = (string) preg_replace(
                    '/^(?:System|Content|User|Editor|Editors-XTD|CAPTCHA|Quick Icon|Button|Fields|Task|Behaviou?r|Two[\\s-]?Factor Authentication|Multi[\\s-]?factor Authentication|API Authentication|Authentication|Web Services|Installer|Privacy|Sample Data|Action ?Log|Console|Filesystem|Schema|Workflow|WebAuthn|Media Action|Finder|Extension)\\s*[-\x{2013}]\\s*/iu',
                    '',
                    $label
                );

                if ($label === '') {
                    $label = $stem;
                }

                // Akeeba : déjà affiché dans la colonne Sauvegarde.
                if (stripos($label, 'akeeba') !== false || stripos($element, 'akeeba') !== false) {
                    continue;
                }

                $id    = (int) ($ext['id'] ?? 0);
                $entry = [
                    'id'      => $id,
                    'name'    => $label,
                    'stem'    => $stem,
                    'version' => $ext['version'] ?? null,
                    'new'     => $pending[$id] ?? null,
                    'ref_new' => $refOutdated ? (string) $refTarget : null,
                    'enabled' => !empty($ext['enabled']),
                    'type'    => $type,
                ];

                // Regroupement par radical (composant + plugin autonome homonyme
                // fusionnés), en gardant l'entrée la plus parente.
                if (!isset($groups[$stem])) {
                    $groups[$stem] = $entry;
                    continue;
                }

                $cur  = $groups[$stem];
                $keep = (($rank[$type] ?? 5) < ($rank[$cur['type']] ?? 5)) ? $entry : $cur;

                // L'action de mise à jour doit cibler l'extension porteuse de la MàJ.
                if (empty($keep['new'])) {
                    if (!empty($entry['new'])) {
                        $keep['id'] = $entry['id'];
                    } elseif (!empty($cur['new'])) {
                        $keep['id'] = $cur['id'];
                    }
                }

                // Préférer un nom lisible plutôt qu'un simple radical.
                if ($keep['name'] === $stem) {
                    if ($cur['name'] !== $stem) {
                        $keep['name'] = $cur['name'];
                    } elseif ($entry['name'] !== $stem) {
                        $keep['name'] = $entry['name'];
                    }
                }

                $keep['new']     = $entry['new'] ?: $cur['new'];
                $keep['ref_new'] = ($entry['ref_new'] ?? null) ?: ($cur['ref_new'] ?? null);
                $keep['enabled'] = $entry['enabled'] || $cur['enabled'];
                $groups[$stem]   = $keep;
            }

            $extList = array_values($groups);

            // Tri par urgence : à mettre à jour (orange) d'abord, puis à jour
            // (vert), puis désactivées (gris) en dernier ; par nom à égalité.
            $urgency = static function (array $x): int {
                if (!empty($x['new']) || !empty($x['ref_new'])) {
                    return 0;
                }

                return empty($x['enabled']) ? 2 : 1;
            };

            usort($extList, static function ($a, $b) use ($urgency) {
                $ua = $urgency($a);
                $ub = $urgency($b);

                if ($ua !== $ub) {
                    return $ua - $ub;
                }

                return strcasecmp((string) $a['name'], (string) $b['name']);
            });

            $result['extensions_list'] = $extList;
        }

        // Extensions requises manquantes ou désactivées.
        if ($required !== [] && \is_array($data['extensions'] ?? null) && !isset($data['extensions']['error'])) {
            foreach ($required as $token) {
                $needle = mb_strtolower($token);
                $found  = false;

                foreach ($data['extensions'] as $ext) {
                    if (!\is_array($ext) || empty($ext['enabled'])) {
                        continue;
                    }

                    if (
                        str_contains(mb_strtolower((string) ($ext['element'] ?? '')), $needle)
                        || str_contains(mb_strtolower((string) ($ext['name'] ?? '')), $needle)
                    ) {
                        $found = true;
                        break;
                    }
                }

                if ($found) {
                    $result['present_required'][] = $token;
                } else {
                    $result['missing_required'][] = $token;
                }
            }
        }

        // Utilisateurs backend (plugin client v0.5+), repli sur les super users.
        $backendList = $data['backend_users'] ?? null;

        if (\is_array($backendList) && !isset($backendList['error'])) {
            $result['backend_users'] = \count($backendList);

            foreach ($backendList as $user) {
                if (\is_array($user) && isset($user['username'])) {
                    $groups = isset($user['groups']) && \is_array($user['groups']) ? ' (' . implode(', ', $user['groups']) . ')' : '';
                    $result['backend_names'][] = $user['username'] . $groups;

                    if (($user['mfa_enabled'] ?? null) === false) {
                        $result['backend_no_mfa'][] = $user['username'];
                    } elseif (($user['mfa_enabled'] ?? null) === true) {
                        $result['backend_mfa']++;
                    }
                }
            }
        }

        // Sépare la mise à jour du cœur Joomla des mises à jour d'extensions
        // (packs de langue installés inclus).
        $available = $data['updates']['available'] ?? null;

        if (\is_array($available)) {
            $names         = [];
            $joomlaCurrent = (string) ($data['core']['joomla_version'] ?? '');

            foreach ($available as $update) {
                $newVersion = (string) ($update['new_version'] ?? '');

                if (($update['element'] ?? '') === 'joomla' && ($update['type'] ?? '') === 'file') {
                    // Ignore les entrées périmées (version proposée <= version installée).
                    if ($newVersion !== '' && ($joomlaCurrent === '' || version_compare($newVersion, $joomlaCurrent, '>'))) {
                        $result['joomla_update'] = $newVersion;
                    }
                } else {
                    // Même garde-fou pour les extensions quand la version actuelle est connue.
                    $current = (string) ($update['current_version'] ?? '');

                    if ($current !== '' && $newVersion !== '' && version_compare($newVersion, $current, '<=')) {
                        continue;
                    }

                    $names[] = ($update['name'] ?? '?') . ' → ' . ($newVersion !== '' ? $newVersion : '?');
                }
            }

            $result['ext_updates']       = \count($names);
            $result['ext_updates_names'] = $names;
        } else {
            // Plugin plus ancien : on retombe sur le compteur global du résumé.
            $result['ext_updates'] = (int) ($result['summary']['updates_available'] ?? 0);
        }

        return $result;
    }
}
