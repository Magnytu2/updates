<?php

/**
 * @package     Joomanji.Tikus
 * @subpackage  pkg_tikus
 *
 * @copyright   (C) 2026 Joomanji
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Version;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

/*
 * POURQUOI CE FICHIER EXISTE.
 *
 * Le verrou d'installation (décision de Cyrille du 16 octobre 2026, CLAUDE.md
 * § 10 « QUELLES VERSIONS DE JOOMLA NOUS SUIVONS »). Tikus suit la dernière
 * version mineure de Joomla, aujourd'hui la 6.2. Sur un Joomla plus ancien, le
 * paquet refuse l'installation ET la mise à jour, avant qu'une seule des
 * quatre extensions ne soit touchée, et dit pourquoi en une phrase.
 *
 * Le message est lu dans les fichiers de langue du paquet en cours
 * d'installation (ils ne sont pas encore posés sur le site à ce moment-là),
 * avec une phrase française en secours si la clé n'est pas trouvée.
 */

return new class () implements InstallerScriptInterface {
    /**
     * La plus ancienne version de Joomla acceptée.
     *
     * @var    string
     * @since  2.9.012
     */
    private const JOOMLA_MINIMUM = '6.2.0';

    public function install(InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function update(InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function uninstall(InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function preflight(string $type, InstallerAdapter $adapter): bool
    {
        if ($type === 'uninstall') {
            return true;
        }

        $joomla = \defined('JVERSION') ? JVERSION : (new Version())->getShortVersion();

        if (version_compare($joomla, self::JOOMLA_MINIMUM, '<')) {
            $version = (string) ($adapter->getManifest()->version ?? '');
            $app     = Factory::getApplication();

            try {
                $source = $adapter->getParent()->getPath('source');

                if ($source) {
                    $app->getLanguage()->load('pkg_tikus.sys', $source);
                }
            } catch (\Throwable $e) {
                // Sans fichier de langue, la phrase de secours ci-dessous suffit.
            }

            $message = Text::sprintf('PKG_TIKUS_JOOMLA_TROP_ANCIEN', $version);

            if (strpos($message, 'PKG_TIKUS_JOOMLA_TROP_ANCIEN') !== false) {
                $message = sprintf('Tikus %s demande Joomla 6.2 ou plus récent. Mettez d’abord Joomla à jour.', $version);
            }

            $app->enqueueMessage($message, 'error');

            return false;
        }

        return true;
    }

    public function postflight(string $type, InstallerAdapter $adapter): bool
    {
        return true;
    }
};
