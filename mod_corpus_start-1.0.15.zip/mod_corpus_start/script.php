<?php
/**
 * Ce qui se passe à l'installation du module.
 *
 * UN MODULE INSTALLÉ N'EST PAS UN MODULE POSÉ, et c'est une confusion que
 * Joomla traîne depuis toujours. « Installer » copie les fichiers et déclare
 * l'extension ; il faut ENSUITE créer une instance, lui donner une position, la
 * publier et l'affecter à des pages. Quatre gestes dans quatre écrans, pour un
 * module dont l'unique raison d'être est de s'afficher sur le tableau de bord.
 *
 * Demande de Cyrille du 5 septembre 2026 : que le module arrive publié, en
 * position `cpanel`, sans rien à régler.
 *
 * PREMIÈRE VERSION, ET CE QU'ELLE A DONNÉ. Elle écrivait la ligne d'un coup
 * avec `insertObject()`. Mesuré ensuite sur le banc neuf, formulaire d'édition
 * du module 287 sous les yeux : `title`, `access`, `language`, `client_id` et
 * `module` étaient bien posés, mais `position` était vide, `published` à 0 et
 * `showtitle` à 0. Trois champs sur huit perdus en route, sans la moindre
 * erreur.
 *
 * Je n'ai pas su expliquer pourquoi, et une explication inventée aurait été
 * pire qu'aucune. Cette version fait donc trois choses au lieu d'une :
 *
 *   1. elle écrit par `Table\Module`, l'API que Joomla utilise lui-même,
 *      plutôt que par une insertion à la main ;
 *   2. elle RELIT ce qu'elle vient d'écrire, et corrige d'une mise à jour
 *      explicite ce qui ne correspond pas ;
 *   3. elle note le résultat observé dans les réglages de l'extension, sous
 *      `poseTableauDeBord`. Si cela se reproduit, la trace sera là, et
 *      personne n'aura à deviner une deuxième fois.
 *
 * Le nom de la classe n'est pas libre. Lu dans `InstallerAdapter.php` de
 * Joomla 6.1.2, ligne 627 :
 *
 *     $className = InputFilter::getInstance()->clean($this->element, 'cmd')
 *                . 'InstallerScript';
 *
 * L'élément d'un module est son dossier : d'où `mod_corpus_startInstallerScript`,
 * en minuscules. Une classe mal nommée ne provoque aucune erreur, le script est
 * simplement ignoré, et on cherche longtemps pourquoi rien ne se passe.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Table\Module as ModuleTable;
use Joomla\Database\ParameterType;

class mod_corpus_startInstallerScript
{
    /**
     * La position voulue sur le tableau de bord de l'administration.
     */
    protected const POSITION = 'cpanel';

    /**
     * Après la copie des fichiers, sur une installation comme sur une mise à jour.
     *
     * @param  string $route  install, update ou discover_install
     * @param  mixed  $parent
     *
     * @return bool
     */
    public function postflight($route, $parent)
    {
        if (!\in_array($route, ['install', 'update', 'discover_install'], true)) {
            return true;
        }

        try {
            $trace = $this->poserSurLeTableauDeBord();
        } catch (\Throwable $e) {
            /*
             * ON N'EMPÊCHE JAMAIS UNE INSTALLATION DE RÉUSSIR POUR ÇA. Le module
             * est installé, ses fichiers sont en place ; le seul confort qu'on
             * n'a pas pu offrir est de le poser tout seul. Une exception ici
             * ferait échouer une installation par ailleurs valide.
             */
            $trace = ['erreur' => $e->getMessage()];

            Factory::getApplication()->enqueueMessage(
                Text::sprintf('MOD_CORPUS_START_SCRIPT_ECHEC', $e->getMessage()),
                'warning'
            );
        }

        $this->noterLaTrace($trace);

        return true;
    }

    /**
     * Pose l'instance en position `cpanel`, ou répare celle qui n'en a pas.
     *
     * @return array Ce qui a été fait, et ce qui a été relu ensuite.
     */
    protected function poserSurLeTableauDeBord(): array
    {
        $db = Factory::getContainer()->get('DatabaseDriver');

        /*
         * CE QUI EXISTE DÉJÀ. On regarde toutes positions et tous états
         * confondus, corbeille comprise : une instance jetée est un choix, et
         * en créer une seconde donnerait deux cartes le jour où l'utilisateur
         * vide sa corbeille.
         */
        $query = $db->getQuery(true)
            ->select($db->quoteName(['id', 'position', 'published', 'showtitle']))
            ->from($db->quoteName('#__modules'))
            ->where($db->quoteName('module') . ' = ' . $db->quote('mod_corpus_start'))
            ->where($db->quoteName('client_id') . ' = 1')
            ->order($db->quoteName('id') . ' ASC');

        $db->setQuery($query, 0, 1);
        $existante = $db->loadObject();

        /*
         * UNE INSTANCE DÉJÀ PLACÉE NE SE TOUCHE PAS. Si elle porte une position,
         * quelle qu'elle soit, quelqu'un l'a mise là : une mise à jour n'a pas à
         * défaire un rangement.
         *
         * UNE INSTANCE SANS POSITION, EN REVANCHE, N'EST LE CHOIX DE PERSONNE.
         * C'est une pose qui a échoué, et c'est exactement l'état laissé par la
         * première version de ce script. On la répare.
         */
        if ($existante && trim((string) $existante->position) !== '') {
            return ['action' => 'rien', 'id' => (int) $existante->id,
                    'position' => (string) $existante->position];
        }

        // Le titre suit la langue de l'administration, et vient du .sys.ini.
        Factory::getApplication()->getLanguage()->load(
            'mod_corpus_start.sys',
            JPATH_ADMINISTRATOR . '/modules/mod_corpus_start'
        );

        $id     = $existante ? (int) $existante->id : 0;
        $action = $existante ? 'reparation' : 'creation';

        if (!$id) {
            $id = $this->creerInstance(Text::_('MOD_CORPUS_START'));
        }

        if (!$id) {
            return ['action' => $action, 'id' => 0, 'echec' => 'aucun identifiant rendu'];
        }

        /*
         * ON RELIT, ET ON CORRIGE. C'est le cœur de cette version : quelle que
         * soit la raison pour laquelle un champ ne serait pas arrivé, une mise
         * à jour explicite et ciblée le rétablit. Trois colonnes, nommées une
         * par une, avec des valeurs liées.
         */
        $this->forcerPlacement($id);

        return ['action' => $action, 'id' => $id, 'relu' => $this->relire($id)];
    }

    /**
     * Crée l'instance par la table de Joomla, et rend son identifiant.
     *
     * `Table\Module` est l'API que le gestionnaire de modules utilise lui-même :
     * elle gère l'enregistrement d'accès (`asset_id`) et le contrôle des
     * valeurs. Une insertion à la main ne fait ni l'un ni l'autre.
     *
     * @param  string $titre
     *
     * @return int
     */
    protected function creerInstance(string $titre): int
    {
        $db = Factory::getContainer()->get('DatabaseDriver');

        /*
         * L'ORDRE D'AFFICHAGE. On se met APRÈS ce qui occupe déjà `cpanel` :
         * les cartes de Joomla, messages de post-installation et état
         * multilingue, sont plus urgentes qu'un module de démonstration.
         */
        $query = $db->getQuery(true)
            ->select('MAX(' . $db->quoteName('ordering') . ')')
            ->from($db->quoteName('#__modules'))
            ->where($db->quoteName('position') . ' = ' . $db->quote(self::POSITION))
            ->where($db->quoteName('client_id') . ' = 1');

        $ordre = (int) $db->setQuery($query)->loadResult() + 1;

        $table = new ModuleTable($db);

        $table->bind([
            'title'      => $titre,
            'note'       => '',
            'content'    => '',
            'ordering'   => $ordre,
            'position'   => self::POSITION,
            'published'  => 1,
            'module'     => 'mod_corpus_start',
            'access'     => 1,
            'showtitle'  => 1,
            'params'     => '{}',
            'client_id'  => 1,
            'language'   => '*',
            'publish_up' => null,
        ]);

        if (!$table->check() || !$table->store()) {
            throw new \RuntimeException($table->getError() ?: 'Table\Module a refusé la ligne.');
        }

        return (int) $table->id;
    }

    /**
     * Impose position, publication, titre visible, et l'affectation aux pages.
     *
     * @param  int $id
     *
     * @return void
     */
    protected function forcerPlacement(int $id): void
    {
        $db       = Factory::getContainer()->get('DatabaseDriver');
        $position = self::POSITION;

        $query = $db->getQuery(true)
            ->update($db->quoteName('#__modules'))
            ->set($db->quoteName('position') . ' = :position')
            ->set($db->quoteName('published') . ' = 1')
            ->set($db->quoteName('showtitle') . ' = 1')
            ->where($db->quoteName('id') . ' = :id')
            ->bind(':position', $position)
            ->bind(':id', $id, ParameterType::INTEGER);

        $db->setQuery($query)->execute();

        /*
         * L'AFFECTATION AUX PAGES, SANS LAQUELLE LE MODULE NE SORT NULLE PART.
         *
         * `#__modules_menu` avec `menuid = 0` veut dire « toutes les pages ».
         * Une instance sans aucune ligne dans cette table n'est affectée à
         * rien : elle est publiée, elle est bien placée, et elle reste
         * invisible. C'est la panne la plus longue à trouver, parce que tout a
         * l'air correct dans le gestionnaire de modules.
         */
        $query = $db->getQuery(true)
            ->select('COUNT(*)')
            ->from($db->quoteName('#__modules_menu'))
            ->where($db->quoteName('moduleid') . ' = :id')
            ->bind(':id', $id, ParameterType::INTEGER);

        if ((int) $db->setQuery($query)->loadResult() > 0) {
            return;
        }

        $lien = (object) ['moduleid' => $id, 'menuid' => 0];

        $db->insertObject('#__modules_menu', $lien);
    }

    /**
     * Relit la ligne, pour savoir ce qui est VRAIMENT en base.
     *
     * @param  int $id
     *
     * @return array
     */
    protected function relire(int $id): array
    {
        $db    = Factory::getContainer()->get('DatabaseDriver');
        $query = $db->getQuery(true)
            ->select($db->quoteName(['position', 'published', 'showtitle']))
            ->from($db->quoteName('#__modules'))
            ->where($db->quoteName('id') . ' = :id')
            ->bind(':id', $id, ParameterType::INTEGER);

        $ligne = $db->setQuery($query)->loadAssoc();

        $query = $db->getQuery(true)
            ->select('COUNT(*)')
            ->from($db->quoteName('#__modules_menu'))
            ->where($db->quoteName('moduleid') . ' = :id')
            ->bind(':id', $id, ParameterType::INTEGER);

        $ligne['pages'] = (int) $db->setQuery($query)->loadResult();

        return $ligne;
    }

    /**
     * Note dans les réglages de l'extension ce que la pose a donné.
     *
     * UNE TRACE QUI SURVIT À LA REQUÊTE. Un message à l'écran disparaît au
     * rafraîchissement suivant, et personne ne lit les journaux d'un site de
     * démonstration. Trois lignes de JSON dans les réglages de l'extension se
     * relisent des semaines plus tard, depuis le gestionnaire d'extensions ou
     * depuis une session de développement.
     *
     * @param  array $trace
     *
     * @return void
     */
    protected function noterLaTrace(array $trace): void
    {
        try {
            $db    = Factory::getContainer()->get('DatabaseDriver');
            $query = $db->getQuery(true)
                ->select($db->quoteName(['extension_id', 'params']))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('element') . ' = ' . $db->quote('mod_corpus_start'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('module'));

            $ligne = $db->setQuery($query)->loadObject();

            if (!$ligne) {
                return;
            }

            $params = json_decode((string) $ligne->params, true);
            $params = \is_array($params) ? $params : [];

            $trace['quand'] = Factory::getDate()->toSql();

            $params['poseTableauDeBord'] = $trace;

            $id      = (int) $ligne->extension_id;
            $encodes = json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            $query = $db->getQuery(true)
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('params') . ' = :params')
                ->where($db->quoteName('extension_id') . ' = :id')
                ->bind(':params', $encodes)
                ->bind(':id', $id, ParameterType::INTEGER);

            $db->setQuery($query)->execute();
        } catch (\Throwable $e) {
            // Une trace qui échoue ne doit rien casser : on la perd, c'est tout.
        }
    }
}
