<?php
/**
 * Scénario « Page d'atterrissage ».
 *
 * Celui-ci ne présente PAS le livre de recettes : il présente Corpus. Le
 * contenu commun est quand même installé, parce que les liens de la page et
 * du menu doivent mener quelque part, mais la page d'accueil ne parle que du
 * template.
 *
 * LE PRÉRÉGLAGE `landing` ÉTEINT LE COMPOSANT (`layoutEnable_content: 0`) :
 * la page n'est plus faite que de rangées de modules. C'est ce qui distingue
 * vraiment ce scénario des deux autres, et c'est aussi pourquoi il faut
 * garnir chaque rangée allumée, sous peine d'une page trouée.
 *
 * Les deux premières rangées reprennent EXACTEMENT celles de la maquette du
 * banc 8090, relevées à l'écran : le hero et son sommaire en vis-à-vis, puis
 * les trois tuiles. Les classes ont été portées au vocabulaire d'aujourd'hui,
 * `rule` et non `filet`, `btn` et non `bouton`, `card` et non `carte`.
 */

defined('_JEXEC') or die;

/*
 * TROIS PETITS ASSEMBLEURS, pour ne pas recopier vingt fois le même balisage.
 *
 * Des FERMETURES et non des fonctions nommées : ce fichier peut être lu
 * plusieurs fois dans la même requête, et une fonction déclarée deux fois
 * arrête PHP net.
 */

/*
 * Une carte à pastille, du tampon « Grille - Cartes avec etat ».
 *
 * LA COULEUR VIENT DES QUATRE PRÉRÉGLAGES DE TEINTE DE CORPUS, demande de
 * Cyrille : Bleu Joomla, Olive, Orange et Rouge profond. Un préréglage de style
 * ne stocke pas une couleur mais un ANGLE DE TEINTE, `styleTeinte`, à partir
 * duquel `_echelle.scss` construit tout le reste. On reprend donc sa formule
 * plutôt que d'inventer des valeurs :
 *
 *     clair   --accent : hsl(teinte 40% 32%)
 *     sombre  --accent : hsl(teinte 45% 70%)
 *
 * `light-dark()` demande un `color-scheme` déclaré : Corpus le pose sur la
 * racine, `light` d'un côté, `dark` de l'autre. La déclaration simple qui
 * précède sert de repli aux navigateurs qui ne connaissent pas la fonction,
 * et donne alors la version claire.
 *
 * CONTRASTES VÉRIFIÉS sur les quatre teintes, dans les deux thèmes, contre les
 * fonds de carte des deux échelles. Pire cas 5,05:1, l'olive sur `#f5f5f5`.
 * Le seuil est à 4,5:1.
 *
 * L'ATTRIBUTION NE CODE RIEN, et c'est voulu : les quatre lignes disent toutes
 * la même chose, « c'est là, et vous n'avez plus besoin de l'extension d'à
 * côté ». Une couleur qui semble classer alors qu'elle ne classe rien serait
 * pire qu'une couleur unique.
 */
$carte = static function (string $titre, string $texte, int $teinte, string $etat): string {
	$clair  = 'hsl(' . $teinte . ' 40% 32%)';
	$sombre = 'hsl(' . $teinte . ' 45% 70%)';

	return '<div class="col-md-3"><article class="card h-100"><div class="card-body">'
		. '<h3 class="lead fw-semibold mt-0 mb-2">' . $titre . '</h3>'
		. '<p>' . $texte . '</p>'
		. '<p class="mb-0" style="color:' . $clair . ';color:light-dark(' . $clair . ',' . $sombre . ')">'
		. '<span aria-hidden="true" style="display:inline-block;width:.6em;height:.6em;'
		. 'border-radius:50%;background:currentColor;margin-right:.4em"></span>'
		. '<strong>' . $etat . '</strong></p>'
		. '</div></article></div>';
};

// Un point numéroté, du tampon « Page - Points cles avec visuel ».
$point = static function (int $rang, string $titre, string $texte): string {
	return '<li class="d-flex gap-3 mb-4">'
		. '<span class="badge rounded-circle" aria-hidden="true">' . $rang . '</span><div>'
		. '<h3 class="lead fw-semibold mt-0 mb-2">' . $titre . '</h3>'
		. '<p class="mb-0">' . $texte . '</p>'
		. '</div></li>';
};

// Un volet d'accordéon, du tampon « FAQ - Accordeon ».
$volet = static function (string $id, bool $ouvert, string $question, string $reponse): string {
	return '<h3 class="accordeon__titre">'
		. '<button type="button" class="accordeon__bouton" aria-expanded="' . ($ouvert ? 'true' : 'false')
		. '" aria-controls="' . $id . '">' . $question . '</button></h3>'
		. '<div class="accordeon__volet" id="' . $id . '"' . ($ouvert ? '' : ' hidden') . '>'
		. '<p>' . $reponse . '</p></div>';
};

$contenu = require __DIR__ . '/commun.php';

/*
 * LES TEXTES, ET LA LANGUE DE CE QUI N'EN A QU'UNE.
 *
 * Depuis que le site de démonstration parle deux langues, la page existe en
 * deux exemplaires : c'est `parLangue`, plus bas, qui les monte. Ce qui suit ne
 * sert qu'à ce qui n'a qu'une seule valeur pour tout le site, le nom du style de
 * template par exemple, et suit alors la langue de l'ADMINISTRATION : celle que
 * la personne a sous les yeux au moment du clic.
 *
 * Une langue inconnue du fichier de textes retombe sur l'anglais, pas sur le
 * français : Joomanji vend hors de France.
 *
 * Un fichier de contenu qui interroge l'application, c'est une entorse à leur
 * rôle de simples données. Elle est assumée ici, pour un seul cas d'usage.
 */
$textes = require __DIR__ . '/landing-textes.php';
$langue = \Joomla\CMS\Factory::getApplication()->getLanguage()->getTag();
$t      = $textes[$langue] ?? $textes['en-GB'];

/*
 * LE SÉLECTEUR DE LANGUE, quand le site en a deux.
 *
 * IL N'EST PLUS DANS LA ZONE À DROITE DU MENU. Le 26 août 2026, demande de
 * Cyrille, mesurée avant d'être suivie. Cette zone porte déjà le menu d'appel à
 * l'action (deux entrées), et elle ne fait que deux douzièmes depuis le 25 :
 * les drapeaux passaient à la ligne, sous les boutons, et se voyaient à peine.
 *
 * IL PASSE À DROITE DU LOGO, dans `social-links`, la position que le préréglage
 * `landing` donne déjà à la zone `header_right`, laquelle était vide. C'est
 * `entete__outils`, la ligne du haut, à côté du nom du site : le premier endroit
 * où l'œil va, et le bon pour une commande de langue.
 *
 * POURQUOI ELLE DOIT ÊTRE VISIBLE, ET NON RANGÉE. La langue de la page est
 * choisie par le navigateur du visiteur (plugin de filtre de langue). Cette
 * détection se trompe : un Français en déplacement, un poste de travail
 * configuré en anglais, un lecteur qui veut lire l'original. Le choix de la
 * machine doit donc rester révocable d'un clic, sans le chercher. C'est aussi
 * ce que demande le RGAA : la langue est une propriété de la page, pas une
 * préférence enfouie.
 *
 * Le module s'ignore de lui-même sur un site qui n'a qu'une langue.
 */
$contenu['switch'] = [
	'title'    => 'Langues',
	'position' => 'social-links',
	'params'   => [
		'header_text'     => '',
		'footer_text'     => '',
		'dropdown'        => '0',
		'image'           => '1',
		'inline'          => '1',
		'show_active'     => '1',
		'full_name'       => '0',
		'horizontal'      => '1',
		'layout'          => '',
		'moduleclass_sfx' => '',
		'module_tag'      => 'div',
		'header_tag'      => 'h3',
		'header_class'    => '',
		'style'           => '0',
	],
];

/*
 * L'IDENTITÉ DE CETTE DÉMONSTRATION : son nom et sa couleur.
 *
 * LE NOM PASSE PAR `logoText`, le champ « Texte du logo » du style de template,
 * et NON par le nom du site. Mesuré dans `helper.php` du template, méthode
 * `siteName()` : le gabarit affiche `logoText` s'il est rempli, et retombe sur
 * `sitename` sinon. C'est donc un réglage de STYLE, sauvegardé et rendu à la
 * réinitialisation comme les autres. Écrire dans la configuration globale
 * aurait touché un fichier qui n'appartient pas à ce module.
 *
 * CE QUI RESTE AU NOM DU SITE : le titre de l'onglet du navigateur, et la
 * mention de copyright du pied de page, qui lisent tous deux `sitename` en
 * direct. À régler à la main dans la configuration globale de chaque site.
 *
 * LES DEUX RÉGLAGES VONT DANS LES DEUX STYLES, comme la largeur de page et pour
 * la même raison : le style dédié ne sert qu'à l'accueil, et un article ouvert
 * depuis le menu doit porter le même nom et la même couleur que la page d'où
 * l'on vient.
 *
 * L'olive est la teinte propre de Corpus. C'est la vitrine du template : elle
 * porte ses couleurs, les trois autres démonstrations montrent qu'on en change.
 */
$teintes  = require __DIR__ . '/teintes.php';
$identite = ['logoText' => 'Corpus - Landingpage'] + $teintes['olive'];

// Le sélecteur de langue, resserré dans les outils d'en-tête : il vit dans les
// deux styles, comme le nom et la couleur. Voir `css-switch.php`.
$identite['styleCssPerso'] = require __DIR__ . '/css-switch.php';

$contenu['preset'] = 'landing';

/*
 * UN STYLE DE TEMPLATE À PART, ET C'EST LE CŒUR DE CE SCÉNARIO.
 *
 * Le préréglage `landing` éteint le corps de page (`layoutEnable_content: 0`).
 * Écrit dans le style du site, il l'éteignait PARTOUT : chaque article
 * s'ouvrait sans <main>, avec les seules bandes de cette page qui se
 * répétaient. Diagnostic de Cyrille, vérifié sur le banc.
 *
 * Joomla prévoit exactement ce cas : plusieurs styles du même template, et un
 * choix de style par élément de menu. Le module crée donc une COPIE du style
 * du site, y écrit le préréglage et les réglages ci-dessous, et ne l'assigne
 * qu'à l'entrée d'accueil. Le reste du site garde son style et son corps de
 * page. Les couleurs, la typographie et le logo sont hérités de la copie : seule
 * la mise en page diffère.
 */
$contenu['styleDedie'] = [
	'title' => $t['styleDedie'],

	/*
	 * ET SUR LA SEULE PAGE D'ACCUEIL, PAS SUR LES AUTRES ENTRÉES.
	 *
	 * Relevé par Cyrille le 26 août 2026 sur landing.joomanji.eu : « Typographie »,
	 * « Les tampons », « Connexion » s'ouvraient sur une page vide. Le préréglage
	 * `landing` éteint le corps de page ; l'accueil s'en passe, puisqu'il est bâti
	 * de rangées de modules, mais toute autre page devient blanche.
	 *
	 * C'est le seul des quatre scénarios dans ce cas : le blog et le magazine ont
	 * une ossature qui vaut pour toutes leurs pages.
	 */
	'accueilSeul' => true,
];

/*
 * CE QUI VA DANS LE STYLE DU SITE, ET NON DANS LE STYLE DÉDIÉ.
 *
 * Le style dédié ne sert qu'à la page d'accueil. Tout le reste du site, les
 * articles, les catégories, la typographie, garde le style du site : Cyrille a
 * vu que ces pages restaient plus étroites que la page d'atterrissage.
 *
 * La largeur de page est donc posée DES DEUX CÔTÉS. Elle est la seule à
 * traverser : le préréglage `landing`, lui, doit rester enfermé dans le style
 * dédié, sinon on éteint de nouveau le corps de page du site entier.
 *
 * Écrit avec sauvegarde, comme pour le blog et le magazine : la
 * réinitialisation rend au style du site sa largeur d'avant.
 */
$contenu['styleParamsSite'] = $identite + [
	'layoutMaxWidth' => '1420px',

	/*
	 * LA ZONE À DROITE DU LOGO, OUVERTE SUR TOUT LE SITE. 26 août 2026.
	 *
	 * Le sélecteur de langue y est posé, et il est publié sur TOUTES les pages :
	 * si la zone n'était ouverte que dans le style dédié, il disparaîtrait dès
	 * qu'on quitte la page d'accueil. Une commande de langue qui ne suit pas le
	 * visiteur ne sert à rien : c'est en lisant un article qu'on s'aperçoit
	 * qu'on n'est pas dans la bonne langue.
	 *
	 * LARGEUR LAISSÉE VIDE, ET LE COMMENTAIRE D'ORIGINE EST PÉRIMÉ. Il disait
	 * que le gabarit calculait `12 - layoutWidth_header_left`. Ce calcul a
	 * disparu le 8 septembre 2026 avec les largeurs en classes Bootstrap :
	 * une largeur vide donne aujourd'hui une piste `auto`, et la boîte se
	 * dimensionne sur son contenu. Le résultat visible est le même, la raison
	 * n'est plus la même.
	 */
	'layoutEnable_header_right' => '1',
	'layoutPos_header_right'    => 'social-links',
	'layoutLargeur_header_right' => '',

	/*
	 * LA ZONE À DROITE DU MENU, ELLE AUSSI SUR TOUT LE SITE. 26 août 2026.
	 *
	 * Depuis que le style dédié ne vaut plus que pour l'accueil, tout ce qui
	 * doit se voir sur les AUTRES pages doit être ici. Le menu d'appel à
	 * l'action est publié partout ; sans cette zone allumée dans le style du
	 * site, il disparaissait dès qu'on ouvrait « Typographie ».
	 *
	 * Les largeurs suivent, pour la même raison : c'est le même menu qui
	 * s'affiche, et il réclame les mêmes dix douzièmes. Mesure du 25 août.
	 */
	'layoutEnable_nav_right' => '1',
	'layoutPos_nav_right'    => 'search',
	'layoutLargeur_nav_left'  => '10',
	'layoutLargeur_nav_right' => '2',
];

/*
 * LE FIL D'ARIANE N'A RIEN À FAIRE SUR UNE PAGE D'ATTERRISSAGE : il indique où
 * l'on est dans une arborescence, et cette page n'est nulle part dans une
 * arborescence, elle est le point d'entrée.
 *
 * IL NE SE RÈGLE PAS DANS LE STYLE. `index.php` inclut la position
 * `breadcrumbs` en dur, sans interrupteur de zone. Le gabarit du template le
 * dit lui-même : « pour ne pas le voir sur l'accueil, la bonne manoeuvre est de
 * désassigner le module de cet élément de menu ». C'est ce que fait le module,
 * et rien d'autre : le module de fil d'Ariane appartient à l'utilisateur, on ne
 * le dépublie pas, on l'exclut d'UNE page.
 */
$contenu['masquerAriane'] = true;

// --- Les réglages du style, posés par-dessus le préréglage -----------------
$contenu['styleParams'] = $identite + [
	// Plus large que le blog et le magazine, demandé par Cyrille : une page
	// d'atterrissage respire, elle n'a pas de colonne de texte à contenir.
	'layoutMaxWidth' => '1420px',

	// La première rangée en deux moitiés : le hero à gauche, le sommaire à
	// droite. C'est la disposition de la maquette du 8090.
	'layoutWidth_top_1' => '6:6',

	/*
	 * LE NOM D'UNE BANDE EST SON ANCRE. Mesuré dans `helper.php` du template :
	 * `$options['id'] = $this->getParam('layoutName_' . $pos) ?: $pos`, et le
	 * gabarit `corpus/position.php` le sort en `id` sur le <div class="section">.
	 * C'est donc ce champ, et lui seul, qui donne au menu du haut de quoi
	 * pointer.
	 *
	 * LE PRÉRÉGLAGE LIVRÉ EN POSE DE MAUVAIS, et c'est un défaut du template à
	 * corriger à la source : ils sont en anglais, hérités de JA Simpli, l'un
	 * d'eux est vide (la bande retombe alors sur `bot_1`), et surtout
	 * `gallery` y figure DEUX FOIS. Deux éléments du même document portaient
	 * donc le même identifiant, ce qui est invalide et rend l'ancre
	 * imprévisible.
	 *
	 * Sept noms, en français, sans accent ni espace : ils finissent dans une
	 * adresse.
	 */
	'layoutName_top_1' => 'presentation',
	'layoutName_top_2' => 'apercu',
	'layoutName_top_3' => 'chantiers',
	'layoutName_top_4' => 'partis-pris',
	'layoutName_bot_1' => 'chiffres',
	'layoutName_bot_2' => 'construction',
	'layoutName_bot_3' => 'questions',
	'layoutName_bot_4' => 'essayer',

	// LES CLASSES DE BANDE DU PRÉRÉGLAGE SONT PÉRIMÉES. Il porte `blue-bg` et
	// `grey-bg`, héritées du template d'origine, que Corpus ne déclare pas.
	// On les remplace par les siennes, celles d'`etc/aide-classes.ini`.
	'layoutClass_top_1' => '',
	'layoutClass_top_2' => 'section--alt',
	'layoutClass_top_3' => '',
	'layoutClass_top_4' => 'section--tint',

	// Les quatre rangées basses, qui portent la seconde moitié de la page.
	// Le préréglage colle `no-repeat,full-width` sur la première : encore une
	// classe du template d'origine, que Corpus ne déclare pas.
	'layoutEnable_bot_1' => '1',
	'layoutPos_bot_1'    => 'bottom-a',
	'layoutClass_bot_1'  => '',
	'layoutEnable_bot_2' => '1',
	'layoutPos_bot_2'    => 'bottom-b',
	'layoutClass_bot_2'  => 'section--alt',
	'layoutEnable_bot_3' => '1',
	'layoutPos_bot_3'    => 'bottom-c',
	'layoutClass_bot_3'  => '',
	'layoutEnable_bot_4' => '1',
	'layoutPos_bot_4'    => 'bottom-d',
	'layoutClass_bot_4'  => 'section--tint',

	/*
	 * LA QUATRIÈME RANGÉE BASSE SERT DEPUIS LE 25 AOÛT. Elle était éteinte
	 * faute d'emploi ; la bande « Comment Corpus est construit », insérée entre
	 * les chiffres et les questions, a décalé les deux suivantes d'un cran et
	 * l'appel final est venu l'occuper.
	 */

	/*
	 * LE PRÉRÉGLAGE PORTE ENCORE QUATRE TITRES DE RANGÉE EN ANGLAIS, hérités
	 * de JA Simpli : « Architecture & Technologies », « Images Gallery »,
	 * « FAQs » et « Subscribe to our mailing list for early access », avec
	 * leurs descriptions. Ils s'affichent en tête des bandes concernées.
	 *
	 * C'est un défaut de `landing.nvp`, du même genre que les positions et les
	 * classes mortes corrigées le 19 août. On les vide ici, mais le vrai
	 * correctif est dans le template.
	 */
	'layoutTitle_top_3' => '',
	'layoutDesc_top_3'  => '',
	'layoutTitle_bot_2' => '',
	'layoutDesc_bot_2'  => '',
	'layoutTitle_bot_3' => '',
	'layoutDesc_bot_3'  => '',
	'layoutTitle_bot_4' => '',
	'layoutDesc_bot_4'  => '',

	// Sans composant, deux colonnes latérales n'ont plus rien à encadrer.
	'layoutEnable_col_1' => '0',
	'layoutEnable_col_2' => '0',

	/*
	 * LA ZONE À DROITE DU MENU. Le préréglage l'éteint ; on l'allume, et on y
	 * met le menu d'appel à l'action plutôt que la recherche.
	 *
	 * Ce n'est pas un détournement : le gabarit du template le dit lui-même,
	 * « la zone reste libre, recherche, drapeaux, ou ce qu'on y publie », et
	 * elle ne porte aucun repère de recherche. Sur une page qui vend un
	 * template, un champ de recherche n'a rien à chercher ; deux boutons, si.
	 *
	 * LA RÉPARTITION EST 10 / 2, ET NON 8 / 4. Mesure du 25 août sur le banc :
	 * à huit douzièmes, la liste du menu réclamait 949 pixels pour 843
	 * disponibles, et débordait sur la zone de droite. Le menu d'action, lui,
	 * ne porte que deux entrées courtes et se contente de deux douzièmes.
	 */
	'layoutEnable_nav_right' => '1',
	'layoutPos_nav_right'    => 'search',
	'layoutLargeur_nav_left'  => '10',
	'layoutLargeur_nav_right' => '2',

	/*
	 * LA ZONE À DROITE DU LOGO, RÉPÉTÉE ICI. Le préréglage `landing` la donne
	 * déjà (`layoutEnable_header_right: 1`, `layoutPos_header_right:
	 * social-links`) : on ne fait que l'écrire noir sur blanc, pour que le
	 * scénario ne dépende pas d'un fichier du template qu'il ne contrôle pas.
	 * Le sélecteur de langue y est publié.
	 */
	'layoutEnable_header_right' => '1',
	'layoutPos_header_right'    => 'social-links',
	'layoutLargeur_header_right' => '9',

	/*
	 * L'EN-TÊTE DE CETTE DÉMONSTRATION : 3 / 9, MENU CENTRÉ. 8 septembre 2026.
	 *
	 * Les quatre démonstrations avaient jusqu'ici le MÊME en-tête, et ne
	 * montraient donc qu'une seule des mises en page que Corpus sait faire.
	 * Chacune en prend une desormais.
	 *
	 * Ici, celle d'une page qui vend : une marque discrète calée à gauche, la
	 * ligne de service à droite, et le menu CENTRÉ sous elle. Le centrage du
	 * menu est le seul du lot : il donne à la barre l'allure d'un sommaire
	 * plutôt que d'une barre d'outils.
	 */
	'layoutLargeur_marque' => '3',
	'layoutAlign_marque'   => 'debut',
	'layoutAlign_header_right' => 'fin',
	'layoutAlign_nav_left'     => 'centre',
	'layoutAlign_nav_right'    => 'fin',
];

$contenu['featured'] = [];

/*
 * ---- CE QUI DÉPEND DE LA LANGUE ------------------------------------------
 *
 * Le module appelle cette fermeture une fois par langue installée, et monte
 * pour chacune son menu, ses entrées et ses modules. C'est la règle du
 * multilingue de Joomla : un module sans langue s'affiche dans toutes, et un
 * seul menu pour deux langues sortirait les deux jeux d'entrées l'un sous
 * l'autre.
 *
 * Sur un site qui n'a qu'une langue installée, le module ne l'appelle pas et
 * reprend le tableau tel quel, en langue « Toutes ».
 */
$contenu['parLangue'] = static function (string $code) use ($textes, $carte, $point, $volet): array {
	$t    = $textes[$code] ?? $textes['en-GB'];
	$bloc = ['menuTitre' => $t['menuAccueil']];

	// --- Le menu propre à la page d'atterrissage ------------------------------
	// Un VRAI menu Joomla, et non deux boutons écrits à la main dans un module de
	// contenu : la personne qui découvre Joomla doit pouvoir l'ouvrir dans
	// Menus, en changer les entrées, et voir la page suivre.
	$bloc['menus'] = [
		'actions' => [
			'menutype'    => 'corpus-actions',
			'title'       => $t['menuActions'],
			'description' => $t['menuActionsDesc'],
		],
	];

	// Aucun article en vedette : le composant est éteint, personne ne les verrait.
	// --- Les modules ----------------------------------------------------------
	$bloc['modules'] = [

		// ---- RANGÉE 1, moitié gauche : le hero -------------------------------
		[
			'title'     => 'Corpus, en une phrase',
			'module'    => 'mod_custom',
			'position'  => 'top-a',
			'showtitle' => 0,
			'pages'     => 'home',
			/*
			 * LE TITRE ET L'ACCROCHE, réécrits le 25 août à la demande de Cyrille.
			 *
			 * Les précédents parlaient des sites de l'État et de leur identité
			 * visuelle : ils décrivaient à qui le template s'adresse, pas ce qu'il
			 * est. Sur une page qui présente Corpus, c'est le produit qui doit
			 * parler en premier.
			 *
			 * L'accroche est la formule « inventaire » écrite pour le pied de site
			 * et écartée là-bas au profit de la formule à contraste. Elle est à sa
			 * place ici, où il y a de la largeur : elle nomme les pièces au lieu de
			 * promettre des qualités.
			 */
			'content'   => '<h1 class="mt-0">' . $t['heroTitre'] . '</h1>'
				. '<p class="lead">' . $t['heroLead'] . '</p>'
				. '<p class="boutons">'
				. '<a class="btn" href="{lien:les-tampons}">' . $t['heroBtn1'] . '</a> '
				. '<a class="btn btn-secondary" href="{lien:typographie}">' . $t['heroBtn2'] . '</a>'
				. '</p>'
				. '<p class="note">' . $t['heroNote'] . '</p>',
			'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
		],

		// ---- RANGÉE 1, moitié droite : l'alerte et le sommaire ---------------
		[
			'title'     => 'Sommaire',
			'module'    => 'mod_custom',
			'position'  => 'top-a',
			'showtitle' => 0,
			'pages'     => 'home',
			'content'   => '<div class="message rule message--info" role="note"><div>'
				. '<p class="message__titre">' . $t['noteTitre'] . '</p>'
				. '<p>' . $t['noteTexte'] . '</p>'
				. '</div></div>'
				. '<div class="sommaire">'
				. '<p class="message__titre">' . $t['sommaire'] . '</p>'
				. '<ol>'
				. '<li><a href="{lien:typographie}">' . $t['somTypo'] . '</a></li>'
				. '<li><a href="{lien:les-tampons}">' . $t['somTampons'] . '</a></li>'
				. '<li><a href="{lien:recettes}">' . $t['somGabarit'] . '</a></li>'
				. '<li><a href="{lien:potager}">' . $t['somNative'] . '</a></li>'
				. '<li><a href="index.php?option=com_finder&view=search">' . $t['somRech'] . '</a></li>'
				. '<li><a href="index.php?option=com_users&view=login">' . $t['somConnex'] . '</a></li>'
				. '<li><a href="index.php?option=com_contact&view=categories&id=0">' . $t['somContacts'] . '</a></li>'
				. '<li><a href="{lien:aubergine}">' . $t['somArticle'] . '</a></li>'
				. '</ol>'
				. '</div>',
			'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
		],

		// ---- RANGÉE 2 : les trois tuiles -------------------------------------
		[
			'title'     => 'Trois entrées',
			'module'    => 'mod_custom',
			'position'  => 'top-b',
			'showtitle' => 0,
			'pages'     => 'home',
			// LE TITRE N'EST PAS DÉCORATIF ICI. La navigation d'ancres de Corpus
			// ignore une bande sans titre de niveau 1 à 3, et cette rangée n'en
			// avait aucun : ses trois tuiles portent des `<p class="lead">`. Elle
			// serait donc restée absente de la colonne de points, alors qu'une
			// entrée du menu du haut y mène.
			'content'   => '<h2 class="rule">' . $t['apercuTitre'] . '</h2>'
				. '<div class="row g-4">'
				. '<div class="col-md-4"><article class="card"><div class="card-body">'
				. '<h3 class="lead fw-semibold mt-0 mb-2"><a href="{lien:typographie}">' . $t['tuile1Titre'] . '</a></h3>'
				. '<p>' . $t['tuile1Texte'] . '</p>'
				. '</div></article></div>'
				. '<div class="col-md-4"><article class="card"><div class="card-body">'
				. '<h3 class="lead fw-semibold mt-0 mb-2"><a href="{lien:les-tampons}">' . $t['tuile2Titre'] . '</a></h3>'
				. '<p>' . $t['tuile2Texte'] . '</p>'
				. '</div></article></div>'
				. '<div class="col-md-4"><article class="card"><div class="card-body">'
				. '<h3 class="lead fw-semibold mt-0 mb-2"><a href="{lien:recettes}">' . $t['tuile3Titre'] . '</a></h3>'
				. '<p>' . $t['tuile3Texte'] . '</p>'
				. '</div></article></div>'
				. '</div>',
			'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
		],

		// ---- RANGÉE 3 : les quatre cartes à pastille -------------------------
		// Le tampon « Grille - Cartes avec etat », celui de la maquette de la
		// boutique. Sa pastille prend sa couleur d'un jeton du template, avec un
		// repli en dur : rien n'est inventé ici. Quatre colonnes au lieu de trois.
		[
			'title'     => 'Ce que fait Corpus',
			'module'    => 'mod_custom',
			'position'  => 'top-c',
			'showtitle' => 0,
			'pages'     => 'home',
			'content'   => '<h2 class="rule">' . $t['chantiersTitre'] . '</h2>'
				. '<p>' . $t['chantiersLead'] . '</p>'
				. '<div class="row g-4">'
				. $carte($t['carte1Titre'], $t['carte1Texte'], 332, $t['carte1Etat'])
				. $carte($t['carte2Titre'], $t['carte2Texte'], 214, $t['carte2Etat'])
				. $carte($t['carte3Titre'], $t['carte3Texte'], 30,  $t['carte3Etat'])
				. $carte($t['carte4Titre'], $t['carte4Texte'], 90,  $t['carte4Etat'])
				. '</div>',
			'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
		],

		// ---- RANGÉE 4 : les quatre partis pris, avec leurs pastilles ---------
		[
			'title'     => 'Quatre partis pris',
			'module'    => 'mod_custom',
			'position'  => 'top-d',
			'showtitle' => 0,
			'pages'     => 'home',
			'content'   => '<div class="row align-items-center">'
				. '<div class="col-lg-6 mb-4">'
				. '<img class="img-fluid" src="images/corpus-start/layout-corpus.webp"'
				. ' alt="' . $t['partisAlt'] . '"'
				. ' width="800" height="594">'
				. '</div>'
				. '<div class="col-lg-6">'
				. '<h2 class="rule mt-0">' . $t['partisTitre'] . '</h2>'
				. '<ol class="list-unstyled">'
				. $point(1, $t['parti1Titre'], $t['parti1Texte'])
				. $point(2, $t['parti2Titre'], $t['parti2Texte'])
				. $point(3, $t['parti3Titre'], $t['parti3Texte'])
				. $point(4, $t['parti4Titre'], $t['parti4Texte'])
				. '</ol>'
				. '</div></div>',
			'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
		],

		// ---- RANGÉE BASSE 1 : ce qui est mesuré ------------------------------
		// La règle de la maquette de la boutique, reprise telle quelle : un nombre
		// qu'on ne peut pas aller vérifier n'entre pas dans ce bloc.
		[
			'title'     => 'Vérifié, pas promis',
			'module'    => 'mod_custom',
			'position'  => 'bottom-a',
			'showtitle' => 0,
			'pages'     => 'home',
			'content'   => '<h2 class="rule">' . $t['chiffresTitre'] . '</h2>'
				. '<p>' . $t['chiffresLead'] . '</p>'
				. '<div class="row text-center">'
				. '<div class="col-md-4"><p><strong style="font-size:2.5rem;line-height:1.1;display:block">55</strong> '
				. $t['chiffre1'] . '</p></div>'
				. '<div class="col-md-4"><p><strong style="font-size:2.5rem;line-height:1.1;display:block">19</strong> '
				. $t['chiffre2'] . '</p></div>'
				. '<div class="col-md-4"><p><strong style="font-size:2.5rem;line-height:1.1;display:block">4</strong> '
				. $t['chiffre3'] . '</p></div>'
				. '</div>',
			'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
		],

		/*
		 * ---- RANGÉE BASSE 2 : comment c'est construit ------------------------
		 *
		 * Demande de Cyrille du 25 août : un acheteur intégrateur, même débutant,
		 * veut savoir ce qu'il y a sous le capot avant d'installer.
		 *
		 * CHAQUE AFFIRMATION DE CE BLOC A ÉTÉ RELEVÉE DANS LE CODE DE CORPUS, et
		 * non déduite. Le chargement de Bootstrap et la condition sur son
		 * JavaScript sont dans `index.php` ; les dix-neuf partiels Sass et la
		 * feuille unique sont dans `media/scss` et `package.json` ; l'angle de
		 * teinte est `--corpus-teinte` dans `_echelle.scss` ; les deux scripts de
		 * contrôle sont `tools/contraste.mjs` et `tools/verifier.mjs`, et le second
		 * a bien rattrapé un `right: 0; width: 28px` déplacé en silence, sa notice
		 * le raconte.
		 *
		 * CE QUI N'Y EST PAS, ET POURQUOI. Les attaques de juillet 2026 dont parle
		 * Cyrille n'y figurent pas : je ne les ai pas vérifiées, viser une catégorie
		 * de produits concurrents l'expose, et surtout un argument daté vieillit mal
		 * sur une page qui reste en ligne des années. L'encadré dit la même chose
		 * sans dépendre d'un événement : ce qui n'est pas embarqué ne peut pas être
		 * une porte d'entrée. Sa place, si Cyrille y tient, est un article daté et
		 * sourcé dans le Journal, avec un lien depuis ici.
		 */
		[
			'title'     => 'Comment Corpus est construit',
			'module'    => 'mod_custom',
			'position'  => 'bottom-b',
			'showtitle' => 0,
			'pages'     => 'home',
			'content'   => '<h2 class="rule">' . $t['constrTitre'] . '</h2>'
				. '<p>' . $t['constrLead'] . '</p>'
				. '<div class="row g-4">'

				. '<div class="col-md-4"><article class="card h-100"><div class="card-body">'
				. '<h3 class="lead fw-semibold mt-0 mb-2">' . $t['constr1Titre'] . '</h3>'
				. '<p>' . $t['constr1Texte'] . '</p>'
				. '</div></article></div>'

				. '<div class="col-md-4"><article class="card h-100"><div class="card-body">'
				. '<h3 class="lead fw-semibold mt-0 mb-2">' . $t['constr2Titre'] . '</h3>'
				. '<p>' . $t['constr2Texte'] . '</p>'
				. '</div></article></div>'

				. '<div class="col-md-4"><article class="card h-100"><div class="card-body">'
				. '<h3 class="lead fw-semibold mt-0 mb-2">' . $t['constr3Titre'] . '</h3>'
				. '<p>' . $t['constr3Texte'] . '</p>'
				. '</div></article></div>'

				. '</div>'

				. '<div class="row g-4 mt-2">'

				. '<div class="col-md-6"><article class="card h-100"><div class="card-body">'
				. '<h3 class="lead fw-semibold mt-0 mb-2">' . $t['constr4Titre'] . '</h3>'
				. '<p>' . $t['constr4Texte'] . '</p>'
				. '</div></article></div>'

				. '<div class="col-md-6"><article class="card h-100"><div class="card-body">'
				. '<h3 class="lead fw-semibold mt-0 mb-2">' . $t['constr5Titre'] . '</h3>'
				. '<p>' . $t['constr5Texte'] . '</p>'
				. '</div></article></div>'

				. '</div>',
			'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
		],

		// ---- RANGÉE BASSE 3 : les questions ----------------------------------
		[
			'title'     => 'Les questions qu\'on nous pose',
			'module'    => 'mod_custom',
			'position'  => 'bottom-c',
			'showtitle' => 0,
			'pages'     => 'home',
			'content'   => '<h2 class="rule">' . $t['questionsTitre'] . '</h2>'
				. '<div class="accordeon">'
				. $volet('landing-q1', true, $t['q1'], $t['r1'])
				. $volet('landing-q2', false, $t['q2'], $t['r2'])
				. $volet('landing-q3', false, $t['q3'], $t['r3'])
				. $volet('landing-q4', false, $t['q4'], $t['r4'])
				. $volet('landing-q5', false, $t['q5'], $t['r5'])
				. $volet('landing-q6', false, $t['q6'], $t['r6'])
				. $volet('landing-q7', false, $t['q7'], $t['r7'])
				. $volet('landing-q8', false, $t['q8'], $t['r8'])
				. $volet('landing-q9', false, $t['q9'], $t['r9'])
				. $volet('landing-q10', false, $t['q10'], $t['r10'])
				. '</div>',
			'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
		],

		// ---- RANGÉE BASSE 4 : l'appel final ----------------------------------
		[
			'title'     => 'Voir avant de décider',
			'module'    => 'mod_custom',
			'position'  => 'bottom-d',
			'showtitle' => 0,
			'pages'     => 'home',
			'content'   => '<div class="panneau__boite">'
				. '<h2>' . $t['appelTitre'] . '</h2>'
				. '<p>' . $t['appelTexte'] . '</p>'
				. '<p><a class="btn" href="{lien:recettes}">' . $t['appelBtn1'] . '</a>'
				. ' <a class="btn btn-secondary" href="{lien:les-tampons}">' . $t['appelBtn2'] . '</a></p>'
				. '</div>',
			'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
		],

		/*
		 * ---- LE MENU DE DROITE, propre à la page d'atterrissage --------------
		 *
		 * Il remplace la recherche des deux autres scénarios. `menutype` désigne le
		 * menu créé plus haut : son nom réel n'est connu qu'à l'installation, d'où
		 * le repère {menu:…}.
		 *
		 * LES RÉGLAGES SONT ÉNUMÉRÉS EN ENTIER, pour la même raison que dans le
		 * scénario magazine : un module écrit par du code ne reçoit aucune valeur
		 * par défaut de son manifeste. `startLevel` absent, mod_menu n'affiche rien.
		 */
		[
			'title'     => 'Essayer Corpus',
			'module'    => 'mod_menu',
			'position'  => 'search',
			'showtitle' => 0,
			'pages'     => 'home',
			'params'    => [
				'menutype'        => '{menu:actions}',
				'base'            => '',
				'startLevel'      => '1',
				'endLevel'        => '0',
				'showAllChildren' => '0',
				'tag_id'          => '',
				'class_sfx'       => '',
				'window_open'     => '',
				'layout'          => '',
			],
		],
	];

	/*
	 * ---- LE PIED DE SITE -------------------------------------------------
	 * Commun aux quatre scénarios. Ses réglages vont dans le STYLE DÉDIÉ, comme
	 * tout ce scénario ; sur les autres pages, le pied du site garde les siens, et
	 * les deux modules s'y affichent quand même puisqu'ils sont publiés partout.
	 */
	$pied = require __DIR__ . '/pied.php';

	// LE PIED SUIT LA LANGUE DE LA PAGE, et non le français en dur. Relevé sur le
	// banc le 25 août : la page passait bien en anglais, et le pied restait en
	// français sous elle, mention de marque comprise.
	$bloc['modules'] = array_merge($bloc['modules'], $pied($code));

	$contenu['styleParams']['layoutEnable_footer'] = '1';
	$contenu['styleParams']['layoutPos_footer']    = 'footer';

	/*
	 * ---- LA BARRE D'INFORMATION -------------------------------------------
	 * La bande fine au-dessus de l'en-tête, elle aussi commune aux quatre
	 * scénarios : les réseaux à gauche, un numéro à droite.
	 */
	$barre = require __DIR__ . '/barre.php';

	// Même raison que pour le pied, juste au-dessus.
	$bloc['modules'] = array_merge($bloc['modules'], $barre($code));

	// `section--tint` est le fond teinté de Corpus, dérivé de la teinte du site :
	// un bandeau de couleur qui suit le préréglage de teinte au lieu de le
	// contredire. La barre est allumée d'office, au cas où un réglage antérieur
	// l'aurait éteinte.
	$contenu['styleParams']['layoutEnable_topbar'] = '1';
	$contenu['styleParams']['layoutFond_topbar']   = 'section--tint';

	/*
	 * ---- LES LIENS VERS LES TROIS AUTRES DÉMONSTRATIONS -------------------
	 *
	 * Dans la zone à droite du logo, JUSTE AVANT les drapeaux : le sélecteur de
	 * langue est créé après la boucle des langues, donc après ce module, et deux
	 * modules d'une même position sortent dans l'ordre où ils ont été créés.
	 *
	 * Le second argument nomme le scénario de CE site, celui qu'on ne met pas en
	 * lien : on ne s'envoie pas vers soi-même.
	 */
	$demos = require __DIR__ . '/demos.php';

	$bloc['modules'] = array_merge($bloc['modules'], $demos($code, 'landing'));

	// --- Le menu --------------------------------------------------------------
	/*
	 * LE MENU DU HAUT SUIT LES SECTIONS DE LA PAGE, demande de Cyrille, et c'est la
	 * règle d'une page d'atterrissage : la barre ne conduit pas ailleurs, elle
	 * déroule la page. Les ancres pointent les `layoutName_*` posés plus haut.
	 *
	 * PAS DE MÉGA-MENU ICI. Le panneau à trois colonnes du blog et du magazine y
	 * est à sa place : les recettes sont le sujet de ces deux sites. Sur une page
	 * qui présente le template, le sujet est le template ; « Découvrir » devient
	 * donc un sous-menu ordinaire, de « Typographie » à « Contacts ».
	 *
	 * LES ENTRÉES DE CONTENU NE SONT PAS SUPPRIMÉES POUR AUTANT, et c'est le point
	 * qui compte : les liens de la page pointent les recettes, le potager et un
	 * article de légume. Sans élément de menu, com_content n'a plus d'Itemid à
	 * saisir et rend une adresse de repli, du genre `/component/content/article?id=42`.
	 * Le lien marcherait, mais mal.
	 *
	 * On les garde donc, avec le paramètre natif `menu_show` à 0 : « Afficher dans
	 * le menu, Non ». Mesuré dans `MenuHelper` de mod_menu, ligne 91, l'entrée est
	 * écartée de la navigation ET de ses enfants, mais elle reste en base, avec son
	 * Itemid et sa route lisible. C'est exactement ce que Joomla fait pour ses
	 * propres pages techniques.
	 */
	// Le fichier rend une fonction depuis le 26 août : les intitulés du
	// méga-menu suivent la langue de la page comme le reste du menu.
	$menuCommun = (require __DIR__ . '/menu.php')($code);
	$menuHaut   = [];

	// Les deux colonnes du méga-menu qui disparaissent en tant que colonnes.
	$colonnesRetirees = ['col-recettes', 'col-potager'];

	// Les doublons qu'elles portaient : ces deux entrées visent les mêmes
	// catégories que « Recettes » et « Le potager » de premier niveau. Deux
	// éléments de menu pour une même vue, c'est un Itemid de trop.
	//
	// ON LES DÉSIGNE PAR LEUR CLÉ, ET PLUS PAR LEUR INTITULÉ. 26 août 2026.
	// Depuis que `menu.php` traduit ses intitulés, « Toutes les recettes »
	// s'appelle « All recipes » en anglais : le test par le texte ne trouvait
	// plus rien et les deux doublons revenaient dans le menu anglais.
	$doublons = ['toutes-recettes', 'tous-legumes'];

	foreach ($menuCommun as $entree) {
		$cle    = $entree['key'] ?? '';
		$parent = $entree['parent'] ?? '';

		if (in_array($cle, $colonnesRetirees, true) || in_array($cle, $doublons, true)) {
			continue;
		}

		// « Le site » n'a plus de sœurs : ses entrées passent directement sous
		// « Découvrir », et l'intitulé de colonne n'a plus d'objet.
		if ($cle === 'col-site') {
			continue;
		}

		if ($parent === 'col-site') {
			$entree['parent'] = 'decouvrir';
			$menuHaut[]       = $entree;
			continue;
		}

		// Les orphelines des deux colonnes retirées, et les deux entrées de
		// contenu de premier niveau : gardées, hors navigation.
		$orpheline = in_array($parent, $colonnesRetirees, true);
		$contenu1  = $parent === '' && ($entree['type'] ?? '') === 'category' && $cle === '';

		if ($orpheline || $contenu1) {
			unset($entree['parent']);
			$entree['params'] = array_merge($entree['params'] ?? [], ['menu_show' => '0']);
			$menuHaut[]       = $entree;
			continue;
		}

		// « Découvrir » redevient une entrée ordinaire : sans le mot « mega » dans
		// le champ « Style CSS du lien », Corpus rend un sous-menu déroulant.
		if ($cle === 'decouvrir') {
			unset($entree['mega']);
		}

		if (!empty($entree['home'])) {
			// Le composant est éteint : cette entrée ne sert plus qu'à porter la
			// page par défaut et à donner leur adresse aux modules.
			$entree['title'] = $t['menuAccueil'];

			/*
			 * LA CLASSE DE PAGE `landing` ALLUME LA NAVIGATION D'ANCRES DE CORPUS,
			 * la colonne de points contre le bord droit. Relevé par Cyrille sur le
			 * banc, puis vérifié dans le template : `index.php` sort la classe de
			 * page sur le <body>, et `template.js` ne construit la colonne que si
			 * le <body> la porte. Elle se décide donc page par page, sur l'élément
			 * de menu, onglet « Affichage de la page ».
			 *
			 * CE QU'ELLE LIT : toute bande portant un `id` ET un titre de niveau 1
			 * à 3, dont elle prend le texte pour intituler le lien. Une bande sans
			 * titre est ignorée, faute de quoi le lien serait annoncé par son
			 * adresse. C'est pourquoi chacune des sept bandes de cette page en
			 * porte un.
			 */
			$entree['params'] = array_merge(
				$entree['params'] ?? [],
				['pageclass_sfx' => 'landing']
			);
		}

		$menuHaut[] = $entree;
	}

	/*
	 * LES ANCRES, insérées juste après l'accueil, donc avant le méga-menu qui doit
	 * rester le dernier. Elles portent le type natif `url` de Joomla, jamais un
	 * lien de composant : voir le commentaire de `createMenuItem`.
	 *
	 * `presentation` n'a pas d'entrée : c'est la première bande de la page, on y
	 * est déjà en arrivant, et un lien qui ne bouge pas est un lien mort.
	 */
	$ancres = [
		['title' => $t['mAper'],        'type' => 'ancre', 'link' => '#apercu',       'alias' => 'ancre-apercu'],
		['title' => $t['mChantiers'],   'type' => 'ancre', 'link' => '#chantiers',    'alias' => 'ancre-chantiers'],
		['title' => $t['mPartis'],      'type' => 'ancre', 'link' => '#partis-pris',  'alias' => 'ancre-partis-pris'],
		['title' => $t['mChiffres'],    'type' => 'ancre', 'link' => '#chiffres',     'alias' => 'ancre-chiffres'],
		['title' => $t['mConstruction'],'type' => 'ancre', 'link' => '#construction', 'alias' => 'ancre-construction'],
		['title' => $t['mQuestions'],   'type' => 'ancre', 'link' => '#questions',    'alias' => 'ancre-questions'],
	];

	array_splice($menuHaut, 1, 0, $ancres);

	/*
	 * LE MENU DE DROITE. Deux entrées, dans le menu créé pour lui : la première
	 * descend à la dernière bande de la page, la seconde ouvre la démonstration.
	 * Elles vivent dans un menu à part, donc elles ne s'ajoutent pas à la barre.
	 */
	$menuHaut[] = [
		'menu'  => 'actions',
		'title' => $t['mEssayer'],
		'type'  => 'ancre',
		'link'  => '#essayer',
		'alias' => 'action-essayer',
	];

	$menuHaut[] = [
		'menu'    => 'actions',
		'title'   => $t['mTampons'],
		'type'    => 'article',
		'article' => 'les-tampons',
		'alias'   => 'action-tampons',
	];

	/*
	 * ---- LES PICTOGRAMMES ----------------------------------------------------
	 *
	 * SEULEMENT SUR CE SCÉNARIO, demande de Cyrille : la page d'atterrissage est
	 * la vitrine, le blog et le magazine gardent un menu nu.
	 *
	 * LE CHAMP EST `menu_icon_css`, « Classe de l'icône du lien », et pas
	 * `menu-anchor_css`, qui porte le déclencheur du méga-menu. Mesuré dans
	 * `MenuHelper` de mod_menu, ligne 164 : c'est lui qui alimente
	 * `$item->menu_icon`, dont les trois gabarits du cœur (url, heading,
	 * component) tirent un `<span class="p-2 pt-0 …" aria-hidden="true"></span>`
	 * devant l'intitulé.
	 *
	 * CORPUS NE S'EN SERT PAS COMME D'UNE FONTE D'ICÔNES. Sa surcharge de
	 * mod_menu récolte ce span, en extrait le premier mot commençant par `i-`, et
	 * le remplace par un `<svg><use href="#i-…">` pris dans son propre jeu de
	 * symboles. Une classe FontAwesome laisserait donc un blanc : les noms
	 * ci-dessous sont ceux du fichier `html/layouts/corpus/pictogrammes.php`, et
	 * eux seuls.
	 *
	 * Les entrées hors navigation n'en reçoivent pas : personne ne les voit.
	 */
	/*
	 * DEUX TABLES, PARCE QU'IL Y A DEUX ORIGINES. 26 août 2026.
	 *
	 * Les entrées venues de `menu.php` traduisent maintenant leur intitulé : les
	 * désigner par le texte marchait en français et ratait tout en anglais.
	 * Elles se désignent donc par leur CLÉ, qui ne change pas de langue.
	 *
	 * Les entrées construites ici même (les ancres, le menu d'action) n'ont pas
	 * de clé : elles gardent le texte, qui vient du même fichier de textes et
	 * suit donc déjà la langue.
	 */
	$pictogrammesParCle = [
		'accueil'    => 'i-accueil',
		'decouvrir'  => 'i-dossier',
		'typo'       => 'i-etiquette',
		'tampons'    => 'i-affichage',
		'connexion'  => 'i-utilisateur',
		'compte'     => 'i-ticket',
		'motdepasse' => 'i-alerte',
		'recherche'  => 'i-recherche',
		'contacts'   => 'i-contact',
	];

	$pictogrammes = [
		$t['menuAccueil']    => 'i-accueil',
		$t['mChantiers']     => 'i-missions',
		$t['mPartis']        => 'i-accessibilite',
		/*
		 * « Aperçu », « Les chiffres » et « Questions » n'ont PAS de pictogramme, et
		 * c'est voulu depuis le 25 août : la barre débordait. Mesuré sur le banc, la
		 * liste faisait 949 pixels pour 843 disponibles, et chaque pictogramme coûte
		 * une trentaine de pixels. Ils ont été retirés un à un, à vue, en gardant
		 * ceux des entrées que Cyrille veut voir en premier.
		 */
		$t['mConstruction']  => 'i-demarches',
		$t['mTampons']       => 'i-affichage',
		$t['mEssayer']       => 'i-fleche',
	];

	foreach ($menuHaut as &$entree) {
		$picto = $pictogrammesParCle[$entree['key'] ?? ''] ?? ($pictogrammes[$entree['title']] ?? '');
		$cache = ($entree['params']['menu_show'] ?? '1') === '0';

		if ($picto === '' || $cache) {
			continue;
		}

		$entree['params'] = array_merge($entree['params'] ?? [], ['menu_icon_css' => $picto]);
	}

	unset($entree);

	$bloc['menu'] = $menuHaut;


	return $bloc;
};

/*
 * ---- LE REPLI MONOLINGUE, ET IL MANQUAIT ---------------------------------
 *
 * RELEVÉ LE 5 SEPTEMBRE 2026 SUR UN SITE EN LIGNE, booking.toysoldiersf.com,
 * qui n'a qu'une langue. Ce scénario ne posait AUCUNE entrée de menu, et
 * laissait derrière lui un menu vide et un style de template neufs. Répété
 * quinze fois, cela faisait quinze menus et seize styles.
 *
 * LA CAUSE : ce fichier ne décrivait sa page que dans `parLangue`, la
 * fermeture appelée une fois par langue publiée. Or `install()` ne l'appelle
 * QUE si le site est bilingue ; sinon il lit `$contenu['menu']` et
 * `$contenu['modules']` au premier niveau, qui n'existaient pas ici.
 *
 * Le blog et le magazine avaient ce repli depuis le 26 août. La landing est
 * née bilingue, sur des bancs bilingues, et personne n'a vu le trou. C'est
 * exactement le genre de défaut qu'un banc ne montre jamais.
 *
 * On appelle la fermeture avec la langue DU SITE, et on range ce qu'elle rend
 * là où `install()` irait le chercher. Pas de recopie, pas de seconde version à
 * tenir à jour, et pas de français imposé à un site anglophone.
 */
$langueSite = (string) \Joomla\CMS\Factory::getApplication()->get('language', 'en-GB');

$monolingue = $contenu['parLangue']($langueSite ?: 'en-GB');

$contenu['menuTitre'] = $monolingue['menuTitre'];
$contenu['menu']      = $monolingue['menu'];
$contenu['modules']   = $monolingue['modules'];
$contenu['menus']     = $monolingue['menus'] ?? [];

return $contenu;
