<?php
/**
 * Scénario « Magazine ».
 *
 * Même contenu que le blog, autre ossature. Il reprend `commun.php` sans y
 * toucher, et ne change que trois choses : le préréglage de mise en page, la
 * page d'accueil, et les modules qui garnissent les zones que ce préréglage
 * ouvre.
 *
 * C'est là tout l'intérêt d'avoir séparé le contenu commun : une personne qui
 * installe les deux scénarios l'un après l'autre voit le MÊME contenu prendre
 * deux allures, ce qui montre bien que la mise en page ne tient pas aux
 * articles.
 */

defined('_JEXEC') or die;

$contenu = require __DIR__ . '/commun.php';

// --- Le préréglage de mise en page ----------------------------------------
// Lu dans le template installé, pas recopié ici. Il ouvre une colonne latérale
// gauche de 4/12, met la recherche dans la barre de navigation, et allume deux
// rangées basses. Les modules ci-dessous vont garnir ces zones : un préréglage
// qui ouvre des zones vides donne une page trouée.
$contenu['preset'] = 'magazine';

/*
 * UN STYLE DE TEMPLATE POUR CE SCÉNARIO.
 *
 * Il est la copie du style du site, et il est assigné à toutes les entrées de
 * menu que ce scénario crée. Sans lui, deux démonstrations installées côte à
 * côte se disputeraient le même style : le préréglage de la seconde écraserait
 * celui de la première, et les deux vues auraient la même ossature.
 *
 * Les couleurs, la typographie et le logo restent hérités de la copie. Seule
 * la mise en page distingue les styles les uns des autres.
 */
$contenu['styleDedie'] = [
	'title' => 'Corpus : magazine',
];

// --- Les réglages du style, posés par-dessus le préréglage -----------------

/*
 * L'IDENTITÉ DE CETTE DÉMONSTRATION : son nom et sa couleur.
 *
 * LE NOM PASSE PAR `logoText`, le champ « Texte du logo » du style de template,
 * et NON par le nom du site. Mesuré dans `helper.php` du template, méthode
 * `siteName()` : le gabarit affiche `logoText` s'il est rempli, et retombe sur
 * `sitename` sinon. C'est donc un réglage de STYLE, sauvegardé et rendu à la
 * réinitialisation comme les autres. Écrire dans la configuration globale
 * aurait touché un fichier qui n'appartient pas à ce module.
 *
 * CE QUI RESTE AU NOM DU SITE : le titre de l'onglet du navigateur, et la
 * mention de copyright du pied de page, qui lisent tous deux `sitename` en
 * direct. À régler à la main dans la configuration globale de chaque site.
 *
 * LA COULEUR EST UN ANGLE DE TEINTE, pas une couleur : voir `teintes.php`.
 */
$teintes = require __DIR__ . '/teintes.php';

$contenu['styleParams'] = [
	'logoText' => 'Corpus - Magazine',

	// Même largeur que les trois autres scénarios : ce qui change d'une
	// démonstration à l'autre est l'ossature, pas l'encombrement. Voir le
	// commentaire de `blog.php` pour ce que cette uniformité évite.
	'layoutMaxWidth' => '1420px',

	/*
	 * L'EN-TÊTE DE CETTE DÉMONSTRATION : LE LOGO CENTRÉ DANS SA MOITIÉ.
	 * 8 septembre 2026.
	 *
	 * Deux parts égales, six et six. Le logo n'est pas calé au bord gauche
	 * comme ailleurs : son contenu est centré dans sa moitié, ce qui lui donne
	 * l'assiette d'un titre de journal. La ligne de service occupe l'autre
	 * moitié, contenu à droite.
	 *
	 * POURQUOI PAS 4 / 4 / 4 AVEC LE LOGO AU MILIEU DE LA PAGE. Il y faudrait
	 * un module à gauche du logo, et une zone sans module publié ne compte pas
	 * de piste : la grille n'aurait que deux colonnes et le centrage serait
	 * faux. Le jour où cette démonstration publiera quelque chose en
	 * « En-tête 1 », le trois-parts sera le bon réglage.
	 *
	 * LE MENU RESTE À GAUCHE, en 9, la recherche en 3 : sur un magazine, le
	 * menu porte des rubriques et il en faut beaucoup.
	 */
	'layoutLargeur_marque' => '6',
	'layoutAlign_marque'   => 'centre',
	'layoutLargeur_header_right' => '6',
	'layoutAlign_header_right'   => 'fin',
	'layoutLargeur_nav_left'  => '9',
	'layoutAlign_nav_left'    => 'debut',
	'layoutLargeur_nav_right' => '3',
	'layoutAlign_nav_right'   => 'fin',

] + $teintes['bleu'];

// --- Les articles de la une -----------------------------------------------
$contenu['featured'] = [
	'ratatouille-mediterraneenne',
	'tarte-fine-tomate-olives',
	'veloute-de-potimaron',
	'gateau-courgette-citron',
	'petits-pois-a-la-francaise',
	'fondue-de-poireaux',
];

/*
 * ---- CE SCÉNARIO PARLE DEUX LANGUES DEPUIS LE 26 AOÛT 2026 -----------------
 *
 * Même principe que le blog : ce qui EXPLIQUE Corpus suit la langue du
 * visiteur, ce qui MONTRE Corpus reste en « Toutes langues ». Les quatorze
 * recettes ne sont pas traduites, et n'ont pas à l'être : ce qu'elles
 * démontrent est une mise en page, pas une cuisine.
 *
 * L'anglais n'a pas été relu par un anglophone.
 */
$textes = [
	'fr-FR' => [
		'menuTitre'   => 'Corpus : magazine',
		'accueil'     => 'La une',
		'modUne'      => 'La une',
		'h1'          => 'Le potager de saison',
		'chapo'       => 'Six recettes et six légumes racontés. La même matière que le'
			. ' scénario blog, dans une autre ossature : c\'est le préréglage de mise en page'
			. ' qui change, pas le contenu.',
		'recherche'   => 'Rechercher',
		'modALaUne'   => 'À la une',
		'modPotager'  => 'Au potager',
		'modRecettes' => 'Dernières recettes',
		'modAPropos'  => 'À propos de ce site',
		'aPropos'     => 'Ce site a été monté en une fois par le module de démarrage de'
			. ' Corpus. Rien n\'y a été saisi à la main : les catégories, les articles, les'
			. ' champs de la recette, le menu et ce module lui-même ont été créés d\'un clic,'
			. ' et le bouton « Tout réinitialiser » les retire tous.',
		'btnTampons'  => 'Voir les tampons',
		'modPlusLoin' => 'Pour aller plus loin',
		'plusLoin'    => 'La page <a href="{lien:typographie}">Typographie</a> montre comment'
			. ' Corpus habille le texte courant. La page <a href="{lien:les-tampons}">Les tampons</a>'
			. ' montre les blocs tout prêts que l\'éditeur sait insérer.',
	],
	'en-GB' => [
		'menuTitre'   => 'Corpus: magazine',
		'accueil'     => 'Front page',
		'modUne'      => 'Front page',
		'h1'          => 'The kitchen garden in season',
		'chapo'       => 'Six recipes and six vegetables. The same material as the blog scenario,'
			. ' in another structure: what changes is the layout preset, not the content.'
			. ' The recipes stay in French on purpose.',
		'recherche'   => 'Search',
		'modALaUne'   => 'Featured',
		'modPotager'  => 'In the garden',
		'modRecettes' => 'Latest recipes',
		'modAPropos'  => 'About this site',
		'aPropos'     => 'This site was built in one go by the Corpus starter module. Nothing was'
			. ' typed in by hand: the categories, the articles, the recipe fields, the menu and'
			. ' this very module were created in one click, and the « Reset everything » button'
			. ' removes them all.',
		'btnTampons'  => 'See the content blocks',
		'modPlusLoin' => 'Going further',
		'plusLoin'    => 'The <a href="{lien:typographie}">Typography</a> page shows how Corpus'
			. ' dresses running text. The <a href="{lien:les-tampons}">Content blocks</a> page'
			. ' shows the ready-made blocks the editor can insert.',
	],
];

$parLangue = static function (string $code) use ($textes): array {

	$t = $textes[$code] ?? $textes['en-GB'];

	$bloc = ['menuTitre' => $t['menuTitre']];

	// --- Les modules ----------------------------------------------------------
	$bloc['modules'] = [
		// La une, en haut de l'accueil. En `top-a` et non en `banner` : le
		// préréglage magazine range `banner` dans la partie droite de l'en-tête,
		// où un grand titre serait à l'étroit.
		[
			'title'     => $t['modUne'],
			'module'    => 'mod_custom',
			'position'  => 'top-a',
			'showtitle' => 0,
			'pages'     => 'home',
			'content'   => '<div class="text-center">'
				. '<h1>' . $t['h1'] . '</h1>'
				. '<p class="lead">' . $t['chapo'] . '</p>'
				. '</div>',
			'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
		],

		// La recherche, à droite du menu. Corpus attend `mod_finder` en position
		// `search` : son propre gabarit y sort déjà une balise <search>, ce que le
		// gabarit du cœur ne fait pas.
		[
			'title'     => $t['recherche'],
			'module'    => 'mod_finder',
			'position'  => 'search',
			'showtitle' => 0,
			'pages'     => 'all',
			'params'    => [
				'searchfilter'   => '',
				'show_label'     => '0',
				'alt_label'      => '',
				'show_button'    => '1',
				'opensearch'     => '1',
				'field_size'     => '20',
				'maxlength'      => '200',
				'set_itemid'     => '',
			],
		],

		// LA UNE : une grande vignette à gauche, deux petites à droite.
		//
		// C'EST UN SEUL MODULE, et rien n'est écrit à la main. Corpus porte pour
		// cela la classe `corpus-magazine`, écrite le 4 août 2026 dans
		// `_modules.scss` : le champ natif « Classe du module » suffit à
		// déclencher la grille, et la feuille fait le reste. Réglages relevés
		// sur le banc 8090, où la mise en page tourne déjà.
		//
		// La feuille attend un module réglé ainsi : les images ALLUMÉES, et tout
		// le reste éteint. On ne masque rien par le CSS, parce qu'un contenu caché
		// en CSS reste lu par un lecteur d'écran et fausse la page.
		[
			'title'     => $t['modALaUne'],
			'module'    => 'mod_articles',
			'position'  => 'main-top',
			'showtitle' => 0,
			'pages'     => 'home',
			'params'    => [
				'mode'                         => 'normal',
				'count'                        => '3',
				'category_filtering_type'      => '1',
				'catid'                        => ['{cat:recettes}'],
				'show_child_category_articles' => '1',
				'levels'                       => '2',
				'show_featured'                => 'show',
				'show_archived'                => 'hide',
				'article_ordering'             => 'a.publish_up',
				'article_ordering_direction'   => 'DESC',
				'article_grouping'             => 'none',
				'moduleclass_sfx'              => 'corpus-magazine',
				'articles_layout'              => '1',
				'layout_columns'               => '3',
				'title_only'                   => '0',
				'item_title'                   => '1',
				'link_titles'                  => '1',
				'item_heading'                 => 'h4',
				'image'                        => '1',
				'img_intro_full'               => 'intro',
				'show_introtext'               => '0',
				'show_date'                    => '0',
				'show_author'                  => '0',
				'show_category'                => '0',
				'show_hits'                    => '0',
				'show_tags'                    => '0',
				'show_readmore'                => '0',
				'style'                        => 'corpus-no-card',
			],
		],

		// Les deux listes de la colonne latérale, ouverte par le préréglage à 4/12.
		//
		// LES RÉGLAGES D'AFFICHAGE SONT ÉNUMÉRÉS EN ENTIER, et ce n'est pas du
		// zèle : un module écrit sans passer par le formulaire ne reçoit aucune
		// valeur par défaut. Sans `item_title`, le gabarit de Joomla saute chaque
		// entrée et la liste sort vide, sans la moindre erreur.
		[
			'title'     => $t['modPotager'],
			'module'    => 'mod_articles',
			'position'  => 'sidebar-left',
			'showtitle' => 1,
			'pages'     => 'all',
			'params'    => [
				'mode'                         => 'normal',
				'count'                        => '6',
				'category_filtering_type'      => '1',
				'catid'                        => ['{cat:potager}'],
				'show_child_category_articles' => '0',
				'show_featured'                => 'show',
				'article_ordering'             => 'a.title',
				'article_ordering_direction'   => 'ASC',
				'article_grouping'             => 'none',
				'item_title'                   => '1',
				'link_titles'                  => '1',
				'item_heading'                 => 'h4',
				// Titres seuls : `title_only` bascule sur le gabarit `_titles` de
				// Joomla, une simple liste de liens, sans vignette ni accroche.
				'title_only'                   => '1',
				'show_introtext'               => '0',
				'show_date'                    => '0',
				'show_author'                  => '0',
				'show_category'                => '0',
				'show_hits'                    => '0',
				'show_tags'                    => '0',
				'show_readmore'                => '0',
				'img_intro_full'               => 'none',
				'articles_layout'              => '0',
			],
		],
		[
			'title'     => $t['modRecettes'],
			'module'    => 'mod_articles',
			'position'  => 'sidebar-left',
			'showtitle' => 1,
			'pages'     => 'all',
			'params'    => [
				'mode'                         => 'normal',
				'count'                        => '5',
				'category_filtering_type'      => '1',
				'catid'                        => ['{cat:recettes}'],
				'show_child_category_articles' => '1',
				'levels'                       => '2',
				'show_featured'                => 'show',
				'article_ordering'             => 'a.publish_up',
				'article_ordering_direction'   => 'DESC',
				'article_grouping'             => 'none',
				'item_title'                   => '1',
				'link_titles'                  => '1',
				'item_heading'                 => 'h4',
				// Titres seuls : `title_only` bascule sur le gabarit `_titles` de
				// Joomla, une simple liste de liens, sans vignette ni accroche.
				'title_only'                   => '1',
				'show_introtext'               => '0',
				'show_date'                    => '0',
				'show_author'                  => '0',
				'show_category'                => '1',
				'show_category_link'           => '0',
				'show_hits'                    => '0',
				'show_tags'                    => '0',
				'show_readmore'                => '0',
				'img_intro_full'               => 'none',
				'articles_layout'              => '0',
			],
		],

		// Les deux rangées basses que le préréglage allume.
		[
			'title'     => $t['modAPropos'],
			'module'    => 'mod_custom',
			'position'  => 'bottom-b',
			'showtitle' => 1,
			'pages'     => 'all',
			'content'   => '<p>' . $t['aPropos'] . '</p>'
				. '<p><a class="btn" href="{lien:les-tampons}">' . $t['btnTampons'] . '</a></p>',
			'params'    => ['prepare_content' => 1],
		],
		[
			'title'     => $t['modPlusLoin'],
			'module'    => 'mod_custom',
			'position'  => 'bottom-c',
			'showtitle' => 1,
			'pages'     => 'all',
			'content'   => '<p>' . $t['plusLoin'] . '</p>',
			'params'    => ['prepare_content' => 1],
		],
	];

	/*
	 * ---- LE PIED, LA BARRE, LES LIENS ENTRE DÉMONSTRATIONS ----------------
	 * Communs aux quatre scénarios, et tous les trois suivent la langue de la
	 * page depuis le 26 août 2026.
	 */
	foreach (['pied', 'barre'] as $fichier) {
		$bloc['modules'] = array_merge(
			$bloc['modules'],
			(require __DIR__ . '/' . $fichier . '.php')($code)
		);
	}

	// Le second argument nomme le scénario de CE site, celui qu'on ne met pas
	// en lien : on ne s'envoie pas vers soi-même.
	$bloc['modules'] = array_merge(
		$bloc['modules'],
		(require __DIR__ . '/demos.php')($code, 'magazine')
	);

	/*
	 * ---- LE MENU ----------------------------------------------------------
	 * Le même que celui du blog. Seule l'entrée d'accueil change : elle
	 * s'appelle « La une », et elle affiche en plus quatre titres en liens sous
	 * les articles, ce qui est le propre d'un magazine.
	 */
	$bloc['menu'] = (require __DIR__ . '/menu.php')($code);

	foreach ($bloc['menu'] as &$entree) {
		if (!empty($entree['home'])) {
			$entree['title']  = $t['accueil'];
			$entree['params'] = [
				'num_leading_articles' => '1',
				'num_intro_articles'   => '4',
				'num_columns'          => '2',
				'num_links'            => '4',
				'multi_column_order'   => '1',
			];
		}
	}

	unset($entree);

	return $bloc;
};

$contenu['parLangue'] = $parLangue;

/*
 * LE REPLI, SI JAMAIS `install()` NE PASSAIT PAS PAR `parLangue`.
 *
 * Depuis le 5 septembre 2026 le helper appelle toujours la fermeture, avec la
 * langue du visiteur sur un site bilingue et celle du SITE sinon. Ces trois
 * clés ne servent donc plus, mais elles restent justes : elles prennent la
 * même langue que celle que le helper choisirait, et non le français en dur,
 * qui n'a aucune raison d'être le repli d'un site anglophone.
 */
$langueSite = (string) \Joomla\CMS\Factory::getApplication()->get('language', 'en-GB');

$monolingue = $parLangue($langueSite ?: 'en-GB');

$contenu['menuTitre'] = $monolingue['menuTitre'];
$contenu['menu']      = $monolingue['menu'];
$contenu['modules']   = $monolingue['modules'];

/*
 * ---- LE SÉLECTEUR DE LANGUE -----------------------------------------------
 * Publié seulement si le site a deux langues. Même place que sur les trois
 * autres scénarios : la zone à droite du logo.
 */
$contenu['switch'] = [
	'title'    => 'Langues',
	'position' => 'social-links',
	'params'   => [
		'header_text'     => '',
		'footer_text'     => '',
		'dropdown'        => '0',
		'image'           => '1',
		'inline'          => '1',
		'show_active'     => '1',
		'full_name'       => '0',
		'horizontal'      => '1',
		'layout'          => '',
		'moduleclass_sfx' => '',
		'module_tag'      => 'div',
		'header_tag'      => 'h3',
		'header_class'    => '',
		'style'           => '0',
	],
];

/*
 * ---- LES ZONES DU GABARIT, ALLUMÉES ---------------------------------------
 * Un module publié dans une zone éteinte ne sort nulle part, et rien ne le
 * signale. Ces réglages sont sauvegardés et rendus à la réinitialisation.
 */
$contenu['styleParams']['layoutEnable_footer'] = '1';
$contenu['styleParams']['layoutPos_footer']    = 'footer';

$contenu['styleParams']['layoutEnable_topbar'] = '1';
$contenu['styleParams']['layoutFond_topbar']   = 'section--tint';

$contenu['styleParams']['layoutEnable_header_right'] = '1';
$contenu['styleParams']['layoutPos_header_right']    = 'social-links';

// Le sélecteur de langue, resserré dans les outils d'en-tête. Voir
// `css-switch.php` : trois espacements s'y empilaient pour 43 pixels entre deux
// drapeaux de 17.
$contenu['styleParams']['styleCssPerso'] = require __DIR__ . '/css-switch.php';

/*
 * ---- LE FIL D'ARIANE, ÉCARTÉ DE LA PAGE D'ACCUEIL -------------------------
 *
 * Demande de Cyrille du 26 août 2026, pour les quatre mises en page. Il dit où
 * l'on est dans une arborescence, et l'accueil n'est nulle part dans une
 * arborescence : il en est le point d'entrée. Le fil s'y réduit à « Vous êtes
 * ici : Accueil », qui n'apprend rien et prend une ligne.
 *
 * IL NE SE RÈGLE PAS DANS LE STYLE. `index.php` du template inclut la position
 * `breadcrumbs` en dur, sans interrupteur de zone. Le gabarit le dit lui-même :
 * « pour ne pas le voir sur l'accueil, la bonne manoeuvre est de désassigner le
 * module de cet élément de menu ». C'est ce que fait le module, et rien
 * d'autre : le module de fil d'Ariane appartient à l'utilisateur, on ne le
 * dépublie pas, on l'exclut d'UNE page, et la réinitialisation rend
 * l'affectation d'avant.
 */
$contenu['masquerAriane'] = true;

return $contenu;
