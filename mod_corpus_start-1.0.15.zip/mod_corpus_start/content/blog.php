<?php
/**
 * Scénario « Blog + gabarit d'articles ».
 *
 * Reprend tout le contenu commun, et n'ajoute que ce qui fait la mise en page :
 * la page d'accueil, le menu, et les modules.
 *
 * La structure est calquée sur la donnée d'exemple « Blog » de Joomla sur
 * Cassiopeia : un module de contenu en haut de l'accueil, les articles en
 * vedette en dessous, et une page qui montre la typographie du template. Le
 * but est qu'une personne qui débute avec Joomla comprenne d'où vient chaque
 * morceau de la page.
 */

defined('_JEXEC') or die;

$contenu = require __DIR__ . '/commun.php';

// --- Les articles qui remplissent la page d'accueil -----------------------
// Ce sont les six recettes : l'accueil affiche les articles EN VEDETTE, comme
// la page d'accueil par défaut de Joomla.
$contenu['featured'] = [
	'veloute-de-potimaron',
	'fondue-de-poireaux',
	'ratatouille-mediterraneenne',
	'tarte-fine-tomate-olives',
	'petits-pois-a-la-francaise',
	'gateau-courgette-citron',
];

/*
 * UN STYLE DE TEMPLATE POUR CE SCÉNARIO.
 *
 * Il est la copie du style du site, et il est assigné à toutes les entrées de
 * menu que ce scénario crée. Sans lui, deux démonstrations installées côte à
 * côte se disputeraient le même style : le préréglage de la seconde écraserait
 * celui de la première, et les deux vues auraient la même ossature.
 *
 * Les couleurs, la typographie et le logo restent hérités de la copie. Seule
 * la mise en page distingue les styles les uns des autres.
 */
$contenu['styleDedie'] = [
	'title' => 'Corpus : blog',
];

// --- Les réglages du style ------------------------------------------------
// Le blog n'applique aucun préréglage : il garde l'ossature du site. Il pose
// seulement deux réglages, et la réinitialisation rend les valeurs d'avant.

/*
 * L'IDENTITÉ DE CETTE DÉMONSTRATION : son nom et sa couleur.
 *
 * LE NOM PASSE PAR `logoText`, le champ « Texte du logo » du style de template,
 * et NON par le nom du site. Mesuré dans `helper.php` du template, méthode
 * `siteName()` : le gabarit affiche `logoText` s'il est rempli, et retombe sur
 * `sitename` sinon. C'est donc un réglage de STYLE, sauvegardé et rendu à la
 * réinitialisation comme les autres. Écrire dans la configuration globale
 * aurait touché un fichier qui n'appartient pas à ce module.
 *
 * CE QUI RESTE AU NOM DU SITE : le titre de l'onglet du navigateur, et la
 * mention de copyright du pied de page, qui lisent tous deux `sitename` en
 * direct. À régler à la main dans la configuration globale de chaque site.
 *
 * LA COULEUR EST UN ANGLE DE TEINTE, pas une couleur : voir `teintes.php`.
 */
$teintes = require __DIR__ . '/teintes.php';

$contenu['styleParams'] = [
	'logoText' => 'Corpus - Blog',

	/*
	 * LA MÊME LARGEUR POUR LES QUATRE SCÉNARIOS, décision du 25 août.
	 *
	 * Le blog et le magazine étaient à 1280, la page d'atterrissage à 1420. Sur
	 * un site qui porte plusieurs démonstrations, ces deux valeurs se disputent
	 * le même réglage de style : la seconde installation écrase la première, et
	 * le retrait de l'une rend une largeur qui n'a jamais existé.
	 *
	 * Une seule valeur, et le conflit disparaît sans qu'il faille un style de
	 * template par scénario.
	 */
	'layoutMaxWidth' => '1420px',

	// La zone à droite du menu, éteinte par le préréglage par défaut. Sans
	// elle, un module publié en position `search` ne sortirait nulle part.
	'layoutEnable_nav_right' => '1',
	'layoutPos_nav_right'    => 'search',

	/*
	 * L'EN-TÊTE DE CETTE DÉMONSTRATION : LE LOGO DANS LA BARRE DE NAVIGATION.
	 * 8 septembre 2026.
	 *
	 * C'est la mise en page que Corpus a apprise ce jour-là, et aucune
	 * démonstration ne la montrait. La barre porte le menu à gauche en 5, le
	 * logo au centre en 2, la recherche à droite en 5 : trois parts
	 * symétriques, donc un logo au milieu de la page pour de vrai.
	 *
	 * L'EN-TÊTE RESTE ALLUMÉ, et ce n'est pas un oubli : il porte les liens
	 * entre démonstrations et le sélecteur de langue. Vidé de son logo, il
	 * devient une ligne de service calée à droite sur toute la largeur.
	 *
	 * LE PRIX EST ÉCRIT DANS LA DESCRIPTION DU RÉGLAGE : le lien d'accueil
	 * n'est plus le premier atteint au clavier, puisqu'un menu le précède.
	 * C'est le propre de ce motif, pas un défaut de cette démonstration.
	 */
	'layoutMarqueRangee' => 'nav',

	'layoutLargeur_nav_left'  => '5',
	'layoutAlign_nav_left'    => 'debut',
	'layoutLargeur_marque'    => '2',
	'layoutAlign_marque'      => 'centre',
	'layoutLargeur_nav_right' => '5',
	'layoutAlign_nav_right'   => 'fin',

	'layoutLargeur_header_right' => '12',
	'layoutAlign_header_right'   => 'fin',
] + $teintes['rouge'];

/*
 * ---- CE SCÉNARIO PARLE DEUX LANGUES DEPUIS LE 26 AOÛT 2026 -----------------
 *
 * Cyrille l'a relevé : le blog et le magazine n'avaient pas de sélecteur de
 * langue, alors que les quatre sites de démonstration doivent tous être en
 * français ET en anglais.
 *
 * CE QUI EST TRADUIT, ET CE QUI NE L'EST PAS. Le principe retenu le 25 août est
 * le même que pour la page d'atterrissage : ce qui EXPLIQUE Corpus suit la
 * langue du visiteur, ce qui MONTRE Corpus reste en « Toutes langues ». Les
 * quatorze recettes ne sont donc pas traduites, et elles n'ont pas à l'être :
 * un visiteur anglophone voit le template mettre en page un article, pas un
 * livre de cuisine. Le menu, les intitulés, le bandeau d'accueil, le pied et la
 * barre, eux, changent de langue.
 *
 * L'anglais n'a pas été relu par un anglophone.
 *
 * COMMENT LE HELPER S'EN SERT : `install()` appelle cette fermeture une fois
 * par langue publiée, et ce qu'elle rend remplace `menu` et `modules`. Sur un
 * site qui n'a qu'une langue, elle n'est pas appelée du tout et les deux clés
 * posées plus bas servent telles quelles.
 */
$textes = [
	'fr-FR' => [
		'menuTitre'  => 'Corpus : blog',
		'modTitre'   => 'Bienvenue dans le livre de recettes',
		'h1'         => 'Un livre de recettes pour découvrir Corpus',
		'chapo'      => 'Six recettes, six légumes, et de quoi comprendre comment le template met'
			. ' en page un article. Tout ce que vous voyez ici a été posé par le module de démarrage,'
			. ' et le bouton « Tout réinitialiser » le retire.',
		'btnRecettes' => 'Voir les recettes',
		'btnTypo'     => 'La typographie',
		'recherche'   => 'Rechercher',
	],
	'en-GB' => [
		'menuTitre'  => 'Corpus: blog',
		'modTitre'   => 'Welcome to the recipe book',
		'h1'         => 'A recipe book to discover Corpus',
		'chapo'      => 'Six recipes, six vegetables, and enough to understand how the template lays'
			. ' out an article. Everything you see here was placed by the starter module, and the'
			. ' « Reset everything » button removes it. The recipes themselves stay in French: what'
			. ' they demonstrate is the layout, not the cooking.',
		'btnRecettes' => 'See the recipes',
		'btnTypo'     => 'Typography',
		'recherche'   => 'Search',
	],
];

$parLangue = static function (string $code) use ($textes): array {

	$t = $textes[$code] ?? $textes['en-GB'];

	$bloc = ['menuTitre' => $t['menuTitre']];

	// --- Les modules ------------------------------------------------------
	// Le premier, en position `top-a` : le bandeau d'ouverture de l'accueil.
	// Joomla fait exactement cela dans sa donnée d'exemple, avec un module de
	// contenu personnalisé qui porte un titre et un bouton.
	//
	// PAS `banner` : le préréglage de Corpus range cette position dans la
	// partie droite de l'en-tête, où un grand titre n'a pas la place. `top-a`
	// est une vraie rangée pleine largeur, allumée par le préréglage par
	// défaut.
	$bloc['modules'] = [
		[
			'title'     => $t['modTitre'],
			'module'    => 'mod_custom',
			'position'  => 'top-a',
			'showtitle' => 0,
			'pages'     => 'home',
			'content'   => '<div class="text-center">'
				. '<h1>' . $t['h1'] . '</h1>'
				. '<p class="lead">' . $t['chapo'] . '</p>'
				. '<p><a class="btn" href="{lien:recettes}">' . $t['btnRecettes'] . '</a>'
				. ' <a class="btn" href="{lien:typographie}">' . $t['btnTypo'] . '</a></p>'
				. '</div>',
			'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
		],

		// La recherche, à droite du menu. Corpus attend `mod_finder` en
		// position `search` : son propre gabarit y sort déjà une balise
		// <search>, ce que le gabarit du cœur ne fait pas.
		[
			'title'     => $t['recherche'],
			'module'    => 'mod_finder',
			'position'  => 'search',
			'showtitle' => 0,
			'pages'     => 'all',
			'params'    => [
				'searchfilter'   => '',
				'show_label'     => '0',
				'alt_label'      => '',
				'show_button'    => '1',
				'opensearch'     => '1',
				'field_size'     => '20',
				'maxlength'      => '200',
				'set_itemid'     => '',
			],
		],
	];

	/*
	 * ---- LE PIED, LA BARRE, LES LIENS ENTRE DÉMONSTRATIONS ----------------
	 * Communs aux quatre scénarios, et tous les trois suivent la langue de la
	 * page. Ils étaient en français en dur jusqu'au 26 août : un pied français
	 * sous une page anglaise disait au visiteur qu'il s'était trompé de site.
	 */
	foreach (['pied', 'barre'] as $fichier) {
		$bloc['modules'] = array_merge(
			$bloc['modules'],
			(require __DIR__ . '/' . $fichier . '.php')($code)
		);
	}

	// Le second argument nomme le scénario de CE site, celui qu'on ne met pas
	// en lien : on ne s'envoie pas vers soi-même.
	$bloc['modules'] = array_merge(
		$bloc['modules'],
		(require __DIR__ . '/demos.php')($code, 'blog')
	);

	// --- Le menu ----------------------------------------------------------
	// `key` sert de référence pour les entrées filles. `mega` pose le mot dans
	// le champ natif « Style CSS du lien », ce qui suffit à déclencher le
	// méga-menu de Corpus sur une entrée de premier niveau.
	$bloc['menu'] = (require __DIR__ . '/menu.php')($code);

	// L'entrée d'accueil porte les réglages de la une, qui changent d'un
	// scénario à l'autre : un article de tête, puis les cinq autres sur DEUX
	// colonnes.
	foreach ($bloc['menu'] as &$entree) {
		if (!empty($entree['home'])) {
			$entree['params'] = [
				'num_leading_articles' => '1',
				'num_intro_articles'   => '5',
				'num_columns'          => '2',
				'num_links'            => '0',
				'multi_column_order'   => '1',
			];
		}
	}

	unset($entree);

	return $bloc;
};

$contenu['parLangue'] = $parLangue;

/*
 * LE REPLI, SI JAMAIS `install()` NE PASSAIT PAS PAR `parLangue`.
 *
 * Depuis le 5 septembre 2026 le helper appelle toujours la fermeture, avec la
 * langue du visiteur sur un site bilingue et celle du SITE sinon. Ces trois
 * clés ne servent donc plus, mais elles restent justes : elles prennent la
 * même langue que celle que le helper choisirait, et non le français en dur,
 * qui n'a aucune raison d'être le repli d'un site anglophone.
 */
$langueSite = (string) \Joomla\CMS\Factory::getApplication()->get('language', 'en-GB');

$monolingue = $parLangue($langueSite ?: 'en-GB');

$contenu['menuTitre'] = $monolingue['menuTitre'];
$contenu['menu']      = $monolingue['menu'];
$contenu['modules']   = $monolingue['modules'];

/*
 * ---- LE SÉLECTEUR DE LANGUE -----------------------------------------------
 *
 * Publié seulement si le site a deux langues : le helper ignore cette clé
 * autrement. Mêmes réglages et même place que sur la page d'atterrissage, la
 * zone à droite du logo, où rien ne le pousse à la ligne.
 */
$contenu['switch'] = [
	'title'    => 'Langues',
	'position' => 'social-links',
	'params'   => [
		'header_text'     => '',
		'footer_text'     => '',
		'dropdown'        => '0',
		'image'           => '1',
		'inline'          => '1',
		'show_active'     => '1',
		'full_name'       => '0',
		'horizontal'      => '1',
		'layout'          => '',
		'moduleclass_sfx' => '',
		'module_tag'      => 'div',
		'header_tag'      => 'h3',
		'header_class'    => '',
		'style'           => '0',
	],
];

/*
 * ---- LES ZONES DU GABARIT, ALLUMÉES ---------------------------------------
 *
 * Un module publié dans une zone éteinte ne sort nulle part, et rien ne le
 * signale : c'est la panne la plus longue à trouver. Ces réglages sont
 * sauvegardés, la réinitialisation rend les valeurs d'avant.
 */
$contenu['styleParams']['layoutEnable_footer'] = '1';
$contenu['styleParams']['layoutPos_footer']    = 'footer';

// `section--tint` est le fond teinté de Corpus, dérivé de la teinte du site :
// un bandeau de couleur qui suit le préréglage de teinte au lieu de le
// contredire.
$contenu['styleParams']['layoutEnable_topbar'] = '1';
$contenu['styleParams']['layoutFond_topbar']   = 'section--tint';

// La zone à droite du logo : les liens entre démonstrations, puis les drapeaux.
$contenu['styleParams']['layoutEnable_header_right'] = '1';
$contenu['styleParams']['layoutPos_header_right']    = 'social-links';

// Le sélecteur de langue, resserré dans les outils d'en-tête. Voir
// `css-switch.php` : trois espacements s'y empilaient pour 43 pixels entre deux
// drapeaux de 17.
$contenu['styleParams']['styleCssPerso'] = require __DIR__ . '/css-switch.php';

/*
 * ---- LE FIL D'ARIANE, ÉCARTÉ DE LA PAGE D'ACCUEIL -------------------------
 *
 * Demande de Cyrille du 26 août 2026, pour les quatre mises en page. Il dit où
 * l'on est dans une arborescence, et l'accueil n'est nulle part dans une
 * arborescence : il en est le point d'entrée. Le fil s'y réduit à « Vous êtes
 * ici : Accueil », qui n'apprend rien et prend une ligne.
 *
 * IL NE SE RÈGLE PAS DANS LE STYLE. `index.php` du template inclut la position
 * `breadcrumbs` en dur, sans interrupteur de zone. Le gabarit le dit lui-même :
 * « pour ne pas le voir sur l'accueil, la bonne manoeuvre est de désassigner le
 * module de cet élément de menu ». C'est ce que fait le module, et rien
 * d'autre : le module de fil d'Ariane appartient à l'utilisateur, on ne le
 * dépublie pas, on l'exclut d'UNE page, et la réinitialisation rend
 * l'affectation d'avant.
 */
$contenu['masquerAriane'] = true;

return $contenu;
