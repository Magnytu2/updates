<?php
/**
 * Scénario « Multilingue simple ».
 *
 * Il ne ressemble pas aux trois autres, et c'est voulu : il ne pose ni gabarit
 * d'article, ni préréglage de mise en page, ni champ personnalisé. Il monte le
 * strict nécessaire pour qu'un site parle deux langues, exactement comme la
 * donnée d'exemple multilingue de Joomla :
 *
 *   - une catégorie par langue ;
 *   - deux articles par langue, associés d'une langue à l'autre ;
 *   - un menu par langue, avec sa propre page d'accueil ;
 *   - un module de menu par langue ;
 *   - le sélecteur de langue ;
 *   - le plugin « Système : Filtre de langue », allumé.
 *
 * CE QUE LE MODULE NE FAIT PAS : installer des packs de langue. Il travaille
 * avec les langues DÉJÀ installées côté site. Une seule langue installée, et le
 * scénario s'arrête en le disant : un site multilingue à une langue n'existe
 * pas, et le faire croire serait pire que refuser.
 *
 * LES TEXTES. Le français et l'anglais sont écrits ici. L'allemand et
 * l'espagnol le sont aussi, mais ils n'ont pas été relus par un locuteur : ce
 * sont quatre phrases de démonstration, à reprendre avant toute mise en ligne.
 * Une langue installée qui n'est pas dans cette liste reçoit les textes
 * anglais, et le résultat de l'installation le signale.
 */

defined('_JEXEC') or die;

return [

	'multilangue' => [

		/*
		 * LE SÉLECTEUR DE LANGUE, À DROITE DU LOGO.
		 *
		 * Ce n'est pas la position de la donnée d'exemple de Joomla, qui le met
		 * en `sidebar-right` parce que Cassiopeia y a une colonne.
		 *
		 * IL ÉTAIT EN `search`, LA ZONE À DROITE DU MENU, JUSQU'AU 26 AOÛT 2026.
		 * Cyrille l'a vu sur la landing : cette zone porte déjà les liens entre
		 * démonstrations, elle est étroite, et les drapeaux y passaient à la
		 * ligne. Ils sont maintenant dans `social-links`, sur la ligne du nom du
		 * site, où rien ne les pousse.
		 *
		 * Un sélecteur de langue doit se voir : c'est le navigateur du visiteur
		 * qui décide de la langue de la page, et il se trompe.
		 */
		'switch' => [
			'title'    => 'Langues',
			'position' => 'social-links',
			'params'   => [
				'header_text'     => '',
				'footer_text'     => '',
				'dropdown'        => '0',
				'image'           => '1',
				'inline'          => '1',
				'show_active'     => '1',
				'full_name'       => '1',
				'horizontal'      => '1',
				'layout'          => '',
				'moduleclass_sfx' => '',
				'module_tag'      => 'div',
				'header_tag'      => 'h3',
				'header_class'    => '',
				'style'           => '0',
			],
		],

		/*
		 * LA ZONE QUI ACCUEILLE LE SÉLECTEUR, ALLUMÉE.
		 *
		 * Sans ces trois lignes, le module serait publié en position `search`
		 * et ne sortirait NULLE PART : le préréglage par défaut de Corpus
		 * éteint la zone à droite du menu. Un module invisible sans la moindre
		 * erreur, c'est la panne la plus longue à trouver. La réinitialisation
		 * rend les valeurs d'avant.
		 */
		'styleParams' => [
			/*
			 * L'IDENTITÉ DE CETTE DÉMONSTRATION.
			 *
			 * `logoText` est le champ « Texte du logo » du style : le gabarit
			 * l'affiche s'il est rempli et retombe sur le nom du site sinon.
			 * C'est donc un réglage de style, sauvegardé et rendu à la
			 * réinitialisation. L'onglet du navigateur, lui, garde le nom du
			 * site, qui se règle dans la configuration globale.
			 *
			 * La teinte est l'orange des préréglages de Corpus, angle 30, avec
			 * les quatre couleurs de message mesurées qui l'accompagnent. Voir
			 * `teintes.php`.
			 */
			'logoText'  => 'Corpus - Multilangue',

			// Même largeur que les trois autres démonstrations.
			'layoutMaxWidth' => '1420px',

			'layoutEnable_nav_right' => '1',
			'layoutPos_nav_right'    => 'search',

			/*
			 * L'EN-TÊTE DE CETTE DÉMONSTRATION : 3 / 9, CONTENU À DROITE.
			 * 8 septembre 2026.
			 *
			 * C'est la démonstration de l'alignement du CONTENU, et pas de la
			 * boîte. Les drapeaux et les liens entre démonstrations vivent dans
			 * une zone large de neuf douzièmes : sans alignement, ils
			 * resteraient collés au logo. Réglés à droite, ils vont au bord de
			 * la page, ce qui est la place d'un sélecteur de langue.
			 *
			 * Sur ce scénario-là, la zone est réellement pleine : quatre
			 * drapeaux plus trois liens. C'est le seul des quatre où
			 * l'alignement se voit sans compter les pixels.
			 */
			'layoutLargeur_marque' => '3',
			'layoutAlign_marque'   => 'debut',
			'layoutLargeur_header_right' => '9',
			'layoutAlign_header_right'   => 'fin',
			'layoutLargeur_nav_left'  => '9',
			'layoutAlign_nav_left'    => 'debut',
			'layoutLargeur_nav_right' => '3',
			'layoutAlign_nav_right'   => 'fin',

			// La zone à droite du logo porte maintenant les drapeaux et les
			// liens entre démonstrations. Le préréglage du site l'éteint.
			'layoutEnable_header_right' => '1',
			'layoutPos_header_right'    => 'social-links',

			// Le sélecteur de langue, resserré : voir `css-switch.php`.
			'styleCssPerso' => require __DIR__ . '/css-switch.php',
			'layoutEnable_footer'    => '1',
			'layoutPos_footer'       => 'footer',
			'layoutEnable_topbar'    => '1',
			'layoutFond_topbar'      => 'section--tint',
		] + (require __DIR__ . '/teintes.php')['orange'],

		/*
		 * LE PIED, UN JEU PAR LANGUE.
		 *
		 * C'est le seul scénario qui en demande plusieurs : chaque module porte
		 * sa langue, donc chaque visiteur voit le pied dans la sienne, sans
		 * aucune règle d'affectation de page. Les trois autres scénarios en
		 * posent un seul, sans langue.
		 *
		 * Une fermeture, pas un tableau : les textes dépendent de la langue, et
		 * les langues ne sont connues qu'à l'installation.
		 */
		'pied' => require __DIR__ . '/pied.php',

		// La barre d'information, un jeu par langue elle aussi.
		'barre' => require __DIR__ . '/barre.php',

		/*
		 * LES LIENS VERS LES TROIS AUTRES DÉMONSTRATIONS.
		 *
		 * `demos.php` demande de savoir quel scénario est posé ICI, pour ne pas
		 * mettre ce site en lien vers lui-même. La boucle du helper, elle, ne
		 * passe que la langue du contenu et la langue du module : d'où cette
		 * fermeture qui glisse le nom du scénario au passage.
		 */
		'demos' => static function (string $code, string $langueMod = '*'): array {
			return (require __DIR__ . '/demos.php')($code, 'multilingue', $langueMod);
		},

		// Les réglages de la page d'accueil de chaque langue. Un blog de
		// catégorie, un article de tête et les autres en accroche.
		'accueilParams' => [
			'num_leading_articles' => '1',
			'num_intro_articles'   => '4',
			'num_columns'          => '1',
			'num_links'            => '0',
			'show_pagination'      => '2',
			'orderby_sec'          => 'rdate',

			// L'INTÉRÊT PÉDAGOGIQUE DE CETTE LIGNE : elle affiche, sous chaque
			// article, les drapeaux de ses traductions. C'est le seul endroit
			// où une association se VOIT depuis le site.
			'show_associations'    => '1',
		],

		/*
		 * LES LANGUES CONNUES DU MODULE.
		 *
		 * La clé est le code de langue de Joomla. Seules celles réellement
		 * installées côté site sont montées ; les autres sont ignorées sans
		 * bruit.
		 *
		 * `cle` sert à faire correspondre les articles d'une langue à l'autre :
		 * deux articles qui portent la même clé deviennent une association.
		 */
		'langues' => [

			'fr-FR' => [
				'categorie' => ['title' => 'Actualités', 'alias' => 'actualites'],
				'menu'      => [
					'menutype'    => 'corpus-fr-fr',
					'title'       => 'Menu principal (fr-FR)',
					'description' => 'Le menu du site en français. Posé par le module de démarrage.',
				],
				'accueil'   => 'Accueil',
				'articles'  => [
					[
						'cle'   => 'deux-langues',
						'title' => 'Un site en deux langues',
						'alias' => 'un-site-en-deux-langues',
						'intro' => '<p>Ce site parle maintenant plusieurs langues. Rien n\'a été traduit'
							. ' automatiquement : chaque langue a son propre contenu, ses propres'
							. ' catégories et son propre menu.</p>',
						'body'  => '<h2>Trois pièces, et pas une de plus</h2>'
							. '<p>Un site multilingue Joomla tient en trois pièces. La première est le'
							. ' <strong>filtre de langue</strong>, un plugin : c\'est lui qui décide quelle'
							. ' langue montrer, et qui écarte le contenu des autres.</p>'
							. '<p>La deuxième est le <strong>menu par langue</strong>. Chaque langue a le'
							. ' sien, avec sa propre page d\'accueil. C\'est cette page d\'accueil qui dit à'
							. ' Joomla où atterrir quand on choisit cette langue.</p>'
							. '<p>La troisième est le <strong>sélecteur de langue</strong>, le module aux'
							. ' drapeaux, en haut à droite. Il n\'a aucune intelligence propre : il affiche'
							. ' les langues publiées, et suit les associations quand il y en a.</p>'
							. '<h2>Ce qui se passe si une pièce manque</h2>'
							. '<p>Sans filtre de langue, toutes les langues s\'affichent en même temps.'
							. ' Sans page d\'accueil pour une langue, le sélecteur renvoie sur la page'
							. ' d\'accueil par défaut, dans l\'autre langue. Sans association, le sélecteur'
							. ' fonctionne quand même, mais il ramène à l\'accueil au lieu de la page'
							. ' équivalente.</p>',
					],
					[
						'cle'   => 'association',
						'title' => 'Ce qu\'est une association',
						'alias' => 'ce-qu-est-une-association',
						'intro' => '<p>Une association relie un article à sa traduction. C\'est ce qui permet'
							. ' au sélecteur de langue de vous emmener sur la BONNE page, et non sur'
							. ' l\'accueil.</p>',
						'body'  => '<h2>Où elle se règle</h2>'
							. '<p>Dans l\'article, onglet « Associations ». On y choisit, pour chaque autre'
							. ' langue du site, l\'article qui lui correspond. Un élément de menu se'
							. ' traite de la même façon, et une catégorie aussi.</p>'
							. '<p>Cet article-ci en a une : passez à l\'autre langue avec le sélecteur, et'
							. ' vous arriverez sur sa traduction, pas sur l\'accueil.</p>'
							. '<h2>Ce n\'est pas une traduction</h2>'
							. '<p>Joomla ne traduit rien. Une association dit seulement « ces deux articles'
							. ' se correspondent ». Le texte de chaque langue reste écrit à la main, et'
							. ' peut dire autre chose : c\'est même souvent souhaitable, un même sujet ne'
							. ' se raconte pas pareil d\'un pays à l\'autre.</p>',
					],
				],
			],

			'en-GB' => [
				'categorie' => ['title' => 'News', 'alias' => 'news'],
				'menu'      => [
					'menutype'    => 'corpus-en-gb',
					'title'       => 'Main menu (en-GB)',
					'description' => 'The site menu in English. Created by the start-up module.',
				],
				'accueil'   => 'Home',
				'articles'  => [
					[
						'cle'   => 'deux-langues',
						'title' => 'A site in two languages',
						'alias' => 'a-site-in-two-languages',
						'intro' => '<p>This site now speaks several languages. Nothing was translated'
							. ' automatically: each language has its own content, its own categories and'
							. ' its own menu.</p>',
						'body'  => '<h2>Three parts, and no more</h2>'
							. '<p>A multilingual Joomla site rests on three parts. The first is the'
							. ' <strong>language filter</strong>, a plugin: it decides which language to'
							. ' show, and sets aside the content of the others.</p>'
							. '<p>The second is the <strong>menu per language</strong>. Each language has'
							. ' its own, with its own home page. That home page is what tells Joomla where'
							. ' to land when this language is picked.</p>'
							. '<p>The third is the <strong>language switcher</strong>, the module with the'
							. ' flags, top right. It has no cleverness of its own: it lists the published'
							. ' languages, and follows associations where there are any.</p>'
							. '<h2>What happens when a part is missing</h2>'
							. '<p>With no language filter, every language shows at once. With no home page'
							. ' for a language, the switcher falls back to the default home page, in the'
							. ' other language. With no association, the switcher still works, but it'
							. ' returns to the home page instead of the matching one.</p>',
					],
					[
						'cle'   => 'association',
						'title' => 'What an association is',
						'alias' => 'what-an-association-is',
						'intro' => '<p>An association links an article to its translation. It is what lets'
							. ' the language switcher take you to the RIGHT page, rather than to the home'
							. ' page.</p>',
						'body'  => '<h2>Where it is set</h2>'
							. '<p>In the article, under the “Associations” tab. For each other language'
							. ' on the site, you pick the matching article. A menu item works the same'
							. ' way, and so does a category.</p>'
							. '<p>This article has one: switch language with the selector, and you will'
							. ' land on its translation, not on the home page.</p>'
							. '<h2>It is not a translation</h2>'
							. '<p>Joomla translates nothing. An association only says “these two articles'
							. ' match”. The text of each language stays hand-written, and may well say'
							. ' something else: that is often the better choice, since one subject is'
							. ' rarely told the same way from one country to the next.</p>',
					],
				],
			],

			'de-DE' => [
				'categorie' => ['title' => 'Aktuelles', 'alias' => 'aktuelles'],
				'menu'      => [
					'menutype'    => 'corpus-de-de',
					'title'       => 'Hauptmenü (de-DE)',
					'description' => 'Das Menü der Website auf Deutsch. Vom Startmodul angelegt.',
				],
				'accueil'   => 'Startseite',
				'articles'  => [
					[
						'cle'   => 'deux-langues',
						'title' => 'Eine Website in zwei Sprachen',
						'alias' => 'eine-website-in-zwei-sprachen',
						'intro' => '<p>Diese Website spricht nun mehrere Sprachen. Nichts wurde automatisch'
							. ' übersetzt: Jede Sprache hat eigene Inhalte, eigene Kategorien und ein'
							. ' eigenes Menü.</p>',
						'body'  => '<h2>Drei Teile, mehr nicht</h2>'
							. '<p>Eine mehrsprachige Joomla-Website besteht aus drei Teilen. Der erste ist'
							. ' der <strong>Sprachfilter</strong>, ein Plugin: Er entscheidet, welche'
							. ' Sprache gezeigt wird, und blendet die Inhalte der anderen aus.</p>'
							. '<p>Der zweite ist das <strong>Menü je Sprache</strong>. Jede Sprache hat ihr'
							. ' eigenes, mit einer eigenen Startseite. Diese Startseite sagt Joomla, wohin'
							. ' es führen soll, wenn diese Sprache gewählt wird.</p>'
							. '<p>Der dritte ist die <strong>Sprachauswahl</strong>, das Modul mit den'
							. ' Flaggen, oben rechts. Es zeigt die veröffentlichten Sprachen und folgt den'
							. ' Zuordnungen, sofern es welche gibt.</p>',
					],
					[
						'cle'   => 'association',
						'title' => 'Was eine Zuordnung ist',
						'alias' => 'was-eine-zuordnung-ist',
						'intro' => '<p>Eine Zuordnung verbindet einen Beitrag mit seiner Übersetzung. Nur so'
							. ' führt die Sprachauswahl auf die RICHTIGE Seite statt auf die'
							. ' Startseite.</p>',
						'body'  => '<h2>Wo sie eingestellt wird</h2>'
							. '<p>Im Beitrag, Registerkarte „Zuordnungen“. Für jede weitere Sprache der'
							. ' Website wählt man den passenden Beitrag. Bei einem Menüeintrag und bei'
							. ' einer Kategorie geht es genauso.</p>'
							. '<h2>Es ist keine Übersetzung</h2>'
							. '<p>Joomla übersetzt nichts. Eine Zuordnung sagt nur „diese beiden Beiträge'
							. ' gehören zusammen“. Der Text jeder Sprache bleibt von Hand geschrieben.</p>',
					],
				],
			],

			'es-ES' => [
				'categorie' => ['title' => 'Actualidad', 'alias' => 'actualidad'],
				'menu'      => [
					'menutype'    => 'corpus-es-es',
					'title'       => 'Menú principal (es-ES)',
					'description' => 'El menú del sitio en español. Creado por el módulo de inicio.',
				],
				'accueil'   => 'Inicio',
				'articles'  => [
					[
						'cle'   => 'deux-langues',
						'title' => 'Un sitio en dos idiomas',
						'alias' => 'un-sitio-en-dos-idiomas',
						'intro' => '<p>Este sitio habla ahora varios idiomas. No se ha traducido nada'
							. ' automáticamente: cada idioma tiene su propio contenido, sus propias'
							. ' categorías y su propio menú.</p>',
						'body'  => '<h2>Tres piezas, y ninguna más</h2>'
							. '<p>Un sitio multilingüe de Joomla se apoya en tres piezas. La primera es el'
							. ' <strong>filtro de idioma</strong>, un plugin: decide qué idioma mostrar y'
							. ' aparta el contenido de los demás.</p>'
							. '<p>La segunda es el <strong>menú por idioma</strong>. Cada idioma tiene el'
							. ' suyo, con su propia página de inicio. Esa página indica a Joomla dónde'
							. ' aterrizar cuando se elige ese idioma.</p>'
							. '<p>La tercera es el <strong>selector de idioma</strong>, el módulo de las'
							. ' banderas, arriba a la derecha. Muestra los idiomas publicados y sigue las'
							. ' asociaciones cuando las hay.</p>',
					],
					[
						'cle'   => 'association',
						'title' => 'Qué es una asociación',
						'alias' => 'que-es-una-asociacion',
						'intro' => '<p>Una asociación enlaza un artículo con su traducción. Es lo que permite'
							. ' que el selector de idioma lleve a la página CORRECTA y no a la de'
							. ' inicio.</p>',
						'body'  => '<h2>Dónde se configura</h2>'
							. '<p>En el artículo, pestaña «Asociaciones». Para cada uno de los demás'
							. ' idiomas del sitio se elige el artículo que le corresponde. Un elemento de'
							. ' menú se trata igual, y una categoría también.</p>'
							. '<h2>No es una traducción</h2>'
							. '<p>Joomla no traduce nada. Una asociación solo dice «estos dos artículos se'
							. ' corresponden». El texto de cada idioma se escribe a mano.</p>',
					],
				],
			],
		],
	],
];
