<?php

/**
 * Oculus : plugin de tâche planifiée : alertes de surveillance.
 * Interroge les sites déclarés dans le module mod_oculus, compare avec
 * l'instantané précédent (table #__oculus_state) et alerte par mail.
 * LECTURE SEULE côté sites surveillés.
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

namespace Joomanji\Plugin\Task\Oculus\Extension;

\defined('_JEXEC') or die;

use Joomla\CMS\Access\Access;
use Joomla\CMS\Factory;
use Joomla\CMS\Http\HttpFactory;
use Joomla\CMS\Mail\MailerFactoryAwareTrait;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Scheduler\Administrator\Event\ExecuteTaskEvent;
use Joomla\Component\Scheduler\Administrator\Task\Status;
use Joomla\Component\Scheduler\Administrator\Traits\TaskPluginTrait;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Event\SubscriberInterface;

final class Oculus extends CMSPlugin implements SubscriberInterface
{
    use DatabaseAwareTrait;
    use MailerFactoryAwareTrait;
    use TaskPluginTrait;

    public const VERSION = '0.9.1';

    /** Nombre d'échecs consécutifs avant l'alerte « injoignable ». */
    private const FAILURES_BEFORE_ALERT = 3;

    /**
     * INCIDENTS (ajouté le 30 septembre 2026, version 2.3.0).
     *
     * La panne qui l'a motivé : asso-arsi.com a renvoyé une erreur 500 à ses
     * visiteurs toute une nuit, et c'est le client qui a prévenu, par
     * téléphone. Oculus n'avait rien vu, parce qu'il n'interroge que le point
     * d'accès de son plugin (com_ajax, format brut). Ce chemin ne charge ni le
     * template, ni les modules, ni le constructeur de pages : une erreur qui
     * vient de l'un d'eux casse le site pour tout le monde sauf pour Oculus.
     *
     * D'où deux changements :
     * 1. à chaque passage, la page d'accueil est chargée comme par un visiteur ;
     * 2. une panne (page d'accueil en erreur, ou site injoignable) ouvre un
     *    INCIDENT : mail marqué urgent, rappel chaque heure tant que le site
     *    reste en panne, puis rappel toutes les 6 heures tant que la réparation
     *    n'a pas été confirmée sur le tableau de bord. Un incident ne se ferme
     *    que par cette confirmation : une alerte qu'on peut rater une fois
     *    finit par être ratée.
     */

    /** Passages consécutifs en erreur avant d'ouvrir l'incident (un raté isolé ne réveille personne). */
    private const PAGE_FAILURES_BEFORE_INCIDENT = 2;

    /** Rappel pendant la panne (secondes). */
    private const REMIND_WHILE_DOWN = 3600;

    /** Rappel quand le site répond de nouveau mais que la réparation n'est pas confirmée (secondes). */
    private const REMIND_UNCONFIRMED = 21600;

    /**
     * Marge retirée aux intervalles de rappel : la tâche ne passe jamais à la
     * seconde près, et un rappel « chaque heure » ne doit pas glisser d'un
     * passage entier parce que le quatrième tour arrive trois secondes trop tôt.
     */
    private const REMIND_SLACK = 120;

    /** Même identité que les requêtes du module (voir OculusHelper::USER_AGENT). */
    private const USER_AGENT = 'OculusMonitor/1.0 (+https://oculus.joomnet.fr)';

    /** La colonne « incident » existe-t-elle ? (plugin mis à jour sans passer par l'installeur) */
    private bool $incidentColumn = true;

    /** Intervalle (secondes) entre deux rafraîchissements des mises à jour d'un site. */
    private $updatesInterval = 21600;

    /**
     * Relevé des temps de réponse dans le journal CSV. Le réglage appartient au
     * module mod_oculus : un seul interrupteur pour les deux extensions, sinon
     * on finit avec un journal à moitié rempli sans savoir pourquoi.
     */
    private bool $logTiming = false;

    protected const TASKS_MAP = [
        'oculus.check' => [
            'langConstPrefix' => 'PLG_TASK_OCULUS_CHECK',
            'method'          => 'checkSites',
        ],
    ];

    protected $autoloadLanguage = true;

    public static function getSubscribedEvents(): array
    {
        return [
            'onTaskOptionsList' => 'advertiseRoutines',
            'onExecuteTask'     => 'standardRoutineHandler',
        ];
    }

    // ------------------------------------------------------------------
    // Routine principale
    // ------------------------------------------------------------------

    private function checkSites(ExecuteTaskEvent $event): int
    {
        [$sites, $timeout] = $this->getConfiguredSites();

        // La tâche ne passe que toutes les 5 min : elle peut accorder un délai
        // généreux à un site lent, là où l'affichage temps réel se limite à 5 s.
        // Sans cela, un site alourdi (charge, voire malware) resterait « injoignable »
        // et la surveillance des fichiers ne s'exécuterait jamais dessus.
        $timeout = max($timeout, 45);

        $this->ensureSchema();

        if ($sites === []) {
            $this->logTask('Aucun site configuré dans le module Oculus.', 'warning');

            return Status::OK;
        }

        // On collecte les rapports de tous les sites, puis on envoie UN SEUL mail
        // récapitulatif : lors d'une mise à jour touchant tout le parc, on reçoit
        // une liste unique plutôt que 20 messages séparés.
        $reports = [];

        foreach ($sites as $site) {
            try {
                $report = $this->processSite($site, $timeout);

                // Le site discret est traité normalement (son état est mémorisé,
                // ses mises à jour sont revérifiées), mais il n'alerte jamais :
                // c'est tout l'objet du réglage.
                if ($report !== null && empty($site['discret'])) {
                    $reports[] = $report;
                }
            } catch (\Throwable $e) {
                $this->logTask('Erreur sur ' . $site['url'] . ' : ' . $e->getMessage(), 'error');
            }
        }

        if ($reports !== []) {
            $this->sendDigest($reports);
        }

        return Status::OK;
    }

    /**
     * Envoie UN mail récapitulatif regroupant tous les sites concernés.
     *
     * @param array[] $reports Rapports renvoyés par processSite()
     */
    private function sendDigest(array $reports): void
    {
        // Les sites injoignables n'arrivent plus ici : ils ouvrent un incident,
        // avec son propre mail urgent (voir incidentFailure()). Ce récapitulatif
        // ne porte plus que sur les CHANGEMENTS.
        $changeBlocks = [];
        $totalChanges = 0;

        foreach ($reports as $report) {
            if ($report['lines'] === []) {
                continue;
            }

            $totalChanges  += \count($report['lines']);
            $changeBlocks[] = '• ' . $report['name'] . ' (' . $report['url'] . ")\n    - "
                . implode("\n    - ", $report['lines']);
        }

        if ($changeBlocks === []) {
            return;
        }

        $subject = '[Oculus] ' . $totalChanges . ' changement(s) sur ' . \count($changeBlocks) . ' site(s)';

        $body = 'Rapport de surveillance du ' . $this->localTime(time()) . "\n"
            . "\nCHANGEMENTS DÉTECTÉS\n\n" . implode("\n\n", $changeBlocks) . "\n"
            . "\nSi ces changements ne sont pas de votre fait, vérifiez les sites concernés immédiatement.";

        $this->sendMail($subject, $body);
    }

    /**
     * Lit la liste des sites dans les paramètres du module mod_oculus
     * (source unique de vérité, la même que le tableau de bord).
     */
    private function getConfiguredSites(): array
    {
        $db = $this->getDatabase();

        $raw = $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName('params'))
                ->from($db->quoteName('#__modules'))
                ->where($db->quoteName('module') . ' = ' . $db->quote('mod_oculus'))
                ->where($db->quoteName('client_id') . ' = 1')
                ->where($db->quoteName('published') . ' = 1')
                ->setLimit(1)
        )->loadResult();

        $params  = json_decode((string) $raw, true) ?: [];
        $timeout = max(2, min(30, (int) ($params['timeout'] ?? 5)));

        $this->updatesInterval = max(1, min(48, (int) ($params['updates_hours'] ?? 6))) * 3600;
        $this->logTiming       = !empty($params['log_timing']);
        $sites   = [];

        foreach ((array) ($params['sites'] ?? []) as $site) {
            $site  = (array) $site;
            $url   = trim((string) ($site['url'] ?? ''));
            $token = trim((string) ($site['token'] ?? ''));

            if ($url === '' || $token === '') {
                continue;
            }

            $sites[] = [
                'name'    => trim((string) ($site['sitename'] ?? '')) ?: $url,
                'url'     => $url,
                'token'   => $token,
                // Site DISCRET (surveillance allégée dans mod_oculus) : il est
                // interrogé comme les autres, mais il n'entre jamais dans le mail.
                'discret' => !empty($site['discret']),
            ];
        }

        return [$sites, $timeout];
    }

    // ------------------------------------------------------------------
    // Traitement d'un site
    // ------------------------------------------------------------------

    /**
     * Traite un site et RENVOIE son rapport (sans envoyer de mail) :
     * ['name','url','down'=>bool,'failures'=>int,'lines'=>string[]], ou null si
     * rien à signaler. Les mails sont regroupés en un seul envoi par passage.
     *
     * @return array|null
     */
    private function processSite(array $site, int $timeout): ?array
    {
        $state = $this->loadState($site);

        // Une fois par jour : demander au site de rafraîchir sa liste de
        // mises à jour (sans visite admin, Joomla ne le fait jamais seul).
        $previousSnapshot = $state->snapshot !== null ? json_decode((string) $state->snapshot, true) : null;
        $lastRefresh      = \is_array($previousSnapshot) ? (int) ($previousSnapshot['_updates_refreshed_at'] ?? 0) : 0;
        $refreshedNow     = false;

        if (time() - $lastRefresh > $this->updatesInterval - 300) {
            $refreshedNow = $this->refreshSiteUpdates($site);
        }

        $data = $this->fetchSite($site, $timeout);

        if ($data === null) {
            // Échec : on incrémente, et au seuil le site devient un INCIDENT.
            // Il ne passe plus par le mail récapitulatif : un site injoignable
            // a droit au même traitement qu'une page en erreur (mail urgent,
            // rappels, confirmation), pas à une ligne noyée dans un résumé.
            $state->failures++;

            // Heure du premier raté, pour que l'incident dise depuis quand dure
            // le problème, et pas depuis quand il a franchi le seuil. (2.3.1 :
            // la 2.3.0 datait l'incident du passage qui l'ouvrait.)
            if (!$site['discret']) {
                $this->markFirstFailure($state);
            }

            if ($state->failures >= self::FAILURES_BEFORE_ALERT) {
                $state->alerted_down = 1;

                if (!$site['discret']) {
                    // Le point d'accès ne répond plus. Deux situations très
                    // différentes, que seule la page d'accueil départage
                    // (relevé le 30 septembre sur CC la Houve : plugin absent,
                    // site parfaitement en ligne) :
                    //  - la page s'affiche : le site va bien, c'est la
                    //    SURVEILLANCE qui est coupée (plugin désactivé,
                    //    désinstallé, jeton changé). À réparer, pas en urgence ;
                    //  - la page ne s'affiche pas non plus : vraie panne.
                    $page     = $this->checkHomepage($site, $timeout);
                    $endpoint = 'Le point d\'accès Oculus ne donne plus de réponse exploitable ('
                        . (int) $state->failures . ' passages consécutifs).';

                    if ($page['ok']) {
                        $this->incidentFailure(
                            $state,
                            $site,
                            0,
                            $endpoint . ' La page d\'accueil, elle, s\'affiche normalement (code ' . $page['code'] . ').'
                                . ' Causes probables : Oculus Client désactivé ou désinstallé sur ce site, jeton modifié,'
                                . ' ou pare-feu qui refuse le central sur cette adresse.',
                            true,
                            'blind'
                        );
                    } else {
                        $this->incidentFailure(
                            $state,
                            $site,
                            $page['code'],
                            $endpoint . ' ' . $page['detail'],
                            true
                        );
                    }
                }
            }

            $this->saveState($state);

            return null;
        }

        $lines = [];

        $state->failures     = 0;
        $state->alerted_down = 0;

        $snapshot        = $this->buildSnapshot($data);
        $snapshot['ssl'] = $this->getSslDays($site['url']);

        $snapshot['_updates_refreshed_at'] = $refreshedNow ? time() : $lastRefresh;
        $previous = $state->snapshot !== null ? json_decode((string) $state->snapshot, true) : null;

        if (\is_array($previous)) {
            $lines = array_merge($lines, $this->diffSnapshots($previous, $snapshot));
        } else {
            $this->logTask('Premier passage pour ' . $site['name'] . ' : instantané de référence enregistré.', 'info');
        }

        $state->snapshot = json_encode($snapshot, JSON_UNESCAPED_UNICODE);

        // Contrôle de la page d'accueil, telle qu'un visiteur la reçoit.
        //  - site discret : on lève le pied, c'est tout l'objet du réglage.
        //    Un incident encore ouvert est refermé : passer un site en discret
        //    est une décision de ne plus être prévenu.
        //  - site en maintenance : Joomla y répond volontairement 503, ce
        //    n'est pas une panne. L'incident éventuel reste en l'état.
        if ($site['discret']) {
            $state->incident = null;
        } elseif (empty($snapshot['offline'])) {
            $page = $this->checkHomepage($site, $timeout);

            if ($page['ok']) {
                $this->incidentRecovered($state, $site);
            } else {
                $this->incidentFailure($state, $site, $page['code'], $page['detail']);
            }
        }

        $this->saveState($state);

        if ($lines === []) {
            return null;
        }

        return [
            'name'     => $site['name'],
            'url'      => $site['url'],
            'down'     => false,
            'failures' => 0,
            'lines'    => $lines,
        ];
    }

    /**
     * Demande au site de rafraîchir sa liste de mises à jour
     * (équivalent du bouton « Chercher les mises à jour »).
     */
    private function refreshSiteUpdates(array $site): bool
    {
        $endpoint = rtrim($site['url'], '/')
            . '/index.php?option=com_ajax&plugin=sitemonitor&format=raw&refresh=updates&token=' . urlencode($site['token']);

        try {
            $response = HttpFactory::getHttp()->get($endpoint, ['Accept' => 'application/json'], 40);
        } catch (\Throwable $e) {
            $this->logTask('Rafraîchissement des mises à jour impossible pour ' . $site['name'] . ' : ' . $e->getMessage(), 'warning');

            return false;
        }

        if ($response->code !== 200) {
            $this->logTask('Rafraîchissement des mises à jour refusé pour ' . $site['name'] . ' (HTTP ' . $response->code . '), plugin client v0.7+ requis.', 'warning');

            return false;
        }

        $body = json_decode((string) $response->body, true);

        return \is_array($body) && !empty($body['refreshed']);
    }

    /**
     * Ajoute une ligne au journal des temps, dans le même fichier que le module.
     *
     * Pourquoi ici : la tâche planifiée est la seule à tourner sans que personne
     * ne regarde. Le module, lui, n'écrit que quand on ouvre le tableau de bord,
     * donc jamais à six heures du matin, c'est à dire précisément quand la
     * question se pose.
     *
     * Ce qu'on ne peut pas mesurer : HttpFactory n'expose pas la chronologie
     * DNS / TCP / TLS de cURL. Ces colonnes restent donc VIDES pour les lignes
     * « tache », plutôt que remplies de zéros qu'on lirait comme des mesures.
     * Seul le total est relevé, et c'est lui qui répond à la question posée.
     *
     * Best-effort de bout en bout : un journal ne doit jamais faire échouer une
     * surveillance.
     */
    private function writeTimingLog(array $site, float $seconds, int $code): void
    {
        if (!$this->logTiming) {
            return;
        }

        $app = Factory::getApplication();
        $dir = rtrim((string) $app->get('log_path', JPATH_ADMINISTRATOR . '/logs'), '/\\');

        if (!is_dir($dir)) {
            return;
        }

        $file = $dir . '/oculus-temps.csv';
        $new  = !is_file($file);

        if (!$new && (int) @filesize($file) > 5 * 1024 * 1024) {
            @rename($file, $file . '.1');
            $new = true;
        }

        try {
            // Même piège que dans le module : Date::format() de Joomla formate en
            // GMT tant qu'on ne lui passe pas $local à true. DateTimeImmutable
            // n'a pas cette subtilité, et l'heure locale est ce qui compte pour
            // une question qui porte sur « le matin ».
            $tz    = new \DateTimeZone((string) $app->get('offset', 'UTC'));
            $stamp = (new \DateTimeImmutable('now', $tz))->format('Y-m-d H:i:s');
        } catch (\Throwable $e) {
            $stamp = gmdate('Y-m-d H:i:s') . ' UTC';
        }

        $clean = static fn (string $v): string => str_replace([';', "\n", "\r"], ',', $v);

        $line = sprintf(
            "%s;%s;%s;;;;;%.3f;%d;0;%s\n",
            $stamp,
            $clean((string) ($site['name'] ?? '')),
            $clean((string) ($site['url'] ?? '')),
            $seconds,
            $code,
            'tache'
        );

        if ($new) {
            $line = "\xEF\xBB\xBFdate_locale;site;url;dns;tcp;tls;ttfb;total;code;precede;source\n" . $line;
        }

        @file_put_contents($file, $line, \FILE_APPEND | \LOCK_EX);
    }

    /**
     * Interroge le plugin client d'un site. Renvoie null si injoignable/invalide.
     */
    private function fetchSite(array $site, int $timeout): ?array
    {
        $endpoint = rtrim($site['url'], '/')
            . '/index.php?option=com_ajax&plugin=sitemonitor&format=raw&token=' . urlencode($site['token']);

        // Chronométrage de l'appel que l'on fait DÉJÀ. Pas de seconde requête :
        // le journal doit observer la surveillance, pas l'alourdir.
        $start = microtime(true);

        try {
            $response = HttpFactory::getHttp()->get($endpoint, ['Accept' => 'application/json'], $timeout);
        } catch (\Throwable $e) {
            $this->writeTimingLog($site, microtime(true) - $start, 0);

            return null;
        }

        $this->writeTimingLog($site, microtime(true) - $start, (int) $response->code);

        if ($response->code !== 200) {
            return null;
        }

        $data = json_decode((string) $response->body, true);

        return (\is_array($data) && ($data['status'] ?? '') === 'ok') ? $data : null;
    }

    // ------------------------------------------------------------------
    // Instantanés et comparaison
    // ------------------------------------------------------------------

    /**
     * Ne conserve que les valeurs de base à surveiller.
     */
    private function buildSnapshot(array $data): array
    {
        // Utilisateurs backend (plugin v0.5+) ; repli sur les super users (plugins plus anciens).
        $sourceUsers = (isset($data['backend_users']) && \is_array($data['backend_users']) && !isset($data['backend_users']['error']))
            ? $data['backend_users']
            : (array) ($data['super_users'] ?? []);

        $backendUsers = [];

        $backendMfa = [];

        foreach ($sourceUsers as $user) {
            if (isset($user['id'])) {
                $groups = (isset($user['groups']) && \is_array($user['groups'])) ? ', groupes : ' . implode(', ', $user['groups']) : '';

                $backendUsers[(string) $user['id']] = ($user['username'] ?? '?') . ' (' . ($user['email'] ?? '?') . ')' . $groups;
                $backendMfa[(string) $user['id']]   = $user['mfa_enabled'] ?? null;
            }
        }

        // SUPER ADMINS (droit core.admin) : indexés à part. Leur apparition (ou la
        // promotion d'un compte existant à ce rang) est l'un des signes les plus
        // clairs d'une compromission (l'attaquant se crée un accès permanent).
        $superIds = [];

        foreach ((array) ($data['super_users'] ?? []) as $user) {
            if (isset($user['id'])) {
                $superIds[(string) $user['id']] = ($user['username'] ?? '?') . ' (' . ($user['email'] ?? '?') . ')';
            }
        }

        $extensions = [];

        foreach ((array) ($data['extensions'] ?? []) as $ext) {
            if (isset($ext['id'])) {
                $extensions[(string) $ext['id']] = [
                    'name'    => (string) ($ext['name'] ?? '?'),
                    'enabled' => !empty($ext['enabled']),
                ];
            }
        }

        $tasks = [];

        foreach ((array) ($data['scheduled_tasks'] ?? []) as $task) {
            if (isset($task['id'])) {
                $tasks[(string) $task['id']] = (string) ($task['title'] ?? '?');
            }
        }

        $updates = [];

        foreach ((array) ($data['updates']['available'] ?? []) as $update) {
            $newVersion = (string) ($update['new_version'] ?? '');
            $curVersion = (string) ($update['current_version'] ?? '');

            // Garde-fou : ignore les entrées « fantômes » laissées par Joomla dans
            // #__updates, dont la version cible n'est pas supérieure à l'installée
            // (ex. « Joomla! 6.1.2 → 6.1.2 »). Sans cela, Oculus alerte pour rien.
            if ($curVersion !== '' && $newVersion !== '' && version_compare($newVersion, $curVersion, '<=')) {
                continue;
            }

            $updates[] = ($update['name'] ?? '?') . ' → ' . ($newVersion !== '' ? $newVersion : '?');
        }

        $usersTotal = $data['summary']['users_total'] ?? null;

        // Ancienneté de la dernière sauvegarde Akeeba (jours), si connue.
        $backupDays = null;
        $backupLast = null;

        if (\is_array($data['backup'] ?? null) && !empty($data['backup']['installed'])) {
            $backupLast = $data['backup']['last_backup'] ?? null;

            if ($backupLast && ($ts = strtotime((string) $backupLast)) !== false) {
                $backupDays = (int) floor((time() - $ts) / 86400);
            }
        }

        $phpFiles = (\is_array($data['php_files'] ?? null) && !isset($data['php_files']['error']))
            ? array_keys($data['php_files'])
            : null;

        return [
            'php_files'     => $phpFiles,
            'joomla'        => (string) ($data['core']['joomla_version'] ?? '?'),
            'offline'       => !empty($data['core']['offline']),
            'backend_users' => $backendUsers,
            'backend_mfa'   => $backendMfa,
            'super_ids'     => $superIds,
            'backup_days'   => $backupDays,
            'backup_last'   => $backupLast,
            'users_total'   => \is_numeric($usersTotal) ? (int) $usersTotal : null,
            'extensions'  => $extensions,
            'tasks'       => $tasks,
            'updates'     => $updates,
        ];
    }

    /**
     * Compare deux instantanés et renvoie les changements en français.
     */
    private function diffSnapshots(array $old, array $new): array
    {
        $lines = [];

        // NOUVEAUX FICHIERS PHP dans les emplacements sensibles = porte dérobée probable.
        // (On n'alerte que sur les APPARITIONS, pas les disparitions : un fichier
        //  supprimé n'est pas une menace.)
        if (\is_array($old['php_files'] ?? null) && \is_array($new['php_files'] ?? null)) {
            $added = array_diff($new['php_files'], $old['php_files']);

            foreach ($added as $file) {
                $lines[] = '🛑 FICHIER PHP APPARU : ' . $file . ' : porte dérobée possible, à vérifier d\'urgence';
            }
        }

        // Compatibilité : les anciens instantanés stockaient la liste sous 'super_users'.
        $oldUsers = $old['backend_users'] ?? ($old['super_users'] ?? []);
        $newUsers = $new['backend_users'] ?? [];

        // SUPER ADMIN apparu ou compte existant PROMU super admin : signal de
        // compromission le plus fort après un fichier PHP suspect. Traité en premier
        // et avec un ton sans ambiguïté (cf. l'article : « il s'ajoute un Super User »).
        $newSuper = $new['super_ids'] ?? [];

        // Garde-fou : si l'ancien instantané est ANTÉRIEUR à cette fonction (clé
        // absente), on ne compare pas ce cycle-ci, sinon tous les admins déjà en
        // place seraient signalés « créés ». Le nouvel instantané mémorise la liste,
        // et la comparaison redevient fiable dès le passage suivant.
        $oldSuper = \array_key_exists('super_ids', $old) ? (array) $old['super_ids'] : $newSuper;

        foreach (array_diff_key($newSuper, $oldSuper) as $id => $label) {
            $noMfa       = (($new['backend_mfa'][$id] ?? null) === false) ? ' (et SANS 2FA)' : '';
            $isNewAcct   = !\array_key_exists((string) $id, $oldUsers);

            $lines[] = $isNewAcct
                ? '🛑 SUPER ADMIN CRÉÉ : ' . $label . $noMfa
                    . ' : un compte super administrateur vient d\'apparaître. Si ce n\'est pas de votre fait, '
                    . 'COMPROMISSION PROBABLE : vérifiez le site IMMÉDIATEMENT.'
                : '🛑 ÉLÉVATION EN SUPER ADMIN : ' . $label . $noMfa
                    . ' : un compte existant a reçu les droits super administrateur. À vérifier d\'urgence.';
        }

        foreach (array_diff_key($newUsers, $oldUsers) as $id => $label) {
            // Les nouveaux super admins sont déjà signalés ci-dessus (alerte forte).
            if (\array_key_exists((string) $id, $newSuper)) {
                continue;
            }

            $noMfa   = (($new['backend_mfa'][$id] ?? null) === false) ? ', SANS 2FA !' : '';
            $lines[] = '⚠ UTILISATEUR BACKEND AJOUTÉ : ' . $label . $noMfa;
        }

        foreach (array_diff_key($oldUsers, $newUsers) as $label) {
            $lines[] = 'Utilisateur backend retiré : ' . $label;
        }

        // Double authentification activée ou désactivée sur un compte backend.
        $oldMfa = $old['backend_mfa'] ?? [];
        $newMfa = $new['backend_mfa'] ?? [];

        foreach (array_intersect_key($newMfa, $oldMfa) as $id => $mfa) {
            $label = $newUsers[$id] ?? ('utilisateur #' . $id);

            if ($oldMfa[$id] === true && $mfa === false) {
                $lines[] = '⚠ 2FA DÉSACTIVÉE pour ' . $label;
            } elseif ($oldMfa[$id] === false && $mfa === true) {
                $lines[] = '2FA activée pour ' . $label;
            }
        }

        // Sauvegarde Akeeba : alerte au franchissement des seuils 15 j et 30 j.
        $oldBackup = $old['backup_days'] ?? null;
        $newBackup = $new['backup_days'] ?? null;

        if (\is_int($oldBackup) && \is_int($newBackup)) {
            if ($oldBackup <= 30 && $newBackup > 30) {
                $lines[] = '⚠ CRITIQUE : aucune sauvegarde Akeeba réussie depuis ' . $newBackup . ' jours (dernière : ' . ($new['backup_last'] ?? '?') . ')';
            } elseif ($oldBackup <= 15 && $newBackup > 15) {
                $lines[] = '⚠ Aucune sauvegarde Akeeba réussie depuis ' . $newBackup . ' jours (dernière : ' . ($new['backup_last'] ?? '?') . ')';
            }
        }

        // Certificat SSL : expiration proche, expiré, renouvelé.
        $oldSsl = \is_array($old['ssl'] ?? null) ? ($old['ssl']['days'] ?? null) : null;
        $newSsl = \is_array($new['ssl'] ?? null) ? ($new['ssl']['days'] ?? null) : null;

        if (\is_int($oldSsl) && \is_int($newSsl)) {
            $expires = \is_array($new['ssl']) ? ($new['ssl']['expires'] ?? '?') : '?';

            if ($oldSsl >= 0 && $newSsl < 0) {
                $lines[] = '⚠ CERTIFICAT SSL EXPIRÉ (depuis le ' . $expires . ')';
            } elseif ($oldSsl > 14 && $newSsl <= 14) {
                $lines[] = '⚠ Certificat SSL : expiration dans ' . $newSsl . ' jours (le ' . $expires . ')';
            } elseif ($oldSsl <= 14 && $newSsl > 30) {
                $lines[] = 'Certificat SSL renouvelé (expire le ' . $expires . ')';
            }
        }

        // Variation massive du nombre total de comptes (spam d'inscriptions, purge...).
        if (isset($old['users_total'], $new['users_total'])) {
            $delta = (int) $new['users_total'] - (int) $old['users_total'];

            if ($delta >= 10) {
                $lines[] = '⚠ CRÉATION MASSIVE DE COMPTES : +' . $delta . ' utilisateurs (total : ' . $new['users_total'] . ')';
            } elseif ($delta <= -10) {
                $lines[] = 'Suppression massive de comptes : ' . $delta . ' utilisateurs (total : ' . $new['users_total'] . ')';
            }
        }

        $oldExt = $old['extensions'] ?? [];
        $newExt = $new['extensions'] ?? [];

        foreach (array_diff_key($newExt, $oldExt) as $ext) {
            $lines[] = '⚠ Extension installée : ' . $ext['name'];
        }

        foreach (array_diff_key($oldExt, $newExt) as $ext) {
            $lines[] = 'Extension désinstallée : ' . $ext['name'];
        }

        foreach (array_intersect_key($newExt, $oldExt) as $id => $ext) {
            if ($ext['enabled'] && !$oldExt[$id]['enabled']) {
                $lines[] = '⚠ Extension activée : ' . $ext['name'];
            } elseif (!$ext['enabled'] && $oldExt[$id]['enabled']) {
                $lines[] = 'Extension désactivée : ' . $ext['name'];
            }
        }

        foreach (array_diff_key($new['tasks'] ?? [], $old['tasks'] ?? []) as $title) {
            $lines[] = '⚠ Tâche planifiée créée : ' . $title;
        }

        foreach (array_diff_key($old['tasks'] ?? [], $new['tasks'] ?? []) as $title) {
            $lines[] = 'Tâche planifiée supprimée : ' . $title;
        }

        if (($new['joomla'] ?? '') !== ($old['joomla'] ?? '')) {
            $lines[] = 'Version de Joomla : ' . ($old['joomla'] ?? '?') . ' → ' . ($new['joomla'] ?? '?');
        }

        if (($new['offline'] ?? false) !== ($old['offline'] ?? false)) {
            $lines[] = ($new['offline'] ?? false)
                ? 'Le site est passé HORS LIGNE (mode maintenance).'
                : 'Le site est repassé EN LIGNE.';
        }

        foreach (array_diff($new['updates'] ?? [], $old['updates'] ?? []) as $update) {
            $lines[] = 'Mise à jour disponible : ' . $update;
        }

        return $lines;
    }

    // ------------------------------------------------------------------
    // Incidents : page d'accueil en erreur, site injoignable
    // ------------------------------------------------------------------

    /**
     * Ajoute la colonne « incident » à #__oculus_state si elle manque.
     *
     * Le script d'installation le fait déjà ; ceci couvre le plugin copié à la
     * main, ou une installation dont le script aurait échoué. Sans la colonne,
     * la surveillance continue, simplement sans incidents : mieux vaut une
     * alerte en moins qu'une tâche qui plante sur tous les sites.
     */
    private function ensureSchema(): void
    {
        try {
            $db      = $this->getDatabase();
            $columns = $db->getTableColumns('#__oculus_state', false);

            if (!isset($columns['incident'])) {
                $db->setQuery(
                    'ALTER TABLE ' . $db->quoteName('#__oculus_state')
                    . ' ADD ' . $db->quoteName('incident') . ' mediumtext NULL'
                )->execute();
            }

            $this->incidentColumn = true;
        } catch (\Throwable $e) {
            $this->incidentColumn = false;
            $this->logTask('Colonne « incident » indisponible, les incidents sont désactivés : ' . $e->getMessage(), 'warning');
        }
    }

    /**
     * Charge la page d'accueil comme un visiteur, et dit si elle est servie.
     *
     * Sont une panne : pas de réponse, une erreur serveur (500 et au-delà),
     * une page d'accueil introuvable (404, 410). Ne sont PAS une panne :
     * les redirections, et 401/403, qui disent le plus souvent qu'un pare-feu
     * refuse le central. Ce serait une fausse alerte sur un site qui marche.
     *
     * @return array{ok:bool, code:int, detail:string}
     */
    private function checkHomepage(array $site, int $timeout): array
    {
        $url = rtrim($site['url'], '/') . '/';

        try {
            $response = HttpFactory::getHttp()->get(
                $url,
                ['User-Agent' => self::USER_AGENT, 'Accept' => 'text/html'],
                $timeout
            );
            $code = (int) $response->code;
        } catch (\Throwable $e) {
            return [
                'ok'     => false,
                'code'   => 0,
                'detail' => 'La page d\'accueil ne répond pas (' . $e->getMessage() . ').',
            ];
        }

        if ($code < 500 && $code !== 404 && $code !== 410) {
            return ['ok' => true, 'code' => $code, 'detail' => ''];
        }

        $labels = [
            404 => 'page introuvable',
            410 => 'page supprimée',
            500 => 'erreur interne du serveur',
            502 => 'passerelle en erreur',
            503 => 'service indisponible',
            504 => 'délai de passerelle dépassé',
        ];

        return [
            'ok'     => false,
            'code'   => $code,
            'detail' => 'La page d\'accueil répond par une erreur ' . $code
                . ' (' . ($labels[$code] ?? 'erreur') . ').'
                . ' Si le point d\'accès Oculus, lui, répond normalement, la cause est à chercher du côté'
                . ' du template, d\'une extension de page, d\'un module ou du .htaccess, plutôt que de Joomla lui-même.',
        ];
    }

    /** Incident de ce site, décodé (tableau vide s'il n'y en a pas). */
    private function readIncident(object $state): array
    {
        $raw = $state->incident ?? null;
        $inc = \is_string($raw) && $raw !== '' ? json_decode($raw, true) : null;

        return \is_array($inc) ? $inc : [];
    }

    private function writeIncident(object $state, array $inc): void
    {
        $state->incident = $inc === [] ? null : json_encode($inc, JSON_UNESCAPED_UNICODE);
    }

    /**
     * Note l'heure du premier raté, si aucun incident n'est encore ouvert.
     * Sans effet sur un incident ouvert, qui garde son heure de début.
     */
    private function markFirstFailure(object $state): void
    {
        if (!$this->incidentColumn) {
            return;
        }

        $inc = $this->readIncident($state);

        if (empty($inc['open']) && empty($inc['first_fail'])) {
            $inc['first_fail'] = time();
            $this->writeIncident($state, $inc);
        }
    }

    /**
     * Le site pose problème à ce passage. Deux genres d'incident :
     *
     *  - « down » : le site est en panne pour ses visiteurs. Mail urgent,
     *    rappel urgent chaque heure.
     *  - « blind » : le site s'affiche, mais Oculus ne peut plus le surveiller
     *    (point d'accès muet). Mail normal, rappel toutes les 6 heures : il faut
     *    le réparer, sans réveiller personne, mais tant que c'est coupé une
     *    vraie panne passerait inaperçue.
     *
     * Premier raté : on le note, sans prévenir. Au seuil : l'incident s'ouvre.
     * Un site qui retombe avant qu'on ait confirmé la réparation, ou qui passe
     * de « surveillance coupée » à « en panne », repart aussitôt en urgence.
     *
     * $code vaut 0 quand rien n'a répondu, sinon le code HTTP de la page d'accueil.
     * $immediate : ouvrir dès ce passage. C'est le cas du point d'accès muet,
     * dont la patience est déjà comptée par FAILURES_BEFORE_ALERT.
     */
    private function incidentFailure(object $state, array $site, int $code, string $detail, bool $immediate = false, string $kind = 'down'): void
    {
        if (!$this->incidentColumn) {
            return;
        }

        $now      = time();
        $inc      = $this->readIncident($state);
        $previous = (string) ($inc['kind'] ?? 'down');

        $inc['kind']      = $kind;
        $inc['code']      = $code;
        $inc['detail']    = $detail;
        $inc['last_fail'] = $now;

        if (empty($inc['open'])) {
            $inc['pending']    = (int) ($inc['pending'] ?? 0) + 1;
            $inc['first_fail'] = (int) ($inc['first_fail'] ?? $now);

            $threshold = $immediate ? 1 : self::PAGE_FAILURES_BEFORE_INCIDENT;

            if ($inc['pending'] >= $threshold) {
                $inc['open']         = true;
                $inc['since']        = $inc['first_fail'];
                $inc['recovered_at'] = null;
                $inc['last_mail']    = $now;
                $inc['reminders']    = 0;
                $this->sendIncidentMail($kind === 'blind' ? 'blind' : 'new', $site, $inc);
            }
        } elseif (!empty($inc['recovered_at'])) {
            $inc['recovered_at'] = null;
            $inc['last_mail']    = $now;
            $this->sendIncidentMail($kind === 'blind' ? 'blind' : 'relapse', $site, $inc);
        } elseif ($kind !== $previous) {
            // Aggravation (surveillance coupée → panne) : urgence immédiate.
            // Amélioration (panne → surveillance coupée) : on le dit, sans urgence.
            $inc['last_mail'] = $now;
            $this->sendIncidentMail($kind === 'blind' ? 'blind' : 'new', $site, $inc);
        } else {
            $every = $kind === 'blind' ? self::REMIND_UNCONFIRMED : self::REMIND_WHILE_DOWN;

            if ($now - (int) ($inc['last_mail'] ?? 0) >= $every - self::REMIND_SLACK) {
                $inc['reminders'] = (int) ($inc['reminders'] ?? 0) + 1;
                $inc['last_mail'] = $now;
                $this->sendIncidentMail($kind === 'blind' ? 'blind_remind' : 'remind', $site, $inc);
            }
        }

        $this->writeIncident($state, $inc);
    }

    /**
     * Le site répond normalement à ce passage.
     *
     * Un raté isolé qui n'avait pas encore ouvert d'incident est oublié.
     * Un incident ouvert, lui, ne se referme PAS tout seul : il passe à
     * « rétabli, à confirmer », un mail le dit, et un rappel part toutes les
     * 6 heures jusqu'au clic de confirmation sur le tableau de bord.
     */
    private function incidentRecovered(object $state, array $site): void
    {
        if (!$this->incidentColumn) {
            return;
        }

        $inc = $this->readIncident($state);

        if ($inc === []) {
            return;
        }

        if (empty($inc['open'])) {
            $this->writeIncident($state, []);

            return;
        }

        $now = time();

        if (empty($inc['recovered_at'])) {
            $inc['recovered_at'] = $now;
            $inc['last_mail']    = $now;
            $this->sendIncidentMail('recovered', $site, $inc);
        } elseif ($now - (int) ($inc['last_mail'] ?? 0) >= self::REMIND_UNCONFIRMED - self::REMIND_SLACK) {
            $inc['reminders'] = (int) ($inc['reminders'] ?? 0) + 1;
            $inc['last_mail'] = $now;
            $this->sendIncidentMail('unconfirmed', $site, $inc);
        }

        $this->writeIncident($state, $inc);
    }

    /**
     * Un mail par site et par évènement, jamais noyé dans le récapitulatif.
     * Les mails de panne sont marqués urgents ; ceux de rétablissement non,
     * puisqu'ils ne demandent qu'une vérification.
     */
    private function sendIncidentMail(string $kind, array $site, array $inc): void
    {
        $name     = $site['name'];
        $blind    = ($inc['kind'] ?? 'down') === 'blind';
        $code     = (int) ($inc['code'] ?? 0);
        $what     = $blind ? 'surveillance coupée' : ($code > 0 ? 'erreur ' . $code : 'injoignable');
        $since    = (int) ($inc['since'] ?? time());
        $duration = $this->formatDuration(time() - $since);

        switch ($kind) {
            case 'new':
                $subject = '[Oculus] URGENT : ' . $name . ' en panne (' . $what . ')';
                $intro   = 'Le site ' . $name . ' est en panne.';
                break;
            case 'relapse':
                $subject = '[Oculus] URGENT : ' . $name . ' de nouveau en panne (' . $what . ')';
                $intro   = 'Le site ' . $name . ' était revenu, il est de nouveau en panne.';
                break;
            case 'remind':
                $subject = '[Oculus] RAPPEL URGENT : ' . $name . ' en panne depuis ' . $duration;
                $intro   = 'Le site ' . $name . ' est toujours en panne.';
                break;
            case 'blind':
                $subject = '[Oculus] Surveillance coupée : ' . $name . ' (le site répond)';
                $intro   = 'Oculus ne peut plus surveiller ' . $name . ' : son plugin Oculus Client ne répond plus,'
                    . ' mais la page d\'accueil du site s\'affiche normalement. Ce n\'est pas une panne,'
                    . ' mais tant que la surveillance est coupée, une panne de ce site passerait inaperçue.';
                break;
            case 'blind_remind':
                $subject = '[Oculus] Rappel : surveillance toujours coupée sur ' . $name;
                $intro   = 'Oculus ne peut toujours pas surveiller ' . $name . '. Le site, lui, s\'affiche normalement.';
                break;
            case 'recovered':
                $subject = $blind
                    ? '[Oculus] ' . $name . ' est de nouveau surveillé : confirmez la réparation'
                    : '[Oculus] ' . $name . ' répond de nouveau : confirmez la réparation';
                $intro   = $blind
                    ? 'Oculus surveille de nouveau ' . $name . '.'
                    : 'Le site ' . $name . ' répond de nouveau normalement.';
                break;
            default: // unconfirmed
                $subject = '[Oculus] Rappel : confirmez la réparation de ' . $name;
                $intro   = 'Le site ' . $name . ' répond normalement, mais sa réparation n\'a pas été confirmée.';
        }

        $body = $intro . "\n\n"
            . 'Adresse : ' . $site['url'] . "\n"
            . ($blind ? 'Surveillance coupée depuis le ' : 'En panne depuis le ') . $this->localTime($since);

        if (\in_array($kind, ['recovered', 'unconfirmed'], true) && !empty($inc['recovered_at'])) {
            $body .= ', rétabli le ' . $this->localTime((int) $inc['recovered_at'])
                . ' (durée : ' . $this->formatDuration((int) $inc['recovered_at'] - $since) . ').';
        } else {
            $body .= ' (' . $duration . ').';
        }

        $body .= "\n\nCe qu'Oculus a constaté :\n" . (string) ($inc['detail'] ?? '') . "\n\n";

        if (\in_array($kind, ['recovered', 'unconfirmed'], true)) {
            $body .= "À faire : vérifiez le site, puis ouvrez le tableau de bord Oculus et cliquez"
                . " « J'ai vérifié, c'est réparé ».\n"
                . "Sans cette confirmation, ce rappel est renvoyé toutes les 6 heures.";
        } elseif ($blind) {
            $body .= "À faire : réactiver ou réinstaller Oculus Client sur ce site, ou le passer en « Discret »"
                . " dans le module Oculus si vous ne souhaitez plus le surveiller.\n"
                . "Ce message est renvoyé toutes les 6 heures tant que la surveillance reste coupée.";
        } else {
            $body .= "Ce message est renvoyé chaque heure tant que le site reste en panne.\n"
                . "Quand il répondra de nouveau, il faudra confirmer la réparation sur le tableau de bord Oculus.";
        }

        $dashboard = $this->dashboardUrl();

        if ($dashboard !== '') {
            $body .= "\n\nTableau de bord : " . $dashboard;
        }

        $urgent = \in_array($kind, ['new', 'relapse', 'remind'], true);

        $this->logTask('Incident ' . $kind . ' pour ' . $name . ' (' . $what . ').', $urgent ? 'warning' : 'info');
        $this->sendMail($subject, $body, $urgent);
    }

    /**
     * Adresse de l'administration du site central, pour le lien du mail.
     * Vide si la tâche tourne hors contexte web (ligne de commande) : un lien
     * faux serait pire que pas de lien.
     */
    private function dashboardUrl(): string
    {
        try {
            $root = rtrim(Uri::root(), '/');
            $root = preg_replace('#/administrator$#', '', $root);

            return str_starts_with((string) $root, 'http') ? $root . '/administrator/' : '';
        } catch (\Throwable $e) {
            return '';
        }
    }

    /** « 2 h 14 min », « 35 min », « 1 j 3 h ». */
    private function formatDuration(int $seconds): string
    {
        $seconds = max(0, $seconds);
        $days    = intdiv($seconds, 86400);
        $hours   = intdiv($seconds % 86400, 3600);
        $minutes = intdiv($seconds % 3600, 60);

        if ($days > 0) {
            return $days . ' j' . ($hours > 0 ? ' ' . $hours . ' h' : '');
        }

        if ($hours > 0) {
            return $hours . ' h' . ($minutes > 0 ? ' ' . $minutes . ' min' : '');
        }

        return max(1, $minutes) . ' min';
    }

    /**
     * Date et heure à l'heure du site central. Même précaution que dans
     * writeTimingLog() : date() suit le fuseau de PHP, souvent UTC, pas celui
     * choisi dans la configuration de Joomla.
     */
    private function localTime(int $timestamp): string
    {
        try {
            $tz = new \DateTimeZone((string) Factory::getApplication()->get('offset', 'UTC'));

            return (new \DateTimeImmutable('@' . $timestamp))->setTimezone($tz)->format('d/m/Y à H:i');
        } catch (\Throwable $e) {
            return gmdate('d/m/Y à H:i', $timestamp) . ' UTC';
        }
    }

    // ------------------------------------------------------------------
    // Stockage de l'état (#__oculus_state)
    // ------------------------------------------------------------------

    /**
     * Jours restants avant expiration du certificat SSL du site.
     */
    private function getSslDays(string $url): ?array
    {
        try {
            $host = (string) parse_url($url, PHP_URL_HOST);

            if ($host === '' || stripos($url, 'https://') !== 0) {
                return null;
            }

            $context = stream_context_create(['ssl' => [
                'capture_peer_cert' => true,
                'verify_peer'       => false,
                'verify_peer_name'  => false,
                'SNI_enabled'       => true,
            ]]);

            $client = @stream_socket_client('ssl://' . $host . ':443', $errno, $errstr, 8, STREAM_CLIENT_CONNECT, $context);

            if (!$client) {
                return null;
            }

            $params = stream_context_get_params($client);
            fclose($client);

            $certResource = $params['options']['ssl']['peer_certificate'] ?? null;

            if (!$certResource) {
                return null;
            }

            $cert = openssl_x509_parse($certResource);

            if (!\is_array($cert) || empty($cert['validTo_time_t'])) {
                return null;
            }

            return [
                'days'    => (int) floor(((int) $cert['validTo_time_t'] - time()) / 86400),
                'expires' => date('d-m-Y H:i', (int) $cert['validTo_time_t']),
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function loadState(array $site): object
    {
        $db  = $this->getDatabase();
        $key = md5(rtrim($site['url'], '/'));

        $row = $db->setQuery(
            $db->getQuery(true)
                ->select('*')
                ->from($db->quoteName('#__oculus_state'))
                ->where($db->quoteName('site_key') . ' = ' . $db->quote($key))
        )->loadObject();

        if ($row === null) {
            $row = (object) [
                'site_key'     => $key,
                'snapshot'     => null,
                'failures'     => 0,
                'alerted_down' => 0,
                'incident'     => null,
                '_new'         => true,
            ];
        }

        $row->site_name = $site['name'];
        $row->site_url  = $site['url'];

        return $row;
    }

    private function saveState(object $state): void
    {
        $db    = $this->getDatabase();
        $isNew = !empty($state->_new);
        unset($state->_new);

        $state->checked      = gmdate('Y-m-d H:i:s');
        $state->failures     = (int) $state->failures;
        $state->alerted_down = (int) $state->alerted_down;

        if (!$this->incidentColumn) {
            unset($state->incident);
        } elseif (!property_exists($state, 'incident')) {
            $state->incident = null;
        }

        if ($isNew) {
            $db->insertObject('#__oculus_state', $state, 'site_key');
        } else {
            // $nulls à vrai : sans lui, updateObject() saute les valeurs nulles,
            // et un incident refermé (incident = NULL) resterait ouvert en base.
            $db->updateObject('#__oculus_state', $state, 'site_key', true);
        }
    }

    // ------------------------------------------------------------------
    // Envoi des mails
    // ------------------------------------------------------------------

    /**
     * Envoie aux super users du site central ayant
     * « Recevoir les emails système » activé.
     */
    private function sendMail(string $subject, string $body, bool $urgent = false): void
    {
        $recipients = $this->getRecipients();

        if ($recipients === []) {
            $this->logTask('Aucun destinataire : aucun super user avec « Recevoir les emails système ».', 'warning');

            return;
        }

        foreach ($recipients as $email) {
            try {
                $mailer = $this->getMailerFactory()->createMailer();
                $mailer->isHtml(false);
                $mailer->setSubject($subject);
                $mailer->setBody($body . "\n\n-- \nOculus, surveillance du parc Joomla");
                $mailer->addRecipient($email);

                if ($urgent) {
                    // Priorité haute : les messageries (Proton, Gmail, Outlook)
                    // l'affichent et savent la faire sonner. X-Priority est posé
                    // par PHPMailer à partir de Priority ; Importance est l'en-tête
                    // que lit Outlook.
                    $mailer->Priority = 1;
                    $mailer->addCustomHeader('Importance', 'High');
                }
                $mailer->Send();
            } catch (\Throwable $e) {
                $this->logTask('Envoi du mail impossible à ' . $email . ' : ' . $e->getMessage(), 'error');
            }
        }
    }

    private function getRecipients(): array
    {
        $db = $this->getDatabase();

        $groupIds = $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName('id'))
                ->from($db->quoteName('#__usergroups'))
        )->loadColumn();

        $superGroups = [];

        foreach ($groupIds as $groupId) {
            if (Access::checkGroup((int) $groupId, 'core.admin')) {
                $superGroups[] = (int) $groupId;
            }
        }

        if ($superGroups === []) {
            return [];
        }

        $userIds = $db->setQuery(
            $db->getQuery(true)
                ->select('DISTINCT ' . $db->quoteName('user_id'))
                ->from($db->quoteName('#__user_usergroup_map'))
                ->whereIn($db->quoteName('group_id'), $superGroups)
        )->loadColumn();

        if ($userIds === []) {
            return [];
        }

        return $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName('email'))
                ->from($db->quoteName('#__users'))
                ->whereIn($db->quoteName('id'), array_map('intval', $userIds))
                ->where($db->quoteName('block') . ' = 0')
                ->where($db->quoteName('sendEmail') . ' = 1')
        )->loadColumn();
    }
}
