<?php

/**
 * Oculus — Module tableau de bord (administration).
 * Interroge le plugin client "sitemonitor" de chaque site surveillé.
 * LECTURE SEULE : simples requêtes GET, aucune action à distance.
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

namespace Joomanji\Module\Oculus\Administrator\Helper;

\defined('_JEXEC') or die;

use Joomla\CMS\Cache\CacheControllerFactoryInterface;
use Joomla\CMS\Extension\ExtensionHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Http\HttpFactory;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;
use Joomla\Registry\Registry;

class OculusHelper
{
    /** Résultat de la dernière mise à jour déclenchée (null si aucune). */
    private ?array $updateResult = null;

    /** Vrai sur le rendu initial : le template doit lancer l'interrogation en tâche de fond. */
    private bool $autoLoad = false;

    /** Horodatage de l'instantané affiché (null si aucun / données fraîches). */
    private ?int $snapshotTime = null;

    /**
     * Relevé des temps de réponse dans un journal CSV (réglage du module).
     * Faux par défaut : le journal répond à une question, il ne s'entretient pas.
     */
    private bool $logTiming = false;

    public function getLastUpdateResult(): ?array
    {
        return $this->updateResult;
    }

    /** Le template doit-il déclencher l'interrogation différée des sites ? */
    public function shouldAutoLoad(): bool
    {
        return $this->autoLoad;
    }

    /** Horodatage (epoch) des données affichées si elles viennent du cache. */
    public function getSnapshotTime(): ?int
    {
        return $this->snapshotTime;
    }

    /**
     * User-Agent envoyé avec chaque requête de contrôle.
     * Identifiable par les hébergeurs : évite d'être pris pour un bot
     * malveillant (une requête sans UA = ban CrowdSec « http-bad-user-agent »),
     * et permet de whitelister proprement le monitoring.
     * ATTENTION : ne JAMAIS y mettre les mots « Joomla », « bot », « spider »
     * ou « crawler » — ils figurent dans les listes de User-Agents bannis
     * (cf. hub-data.crowdsec.net/web/bad_user_agents.regex.txt, \bJoomla\b).
     */
    private const USER_AGENT = 'OculusMonitor/1.0 (+https://oculus.joomnet.fr)';

    /**
     * INCIDENTS OUVERTS, pour le bandeau rouge en tête du tableau de bord.
     *
     * C'est Oculus Alerte (plg_task_oculus 2.3.0+) qui les ouvre, dans
     * #__oculus_state.incident, quand la page d'accueil d'un site est en
     * erreur ou que le site ne répond plus. Le module se contente de les
     * montrer, et de refermer celui dont on confirme la réparation : c'est le
     * seul endroit où un incident se ferme. Tant qu'il est ouvert, la tâche
     * renvoie un rappel par mail.
     *
     * Seuls les sites encore déclarés, et non discrets, sont montrés : un site
     * retiré du module ne doit pas laisser un bandeau rouge orphelin.
     *
     * @return array[] name, url, key, kind (down|blind), code, detail, since, recovered_at, last_fail
     */
    public function getIncidents(Registry $params): array
    {
        $this->handleAcknowledge();

        $configured = [];

        foreach ((array) $params->get('sites', []) as $site) {
            $site = (object) $site;
            $url  = trim((string) ($site->url ?? ''));

            if ($url === '' || !empty($site->discret)) {
                continue;
            }

            $configured[md5(rtrim($url, '/'))] = [
                'name' => trim((string) ($site->sitename ?? '')) ?: $url,
                'url'  => $url,
            ];
        }

        if ($configured === []) {
            return [];
        }

        try {
            $db   = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
            $rows = $db->setQuery(
                $db->getQuery(true)
                    ->select([$db->quoteName('site_key'), $db->quoteName('incident')])
                    ->from($db->quoteName('#__oculus_state'))
                    ->where($db->quoteName('incident') . ' IS NOT NULL')
            )->loadObjectList();
        } catch (\Throwable $e) {
            // Table ou colonne absente : Oculus Alerte pas encore en 2.3.0.
            return [];
        }

        $incidents = [];

        foreach ($rows as $row) {
            $inc = json_decode((string) $row->incident, true);

            if (!\is_array($inc) || empty($inc['open']) || !isset($configured[$row->site_key])) {
                continue;
            }

            $incidents[] = $configured[$row->site_key] + [
                'key'          => (string) $row->site_key,
                'kind'         => (string) ($inc['kind'] ?? 'down'),
                'code'         => (int) ($inc['code'] ?? 0),
                'detail'       => (string) ($inc['detail'] ?? ''),
                'since'        => (int) ($inc['since'] ?? 0),
                'recovered_at' => !empty($inc['recovered_at']) ? (int) $inc['recovered_at'] : null,
                'last_fail'    => (int) ($inc['last_fail'] ?? 0),
            ];
        }

        // Les sites en panne d'abord, puis ceux dont la surveillance est coupée,
        // puis ceux à confirmer ; les plus anciens en tête dans chaque groupe.
        $rank = static function (array $i): int {
            if ($i['recovered_at'] !== null) {
                return 2;
            }

            return $i['kind'] === 'blind' ? 1 : 0;
        };

        usort($incidents, static function ($a, $b) use ($rank) {
            return [$rank($a), $a['since']] <=> [$rank($b), $b['since']];
        });

        return $incidents;
    }

    /**
     * Clic sur « J'ai vérifié, c'est réparé » : referme l'incident.
     *
     * Refusé tant que le site est encore en panne au dernier passage de la
     * tâche. Confirmer une réparation qui n'a pas eu lieu ferait taire les
     * rappels, et c'est précisément ce qu'on veut rendre impossible.
     */
    private function handleAcknowledge(): void
    {
        $app = Factory::getApplication();
        $key = $app->getInput()->getAlnum('oculus_ack', '');

        if ($key === '') {
            return;
        }

        if (!Session::checkToken('get')) {
            $app->enqueueMessage('Jeton de session invalide : recharge la page et réessaie.', 'warning');

            return;
        }

        if (!$app->getIdentity()->authorise('core.manage', 'com_modules')) {
            $app->enqueueMessage('Droits insuffisants pour confirmer la réparation.', 'error');

            return;
        }

        try {
            $db  = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
            $row = $db->setQuery(
                $db->getQuery(true)
                    ->select([$db->quoteName('site_name'), $db->quoteName('incident')])
                    ->from($db->quoteName('#__oculus_state'))
                    ->where($db->quoteName('site_key') . ' = ' . $db->quote($key))
            )->loadObject();

            $inc = $row !== null ? json_decode((string) $row->incident, true) : null;

            if (!\is_array($inc) || empty($inc['open'])) {
                $app->enqueueMessage('Cet incident est déjà refermé.', 'info');
            } elseif (empty($inc['recovered_at'])) {
                $app->enqueueMessage(
                    $row->site_name . ' était encore en panne au dernier passage de la surveillance :'
                    . ' la confirmation sera possible dès qu\'il répondra de nouveau.',
                    'warning'
                );
            } else {
                $db->setQuery(
                    $db->getQuery(true)
                        ->update($db->quoteName('#__oculus_state'))
                        ->set($db->quoteName('incident') . ' = NULL')
                        ->where($db->quoteName('site_key') . ' = ' . $db->quote($key))
                )->execute();

                $app->enqueueMessage('Réparation de ' . $row->site_name . ' confirmée : l\'incident est refermé, les rappels s\'arrêtent.', 'success');
            }
        } catch (\Throwable $e) {
            $app->enqueueMessage('Confirmation impossible : ' . $e->getMessage(), 'error');
        }

        // On quitte l'adresse qui porte le jeton, pour qu'un rechargement de
        // la page ne rejoue pas la confirmation.
        $app->redirect('index.php');
    }

    /**
     * Interroge chaque site configuré et renvoie son état.
     *
     * @return array[] Une entrée par site : name, url, ok, error, summary, generated, plugin_version.
     */
    public function getSitesStatus(Registry $params): array
    {
        $timeout = (int) $params->get('timeout', 10);
        $timeout = max(2, min(30, $timeout ?: 10));

        // Relevé des temps de réponse : désactivé par défaut, car il écrit un
        // fichier à chaque passage. On l'allume le temps de répondre à une
        // question, on l'éteint ensuite.
        $this->logTiming = (bool) $params->get('log_timing', 0);

        // Age en dessous duquel on réutilise le dernier instantané au lieu de
        // rappeler les sites. GARDE-FOU AJOUTÉ LE 2 SEPTEMBRE 2026.
        //
        // Chaque ouverture du tableau de bord déclenchait un balayage complet du
        // parc, et l'actualisation automatique en déclenchait un de plus à
        // chaque tour. Relevé ce soir-là dans oculus-temps.csv : 25 balayages en
        // 39 minutes, soit un toutes les 95 secondes, là où le cron n'en demande
        // que trois. Vingt-sept requêtes sortantes d'une même IP toutes les dix
        // secondes finissent par se faire couper par les protections des
        // serveurs d'en face : connexion acceptée, poignée de main TLS bouclée,
        // puis zéro octet reçu. Sept sites parfaitement sains sont passés
        // « injoignables » de cette façon en une demi-heure.
        $maxAge = max(0, min(3600, (int) $params->get('load_maxage', 300)));

        // « Interroger tous les sites » : force la vérification des mises à jour
        // côté chaque site avant d'en lire l'état (déclenché par le bouton).
        $input = Factory::getApplication()->getInput();

        // Téléchargement du journal : traité avant tout le reste, car la méthode
        // termine la requête. Rien de ce qui suit ne doit être fait pour ça.
        if ($input->getInt('oculus_dllog', 0) === 1) {
            $this->downloadTimingLog();
        }

        $force      = (bool) $input->getInt('oculus_refresh', 0);
        $doUpdate   = (bool) $input->getInt('oculus_update', 0);
        $updateSite = $input->getInt('usite', -1);
        $updateEid  = $input->getInt('ueid', 0);
        $doBackup   = (bool) $input->getInt('oculus_backup', 0);
        $backupSite = $input->getInt('usite', -1);
        $doLoad     = (bool) $input->getInt('oculus_load', 0);
        $doHarden   = (bool) $input->getInt('oculus_harden', 0);
        $hardenSite = $input->getInt('usite', -1);
        $doClean    = (bool) $input->getInt('oculus_clean', 0);
        $cleanSite  = $input->getInt('usite', -1);
        $cleanWhat  = $input->getCmd('target', 'tmp');
        $doOne      = (bool) $input->getInt('oculus_one', 0);
        $oneSite    = $input->getInt('usite', -1);

        // RENDU INITIAL (aucune action, aucun chargement demandé) : on N'INTERROGE
        // PAS les sites (ce serait ~20 requêtes HTTP synchrones = page lente). On
        // renvoie tout de suite le dernier instantané en cache, et le template
        // déclenchera l'interrogation réelle en tâche de fond (oculus_load=1).
        if (!$force && !$doUpdate && !$doBackup && !$doLoad && !$doHarden && !$doClean && !$doOne) {
            $snap = $this->readSnapshot();

            if ($snap !== null) {
                $this->snapshotTime = $snap['t'] ?? null;

                // Instantané encore frais : on ne demande même pas l'interrogation
                // de fond au template. La page est déjà juste, et c'est ce qui
                // supprime le balayage à chaque ouverture.
                $this->autoLoad = !$this->snapshotIsFresh($snap, $maxAge);

                return $snap['sites'] ?? [];
            }

            $this->autoLoad = true;

            return []; // pas encore d'instantané → le template affiche « chargement… »
        }

        // Interrogation de fond, et actualisation automatique à intervalle : on ne
        // recontacte les sites que si l'instantané a vieilli. Le bouton
        // « Interroger tous les sites » ($force) passe outre, c'est sa raison
        // d'être : quand on le presse, on veut vraiment des données neuves.
        if ($doLoad && !$force) {
            $snap = $this->readSnapshot();

            if ($this->snapshotIsFresh($snap, $maxAge)) {
                $this->snapshotTime = $snap['t'] ?? null;

                return $snap['sites'] ?? [];
            }
        }

        // Parse des paramètres communs (requis/ignorés/référence/toujours-afficher).
        [$required, $ignore, $reference, $always] = $this->parseListParams($params);

        // ACTION SUR UN SEUL SITE (mise à jour, sauvegarde, durcissement, nettoyage).
        // Toutes passent l'index d'affichage via « usite ». On déclenche l'action,
        // puis on ne rafraîchit QUE ce site (rapide) — les 19 autres viennent du
        // cache. C'est ce qui rend l'enchaînement des MàJ groupées praticable.
        $actionSite = $updateSite; // même paramètre pour toutes les actions

        if (($doUpdate || $doBackup || $doHarden || $doClean) && $actionSite >= 0) {
            $target = $this->findValidSite($params, $actionSite);

            if ($target !== null) {
                if ($doUpdate && $updateEid > 0) {
                    $this->updateResult = $this->triggerUpdate($target['url'], $target['token'], $updateEid, $timeout);
                } elseif ($doBackup) {
                    $this->updateResult = $this->triggerBackup($target['url'], $target['token']);
                } elseif ($doHarden) {
                    $this->updateResult = $this->triggerHarden($target['url'], $target['token'], (string) $params->get('htaccess_block', ''), $timeout);
                } elseif ($doClean) {
                    $this->updateResult = $this->triggerClean($target['url'], $target['token'], $cleanWhat, $timeout);
                }

                if ($this->updateResult !== null) {
                    $this->updateResult['site'] = $target['name'];
                }
            }

            $one = $this->refreshOneSite($params, $actionSite, $timeout, $required, $ignore, $reference, $always);

            if ($one !== null) {
                return $one;
            }

            // Pas de cache exploitable : on désactive les déclencheurs (l'action a
            // déjà eu lieu) et on tombe sur l'interrogation complète pour le rendu.
            $doUpdate = $doBackup = $doHarden = $doClean = false;
        }

        // RAFRAÎCHISSEMENT INDIVIDUEL d'un site (bouton « Actualiser » d'une ligne).
        if ($doOne && $oneSite >= 0) {
            $one = $this->refreshOneSite($params, $oneSite, $timeout, $required, $ignore, $reference, $always);

            if ($one !== null) {
                return $one;
            }
            // pas de cache exploitable : on retombe sur l'interrogation complète.
        }

        $results = [];

        foreach ((array) $params->get('sites', []) as $site) {
            $site = (object) $site;

            $name  = trim((string) ($site->sitename ?? ''));
            $url   = trim((string) ($site->url ?? ''));
            $token = trim((string) ($site->token ?? ''));

            if ($url === '' || $token === '') {
                continue;
            }

            // Index STABLE de ce site (ordre de configuration), indépendant du tri
            // d'affichage : c'est lui qui relie un clic dans le tableau au bon site.
            // (Les actions par site sont gérées plus haut, hors de cette boucle.)
            $idx = \count($results);

            $status             = $this->checkSite($name !== '' ? $name : $url, $url, $token, $timeout, $required, $force, $ignore, $reference, $always);
            $status['category'] = trim((string) ($site->category ?? ''));
            $status['_idx']     = $idx;
            $status['frozen']   = !empty($site->frozen);
            // Surveillance ALLÉGÉE : le site est interrogé comme les autres, mais
            // sa ligne se limite à l'essentiel, il ne remonte jamais dans les
            // priorités et il n'alerte pas. Voir le champ « discret » du manifeste.
            $status['discret']  = !empty($site->discret);

            $results[] = $status;
        }

        $results = $this->applyParcDeduction($results);

        // Interrogation réelle effectuée : on mémorise l'instantané pour que le
        // prochain affichage de la page soit instantané.
        $this->writeSnapshot($results);

        return $results;
    }

    /**
     * DÉDUCTION PARC : la version la plus récente d'une extension vue sur
     * N'IMPORTE quel site sert de référence aux autres. Si un site est en dessous
     * (et que Joomla n'a rien détecté), on le signale « (parc) ». Ré-applicable
     * après un rafraîchissement individuel.
     */
    private function applyParcDeduction(array $results): array
    {
        $parcMax = [];

        foreach ($results as $r) {
            foreach ((array) ($r['extensions_list'] ?? []) as $e) {
                $st = (string) ($e['stem'] ?? '');
                $v  = (string) ($e['version'] ?? '');

                if ($st === '' || $v === '') {
                    continue;
                }

                if (!isset($parcMax[$st]) || version_compare($v, $parcMax[$st], '>')) {
                    $parcMax[$st] = $v;
                }
            }
        }

        foreach ($results as &$r) {
            if (!\is_array($r['extensions_list'] ?? null)) {
                continue;
            }

            foreach ($r['extensions_list'] as &$e) {
                $st = (string) ($e['stem'] ?? '');
                $v  = (string) ($e['version'] ?? '');

                // On repart d'un état propre (utile en rafraîchissement individuel).
                unset($e['parc_new']);

                if ($st !== '' && $v !== '' && isset($parcMax[$st])
                    && empty($e['new']) && empty($e['ref_new'])
                    && version_compare($v, $parcMax[$st], '<')) {
                    $e['parc_new'] = $parcMax[$st];
                }
            }
            unset($e);

            // Re-tri : urgents (new / ref_new / parc_new) d'abord, puis par nom.
            usort($r['extensions_list'], static function ($a, $b) {
                $ua = (!empty($a['new']) || !empty($a['ref_new']) || !empty($a['parc_new'])) ? 0 : (empty($a['enabled']) ? 2 : 1);
                $ub = (!empty($b['new']) || !empty($b['ref_new']) || !empty($b['parc_new'])) ? 0 : (empty($b['enabled']) ? 2 : 1);

                if ($ua !== $ub) {
                    return $ua - $ub;
                }

                return strcasecmp((string) $a['name'], (string) $b['name']);
            });
        }
        unset($r);

        return $results;
    }

    /**
     * Retrouve le site de configuration correspondant à un index d'AFFICHAGE
     * (_idx = position parmi les sites valides). Renvoie [name, url, token] ou null.
     */
    private function findValidSite(Registry $params, int $index): ?array
    {
        $valid = 0;

        foreach ((array) $params->get('sites', []) as $site) {
            $site  = (object) $site;
            $url   = trim((string) ($site->url ?? ''));
            $token = trim((string) ($site->token ?? ''));

            if ($url === '' || $token === '') {
                continue;
            }

            if ($valid === $index) {
                return [
                    'name'  => trim((string) ($site->sitename ?? '')) ?: $url,
                    'url'   => $url,
                    'token' => $token,
                ];
            }

            $valid++;
        }

        return null;
    }

    /**
     * Rafraîchit UN SEUL site (bouton « Actualiser » d'une ligne) : repart de
     * l'instantané en cache, ré-interroge le site demandé en direct, ré-applique
     * la déduction parc, mémorise, et renvoie l'ensemble. Rapide : les 19 autres
     * sites ne sont pas recontactés.
     */
    private function refreshOneSite(Registry $params, int $target, int $timeout, array $required, array $ignore, array $reference, array $always): ?array
    {
        $snap = $this->readSnapshot();

        if ($snap === null || !\is_array($snap['sites'] ?? null)) {
            return null; // pas de cache : on laissera le flux normal tout interroger
        }

        $results = $snap['sites'];

        // Retrouver le site de configuration correspondant à cet index d'affichage
        // (_idx = position parmi les sites VALIDES, comme dans la boucle principale).
        $valid = 0;
        $done  = false;

        foreach ((array) $params->get('sites', []) as $site) {
            $site  = (object) $site;
            $url   = trim((string) ($site->url ?? ''));
            $token = trim((string) ($site->token ?? ''));

            if ($url === '' || $token === '') {
                continue;
            }

            if ($valid === $target) {
                $name   = trim((string) ($site->sitename ?? ''));
                $status = $this->checkSite($name !== '' ? $name : $url, $url, $token, $timeout, $required, false, $ignore, $reference, $always);
                $status['category'] = trim((string) ($site->category ?? ''));
                $status['_idx']     = $target;
                $status['frozen']   = !empty($site->frozen);
                $status['discret']  = !empty($site->discret);

                // Remplace l'entrée correspondante dans les résultats en cache.
                $replaced = false;

                foreach ($results as $i => $row) {
                    if ((int) ($row['_idx'] ?? -1) === $target) {
                        $results[$i] = $status;
                        $replaced    = true;
                        break;
                    }
                }

                if (!$replaced) {
                    $results[] = $status;
                }

                $done = true;
                break;
            }

            $valid++;
        }

        if (!$done) {
            return $results; // index hors périmètre : on renvoie le cache tel quel
        }

        $results = $this->applyParcDeduction($results);
        $this->writeSnapshot($results);

        return $results;
    }

    /**
     * Analyse les listes de configuration partagées par l'interrogation complète
     * et le rafraîchissement individuel.
     *
     * @return array{0:array, 1:array, 2:array, 3:array} [required, ignore, reference, always]
     */
    private function parseListParams(Registry $params): array
    {
        $required = array_values(array_filter(array_map(
            'trim',
            preg_split('/[,;\n]+/', (string) $params->get('required_exts', ''))
        )));

        $ignore = array_values(array_filter(array_map(
            static fn ($v) => mb_strtolower(trim((string) $v)),
            preg_split('/[,;\n]+/', (string) $params->get('ignore_exts', 'pkg_search'))
        )));

        $always = array_values(array_filter(array_map(
            static fn ($v) => mb_strtolower(trim((string) $v)),
            preg_split('/[,;\n]+/', (string) $params->get('always_exts', ''))
        )));

        $reference = [];

        foreach (preg_split('/[\r\n]+/', (string) $params->get('reference_versions', '')) as $refLine) {
            if (strpos($refLine, '=') === false) {
                continue;
            }

            [$rk, $rv] = explode('=', $refLine, 2);
            $rk = mb_strtolower(trim($rk));
            $rv = trim($rv);

            if ($rk !== '' && $rv !== '') {
                $reference[$rk] = $rv;
            }
        }

        return [$required, $ignore, $reference, $always];
    }

    /**
     * Version installée + état de publication du plugin « Oculus Alerte »
     * (plg_task_oculus), pour la pastille verte/rouge du bandeau du module.
     *
     * @return array{found:bool, enabled:bool, version:string}
     */
    public function getAlertPluginStatus(): array
    {
        try {
            $db  = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
            $row = $db->setQuery(
                $db->getQuery(true)
                    ->select([$db->quoteName('enabled'), $db->quoteName('manifest_cache')])
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                    ->where($db->quoteName('folder') . ' = ' . $db->quote('task'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('oculus'))
            )->loadObject();

            if ($row === null) {
                return ['found' => false, 'enabled' => false, 'version' => ''];
            }

            $manifest = json_decode((string) $row->manifest_cache, true) ?: [];

            return [
                'found'   => true,
                'enabled' => (int) $row->enabled === 1,
                'version' => (string) ($manifest['version'] ?? ''),
            ];
        } catch (\Throwable $e) {
            return ['found' => false, 'enabled' => false, 'version' => ''];
        }
    }

    /** Chemin du fichier d'instantané (cache admin). */
    /**
     * L'instantané est-il assez récent pour être réutilisé tel quel ?
     * $maxAge à 0 désactive le garde-fou : chaque passage réinterroge le parc.
     */
    private function snapshotIsFresh(?array $snap, int $maxAge): bool
    {
        if ($maxAge <= 0 || $snap === null) {
            return false;
        }

        $t = (int) ($snap['t'] ?? 0);

        return $t > 0 && (time() - $t) <= $maxAge;
    }

    private function snapshotFile(): string
    {
        return rtrim(JPATH_CACHE, '/\\') . '/mod_oculus_snapshot.json';
    }

    /** Lit le dernier instantané, ou null s'il n'existe pas / est illisible. */
    private function readSnapshot(): ?array
    {
        $file = $this->snapshotFile();

        if (!is_file($file)) {
            return null;
        }

        $data = json_decode((string) @file_get_contents($file), true);

        if (!\is_array($data) || !isset($data['sites']) || !\is_array($data['sites'])) {
            return null;
        }

        return $data;
    }

    /** Enregistre l'instantané des résultats (avec horodatage). */
    private function writeSnapshot(array $sites): void
    {
        try {
            @file_put_contents(
                $this->snapshotFile(),
                (string) json_encode(
                    ['t' => time(), 'sites' => $sites],
                    \JSON_INVALID_UTF8_SUBSTITUTE | \JSON_UNESCAPED_UNICODE
                ),
                \LOCK_EX
            );
        } catch (\Throwable $e) {
            // best-effort : un échec de cache ne doit pas casser l'affichage
        }
    }

    /**
     * Calendrier de fin de vie d'un produit (php, mysql, mariadb, postgresql)
     * via l'API publique endoflife.date, mis en cache 24 h.
     * Renvoie cycle => date de fin (ou false si non planifiée), ou null si indisponible.
     */
    private function getEolCycles(string $product): ?array
    {
        try {
            $controller = Factory::getContainer()
                ->get(CacheControllerFactoryInterface::class)
                ->createCacheController('callback', [
                    'defaultgroup' => 'mod_oculus',
                    'lifetime'     => 1440,
                    'caching'      => true,
                ]);

            $cycles = $controller->get(
                static function (string $p) {
                    try {
                        $response = HttpFactory::getHttp()->get(
                            'https://endoflife.date/api/' . $p . '.json',
                            ['Accept' => 'application/json'],
                            5
                        );
                    } catch (\Throwable $e) {
                        return [];
                    }

                    if ($response->code !== 200) {
                        return [];
                    }

                    $rows = json_decode((string) $response->body, true);

                    if (!\is_array($rows)) {
                        return [];
                    }

                    $map = [];

                    foreach ($rows as $row) {
                        if (isset($row['cycle'])) {
                            $map[(string) $row['cycle']] = \array_key_exists('eol', $row) ? $row['eol'] : null;
                        }
                    }

                    return $map;
                },
                [$product],
                'oculus.eol.' . $product
            );

            return (\is_array($cycles) && $cycles !== []) ? $cycles : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Statut de fin de vie d'une version : eol, soon (< 90 jours), ok, unknown.
     */
    private function versionStatus(string $version, string $product): array
    {
        $unknown = ['status' => 'unknown', 'eol' => null];

        if ($version === '' || !preg_match('/^(\d+\.\d+)/', $version, $m)) {
            return $unknown;
        }

        $cycles = $this->getEolCycles($product);

        if ($cycles === null || !\array_key_exists($m[1], $cycles)) {
            return $unknown;
        }

        $eol = $cycles[$m[1]];

        if ($eol === false || $eol === null) {
            return ['status' => 'ok', 'eol' => null];
        }

        if ($eol === true) {
            return ['status' => 'eol', 'eol' => null];
        }

        $eol = (string) $eol;

        if ($eol <= date('Y-m-d')) {
            return ['status' => 'eol', 'eol' => $eol];
        }

        if ($eol <= date('Y-m-d', time() + 90 * 86400)) {
            return ['status' => 'soon', 'eol' => $eol];
        }

        return ['status' => 'ok', 'eol' => $eol];
    }

    /**
     * Requête GET en cURL direct — même comportement qu'un curl « nu », sans
     * la couche HttpFactory de Joomla. Capture au passage le certificat TLS
     * (CURLOPT_CERTINFO, donc zéro connexion de sonde supplémentaire) et un
     * diagnostic chronométré complet en cas d'échec.
     */
    private function curlRequest(string $url, int $timeout): array
    {
        $ch = curl_init($url);

        curl_setopt_array($ch, [
            \CURLOPT_RETURNTRANSFER => true,
            \CURLOPT_FOLLOWLOCATION => true,
            \CURLOPT_MAXREDIRS      => 5,
            \CURLOPT_TIMEOUT        => $timeout,
            \CURLOPT_CONNECTTIMEOUT => $timeout,
            \CURLOPT_HTTPHEADER     => ['Accept: application/json', 'Expect:'],
            \CURLOPT_USERAGENT      => self::USER_AGENT,
            \CURLOPT_CERTINFO       => true,
        ]);

        $body  = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $info  = curl_getinfo($ch);

        curl_close($ch);

        // Date d'expiration du certificat, extraite de la connexion elle-même.
        $expires = null;

        foreach ((array) ($info['certinfo'][0] ?? []) as $k => $v) {
            if (strcasecmp((string) $k, 'Expire date') === 0) {
                $ts = strtotime((string) $v);

                if ($ts !== false) {
                    $expires = $ts;
                }
            }
        }

        return [
            'errno'           => $errno,
            'error'           => $error,
            'code'            => (int) ($info['http_code'] ?? 0),
            'body'            => \is_string($body) ? $body : '',
            'ip'              => (string) ($info['primary_ip'] ?? ''),
            'time_dns'        => (float) ($info['namelookup_time'] ?? 0),
            'time_connect'    => (float) ($info['connect_time'] ?? 0),
            // PIEGE MESURE LE 2 SEPTEMBRE 2026 : curl_getinfo($ch) SANS second
            // argument ne renvoie PAS de clé « appconnect_time ». PHP expose la
            // poignée de main TLS uniquement en microsecondes, sous
            // « appconnect_time_us ». L'ancienne lecture donnait donc 0 sur les
            // 27 sites du parc, et personne ne le voyait : le chiffre n'était
            // affiché qu'en cas d'échec, où un 0 passe pour un détail.
            // Symptôme qui a mis la puce à l'oreille : TLS 0,00 s alors que TCP
            // valait 0,03 s, ce qui est impossible (ces temps sont cumulés
            // depuis le début de la requête, donc TLS est toujours >= TCP).
            'time_tls'        => isset($info['appconnect_time_us'])
                ? ((float) $info['appconnect_time_us']) / 1000000
                : (float) ($info['appconnect_time'] ?? 0),
            // Premier octet et durée totale, ajoutés le 2 septembre 2026. Ce sont
            // eux qui séparent un serveur endormi (premier octet long, DNS et TCP
            // courts) d'un problème de résolution ou de réseau (DNS ou TCP long).
            // Sans eux, la chronologie s'arrêtait à la poignée de main TLS et ne
            // disait rien du temps que le site met à se réveiller.
            'time_ttfb'       => (float) ($info['starttransfer_time'] ?? 0),
            'time_total'      => (float) ($info['total_time'] ?? 0),
            'cert_expires_ts' => $expires,
        ];
    }

    /**
     * Journal CSV des temps de réponse : une ligne par site et par passage.
     *
     * Pourquoi un fichier et pas une table : le relevé sert à trancher une
     * question ponctuelle (le serveur est-il froid le matin ?), il se lit dans
     * un tableur, et il se supprime quand la réponse est connue. Une table de
     * base de données aurait survécu à la question qui l'a fait naître.
     *
     * Pourquoi l'heure locale et pas UTC : la question porte sur « le matin ».
     * Un horodatage UTC obligerait à retrancher deux heures à chaque lecture,
     * et c'est exactement le genre de calcul qu'on rate une fois sur trois.
     *
     * Plafond à 5 Mo, puis rotation sur un seul fichier .1 : 27 sites toutes les
     * 15 minutes écrivent environ 1,5 Mo par semaine, sans fin.
     *
     * Best-effort de bout en bout : un journal qui échoue ne doit jamais faire
     * échouer une surveillance.
     */
    private function writeTimingLog(string $name, string $url, array $t, int $code, bool $preceded): void
    {
        if (!$this->logTiming) {
            return;
        }

        $app  = Factory::getApplication();
        $file = $this->timingLogFile();

        if ($file === '') {
            return; // dossier de journaux absent : on ne crée rien, on n'alerte pas
        }

        $new = !is_file($file);

        if (!$new && (int) @filesize($file) > 5 * 1024 * 1024) {
            @rename($file, $file . '.1');
            $new = true;
        }

        try {
            // PIEGE JOOMLA, relevé le 2 septembre 2026. Date::format() prend un
            // second paramètre $local qui vaut FALSE par défaut, et dans ce cas
            // la méthode formate en GMT quoi qu'il arrive : le setTimezone() qui
            // précède ne sert alors à rien. Le journal sortait donc en UTC alors
            // que le site est bien réglé sur Europe/Paris, deux heures d'écart
            // en septembre. Assez pour lire une courbe du matin décalée, c'est
            // à dire exactement l'erreur que ce journal doit éviter.
            // DateTimeImmutable n'a pas cette subtilité.
            $tz    = new \DateTimeZone((string) $app->get('offset', 'UTC'));
            $stamp = (new \DateTimeImmutable('now', $tz))->format('Y-m-d H:i:s');
        } catch (\Throwable $e) {
            $stamp = gmdate('Y-m-d H:i:s') . ' UTC';
        }

        // Le point-virgule sépare les colonnes : on le retire des valeurs plutôt
        // que d'entourer chaque champ de guillemets, illisibles à l'oeil nu.
        $clean = static fn (string $v): string => str_replace([';', "\n", "\r"], ',', $v);

        $line = sprintf(
            "%s;%s;%s;%.3f;%.3f;%.3f;%.3f;%.3f;%d;%d;%s\n",
            $stamp,
            $clean($name),
            $clean($url),
            (float) ($t['dns'] ?? 0),
            (float) ($t['tcp'] ?? 0),
            (float) ($t['tls'] ?? 0),
            (float) ($t['ttfb'] ?? 0),
            (float) ($t['total'] ?? 0),
            $code,
            $preceded ? 1 : 0,
            'tableau'
        );

        if ($new) {
            // Colonne « source » : le tableau de bord et la tâche planifiée
            // écrivent tous deux dans ce fichier, et ils ne mesurent pas la même
            // chose. « tableau » remplit toute la chronologie ; « tache » ne
            // remplit que « total », parce qu'elle passe par HttpFactory qui
            // n'expose pas le détail. Sans cette colonne, on lirait des zéros
            // comme des mesures.
            //
            // Le BOM UTF-8 en tête n'est pas décoratif : sans lui, Excel ouvre
            // le fichier en ANSI et massacre les accents des noms de sites.
            $line = "\xEF\xBB\xBFdate_locale;site;url;dns;tcp;tls;ttfb;total;code;precede;source\n" . $line;
        }

        @file_put_contents($file, $line, \FILE_APPEND | \LOCK_EX);
    }

    /**
     * Détail technique ajouté aux messages d'échec : IP réellement contactée
     * et chronologie DNS → TCP → TLS, pour diagnostiquer sans rien deviner.
     */
    private function formatCurlDiag(array $c, string $url = ''): string
    {
        $parts = [];

        // IP réellement contactée. Attention : cURL ne remplit primary_ip que si
        // la connexion s'est établie. Or ce diagnostic ne s'affiche QUE sur un
        // échec, donc dans le cas le plus fréquent (connexion refusée ou
        // silencieuse) la valeur est vide et le message ne disait pas quelle
        // adresse avait été tentée. On la résout alors nous-mêmes : c'est cette
        // adresse-là qu'il faut donner à l'hébergeur d'en face.
        if ($c['ip'] !== '') {
            $parts[] = 'IP ' . $c['ip'];
        } elseif ($url !== '') {
            $host = (string) parse_url($url, \PHP_URL_HOST);

            if ($host !== '') {
                $ip = gethostbyname($host);

                // gethostbyname() renvoie son argument tel quel quand la
                // résolution échoue : un nom en retour signifie « pas résolu ».
                $parts[] = $ip !== $host
                    ? 'IP ' . $ip . ' (résolue)'
                    : 'nom non résolu';
            }
        }

        $parts[] = sprintf('DNS %.2fs', $c['time_dns']);
        $parts[] = sprintf('TCP %.2fs', $c['time_connect']);
        $parts[] = sprintf('TLS %.2fs', $c['time_tls']);
        $parts[] = sprintf('1er octet %.2fs', $c['time_ttfb'] ?? 0);

        // Adresse de DÉPART. C'est elle qu'un hébergeur doit autoriser quand son
        // pare-feu jette nos paquets, et elle n'apparaissait nulle part : on
        // savait que ça bloquait, jamais quoi faire autoriser.
        $from = $this->serverAddress();

        if ($from !== '') {
            $parts[] = 'vue depuis ' . $from;
        }

        return ' [' . implode(' · ', $parts) . ']';
    }

    /**
     * Chemin du journal des temps, ou chaîne vide si le dossier de journaux de
     * Joomla n'existe pas. Partagé par l'écriture et par le téléchargement :
     * deux endroits qui construisent le même chemin finissent toujours par
     * diverger.
     */
    private function timingLogFile(): string
    {
        $dir = rtrim((string) Factory::getApplication()->get('log_path', JPATH_ADMINISTRATOR . '/logs'), '/\\');

        return is_dir($dir) ? $dir . '/oculus-temps.csv' : '';
    }

    /**
     * Sert le journal en téléchargement, puis termine la requête.
     *
     * Pourquoi ici et pas un lien direct vers le fichier : le dossier
     * administrator/logs est fermé par son propre .htaccess, et c'est très bien
     * ainsi. On passe donc par PHP, avec jeton de session et contrôle de droits.
     */
    private function downloadTimingLog(): void
    {
        $app = Factory::getApplication();

        // Le journal ne contient aucun secret, mais une adresse qui sert un
        // fichier du serveur se protège par principe : sans jeton, un autre site
        // pourrait la faire ouvrir au navigateur d'un administrateur connecté.
        if (!Session::checkToken('get')) {
            $app->enqueueMessage('Jeton de session invalide : recharge la page et réessaie.', 'warning');

            return;
        }

        if (!$app->getIdentity()->authorise('core.manage', 'com_modules')) {
            $app->enqueueMessage('Droits insuffisants pour télécharger le journal des temps.', 'error');

            return;
        }

        $file = $this->timingLogFile();

        if ($file === '' || !is_file($file)) {
            $app->enqueueMessage(
                'Aucun journal à télécharger : le relevé des temps de réponse est éteint, ou il n\'a encore rien écrit.',
                'info'
            );

            return;
        }

        // La page d'administration est déjà en cours d'assemblage dans un tampon
        // de sortie. On le jette avant d'envoyer le fichier, faute de quoi le CSV
        // serait précédé du début du HTML.
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        $app->setHeader('Content-Type', 'text/csv; charset=utf-8', true);
        $app->setHeader('Content-Disposition', 'attachment; filename="oculus-temps-' . date('Y-m-d-Hi') . '.csv"', true);
        $app->setHeader('Content-Length', (string) filesize($file), true);
        $app->setHeader('Cache-Control', 'no-store', true);
        $app->sendHeaders();

        readfile($file);

        $app->close();
    }

    /**
     * Adresse publique de CE serveur, celle qu'un hébergeur tiers doit
     * autoriser dans son pare-feu.
     *
     * SERVER_ADDR est l'adresse ENTRANTE. Sur un mutualisé elle coïncide
     * souvent avec l'adresse sortante, mais pas toujours : derrière un
     * répartiteur de charge ou un proxy, elle vaut une adresse de bouclage ou
     * une adresse privée, qu'aucun pare-feu distant ne peut autoriser.
     *
     * MESURE DU 3 SEPTEMBRE 2026, sur oculus.joomnet.fr : SERVER_ADDR vaut
     * 127.0.0.1. Le message de panne annonçait donc « vue depuis 127.0.0.1 »,
     * c'est à dire la seule adresse qui ne serve à rien. L'utilisateur voyait
     * « son IP est bloquée par un pare-feu » sans jamais savoir quelle adresse
     * faire autoriser, et le diagnostic s'arrêtait là.
     *
     * On écarte donc les adresses de bouclage, privées et réservées, et on
     * retombe sur la résolution du nom de domaine du central, publique par
     * construction. Elle reste une piste à confirmer (l'adresse sortante peut
     * différer de l'entrante), d'où le mot « vue depuis ».
     */
    private function serverAddress(): string
    {
        $addr = (string) (Factory::getApplication()->getInput()->server->getString('SERVER_ADDR', '') ?: '');

        // NO_PRIV_RANGE et NO_RES_RANGE écartent 127.0.0.1, ::1, 10.x,
        // 172.16-31.x, 192.168.x et les plages réservées.
        if (filter_var($addr, \FILTER_VALIDATE_IP, \FILTER_FLAG_NO_PRIV_RANGE | \FILTER_FLAG_NO_RES_RANGE)) {
            return $addr;
        }

        try {
            $host = (string) Uri::getInstance()->getHost();
        } catch (\Throwable $e) {
            return '';
        }

        if ($host === '') {
            return '';
        }

        $ip = gethostbyname($host);

        // gethostbyname() renvoie son argument tel quel quand la résolution
        // échoue : un nom en retour signifie « pas résolu ».
        return ($ip !== $host && filter_var($ip, \FILTER_VALIDATE_IP)) ? $ip : '';
    }

    /**
     * Traduit les erreurs cURL/HTTP brutes en diagnostic exploitable.
     * Trois familles bien distinctes :
     *  - la connexion TCP n'aboutit pas  → blocage réseau/pare-feu en amont ;
     *  - connectée mais 0 octet reçu     → serveur en difficulté (PHP muet) ;
     *  - données partielles puis timeout → site fonctionnel mais trop lent.
     */
    private function describeConnectionError(string $raw, int $timeout): string
    {
        if (preg_match('/connect/i', $raw) && preg_match('/timed out|timeout/i', $raw)) {
            return 'Connexion impossible : aucune réponse du serveur en ' . $timeout
                . ' s (IP probablement bloquée par un pare-feu en amont). Détail : ' . $raw;
        }

        if (preg_match('/timed out|timeout/i', $raw)) {
            if (preg_match('/with\s+(\d+)\s+bytes received/i', $raw, $m) && (int) $m[1] > 0) {
                return 'Site trop lent : réponse incomplète après ' . $timeout
                    . ' s (' . $m[1] . ' octets reçus). Augmenter le délai d\'attente du module ?';
            }

            return 'Serveur muet : connexion établie mais aucune donnée reçue en '
                . $timeout . ' s (serveur web ou PHP en difficulté)';
        }

        if (preg_match('/resolve|getaddrinfo|name lookup/i', $raw)) {
            return 'DNS introuvable : le nom de domaine ne se résout pas. Détail : ' . $raw;
        }

        if (preg_match('/ssl|certificate|tls/i', $raw)) {
            return 'Problème SSL/TLS : ' . $raw;
        }

        return 'Injoignable : ' . $raw;
    }

    /**
     * Vide à distance le dossier tmp ou les caches d'un site.
     *
     * @return array{ok:bool, message:string}
     */
    /*
     * POURQUOI LE CENTRAL APPELLE ENCORE &plugin=sitemonitor
     *
     * Le plugin client s'appelle desormais « oculusclient » (paquets 2.1.1), mais
     * com_ajax envoie l'evenement onAjaxXxx a TOUS les plugins du groupe ajax,
     * pas seulement a celui qui porte ce nom. Le nouveau plugin ecoute donc les
     * deux evenements, et l'ancienne adresse continue de fonctionner.
     *
     * On garde volontairement l'ancien nom tant que le parc n'est pas entierement
     * migre : un site pas encore a jour repondrait dans le vide au nouveau nom et
     * disparaitrait du tableau de bord. Le jour ou les 23 sites sont passes en
     * 2.1.1, remplacer les sept occurrences ci-dessous par « oculusclient » et
     * supprimer l'ecoute de l'ancien evenement dans le plugin.
     */

    private function triggerClean(string $url, string $token, string $target, int $timeout): array
    {
        $target = \in_array($target, ['tmp', 'cache'], true) ? $target : 'tmp';

        $endpoint = rtrim($url, '/')
            . '/index.php?option=com_ajax&plugin=sitemonitor&format=raw'
            . '&token=' . urlencode($token)
            . '&action=clean&target=' . $target;

        $curl = $this->curlRequest($endpoint, max($timeout, 300));

        if ($curl['errno'] !== 0) {
            return ['ok' => false, 'message' => 'Site injoignable ou délai dépassé : ' . $curl['error']];
        }

        $data = json_decode((string) $curl['body'], true);

        if (!\is_array($data)) {
            return ['ok' => false, 'message' => 'Réponse invalide du site (HTTP ' . $curl['code'] . ').'];
        }

        if (($data['status'] ?? '') === 'ok') {
            $mo   = round(((int) ($data['bytes'] ?? 0)) / 1048576, 1);
            $skip = (int) ($data['skipped'] ?? 0);

            return [
                'ok'      => true,
                'message' => ($target === 'cache' ? 'Caches vidés' : 'Dossier tmp vidé') . ' : '
                    . (int) ($data['deleted'] ?? 0) . ' fichier(s) supprimé(s), ' . $mo . ' Mo libérés.'
                    . ($skip > 0 ? ' ' . $skip . ' fichier(s) très récent(s) conservé(s) par précaution.' : '')
                    . ' Les fichiers de protection (index.html, .htaccess) ont été préservés.',
            ];
        }

        return ['ok' => false, 'message' => (string) ($data['message'] ?? 'Échec du nettoyage.')];
    }

    /**
     * Applique le bloc de durcissement .htaccess sur un site distant.
     * Le bloc est transmis en base64 (sauts de ligne et symboles Apache).
     *
     * @return array{ok:bool, message:string}
     */
    private function triggerHarden(string $url, string $token, string $block, int $timeout): array
    {
        $endpoint = rtrim($url, '/')
            . '/index.php?option=com_ajax&plugin=sitemonitor&format=raw'
            . '&token=' . urlencode($token)
            . '&action=htaccess'
            . '&block=' . urlencode(base64_encode(trim($block)));

        // Le client teste le site après écriture : on lui laisse le temps.
        $curl = $this->curlRequest($endpoint, max($timeout, 90));

        if ($curl['errno'] !== 0) {
            return ['ok' => false, 'message' => 'Site injoignable ou délai dépassé : ' . $curl['error']];
        }

        $data = json_decode((string) $curl['body'], true);

        if (!\is_array($data)) {
            return ['ok' => false, 'message' => 'Réponse invalide du site (HTTP ' . $curl['code'] . ').'];
        }

        if (($data['status'] ?? '') === 'ok') {
            if (empty($data['applied'])) {
                return ['ok' => true, 'message' => 'Bloc de durcissement Oculus retiré du .htaccess.'];
            }

            $probe  = $data['probe_code'] ?? null;
            $server = trim((string) ($data['server'] ?? ''));

            // Le test réel prime : écrire la règle ne prouve pas qu'elle s'applique.
            if (!empty($data['verified'])) {
                return [
                    'ok'      => true,
                    'message' => 'Oculus Bouclier appliqué et VÉRIFIÉ : un script PHP déposé dans images/ '
                        . 'est bien bloqué (HTTP ' . (int) $probe . ').'
                        . ($server !== '' ? ' Serveur : ' . $server . '.' : '')
                        . (!empty($data['backup']) ? ' Sauvegarde : ' . $data['backup'] : ''),
                ];
            }

            // Test IMPOSSIBLE (le site n'a pas pu s'appeler lui-même) : on ne peut
            // rien conclure sur l'efficacité de la règle. Ne pas confondre avec une
            // règle testée et inopérante.
            if ($probe === null) {
                return [
                    'ok'      => true,
                    'message' => 'Durcissement appliqué, mais la vérification automatique n\'a pas pu être réalisée'
                        . (($data['probe_reason'] ?? '') !== '' ? ' (' . $data['probe_reason'] . ')' : '') . '.'
                        . ($server !== '' ? ' Serveur : ' . $server . '.' : '')
                        . ' Cela ne signifie PAS que la protection est inopérante : il faut la contrôler à la main,'
                        . ' en déposant un fichier .php dans images/ et en l\'appelant dans le navigateur'
                        . ' (403 attendu).',
                ];
            }

            return [
                'ok'      => false,
                'message' => 'Bloc écrit, mais la protection N\'EST PAS EFFECTIVE : le test réel renvoie HTTP '
                    . (int) $probe . ' au lieu de 403.'
                    . ($server !== '' ? ' Serveur : ' . $server . '.' : '')
                    . ' Cet hébergement ignore vraisemblablement les fichiers .htaccess : la protection'
                    . ' des dossiers d\'upload doit y être obtenue autrement.',
            ];
        }

        return ['ok' => false, 'message' => (string) ($data['message'] ?? 'Échec du durcissement.')];
    }

    /**
     * Déclenche une sauvegarde Akeeba à distance via l'action « backup » du
     * plugin client. Délai très long : une sauvegarde peut durer plusieurs minutes.
     *
     * @return array{ok:bool, message:string}
     */
    private function triggerBackup(string $url, string $token): array
    {
        $endpoint = rtrim($url, '/')
            . '/index.php?option=com_ajax&plugin=sitemonitor&format=raw'
            . '&token=' . urlencode($token)
            . '&action=backup';

        // Sauvegarde = long. Délai généreux (10 min).
        $curl = $this->curlRequest($endpoint, 600);

        if ($curl['errno'] !== 0) {
            return ['ok' => false, 'message' => 'Site injoignable ou délai dépassé : ' . $curl['error']];
        }

        $data = json_decode((string) $curl['body'], true);

        if (!\is_array($data)) {
            return ['ok' => false, 'message' => 'Réponse invalide du site (HTTP ' . $curl['code'] . ').'];
        }

        if (($data['status'] ?? '') === 'ok') {
            return ['ok' => true, 'message' => 'Sauvegarde Akeeba effectuée (profil ' . (int) ($data['profile'] ?? 1) . ').'];
        }

        return ['ok' => false, 'message' => (string) ($data['message'] ?? 'Échec de la sauvegarde.')];
    }

    /**
     * Déclenche la mise à jour d'une extension sur un site distant, via l'action
     * « update » du plugin client (écriture, sécurisée par token côté site).
     *
     * @return array{ok:bool, message:string, name?:string, version?:string, code?:string}
     */
    private function triggerUpdate(string $url, string $token, int $eid, int $timeout): array
    {
        $endpoint = rtrim($url, '/')
            . '/index.php?option=com_ajax&plugin=sitemonitor&format=raw'
            . '&token=' . urlencode($token)
            . '&action=update&eid=' . $eid;

        // Une installation peut être longue : délai généreux.
        $curl = $this->curlRequest($endpoint, max($timeout, 120));

        if ($curl['errno'] !== 0) {
            return ['ok' => false, 'message' => 'Site injoignable : ' . $curl['error']];
        }

        $data = json_decode((string) $curl['body'], true);

        if (!\is_array($data)) {
            return ['ok' => false, 'message' => 'Réponse invalide du site (HTTP ' . $curl['code'] . ').'];
        }

        if (($data['status'] ?? '') === 'ok') {
            return [
                'ok'      => true,
                'name'    => (string) ($data['name'] ?? ''),
                'version' => (string) ($data['version'] ?? ''),
                'message' => 'Mise à jour effectuée : ' . trim(($data['name'] ?? '') . ' ' . ($data['version'] ?? '')),
            ];
        }

        return [
            'ok'      => false,
            'code'    => (string) ($data['code'] ?? ''),
            'message' => (string) ($data['message'] ?? 'Échec de la mise à jour.')
                . ' (réf. extension #' . $eid . ' sur ce site)',
        ];
    }

    /**
     * Radical d'une extension : élément en minuscules sans son préfixe de type
     * (com_/mod_/plg_/lib_/pkg_/tpl_). Relie un composant et les plugins/modules
     * qui l'accompagnent : com_cgsecure, plugin « cgsecure » -> « cgsecure ».
     */
    private function extStem(string $element): string
    {
        return (string) preg_replace('/^(com_|mod_|plg_|lib_|pkg_|tpl_)/i', '', strtolower(trim($element)));
    }

    private function checkSite(string $name, string $url, string $token, int $timeout, array $required = [], bool $force = false, array $ignore = [], array $reference = [], array $always = []): array
    {
        $result = [
            'name'              => $name,
            'url'               => $url,
            'ok'                => false,
            'error'             => null,
            'summary'           => null,
            'generated'         => null,
            'plugin_version'    => null,
            'joomla_update'     => null,
            'ext_updates'       => 0,
            'ext_updates_names' => [],
            'db'                => null,
            'auto_update'       => null,
            'backend_users'     => null,
            'backend_names'     => [],
            'suspect_files'     => [],
            'files_checked'     => false,
            'htaccess_suspect'  => [],
            'htaccess_state'    => null,
            // Durcissement Oculus : null = pas d'information (client trop ancien),
            // true/false = bloc présent ou non ; l'empreinte permet de détecter un
            // bloc appliqué mais devenu différent de celui configuré.
            'harden_present'    => null,
            'harden_hash'       => null,
            // Code HTTP du dernier test réel de la protection (403 = effective).
            'harden_verify'     => null,
            'server_soft'       => '',
            // Volumétrie nettoyable (client v0.15+) : null = non remonté.
            'tmp_files'         => null,
            'tmp_bytes'         => 0,
            'cache_files'       => null,
            'cache_bytes'       => 0,
            'htaccess_mode'     => null,
            'config_modified'   => null,
            'config_mode'       => null,
            'config_state'      => null,
            'present_required'  => [],
            'php_status'        => null,
            'db_status'         => null,
            'db_schema'         => null,
            'extensions_list'   => [],
            'maintenance'       => false,
            'backup'            => null,
            'missing_required'  => [],
            'backend_no_mfa'    => [],
            // Comptes dont la MFA est explicitement ACTIVE. Compté à part : une
            // liste backend_no_mfa vide ne prouve pas que tout le monde est
            // protégé (le statut peut être inconnu avec un ancien client).
            'backend_mfa'       => 0,
            'ssl'               => null,
            // Chronologie de la requête de contrôle : dns, tcp, tls, ttfb, total,
            // en secondes. Relevée à chaque passage, plus seulement en cas d'échec.
            'timing'            => null,
        ];

        $endpoint = rtrim($url, '/')
            . '/index.php?option=com_ajax&plugin=sitemonitor&format=raw&token=' . urlencode($token);

        // Forçage : demande d'abord au site de revérifier ses mises à jour
        // (findUpdates), puis on lit l'état frais. Best-effort : on ignore le
        // résultat de cette première requête.
        if ($force) {
            $this->curlRequest($endpoint . '&refresh=updates', $timeout);
        }

        $curl = $this->curlRequest($endpoint, $timeout);

        // Chronologie relevée à CHAQUE passage, et non plus seulement quand la
        // requête échoue. Mesuré le 2 septembre 2026 : les premières visites du
        // matin étaient très lentes, l'hébergeur ne voyait rien de son côté, et
        // aucun relevé n'existait pour trancher entre un DNS froid et un serveur
        // endormi. Le chiffre existait déjà dans cURL, il n'était pas conservé.
        //
        // Ce qu'il mesure, exactement : la requête de contrôle vers com_ajax, pas
        // la page d'accueil. Il dit dans quel état est le serveur, pas ce que voit
        // un visiteur. Et il le dit depuis CE serveur : un DNS froid chez le
        // fournisseur d'accès d'un visiteur ne s'y verra jamais.
        $result['timing'] = [
            'dns'   => round($curl['time_dns'], 3),
            'tcp'   => round($curl['time_connect'], 3),
            'tls'   => round($curl['time_tls'], 3),
            'ttfb'  => round($curl['time_ttfb'], 3),
            'total' => round($curl['time_total'], 3),
        ];

        // $force a déjà lancé une première requête vers le même hôte : DNS et TCP
        // sont alors chauds et leurs chiffres ne valent rien. On journalise quand
        // même, avec la colonne « precede » à 1, plutôt que de laisser un trou.
        $this->writeTimingLog($name, $url, $result['timing'], (int) $curl['code'], $force);

        // Certificat SSL : lu directement sur la connexion de contrôle
        // (CURLOPT_CERTINFO), plus aucune sonde TLS séparée.
        if (stripos($url, 'https://') === 0 && !empty($curl['cert_expires_ts'])) {
            $ts = (int) $curl['cert_expires_ts'];

            $result['ssl'] = [
                'expires' => date('d-m-Y H:i', $ts),
                'days'    => (int) floor(($ts - time()) / 86400),
            ];
        }

        if ($curl['errno'] !== 0) {
            $result['error'] = $this->describeConnectionError($curl['error'], $timeout)
                . $this->formatCurlDiag($curl, $url);

            return $result;
        }

        $response = (object) ['code' => $curl['code'], 'body' => $curl['body']];

        if ($response->code !== 200) {
            // 503 = signature d'un Joomla en mode maintenance (site volontairement
            // hors ligne) : com_ajax est bloqué, on ne peut pas atteindre le plugin,
            // mais ce n'est PAS une panne. On le distingue d'une vraie indisponibilité.
            if ($response->code === 503) {
                $result['maintenance'] = true;
                $result['error']       = 'Site en maintenance (hors ligne), réponse HTTP 503';

                return $result;
            }

            $result['error'] = 'Réponse HTTP ' . $response->code
                . ($response->code === 403 ? ' (token refusé ?)' : '');

            return $result;
        }

        $data = json_decode((string) $response->body, true);

        if (!\is_array($data) || ($data['status'] ?? '') !== 'ok') {
            $result['error'] = 'Réponse invalide (plugin sitemonitor absent ou désactivé ?)';

            return $result;
        }

        $result['ok']             = true;
        $result['summary']        = \is_array($data['summary'] ?? null) ? $data['summary'] : [];
        $result['generated']      = $data['generated'] ?? null;
        $result['plugin_version'] = $data['plugin_version'] ?? null;

        // Version de la base de données, en clair (ex. « MariaDB 10.6.21 »).
        $dbVersion = (string) ($data['core']['db_version'] ?? '');
        $dbType    = (string) ($data['core']['db_type'] ?? '');

        if ($dbVersion !== '') {
            if (stripos($dbVersion, 'mariadb') !== false) {
                $result['db'] = 'MariaDB ' . trim(str_ireplace(['-MariaDB', 'MariaDB'], '', $dbVersion), '- ');
            } else {
                $result['db'] = trim(ucfirst($dbType) . ' ' . $dbVersion);
            }
        }

        // Statuts de fin de vie (PHP / base de données) via endoflife.date.
        $result['php_status'] = $this->versionStatus((string) ($data['core']['php_version'] ?? ''), 'php');

        if ($dbVersion !== '') {
            $product = stripos($dbVersion, 'mariadb') !== false
                ? 'mariadb'
                : ($dbType === 'postgresql' ? 'postgresql' : 'mysql');

            $result['db_status'] = $this->versionStatus($dbVersion, $product);
        }

        // Surveillance du schéma BDD (plugin client v0.9.4+) : structures de
        // tables en erreur après une mise à jour (écran Maintenance : BDD).
        if (\is_array($data['db_schema'] ?? null) && !isset($data['db_schema']['error'])) {
            $problems = [];

            foreach ((array) ($data['db_schema']['problems'] ?? []) as $p) {
                if (!\is_array($p)) {
                    continue;
                }

                $label = trim((string) ($p['name'] ?? ''));

                // Certains noms restent sous forme de clé de langue non traduite
                // côté site (ex. « COM_FOO_XYZ ») : on retombe alors sur l'élément.
                if ($label === '' || preg_match('/^[A-Z0-9_]+$/', $label)) {
                    $label = (string) ($p['element'] ?? $label);
                }

                $problems[] = [
                    'name'   => $label !== '' ? $label : '?',
                    'errors' => (int) ($p['errors'] ?? 0),
                ];
            }

            $result['db_schema'] = [
                'checked'  => (int) ($data['db_schema']['checked'] ?? 0),
                'problems' => $problems,
            ];
        }

        // Mises à jour automatiques du cœur (plugin client v0.3+, Joomla 5.4+).
        if (\is_array($data['auto_update'] ?? null)) {
            $au = $data['auto_update'];

            $mapped = [
                'supported' => (bool) ($au['supported'] ?? false),
                'enabled'   => (bool) ($au['enabled'] ?? false),
            ];

            // « healthy » n'est renvoyé que par le client v0.18+. On ne le fixe que
            // s'il est réellement présent : ainsi un client plus ancien (qui ne sait
            // pas calculer la santé) ne déclenche PAS de faux orange côté module.
            if (\array_key_exists('healthy', $au)) {
                $mapped['healthy'] = (bool) $au['healthy'];
            }

            $result['auto_update'] = $mapped;
        }

        // Fichiers .php suspects (plugin client v0.8+) : à la racine, tout .php
        // autre que index.php ; dans media/images/tmp, tout .php est anormal.
        if (\is_array($data['php_files'] ?? null) && !isset($data['php_files']['error'])) {
            $result['files_checked'] = true;

            foreach (array_keys($data['php_files']) as $path) {
                $isRoot = strpos($path, '/') === false;

                if ($isRoot) {
                    // À la racine, seuls index.php et configuration.php sont normaux.
                    if (!\in_array($path, ['index.php', 'configuration.php'], true)) {
                        $result['suspect_files'][] = $path;
                    }
                } else {
                    // Tout script remonté sous media/images/tmp/cache est suspect
                    // (le plugin a déjà écarté les fichiers de cache légitimes).
                    $result['suspect_files'][] = $path;
                }
            }
        }

        // Pièces maîtresses de sécurité (plugin client v0.10.4+) : configuration.php
        // (empreinte/date) et .htaccess (contenu dangereux hors bloc CG Secure).
        if (\is_array($data['security_files'] ?? null) && !isset($data['security_files']['error'])) {
            $sf = $data['security_files'];

            $result['htaccess_suspect'] = array_values((array) ($sf['htaccess_suspect'] ?? []));
            $result['htaccess_mode']    = $sf['htaccess_mode'] ?? null;

            // Durcissement Oculus (client v0.13.1+) : absent de la réponse d'un
            // client plus ancien → on reste sur null (« pas de communication »).
            if (\is_array($data['maintenance'] ?? null) && !isset($data['maintenance']['error'])) {
                $mt = $data['maintenance'];

                $result['tmp_files']   = (int) ($mt['tmp']['files'] ?? 0);
                $result['tmp_bytes']   = (int) ($mt['tmp']['bytes'] ?? 0);
                $result['cache_files'] = (int) ($mt['cache']['files'] ?? 0);
                $result['cache_bytes'] = (int) ($mt['cache']['bytes'] ?? 0);
            }

            if (\array_key_exists('htaccess_oculus', $sf)) {
                $result['harden_present'] = $sf['htaccess_oculus'] === null ? null : (bool) $sf['htaccess_oculus'];
                $result['harden_hash']    = $sf['htaccess_oculus_hash'] ?? null;
                $result['harden_verify']  = isset($sf['htaccess_verify']) ? (int) $sf['htaccess_verify'] : null;
                $result['server_soft']    = (string) ($sf['server_software'] ?? '');
            }
            $result['config_modified']  = $sf['config_modified'] ?? null;
            $result['config_mode']      = $sf['config_mode'] ?? null;

            // État .htaccess : absent / rouge (contenu dangereux) / orange
            // (permissions trop ouvertes) / vert (sain).
            if (empty($sf['htaccess_present'])) {
                $result['htaccess_state'] = 'absent';
            } elseif (!empty($result['htaccess_suspect'])) {
                $result['htaccess_state'] = 'red';
            } elseif ($result['htaccess_mode'] !== null && (octdec($result['htaccess_mode']) & 022)) {
                $result['htaccess_state'] = 'orange';
            } else {
                $result['htaccess_state'] = 'green';
            }

            // État configuration.php d'après ses permissions : vert = lecture seule,
            // orange = modifiable par le propriétaire, rouge = inscriptible par autrui.
            if ($result['config_mode'] !== null) {
                $m = (int) octdec($result['config_mode']);

                if ($m & 022) {
                    $result['config_state'] = 'red';
                } elseif ($m & 0200) {
                    $result['config_state'] = 'orange';
                } else {
                    $result['config_state'] = 'green';
                }
            }
        }

        // Dernière sauvegarde Akeeba (plugin client v0.6+).
        if (\is_array($data['backup'] ?? null) && !isset($data['backup']['error'])) {
            $last = $data['backup']['last_backup'] ?? null;
            $days = null;

            if ($last && ($ts = strtotime((string) $last)) !== false) {
                $days = (int) floor((time() - $ts) / 86400);
            }

            // Mise à jour Akeeba en attente ? (Akeeba est hors de la colonne
            // Extensions ; on rapatrie ici son eid + version cible pour rendre la
            // ligne Sauvegarde cliquable.)
            $akEid = 0;
            $akNew = null;

            foreach ((array) ($data['updates']['available'] ?? []) as $u) {
                if (!\is_array($u)) {
                    continue;
                }

                $uel = strtolower((string) ($u['element'] ?? ''));
                $unm = strtolower((string) ($u['name'] ?? ''));

                if (strpos($uel, 'akeeba') !== false || strpos($unm, 'akeeba') !== false) {
                    $akEid = (int) ($u['extension_id'] ?? 0);
                    $akNew = (string) ($u['new_version'] ?? '');

                    // Le paquet (pkg_akeebabackup) est l'entrée à mettre à jour.
                    if (strpos($uel, 'pkg_') === 0) {
                        break;
                    }
                }
            }

            $result['backup'] = [
                'installed'     => !empty($data['backup']['installed']),
                'last'          => $last,
                'days'          => $days,
                'edition'       => $data['backup']['edition'] ?? null,
                'version'       => $data['backup']['version'] ?? null,
                'update_eid'    => $akEid,
                'update_new'    => $akNew ?: null,
                'remote_ready'  => !empty($data['backup']['remote_ready']),
                'remote_reason' => (string) ($data['backup']['remote_reason'] ?? ''),
            ];
        }

        // Inventaire des extensions NON natives (tierces), avec état de mise à jour.
        if (\is_array($data['extensions'] ?? null) && !isset($data['extensions']['error'])) {
            // Correspondance extension_id -> nouvelle version disponible.
            $pending = [];

            foreach ((array) ($data['updates']['available'] ?? []) as $u) {
                if (\is_array($u) && !empty($u['extension_id'])) {
                    $pending[(int) $u['extension_id']] = (string) ($u['new_version'] ?? '');
                }
            }

            // Rang de « parenté » : pour un même produit, on garde le plus parent.
            $rank = ['package' => 0, 'component' => 1, 'template' => 2, 'plugin' => 3];

            // Nos propres agents : toujours affichés, même installés en plugin isolé
            // (sites où l'Agent n'est pas posé via le paquet), avec leur état de MàJ.
            // Nos agents Oculus + les extensions déclarées « à toujours afficher ».
            $ourAgents = array_merge(['sitemonitor', 'oculusgate', 'oculus'], $always);

            $groups = [];

            foreach ($data['extensions'] as $ext) {
                if (!\is_array($ext)) {
                    continue;
                }

                $type    = (string) ($ext['type'] ?? '');
                $element = (string) ($ext['element'] ?? '');
                $folder  = (string) ($ext['folder'] ?? '');
                $client  = (int) ($ext['client_id'] ?? 0);
                $rawName = trim((string) ($ext['name'] ?? ''));

                // Packs de langue : par type ET par nom (certains sont de type
                // « file »/« package » : « French (fr-FR) Language Pack for… »).
                if ($type === 'language' || preg_match('/language pack/i', $rawName)) {
                    continue;
                }

                // Cœur natif de Joomla.
                if (ExtensionHelper::checkIfCoreExtension($type, $element, $client, $folder)) {
                    continue;
                }

                $stem       = $this->extStem($element);
                $el         = strtolower($element);
                // Correspondance sur l'élément OU sur le radical (plg_system_iris → iris).
                $isOurAgent = \in_array($el, $ourAgents, true)
                    || \in_array($stem, $ourAgents, true)
                    || strpos($el, 'oculus') === 0;

                // RÈGLE DE CONFIANCE : si une mise à jour est EN ATTENTE pour cette
                // extension, on l'affiche TOUJOURS — même si elle serait normalement
                // masquée (plugin isolé, satellite…). Oculus ne cache jamais une MàJ.
                $eid       = (int) ($ext['id'] ?? 0);
                $hasUpdate = !empty($pending[$eid]);

                // Version de référence (MàJ manuelle, hors circuit Joomla) :
                // la version installée est-elle EN DESSOUS de la référence saisie ?
                $curVer      = (string) ($ext['version'] ?? '');
                $refTarget   = $reference[$el] ?? $reference[$stem] ?? ($reference[mb_strtolower($rawName)] ?? null);
                $refOutdated = $refTarget !== null && $curVer !== '' && version_compare($curVer, (string) $refTarget, '<');

                // Notre propre PAQUET est masqué en temps normal : on montre plutôt
                // le PLUGIN Oculus Client qu'il embarque, pour ne pas afficher deux
                // lignes qui disent la même chose.
                //
                // MAIS JAMAIS QUAND IL PORTE UNE MISE A JOUR. Ce masquage était
                // inconditionnel jusqu'au 27 aout 2026, et il enfreignait la regle
                // de confiance enoncee quinze lignes plus haut : Oculus ne cache
                // jamais une mise a jour. Consequence, les 21 sites du parc avaient
                // bien detecte le paquet 2.1.1, chacun le montrait dans son propre
                // gestionnaire d'extensions, et le tableau de bord n'affichait rien.
                // Une demi-journee perdue a chercher la panne partout ailleurs.
                //
                // Les deux identifiants sont traites : pkg_oculus_agent equipe le
                // parc, pkg_oculus_client quelques sites. Voir la note du manifeste.
                if (\in_array($el, ['pkg_oculus_agent', 'pkg_oculus_client'], true) && !$hasUpdate) {
                    continue;
                }

                // Sous-extension d'un paquet : masquée — SAUF nos agents, ou si elle
                // porte sa PROPRE mise à jour en attente.
                if (!$isOurAgent && !$hasUpdate && !$refOutdated && (int) ($ext['package_id'] ?? 0) > 0) {
                    continue;
                }

                // PRODUITS (composants/paquets/templates) + nos agents + TOUTE extension
                // ayant une MàJ en attente. Le reste (plugins/modules à jour, PRISM,
                // reCAPTCHA, satellites SP Page Builder…) est masqué.
                if (!$isOurAgent && !$hasUpdate && !$refOutdated && !\in_array($type, ['component', 'package', 'template'], true)) {
                    continue;
                }

                // Liste d'exclusion (réglages) : masque des produits résiduels
                // indésirables (ex. pkg_search publié par Joomla).
                if ($ignore !== []
                    && (\in_array(strtolower($element), $ignore, true)
                        || \in_array($stem, $ignore, true)
                        || \in_array(mb_strtolower($rawName), $ignore, true))) {
                    continue;
                }

                // Nom d'affichage : repli sur le radical si le nom est une clé de
                // langue non traduite ou un identifiant technique (com_/plg_/...).
                $label = $rawName;

                if ($label === ''
                    || preg_match('/^[A-Z0-9_]+$/', $label)
                    || preg_match('/^(com_|mod_|plg_|lib_|pkg_|tpl_)/i', $label)) {
                    $label = $stem;
                }

                // Retire le préfixe de GROUPE des plugins (« System - », « Content - »,
                // « CAPTCHA - »…) pour n'afficher que le nom du produit.
                $label = (string) preg_replace(
                    '/^(?:System|Content|User|Editor|Editors-XTD|CAPTCHA|Quick Icon|Button|Fields|Task|Behaviou?r|Two[\\s-]?Factor Authentication|Multi[\\s-]?factor Authentication|API Authentication|Authentication|Web Services|Installer|Privacy|Sample Data|Action ?Log|Console|Filesystem|Schema|Workflow|WebAuthn|Media Action|Finder|Extension)\\s*[-\x{2013}]\\s*/iu',
                    '',
                    $label
                );

                if ($label === '') {
                    $label = $stem;
                }

                // Akeeba : déjà affiché dans la colonne Sauvegarde.
                if (stripos($label, 'akeeba') !== false || stripos($element, 'akeeba') !== false) {
                    continue;
                }

                $id    = (int) ($ext['id'] ?? 0);
                $entry = [
                    'id'      => $id,
                    'name'    => $label,
                    'stem'    => $stem,
                    'version' => $ext['version'] ?? null,
                    'new'     => $pending[$id] ?? null,
                    'ref_new' => $refOutdated ? (string) $refTarget : null,
                    'enabled' => !empty($ext['enabled']),
                    'type'    => $type,
                ];

                // Regroupement par radical (composant + plugin autonome homonyme
                // fusionnés), en gardant l'entrée la plus parente.
                if (!isset($groups[$stem])) {
                    $groups[$stem] = $entry;
                    continue;
                }

                $cur  = $groups[$stem];
                $keep = (($rank[$type] ?? 5) < ($rank[$cur['type']] ?? 5)) ? $entry : $cur;

                // L'action de mise à jour doit cibler l'extension porteuse de la MàJ.
                if (empty($keep['new'])) {
                    if (!empty($entry['new'])) {
                        $keep['id'] = $entry['id'];
                    } elseif (!empty($cur['new'])) {
                        $keep['id'] = $cur['id'];
                    }
                }

                // Préférer un nom lisible plutôt qu'un simple radical.
                if ($keep['name'] === $stem) {
                    if ($cur['name'] !== $stem) {
                        $keep['name'] = $cur['name'];
                    } elseif ($entry['name'] !== $stem) {
                        $keep['name'] = $entry['name'];
                    }
                }

                $keep['new']     = $entry['new'] ?: $cur['new'];
                $keep['ref_new'] = ($entry['ref_new'] ?? null) ?: ($cur['ref_new'] ?? null);
                $keep['enabled'] = $entry['enabled'] || $cur['enabled'];
                $groups[$stem]   = $keep;
            }

            $extList = array_values($groups);

            // Tri par urgence : à mettre à jour (orange) d'abord, puis à jour
            // (vert), puis désactivées (gris) en dernier ; par nom à égalité.
            $urgency = static function (array $x): int {
                if (!empty($x['new']) || !empty($x['ref_new'])) {
                    return 0;
                }

                return empty($x['enabled']) ? 2 : 1;
            };

            usort($extList, static function ($a, $b) use ($urgency) {
                $ua = $urgency($a);
                $ub = $urgency($b);

                if ($ua !== $ub) {
                    return $ua - $ub;
                }

                return strcasecmp((string) $a['name'], (string) $b['name']);
            });

            $result['extensions_list'] = $extList;
        }

        // Extensions requises manquantes ou désactivées.
        if ($required !== [] && \is_array($data['extensions'] ?? null) && !isset($data['extensions']['error'])) {
            foreach ($required as $token) {
                $needle = mb_strtolower($token);
                $found  = false;

                foreach ($data['extensions'] as $ext) {
                    if (!\is_array($ext) || empty($ext['enabled'])) {
                        continue;
                    }

                    if (
                        str_contains(mb_strtolower((string) ($ext['element'] ?? '')), $needle)
                        || str_contains(mb_strtolower((string) ($ext['name'] ?? '')), $needle)
                    ) {
                        $found = true;
                        break;
                    }
                }

                if ($found) {
                    $result['present_required'][] = $token;
                } else {
                    $result['missing_required'][] = $token;
                }
            }
        }

        // Utilisateurs backend (plugin client v0.5+), repli sur les super users.
        $backendList = $data['backend_users'] ?? null;

        if (\is_array($backendList) && !isset($backendList['error'])) {
            $result['backend_users'] = \count($backendList);

            foreach ($backendList as $user) {
                if (\is_array($user) && isset($user['username'])) {
                    $groups = isset($user['groups']) && \is_array($user['groups']) ? ' (' . implode(', ', $user['groups']) . ')' : '';
                    $result['backend_names'][] = $user['username'] . $groups;

                    if (($user['mfa_enabled'] ?? null) === false) {
                        $result['backend_no_mfa'][] = $user['username'];
                    } elseif (($user['mfa_enabled'] ?? null) === true) {
                        $result['backend_mfa']++;
                    }
                }
            }
        }

        // Sépare la mise à jour du cœur Joomla des mises à jour d'extensions
        // (packs de langue installés inclus).
        $available = $data['updates']['available'] ?? null;

        if (\is_array($available)) {
            $names         = [];
            $joomlaCurrent = (string) ($data['core']['joomla_version'] ?? '');

            foreach ($available as $update) {
                $newVersion = (string) ($update['new_version'] ?? '');

                if (($update['element'] ?? '') === 'joomla' && ($update['type'] ?? '') === 'file') {
                    // Ignore les entrées périmées (version proposée <= version installée).
                    if ($newVersion !== '' && ($joomlaCurrent === '' || version_compare($newVersion, $joomlaCurrent, '>'))) {
                        $result['joomla_update'] = $newVersion;
                    }
                } else {
                    // Même garde-fou pour les extensions quand la version actuelle est connue.
                    $current = (string) ($update['current_version'] ?? '');

                    if ($current !== '' && $newVersion !== '' && version_compare($newVersion, $current, '<=')) {
                        continue;
                    }

                    $names[] = ($update['name'] ?? '?') . ' → ' . ($newVersion !== '' ? $newVersion : '?');
                }
            }

            $result['ext_updates']       = \count($names);
            $result['ext_updates_names'] = $names;
        } else {
            // Plugin plus ancien : on retombe sur le compteur global du résumé.
            $result['ext_updates'] = (int) ($result['summary']['updates_available'] ?? 0);
        }

        return $result;
    }
}
