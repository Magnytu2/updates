<?php

/**
 * Oculus — Module tableau de bord (administration).
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Extension\Service\Provider\HelperFactory;
use Joomla\CMS\Extension\Service\Provider\Module;
use Joomla\CMS\Extension\Service\Provider\ModuleDispatcherFactory;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->registerServiceProvider(new ModuleDispatcherFactory('\\Joomanji\\Module\\Oculus'));
        $container->registerServiceProvider(new HelperFactory('\\Joomanji\\Module\\Oculus\\Administrator\\Helper'));
        $container->registerServiceProvider(new Module());
    }
};
