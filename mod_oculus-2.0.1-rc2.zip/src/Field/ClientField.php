<?php

/**
 * Oculus — Champ « Client / catégorie » : liste déroulante alimentée
 * par le référentiel de catégories défini dans les paramètres du module.
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

namespace Joomanji\Module\Oculus\Administrator\Field;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\ListField;
use Joomla\CMS\HTML\HTMLHelper;

class ClientField extends ListField
{
    protected $type = 'Client';

    protected function getOptions()
    {
        $options = parent::getOptions();
        $titles  = [];

        try {
            // Identifiant du module en cours d'édition (com_modules).
            $moduleId = Factory::getApplication()->getInput()->getInt('id');

            if ($moduleId) {
                $db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);

                $raw = $db->setQuery(
                    $db->getQuery(true)
                        ->select($db->quoteName('params'))
                        ->from($db->quoteName('#__modules'))
                        ->where($db->quoteName('id') . ' = ' . (int) $moduleId)
                )->loadResult();

                $params = json_decode((string) $raw, true) ?: [];

                foreach ((array) ($params['categories'] ?? []) as $row) {
                    $row   = (array) $row;
                    $title = trim((string) ($row['title'] ?? ''));

                    if ($title !== '') {
                        $titles[$title] = true;
                    }
                }
            }

            // Si la valeur enregistrée n'est plus dans le référentiel
            // (ancienne saisie libre), on la garde pour ne pas la perdre.
            $current = trim((string) $this->value);

            if ($current !== '') {
                $titles[$current] = true;
            }
        } catch (\Throwable $e) {
            // Sans gravité : la liste restera limitée à l'option vide.
        }

        $titles = array_keys($titles);
        sort($titles, SORT_NATURAL | SORT_FLAG_CASE);

        foreach ($titles as $title) {
            $options[] = HTMLHelper::_('select.option', $title, $title);
        }

        return $options;
    }
}
