<?php

/**
 * Oculus — Champ token compact pour la liste des sites :
 * replié une fois rempli, déplié au focus pour lecture/collage.
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

namespace Joomanji\Module\Oculus\Administrator\Field;

\defined('_JEXEC') or die;

use Joomla\CMS\Form\Field\TextField;

class SitetokenField extends TextField
{
    protected $type = 'Sitetoken';

    protected function getInput()
    {
        static $cssDone = false;

        $this->class = trim((string) $this->class . ' oc-token');

        $html = parent::getInput();

        if (!$cssDone) {
            $cssDone = true;

            $html .= '<style>'
                . '.oc-token { width: 9rem; min-width: 9rem; font-family: monospace; transition: width .15s ease; }'
                . '.oc-token:focus { width: 27rem; }'
                . '</style>';
        }

        return $html;
    }
}
