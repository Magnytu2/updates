<?php

/**
 * Oculus — Champ « Geler » : interrupteur (switcher) identique au natif, mais qui
 * contraint la largeur de SA colonne dans le sous-formulaire des sites. Même
 * technique éprouvée que le champ token (SitetokenField) : on injecte un <style>
 * depuis getInput() — sortie NON filtrée par Joomla — avec un ciblage de la cellule
 * qui contient l'interrupteur. Sans cela le switcher remplit toute la cellule et la
 * colonne absorbe l'espace libre du tableau.
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

namespace Joomanji\Module\Oculus\Administrator\Field;

\defined('_JEXEC') or die;

use Joomla\CMS\Form\Field\RadioField;

class FrozenField extends RadioField
{
    protected $type = 'Frozen';

    protected function getInput()
    {
        static $cssDone = false;

        $html = parent::getInput();

        if (!$cssDone) {
            $cssDone = true;

            // La cellule qui contient une bascule « frozen » est ramenée à sa
            // largeur minimale ; l'espace libéré profite aux colonnes Nom/URL/Token.
            // Le nom « [frozen] » est propre à ce sous-formulaire : ciblage sûr.
            $html .= '<style>'
                . 'td:has([name*="[frozen]"]){width:1%!important;white-space:nowrap!important;text-align:center;}'
                . 'td:has([name*="[frozen]"]) fieldset,'
                . 'td:has([name*="[frozen]"]) .switcher{width:auto!important;min-width:0!important;}'
                . '</style>';
        }

        return $html;
    }
}
