<?php

/**
 * Oculus — Module tableau de bord (administration).
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

namespace Joomanji\Module\Oculus\Administrator\Dispatcher;

\defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Factory;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;
use Joomla\Database\DatabaseInterface;

final class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
    use HelperFactoryAwareTrait;

    protected function getLayoutData(): array
    {
        $data = parent::getLayoutData();

        $helper = $this->getHelperFactory()->getHelper('OculusHelper');

        $data['sites']      = $helper->getSitesStatus($data['params']);
        $data['ocUpdate']   = $helper->getLastUpdateResult();
        $data['ocAutoLoad'] = $helper->shouldAutoLoad();
        $data['ocSnapTime'] = $helper->getSnapshotTime();
        $data['ocAlert']    = $helper->getAlertPluginStatus();

        // Version réelle installée, lue dans le manifeste enregistré par Joomla
        // (évite toute version codée en dur qui se désynchronise à chaque MàJ).
        $data['ocVersion'] = $this->readInstalledVersion();

        return $data;
    }

    /**
     * Numéro de version du module tel qu'enregistré en base à l'installation.
     */
    private function readInstalledVersion(): string
    {
        try {
            $db    = Factory::getContainer()->get(DatabaseInterface::class);
            $cache = $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('manifest_cache'))
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('module'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('mod_oculus'))
            )->loadResult();

            $manifest = json_decode((string) $cache, true) ?: [];

            return (string) ($manifest['version'] ?? '');
        } catch (\Throwable $e) {
            return '';
        }
    }
}
