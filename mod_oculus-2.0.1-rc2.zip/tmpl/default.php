<?php

/**
 * Oculus — Module tableau de bord (administration).
 * Reprend fidèlement la présentation des listes natives de Joomla
 * (vue Utilisateurs / Articles) : barre de recherche, tri, icônes d'état.
 *
 * Variables disponibles : $module, $params, $sites (fournie par le Dispatcher).
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;

// Charge la feuille de style native des barres de recherche Joomla
// (searchtools) : chargée d'office sur les pages de listes, mais pas
// sur le tableau de bord — d'où cet appel explicite.
try {
    Factory::getApplication()->getDocument()->getWebAssetManager()->useStyle('searchtools');
} catch (\Throwable $e) {
    // Asset absent : sans gravité, la barre reste fonctionnelle.
}

$modId   = (int) $module->id;
$refresh = max(0, (int) $params->get('refresh', 60));
$columns = ['Site', 'Client', 'Joomla', 'PHP', 'BDD', 'Sauvegarde', 'Extensions', 'Nbrs', 'Users backend', 'Tâches', 'SSL'];

$clients = [];

foreach ((array) $sites as $siteRow) {
    $c = trim((string) ($siteRow['category'] ?? ''));

    if ($c !== '') {
        $clients[$c] = true;
    }
}

$clients = array_keys($clients);
sort($clients, SORT_NATURAL | SORT_FLAG_CASE);

$phpMin = trim((string) $params->get('php_secure_min', '8.2')) ?: '8.2';

/*
 * Score de danger par site, à partir de tous les signaux connus.
 * Les sites sont affichés du plus prioritaire au moins prioritaire, en TROIS
 * paliers (_tier) : 2 = alerte rouge, 1 = extensions non à jour, 0 = le reste.
 * Le score affine ensuite l'ordre à l'intérieur de chaque palier.
 */
$scored = [];

foreach ((array) $sites as $siteRow) {
    $score = 0;
    $why   = [];
    $sm    = $siteRow['summary'] ?? [];

    if (!$siteRow['ok']) {
        $score += 100;
        $why[]  = 'site injoignable ou en erreur';
    } else {
        $suspects = (array) ($siteRow['suspect_files'] ?? []);

        if ($suspects !== []) {
            $score += 100;
            $why[]  = \count($suspects) . ' fichier(s) PHP suspect(s) : ' . implode(', ', array_slice($suspects, 0, 5));
        }

        $bk = $siteRow['backup'] ?? null;

        if (\is_array($bk)) {
            if (!$bk['installed']) {
                $score += 25;
                $why[]  = 'pas d\'Akeeba Backup';
            } elseif ($bk['days'] === null) {
                $score += 50;
                $why[]  = 'aucune sauvegarde réussie';
            } elseif ($bk['days'] > 30) {
                $score += 40;
                $why[]  = 'sauvegarde vieille de ' . $bk['days'] . ' j';
            } elseif ($bk['days'] > 15) {
                $score += 15;
                $why[]  = 'sauvegarde vieille de ' . $bk['days'] . ' j';
            }
        }

        $pst = $siteRow['php_status'] ?? null;

        if (\is_array($pst) && $pst['status'] === 'eol') {
            $score += 40;
            $why[]  = 'PHP en fin de vie';
        } elseif (\is_array($pst) && $pst['status'] === 'soon') {
            $score += 10;
            $why[]  = 'PHP bientôt en fin de vie';
        }

        if (!empty($siteRow['joomla_update'])) {
            // Priorité forte : une MàJ du CŒUR Joomla prime sur les MàJ d'extensions.
            // Le score domine le palier « à mettre à jour » pour hisser ces sites en
            // tête, juste sous les alertes rouges.
            $score += 100;
            $why[]  = 'mise à jour Joomla en attente';
        }

        $missing = (array) ($siteRow['missing_required'] ?? []);

        if ($missing !== []) {
            $score += min(60, 30 * \count($missing));
            $why[]  = 'extension requise manquante : ' . implode(', ', $missing);
        }

        $eu = (int) ($siteRow['ext_updates'] ?? 0);

        if ($eu > 0) {
            $score += min(25, 5 * $eu);
            $why[]  = $eu . ' mise(s) à jour d\'extension en attente';
        }

        $ssl = $siteRow['ssl'] ?? null;

        if (\is_array($ssl)) {
            if ($ssl['days'] < 0) {
                $score += 60;
                $why[]  = 'certificat SSL expiré';
            } elseif ($ssl['days'] <= 14) {
                $score += 30;
                $why[]  = 'certificat SSL expire dans ' . $ssl['days'] . ' j';
            } elseif ($ssl['days'] <= 30) {
                $score += 10;
                $why[]  = 'certificat SSL expire dans ' . $ssl['days'] . ' j';
            }
        }

        $dst = $siteRow['db_status'] ?? null;

        if (\is_array($dst) && $dst['status'] === 'eol') {
            $score += 15;
            $why[]  = 'base de données en fin de vie';
        }

        $noMfa = \count((array) ($siteRow['backend_no_mfa'] ?? []));

        if ($noMfa > 0) {
            $score += min(20, 10 * $noMfa);
            $why[]  = $noMfa . ' compte(s) backend sans 2MFA';
        }

        $auto = $siteRow['auto_update'] ?? null;

        if (\is_array($auto) && $auto['supported'] && !$auto['enabled']) {
            $score += 10;
            $why[]  = 'mises à jour automatiques désactivées';
        }

        if (!empty($sm['offline'])) {
            $score += 5;
            $why[]  = 'site hors ligne (maintenance)';
        }
    }

    /*
     * PALIER D'AFFICHAGE.
     * 2 = au moins une alerte ROUGE (ce qui s'affiche en badge rouge dans le
     *     tableau : site injoignable, fichier suspect, .htaccess/configuration.php
     *     compromis, sauvegarde absente ou > 30 j, extension requise manquante,
     *     SSL expiré ou < 15 j, PHP en fin de vie, schéma BDD en erreur).
     * 1 = pas d'alerte rouge, mais des extensions non à jour.
     * 0 = rien de particulier.
     */
    $critical = !$siteRow['ok'];

    if (!$critical) {
        $bkR  = $siteRow['backup'] ?? null;
        $sslR = $siteRow['ssl'] ?? null;
        $phpV = (string) (($siteRow['summary']['php'] ?? '') ?: '');
        $pstR = \is_array($siteRow['php_status'] ?? null) ? $siteRow['php_status'] : ['status' => 'unknown'];

        $phpEolR = $pstR['status'] === 'eol'
            || ($pstR['status'] === 'unknown' && $phpV !== '' && version_compare($phpV, $phpMin, '<'));

        $critical =
            (array) ($siteRow['suspect_files'] ?? []) !== []
            || ($siteRow['htaccess_state'] ?? null) === 'red'
            || ($siteRow['config_state'] ?? null) === 'red'
            || (array) ($siteRow['missing_required'] ?? []) !== []
            || $phpEolR
            || !empty($siteRow['db_schema']['problems'])
            || (\is_array($bkR) && !empty($bkR['installed']) && ($bkR['days'] === null || $bkR['days'] > 30))
            || (\is_array($sslR) && $sslR['days'] !== null && $sslR['days'] <= 14);
    }

    // Extensions non à jour : mise à jour Joomla détectée, référence manuelle, ou
    // déduction parc — exactement ce qui apparaît en badge orange dans la colonne.
    $extOutdated = 0;

    foreach ((array) ($siteRow['extensions_list'] ?? []) as $eRow) {
        if (!empty($eRow['new']) || !empty($eRow['ref_new']) || !empty($eRow['parc_new'])) {
            $extOutdated++;
        }
    }

    // Une MàJ du cœur Joomla place aussi le site dans le palier « à mettre à jour »
    // (et son score élevé l'y met en tête).
    $hasJoomlaUpdate     = !empty($siteRow['joomla_update']);
    $siteRow['_tier']    = $critical ? 2 : (($extOutdated > 0 || $hasJoomlaUpdate) ? 1 : 0);
    $siteRow['_score']   = $score;
    $siteRow['_reasons'] = $why;
    $scored[]            = $siteRow;
}

// Palier d'abord (rouge > extensions à mettre à jour > reste), score ensuite.
usort($scored, static function ($a, $b) {
    return [$b['_tier'], $b['_score']] <=> [$a['_tier'], $a['_score']];
});

$sites = $scored;
$ocVersion = $ocVersion ?? '';

// Chargement différé : sur le rendu initial, le helper renvoie l'instantané en
// cache (ou rien) et demande au template d'interroger les sites en tâche de fond.
$ocAutoLoad = $ocAutoLoad ?? false;
$ocSnapTime = $ocSnapTime ?? null;

// Sites réellement configurés (indépendant de l'interrogation) : sert à distinguer
// « aucun site configuré » d'un simple « pas encore chargé ».
$ocConfigured   = (array) $params->get('sites', []);
$ocDeferEmpty   = (empty($sites) && $ocAutoLoad && $ocConfigured !== []);
$ocDisplayCount = $ocDeferEmpty ? \count($ocConfigured) : \count((array) $sites);

// Compteur GLOBAL de mises à jour automatisables (détectées par Joomla) sur tout
// le parc — pour le bouton « Mettre à jour (N) » de la barre d'outils.
$ocUpdatesTotal = 0;

foreach ((array) $sites as $sRow) {
    if (!empty($sRow['frozen'])) {
        continue; // site gelé : jamais dans le total du bouton global
    }

    foreach ((array) ($sRow['extensions_list'] ?? []) as $e) {
        if (!empty($e['new']) && (int) ($e['id'] ?? 0) > 0) {
            $ocUpdatesTotal++;
        }
    }
}

?>
<style>
    /* Pleine largeur sur le tableau de bord (grille CSS d'Atum ou colonnes) */
    .card-columns > .card:has(.mod-oculus),
    .card-columns > div:has(.mod-oculus) {
        grid-column: 1 / -1;
        column-span: all;
        width: 100%;
    }
    /* Même respiration à droite du sélecteur de tri qu'entre les champs */
    .mod-oculus .ordering-select {
        margin-inline-end: 8px;
    }
    .mod-oculus .mod-oculus-summary {
        display: flex;
        align-items: center;
        margin-inline-end: auto;
        padding-inline-start: 1rem;
    }
    /* Pastille de priorité devant le nom du site */
    .mod-oculus .oc-prio {
        display: inline-block;
        width: .75rem;
        height: .75rem;
        border-radius: 50%;
        margin-inline-end: .4rem;
        vertical-align: baseline;
    }
    .mod-oculus .oc-prio-high { background: #c52827; }
    .mod-oculus .oc-prio-mid  { background: #ffb514; }
    .mod-oculus .oc-prio-low  { background: #2f7d32; }
    /* Aligne la note de bas de tableau sur la colonne Site (padding des cellules) */
    .mod-oculus .oc-footnote {
        padding-inline-start: 1rem;
    }
    /* Palette d'alerte adoucie : fonds pastel + texte foncé lisible.
       On surcharge les classes Bootstrap uniquement dans le module, pour ne
       pas fatiguer l'œil quand un tableau comporte beaucoup d'alertes. */
    .mod-oculus .badge.bg-danger  { background-color: #f7d6d9 !important; color: #a11f28 !important; }
    .mod-oculus .badge.bg-warning { background-color: #f9dfa6 !important; color: #7c5200 !important; }
    .mod-oculus .badge.bg-success { background-color: #d3ead9 !important; color: #16643a !important; }
    /* Texte des badges d'alerte moins gras (500 au lieu du 700 Bootstrap) */
    .mod-oculus .badge { font-weight: 500; font-size: 12px; }
    /* Extensions requises : en ligne, avec passage à la ligne automatique */
    .mod-oculus .oc-ext-required { display: flex; flex-wrap: wrap; gap: .15rem .6rem; margin-top: .25rem; }
    .mod-oculus .oc-ext-cell { min-width: 340px; }
    /* Bouton « Tout mettre à jour » : teinte ambre, comme les badges de MàJ. */
    .mod-oculus .oc-ext-updateall {
        display: inline-flex; align-items: center; gap: .3em;
        padding: .12rem .5rem; font-size: .76rem; font-weight: 600; line-height: 1.2;
        border-radius: .25rem; border: 1px solid #d0a12e; background: #f6c445; color: #5a4300;
        width: max-content;
    }
    .mod-oculus .oc-ext-updateall:hover { background: #eab308; }
    .mod-oculus .oc-ext-updateall[disabled] { cursor: progress; opacity: .85; }
    /* Bouton « Mettre à jour » PAR SITE : gris, comme le badge d'effacement du cache. */
    .mod-oculus .oc-ext-updateall.oc-updateone {
        background: #e9ecef; border-color: #ced4da; color: #495057;
    }
    .mod-oculus .oc-ext-updateall.oc-updateone:hover { background: #dbe0e5; }
    .mod-oculus .oc-updone-ico { color: #6c757d; margin-left: .5rem; flex: 0 0 auto; }
    .mod-oculus .oc-frozen-flake { color: #2b7bbd; margin-left: 5px; cursor: help; }
    .mod-oculus .oc-frozen-note { margin-left: .6rem; }
    .mod-oculus .oc-autoupd { margin-top: 3px; font-size: .78rem; line-height: 1.1; cursor: help; }
    .mod-oculus .oc-autoupd-off { color: #b26a00; }
    /* Boutons de la barre d'outils : 4 coins arrondis même à l'intérieur d'un btn-group. */
    .mod-oculus .oc-toolbar-btn { border-radius: .25rem !important; }
    /* Animation rayée pendant une mise à jour (par site ET parc). */
    .mod-oculus .oc-ext-updateall.oc-batch-running,
    .mod-oculus .oc-updateall-park.oc-batch-running {
        cursor: progress;
        background-image: linear-gradient(45deg, rgba(0, 0, 0, .12) 25%, transparent 25%, transparent 50%, rgba(0, 0, 0, .12) 50%, rgba(0, 0, 0, .12) 75%, transparent 75%, transparent);
        background-size: .8rem .8rem;
        animation: oc-stripes .8s linear infinite;
    }
    .oc-batch-list { margin: .3rem 0 0; padding-left: 1.1rem; max-height: 50vh; overflow: auto; }
    .oc-batch-list li { margin: .18rem 0; }
    .oc-batch-list li.oc-ko { color: #b02a37; }
    .mod-oculus .oc-ext-badges { display: flex; flex-wrap: wrap; gap: 3px 4px; align-items: flex-start; }
    .mod-oculus .oc-ext-badges.oc-collapsed { max-height: 3.5em; overflow: hidden; }
    .mod-oculus .oc-ext-badges .badge { font-weight: 500; }
    .mod-oculus .oc-ext-off { background-color: #ececec; color: #8a8a8a; }
    .mod-oculus .oc-ext-toggle { margin-top: .3rem; border: 0; background: none; color: #185fa5; font-size: 12px; cursor: pointer; padding: 0; }
    .mod-oculus .oc-ext-toggle:hover { text-decoration: underline; }
    /* Police harmonisée sur la taille des badges pour tout le tableau. */
    .mod-oculus table.table { font-size: 12px; }
    .mod-oculus table.table th, .mod-oculus table.table td { font-size: 12px; }
    /* Colonne Site : largeur minimale pour ne plus casser les noms. */
    .mod-oculus table.table th:first-child { min-width: 155px; }
    /* Colonne Client resserrée (-30%) : l'espace libéré profite à la colonne Joomla,
       qui porte désormais version, durcissement et fichiers sensibles. */
    .mod-oculus table.table th:nth-child(2),
    .mod-oculus table.table td:nth-child(2) { width: 110px; max-width: 110px; }
    /* Icône d'alerte accolée hors du badge d'extension. */
    .mod-oculus .oc-ext-item { display: inline-flex; align-items: center; gap: 2px; }
    .mod-oculus .oc-ext-update { cursor: pointer; }
    .mod-oculus .oc-ext-update:hover .badge { outline: 1px solid #7c5200; }
    .mod-oculus .oc-ext-updating { cursor: progress; }
    .mod-oculus .oc-ext-updating .badge {
        background-image: linear-gradient(45deg, rgba(255,255,255,.5) 25%, transparent 25%, transparent 50%, rgba(255,255,255,.5) 50%, rgba(255,255,255,.5) 75%, transparent 75%, transparent);
        background-size: .8rem .8rem;
        animation: oc-stripes .8s linear infinite;
    }
    @keyframes oc-stripes { from { background-position: .8rem 0; } to { background-position: 0 0; } }
    /* Même respiration qu'entre .htaccess et configuration.php (gap de 10px). */
    .mod-oculus .oc-harden-badge { margin-left: 10px; }
    .mod-oculus .oc-clean-badge { cursor: pointer; }
    .mod-oculus .oc-clean-badge:hover .badge { filter: brightness(.94); }
    .mod-oculus .oc-clean-ico { width: .85em; height: .85em; vertical-align: -1px; margin-right: 2px; color: #6c757d; }
    /* État sain : icône et libellé en vert, comme les autres indicateurs « OK ». */
    .mod-oculus .oc-clean-ok .oc-clean-ico { color: #16643a; }
    /* Cache : gris neutre, volontairement non alarmant. */
    .mod-oculus .badge.oc-badge-muted { background-color: #e9ecef !important; color: #495057 !important; }
    .mod-oculus .oc-harden-ico { width: .9em; height: .9em; vertical-align: -1px; margin-right: 2px; flex: 0 0 auto; }
    .mod-oculus .oc-harden-badge[data-oc-harden] { cursor: pointer; }
    .mod-oculus .oc-harden-badge[data-oc-harden]:hover .badge { filter: brightness(.94); }
    .mod-oculus .oc-alert-status { display: inline-flex; align-items: center; gap: .35em; white-space: nowrap; }
    .mod-oculus .oc-alert-dot { width: .6rem; height: .6rem; border-radius: 50%; display: inline-block; flex: 0 0 auto; }
    /* Icône à l'extérieur, à gauche du bouton (comme le bouclier de sauvegarde). */
    .mod-oculus .oc-refresh-line { display: inline-flex; align-items: center; gap: .35em; }
    .mod-oculus .oc-refresh-ico { color: #6c757d; flex: 0 0 auto; }
    .mod-oculus .oc-refresh-one {
        padding: .12rem .45rem;
        font-size: .74rem;
        line-height: 1.2;
        border-radius: .25rem;
    }
    .mod-oculus .oc-refresh-one.oc-one-running {
        cursor: progress;
        background-image: linear-gradient(45deg, rgba(0,0,0,.10) 25%, transparent 25%, transparent 50%, rgba(0,0,0,.10) 50%, rgba(0,0,0,.10) 75%, transparent 75%, transparent);
        background-size: .7rem .7rem;
        animation: oc-stripes .8s linear infinite;
    }
    .mod-oculus .oc-backup-line { display: inline-flex; align-items: center; gap: .45em; }
    .mod-oculus .oc-backup-ico { width: .95em; height: .95em; flex: 0 0 auto; color: #6c757d; }
    .mod-oculus .oc-backup-ico.oc-ico-ok { color: #16643a; } /* prêt : vert (harmonisé badges) */
    .mod-oculus .oc-backup-ico.oc-ico-ko { color: #b02a37; } /* non connecté : rouge */
    .mod-oculus .oc-backup-btn {
        padding: .18rem .5rem;
        font-size: .78rem;
        font-weight: 500;
        line-height: 1.25;
        border-radius: .25rem;
        width: max-content;
    }
    /* Vert « à jour » harmonisé avec les badges d'extensions (bg-success). */
    .mod-oculus .oc-backup-btn.oc-backup-recent {
        background-color: #d3ead9;
        border-color: #b5d8c0;
        color: #16643a;
    }
    .mod-oculus .oc-backup-btn.oc-backup-recent:hover {
        background-color: #c4e1cc;
        border-color: #a5cfb2;
        color: #16643a;
    }
    .mod-oculus .oc-backup-btn.oc-backup-running {
        cursor: progress;
        background-image: linear-gradient(45deg, rgba(255, 255, 255, .35) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .35) 50%, rgba(255, 255, 255, .35) 75%, transparent 75%, transparent);
        background-size: .8rem .8rem;
        animation: oc-stripes .8s linear infinite;
    }
    .oc-modal-back { position: fixed; inset: 0; background: rgba(0,0,0,.45); display: flex; align-items: center; justify-content: center; z-index: 10500; }
    .oc-modal { background: #fff; border-radius: 10px; max-width: 540px; width: 90%; box-shadow: 0 12px 45px rgba(0,0,0,.35); overflow: hidden; }
    .oc-modal-head { padding: .9rem 1.25rem; font-weight: 600; font-size: 15px; }
    .oc-modal-head.oc-ok { background: #d3ead9; color: #16643a; }
    .oc-modal-head.oc-ko { background: #f7d6d9; color: #a11f28; }
    .oc-modal-body { padding: 1rem 1.25rem; font-size: 13px; line-height: 1.5; }
    .oc-modal-body .oc-detail { color: #555; word-break: break-word; }
    .oc-modal-foot { padding: .75rem 1.25rem; text-align: right; border-top: 1px solid #eee; }
    /* Icône de statut colorée : rouge = hors ligne / injoignable, vert = en ligne */
    .mod-oculus .oc-status-down { color: #c52827; }
    .mod-oculus .oc-status-up   { color: #2f7d32; }
    /* État maintenance : ambre — distinct du rouge « injoignable » */
    .mod-oculus .oc-status-maint { color: #b26a00; }
    .mod-oculus .oc-state-mini { font-size: 12px; margin-inline-start: 5px; vertical-align: baseline; }
    .mod-oculus .oc-joomla-cell { min-width: 330px; }
    .mod-oculus .oc-secfiles { display: flex; flex-wrap: wrap; gap: 2px 10px; align-items: center; }
</style>
<div class="mod-oculus" id="mod-oculus-wrap-<?php echo $modId; ?>">
<?php if (empty($sites) && !$ocDeferEmpty) : ?>
    <div class="alert alert-info mb-0">
        <span class="icon-info-circle" aria-hidden="true"></span>
        Aucun site configuré. Modifiez ce module et ajoutez vos sites
        (nom, URL, token) dans l'onglet <strong>Module</strong>.
    </div>
<?php else : ?>
    <div class="js-stools" role="search">
        <div class="mod-oculus-summary">
            <span class="fw-bold fs-5 me-1"><?php echo (int) $ocDisplayCount; ?></span>sites surveillés
            <span class="text-muted ms-2 small">Oculus v<?php echo htmlspecialchars($ocVersion, ENT_QUOTES, 'UTF-8'); ?></span>
            <?php
            /*
             * Pastille « Oculus Alerte » : plugin de tâche qui envoie les mails.
             * Vert = installé ET publié (les alertes partent). Rouge = installé mais
             * DÉPUBLIÉ (aucun mail ne partira — silence dangereux). Gris = absent.
             */
            $ocAlert = \is_array($ocAlert ?? null) ? $ocAlert : ['found' => false, 'enabled' => false, 'version' => ''];

            if (!$ocAlert['found']) {
                $alDot = '#6c757d'; $alTip = 'Oculus Alerte non installé : aucune alerte par mail ne sera envoyée.';
                $alTxt = 'Oculus Alerte : absent';
            } elseif ($ocAlert['enabled']) {
                $alDot = '#1a7f45'; $alTip = 'Oculus Alerte installé et publié : la surveillance par mail est active.';
                $alTxt = 'Oculus Alerte v' . $ocAlert['version'];
            } else {
                $alDot = '#b02a37'; $alTip = 'Oculus Alerte est DÉPUBLIÉ : aucune alerte par mail ne partira. À publier dans Système → Plugins.';
                $alTxt = 'Oculus Alerte v' . $ocAlert['version'] . ' — DÉPUBLIÉ';
            }
            ?>
            <span class="text-muted ms-3 small oc-alert-status" title="<?php echo htmlspecialchars($alTip, ENT_QUOTES, 'UTF-8'); ?>">
                <span class="oc-alert-dot" style="background:<?php echo $alDot; ?>"></span>
                <?php echo htmlspecialchars($alTxt, ENT_QUOTES, 'UTF-8'); ?>
            </span>
            <?php if ($ocAutoLoad) : ?>
                <span class="text-muted ms-2 small oc-refreshing">
                    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    actualisation…
                </span>
            <?php endif; ?>
        </div>
        <div class="js-stools-container-bar">
            <div class="btn-toolbar">
                <div class="filter-search-bar btn-group">
                    <div class="input-group">
                        <input type="text" id="mod-oculus-search-<?php echo $modId; ?>"
                               class="form-control" placeholder="Rechercher"
                               aria-label="Rechercher un site">
                        <button type="button" class="filter-search-bar__button btn btn-primary"
                                aria-label="Rechercher">
                            <span class="filter-search-bar__button-icon icon-search" aria-hidden="true"></span>
                        </button>
                    </div>
                </div>
                <div class="filter-search-actions btn-group">
                    <button type="button" id="mod-oculus-clear-<?php echo $modId; ?>"
                            class="filter-search-actions__button btn btn-primary js-stools-btn-clear">
                        Effacer
                    </button>
                </div>
                <div class="filter-search-actions btn-group ms-2">
                    <button type="button" id="mod-oculus-refresh-<?php echo $modId; ?>"
                            class="btn btn-outline-primary oc-toolbar-btn"
                            title="Forcer la vérification des mises à jour sur tous les sites (peut prendre un moment)">
                        <span class="icon-refresh" aria-hidden="true"></span> Actualiser
                    </button>
                    <button type="button" id="mod-oculus-updatepark-<?php echo $modId; ?>"
                            class="btn btn-outline-primary oc-updateall-park oc-toolbar-btn ms-2"
                            data-oc-park="1"
                            style="<?php echo $ocUpdatesTotal >= 1 ? '' : 'display:none'; ?>"
                            title="Mettre à jour, site par site puis une par une, TOUTES les extensions détectées par Joomla sur l'ensemble du parc. Idéal pour propager une nouvelle version de nos plugins. Les mises à jour manuelles (man./parc) ne sont pas concernées.">
                        <span class="icon-cog" aria-hidden="true"></span> Mettre à jour (<span class="oc-park-count"><?php echo (int) $ocUpdatesTotal; ?></span>)
                    </button>
                </div>
                <div class="ordering-select">
                    <?php if ($clients !== []) : ?>
                        <div class="js-stools-field-list">
                            <span class="visually-hidden">Filtrer par client</span>
                            <select id="mod-oculus-client-<?php echo $modId; ?>" class="form-select">
                                <option value="">- Tous les clients -</option>
                                <?php foreach ($clients as $client) : ?>
                                    <option value="<?php echo htmlspecialchars($client, ENT_QUOTES, 'UTF-8'); ?>">
                                        <?php echo htmlspecialchars($client, ENT_QUOTES, 'UTF-8'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>
                    <div class="js-stools-field-list">
                        <span class="visually-hidden">Tri</span>
                        <select id="mod-oculus-sort-<?php echo $modId; ?>" class="form-select">
                            <option value="">Tri - Par défaut</option>
                            <?php foreach ($columns as $ci => $label) : ?>
                                <option value="<?php echo $ci; ?>:1"><?php echo htmlspecialchars($label, ENT_QUOTES, 'UTF-8'); ?> - Ascendant</option>
                                <option value="<?php echo $ci; ?>:-1"><?php echo htmlspecialchars($label, ENT_QUOTES, 'UTF-8'); ?> - Descendant</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="mod-oculus-zone-<?php echo $modId; ?>">
        <?php if (\is_array($ocUpdate ?? null)) : ?>
            <div id="mod-oculus-result-<?php echo $modId; ?>" hidden
                 data-ok="<?php echo !empty($ocUpdate['ok']) ? '1' : '0'; ?>"
                 data-site="<?php echo htmlspecialchars((string) ($ocUpdate['site'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"
                 data-msg="<?php echo htmlspecialchars((string) ($ocUpdate['message'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
        <?php endif; ?>
        <?php if ($ocDeferEmpty) : ?>
            <div class="alert alert-info mb-0 oc-loading">
                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                Interrogation des sites en cours… le tableau s'affichera dans quelques secondes.
            </div>
        <?php else : ?>
        <table class="table" id="mod-oculus-list-<?php echo $modId; ?>">
            <caption class="visually-hidden">Sites surveillés par Oculus</caption>
            <thead>
                <tr>
                    <th scope="col">
                        <a href="#" class="js-stools-column-order" data-col="0">
                            <span>Site</span><span class="ms-1 icon-sort" aria-hidden="true"></span>
                        </a>
                    </th>
                    <th scope="col" class="w-10">
                        <a href="#" class="js-stools-column-order" data-col="1">
                            <span>Client</span><span class="ms-1 icon-sort" aria-hidden="true"></span>
                        </a>
                    </th>
                    <th scope="col" class="w-10">
                        <a href="#" class="js-stools-column-order" data-col="2">
                            <span>Joomla</span><span class="ms-1 icon-sort" aria-hidden="true"></span>
                        </a>
                    </th>
                    <th scope="col" class="w-8 d-none d-md-table-cell">
                        <a href="#" class="js-stools-column-order" data-col="3">
                            <span>PHP</span><span class="ms-1 icon-sort" aria-hidden="true"></span>
                        </a>
                    </th>
                    <th scope="col" class="w-8 d-none d-lg-table-cell">
                        <a href="#" class="js-stools-column-order" data-col="4">
                            <span>BDD</span><span class="ms-1 icon-sort" aria-hidden="true"></span>
                        </a>
                    </th>
                    <th scope="col" class="w-8">
                        <a href="#" class="js-stools-column-order" data-col="5">
                            <span>Sauvegarde</span><span class="ms-1 icon-sort" aria-hidden="true"></span>
                        </a>
                    </th>
                    <th scope="col" class="w-10">
                        <a href="#" class="js-stools-column-order" data-col="6">
                            <span>Extensions</span><span class="ms-1 icon-sort" aria-hidden="true"></span>
                        </a>
                    </th>
                    <th scope="col" class="w-8 d-none d-lg-table-cell">
                        <a href="#" class="js-stools-column-order" data-col="7">
                            <span>Nbrs</span><span class="ms-1 icon-sort" aria-hidden="true"></span>
                        </a>
                    </th>
                    <th scope="col" class="w-8">
                        <a href="#" class="js-stools-column-order" data-col="8">
                            <span>Users</span><span class="ms-1 icon-sort" aria-hidden="true"></span>
                        </a>
                        <small class="text-muted d-block">Backend</small>
                    </th>
                    <th scope="col" class="w-5 d-none d-md-table-cell">
                        <a href="#" class="js-stools-column-order" data-col="9">
                            <span>Tâches</span><span class="ms-1 icon-sort" aria-hidden="true"></span>
                        </a>
                    </th>
                    <th scope="col" class="w-5">
                        <a href="#" class="js-stools-column-order" data-col="10">
                            <span>SSL</span><span class="ms-1 icon-sort" aria-hidden="true"></span>
                        </a>
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($sites as $i => $site) : ?>
                    <?php
                    $s        = $site['summary'] ?? [];
                    $client   = htmlspecialchars(trim((string) ($site['category'] ?? '')), ENT_QUOTES, 'UTF-8');
                    $name     = htmlspecialchars($site['name'], ENT_QUOTES, 'UTF-8');
                    $url      = htmlspecialchars($site['url'], ENT_QUOTES, 'UTF-8');
                    $adminUrl = htmlspecialchars(rtrim($site['url'], '/') . '/administrator', ENT_QUOTES, 'UTF-8');

                    // Site GELÉ : aucune mise à jour à distance (ni individuelle, ni globale).
                    $frozen = !empty($site['frozen']);

                    // Nombre de MàJ automatisables de CE site (badges Joomla cliquables).
                    $extListRow = \is_array($site['extensions_list'] ?? null) ? $site['extensions_list'] : [];
                    $extAuto    = 0;
                    foreach ($extListRow as $eTmp) {
                        if (!empty($eTmp['new']) && (int) ($eTmp['id'] ?? 0) > 0) {
                            $extAuto++;
                        }
                    }

                    if (!$site['ok']) {
                        $stIcon = !empty($site['maintenance'])
                            ? '<span class="icon-wrench oc-state-mini oc-status-maint" title="En maintenance"></span>'
                            : '<span class="icon-unpublish oc-state-mini oc-status-down" title="Injoignable / erreur"></span>';
                    } elseif (!empty($s['offline'])) {
                        $stIcon = '<span class="icon-expired oc-state-mini oc-status-maint" title="Hors ligne (maintenance)"></span>';
                    } else {
                        $stIcon = '<span class="icon-publish oc-state-mini oc-status-up" title="En ligne"></span>';
                    }
                    ?>
                    <tr class="row<?php echo $i % 2; ?>" data-client="<?php echo $client; ?>" data-oc-site="<?php echo (int) ($site['_idx'] ?? $i); ?>"<?php echo $frozen ? ' data-oc-frozen="1"' : ''; ?>>
                        <th scope="row" data-sort="<?php echo $name; ?>">
                            <?php
                            $prioClass = $site['_score'] >= 60 ? 'oc-prio-high' : ($site['_score'] >= 25 ? 'oc-prio-mid' : 'oc-prio-low');
                            $prioTitle = 'Priorité ' . (int) $site['_score'] . ' — '
                                . ($site['_reasons'] !== [] ? implode(' ; ', $site['_reasons']) : 'rien à signaler');
                            ?>
                            <div class="name break-word">
                                <span class="oc-prio <?php echo $prioClass; ?>"
                                      title="<?php echo htmlspecialchars($prioTitle, ENT_QUOTES, 'UTF-8'); ?>"></span><a
                                    href="<?php echo $adminUrl; ?>" target="_blank" rel="noopener noreferrer"
                                    title="Ouvrir l'administration de <?php echo $name; ?> (nouvel onglet)">
                                    <?php echo $name; ?>
                                </a><?php echo $stIcon; ?><?php if ($frozen) : ?><span class="oc-frozen-flake" title="Site gelé : aucune mise à jour à distance (individuelle ou globale). La surveillance reste active.">❄</span><?php endif; ?>
                            </div>
                            <div class="small break-word">
                                <a href="<?php echo $url; ?>" target="_blank" rel="noopener noreferrer"
                                   class="text-muted" title="Ouvrir le site (nouvel onglet)">
                                    <?php echo $url; ?>
                                </a>
                            </div>
                            <span class="oc-refresh-line mt-1">
                                <span class="icon-refresh oc-refresh-ico" aria-hidden="true"></span>
                                <button type="button" class="btn btn-outline-primary oc-refresh-one"
                                        data-oc-one="1"
                                        title="Ré-interroger uniquement ce site (les autres ne sont pas recontactés)">Actualiser</button>
                                <?php if ($extAuto >= 1 && !$frozen) : ?>
                                    <span class="icon-cog oc-updone-ico" aria-hidden="true"></span>
                                    <button type="button" class="oc-ext-updateall oc-updateone" data-oc-updateall="1"
                                            title="Mettre à jour, une par une, les <?php echo $extAuto; ?> extension(s) détectée(s) par Joomla sur ce site. Les MàJ manuelles (man./parc) ne sont pas concernées.">Mettre à jour (<?php echo $extAuto; ?>)</button>
                                <?php elseif ($extAuto >= 1 && $frozen) : ?>
                                    <span class="oc-frozen-note small text-muted" title="Site gelé : mises à jour à distance désactivées.">❄ gelé</span>
                                <?php endif; ?>
                            </span>
                        </th>
                        <td data-sort="<?php echo $client; ?>">
                            <?php echo $client !== '' ? $client : '–'; ?>
                        </td>
                        <?php if (!$site['ok']) : ?>
                            <?php if (!empty($site['maintenance'])) : ?>
                            <td colspan="8" data-sort="1">
                                <span class="tbody-icon">
                                    <span class="icon-wrench oc-status-maint" aria-hidden="true" title="Site en maintenance (hors ligne)"></span>
                                </span>
                                <span class="oc-status-maint fw-bold">En maintenance</span>
                                <small class="text-muted d-block oc-footnote">
                                    Site volontairement hors ligne — supervision complète indisponible tant qu'il est en maintenance.
                                </small>
                            </td>
                            <?php else : ?>
                            <td colspan="8" data-sort="2">
                                <span class="tbody-icon">
                                    <span class="icon-unpublish oc-status-down" aria-hidden="true" title="Injoignable / erreur"></span>
                                </span>
                                <span class="text-danger">Injoignable / erreur</span>
                                <small class="text-muted d-block oc-footnote">
                                    <?php echo htmlspecialchars((string) $site['error'], ENT_QUOTES, 'UTF-8'); ?>
                                </small>
                            </td>
                            <?php endif; ?>
                        <?php else : ?>
                            <?php
                            $joomla = htmlspecialchars((string) ($s['joomla'] ?? '?'), ENT_QUOTES, 'UTF-8');
                            /*
                             * Auto-MàJ « à problème » : la fonction existe (Joomla 5.4+) MAIS
                             * elle n'est pas active (désactivée, ou incapable de s'exécuter :
                             * Download ID manquant, droits d'écriture…). C'est ce que Joomla
                             * signale par « Mise à jour auto. indisponible ».
                             * Sur Joomla 3/4 (non pris en charge) la notion n'existe pas : on
                             * n'affiche RIEN — ce serait du bruit inutile.
                             */
                            $au = $site['auto_update'] ?? null;
                            // On ne signale que si le client SAIT calculer la santé
                            // (clé « healthy » présente, client v0.18+) : sinon un
                            // client plus ancien ferait passer tous les sites en orange.
                            $auProblem = \is_array($au)
                                && !empty($au['supported'])
                                && \array_key_exists('healthy', $au)
                                && empty($au['healthy']);
                            ?>
                            <td class="oc-joomla-cell" data-sort="<?php echo $joomla; ?>">
                                <?php if (!empty($site['joomla_update'])) : ?>
                                    <span class="oc-status-maint" aria-hidden="true"
                                          title="Mise à jour Joomla disponible — non installée">⚠</span>
                                    <span class="badge bg-warning text-dark">
                                        <?php echo $joomla; ?> → <?php echo htmlspecialchars((string) $site['joomla_update'], ENT_QUOTES, 'UTF-8'); ?>
                                    </span>
                                <?php elseif ($auProblem) : ?>
                                    <?php $auTip = 'Cœur à jour, mais la MISE À JOUR AUTOMATIQUE de Joomla est inactive (« Mise à jour auto. indisponible ») : fonction prise en charge (5.4+) mais non saine — désactivée, site non enregistré (token manquant) ou vérification trop ancienne. Le cœur devra être mis à jour manuellement.'; ?>
                                    <span class="oc-status-maint" aria-hidden="true" title="<?php echo htmlspecialchars($auTip, ENT_QUOTES, 'UTF-8'); ?>">⚠</span>
                                    <span class="badge bg-warning text-dark" title="<?php echo htmlspecialchars($auTip, ENT_QUOTES, 'UTF-8'); ?>" style="cursor:help"><?php echo $joomla; ?></span>
                                <?php else : ?>
                                    <span class="oc-status-up" aria-hidden="true" title="Joomla à jour">✓</span>
                                    <span class="badge bg-success"><?php echo $joomla; ?></span>
                                <?php endif; ?>
                                <?php
                                /*
                                 * Durcissement .htaccess — badge d'état à droite de la version.
                                 * Rouge  : non appliqué (ou différent du bloc configuré) → CLIQUABLE
                                 * Orange : aucune information remontée (client trop ancien)
                                 * Vert   : appliqué et conforme
                                 */
                                $hbCfg = trim(str_replace("\r\n", "\n", (string) $params->get('htaccess_block', '')));

                                if ($hbCfg !== '') {
                                    $hbPresent = $site['harden_present'] ?? null;
                                    $hbSame    = ((string) ($site['harden_hash'] ?? '')) === md5($hbCfg);
                                    $hbVerify  = $site['harden_verify'] ?? null;
                                    $hbServer  = trim((string) ($site['server_soft'] ?? ''));

                                    if ($hbPresent === null) {
                                        $hbCls   = 'bg-warning text-dark';
                                        $hbIco   = '#b26a00';
                                        $hbClick = false;
                                        $hbTip   = 'Durcissement .htaccess : aucune information remontée par ce site (plugin client antérieur à 0.13.1).';
                                    } elseif ($hbPresent && $hbSame && $hbVerify !== null && !\in_array($hbVerify, [403, 404], true)) {
                                        // Règle écrite mais IGNORÉE par le serveur : le pire cas,
                                        // car il donne l'illusion d'être protégé.
                                        $hbCls   = 'bg-danger';
                                        $hbIco   = '#b02a37';
                                        $hbClick = true;
                                        $hbTip   = 'Bloc écrit mais SANS EFFET : le serveur n\'applique pas la règle (test réel : HTTP '
                                            . (int) $hbVerify . ' au lieu de 403)'
                                            . ($hbServer !== '' ? ' — serveur : ' . $hbServer : '')
                                            . '. Les .htaccess sont probablement ignorés sur cet hébergement.';
                                    } elseif ($hbPresent && $hbSame && $hbVerify === null) {
                                        $hbCls   = 'bg-warning text-dark';
                                        $hbIco   = '#b26a00';
                                        $hbClick = true;
                                        $hbTip   = 'Bloc appliqué mais jamais testé réellement — cliquer pour réappliquer et vérifier.';
                                    } elseif ($hbPresent && $hbSame) {
                                        $hbCls   = 'bg-success';
                                        $hbIco   = '#16643a';
                                        $hbClick = false;
                                        $hbTip   = 'Oculus Bouclier appliqué et VÉRIFIÉ : un script PHP déposé dans images/ est bien bloqué (HTTP '
                                            . (int) $hbVerify . ')'
                                            . ($hbServer !== '' ? ' — serveur : ' . $hbServer : '') . '.';
                                    } else {
                                        $hbCls   = 'bg-danger';
                                        $hbIco   = '#b02a37';
                                        $hbClick = true;
                                        $hbTip   = $hbPresent
                                            ? 'Bloc .htaccess présent mais DIFFÉRENT du bloc configuré — cliquer pour le mettre à jour (sauvegarde et restauration automatiques).'
                                            : 'Durcissement .htaccess non appliqué — cliquer pour l\'appliquer (sauvegarde et restauration automatiques).';
                                    }

                                    echo '<span class="oc-ext-item oc-harden-badge"'
                                        . ($hbClick ? ' data-oc-harden="1" role="button" tabindex="0"' : '')
                                        . ' title="' . htmlspecialchars($hbTip, ENT_QUOTES, 'UTF-8') . '">'
                                        . '<svg class="oc-harden-ico" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"'
                                        . ' style="color:' . $hbIco . '">'
                                        . '<path d="M12 1 3 5v6c0 5 3.8 9.7 9 11 5.2-1.3 9-6 9-11V5l-9-4Zm0 10.9h7c-.5 3.6-2.9 6.9-7 8.2V12H5V6.3l7-3.1v8.7Z"/></svg>'
                                        // « Oculus Bouclier » : nom de la fonction dans la famille Oculus
                                        // (Monitor, Client, Gate, Bouclier). Évite aussi la collision avec
                                        // l'indicateur .htaccess de la ligne du dessous, qui porte lui sur
                                        // la santé du FICHIER et non sur l'état de protection.
                                        . '<span class="badge ' . $hbCls . '">Oculus Bouclier</span></span>';
                                }
                                ?>
                                <?php
                                /*
                                 * Ligne « hygiène des fichiers » : fichiers suspects, puis
                                 * nettoyage à distance. Les badges de nettoyage n'apparaissent
                                 * QUE s'il y a matière. tmp en orange (résidus d'installation =
                                 * surface d'attaque), caches en gris neutre (normal, sans risque :
                                 * les colorer en alerte créerait une urgence factice).
                                 */
                                $tmpN   = $site['tmp_files'] ?? null;
                                $cacheN = $site['cache_files'] ?? null;

                                $svgBin = '<svg class="oc-clean-ico" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">'
                                    . '<path d="M9 3h6l1 2h4v2H4V5h4l1-2Zm-3 6h12l-1 12H7L6 9Z"/></svg>';

                                $cleanHtml = '';

                                if ($tmpN !== null) {
                                    if ($tmpN > 0) {
                                        $cleanHtml .= '<span class="oc-ext-item oc-clean-badge" data-oc-clean="tmp" role="button" tabindex="0"'
                                            . ' title="' . htmlspecialchars(
                                                $tmpN . ' fichier(s) dans tmp (' . round(((int) ($site['tmp_bytes'] ?? 0)) / 1048576, 1)
                                                . ' Mo) — cliquer pour vider. index.html et .htaccess sont préservés.',
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) . '">'
                                            . $svgBin . '<span class="badge bg-warning text-dark">tmp (' . (int) $tmpN . ')</span></span>';
                                    } else {
                                        // Rien à nettoyer : état sain, texte vert simple comme ailleurs.
                                        $cleanHtml .= '<span class="text-success oc-clean-ok" title="Dossier tmp propre : aucun résidu d\'installation">'
                                            . $svgBin . 'tmp</span>';
                                    }
                                }

                                if ($cacheN !== null) {
                                    if ($cacheN > 0) {
                                        $cleanHtml .= '<span class="oc-ext-item oc-clean-badge" data-oc-clean="cache" role="button" tabindex="0"'
                                            . ' title="' . htmlspecialchars(
                                                $cacheN . ' fichier(s) en cache (' . round(((int) ($site['cache_bytes'] ?? 0)) / 1048576, 1)
                                                . ' Mo) — cliquer pour vider. Sans risque : le cache se reconstruit.',
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) . '">'
                                            . $svgBin . '<span class="badge oc-badge-muted">cache (' . (int) $cacheN . ')</span></span>';
                                    } else {
                                        $cleanHtml .= '<span class="text-success oc-clean-ok" title="Caches vides">'
                                            . $svgBin . 'cache</span>';
                                    }
                                }

                                $suspectHtml = '';

                                if (!empty($site['suspect_files'])) {
                                    $suspectHtml = '<span class="oc-ext-item"><span class="oc-status-down" aria-hidden="true">⚠</span> '
                                        . '<span class="badge bg-danger" title="Fichiers PHP anormaux (portes dérobées possibles) : '
                                        . htmlspecialchars(implode(' | ', (array) $site['suspect_files']), ENT_QUOTES, 'UTF-8') . '">'
                                        . \count((array) $site['suspect_files']) . ' fichier(s) suspect(s)</span></span>';
                                } elseif (!empty($site['files_checked'])) {
                                    $suspectHtml = '<span class="text-success" title="Aucun fichier PHP anormal détecté'
                                        . ' (racine, media, images, tmp, caches)">✓ 0 fichier suspect</span>';
                                }

                                if ($suspectHtml !== '' || $cleanHtml !== '') {
                                    echo '<div class="oc-secfiles small mt-1">' . $suspectHtml . $cleanHtml . '</div>';
                                }

                                $sec = [];

                                $hs = $site['htaccess_state'] ?? null;
                                $hm = htmlspecialchars((string) ($site['htaccess_mode'] ?? ''), ENT_QUOTES, 'UTF-8');
                                if ($hs === 'absent') {
                                    $sec[] = '<span class="text-muted" title="Pas de .htaccess (site de test non mis en ligne)">○ htaccess.txt</span>';
                                } elseif ($hs === 'red') {
                                    $sec[] = '<span class="oc-ext-item"><span class="oc-status-down">⚠</span> <span class="badge bg-danger"'
                                        . ' title="Motifs dangereux dans .htaccess (hors bloc CG Secure) : '
                                        . htmlspecialchars(implode(', ', (array) $site['htaccess_suspect']), ENT_QUOTES, 'UTF-8')
                                        . ' — à vérifier d\'urgence">.htaccess</span></span>';
                                } elseif ($hs === 'orange') {
                                    $sec[] = '<span class="oc-ext-item"><span class="oc-status-maint">⚠</span> <span class="badge bg-warning text-dark"'
                                        . ' title="Permissions trop ouvertes (' . $hm . ') : inscriptible par groupe/autres">.htaccess ' . $hm . '</span></span>';
                                } elseif ($hs === 'green') {
                                    $sec[] = '<span class="oc-status-up" title=".htaccess présent, sain, permissions correctes">✓ .htaccess</span>';
                                }

                                $cs    = $site['config_state'] ?? null;
                                $cmode = htmlspecialchars((string) ($site['config_mode'] ?? ''), ENT_QUOTES, 'UTF-8');
                                if ($cs === 'red') {
                                    $sec[] = '<span class="oc-ext-item"><span class="oc-status-down">⚠</span> <span class="badge bg-danger"'
                                        . ' title="configuration.php inscriptible par groupe/autres (' . $cmode . ') — à passer en lecture seule (444)">configuration.php ' . $cmode . '</span></span>';
                                } elseif ($cs === 'orange') {
                                    $sec[] = '<span class="oc-ext-item"><span class="oc-status-maint">⚠</span> <span class="badge bg-warning text-dark"'
                                        . ' title="configuration.php modifiable par le propriétaire (' . $cmode . ') — durcissement possible en lecture seule (444)">configuration.php ' . $cmode . '</span></span>';
                                } elseif ($cs === 'green') {
                                    $sec[] = '<span class="oc-status-up" title="configuration.php en lecture seule (' . $cmode . ') — sécurisé">✓ configuration.php ' . $cmode . '</span>';
                                }

                                if ($sec !== []) {
                                    echo '<div class="oc-secfiles small mt-1">' . implode('', $sec) . '</div>';
                                }

                                ?>
                            </td>
                            <?php
                            $php    = htmlspecialchars((string) ($s['php'] ?? ''), ENT_QUOTES, 'UTF-8');
                            $pst    = \is_array($site['php_status'] ?? null) ? $site['php_status'] : ['status' => 'unknown', 'eol' => null];
                            $phpEol = $pst['status'] === 'eol'
                                || ($pst['status'] === 'unknown' && $php !== '' && version_compare($php, $phpMin, '<'));
                            ?>
                            <td class="d-none d-md-table-cell" data-sort="<?php echo $php; ?>">
                                <?php if ($phpEol) : ?>
                                    <span class="badge bg-danger"
                                          title="PHP en fin de vie : plus aucun correctif de sécurité<?php echo $pst['eol'] ? ' (depuis le ' . htmlspecialchars($pst['eol'], ENT_QUOTES, 'UTF-8') . ')' : ''; ?> — source : endoflife.date">
                                        <?php echo $php; ?>
                                    </span>
                                <?php elseif ($pst['status'] === 'soon') : ?>
                                    <span class="badge bg-warning text-dark"
                                          title="Fin de support PHP le <?php echo htmlspecialchars((string) $pst['eol'], ENT_QUOTES, 'UTF-8'); ?> — prévoir la montée de version">
                                        <?php echo $php; ?>
                                    </span>
                                <?php else : ?>
                                    <?php echo $php !== '' ? $php : '?'; ?>
                                <?php endif; ?>
                            </td>
                            <?php
                            $dbLabel = htmlspecialchars((string) ($site['db'] ?? '?'), ENT_QUOTES, 'UTF-8');
                            $dst     = \is_array($site['db_status'] ?? null) ? $site['db_status'] : ['status' => 'unknown', 'eol' => null];
                            ?>
                            <td class="text-nowrap d-none d-lg-table-cell">
                                <?php if ($dst['status'] === 'eol') : ?>
                                    <span class="badge bg-warning text-dark"
                                          title="Base de données en fin de vie : plus aucun correctif de sécurité<?php echo $dst['eol'] ? ' (depuis le ' . htmlspecialchars($dst['eol'], ENT_QUOTES, 'UTF-8') . ')' : ''; ?> — voir avec l'hébergeur — source : endoflife.date">
                                        <?php echo $dbLabel; ?>
                                    </span>
                                <?php elseif ($dst['status'] === 'soon') : ?>
                                    <span class="badge bg-warning text-dark"
                                          title="Fin de support le <?php echo htmlspecialchars((string) $dst['eol'], ENT_QUOTES, 'UTF-8'); ?> — prévoir la montée de version">
                                        <?php echo $dbLabel; ?>
                                    </span>
                                <?php else : ?>
                                    <?php echo $dbLabel; ?>
                                <?php endif; ?>
                                <?php $dbSchema = \is_array($site['db_schema'] ?? null) ? $site['db_schema'] : null; ?>
                                <?php if ($dbSchema !== null && !empty($dbSchema['problems'])) : ?>
                                    <?php foreach ($dbSchema['problems'] as $sp) : ?>
                                        <span class="badge bg-danger d-block mt-1" style="width: max-content"
                                              title="Structure de tables en erreur après mise à jour — à corriger via Système → Maintenance : Base de données">
                                            ⚠ <?php echo htmlspecialchars((string) $sp['name'], ENT_QUOTES, 'UTF-8'); ?> : schéma BDD
                                        </span>
                                    <?php endforeach; ?>
                                <?php elseif ($dbSchema !== null && ($dbSchema['checked'] ?? 0) > 0) : ?>
                                    <span class="text-success d-block mt-1 small" style="width: max-content"
                                          title="Structures de tables suivies et à jour : <?php echo (int) $dbSchema['checked']; ?> extension(s)">
                                        ✓ Schéma à jour (<?php echo (int) $dbSchema['checked']; ?>)
                                    </span>
                                <?php endif; ?>
                            </td>
                            <?php
                            $bk     = $site['backup'] ?? null;
                            $bkDays = \is_array($bk) ? $bk['days'] : null;
                            $bkSort = $bk === null ? 99998 : (!$bk['installed'] ? 99997 : ($bkDays === null ? 99999 : $bkDays));
                            ?>
                            <td data-sort="<?php echo $bkSort; ?>">
                                <?php if ($bk === null) : ?>
                                    <span class="text-muted" title="Plugin client v0.6+ requis sur ce site">?</span>
                                <?php elseif (!$bk['installed']) : ?>
                                    <span class="text-muted" title="Akeeba Backup non détecté sur ce site">n/d</span>
                                <?php elseif ($bkDays === null) : ?>
                                    <span class="badge bg-danger" title="Akeeba Backup est installé mais aucune sauvegarde réussie n'a été trouvée">Jamais</span>
                                <?php elseif ($bkDays > 30) : ?>
                                    <span class="badge bg-danger" title="Dernière sauvegarde réussie : <?php echo htmlspecialchars((string) $bk['last'], ENT_QUOTES, 'UTF-8'); ?>">
                                        <?php echo $bkDays; ?> j
                                    </span>
                                <?php elseif ($bkDays > 15) : ?>
                                    <span class="badge bg-warning text-dark" title="Dernière sauvegarde réussie : <?php echo htmlspecialchars((string) $bk['last'], ENT_QUOTES, 'UTF-8'); ?>">
                                        <?php echo $bkDays; ?> j
                                    </span>
                                <?php else : ?>
                                    <span title="Dernière sauvegarde réussie : <?php echo htmlspecialchars((string) $bk['last'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo $bkDays; ?> j</span>
                                <?php endif; ?>
                                <?php
                                if (\is_array($bk) && !empty($bk['installed'])) {
                                    $ed   = $bk['edition'] ?? null;
                                    $ver  = $bk['version'] ?? null;
                                    $ueid = (int) ($bk['update_eid'] ?? 0);
                                    $unew = $bk['update_new'] ?? null;

                                    $edName = $ed === 'pro' ? 'Akeeba Pro' : ($ed === 'core' ? 'Akeeba Core' : 'Akeeba (édition ?)');
                                    $edFull = htmlspecialchars($edName . ($ver ? ' ' . $ver : ''), ENT_QUOTES, 'UTF-8');

                                    if ($ueid > 0 && $unew) {
                                        // Mise à jour disponible : badge orange CLIQUABLE (comme Extensions).
                                        echo '<span class="oc-ext-item oc-ext-update d-block mt-1" data-oc-eid="' . $ueid . '"'
                                            . ' role="button" tabindex="0" title="Cliquer pour mettre à jour Akeeba à distance">'
                                            . '<span class="oc-status-maint" aria-hidden="true">⚠</span> '
                                            . '<span class="badge bg-warning text-dark">' . $edFull . ' → '
                                            . htmlspecialchars((string) $unew, ENT_QUOTES, 'UTF-8') . '</span></span>';
                                    } else {
                                        // À jour : texte simple, sans fond — vert (Pro) ou gris (Core/inconnu).
                                        $cls  = $ed === 'pro' ? 'text-success' : 'text-muted';
                                        $tick = $ed === 'pro' ? '✓ ' : '';
                                        echo '<span class="' . $cls . ' d-block mt-1 small" style="width: max-content"'
                                            . ' title="Édition Akeeba détectée (détermine la méthode de sauvegarde à distance)">'
                                            . $tick . $edFull . '</span>';
                                    }
                                }

                                // Bouton « Sauvegarder » : affiché automatiquement sur tout site
                                // détecté en Akeeba PRO (la sauvegarde front-end distante n'existe
                                // qu'en Pro). Aucune liste à maintenir : le jour où un site passe
                                // Core → Pro, le bouton apparaît de lui-même à l'interrogation suivante.
                                $isPro = \is_array($bk) && !empty($bk['installed']) && (($bk['edition'] ?? '') === 'pro');

                                if ($isPro) {
                                    // Vert si une sauvegarde a moins de 24 h, bleu sinon (invite à sauvegarder).
                                    $bkRecent = ($bkDays !== null && $bkDays < 1);
                                    $bkBtnCls = $bkRecent ? 'oc-backup-recent' : 'btn-primary';
                                    $bkTitle  = $bkRecent
                                        ? 'Sauvegarde de moins de 24 h — relancer une sauvegarde Akeeba à distance'
                                        : 'Lancer une sauvegarde Akeeba à distance (peut durer plusieurs minutes)';

                                    // Bouclier : vert si la sauvegarde à distance est opérationnelle
                                    // (client joignable + actions autorisées + mot secret Akeeba),
                                    // rouge sinon. Détail au survol.
                                    $bkReady   = !empty($bk['remote_ready']);
                                    $bkReason  = (string) ($bk['remote_reason'] ?? '');
                                    $bkIcoCls  = $bkReady ? 'oc-ico-ok' : 'oc-ico-ko';
                                    $bkIcoTtl  = $bkReason !== ''
                                        ? $bkReason
                                        : ($bkReady ? 'Sauvegarde à distance opérationnelle.' : 'Sauvegarde à distance non disponible.');

                                    echo '<span class="oc-backup-line mt-2">'
                                        . '<svg class="oc-backup-ico ' . $bkIcoCls . '" viewBox="0 0 24 24" fill="currentColor" role="img">'
                                        . '<title>' . htmlspecialchars($bkIcoTtl, ENT_QUOTES, 'UTF-8') . '</title>'
                                        . '<path d="M12 1 3 5v6c0 5 3.8 9.7 9 11 5.2-1.3 9-6 9-11V5l-9-4Zm0 10.9h7c-.5 3.6-2.9 6.9-7 8.2V12H5V6.3l7-3.1v8.7Z"/></svg>'
                                        . '<button type="button" class="btn ' . $bkBtnCls . ' oc-backup-btn"'
                                        . ' data-oc-backup="1" title="' . htmlspecialchars($bkTitle, ENT_QUOTES, 'UTF-8') . '">'
                                        . 'Sauvegarder</button></span>';
                                }
                                ?>
                            </td>
                            <?php
                            $extList = \is_array($site['extensions_list'] ?? null) ? $site['extensions_list'] : [];
                            $extOut  = 0;
                            foreach ($extList as $eTmp) { if (!empty($eTmp['new']) || !empty($eTmp['ref_new']) || !empty($eTmp['parc_new'])) { $extOut++; } }
                            ?>
                            <td class="oc-ext-cell" data-sort="<?php echo $extOut; ?>">
                                <?php if (!empty($site['missing_required'])) : ?>
                                    <span class="badge bg-danger d-block mb-1" style="width: max-content"
                                          title="Extension(s) requise(s) absente(s) ou désactivée(s) sur ce site">
                                        Manque : <?php echo htmlspecialchars(implode(', ', (array) $site['missing_required']), ENT_QUOTES, 'UTF-8'); ?>
                                    </span>
                                <?php endif; ?>
                                <?php if ($extList === []) : ?>
                                    <span class="text-muted small">–</span>
                                <?php else : ?>
                                    <div class="oc-ext-badges oc-collapsed" data-oc-badges>
                                        <?php foreach ($extList as $e) :
                                            $nm = htmlspecialchars((string) $e['name'], ENT_QUOTES, 'UTF-8');
                                            $vr = htmlspecialchars((string) ($e['version'] ?? ''), ENT_QUOTES, 'UTF-8');
                                        ?>
                                            <?php if (!empty($e['new']) && $frozen) : ?>
                                                <span class="oc-ext-item" title="Mise à jour disponible, mais site GELÉ : mise à jour à distance désactivée."><span class="oc-status-maint" aria-hidden="true">⚠</span><span class="badge bg-warning text-dark"><?php echo $nm; ?> <?php echo $vr; ?> → <?php echo htmlspecialchars((string) $e['new'], ENT_QUOTES, 'UTF-8'); ?> <span style="opacity:.75">❄</span></span></span>
                                            <?php elseif (!empty($e['new'])) : ?>
                                                <span class="oc-ext-item oc-ext-update" data-oc-eid="<?php echo (int) ($e['id'] ?? 0); ?>" role="button" tabindex="0" title="Cliquer pour mettre à jour cette extension à distance"><span class="oc-status-maint" aria-hidden="true">⚠</span><span class="badge bg-warning text-dark"><?php echo $nm; ?> <?php echo $vr; ?> → <?php echo htmlspecialchars((string) $e['new'], ENT_QUOTES, 'UTF-8'); ?></span></span>
                                            <?php elseif (!empty($e['ref_new'])) : ?>
                                                <span class="oc-ext-item" title="Version de référence plus récente disponible — MISE À JOUR MANUELLE (extension hors circuit de mise à jour Joomla)"><span class="oc-status-maint" aria-hidden="true">⚠</span><span class="badge bg-warning text-dark"><?php echo $nm; ?> <?php echo $vr; ?> → <?php echo htmlspecialchars((string) $e['ref_new'], ENT_QUOTES, 'UTF-8'); ?> <span style="opacity:.75">(man.)</span></span></span>
                                            <?php elseif (!empty($e['parc_new'])) : ?>
                                                <span class="oc-ext-item" title="Un autre site de ton parc a déjà une version plus récente — mise à jour à faire (souvent manuelle : Joomla ne la détecte pas ici)"><span class="oc-status-maint" aria-hidden="true">⚠</span><span class="badge bg-warning text-dark"><?php echo $nm; ?> <?php echo $vr; ?> → <?php echo htmlspecialchars((string) $e['parc_new'], ENT_QUOTES, 'UTF-8'); ?> <span style="opacity:.75">(parc)</span></span></span>
                                            <?php elseif (empty($e['enabled'])) : ?>
                                                <span class="badge oc-ext-off" title="Extension désactivée"><?php echo $nm; ?> <?php echo $vr; ?></span>
                                            <?php else : ?>
                                                <span class="badge bg-success"><?php echo $nm; ?> <?php echo $vr; ?></span>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </div>
                                    <button type="button" class="oc-ext-toggle" data-oc-toggle style="display:none">▾ voir tout</button>
                                <?php endif; ?>
                            </td>
                            <td class="d-none d-lg-table-cell" data-sort="<?php echo (int) ($s['extensions_total'] ?? 0); ?>">
                                <?php echo (int) ($s['extensions_total'] ?? 0); ?>
                            </td>
                            <?php $bu = $site['backend_users'] !== null ? (int) $site['backend_users'] : (int) ($s['super_users'] ?? 0); ?>
                            <td data-sort="<?php echo $bu; ?>">
                                <?php if (!empty($site['backend_names'])) : ?>
                                    <span title="<?php echo htmlspecialchars(implode(' | ', (array) $site['backend_names']), ENT_QUOTES, 'UTF-8'); ?>">
                                        <?php echo $bu; ?>
                                    </span>
                                <?php else : ?>
                                    <?php echo $bu; ?>
                                <?php endif; ?>
                                <?php
                                // Vert UNIQUEMENT si la MFA est explicitement active sur TOUS les
                                // comptes backend. Une liste « sans MFA » vide ne suffit pas :
                                // le statut peut être inconnu (ancien client), et un faux vert
                                // sur un indicateur de sécurité serait pire que pas d'indicateur.
                                $mfaOk = (int) ($site['backend_mfa'] ?? 0);
                                ?>
                                <?php if (!empty($site['backend_no_mfa'])) : ?>
                                    <span class="badge bg-warning text-dark d-block mt-1" style="width: max-content"
                                          title="Sans authentification multifacteur : <?php echo htmlspecialchars(implode(', ', (array) $site['backend_no_mfa']), ENT_QUOTES, 'UTF-8'); ?>">
                                        <?php echo \count((array) $site['backend_no_mfa']); ?> sans 2MFA
                                    </span>
                                <?php elseif ($bu > 0 && $mfaOk === $bu) : ?>
                                    <span class="text-success d-block mt-1 small" style="width: max-content"
                                          title="Tous les comptes backend ont l'authentification multifacteur active">
                                        ✓ <?php echo $mfaOk; ?> avec 2MFA
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="d-none d-md-table-cell" data-sort="<?php echo (int) ($s['scheduled_tasks'] ?? 0); ?>">
                                <?php echo (int) ($s['scheduled_tasks'] ?? 0); ?>
                            </td>
                        <?php endif; ?>
                        <?php
                        $ssl     = $site['ssl'] ?? null;
                        $sslDays = \is_array($ssl) ? (int) $ssl['days'] : null;
                        ?>
                        <td data-sort="<?php echo $sslDays === null ? 99999 : $sslDays; ?>">
                            <?php if ($ssl === null) : ?>
                                <span class="text-muted" title="Certificat non vérifiable">?</span>
                            <?php elseif ($sslDays < 0) : ?>
                                <span class="badge bg-danger" title="Certificat expiré le <?php echo htmlspecialchars((string) $ssl['expires'], ENT_QUOTES, 'UTF-8'); ?>">Expiré</span>
                            <?php elseif ($sslDays <= 14) : ?>
                                <span class="badge bg-danger" title="Expire le <?php echo htmlspecialchars((string) $ssl['expires'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo $sslDays; ?> j</span>
                            <?php elseif ($sslDays <= 30) : ?>
                                <span class="badge bg-warning text-dark" title="Expire le <?php echo htmlspecialchars((string) $ssl['expires'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo $sslDays; ?> j</span>
                            <?php else : ?>
                                <span title="Expire le <?php echo htmlspecialchars((string) $ssl['expires'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo $sslDays; ?> j</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
    <small class="text-muted d-block oc-footnote">
        <?php if ($refresh > 0) : ?>
            Sites classés du plus prioritaire au moins prioritaire (pastille : détail au survol) —
            actualisation automatique toutes les <?php echo $refresh; ?> s —
            dernière : <span id="mod-oculus-time-<?php echo $modId; ?>"><?php echo date('H:i:s'); ?></span>
        <?php else : ?>
            Données interrogées à chaque affichage de la page (actualisation automatique désactivée).
        <?php endif; ?>
    </small>
    <script>
    (function () {
        'use strict';

        var wrap   = document.getElementById('mod-oculus-wrap-<?php echo $modId; ?>');
        var search = document.getElementById('mod-oculus-search-<?php echo $modId; ?>');
        var clear  = document.getElementById('mod-oculus-clear-<?php echo $modId; ?>');
        var sortSel   = document.getElementById('mod-oculus-sort-<?php echo $modId; ?>');
        var clientSel = document.getElementById('mod-oculus-client-<?php echo $modId; ?>');
        var time   = document.getElementById('mod-oculus-time-<?php echo $modId; ?>');
        var state  = { col: -1, dir: 1, q: '', client: '' };

        function zone() {
            return document.getElementById('mod-oculus-zone-<?php echo $modId; ?>');
        }

        function ocEsc(t) { var d = document.createElement('div'); d.textContent = (t == null ? '' : String(t)); return d.innerHTML; }

        function showResultModal() {
            var el = document.getElementById('mod-oculus-result-<?php echo $modId; ?>');
            if (!el) { return; }
            var ok   = el.getAttribute('data-ok') === '1';
            var site = el.getAttribute('data-site') || '';
            var msg  = el.getAttribute('data-msg') || '';
            el.parentNode && el.parentNode.removeChild(el);

            var back = document.createElement('div');
            back.className = 'oc-modal-back';
            back.innerHTML = '<div class="oc-modal" role="dialog" aria-modal="true">'
                + '<div class="oc-modal-head ' + (ok ? 'oc-ok' : 'oc-ko') + '">'
                + (ok ? '✓ Mise à jour réussie' : '✕ Mise à jour échouée') + '</div>'
                + '<div class="oc-modal-body"><p><strong>Site :</strong> ' + ocEsc(site) + '</p>'
                + '<p class="oc-detail">' + ocEsc(msg) + '</p></div>'
                + '<div class="oc-modal-foot"><button type="button" class="btn btn-primary oc-modal-close">Fermer</button></div>'
                + '</div>';
            document.body.appendChild(back);

            function close() { back.parentNode && back.parentNode.removeChild(back); document.removeEventListener('keydown', onKey); }
            function onKey(e) { if (e.key === 'Escape') { close(); } }
            back.querySelector('.oc-modal-close').addEventListener('click', close);
            back.addEventListener('click', function (e) { if (e.target === back) { close(); } });
            document.addEventListener('keydown', onKey);
        }

        /* Enchaîne une liste de mises à jour {usite, eid, name} une par une, met à
           jour la progression sur le bouton, puis remplace la zone et affiche le
           récapitulatif. Partagé par le bouton par site et le bouton parc. */
        function ocRunBatch(jobs, btn) {
            btn.setAttribute('disabled', 'disabled');
            btn.classList.add('oc-batch-running');
            var origHtml = btn.innerHTML;
            var results  = [];
            var lastHtml = null;
            var k = 0;

            function step() {
                if (k >= jobs.length) {
                    var doc   = lastHtml ? new DOMParser().parseFromString(lastHtml, 'text/html') : null;
                    var fresh = doc ? doc.getElementById('mod-oculus-zone-<?php echo $modId; ?>') : null;
                    var z     = zone();
                    // Restaure le bouton AVANT le rendu : le bouton parc vit dans la
                    // barre d'outils (hors zone) et ne serait pas remplacé par le swap.
                    btn.classList.remove('oc-batch-running');
                    btn.removeAttribute('disabled');
                    btn.innerHTML = origHtml;
                    if (fresh && z) { z.innerHTML = fresh.innerHTML; apply(); }
                    if (time) { time.textContent = new Date().toLocaleTimeString(); }
                    showBatchModal(results);
                    return;
                }
                btn.textContent = 'MàJ ' + (k + 1) + '/' + jobs.length + '…';
                var u = new URL(window.location.href);
                u.searchParams.set('oculus_update', '1');
                u.searchParams.set('usite', jobs[k].usite);
                u.searchParams.set('ueid', jobs[k].eid);
                fetch(u.toString(), { credentials: 'same-origin', cache: 'no-store' })
                    .then(function (r) { return r.text(); })
                    .then(function (html) {
                        lastHtml = html;
                        var doc = new DOMParser().parseFromString(html, 'text/html');
                        var rm  = doc.getElementById('mod-oculus-result-<?php echo $modId; ?>');
                        results.push({
                            name: jobs[k].name,
                            ok:   rm && rm.getAttribute('data-ok') === '1',
                            msg:  rm ? (rm.getAttribute('data-msg') || '') : 'Pas de retour.'
                        });
                        k++;
                        step();
                    })
                    .catch(function () {
                        results.push({ name: jobs[k].name, ok: false, msg: 'Appel interrompu.' });
                        k++;
                        step();
                    });
            }
            step();
        }

        function showBatchModal(results) {
            var okN   = results.filter(function (r) { return r.ok; }).length;
            var koN   = results.length - okN;
            var allOk = koN === 0;
            var rows  = results.map(function (r) {
                return '<li class="' + (r.ok ? 'oc-ok' : 'oc-ko') + '">'
                    + (r.ok ? '✓ ' : '✕ ') + ocEsc(r.name)
                    + (r.ok ? '' : ' — ' + ocEsc(r.msg)) + '</li>';
            }).join('');

            var back = document.createElement('div');
            back.className = 'oc-modal-back';
            back.innerHTML = '<div class="oc-modal" role="dialog" aria-modal="true">'
                + '<div class="oc-modal-head ' + (allOk ? 'oc-ok' : 'oc-ko') + '">'
                + (allOk ? '✓ Mises à jour terminées' : '⚠ Terminé — ' + koN + ' échec(s)') + '</div>'
                + '<div class="oc-modal-body"><p>' + okN + ' réussie(s)'
                + (koN ? ', ' + koN + ' en échec' : '') + ' :</p>'
                + '<ul class="oc-batch-list">' + rows + '</ul></div>'
                + '<div class="oc-modal-foot"><button type="button" class="btn btn-primary oc-modal-close">Fermer</button></div>'
                + '</div>';
            document.body.appendChild(back);

            function close() { back.parentNode && back.parentNode.removeChild(back); document.removeEventListener('keydown', onKey); }
            function onKey(ev) { if (ev.key === 'Escape') { close(); } }
            back.querySelector('.oc-modal-close').addEventListener('click', close);
            back.addEventListener('click', function (ev) { if (ev.target === back) { close(); } });
            document.addEventListener('keydown', onKey);
        }

        function ocCollapse(z) {
            if (!z) { return; }
            Array.prototype.forEach.call(z.querySelectorAll('[data-oc-badges]'), function (b) {
                var t = b.nextElementSibling;
                if (!t || !t.hasAttribute('data-oc-toggle')) { return; }
                if (b.classList.contains('oc-collapsed')) {
                    t.style.display = (b.scrollHeight > b.clientHeight + 2) ? '' : 'none';
                } else {
                    t.style.display = '';
                }
            });
        }

        /* Réapplique filtre + tri + zébrage (aussi après chaque actualisation). */
        function apply() {
            var z = zone();
            if (!z) { return; }
            var tbody = z.querySelector('tbody');
            if (!tbody) { return; }

            var rows = Array.prototype.slice.call(tbody.rows);
            var q    = state.q.toLowerCase();

            if (state.col >= 0) {
                rows.sort(function (a, b) {
                    function val(row) {
                        var c = row.cells[state.col];
                        return c ? (c.getAttribute('data-sort') || c.textContent.trim()) : '';
                    }
                    var x = val(a), y = val(b);
                    var nx = parseFloat(x), ny = parseFloat(y);
                    if (!isNaN(nx) && !isNaN(ny) && String(nx) === x && String(ny) === y) {
                        return state.dir * (nx - ny);
                    }
                    return state.dir * x.localeCompare(y, 'fr', { numeric: true, sensitivity: 'base' });
                });
                rows.forEach(function (r) { tbody.appendChild(r); });
            }

            var visible = 0;

            rows.forEach(function (r) {
                var hit = r.textContent.toLowerCase().indexOf(q) !== -1;

                if (hit && state.client !== '') {
                    hit = r.getAttribute('data-client') === state.client;
                }

                r.style.display = hit ? '' : 'none';
                if (hit) {
                    r.className = 'row' + (visible % 2);
                    visible++;
                }
            });

            if (sortSel) {
                sortSel.value = state.col >= 0 ? state.col + ':' + state.dir : '';
            }

            /* Icônes de tri natives : icon-sort par défaut, caret sur la colonne active. */
            Array.prototype.forEach.call(z.querySelectorAll('a.js-stools-column-order'), function (a) {
                var icon   = a.querySelector('[class*="icon-"]');
                var active = parseInt(a.getAttribute('data-col'), 10) === state.col;
                a.classList.toggle('selected', active);
                if (icon) {
                    icon.className = 'ms-1 ' + (active ? (state.dir === 1 ? 'icon-caret-up' : 'icon-caret-down') : 'icon-sort');
                }
            });

            ocCollapse(z);

            // Recompte les MàJ automatisables restantes et met à jour le bouton parc
            // de la barre d'outils (qui vit hors de la zone re-rendue).
            var parkBtn = document.getElementById('mod-oculus-updatepark-<?php echo $modId; ?>');
            if (parkBtn) {
                var n   = z.querySelectorAll('tr:not([data-oc-frozen="1"]) .oc-ext-update[data-oc-eid]').length;
                var cnt = parkBtn.querySelector('.oc-park-count');
                if (cnt) { cnt.textContent = n; }
                parkBtn.style.display = n >= 1 ? '' : 'none';
            }
        }

        if (wrap) {
            wrap.addEventListener('click', function (e) {
                // MISE À JOUR DE TOUT LE PARC (bouton global) — testé AVANT le bouton
                // par site, car il porte aussi la classe .oc-ext-updateall.
                var park = e.target.closest('.oc-updateall-park');
                if (park && wrap.contains(park)) {
                    e.preventDefault();
                    // Les sites GELÉS (data-oc-frozen) sont exclus du lot global.
                    var pjobs = Array.prototype.slice.call(zone().querySelectorAll('tr:not([data-oc-frozen="1"]) .oc-ext-update[data-oc-eid]'))
                        .map(function (b) {
                            var tr = b.closest('tr');
                            return {
                                usite: tr ? tr.getAttribute('data-oc-site') : null,
                                eid:   b.getAttribute('data-oc-eid'),
                                name:  (b.textContent || '').trim()
                            };
                        })
                        .filter(function (j) { return j.usite !== null && j.eid && j.eid !== '0'; });
                    if (!pjobs.length) { return; }

                    if (!window.confirm('Mettre à jour les ' + pjobs.length + ' extension(s) détectée(s) sur TOUT le parc ?\n\n'
                        + 'Traitement site par site, une par une. Ne fermez pas la page. '
                        + 'Les composants sans sauvegarde récente et les échecs éventuels sont listés à la fin, sans bloquer le reste.')) { return; }

                    ocRunBatch(pjobs, park);
                    return;
                }

                var ua = e.target.closest('.oc-ext-updateall');
                if (ua && wrap.contains(ua)) {
                    e.preventDefault();
                    var uarow = ua.closest('tr');
                    var uasi  = uarow ? uarow.getAttribute('data-oc-site') : null;
                    if (uasi === null) { return; }

                    var jobs = Array.prototype.slice.call(uarow.querySelectorAll('.oc-ext-update[data-oc-eid]'))
                        .map(function (b) { return { usite: uasi, eid: b.getAttribute('data-oc-eid'), name: (b.textContent || '').trim() }; })
                        .filter(function (j) { return j.eid && j.eid !== '0'; });
                    if (!jobs.length) { return; }

                    if (!window.confirm('Mettre à jour la/les ' + jobs.length + ' extension(s) de ce site, une par une ?\n\n'
                        + 'Rappel : les composants exigent une sauvegarde de moins de 24 h ; '
                        + 'les extensions qui échouent sont listées à la fin, sans bloquer les autres.')) { return; }

                    ocRunBatch(jobs, ua);
                    return;
                }
                var one = e.target.closest('.oc-refresh-one');
                if (one && wrap.contains(one)) {
                    e.preventDefault();
                    var orow = one.closest('tr');
                    var osi  = orow ? orow.getAttribute('data-oc-site') : null;
                    if (osi === null) { return; }
                    var olabel = one.innerHTML;
                    one.classList.add('oc-one-running');
                    one.setAttribute('disabled', 'disabled');
                    one.textContent = 'Actualisation…';
                    var ou = new URL(window.location.href);
                    ou.searchParams.set('oculus_one', '1');
                    ou.searchParams.set('usite', osi);
                    fetch(ou.toString(), { credentials: 'same-origin', cache: 'no-store' })
                        .then(function (r) { return r.text(); })
                        .then(function (html) {
                            var doc   = new DOMParser().parseFromString(html, 'text/html');
                            var fresh = doc.getElementById('mod-oculus-zone-<?php echo $modId; ?>');
                            var z     = zone();
                            if (fresh && z) { z.innerHTML = fresh.innerHTML; apply(); }
                            if (time) { time.textContent = new Date().toLocaleTimeString(); }
                        })
                        .catch(function () {
                            one.classList.remove('oc-one-running');
                            one.removeAttribute('disabled');
                            one.innerHTML = olabel;
                        });
                    return;
                }
                var up = e.target.closest('.oc-ext-update');
                if (up && wrap.contains(up)) {
                    e.preventDefault();
                    var row = up.closest('tr');
                    var si  = row ? row.getAttribute('data-oc-site') : null;
                    var eid = up.getAttribute('data-oc-eid');
                    if (si === null || !eid || eid === '0') { return; }
                    if (!window.confirm('Mettre à jour cette extension à distance sur ce site ?\n(Une sauvegarde de moins de 24 h est requise pour les composants.)')) { return; }
                    up.classList.add('oc-ext-updating');
                    var uu = new URL(window.location.href);
                    uu.searchParams.set('oculus_update', '1');
                    uu.searchParams.set('usite', si);
                    uu.searchParams.set('ueid', eid);
                    fetch(uu.toString(), { credentials: 'same-origin', cache: 'no-store' })
                        .then(function (r) { return r.text(); })
                        .then(function (html) {
                            var doc   = new DOMParser().parseFromString(html, 'text/html');
                            var fresh = doc.getElementById('mod-oculus-zone-<?php echo $modId; ?>');
                            var z     = zone();
                            if (fresh && z) { z.innerHTML = fresh.innerHTML; apply(); }
                            if (time) { time.textContent = new Date().toLocaleTimeString(); }
                            showResultModal();
                        })
                        .catch(function () { up.classList.remove('oc-ext-updating'); });
                    return;
                }
                var bk = e.target.closest('.oc-backup-btn');
                if (bk && wrap.contains(bk)) {
                    e.preventDefault();
                    var brow = bk.closest('tr');
                    var bsi  = brow ? brow.getAttribute('data-oc-site') : null;
                    if (bsi === null) { return; }
                    if (!window.confirm('Lancer une sauvegarde Akeeba à distance sur ce site ?\n(Cela peut durer plusieurs minutes — ne fermez pas cette page.)')) { return; }
                    var blabel = bk.innerHTML;
                    bk.classList.add('oc-backup-running');
                    bk.setAttribute('disabled', 'disabled');
                    bk.textContent = 'Sauvegarde…';
                    var bu = new URL(window.location.href);
                    bu.searchParams.set('oculus_backup', '1');
                    bu.searchParams.set('usite', bsi);
                    fetch(bu.toString(), { credentials: 'same-origin', cache: 'no-store' })
                        .then(function (r) { return r.text(); })
                        .then(function (html) {
                            var doc   = new DOMParser().parseFromString(html, 'text/html');
                            var fresh = doc.getElementById('mod-oculus-zone-<?php echo $modId; ?>');
                            var z     = zone();
                            if (fresh && z) { z.innerHTML = fresh.innerHTML; apply(); }
                            if (time) { time.textContent = new Date().toLocaleTimeString(); }
                            showResultModal();
                        })
                        .catch(function () {
                            bk.classList.remove('oc-backup-running');
                            bk.removeAttribute('disabled');
                            bk.innerHTML = blabel;
                            window.alert('La sauvegarde a échoué ou le délai a été dépassé. Vérifiez le journal Akeeba sur le site.');
                        });
                    return;
                }
                var cl = e.target.closest('.oc-clean-badge[data-oc-clean]');
                if (cl && wrap.contains(cl)) {
                    e.preventDefault();
                    var crow = cl.closest('tr');
                    var csi  = crow ? crow.getAttribute('data-oc-site') : null;
                    var what = cl.getAttribute('data-oc-clean');
                    if (csi === null || !what) { return; }
                    if (!window.confirm(what === 'cache'
                        ? 'Vider les caches de ce site ?\n\nSans risque : ils se reconstruiront automatiquement.'
                        : 'Vider le dossier tmp de ce site ?\n\nLes fichiers de protection (index.html, .htaccess) sont préservés.')) { return; }
                    var clabel = cl.innerHTML;
                    cl.classList.add('oc-ext-updating');
                    var cu = new URL(window.location.href);
                    cu.searchParams.set('oculus_clean', '1');
                    cu.searchParams.set('usite', csi);
                    cu.searchParams.set('target', what);
                    fetch(cu.toString(), { credentials: 'same-origin', cache: 'no-store' })
                        .then(function (r) { return r.text(); })
                        .then(function (html) {
                            var doc   = new DOMParser().parseFromString(html, 'text/html');
                            var fresh = doc.getElementById('mod-oculus-zone-<?php echo $modId; ?>');
                            var z     = zone();
                            if (fresh && z) { z.innerHTML = fresh.innerHTML; apply(); }
                            if (time) { time.textContent = new Date().toLocaleTimeString(); }
                            showResultModal();
                        })
                        .catch(function () {
                            cl.classList.remove('oc-ext-updating');
                            cl.innerHTML = clabel;
                            window.alert('Nettoyage interrompu ou délai dépassé.');
                        });
                    return;
                }
                var hd = e.target.closest('.oc-harden-badge[data-oc-harden]');
                if (hd && wrap.contains(hd)) {
                    e.preventDefault();
                    var hrow = hd.closest('tr');
                    var hsi  = hrow ? hrow.getAttribute('data-oc-site') : null;
                    if (hsi === null) { return; }
                    if (!window.confirm('Appliquer le bloc de durcissement au .htaccess de ce site ?\n\n'
                        + 'Le fichier sera sauvegardé avant modification. Si le site tombe en erreur, '
                        + 'le .htaccess précédent sera restauré automatiquement.')) { return; }
                    var hlabel = hd.innerHTML;
                    hd.classList.add('oc-ext-updating');
                    var hu = new URL(window.location.href);
                    hu.searchParams.set('oculus_harden', '1');
                    hu.searchParams.set('usite', hsi);
                    fetch(hu.toString(), { credentials: 'same-origin', cache: 'no-store' })
                        .then(function (r) { return r.text(); })
                        .then(function (html) {
                            var doc   = new DOMParser().parseFromString(html, 'text/html');
                            var fresh = doc.getElementById('mod-oculus-zone-<?php echo $modId; ?>');
                            var z     = zone();
                            if (fresh && z) { z.innerHTML = fresh.innerHTML; apply(); }
                            if (time) { time.textContent = new Date().toLocaleTimeString(); }
                            showResultModal();
                        })
                        .catch(function () {
                            hd.classList.remove('oc-ext-updating');
                            hd.innerHTML = hlabel;
                            window.alert('Opération interrompue. Vérifiez le site : en cas d\'erreur, le .htaccess est restauré automatiquement côté serveur.');
                        });
                    return;
                }
                var t = e.target.closest('[data-oc-toggle]');
                if (t && wrap.contains(t)) {
                    e.preventDefault();
                    var badges = t.previousElementSibling;
                    if (badges && badges.hasAttribute('data-oc-badges')) {
                        var collapsed = badges.classList.toggle('oc-collapsed');
                        t.textContent = collapsed ? '▾ voir tout' : '▴ réduire';
                    }
                    return;
                }
                var a = e.target.closest('a.js-stools-column-order');
                if (!a || !wrap.contains(a)) { return; }
                e.preventDefault();
                var c = parseInt(a.getAttribute('data-col'), 10);
                state.dir = (state.col === c) ? -state.dir : 1;
                state.col = c;
                apply();
            });
        }

        if (search) {
            search.addEventListener('input', function () {
                state.q = this.value;
                apply();
            });
        }

        if (clear) {
            clear.addEventListener('click', function () {
                state.q      = '';
                state.col    = -1;
                state.dir    = 1;
                state.client = '';
                if (search) { search.value = ''; }
                if (clientSel) { clientSel.value = ''; }
                apply();
            });
        }

        if (clientSel) {
            clientSel.addEventListener('change', function () {
                state.client = this.value;
                apply();
            });
        }

        var refreshBtn = document.getElementById('mod-oculus-refresh-<?php echo $modId; ?>');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', function () {
                var original = refreshBtn.innerHTML;
                refreshBtn.disabled  = true;
                refreshBtn.textContent = 'Actualisation…';
                var u = new URL(window.location.href);
                u.searchParams.set('oculus_refresh', '1');
                fetch(u.toString(), { credentials: 'same-origin', cache: 'no-store' })
                    .then(function (r) { return r.text(); })
                    .then(function (html) {
                        var doc   = new DOMParser().parseFromString(html, 'text/html');
                        var fresh = doc.getElementById('mod-oculus-zone-<?php echo $modId; ?>');
                        var z     = zone();
                        if (fresh && z) { z.innerHTML = fresh.innerHTML; apply(); }
                        if (time) { time.textContent = new Date().toLocaleTimeString(); }
                    })
                    .catch(function () {})
                    .then(function () {
                        refreshBtn.disabled  = false;
                        refreshBtn.innerHTML = original;
                    });
            });
        }

        if (sortSel) {
            sortSel.addEventListener('change', function () {
                if (this.value === '') {
                    state.col = -1;
                    state.dir = 1;
                } else {
                    var parts = this.value.split(':');
                    state.col = parseInt(parts[0], 10);
                    state.dir = parseInt(parts[1], 10);
                }
                apply();
            });
        }

        ocCollapse(zone());

        /* Construit une URL d'interrogation LIVE (les sites sont réellement
           contactés) — à distinguer du rendu initial qui sert le cache. */
        function ocLoadUrl() {
            var u = new URL(window.location.href);
            u.searchParams.set('oculus_load', '1');
            return u.toString();
        }

        function ocFetchInto(url, done) {
            fetch(url, { credentials: 'same-origin', cache: 'no-store' })
                .then(function (r) { return r.ok ? r.text() : Promise.reject(new Error(r.status)); })
                .then(function (html) {
                    var doc   = new DOMParser().parseFromString(html, 'text/html');
                    var fresh = doc.getElementById('mod-oculus-zone-<?php echo $modId; ?>');
                    var z     = zone();
                    if (fresh && z) {
                        z.innerHTML = fresh.innerHTML;
                        if (time) { time.textContent = new Date().toLocaleTimeString(); }
                        apply();
                    }
                    if (done) { done(); }
                })
                .catch(function () { if (done) { done(); } });
        }

        <?php if ($ocAutoLoad) : ?>
        /* Rendu initial : la page est déjà à l'écran (cache ou « chargement… »).
           On interroge maintenant les sites en tâche de fond, puis on remplace la
           zone par les données fraîches et on retire l'indicateur « actualisation ». */
        ocFetchInto(ocLoadUrl(), function () {
            var badge = document.querySelector('#mod-oculus-wrap-<?php echo $modId; ?> .oc-refreshing');
            if (badge) { badge.parentNode.removeChild(badge); }
        });
        <?php endif; ?>

        <?php if ($refresh > 0) : ?>
        setInterval(function () { ocFetchInto(ocLoadUrl()); }, <?php echo $refresh * 1000; ?>);
        <?php endif; ?>
    })();
    </script>
<?php endif; ?>
</div>
