<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * L'ASSISTANT.
 *
 * Il porte toutes les decisions, pour que les fichiers de tmpl/ ne contiennent
 * que du balisage. C'est ce qui permet a un integrateur d'ecrire SA mise en
 * page dans les surcharges du template sans avoir a redecouvrir ces regles.
 */

namespace Joomanji\Module\Opus\Site\Helper;

use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Registry\Registry;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

class BlocsHelper
{
    /**
     * VRAI DES QU'UN ONGLET A ETE LU DANS LE MONTAGE.
     *
     * Il sert au repartiteur, qui ne demande le script `joomla-tab` du coeur
     * que si la page en a besoin. Le savoir nait ici parce que c'est ici qu'on
     * parcourt le montage : le refaire dans le repartiteur serait lire deux
     * fois la meme chose pour la meme reponse.
     */
    private bool $onglets = false;

    /** Le montage lu porte-t-il au moins un element Onglets ? */
    public function aDesOnglets(): bool
    {
        return $this->onglets;
    }

    /**
     * La classe posee sur le conteneur racine du module.
     *
     * Elle sert a deux choses : limiter la portee du CSS personnalise, et
     * donner a l'integrateur un point d'accroche stable.
     *
     * UN SEUL CHAMP POUR CELA, ET C'EST CELUI DU COEUR. Le module a porte un
     * « Classe du montage » a lui jusqu'au 22 septembre 2026, a cote du
     * « Suffixe de classe du module » que Joomla pose dans Parametres avances.
     * Deux champs pour la meme chose, dont un que l'administrateur connait
     * deja depuis quinze ans : le notre est parti.
     */
    /**
     * UNE CLASSE SAISIE SORT ECHAPPEE, ET C'EST LE SEUL ENDROIT QUI LE FAIT.
     *
     * Releve du 25 septembre 2026 : les neuf champs de classe du manifeste, et
     * le suffixe du coeur, arrivaient tels quels dans 39 attributs `class` des
     * fichiers de `tmpl/`. Un guillemet tape par erreur fermait l'attribut, et
     * la suite de la saisie devenait du balisage. Le coeur, lui, passe son
     * suffixe de classe par `htmlspecialchars()` dans chacune de ses mises en
     * page.
     *
     * On echappe ICI, a la lecture, plutot que dans les 39 sorties : toutes
     * les classes saisies passent par cet assistant, aucune mise en page ne les
     * lit dans le Registry. `double_encode` a faux, parce que `preparer()` et
     * `rangees()` peuvent repasser sur une valeur deja lue : un `&amp;` ne
     * doit pas devenir `&amp;amp;`.
     *
     * C'EST LA SECONDE CEINTURE. La premiere est `validate="CssIdentifier"`
     * dans le manifeste : mesure sur le banc, un guillemet saisi dans la
     * classe d'une rangee est refuse a l'enregistrement (« Champ invalide :
     * Classe »). Mais seize champs de classe (valeur, mesure, source, barre)
     * portaient `type="CssIdentifier"`, un type qui n'existe pas : Joomla
     * retombe alors en champ texte, SANS aucun controle. Corrige le meme jour.
     * Cet echappement reste pour ce que le formulaire ne voit pas : un montage
     * importe, une valeur enregistree avant la correction.
     *
     * On ne retire rien : corriger la valeur serait une correction
     * silencieuse du choix de l'utilisateur.
     */
    public function classeSaisie($valeur): string
    {
        return htmlspecialchars(trim((string) $valeur), ENT_QUOTES, 'UTF-8', false);
    }

    public function classeRacine(Registry $params, $module): string
    {
        $classes = ['opus'];

        $suffixe = trim((string) $params->get('moduleclass_sfx', ''));

        if ($suffixe !== '') {
            $classes[] = $this->classeSaisie($suffixe);
        }

        return implode(' ', $classes);
    }

    /**
     * Remet un sous-formulaire en liste simple, dans l'ordre saisi, sans les
     * elements masques.
     *
     * POURQUOI CETTE FONCTION EXISTE : un sous-formulaire enregistre par
     * Joomla revient tantot en tableau, tantot en objet dont les clefs sont
     * des index, selon qu'il a ete relu depuis la base ou depuis le
     * formulaire. Le normaliser une fois evite de traiter les deux cas dans
     * chaque mise en page.
     *
     * L'ORDRE DES LIGNES EST L'ORDRE DU RENDU. La poignee du composant du coeur
     * reordonne les lignes, et nous n'y touchons pas : aucun `order` en CSS,
     * qui ferait diverger ce qui est lu au clavier de ce qui est affiche.
     */
    public function elements($brut): array
    {
        if (empty($brut)) {
            return [];
        }

        $sortie = [];

        foreach ($this->lignes($brut) as $ligne) {
            // Masque : la saisie est gardee, elle ne sort simplement pas.
            if (isset($ligne->show) && (int) $ligne->show === 0) {
                continue;
            }

            $sortie[] = $ligne;
        }

        return $sortie;
    }

    /**
     * Les lignes d'une liste, telles quelles, SANS ecarter les masquees.
     *
     * LES RANGEES N'ONT PLUS D'OEIL, et elles passent donc par ici. Retirer le
     * champ du manifeste ne suffisait pas : un module regle pendant la beta a
     * pu enregistrer `show=0` sur une rangee, et le filtre l'aurait ecartee
     * pour toujours, sans plus aucun bouton pour la faire revenir. Une rangee
     * qu'on ne voit pas et qu'on ne peut pas retrouver est pire que trois
     * facons de la cacher.
     *
     * @param  mixed  $brut  Ce que le registre rend pour une liste.
     * @return array<int, object>
     */
    public function lignes($brut): array
    {
        if (empty($brut)) {
            return [];
        }

        $lignes = \is_object($brut) ? get_object_vars($brut) : (array) $brut;

        return array_map(function ($ligne) { return (object) $ligne; }, array_values($lignes));
    }

    /**
     * Prepare une liste d'elements pour une mise en page.
     *
     * TOUTE DECISION SE PREND ICI, PAS DANS tmpl/. Un fichier de mise en page
     * ne doit contenir que du balisage : c'est ce qui permet a un integrateur
     * d'ecrire la sienne dans les surcharges du template sans redecouvrir la
     * regle du niveau de titre, celle du lien en nouvelle fenetre ou celle de
     * l'image.
     *
     * Chaque element revient avec, selon son type : `tag`, `texte`, `lien`,
     * `image`, `classe`. La mise en page n'a plus qu'a choisir ou les poser.
     */
    public function preparer(array $elements, int $niveauDepart): array
    {
        foreach ($elements as $el) {
            /*
             * LA CLASSE SAISIE ET CELLE DE L'ALIGNEMENT COHABITENT.
             *
             * Le champ derriere la roue dentee s'appelle `classe`, comme dans
             * Corpus, et c'est aussi le nom que porte la classe d'alignement
             * calculee ici : sans ce garde, la premiere ecrasait la seconde en
             * silence, et l'alignement cessait de fonctionner des qu'une classe
             * etait saisie.
             *
             * `blocsBrut` retient la valeur d'origine pour que deux appels de
             * `preparer()` sur la meme liste ne cumulent pas l'alignement.
             */
            if (!isset($el->blocsBrut)) {
                $el->blocsBrut = $this->classeSaisie($el->classe ?? '');
            }

            /*
             * L'ALIGNEMENT EST RENDU DEUX FOIS, ET LES DEUX SERVENT.
             *
             * `classe` porte la classe toute faite, pour une pile d'elements
             * ou chaque element est sa propre boite. `alignement` rend la
             * valeur brute, pour les mises en page qui doivent la poser
             * AILLEURS que sur la boite : dans une carte, `align-self` sur
             * `.carte` l'empecherait de s'etirer a la hauteur de ses voisines,
             * et une carte plus courte que les autres se voit tout de suite.
             */
            $el->alignement = (string) ($el->align ?? 'start');
            $el->classe = trim($this->classeAlignement($el->alignement) . ' ' . $el->blocsBrut);
            $el->identifiant = trim((string) ($el->identifiant ?? ''));

            /*
             * L'ATTRIBUT TOUT FAIT, PARCE QU'UN `id=""` VIDE N'EST PAS ANODIN.
             *
             * Ecrit tel quel dans chaque mise en page, un identifiant absent
             * sortirait `id=""` sur tous les elements de toutes les pages :
             * `document.querySelector('#')` est une erreur de syntaxe, et un
             * validateur le signale a chaque ligne. On rend donc soit
             * l'attribut complet, soit rien du tout.
             */
            $el->attrId = $el->identifiant === ''
                ? ''
                : ' id="' . htmlspecialchars($el->identifiant, ENT_QUOTES, 'UTF-8') . '"';

            if (($el->type ?? '') === 'heading') {
                $el->tag = $this->baliseTitre($el->headingLevel ?? '', $niveauDepart);
            }

            if (isset($el->image)) {
                $el->visuel = $this->image($el->image);
            }

            if (($el->type ?? '') === 'image') {
                $el->imageClasses = $this->habillageImage($el);
                $el->imageStyle   = $this->styleImage($el);
                $el->imageCharge  = ($el->imgChargement ?? 'differe') === 'immediat';
            }

            if (isset($el->linkType)) {
                $el->lien = $this->lien($el);
            }

            // Les boutons, prets a poser. Vide pour les autres types d'element.
            $el->sens    = ($el->sens ?? '') === 'column' ? 'column' : 'row';
            $el->boutons = ($el->type ?? '') === 'buttons' ? $this->boutons($el) : [];

            /*
             * LA LISTE : UNE LIGNE, UN ELEMENT.
             *
             * Le decoupage se fait ici, une fois, et pas dans la mise en page :
             * un integrateur qui surcharge `_elements.php` recoit un tableau
             * pret a parcourir, sans avoir a redecouvrir ce qu'est une ligne.
             *
             * LES LIGNES VIDES SAUTENT. On en laisse toujours une en fin de
             * saisie, et elle sortirait en puce vide.
             */
            $el->items = [];

            if (($el->type ?? '') === 'liste') {
                foreach (preg_split('/\R/', (string) ($el->listItems ?? '')) as $ligne) {
                    $ligne = trim($ligne);

                    if ($ligne === '') {
                        continue;
                    }

                    /*
                     * « TEXTE | ADRESSE » FAIT UN LIEN, ET C'EST TOUT CE QU'IL Y A
                     * A APPRENDRE.
                     *
                     * Mesure faite le 23 septembre 2026 sur la page d'accueil de
                     * landing.joomanji.eu : son sommaire est une liste de huit
                     * LIENS. Une liste qui ne sait ecrire que du texte ne refait
                     * donc pas une page existante, et c'etait le seul manque.
                     *
                     * POURQUOI UNE BARRE ET PAS DU HTML. Ouvrir la zone au HTML
                     * aurait suffi, et aurait demande a celui qui redige de savoir
                     * ecrire une balise `a`. La barre verticale ne s'apprend pas,
                     * elle se voit dans l'aide du champ, et elle reste lisible
                     * quand on relit sa liste six mois plus tard.
                     *
                     * ON COUPE A LA PREMIERE BARRE SEULEMENT : une adresse peut en
                     * contenir une, un texte aussi, et la premiere separe toujours
                     * les deux.
                     */
                    $adresse = '';
                    $barre   = strpos($ligne, '|');

                    if ($barre !== false) {
                        $adresse = trim(substr($ligne, $barre + 1));
                        $ligne   = trim(substr($ligne, 0, $barre));
                    }

                    if ($ligne === '') {
                        continue;
                    }

                    $el->items[] = (object) ['texte' => $ligne, 'href' => $adresse];
                }
            }

            /*
             * LES COORDONNEES : L'ADRESSE EN LIGNES, LE TELEPHONE EN LIEN.
             *
             * DEUX ELEMENTS, PAS UN : `adresse` et `contact`. Arbitrage de
             * Cyrille, 24 septembre 2026, apres avoir vu un element unique
             * livre a demi rempli : « il faut deux blocs, avec des champs
             * differents ». Les deux preparations vivent cote a cote ici parce
             * qu'elles se lisent ensemble, pas parce que ce serait le meme
             * element.
             *
             * DEUX CHOSES SE PREPARENT ICI, ET AUCUNE NE S'INVENTE DANS LA MISE
             * EN PAGE.
             *
             * 1. L'ADRESSE EST UNE SUITE DE LIGNES, comme la liste : c'est ainsi
             *    qu'on ecrit une adresse, et c'est ce que `<address>` attend. Le
             *    saut se fait avec un `<br>` et non un paragraphe par ligne : une
             *    adresse est UN bloc, pas quatre.
             *
             * 2. LE LIEN `tel:` SE CALCULE DEPUIS LE NUMERO AFFICHE. Le tampon
             *    « Page - Coordonnees » de Corpus le dit : « sur telephone, on
             *    appelle d'un doigt au lieu de recopier dix chiffres. » Mais
             *    personne ne doit avoir a saisir deux fois son numero, une fois
             *    pour l'oeil et une fois pour la machine. On garde donc les
             *    chiffres et le `+` de tete, et on jette tout le reste : espaces,
             *    points, tirets, parentheses.
             *
             * CE QUE CE CALCUL NE SAIT PAS FAIRE : deviner un indicatif. Un
             * numero ecrit « 01 00 00 00 00 » donne « tel:0100000000 », qui
             * fonctionne depuis le pays et pas depuis l'etranger. Celui qui veut
             * l'international ecrit « +33 1 00 00 00 00 », et le lien suit. On ne
             * devine pas un pays a partir d'un zero.
             */
            $el->coordLignes = [];

            if (($el->type ?? '') === 'adresse') {
                foreach (preg_split('/\R/', (string) ($el->coordAdresse ?? '')) as $ligne) {
                    $ligne = trim($ligne);

                    if ($ligne !== '') {
                        $el->coordLignes[] = $ligne;
                    }
                }
            }

            $el->coordTelLien = '';

            $numero = trim((string) ($el->coordTel ?? ''));

            if ($numero !== '') {
                $plus  = str_starts_with($numero, '+') ? '+' : '';
                $brut  = preg_replace('/\D+/', '', $numero);

                if ($brut !== '') {
                    $el->coordTelLien = $plus . $brut;
                }
            }

            /*
             * LES CHIFFRES ET LES VOLETS : MEME MECANIQUE QUE LES POINTS.
             *
             * Une entree dont les deux champs sont vides ne sort pas : c'est une
             * ligne ajoutee et pas encore remplie, et elle laisserait un trou.
             */
            $el->chiffresListe = [];

            if (($el->type ?? '') === 'chiffres') {
                foreach ($this->elements($el->chiffres ?? null) as $chiffre) {
                    $valeur = trim((string) ($chiffre->valeur ?? ''));
                    $mesure = trim((string) ($chiffre->mesure ?? ''));

                    if ($valeur === '' && $mesure === '') {
                        continue;
                    }

                    /*
                     * LA SOURCE EST FACULTATIVE ET N'EST PAS DECORATIVE.
                     *
                     * Le tampon « Donnees - Chiffres verifiables » de Corpus
                     * n'ajoute qu'une chose aux chiffres cles : la ligne qui dit
                     * d'ou vient le nombre. « 1 200 personnes accompagnees » est
                     * une affirmation ; « chiffre issu du rapport d'activite
                     * 2026, page 12 » la rend verifiable. Un chiffre sans source
                     * reste possible, c'est le meme element.
                     */
                    $source = trim((string) ($chiffre->source ?? ''));

                    /*
                     * CHAQUE PART DU CHIFFRE PORTE SES PROPRES HABITS.
                     *
                     * « Comment je pourrais faire pour mettre la valeur 1 200 en
                     * rouge ? », Cyrille, 23 puis 24 septembre 2026, puis « il me
                     * faudrait cela pour chaque champ, valeur, mesure et
                     * source ». Le champ Classe de l'element se pose sur le
                     * `dl` : il vise les trois chiffres a la fois, et il faut
                     * connaitre le nom de la classe interne pour descendre
                     * jusqu'a une part.
                     *
                     * DEUX REPONSES QUI NE SE CONCURRENCENT PAS, par part. Le TON
                     * couvre le cas courant sans une ligne de CSS, avec les
                     * couleurs de Corpus. La CLASSE couvre tout le reste, et se
                     * pose au meme endroit.
                     *
                     * LE TON EST FILTRE CONTRE UNE LISTE FERMEE : une valeur
                     * inventee ecrirait une classe qui n'existe pas, et la
                     * feuille resterait muette sans qu'on sache pourquoi.
                     */
                    $habiller = function (string $ton): string {
                        return \in_array($ton, ['accent', 'succes', 'alerte', 'erreur'], true) ? $ton : '';
                    };

                    $el->chiffresListe[] = (object) [
                        'valeur'       => $valeur,
                        'mesure'       => $mesure,
                        'source'       => $source,
                        'tonValeur'    => $habiller((string) ($chiffre->tonValeur ?? '')),
                        'classeValeur' => $this->classeSaisie($chiffre->classeValeur ?? ''),
                        'tonMesure'    => $habiller((string) ($chiffre->tonMesure ?? '')),
                        'classeMesure' => $this->classeSaisie($chiffre->classeMesure ?? ''),
                        'tonSource'    => $habiller((string) ($chiffre->tonSource ?? '')),
                        'classeSource' => $this->classeSaisie($chiffre->classeSource ?? ''),
                    ];
                }
            }

            /*
             * LES BARRES : UNE PART, UN MOT, UN TRAIT.
             *
             * « Ce qui manque : des barres graphe », Cyrille, 24 septembre 2026.
             *
             * LA PART EST BORNEE ICI, ET NULLE PART AILLEURS. Le manifeste pose
             * `min` et `max` sur le champ, mais un `min` de formulaire est un
             * garde-fou de saisie, pas une garantie : un montage importe, un
             * champ vide, une valeur collee, et `width: 340%` sortirait une
             * barre qui deborde de la colonne sans un mot d'erreur. On borne
             * donc au moment de lire, une fois pour toutes.
             *
             * UNE LIGNE SANS MOT NI PART NE SORT PAS, comme partout ailleurs :
             * c'est une ligne ajoutee et pas encore remplie. Une part a zero,
             * elle, est une vraie valeur et sort : « Reste a faire, 0 % » veut
             * dire quelque chose.
             */
            $el->barresListe = [];

            if (($el->type ?? '') === 'barres') {
                foreach ($this->elements($el->barres ?? null) as $barre) {
                    $terme = trim((string) ($barre->terme ?? ''));
                    $brut  = $barre->part ?? '';

                    if ($terme === '' && trim((string) $brut) === '') {
                        continue;
                    }

                    $part = max(0.0, min(100.0, (float) $brut));

                    /*
                     * LE TON EST FILTRE CONTRE UNE LISTE FERMEE, comme celui des
                     * chiffres : une valeur inventee ecrirait une classe qui
                     * n'existe pas, et la feuille resterait muette.
                     */
                    $ton = (string) ($barre->tonBarre ?? '');

                    $el->barresListe[] = (object) [
                        'terme'  => $terme,
                        'part'   => $part,
                        /*
                         * LE NOMBRE ECRIT N'A PAS DE DECIMALE INUTILE : 86 et non
                         * 86.0, mais 12.5 reste 12.5.
                         */
                        'ecrit'  => rtrim(rtrim(number_format($part, 1, ',', ' '), '0'), ','),
                        'ton'    => \in_array($ton, ['accent', 'succes', 'alerte', 'erreur'], true) ? $ton : '',
                        'classe' => $this->classeSaisie($barre->classeBarre ?? ''),
                    ];
                }
            }

            /*
             * LA FICHE : DES PAIRES, MEME MECANIQUE QUE LES CHIFFRES.
             *
             * ELLE RESSEMBLE AUX CHIFFRES CLES ET N'EST PAS LA MEME CHOSE, et la
             * difference vaut d'etre dite parce qu'elle decide laquelle employer.
             * Les chiffres cles MONTRENT trois valeurs, grandes, pour frapper.
             * La fiche ENUMERE cinq ou dix caracteristiques, petites, pour qu'on
             * les consulte : preparation, cuisson, pour combien de personnes.
             * L'une se regarde, l'autre se lit ligne a ligne.
             *
             * C'EST POURQUOI ELLE EST UN ELEMENT A PART et non un reglage de
             * taille des chiffres : le tampon « Donnees - Fiche » de Corpus lui
             * donne une classe a elle, `corpus-specs`, qui pose un filet entre
             * chaque ligne et pousse la valeur a droite. Un reglage de taille ne
             * fabriquerait pas ces filets.
             *
             * UNE LIGNE DONT LES DEUX CHAMPS SONT VIDES NE SORT PAS : c'est une
             * ligne ajoutee et pas encore remplie.
             */
            $el->ficheListe = [];

            if (($el->type ?? '') === 'fiche') {
                foreach ($this->elements($el->fiche ?? null) as $ligne) {
                    $terme  = trim((string) ($ligne->terme ?? ''));
                    $valeur = trim((string) ($ligne->valeur ?? ''));

                    if ($terme === '' && $valeur === '') {
                        continue;
                    }

                    $el->ficheListe[] = (object) ['terme' => $terme, 'valeur' => $valeur];
                }
            }

            /*
             * LES LIENS : LA MECANIQUE DES BOUTONS, SANS LE BOUTON.
             *
             * `lien()` sait deja lire `linkType`, `linkMenu`, `linkUrl` et
             * `linkNewTab` : c'est le meme jeu de champs, donc le meme
             * assistant. Un lien sans intitule ne sort pas ; c'est l'intitule
             * qu'on lit et qu'on clique.
             */
            $el->liensListe = [];

            if (($el->type ?? '') === 'liens') {
                foreach ($this->elements($el->liens ?? null) as $ligne) {
                    $libelle = trim((string) ($ligne->text ?? ''));

                    if ($libelle === '') {
                        continue;
                    }

                    $el->liensListe[] = (object) [
                        'texte' => $libelle,
                        'lien'  => $this->lien($ligne),
                    ];
                }
            }

            $el->voletsListe = [];

            if (($el->type ?? '') === 'accordeon') {
                foreach ($this->elements($el->volets ?? null) as $volet) {
                    $titre = trim((string) ($volet->titre ?? ''));

                    /*
                     * UN VOLET SANS TITRE N'EXISTE PAS : le titre EST le bouton
                     * qui l'ouvre. Sans lui, le contenu serait inatteignable.
                     */
                    if ($titre === '') {
                        continue;
                    }

                    $el->voletsListe[] = (object) [
                        'titre'  => $titre,
                        'texte'  => (string) ($volet->texte ?? ''),
                        'ouvert' => (int) ($volet->ouvert ?? 0) === 1,
                    ];
                }
            }

            /*
             * LES POINTS CLES : UN SOUS-FORMULAIRE, DONC LE MEME TRAITEMENT QUE
             * LES BOUTONS. Un point sans intitule ET sans texte ne sort pas :
             * c'est une ligne ajoutee et pas encore remplie.
             */
            $el->pointsListe = [];

            if (($el->type ?? '') === 'points') {
                foreach ($this->elements($el->points ?? null) as $point) {
                    $titre = trim((string) ($point->titre ?? ''));
                    $texte = trim((string) ($point->texte ?? ''));

                    if ($titre === '' && $texte === '') {
                        continue;
                    }

                    $el->pointsListe[] = (object) ['titre' => $titre, 'texte' => $texte];
                }
            }
        }

        return $elements;
    }

    /**
     * Les rapports permis, en douziemes.
     *
     * REPRIS DE `helper-gabarits.php` DE CORPUS, l. 130, a l'identique : une
     * valeur absente ou fautive rend des parts egales plutot que de casser la
     * page parce qu'un rapport a ete mal saisi. Le reste des douziemes va a la
     * premiere colonne, pour que la somme fasse toujours douze.
     */
    protected function rapport(int $colonnes, string $brut): array
    {
        $parts = array_map('intval', array_filter(explode('-', $brut), 'strlen'));

        if (\count($parts) === $colonnes && array_sum($parts) === 12) {
            return $parts;
        }

        $egal = (int) floor(12 / max(1, $colonnes));
        $rendu = array_fill(0, $colonnes, $egal);
        $rendu[0] += 12 - ($egal * $colonnes);

        return $rendu;
    }

    /**
     * Les codes de colonne permis selon le nombre de colonnes de la rangee.
     *
     * Repris de Corpus, l. 148. `p` pour une rangee d'une seule colonne, puis
     * gauche et droite, puis gauche, centre et droite.
     */
    protected function colonnesPermises(int $colonnes): array
    {
        if ($colonnes >= 3) {
            return ['g', 'c', 'd'];
        }

        if ($colonnes === 2) {
            return ['g', 'd'];
        }

        return ['p'];
    }

    /**
     * Le montage complet : les rangees, leurs colonnes, et les blocs dedans.
     *
     * C'EST LE SEUL ENDROIT QUI CONNAIT LE MODELE. Les fichiers de tmpl/ ne
     * font que parcourir ce qu'il rend : un integrateur qui ecrit sa propre
     * mise en page dans les surcharges du template n'a ni a relire le
     * manifeste, ni a redecouvrir comment un bloc trouve sa rangee.
     *
     * LE MODELE EST CELUI DE CORPUS, A LA LETTRE : `colonnes` de 1 a 3, un
     * rapport en douziemes, des codes de colonne p, g, c, d, un fond qui porte
     * directement la classe de section du template et un « appliquer a » qui
     * le pose sur une seule colonne. Meme normalisation, memes noms, meme
     * repli quand une valeur est fautive.
     *
     * UN BLOC DESIGNE SA RANGEE PAR SON NUMERO, comme une brique. Consequence
     * assumee, et ecrite dans l'aide du champ : deplacer une rangee deplace son
     * numero, pas son contenu.
     *
     * UN BLOC QUI DESIGNE UNE RANGEE INEXISTANTE EST ABANDONNE. Il ne se
     * rattache pas a la derniere rangee, ni a la premiere : apparaitre au
     * mauvais endroit est pire que ne pas apparaitre, parce qu'on cherche la
     * cause dans le contenu au lieu de la chercher dans le numero.
     *
     * @return array<int, object> Une rangee par entree, dans l'ordre de saisie.
     */
    public function montage(Registry $params, int $niveauDepart): array
    {
        $rangees = $this->lignes($params->get('rangees'));
        $blocs   = $this->elements($params->get('blocs'));

        /*
         * RIEN DANS LE NOUVEAU MODELE : on regarde si l'ancien a quelque chose
         * a dire avant de rendre une page vide.
         */
        if ($rangees === []) {
            $reprise = $this->reprise($params);

            if ($reprise === []) {
                return [];
            }

            $rangees = [$reprise[0]];
            $blocs   = $reprise[1];
        }

        $sortie = [];

        foreach ($rangees as $rang => $rangee) {
            $colonnes = max(1, min(3, (int) ($rangee->colonnes ?? 1)));
            $codes    = $this->colonnesPermises($colonnes);
            $fond     = (string) ($rangee->fond ?? '');

            /*
             * SUR QUOI LE FOND SE POSE. Vide : toute la rangee. Sinon le code
             * d'une colonne. Une colonne qui n'existe pas dans cette rangee
             * ramene le fond sur la rangee entiere : mieux vaut un aplat trop
             * large qu'un aplat disparu. C'est le choix de Corpus, l. 798.
             */
            $fondSur = strtolower(substr((string) ($rangee->fondSur ?? ''), 0, 1));

            if ($fond === '' || !\in_array($fondSur, $codes, true)) {
                $fondSur = '';
            }

            $r = (object) [
                'colonnes' => $colonnes,
                'codes'    => $codes,
                'parts'    => $this->rapport($colonnes, (string) ($rangee->rapport ?? '')),
                'fond'     => $fond,
                'fondSur'  => $fondSur,
                /*
                 * LE DEFAUT EST « AU MILIEU » DEPUIS LE 23 SEPTEMBRE 2026.
                 *
                 * « Tes alignements devraient etre toujours par defaut au milieu
                 * dans l'axe horizontal », Cyrille. Deux colonnes de hauteurs
                 * differentes collees en haut laissent un vide sous la plus
                 * courte, et c'est ce vide qu'on voit. Au milieu, les deux se
                 * repondent.
                 *
                 * LE REPLI SUIT LE MANIFESTE : une rangee enregistree avant ce
                 * jour porte sa valeur, et ne bouge pas. Seules les rangees sans
                 * valeur du tout, ou neuves, prennent le nouveau defaut.
                 */
                'hauteur'  => (string) ($rangee->hauteur ?? 'center'),
                'classe'   => $this->classeSaisie($rangee->classe ?? ''),
                'attrId'   => '',
                'cases'    => [],
            ];

            $identifiant = trim((string) ($rangee->identifiant ?? ''));

            if ($identifiant !== '') {
                $r->attrId = ' id="' . htmlspecialchars($identifiant, ENT_QUOTES, 'UTF-8') . '"';
            }

            // Une case par colonne permise, toujours, meme vide.
            foreach ($codes as $code) {
                $r->cases[$code] = [];
            }

            $sortie[$rang + 1] = $r;
        }

        foreach ($blocs as $bloc) {
            $numero = (int) ($bloc->rangee ?? 1);

            if (!isset($sortie[$numero])) {
                continue;
            }

            $rangee = $sortie[$numero];
            $code   = strtolower(substr((string) ($bloc->colonne ?? 'p'), 0, 1));

            /*
             * UN CODE HORS DE LA RANGEE RETOMBE SUR SA PREMIERE COLONNE, et ce
             * n'est pas une correction silencieuse : c'est ce que l'aide du
             * reglage promet. Un bloc pose a droite puis une rangee ramenee a
             * une colonne doit rester visible, pas disparaitre.
             */
            if (!isset($rangee->cases[$code])) {
                $code = $rangee->codes[0];
            }

            $bloc->type   = (string) ($bloc->type ?? 'ouverture');
            $bloc->classe = $this->classeSaisie($bloc->classe ?? '');

            /*
             * LE CADRE S'AJOUTE A LA CLASSE DU BLOC, ET C'EST TOUT.
             *
             * Chaque mise en page ecrit deja `$bloc->classe` sur son conteneur,
             * quel que soit son type : l'encadrement profite donc a l'ouverture
             * comme aux cartes, a la galerie et au carrousel, sans qu'aucun des
             * quatre fichiers n'ait a le savoir.
             */
            $cadre = (string) ($bloc->cadre ?? '');

            if (\in_array($cadre, ['doux', 'teinte', 'trait'], true)) {
                $bloc->classe = trim($bloc->classe . ' opus__cadre opus__cadre--' . $cadre);
            }
            $bloc->attrId = '';

            $identifiant = trim((string) ($bloc->identifiant ?? ''));

            if ($identifiant !== '') {
                $bloc->attrId = ' id="' . htmlspecialchars($identifiant, ENT_QUOTES, 'UTF-8') . '"';
            }

            /*
             * LE CONTENU EST PREPARE ICI, UNE FOIS, ET SELON LE TYPE DU BLOC.
             *
             * Les titres des cartes descendent d'un cran : une carte vit dans
             * une rangee, elle n'est pas au meme rang qu'un titre d'ouverture.
             */
            $bloc->elements = $this->preparer($this->elements($bloc->elements ?? null), $niveauDepart);
            $bloc->cartes   = $this->preparer($this->elements($bloc->cartes ?? null), $niveauDepart + 1);

            /*
             * CHAQUE CARTE PREPARE SA PROPRE PILE.
             *
             * Depuis le 22 septembre 2026 une carte n est plus faite de trois
             * champs fixes mais d une pile d elements, comme l ouverture. Le
             * quatrieme niveau du formulaire (blocs > cartes > elements >
             * boutons) se replie donc ici en une liste prete a dessiner.
             *
             * LES TITRES DESCENDENT ENCORE D UN CRAN : le bloc Cartes est deja
             * a `niveauDepart + 1`, et un titre de carte vit sous le titre de
             * la rangee qui la porte.
             */
            foreach ($bloc->cartes as $carte) {
                $carte->pile = $this->preparer(
                    $this->elements($carte->elements ?? null),
                    $niveauDepart + 1
                );
            }

            /*
             * LE BLOC ONGLETS, 24 septembre 2026 : MEME MECANIQUE QUE LES
             * CARTES, A LA LETTRE.
             *
             * « Voila un exemple avec la mise en page Cartes. Je veux la meme
             * chose, mais pour des onglets », Cyrille, apres trois essais rates
             * ou j'en avais fait un element a quatre champs fixes. Un onglet
             * est un CONTENANT : il porte son titre, qui fait le bouton, et une
             * pile d'elements qu'on ordonne librement.
             *
             * UN ONGLET SANS TITRE NE SORT PAS, et la regle est plus dure
             * qu'ailleurs : un onglet sans titre donnerait dans la barre un
             * bouton VIDE, que personne ne pourrait nommer ni atteindre au
             * clavier. Un onglet sans contenu, lui, reste : le titre suffit a
             * en faire un onglet, et la pile se remplira.
             *
             * LES TITRES DESCENDENT D'UN CRAN, comme dans une carte : ce qui
             * est dans un panneau vit sous le titre qui porte le bloc.
             */
            $bloc->onglets = $this->preparer($this->elements($bloc->onglets ?? null), $niveauDepart + 1);

            $gardes = [];

            foreach ($bloc->onglets as $onglet) {
                $onglet->titre = trim((string) ($onglet->titre ?? ''));

                if ($onglet->titre === '') {
                    continue;
                }

                $onglet->dispo = \in_array(($onglet->dispo ?? 'empile'), ['media-droite', 'media-gauche'], true)
                    ? $onglet->dispo
                    : 'empile';

                $onglet->actif = (string) ($onglet->actif ?? '0') === '1';

                $onglet->pile = $this->preparer(
                    $this->elements($onglet->elements ?? null),
                    $niveauDepart + 1
                );

                $gardes[] = $onglet;
            }

            $bloc->onglets = $gardes;

            /*
             * LA FRISE, 24 septembre 2026 : ENCORE LA MEME MECANIQUE.
             *
             * « Un montage sur deux axes pour presenter une echelle de temps,
             * par exemple une entreprise qui evolue », Cyrille. Une etape porte
             * son repere, la date ou le jalon, et une pile d'elements.
             *
             * UNE ETAPE SANS REPERE NI CONTENU NE SORT PAS. Contrairement a un
             * onglet, dont le titre se voit seul dans la barre, une etape vide
             * ne dessinerait qu'une pastille sur l'axe, sans rien a cote : un
             * trou que rien n'explique.
             */
            $bloc->etapes = $this->preparer($this->elements($bloc->etapes ?? null), $niveauDepart + 1);

            $gardesEtapes = [];

            foreach ($bloc->etapes as $etape) {
                $etape->repere = trim((string) ($etape->repere ?? ''));

                $etape->pile = $this->preparer(
                    $this->elements($etape->elements ?? null),
                    $niveauDepart + 1
                );

                if ($etape->repere === '' && $etape->pile === []) {
                    continue;
                }

                /*
                 * LE TON EST FILTRE CONTRE UNE LISTE FERMEE, comme partout
                 * ailleurs : une valeur inventee ecrirait une classe qui
                 * n'existe pas, et la feuille resterait muette.
                 */
                $ton = (string) ($etape->tonEtape ?? '');

                $etape->ton = \in_array($ton, ['accent', 'succes', 'alerte', 'erreur'], true) ? $ton : '';

                $gardesEtapes[] = $etape;
            }

            $bloc->etapes = $gardesEtapes;

            if ($bloc->type === 'onglets' && $gardes !== []) {
                $this->onglets = true;
            }

            /*
             * UN BLOC QUI NE DESSINERA RIEN N'OCCUPE PAS DE COLONNE.
             *
             * La mise en page ecarte deja un bloc vide, mais trop tard : la
             * colonne etait ecrite avant qu'on sache que son contenu se
             * tairait. Resultat vu sur le banc le 21 septembre 2026, un bloc
             * Cartes ajoute et pas encore rempli : `<div class="colonne-7
             * opus__colonne"></div>`, sept douziemes de page blancs, et
             * l'ouverture d'a cote enfermee dans ses cinq douziemes.
             *
             * LA CARTE DU MONTAGE LE DISAIT DEJA, elle affichait « a remplir ».
             * Elle promet de ne montrer que ce qui sortira ; c'etait donc la
             * page qui avait tort, pas elle.
             */
            if (!$this->blocRempli($bloc)) {
                continue;
            }

            $rangee->cases[$code][] = $bloc;
        }

        /*
         * LE RAPPORT SAISI EST LE RAPPORT RENDU, MEME QUAND UNE COLONNE EST
         * VIDE.
         *
         * CE BLOC A DIT L'INVERSE PENDANT UNE JOURNEE, et les deux versions
         * viennent d'une mesure, d'ou la note. Le 21 septembre, une rangee en
         * 5/7 dont la GAUCHE etait vide sortait son contenu en `colonne-7`
         * colle au bord gauche : sept douziemes de contenu la ou l'auteur en
         * attendait cinq, et cinq douziemes de blanc au mauvais endroit. La
         * reponse d'alors : redistribuer les douze douziemes entre les
         * survivantes.
         *
         * Le 22 septembre a 16 h, Cyrille pose l'autre moitie du probleme :
         * « je devrais avoir l'ouverture seulement sur la gauche sur un
         * rapport de 7/5, ce n'est pas le cas ». Mesure : `colonne-12` au lieu
         * de `colonne-7`. La redistribution avalait le vide de DROITE, qui est
         * pourtant une respiration voulue, c'est meme ainsi qu'on obtient une
         * colonne de texte etroite sans rien poser a cote.
         *
         * LA REGLE QUI SATISFAIT LES DEUX : le vide de droite se garde, le
         * vide de gauche se comble. Une colonne vide qui precede du contenu
         * sort en placeholder, pour que la grille pose le contenu dans sa
         * case ; une colonne vide qui ne precede rien ne sort pas, et ses
         * douziemes restent blancs. Le rapport saisi n'est plus jamais
         * recalcule.
         */
        foreach ($sortie as $rangee) {
            $pleines = [];

            foreach ($rangee->codes as $index => $code) {
                if ($rangee->cases[$code] !== []) {
                    $pleines[] = $index;
                }
            }

            if ($pleines === []) {
                $rangee->codes = [];

                continue;
            }

            // Tout ce qui suit la derniere colonne pleine ne sort pas.
            $dernier = $pleines[\count($pleines) - 1];
            $codes   = [];
            $parts   = [];

            foreach ($rangee->codes as $index => $code) {
                if ($index > $dernier) {
                    continue;
                }

                $codes[] = $code;
                $parts[] = max(1, (int) $rangee->parts[$index]);
            }

            $rangee->codes = $codes;
            $rangee->parts = $parts;

            /*
             * UN FOND POSE SUR UNE COLONNE QUI NE SORT PLUS REVIENT SUR LA
             * RANGEE, sinon l'aplat n'est dessine nulle part et le reglage
             * semble sans effet.
             */
            if ($rangee->fondSur !== '' && !\in_array($rangee->fondSur, $codes, true)) {
                $rangee->fondSur = '';
            }
        }

        /*
         * UNE RANGEE SANS AUCUN BLOC NE SORT PAS.
         *
         * Sans ce filtre, une rangee ajoutee puis oubliee laissait une bande
         * vide dans la page, avec sa gouttiere et son fond. C'est la regle de
         * Corpus pour ses gabarits, et l'aide du champ la dit.
         */
        return array_values(array_filter($sortie, function ($rangee) {
            foreach ($rangee->cases as $blocs) {
                if ($blocs !== []) {
                    return true;
                }
            }

            return false;
        }));
    }

    /**
     * Reprend la saisie d'un module regle avant le modele rangees + blocs.
     *
     * POURQUOI ELLE EXISTE. Le 21 septembre 2026, les quatre listes de contenu
     * et le champ `layout` ont ete remplaces par des rangees et des blocs. Les
     * anciens noms de reglages restent en base : sans cette reprise, un module
     * deja rempli remontait VIDE apres la mise a jour, et sa saisie semblait
     * perdue alors qu'elle etait toujours la.
     *
     * ELLE NE S'EXECUTE QU'A VIDE. Des qu'une rangee existe, elle ne touche
     * plus a rien : un module repris puis modifie ne doit jamais se faire
     * reecrire par l'ancienne saisie restee en base.
     *
     * ELLE N'ENREGISTRE RIEN. Elle fabrique le montage a l'affichage ; c'est le
     * premier enregistrement depuis l'ecran de reglage qui fixe le nouveau
     * modele. Un module qu'on ne rouvre jamais continue donc de sortir la meme
     * page, indefiniment.
     *
     * @return array<int, object> Les rangees deduites, ou un tableau vide.
     */
    protected function reprise(Registry $params): array
    {
        $layout = (string) $params->get('layout', '');

        if ($layout === '') {
            return [];
        }

        // `_:atouts` pour un fichier du module, `corpus:atouts` pour une
        // surcharge du template : seule la forme nous interesse.
        $i = strpos($layout, ':');
        $forme = $i === false ? $layout : substr($layout, $i + 1);

        $ouverture = $params->get('opening');
        $cartes    = $params->get('cards');
        $diapos    = $params->get('slides');
        $images    = $params->get('images');

        // Les dispositions a deux colonnes gardent leur rapport et leur cote.
        $aDeuxColonnes = \in_array($forme, ['atouts', 'illustration'], true);
        $rapport = $aDeuxColonnes ? (string) $params->get('rowRatio', '5-7') : '';
        $gauche  = (string) $params->get('rowOpeningSide', 'left') === 'left';

        $fonds = ['tinted' => 'section--tint', 'alternate' => 'section--alt'];
        $ancienFond = (string) $params->get('rowBackground', 'none');

        $rangee = (object) [
            'colonnes' => $aDeuxColonnes ? 2 : 1,
            'rapport'  => $rapport,
            'fond'     => $fonds[$ancienFond] ?? '',
            'fondSur'  => '',
            'hauteur'  => (string) $params->get('rowVerticalAlign', 'start'),
            'show'     => '1',
        ];

        $blocs = [];

        $poser = function (string $type, $contenu, string $colonne) use (&$blocs) {
            if (empty($contenu)) {
                return;
            }

            $bloc = (object) ['type' => $type, 'rangee' => 1, 'colonne' => $colonne, 'show' => '1'];

            if ($type === 'ouverture') {
                $bloc->elements = $contenu;
            } elseif ($type === 'carrousel') {
                $bloc->diapos = $contenu;
            } else {
                $bloc->cartes = $contenu;
            }

            $blocs[] = $bloc;
        };

        /*
         * LES SIX ANCIENNES DISPOSITIONS RETOMBENT SUR DEUX BLOCS.
         *
         * Le module n'en dessine plus que deux : l'ouverture et les cartes.
         * Un carrousel ou une galerie regles avant la bascule reviennent donc
         * en grille de cartes, avec leur contenu : image, titre, texte et lien
         * sont les memes champs, rien n'est perdu, et la page change d'allure
         * sans se vider. Mieux vaut cela qu'un module devenu blanc.
         */
        switch ($forme) {
            case 'atouts':
            case 'illustration':
                $poser('ouverture', $ouverture, $gauche ? 'g' : 'd');
                $poser('cartes', $cartes, $gauche ? 'd' : 'g');
                break;

            case 'carrousel':
                $poser('cartes', $diapos, 'p');
                break;

            case 'galerie':
                $poser('cartes', $images, 'p');
                break;

            case 'portraits':
                $poser('cartes', $cartes, 'p');
                break;

            default:
                $poser('ouverture', $ouverture, 'p');
                break;
        }

        if ($blocs === []) {
            return [];
        }

        return [$rangee, $blocs];
    }

    /**
     * Le contenu d'un bloc a-t-il quelque chose a montrer ?
     *
     * La mise en page pose la question avant d'ecrire le conteneur du bloc :
     * un cadre vide prend sa marge dans la page et se cherche dans
     * l'inspecteur.
     */
    public function blocRempli(object $bloc): bool
    {
        if ($bloc->type === 'ouverture') {
            return $bloc->elements !== [];
        }

        /*
         * UN ONGLET SUFFIT A REMPLIR LE BLOC, MEME SANS CONTENU, et c'est la
         * difference avec une carte : le titre d'un onglet se voit tout seul
         * dans la barre. Un onglet titre mais vide dessine donc quelque chose,
         * et le bloc doit garder sa colonne. Les onglets sans titre, eux, ont
         * deja ete ecartes a la lecture.
         */
        if ($bloc->type === 'onglets') {
            return $bloc->onglets !== [];
        }

        /*
         * UNE FRISE SANS ETAPE N'EST PAS UNE FRISE : elle ne dessinerait qu'un
         * axe nu. Les etapes vides ont deja ete ecartees a la lecture.
         */
        if ($bloc->type === 'frise') {
            return $bloc->etapes !== [];
        }

        /*
         * UNE CARTE VIDE NE COMPTE PAS. Trois cartes ajoutees et pas encore
         * remplies, c est un bloc qui ne dessinera rien : il ne doit donc pas
         * reserver sa colonne. La mise en page ecarte les memes cartes, une a
         * une ; ici on repond pour le bloc entier.
         */
        foreach ($bloc->cartes as $carte) {
            if (!empty($carte->pile)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Le niveau de titre de depart.
     *
     * Un module vit hors du contenu principal : son titre est un h2. Il
     * descend a h3 quand la page affiche deja son propre titre, pour ne pas
     * doubler le rang. Aucun niveau n'est jamais ecrit en dur dans une mise en
     * page.
     */
    public function niveauDepart(CMSApplicationInterface $app): int
    {
        $menu = $app->getMenu() ? $app->getMenu()->getActive() : null;

        if ($menu && (int) $menu->getParams()->get('show_page_heading', 0) === 1) {
            return 3;
        }

        return 2;
    }

    /**
     * La balise d'un titre, depuis le choix de l'utilisateur et le niveau de
     * depart. « Automatique » suit le contexte, un choix explicite l'emporte.
     */
    public function baliseTitre(?string $choix, int $depart): string
    {
        $choix = (string) $choix;

        if (preg_match('/^h[2-6]$/', $choix)) {
            return $choix;
        }

        return 'h' . min(6, max(2, $depart));
    }

    /**
     * La classe d'alignement d'un element.
     *
     * Une classe par valeur, jamais un style en ligne : un style en ligne ne
     * se surcharge qu'avec un `!important`, et c'est la spirale qu'on refuse.
     */
    public function classeAlignement(?string $valeur): string
    {
        switch ((string) $valeur) {
            case 'center':
                return 'opus__el--center';
            case 'end':
                return 'opus__el--end';
            default:
                return '';
        }
    }

    /**
     * Le lien d'un element : adresse, cible, et ce qu'il faut annoncer.
     *
     * Rend un tableau vide quand il n'y a pas de lien, pour que la mise en page
     * n'ait qu'un `if` a ecrire.
     *
     * NOUVEL ONGLET : `rel="noopener"` et la mention « nouvelle fenetre » sont
     * ajoutes d'office. Le RGAA exige de prevenir l'ouverture d'une nouvelle
     * fenetre, et personne ne pense a l'ecrire a la main.
     */
    public function lien(object $element, string $prefixe = ''): array
    {
        /*
         * LE PREFIXE SERT AUX BOUTONS, QUI ONT CHACUN LEUR LIEN.
         *
         * L'element porte `linkType`, `linkMenu`, `linkUrl`, `linkNewTab` ; un
         * bouton porte `button2LinkType`, `button2LinkMenu`, et ainsi de suite.
         * Une seule fonction lit les deux : trois copies de ces trente lignes
         * auraient fini par diverger, et c'est toujours celle qu'on a oubliee
         * qui garde le defaut.
         *
         * `$prefixe` vide rend donc exactement le comportement d'avant.
         */
        $champ = static function (string $nom) use ($prefixe): string {
            return $prefixe === '' ? $nom : $prefixe . ucfirst($nom);
        };

        $type = (string) ($element->{$champ('linkType')} ?? 'none');

        if ($type === 'none') {
            return [];
        }

        $href = '';

        if ($type === 'menu') {
            $itemid = (int) ($element->{$champ('linkMenu')} ?? 0);

            if ($itemid > 0) {
                $href = Route::_('index.php?Itemid=' . $itemid);
            }
        } elseif ($type === 'url') {
            $href = trim((string) ($element->{$champ('linkUrl')} ?? ''));
        }

        if ($href === '') {
            return [];
        }

        /*
         * LE NOUVEL ONGLET NE SE NOMME PAS PAREIL DES DEUX COTES : l'element
         * porte `linkNewTab`, un bouton porte `button2NewTab`, sans le mot
         * « Link ». On regarde donc les deux, plutot que d'imposer un nom au
         * manifeste pour arranger cette fonction.
         */
        $nouvelOnglet = (int) (
            $element->{$prefixe === '' ? 'linkNewTab' : $prefixe . 'NewTab'}
            ?? $element->{$champ('linkNewTab')}
            ?? 0
        ) === 1;

        return [
            'href'     => $href,
            'target'   => $nouvelOnglet ? '_blank' : '',
            'rel'      => $nouvelOnglet ? 'noopener' : '',
            'mention'  => $nouvelOnglet ? Text::_('MOD_OPUS_NEW_WINDOW') : '',
        ];
    }

    /**
     * Les boutons d'un element, prets a poser.
     *
     * UNE LISTE, ET PLUS TROIS CHAMPS FIGES. Le manifeste portait
     * `button1Text`, `button2Text`, `button3Text` et leurs sept champs chacun
     * jusqu'au 22 septembre 2026. Trois au maximum, aucun deplacement, aucune
     * duplication : c'etait le prix d'une prudence sur l'imbrication, et
     * Cyrille a tranche l'autre sens. La liste est un sous-formulaire de plus,
     * au troisieme niveau, `blocs > elements > boutons`.
     *
     * UN BOUTON SANS LIBELLE NE SORT PAS. Ce n'est pas une correction
     * silencieuse : l'aide du champ le dit, et la carte du montage ne le
     * montre pas non plus.
     *
     * `lien()` EST APPELEE SANS PREFIXE, et c'est tout l'interet des noms
     * choisis dans le manifeste : une ligne de bouton porte `linkType`,
     * `linkMenu`, `linkUrl`, `linkNewTab`, exactement ce que la fonction
     * attend d'un element. Les trente lignes du lien ne sont ecrites qu'une
     * fois.
     *
     * @return array  Liste de boutons : libelle, variante, icones, lien.
     */
    /**
     * LES ICONES DECLAREES PAR L'ADMINISTRATEUR, nom => fichier.
     *
     * Lues une fois par rendu et gardees : les mises en page les demandent une
     * fois par bouton, et relire le parametre a chaque fois n'apprendrait rien
     * de nouveau.
     */
    private array $miennes = [];

    public function poserMesIcones($brut): void
    {
        $this->miennes = [];

        /*
         * LA MEME DONNEE ARRIVE SOUS TROIS FORMES, ET LA TROISIEME MANQUAIT
         * ICI.
         *
         * Tableau quand elle vient d'etre envoyee, objet quand elle sort du
         * Registry, CHAINE JSON quand le Registry ne l'a pas encore decodee.
         * Les deux champs d'administration lisaient bien les trois ; la page
         * publique, non. Resultat mesure le 25 septembre 2026 : le bouton
         * portait « perso:minions », la liste d'administration l'offrait, et
         * le site ne dessinait rien, sans erreur.
         */
        if (\is_string($brut)) {
            $decode = json_decode($brut);
            $brut   = $decode === null ? [] : $decode;
        }

        if (\is_object($brut)) {
            $brut = (array) $brut;
        }

        if (!\is_array($brut)) {
            return;
        }

        foreach ($brut as $ligne) {
            $ligne = (array) $ligne;

            $nom     = strtolower(preg_replace('#[^A-Za-z0-9-]#', '-', trim((string) ($ligne['nom'] ?? ''))));
            $fichier = trim((string) ($ligne['fichier'] ?? ''));

            if ($nom === '' || $nom === '-' || $fichier === '') {
                continue;
            }

            $this->miennes[$nom] = $fichier;
        }
    }

    /**
     * LE PICTOGRAMME D'UN BOUTON, ET LE SEUL ENDROIT QUI CHOISIT COMMENT.
     *
     * DEUX MECANIQUES, ET LE NOM DIT LAQUELLE. Un nom ordinaire, `i-fleche`,
     * est un symbole de la planche : on ecrit un `<use>`, et c'est ce que fait
     * le template depuis toujours. Un nom prefixe de `perso:` est un FICHIER
     * choisi par l'administrateur : on le pose en MASQUE.
     *
     * POURQUOI UN MASQUE ET PAS UNE IMAGE. Une `<img>` garde les couleurs du
     * fichier : sur un bouton plein, un dessin noir devient invisible, et sur
     * un bouton de couleur il jure. Un masque ne reprend que la FORME et la
     * remplit de `currentColor`, donc de la couleur du texte du bouton. Une
     * icone a soi se comporte alors exactement comme une icone livree.
     *
     * ON NE REMET JAMAIS LE CONTENU DU FICHIER DANS LA PAGE. Le chemin part
     * dans une `url()`, le navigateur va le chercher comme une image et n'en
     * lit que les pixels : un SVG pose en masque ne peut porter ni script ni
     * lien. C'est ce qui permet d'accepter un fichier choisi dans le
     * gestionnaire de medias sans avoir a le relire.
     *
     * @param   string  $nom  La valeur enregistree dans le champ Icone.
     *
     * @return  string  Le balisage, ou la chaine vide s'il n'y a pas d'icone.
     */
    public function picto(string $nom): string
    {
        $nom = trim($nom);

        if ($nom === '') {
            return '';
        }

        /*
         * LE PICTOGRAMME DOUBLE LE LIBELLE, IL NE LE REMPLACE JAMAIS.
         * `aria-hidden` et `focusable="false"` dans les deux cas : un lecteur
         * d'ecran lit le mot du bouton, pas le dessin.
         */
        if (strpos($nom, 'perso:') !== 0) {
            return '<svg class="i" aria-hidden="true" focusable="false"><use href="#'
                . htmlspecialchars($nom, ENT_QUOTES, 'UTF-8')
                . '"></use></svg>';
        }

        $clef = substr($nom, 6);

        /*
         * UNE ICONE SUPPRIMEE NE LAISSE PAS UN TROU. L'administrateur peut
         * retirer une ligne de l'onglet Icones alors qu'un bouton la nomme
         * encore : le bouton garde son libelle et perd son dessin, ce qui est
         * la bonne facon d'echouer.
         */
        if (!isset($this->miennes[$clef])) {
            return '';
        }

        $fichier = HTMLHelper::_('cleanImageURL', $this->miennes[$clef]);
        $url     = \is_object($fichier) ? ($fichier->url ?? '') : (string) $fichier;

        /*
         * `cleanImageURL` PEUT RENDRE VIDE : un fichier renomme ou supprime
         * depuis, un adaptateur inconnu. On retombe sur le chemin brut ampute
         * de son fragment, qui reste la meilleure reponse possible. Le meme
         * repli que dans le champ d'administration, pour que l'apercu et la
         * page publique montrent la meme chose.
         */
        if ($url === '') {
            $url = explode('#', (string) $this->miennes[$clef])[0];
        }

        if ($url === '') {
            return '';
        }

        /*
         * L'ADRESSE EST RENDUE ABSOLUE. Le gestionnaire de medias enregistre
         * un chemin relatif a la racine du site. En page publique la balise
         * `<base>` de Joomla le fait tomber juste, mais un module peut etre
         * rendu hors de ce cadre, dans un flux ou une previsualisation, et le
         * chemin y serait resolu depuis ailleurs. Le meme calcul que dans le
         * champ d'administration, ou l'absence de `<base>` sortait un 404.
         */
        if (!preg_match('#^(?:https?:)?//|^/#', $url)) {
            $url = Uri::root(true) . '/' . ltrim($url, '/');
        }

        /*
         * L'URL EST ECHAPPEE DEUX FOIS, pour deux langages. `htmlspecialchars`
         * la met a l'abri dans l'attribut `style`, et les apostrophes et
         * parentheses sont retirees avant, parce qu'elles fermeraient l'`url()`
         * du CSS, ce que l'echappement HTML ne voit pas.
         */
        $url = str_replace(["'", '"', '(', ')', "\n", "\r"], '', $url);

        return '<span class="i i--perso" aria-hidden="true" style="--opus-icone:url(\''
            . htmlspecialchars($url, ENT_QUOTES, 'UTF-8')
            . '\')"></span>';
    }

    public function boutons(object $element): array
    {
        $boutons = [];

        foreach ($this->elements($element->boutons ?? null) as $ligne) {
            $libelle = trim((string) ($ligne->text ?? ''));

            if ($libelle === '') {
                continue;
            }

            $boutons[] = (object) [
                'libelle'  => $libelle,
                'variante' => $this->varianteBouton((string) ($ligne->variant ?? '')),
                'taille'   => (string) ($ligne->taille ?? '') === 'petit' ? 'petit' : '',
                'classe'   => $this->classeSaisie($ligne->classe ?? ''),
                'avant'    => (string) ($ligne->iconBefore ?? ''),
                'apres'    => (string) ($ligne->iconAfter ?? ''),
                'lien'     => $this->lien($ligne),
            ];
        }

        return $boutons;
    }

    /**
     * LE NOM DE VARIANTE QUE CORPUS HABILLE VRAIMENT.
     *
     * MESURE DU 22 SEPTEMBRE 2026, DANS LE NAVIGATEUR, SUR LE BANC. Le module
     * ecrivait `bouton--contour` et `bouton--lien`. Ces deux classes
     * n'existent nulle part dans `template.css` : les trois formats rendaient
     * donc le MEME bouton, aplat plein, et personne ne s'en etait apercu parce
     * qu'un bouton plein est plausible. Releve : fond, texte, bordure et
     * retrait identiques au pixel pour les trois valeurs.
     *
     * Corpus habille `.bouton`, `.bouton--second` et `.bouton--tertiaire` :
     * plein, contour sur fond clair, texte souligne sans cadre. Ce sont ces
     * noms-la, et c'est la regle du projet, quand Corpus nomme deja une chose
     * on reprend son nom.
     *
     * LES ANCIENNES VALEURS SONT TRADUITES, PAS JETEES. Un montage enregistre
     * avant aujourd'hui porte `contour` ou `lien` : il doit rendre ce que son
     * auteur croyait avoir choisi, pas retomber sur le format plein.
     */
    public function varianteBouton(string $valeur): string
    {
        switch ($valeur) {
            case 'second':
            case 'contour':
                return 'second';

            case 'tertiaire':
            case 'lien':
                return 'tertiaire';

            default:
                return '';
        }
    }

    /**
     * Une image du champ media du coeur, prete a poser.
     *
     * `cleanImageURL` du coeur retire le fragment `#joomlaImage://...` et rend
     * au passage la largeur et la hauteur enregistrees : les ecrire dans la
     * balise evite le decalage de la page au chargement, sans que personne ait
     * a les saisir.
     */
    /**
     * Les classes d une image, d apres ses reglages.
     *
     * TOUT PASSE PAR DES CLASSES, JAMAIS PAR DU STYLE EN LIGNE, sauf la largeur
     * maximale, qui est un nombre saisi et ne peut pas s ecrire autrement. Une
     * classe se surcharge depuis l onglet CSS personnalise du template ; un
     * style en ligne ne se surcharge qu a coups de `!important`, et la regle de
     * Corpus est qu on n en ecrit pas.
     *
     * L HABILLAGE NE DIT PAS A QUOI IL RESSEMBLE. La classe dit « habillee », et
     * c est la feuille du module qui va chercher les jetons de forme de Corpus.
     * Le module ne choisit donc jamais une epaisseur ni un rayon.
     *
     * @return string Les classes, pretes a poser, sans espace en trop.
     */
    public function habillageImage(object $el): string
    {
        $classes = ['opus__image'];

        $format = (string) ($el->imgFormat ?? '');

        // Seuls les quatre rapports connus sont acceptes : une valeur inventee
        // sortirait une classe que personne n habille.
        if (\in_array($format, ['16-9', '4-3', '1-1', '3-4'], true)) {
            $classes[] = 'opus__image--' . $format;

            if (($el->imgCadrage ?? 'cover') === 'contain') {
                $classes[] = 'opus__image--entiere';
            }
        }

        $habillage = (string) ($el->imgHabillage ?? 'habillee');

        /*
         * « Icone » EST UN RACCOURCI, PAS UN MOTEUR DE PLUS.
         *
         * « Parfois c est juste une icone », Cyrille, 23 septembre 2026. Le cas
         * se reglait deja, en deux temps : habillage nu, puis largeur limitee a
         * trois ou quatre rem. Mais le defaut « habillee » pose une bordure et
         * un angle autour d un pictogramme de 48 px, et rien ne laisse deviner
         * qu il faut deux reglages pour l enlever.
         *
         * UNE SEULE CLASSE PORTE LES DEUX : ni bordure, ni angle, et une taille
         * d icone. Le plafond de largeur, s il est demande, la surcharge, parce
         * qu il s ecrit en style et passe donc devant.
         */
        if (\in_array($habillage, ['nue', 'ronde', 'icone'], true)) {
            $classes[] = 'opus__image--' . $habillage;
        }

        if (($el->imgLargeur ?? 'pleine') === 'limitee') {
            $classes[] = 'opus__image--plafond';
        }

        return implode(' ', $classes);
    }

    public function image($champ): array
    {
        if (empty($champ)) {
            return [];
        }

        $champ = \is_string($champ) ? json_decode($champ) : (object) $champ;

        $src = trim((string) ($champ->imagefile ?? ''));

        if ($src === '') {
            return [];
        }

        $propre = HTMLHelper::cleanImageURL($src);
        $alt    = (string) ($champ->alt_text ?? '');

        return [
            'src'    => $propre->url,
            'width'  => $propre->attributes['width'] ?? 0,
            'height' => $propre->attributes['height'] ?? 0,
            // alt vide ASSUME : l'image est decorative, le lecteur d'ecran la saute.
            'alt'    => (int) ($champ->alt_empty ?? 0) === 1 ? '' : $alt,
        ];
    }

    /**
     * Le seul style en ligne d une image : son plafond de largeur.
     *
     * DEUX UNITES, ET CHACUNE A SA RAISON. Le rem suit la taille de texte du
     * visiteur : c est ce qu il faut pour une photo, qui accompagne un texte et
     * doit grandir avec lui. Le pixel ne suit rien : c est ce qu il faut pour
     * un logo ou un pictogramme, qu on pose a une taille exacte.
     *
     * LES BORNES NE CORRIGENT PLUS EN SILENCE. La premiere version ramenait a
     * 40 toute valeur hors de 6 a 90 : un plafond de 2 rem, saisi pour une
     * petite image, ressortait a 40 sans un mot. Elle se contente desormais
     * d ecarter ce qui n est pas un nombre utilisable.
     */
    public function styleImage(object $el): string
    {
        if (($el->imgLargeur ?? 'pleine') !== 'limitee') {
            return '';
        }

        $max = (int) ($el->imgMax ?? 40);
        $unite = ($el->imgMaxUnite ?? 'rem') === 'px' ? 'px' : 'rem';

        // Zero ou negatif ferait disparaitre l image ; au-dela, la valeur ne
        // plafonne plus rien et autant ne rien ecrire.
        if ($max < 1) {
            return '';
        }

        if ($unite === 'px' && $max > 2000) {
            return '';
        }

        if ($unite === 'rem' && $max > 200) {
            return '';
        }

        return ' style="max-width: ' . $max . $unite . '"';
    }

    /**
     * Pose le CSS personnalise dans l'en-tete de page.
     *
     * UN SEUL DEPOT PAR MODULE. `addStyleDeclaration` concatene, donc un meme
     * module publie deux fois ecrirait deux fois la meme feuille. Le repere
     * statique l'empeche.
     */
    public function poserCss(Registry $params, $document): void
    {
        static $poses = [];

        $css = trim((string) $params->get('customCss', ''));

        if ($css === '') {
            return;
        }

        $repere = md5($css);

        if (isset($poses[$repere])) {
            return;
        }

        $poses[$repere] = true;

        $document->addStyleDeclaration($css);
    }
}
