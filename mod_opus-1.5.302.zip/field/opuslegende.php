<?php
/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Joomanji, Cyrille Poussin
 * @license     GNU General Public License version 2 or later
 *
 * CHAMP : LE TITRE D'UN GROUPE DE REGLAGES.
 *
 * POURQUOI IL EXISTE, 25 septembre 2026. Jusqu'au 25 septembre 2026, les deux
 * titres « Rangees » et « Blocs » etaient des champs `legend` pris dans le
 * dossier du template Corpus (`addfieldpath="/templates/corpus/admin/field"`).
 * Sur un site sans Corpus, ce type n'existe pas : Joomla retombe alors en
 * champ TEXTE, sans erreur ni message, et l'ecran montre une zone de saisie
 * vide a la place du titre. Decision de Cyrille le meme jour : « Opus doit
 * etre completement independant de Corpus ».
 *
 * CE QUI EST REPRIS DE `legend.php` DE CORPUS, ET RIEN D'AUTRE : le balisage
 * du titre (`h3.legend`, `span.legend-texte`), parce que `admin.css` et
 * `admin.js` s'y accrochent. Le rail de groupes, les pictogrammes et
 * l'interrupteur marche/arret n'ont jamais servi ici (`rail="0"`) : ils ne
 * sont pas copies.
 *
 * LA CLASSE `top-legend-group` DU GROUPE EST POSEE PAR LE MANIFESTE, avec
 * `parentclass`, que le coeur lit dans `FormField::setup()`. Chez Corpus,
 * c'est `legend.js` qui la posait apres coup, dans un rappel jQuery : le
 * module devait l'attendre. Posee au rendu, elle est la des le chargement.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Form\FormField;
use Joomla\CMS\Language\Text;

class JFormFieldOpusLegende extends FormField
{
    protected $type = 'OpusLegende';

    /**
     * Rien a saisir : le groupe ne porte que son titre.
     */
    protected function getInput()
    {
        return '';
    }

    /**
     * Le titre, a la place du libelle.
     *
     * Le texte est enveloppe dans son propre element : un noeud de texte nu
     * ne se designe pas en CSS, et `admin.js` lit ce mot pour reconnaitre un
     * double (« Blocs » sous « Les blocs »).
     */
    protected function getLabel()
    {
        $texte = Text::_((string) $this->element['label']);
        $depli = (string) $this->element['expend'] !== ''
            ? ' data-expend="' . htmlspecialchars((string) $this->element['expend'], ENT_QUOTES, 'UTF-8') . '"'
            : '';

        return '<h3 class="legend legend--sans-rail"' . $depli . '><span>'
            . '<span class="legend-texte">' . htmlspecialchars($texte, ENT_QUOTES, 'UTF-8') . '</span>'
            . '</span></h3>';
    }
}
