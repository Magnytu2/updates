<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * CHAMP : LA PLANCHE DES PICTOGRAMMES, EN ENTIER, POUR LA REGARDER.
 *
 * Demande de Cyrille, 25 septembre 2026 : « peut-on creer un onglet Icones
 * avec notre page d'icones ». Les listes deroulantes des boutons proposent
 * deja les noms, une par une ; elles ne montrent pas le dessin, et il faut
 * choisir « i-fleche » ou « i-chevron » sans les avoir vus cote a cote.
 *
 * LE MODULE NE TIENT AUCUN CATALOGUE, et c'est la meme regle que pour
 * `blocsicone.php` : il lit la planche du template et montre ce qu'il y
 * trouve. Une icone ajoutee dans Corpus apparait ici le jour meme, sans que ce
 * module soit relivre.
 *
 * ON N'INCLUT JAMAIS LE FICHIER, ON N'EN EXTRAIT QUE DES `<symbol>`.
 * `pictogrammes.php` est un fichier PHP : l'inclure l'executerait, et le
 * recopier tel quel sortirait son en-tete en clair. Une expression reguliere
 * ne retient donc que les blocs `<symbol id="i-...">...</symbol>`, dont l'id
 * suit un motif ferme. Ce qui n'est pas un symbole n'entre pas.
 *
 * ET CE QUI ENTRE EST RELU. Un `<symbol>` qui contiendrait un `<script`, un
 * attribut evenement ou une reference exterieure est ECARTE, pas nettoye :
 * nettoyer, c'est parier qu'on a pense a tout. Le fichier vient du template
 * donc d'une source de confiance ; ce garde couvre le cas d'un template tiers
 * qui declarerait la meme planche.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Form\FormField;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

class JFormFieldBlocsIcones extends FormField
{
    protected $type = 'BlocsIcones';

    /**
     * Le chemin de la planche, relatif a la racine du site.
     *
     * DEUX SOURCES, DANS CET ORDRE. Celle du TEMPLATE d'abord : un site sous
     * Corpus, ou un template enfant qui a redessine ses icones, garde les
     * siennes, et le module ne les remplace pas. A defaut, CELLE DU MODULE,
     * livree avec lui, qui rend Opus utilisable sous Cassiopeia comme sous
     * n'importe quel autre template.
     *
     * C'est la meme regle qu'en page publique, ou le repartiteur ne pose la
     * planche du module que s'il n'a pas trouve celle du template.
     */
    protected function planche(): string
    {
        $template = (string) $this->element['template'];
        $template = $template !== '' ? preg_replace('#\W#', '', $template) : 'corpus';

        $duTemplate = 'templates/' . $template . '/html/layouts/corpus/pictogrammes.php';

        if (is_file(JPATH_ROOT . '/' . $duTemplate)) {
            return $duTemplate;
        }

        return 'media/mod_opus/icones/pictogrammes.svg';
    }

    /**
     * Les symboles de la planche : le nom, et son trace.
     *
     * Rend un tableau vide si la planche est introuvable. Le champ dit alors
     * pourquoi, au lieu de dessiner une grille vide que rien n'explique.
     */
    protected function symboles(): array
    {
        $fichier = JPATH_ROOT . '/' . $this->planche();

        if (!is_file($fichier) || !is_readable($fichier)) {
            return [];
        }

        $contenu = file_get_contents($fichier);

        if ($contenu === false) {
            return [];
        }

        preg_match_all(
            '#<symbol\s+id="(i-[a-z0-9-]+)"[^>]*>(.*?)</symbol>#is',
            $contenu,
            $trouves,
            PREG_SET_ORDER
        );

        $symboles = [];

        foreach ($trouves as $un) {
            $nom    = $un[1];
            $entier = $un[0];

            /*
             * LE GARDE : ON ECARTE, ON NE NETTOIE PAS.
             *
             * Un `<symbol>` n'a besoin que de traces geometriques. Tout ce qui
             * pourrait agir, un script, un attribut `on...`, une reference
             * exterieure, un `foreignObject`, n'a rien a faire la. Sa presence
             * signale un fichier qui n'est pas celui qu'on croit : on saute ce
             * symbole plutot que d'essayer de le rendre inoffensif.
             */
            if (preg_match('#<script|<foreignObject|\son[a-z]+\s*=|javascript:|xlink:href\s*=\s*["\']\s*http#i', $entier)) {
                continue;
            }

            $symboles[$nom] = $entier;
        }

        ksort($symboles, SORT_STRING);

        return $symboles;
    }

    /**
     * Les icones que l'administrateur a declarees, nom => fichier.
     *
     * LUES DANS LE FORMULAIRE, PAS DANS LA BASE : une ligne ajoutee et pas
     * encore enregistree doit se voir ici, sinon la grille dirait le contraire
     * de ce que l'ecran montre juste au-dessus.
     */
    protected function mesIcones(): array
    {
        if (!$this->form) {
            return [];
        }

        /*
         * LE GROUPE DU CHAMP, PAS `params` ECRIT EN DUR. Les deux valent la
         * meme chose aujourd'hui ; le jour ou ce champ sert ailleurs, la
         * valeur en dur serait fausse et la grille muette, sans rien dire.
         */
        $groupe = $this->group !== '' ? $this->group : 'params';

        $brut = $this->form->getValue('iconesPerso', $groupe);

        /*
         * TROIS FORMES POSSIBLES POUR LA MEME DONNEE, ET IL FAUT LES TROIS.
         *
         * Un sous-formulaire arrive en tableau quand il vient d'etre envoye,
         * en objet quand il sort du Registry des parametres, et en CHAINE JSON
         * quand le Registry n'a pas encore ete decode. La troisieme est celle
         * qui manquait : `is_array` rendait faux, la methode rendait un
         * tableau vide, et la grille disait « aucune icone declaree » alors que
         * le formulaire juste en dessous en montrait une. Vu le 25 septembre
         * 2026.
         */
        if (\is_string($brut)) {
            $decode = json_decode($brut);
            $brut   = $decode === null ? [] : $decode;
        }

        if (\is_object($brut)) {
            $brut = (array) $brut;
        }

        if (!\is_array($brut)) {
            return [];
        }

        $miennes = [];

        foreach ($brut as $ligne) {
            $ligne = (array) $ligne;

            $nom     = strtolower(preg_replace('#[^A-Za-z0-9-]#', '-', trim((string) ($ligne['nom'] ?? ''))));
            $fichier = trim((string) ($ligne['fichier'] ?? ''));

            if ($nom === '' || $nom === '-' || $fichier === '') {
                continue;
            }

            /*
             * DEUX LIGNES DE MEME NOM NE S'ECRASENT PLUS EN SILENCE.
             *
             * Le nom sert de clef : une seconde ligne appelee comme la
             * premiere la remplacait, et l'icone d'avant disparaissait de la
             * grille sans un mot, alors que sa ligne etait toujours dans le
             * formulaire. On garde la premiere, la suivante est mise de cote,
             * et la grille le dit.
             */
            if (isset($miennes[$nom])) {
                $this->doublons[] = $nom;

                continue;
            }

            $miennes[$nom] = $fichier;
        }

        ksort($miennes, SORT_STRING);

        return $miennes;
    }

    /**
     * Les noms trouves plus d'une fois, remplis par `mesIcones`.
     */
    protected array $doublons = [];

    /**
     * Le fichier de l'icone en cours de dessin, pour en lire la famille.
     */
    protected string $sourceCourante = '';

    /**
     * La mesure a ecrire sous le nom, vide pour un symbole de la planche ou un
     * trace vectoriel.
     */
    protected function mesure(): string
    {
        if ($this->sourceCourante === '') {
            return '';
        }

        $mesure = $this->dimensions($this->sourceCourante);

        if ($mesure === '') {
            return '';
        }

        $classe = 'blocs-icones__taille';

        if ($this->mesureDouteuse($mesure)) {
            $classe .= ' blocs-icones__taille--douteuse';
        }

        return '<span class="' . $classe . '">' . $mesure . '</span>';
    }

    protected function getInput()
    {
        /*
         * DEUX MODES, DEUX COLONNES DE L'ECRAN - 25 septembre 2026.
         *
         * « Deux colonnes, a gauche les notres, a droite celles du client. »
         * Un seul champ rendait les deux series l'une sous l'autre, donc dans
         * la meme colonne. Le champ est declare deux fois dans le manifeste,
         * `mode="planche"` et `mode="perso"`, et la feuille place chacun dans
         * sa colonne. Le code de lecture, lui, reste unique.
         */
        return (string) $this->element['mode'] === 'perso'
            ? $this->mesIconesEnGrille()
            : $this->plancheEnGrille();
    }

    /**
     * LA PLANCHE : ce que le template, ou le module, met a disposition.
     */
    protected function plancheEnGrille(): string
    {
        $symboles = $this->symboles();

        if ($symboles === []) {
            /*
             * SANS PLANCHE, ON DIT POURQUOI. Dire « rien trouve » sans dire ou
             * l'on a cherche laisse l'administrateur sans prise.
             */
            return '<div class="blocs-icones blocs-icones--planche blocs-icones--vide">'
                . '<p>' . Text::_('MOD_OPUS_ICONS_NONE') . '</p>'
                . '<p class="blocs-icones__chemin"><code>'
                . htmlspecialchars($this->planche(), ENT_QUOTES, 'UTF-8')
                . '</code></p>'
                . '</div>';
        }

        /*
         * LA PLANCHE EST INJECTEE DANS LA PAGE D'ADMINISTRATION.
         *
         * `<use href="#i-accueil">` ne trouve un symbole que s'il est dans le
         * MEME document. La planche vit dans le template du SITE ; en
         * administration, elle n'est nulle part. On la pose donc ici, une fois,
         * masquee, et les `<use>` de la grille y puisent.
         *
         * `aria-hidden` ET `hidden` : elle ne se voit ni ne s'annonce, elle
         * sert de reserve de traces.
         */
        $planche = '<svg xmlns="http://www.w3.org/2000/svg" class="blocs-icones__planche" aria-hidden="true" hidden>'
            . implode('', $symboles)
            . '</svg>';

        $cases = '';

        $this->sourceCourante = '';

        foreach (array_keys($symboles) as $nom) {
            $cases .= $this->caseIcone($nom, $nom, '');
        }

        return '<div class="blocs-icones blocs-icones--planche">'
            . $planche
            . '<p class="blocs-icones__intro">' . Text::_('MOD_OPUS_ICONS_INTRO') . '</p>'
            . '<div class="blocs-icones__grille">' . $cases . '</div>'
            . '<p class="blocs-icones__compte">'
            . Text::plural('MOD_OPUS_ICONS_COUNT', \count($symboles))
            . '</p>'
            . '</div>';
    }

    /**
     * MES ICONES : celles que l'administrateur a declarees juste en dessous.
     *
     * ELLE SE PLACE AU-DESSUS DU FORMULAIRE, pas en dessous : on regarde ce
     * qu'on a avant d'en ajouter, et c'est aussi l'ordre de la colonne de
     * gauche, ou la planche se regarde avant de servir.
     */
    protected function mesIconesEnGrille(): string
    {
        $miennes = $this->mesIcones();

        if ($miennes === []) {
            /*
             * RIEN ENCORE, ET C'EST NORMAL. La grille vide dit quoi faire
             * plutot que de laisser un cadre muet au-dessus du formulaire.
             */
            return '<div class="blocs-icones blocs-icones--miennes blocs-icones--vide">'
                . '<p>' . Text::_('MOD_OPUS_MYICONS_EMPTY') . '</p>'
                . $this->aide()
                . '</div>';
        }

        $cases = '';

        foreach ($miennes as $nom => $fichier) {
            /*
             * L'APERCU EST POSE EN MASQUE, comme en page publique : c'est la
             * seule facon qu'il dise la verite. Une `<img>` montrerait le
             * fichier avec ses couleurs, et le dessin monochrome se
             * decouvrirait seulement une fois le bouton pose sur le site.
             */
            $url = $this->urlIcone($fichier);

            if ($url === '') {
                continue;
            }

            $this->sourceCourante = $fichier;

            $cases .= $this->caseIcone($nom, 'perso:' . $nom, $url);
        }

        $alerte = '';

        if ($this->doublons !== []) {
            $alerte = '<p class="blocs-icones__doublon">'
                . htmlspecialchars(
                    Text::sprintf('MOD_OPUS_MYICONS_DUPLICATE', implode(', ', array_unique($this->doublons))),
                    ENT_QUOTES,
                    'UTF-8'
                )
                . '</p>';
        }

        /*
         * LA LEGENDE EST SOUS LA GRILLE, et elle ne s'affiche que s'il y a
         * quelque chose a legender. Elle reprend le dessin de celle des
         * classes produites : un filet a gauche, un mot, une explication.
         */
        $legende = '<ul class="blocs-icones__legende">'
            . '<li class="blocs-icones__legende--trace">' . Text::_('MOD_OPUS_MYICONS_KIND_VECTOR') . '</li>'
            . '<li class="blocs-icones__legende--pixels">' . Text::_('MOD_OPUS_MYICONS_KIND_RASTER') . '</li>'
            . '<li class="blocs-icones__legende--opaque">' . Text::_('MOD_OPUS_MYICONS_KIND_OPAQUE') . '</li>'
            . '</ul>';

        return '<div class="blocs-icones blocs-icones--miennes">'
            . '<div class="blocs-icones__grille">' . $cases . '</div>'
            . $legende
            . $alerte
            . $this->aide()
            . '</div>';
    }

    /**
     * CE QU'UN FICHIER D'ICONE DOIT ETRE, ECRIT EN CLAIR SOUS LA GRILLE.
     *
     * « Ajoute une vraie description des images acceptees et egalement
     * l'exigence de construction des fichiers SVG. » Cyrille, 25 septembre
     * 2026.
     *
     * ELLE RESTE VISIBLE, elle ne passe pas derriere une pastille. Une aide
     * d'une ligne se lit au survol ; celle-ci a huit points et se consulte
     * pendant qu'on prepare un fichier dans un autre logiciel. La pastille est
     * faite pour rappeler, pas pour enseigner.
     *
     * ELLE EST DEPLIABLE, en `details` du langage, ferme par defaut : elle ne
     * doit pas pousser le formulaire vers le bas a chaque ouverture de
     * l'onglet. Aucun script, aucune classe a nous : le navigateur sait faire.
     */
    protected function aide(): string
    {
        $points = '';

        foreach (['1', '2', '3', '4', '5', '6', '7'] as $rang) {
            $points .= '<li>' . Text::_('MOD_OPUS_MYICONS_HELP_' . $rang) . '</li>';
        }

        return '<details class="blocs-icones__aide">'
            . '<summary>' . Text::_('MOD_OPUS_MYICONS_HELP_TITLE') . '</summary>'
            . '<p>' . Text::_('MOD_OPUS_MYICONS_HELP_FORMATS') . '</p>'
            . '<p class="blocs-icones__aide-titre">' . Text::_('MOD_OPUS_MYICONS_HELP_SVG') . '</p>'
            . '<ul>' . $points . '</ul>'
            . '</details>'
            . $this->sources();
    }

    /**
     * OU TROUVER DES ICONES LIBRES DE DROIT.
     *
     * « J'aimerais ajouter des liens vers des ressources web pour telecharger
     * des icones libres de droit. » Cyrille, 25 septembre 2026, qui avait
     * trouve les siennes sur Icons8.
     *
     * LA LICENCE EST ECRITE A COTE DU NOM, et c'est le point de la liste.
     * « Gratuit » ne veut pas dire « libre » : Icons8 demande de citer la
     * source tant qu'on ne paie pas, et une icone posee sur le site d'un
     * client sans cette mention est un manquement, pas une economie. Les jeux
     * sous MIT, ISC ou Apache ne demandent rien de tel.
     *
     * LES ADRESSES SONT ECRITES ICI, PAS DANS LES FICHIERS DE LANGUE : une
     * adresse ne se traduit pas, et la voir changer dans une seule des deux
     * langues serait le genre de defaut qu'on ne trouve jamais.
     *
     * CHAQUE LIEN S'OUVRE DANS UN NOUVEL ONGLET, avec `rel="noopener"` :
     * l'administrateur est au milieu d'une saisie non enregistree, et le
     * ramener sur un site exterieur la lui ferait perdre.
     */
    protected function sources(): string
    {
        $sources = [
            ['Tabler Icons', 'https://tabler.io/icons', 'MIT'],
            ['Lucide', 'https://lucide.dev/icons/', 'ISC'],
            ['Bootstrap Icons', 'https://icons.getbootstrap.com/', 'MIT'],
            ['Remix Icon', 'https://remixicon.com/', 'Apache 2.0'],
            ['Phosphor Icons', 'https://phosphoricons.com/', 'MIT'],
            ['Material Symbols', 'https://fonts.google.com/icons', 'Apache 2.0'],
            ['Icons8', 'https://icons8.com/icons', Text::_('MOD_OPUS_MYICONS_SOURCES_CREDIT')],
            ['SVG Repo', 'https://www.svgrepo.com/', Text::_('MOD_OPUS_MYICONS_SOURCES_MIXED')],
        ];

        $liens = '';

        $nouvelOnglet = htmlspecialchars(Text::_('MOD_OPUS_MYICONS_SOURCES_TAB'), ENT_QUOTES, 'UTF-8');

        foreach ($sources as $une) {
            $liens .= '<li>'
                . '<a href="' . htmlspecialchars($une[1], ENT_QUOTES, 'UTF-8') . '"'
                . ' target="_blank" rel="noopener noreferrer">'
                . htmlspecialchars($une[0], ENT_QUOTES, 'UTF-8')
                . '<span class="visually-hidden"> ' . $nouvelOnglet . '</span>'
                . '</a>'
                . '<span class="blocs-icones__licence">' . htmlspecialchars($une[2], ENT_QUOTES, 'UTF-8') . '</span>'
                . '</li>';
        }

        return '<details class="blocs-icones__aide blocs-icones__sources">'
            . '<summary>' . Text::_('MOD_OPUS_MYICONS_SOURCES_TITLE') . '</summary>'
            . '<p>' . Text::_('MOD_OPUS_MYICONS_SOURCES_INTRO') . '</p>'
            . '<ul class="blocs-icones__liens">' . $liens . '</ul>'
            . '</details>';
    }

    /**
     * LA FAMILLE D'UN FICHIER, D'APRES SON EXTENSION.
     *
     * « Colore de facon differente les svg, png etc, et ajoute une legende. »
     * Cyrille, 25 septembre 2026. Trois familles, parce que ce sont les trois
     * comportements reels, pas les sept extensions :
     *
     * - `trace` : un SVG, redessine net a toute taille ;
     * - `pixels` : PNG, WebP, AVIF, GIF, nets a leur taille et flous au-dela,
     *   et qui n'existent en pochoir que par leur transparence ;
     * - `opaque` : JPEG, qui n'a PAS de transparence, donc un carre plein a
     *   tous les coups. Le signaler vaut mieux que le refuser : le fichier
     *   peut etre la par erreur, et un carre gris sans explication est une
     *   enigme.
     *
     * L'EXTENSION EST PRISE SUR LE CHEMIN, avant le `#` que le gestionnaire de
     * medias accroche derriere.
     */
    protected function famille(string $fichier): string
    {
        $chemin = explode('#', $fichier)[0];
        $chemin = explode('?', $chemin)[0];

        $ext = strtolower(pathinfo($chemin, PATHINFO_EXTENSION));

        if ($ext === 'svg') {
            return 'trace';
        }

        if (\in_array($ext, ['jpg', 'jpeg', 'jfif'], true)) {
            return 'opaque';
        }

        return 'pixels';
    }

    /**
     * LES DIMENSIONS D'UN FICHIER EN PIXELS, ou une chaine vide.
     *
     * « Peux-tu afficher la dimension des icones png ? Parfois les gens font
     * n'importe quoi. » Cyrille, 25 septembre 2026. Une icone de 2 400 pixels
     * de cote pese cent fois ce qu'il faut pour un dessin haut comme un mot,
     * et une de 12 pixels sera floue des qu'elle grandit. Les deux se voient
     * au premier coup d'oeil quand le nombre est ecrit.
     *
     * DEUX SOURCES, ET LA PREMIERE EST GRATUITE. Le gestionnaire de medias
     * inscrit les dimensions dans le fragment qu'il accroche au chemin,
     * `#joomlaImage://...?width=128&height=128` : les lire ne coute aucun
     * acces au disque. A defaut seulement, on ouvre le fichier.
     *
     * RIEN POUR UN SVG. Un trace vectoriel n'a pas de taille : il prend celle
     * qu'on lui donne. Afficher un nombre laisserait croire le contraire.
     */
    protected function dimensions(string $fichier): string
    {
        if ($this->famille($fichier) === 'trace') {
            return '';
        }

        $largeur = 0;
        $hauteur = 0;

        if (preg_match('#[?&]width=(\d+)#', $fichier, $m)) {
            $largeur = (int) $m[1];
        }

        if (preg_match('#[?&]height=(\d+)#', $fichier, $m)) {
            $hauteur = (int) $m[1];
        }

        if ($largeur < 1 || $hauteur < 1) {
            $chemin = explode('#', $fichier)[0];
            $chemin = explode('?', $chemin)[0];
            $disque = JPATH_ROOT . '/' . ltrim($chemin, '/');

            if (is_file($disque) && is_readable($disque)) {
                $taille = @getimagesize($disque);

                if ($taille !== false) {
                    $largeur = (int) $taille[0];
                    $hauteur = (int) $taille[1];
                }
            }
        }

        if ($largeur < 1 || $hauteur < 1) {
            return '';
        }

        return $largeur . ' × ' . $hauteur;
    }

    /**
     * LA MESURE EST-ELLE RAISONNABLE POUR UNE ICONE ?
     *
     * SOUS 32 PIXELS, le dessin sera flou des qu'il depasse la taille du
     * texte. AU-DELA DE 1024, le fichier pese pour rien : le pochoir est
     * affiche haut comme un mot, le reste est charge puis jete. Entre les
     * deux, on ne dit rien : ce n'est pas au module de faire la lecon.
     */
    protected function mesureDouteuse(string $mesure): bool
    {
        if ($mesure === '') {
            return false;
        }

        $cotes = array_map('intval', explode('×', str_replace(' ', '', $mesure)));

        foreach ($cotes as $cote) {
            if ($cote < 32 || $cote > 1024) {
                return true;
            }
        }

        return false;
    }

    /**
     * L'ADRESSE D'UN FICHIER D'ICONE, prete a entrer dans une `url()`.
     *
     * `cleanImageURL` separe le chemin de l'adaptateur que le gestionnaire de
     * medias accroche derriere un `#`. IL PEUT RENDRE VIDE : un fichier
     * renomme ou supprime depuis, un adaptateur inconnu. On retombe alors sur
     * le chemin brut ampute de son fragment, qui reste la meilleure reponse
     * possible : l'apercu montre le dessin, ou une case vide si le fichier
     * n'existe plus, mais l'icone ne disparait pas de la liste sans un mot.
     *
     * LES APOSTROPHES ET LES PARENTHESES SONT RETIREES : elles fermeraient
     * l'`url()` du CSS, et l'echappement HTML ne voit pas ce langage-la.
     */
    protected function urlIcone(string $fichier): string
    {
        $image = HTMLHelper::_('cleanImageURL', $fichier);
        $url   = \is_object($image) ? ($image->url ?? '') : (string) $image;

        if ($url === '') {
            $url = explode('#', $fichier)[0];
        }

        if ($url === '') {
            return '';
        }

        /*
         * L'ADRESSE EST RENDUE ABSOLUE, ET C'EST TOUTE L'HISTOIRE DU BOGUE.
         *
         * Le gestionnaire de medias enregistre un chemin RELATIF A LA RACINE
         * DU SITE, `images/icones/logo.svg`. En page publique, Joomla pose une
         * balise `<base>` et ce chemin tombe juste. EN ADMINISTRATION, il n'y
         * a pas de `<base>` : le navigateur le resout depuis l'adresse
         * courante, donc depuis `/administrator/`, et demande
         * `/administrator/images/icones/logo.svg`. Mesure a l'ecran le
         * 25 septembre 2026 : 404, un masque vide, une case sans dessin, et
         * rien dans la console pour le dire, puisqu'une image de masque qui
         * manque n'est pas une erreur de page.
         *
         * `Uri::root(true)` rend le chemin du site sans le domaine, vide a la
         * racine et `/mon-site` dans un sous-dossier : la meme ligne vaut pour
         * les deux.
         */
        if (!preg_match('#^(?:https?:)?//|^/#', $url)) {
            $url = Uri::root(true) . '/' . ltrim($url, '/');
        }

        return str_replace(["'", '"', '(', ')'], '', $url);
    }

    /**
     * UNE CASE DE LA GRILLE, et les deux series la fabriquent pareil.
     *
     * CHAQUE CASE EST UN BOUTON, et c'est ce qui la rend utilisable au clavier
     * sans une ligne de plus. Son libelle accessible porte le nom ET ce que le
     * clic fait : « i-accueil, copier le nom ».
     *
     * LE DESSIN EST `aria-hidden` : il double le nom ecrit dessous, il ne le
     * remplace pas. C'est la regle de la planche elle-meme, ecrite en tete de
     * `pictogrammes.php`.
     *
     * @param   string  $nom     Le nom montre sous le dessin.
     * @param   string  $valeur  Ce que le clic copie : le nom, ou `perso:nom`.
     * @param   string  $url     Le fichier a poser en masque, vide pour un
     *                           symbole de la planche.
     */
    protected function caseIcone(string $nom, string $valeur, string $url): string
    {
        $sur    = htmlspecialchars($nom, ENT_QUOTES, 'UTF-8');
        $copie  = htmlspecialchars($valeur, ENT_QUOTES, 'UTF-8');
        $action = htmlspecialchars(Text::_('MOD_OPUS_ICONS_COPY'), ENT_QUOTES, 'UTF-8');

        $dessin = $url === ''
            ? '<svg class="blocs-icones__dessin" aria-hidden="true" focusable="false"><use href="#' . $sur . '"></use></svg>'
            : '<span class="blocs-icones__dessin blocs-icones__dessin--perso" aria-hidden="true"'
                . ' style="--opus-icone:url(&#039;' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '&#039;)"></span>';

        $bouton = '<button type="button" class="blocs-icones__case" data-icone="' . $copie . '"'
            . ' aria-label="' . $sur . ', ' . $action . '">'
            . $dessin
            . '<span class="blocs-icones__nom">' . $sur . '</span>'
            . $this->mesure()
            . '</button>';

        if ($url === '') {
            return $bouton;
        }

        /*
         * LA CROIX RETIRE L'ICONE, et elle est a COTE du bouton, pas dedans.
         *
         * « Une croix en haut a droite de la zone de l'icone a plat serait
         * bien. » Cyrille, 25 septembre 2026. Un bouton dans un bouton n'est
         * pas du HTML valide et ne se clique pas de facon previsible : la case
         * et sa croix sont donc deux boutons voisins dans une meme boite, que
         * la feuille superpose.
         *
         * ELLE NE RETIRE QUE DES ICONES A SOI. Celles de la planche viennent
         * du template et ne se suppriment pas d'ici, d'ou le retour anticipe
         * au-dessus : une croix sur elles promettrait une chose qu'on ne peut
         * pas tenir.
         */
        return '<span class="blocs-icones__boite blocs-icones__boite--' . $this->famille($this->sourceCourante) . '">'
            . $bouton
            . '<button type="button" class="blocs-icones__ote" data-ote="' . $sur . '"'
            . ' aria-label="' . htmlspecialchars(Text::sprintf('MOD_OPUS_MYICONS_REMOVE', $nom), ENT_QUOTES, 'UTF-8') . '">'
            . '<span aria-hidden="true">&times;</span>'
            . '</button>'
            . '</span>';
    }
}
