<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * CHAMP : L'EN-TETE DU MODULE, ET SES ASSETS D'ADMINISTRATION.
 *
 * Il fait deux choses, et c'est volontaire : un seul champ a poser dans le XML
 * plutot que deux, et surtout un seul endroit ou l'on decide de quoi l'ecran a
 * besoin.
 *
 * 1. IL AFFICHE LE NUMERO DE VERSION, LU DANS LE MANIFESTE.
 *
 *    Jamais ecrit en dur. Le code moral du projet le dit pour les paquets, et
 *    la raison vaut ici : un numero recopie a la main se perime, et il s'est
 *    deja perime de dix crans ailleurs. La seule source est le manifeste, que
 *    l'outil de livraison met a jour.
 *
 * 2. IL CHARGE LA FEUILLE ET LE SCRIPT DE L'ECRAN.
 *
 *    Avec la date de modification en suffixe, comme le fait `tplhelper` de
 *    Corpus : sans cela, une correction reste invisible tant que le navigateur
 *    garde l'ancien fichier, et l'on cherche la panne dans le code.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormField;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

class JFormFieldBlocsInfo extends FormField
{
    protected $type = 'BlocsInfo';

    /**
     * Le chemin du module, relatif a la racine du site.
     */
    protected const BASE = 'modules/mod_opus';

    /**
     * Rend « ?<date de modification> » pour un chemin relatif a la racine, ou
     * une chaine vide si le fichier est introuvable.
     */
    protected function version(string $cheminRelatif): string
    {
        $fichier = JPATH_ROOT . '/' . ltrim($cheminRelatif, '/');

        return is_file($fichier) ? '?' . filemtime($fichier) : '';
    }

    /**
     * Le numero de version, lu dans le manifeste du module.
     *
     * JAMAIS EN DUR. Si le manifeste est introuvable, on ne rend rien plutot
     * qu'un numero invente : une version fausse est pire qu'une version absente,
     * parce qu'on la croit.
     */
    protected function numero(): string
    {
        $manifeste = JPATH_SITE . '/' . self::BASE . '/mod_opus.xml';

        if (!is_file($manifeste)) {
            return '';
        }

        $xml = simplexml_load_file($manifeste);

        return $xml && isset($xml->version) ? (string) $xml->version : '';
    }

    /**
     * Le numero, ecrit pour un humain.
     *
     * Le manifeste porte « 1.0.0-beta1 » parce que c'est cette forme que
     * `version_compare()` de PHP classe correctement : la beta passe AVANT la
     * 1.0.0 finale. Un espace ou une majuscule dans le manifeste casserait ce
     * classement sans rien signaler, et le serveur de mise a jour proposerait
     * la beta comme si elle etait posterieure a la stable.
     *
     * Ici, on n'est plus dans la comparaison mais dans la lecture : on rend
     * « 1.0.0 Beta 1 ». La source reste unique, seul l'affichage change.
     */
    protected function lisible(string $numero): string
    {
        return preg_replace_callback(
            '#-(alpha|beta|rc)(\d*)$#i',
            static function (array $trouve): string {
                $mot = ucfirst(strtolower($trouve[1]));

                return ' ' . ($mot === 'Rc' ? 'RC' : $mot) . ($trouve[2] !== '' ? ' ' . $trouve[2] : '');
            },
            $numero
        );
    }

    /**
     * LES ASSETS SE CHARGENT DANS setup(), PAS DANS LE RENDU.
     *
     * `setup()` est appele quand le formulaire se construit, une fois, avant
     * tout affichage. Le rendu, lui, peut ne jamais avoir lieu : un champ dans
     * un onglet ferme, un formulaire rendu en morceaux, et la feuille ne
     * partait pas. C'est la ou `legend.php` de Corpus les charge, et pour la
     * meme raison.
     */
    public function setup(\SimpleXMLElement $element, $value, $group = null)
    {
        $doc = Factory::getApplication()->getDocument();

        /*
         * COTE SITE, L'ECRAN DE MONTAGE NE S'AFFICHE PAS, 25 septembre 2026.
         *
         * Le crayon d'un module, sur le site, ouvre le meme formulaire dans le
         * template du site (`com_config`). Mesure sur le banc : le volet
         * « Mise en page » y mesurait 36 583 px de haut, les tableaux etaient
         * coupes a 575 px de large, et le navigateur a gele deux fois. Rien de
         * notre ecran ne s'y applique, parce que Joomla range les onglets dans
         * un accordeon aux noms generiques, et que tout `admin.css` et
         * `admin.js` s'accrochent aux onglets de l'administration.
         *
         * Decision de Cyrille : cote site, on garde ce que Joomla montre
         * (titre, position, publication, acces, parametres avances) et l'on
         * renvoie le montage a l'administration, par un bouton.
         *
         * ON MASQUE, ON NE RETIRE PAS. Retirer les champs du formulaire les
         * retirerait aussi de l'enregistrement : un « Enregistrer » depuis le
         * site remplacerait les parametres par ceux qui restent, et le montage
         * serait perdu. Masques, ils partent avec le formulaire, intacts.
         *
         * La mise en page du formulaire est celle du coeur
         * (`components/com_config/tmpl/modules/default_options.php`) : la meme
         * sous Corpus et sous Cassiopeia, aucun des deux ne la surcharge.
         */
        if (Factory::getApplication()->isClient('site')) {
            /*
             * REVU LE MEME SOIR : « une mise en page proche du module en
             * backend, avec uniquement les champs modifiables, sans acces aux
             * reglages », Cyrille. Le volet du montage reste donc visible, et
             * `admin.js` le met en forme en mode site (`mod_opus.site`) : il
             * pose les reperes que la feuille attend, et ne laisse voir que
             * les champs de contenu. Seuls les volets CSS et Icones, qui ne
             * sont que des reglages, restent masques.
             */
            $doc->addScriptOptions('mod_opus.site', true);

            /*
             * DANS LA GRANDE FENETRE (`tmpl=component`, ouverte par
             * `edition.js`), l'ecran est complet : on ne masque aucun volet.
             */
            $fenetre = Factory::getApplication()->getInput()->getCmd('tmpl') === 'component';
            $doc->addScriptOptions('mod_opus.fenetre', $fenetre);

            $doc->addStyleDeclaration($fenetre ? '' : 
                '.accordion-item:has(:is([name="jform[params][customCss]"],[name^="jform[params][iconesPerso]"])){display:none}'
                . '.opus-site{margin:0 0 1rem;padding:1rem;border:1px solid var(--bs-border-color,#dee2e6);'
                . 'border-radius:var(--bs-border-radius,.375rem)}'
                . '.opus-site p{margin:0 0 .75rem}'
            );
        }

        $css = 'media/mod_opus/css/admin.css';
        $js  = 'media/mod_opus/js/admin.js';

        /*
         * LA DATE DE MODIFICATION SERT DE NUMERO DE VERSION. Sans elle, le
         * navigateur garde sa copie : la feuille a beau etre mise a jour sur
         * le serveur, l'ecran continue d'employer l'ancienne, et on cherche la
         * panne dans le code. Meme piege que pour `legend.js` de Corpus.
         */
        $doc->addStyleSheet(Uri::root() . $css . $this->version($css));
        $doc->addScript(Uri::root() . $js . $this->version($js), ['defer' => true]);

        /*
         * LA FENETRE DE JOOMLA SE DEMANDE, ELLE N'EST JAMAIS LA D'AVANCE.
         *
         * Joomla ne charge ses composants qu'a la demande : un ecran qui ne
         * s'en sert pas ne les embarque pas. Sans cette ligne,
         * `customElements.get('joomla-dialog')` rend `undefined` et le script
         * retombe sur la fenetre du navigateur.
         *
         * `joomla.dialog` suffit : c'est lui qui definit l'element et ses
         * aides `alert()` et `confirm()`, relues dans
         * `media/system/js/joomla-dialog.js` l. 577 et 606.
         * `joomla.dialog-autocreate` ne sert qu'aux boutons a attributs, et
         * nous fabriquons la notre en JavaScript.
         */
        $doc->getWebAssetManager()->useScript('joomla.dialog');

        /*
         * LES VALEURS PAR DEFAUT DU MANIFESTE, LIVREES AU SCRIPT.
         *
         * LA PASTILLE DE LA ROUE COMPTE LES REGLAGES POSES, et « pose » veut
         * dire « different de ce que le manifeste donne ». Mesure faite sur le
         * banc le 24 septembre 2026 : `defaultValue` et `defaultSelected` du
         * navigateur ne disent PAS cela. Ils rendent la valeur SERVIE dans le
         * HTML, c'est-a-dire celle deja enregistree. La pastille restait donc a
         * zero sur un module enregistre, quels que soient les reglages poses.
         * C'est le critere du poincon rouge du coeur, « change depuis le
         * chargement », et ce n'est pas la question posee ici.
         *
         * SEUL LE MANIFESTE SAIT, et lui seul : on le lit ici, une fois, et on
         * passe la table au script. `getForm()` n'est pas employe a dessein, il
         * rendrait le formulaire deja peuple des valeurs enregistrees, soit le
         * probleme qu'on cherche a eviter.
         */
        $defauts = [];

        $manifeste = @simplexml_load_file(JPATH_SITE . '/modules/mod_opus/mod_opus.xml');

        if ($manifeste !== false) {
            foreach ($manifeste->xpath('//field[@name]') as $champ) {
                $nom = (string) $champ['name'];

                if ($nom === '') {
                    continue;
                }

                /*
                 * UN NOM PEUT REVENIR DANS DEUX PILES, avec le meme defaut : la
                 * pile d'elements est recopiee telle quelle pour les cartes. Le
                 * premier vu fait foi, et le second lui est identique.
                 */
                if (!\array_key_exists($nom, $defauts)) {
                    $defauts[$nom] = (string) ($champ['default'] ?? '');
                }
            }
        }

        $doc->addScriptOptions('mod_opus.defauts', $defauts);

        /*
         * LE CATALOGUE DES CLASSES, POUR LE PANNEAU DU CSS PERSONNALISE.
         *
         * Il est PRODUIT A LA LIVRAISON par `outils/catalogue-classes.py`, et
         * la maquette l'exige ainsi : « les declarations viennent du catalogue
         * produit a la livraison, pas d'une lecture de la feuille compilee ».
         * Une feuille minifiee ne rend pas des regles lisibles, et la relire a
         * chaque ouverture de l'ecran couterait a chaque fois.
         *
         * SON ABSENCE N'EST PAS UNE PANNE : le panneau ne se dessine pas, le
         * reste de l'ecran ne bouge pas. Un module installe depuis un zip plus
         * ancien n'a pas ce fichier, et doit continuer a s'ouvrir.
         */
        /*
         * L'EXEMPLE COMMENTE, DANS LA LANGUE DE L'ADMINISTRATION.
         *
         * « Ceci n'est pas facile a comprendre. Dessous il me faudrait un
         * exemple de creation d'une classe, ou l'on voit comment changer une
         * couleur, les marges, padding, bordures, epaisseur. Un code complet,
         * mais simple. » Cyrille, 24 septembre 2026, devant le panneau des
         * classes.
         *
         * IL EST DANS UN FICHIER, PAS DANS LES LANGUES : un `.ini` ne sait pas
         * porter trente lignes de code avec ses retours et ses commentaires
         * sans devenir illisible, et `parse_ini_string` ne connait meme pas
         * `\n`. Un fichier `.css` se relit, se corrige, et se colore tout seul
         * dans n'importe quel editeur.
         *
         * LE REPLI EST L'ANGLAIS : une langue installee sans son exemple vaut
         * mieux qu'un panneau vide.
         */
        $langue  = Factory::getApplication()->getLanguage()->getTag();
        $exemple = JPATH_SITE . '/media/mod_opus/data/exemple-' . $langue . '.css';

        if (!is_file($exemple)) {
            $exemple = JPATH_SITE . '/media/mod_opus/data/exemple-en-GB.css';
        }

        if (is_file($exemple)) {
            $doc->addScriptOptions('mod_opus.exemple', (string) file_get_contents($exemple));
        }

        $catalogue = JPATH_SITE . '/media/mod_opus/data/classes.json';

        if (is_file($catalogue)) {
            $lu = json_decode((string) file_get_contents($catalogue), true);

            if (\is_array($lu)) {
                $doc->addScriptOptions('mod_opus.classes', $lu);
            }
        }

        return parent::setup($element, $value, $group);
    }

    /**
     * LE BLOC EST RENDU COMME CHAMP, PAS COMME LIBELLE.
     *
     * Il etait dans `getLabel()`, et c'etait une panne : Joomla range le
     * libelle d'un champ dans `.control-label`, une colonne de 240 px. Le
     * descriptif du module s'y retrouvait comprime sur 224 px de large,
     * quinze mots par ligne, sur toute la hauteur de l'ecran. Mesure faite
     * dans le navigateur le 19 septembre 2026.
     *
     * Rendu comme champ, il occupe `.controls`, qui prend la largeur
     * disponible. Le libelle, lui, ne rend plus rien : ce bloc EST son propre
     * titre.
     */
    protected function getLabel()
    {
        return '';
    }

    protected function getInput()
    {

        // Les textes que le script ecrira. Sans cela, l'ecran afficherait les
        // clefs brutes, et le defaut ne se verrait pas : l'ecran affiche bien
        // quelque chose.
        Text::script('MOD_OPUS_GAUGE');
        Text::script('MOD_OPUS_GAUGE_FULL');
        Text::script('MOD_OPUS_CLASSES_TITLE');
        Text::script('MOD_OPUS_CLASSES_HELP');
        Text::script('MOD_OPUS_CLASSES_MINE');
        Text::script('MOD_OPUS_CLASSES_SHARED');
        Text::script('MOD_OPUS_CLASSES_VENDOR');
        Text::script('MOD_OPUS_CLASSES_LEG_MINE');
        Text::script('MOD_OPUS_CLASSES_LEG_CORPUS');
        Text::script('MOD_OPUS_CLASSES_LEG_VENDOR');
        Text::script('MOD_OPUS_EXAMPLE_TITLE');
        Text::script('MOD_OPUS_EXAMPLE_INSERT');
        Text::script('MOD_OPUS_CLASSES_COPY');
        Text::script('MOD_OPUS_CLASSES_NEWNAME');
        Text::script('MOD_OPUS_CLASSES_COPIED');
        Text::script('MOD_OPUS_ORPHAN_WARN');
        Text::script('MOD_OPUS_ORPHAN_CLEAN');
        Text::script('MOD_OPUS_MAP_TITLE');
        Text::script('MOD_OPUS_MAP_EMPTY');
        Text::script('MOD_OPUS_MAP_HIDDEN');
        Text::script('MOD_OPUS_MAP_CARDS');
        Text::script('MOD_OPUS_MAP_NOLABEL');
        Text::script('MOD_OPUS_BLOCK_CARDS');
        Text::script('MOD_OPUS_BLOCK_CAROUSEL');
        Text::script('MOD_OPUS_BLOCK_GALLERY');
        Text::script('MOD_OPUS_BLOCK_IMAGE');
        Text::script('MOD_OPUS_BLOCK_OPENING');
        Text::script('MOD_OPUS_MODEL_OPENING');
        Text::script('MOD_OPUS_ELEMENT_STATE');
        Text::script('MOD_OPUS_MODEL_STATES');
        Text::script('MOD_OPUS_MODEL_PORTRAITS');
        Text::script('MOD_OPUS_MODEL_QUOTES');
        Text::script('MOD_OPUS_MODEL_LOGOS');
        Text::script('MOD_OPUS_MODEL_STEPS');
        Text::script('MOD_OPUS_MODEL_PRICES');
        Text::script('MOD_OPUS_MODEL_FAQ');
        /*
         * LES CLEFS OUBLIEES, 24 septembre 2026.
         *
         * « Je veux du texte a gauche et une image a droite », Cyrille, devant
         * un panneau d'onglets qui ne montrait QUE l'image. Le texte n'etait pas
         * absent du modele : sa clef n'avait jamais ete declaree ici, donc
         * `texte()` retombait sur le defaut du script, qui valait la chaine
         * vide. Un montage entier sortait ampute, sans la moindre erreur.
         *
         * LE TROU ETAIT BIEN PLUS LARGE QUE LES ONGLETS : soixante-quatre clefs
         * manquaient, celles des Tuiles, de la Mosaique, des Atouts, des
         * Coordonnees, des Chiffres verifiables, du Bandeau d'appel et de la
         * Comparaison. Tous ces montages sortaient avec les defauts ecrits dans
         * le script, donc jamais traduits, et parfois vides.
         *
         * `outils/clefs-script.py` COMPARE DESORMAIS LES DEUX LISTES, et doit
         * etre lance avant chaque livraison : cet oubli-la ne se voit pas a
         * l'ecran tant qu'on ne pose pas le montage concerne.
         */
        Text::script('MOD_OPUS_CARD_COPY');
        Text::script('MOD_OPUS_ELEMENT_ADDRESS');
        Text::script('MOD_OPUS_ELEMENT_BARS');
        Text::script('MOD_OPUS_ELEMENT_CONTACT');
        Text::script('MOD_OPUS_ELEMENT_SPECS');
        Text::script('MOD_OPUS_MODEL_BARS');
        Text::script('MOD_OPUS_MODEL_BENEFITS');
        Text::script('MOD_OPUS_MODEL_COMPARE');
        Text::script('MOD_OPUS_MODEL_CONTACT');
        Text::script('MOD_OPUS_MODEL_CTA');
        Text::script('MOD_OPUS_MODEL_MOSAIC');
        Text::script('MOD_OPUS_MODEL_PROOF');
        Text::script('MOD_OPUS_MODEL_TABS');
        Text::script('MOD_OPUS_MODEL_TILES');
        Text::script('MOD_OPUS_SAMPLE_BARS1');
        Text::script('MOD_OPUS_SAMPLE_BARS2');
        Text::script('MOD_OPUS_SAMPLE_BARS3');
        Text::script('MOD_OPUS_SAMPLE_BARS4');
        Text::script('MOD_OPUS_SAMPLE_BARS_INTRO');
        Text::script('MOD_OPUS_SAMPLE_BARS_TITLE');
        Text::script('MOD_OPUS_SAMPLE_BENEFIT1');
        Text::script('MOD_OPUS_SAMPLE_BENEFIT2');
        Text::script('MOD_OPUS_SAMPLE_BENEFIT3');
        Text::script('MOD_OPUS_SAMPLE_BENEFIT4');
        Text::script('MOD_OPUS_SAMPLE_BENEFIT5');
        Text::script('MOD_OPUS_SAMPLE_BENEFIT6');
        Text::script('MOD_OPUS_SAMPLE_BENEFITS_TITLE');
        Text::script('MOD_OPUS_SAMPLE_BENEFIT_TEXT');
        Text::script('MOD_OPUS_SAMPLE_BUTTON2');
        Text::script('MOD_OPUS_SAMPLE_COMPARE1_TEXT');
        Text::script('MOD_OPUS_SAMPLE_COMPARE1_TITLE');
        Text::script('MOD_OPUS_SAMPLE_COMPARE2_TEXT');
        Text::script('MOD_OPUS_SAMPLE_COMPARE2_TITLE');
        Text::script('MOD_OPUS_SAMPLE_COORD_ADDRESS');
        Text::script('MOD_OPUS_SAMPLE_COORD_FIND');
        Text::script('MOD_OPUS_SAMPLE_COORD_HOURS');
        Text::script('MOD_OPUS_SAMPLE_COORD_MAIL');
        Text::script('MOD_OPUS_SAMPLE_COORD_ORG');
        Text::script('MOD_OPUS_SAMPLE_COORD_PHONE');
        Text::script('MOD_OPUS_SAMPLE_COORD_REACH');
        Text::script('MOD_OPUS_SAMPLE_CTA_BUTTON');
        Text::script('MOD_OPUS_SAMPLE_CTA_TEXT');
        Text::script('MOD_OPUS_SAMPLE_CTA_TITLE');
        Text::script('MOD_OPUS_SAMPLE_LEAD');
        Text::script('MOD_OPUS_SAMPLE_MOSAIC_TEXT');
        Text::script('MOD_OPUS_SAMPLE_MOSAIC_TITLE');
        Text::script('MOD_OPUS_SAMPLE_NOTE');
        Text::script('MOD_OPUS_SAMPLE_PROOF1');
        Text::script('MOD_OPUS_SAMPLE_PROOF1_LABEL');
        Text::script('MOD_OPUS_SAMPLE_PROOF1_SOURCE');
        Text::script('MOD_OPUS_SAMPLE_PROOF2');
        Text::script('MOD_OPUS_SAMPLE_PROOF2_LABEL');
        Text::script('MOD_OPUS_SAMPLE_PROOF2_SOURCE');
        Text::script('MOD_OPUS_SAMPLE_PROOF3');
        Text::script('MOD_OPUS_SAMPLE_PROOF3_LABEL');
        Text::script('MOD_OPUS_SAMPLE_PROOF3_SOURCE');
        Text::script('MOD_OPUS_SAMPLE_PROOF_TITLE');
        Text::script('MOD_OPUS_BLOCK_TABS');
        Text::script('MOD_OPUS_BLOCK_TIMELINE');
        Text::script('MOD_OPUS_MODEL_TIMELINE');
        Text::script('MOD_OPUS_STEPS_LABEL');
        Text::script('MOD_OPUS_STEP_N');
        Text::script('MOD_OPUS_SAMPLE_TL1');
        Text::script('MOD_OPUS_SAMPLE_TL1_TITLE');
        Text::script('MOD_OPUS_SAMPLE_TL1_TEXT');
        Text::script('MOD_OPUS_SAMPLE_TL2');
        Text::script('MOD_OPUS_SAMPLE_TL2_TITLE');
        Text::script('MOD_OPUS_SAMPLE_TL2_TEXT');
        Text::script('MOD_OPUS_SAMPLE_TL3');
        Text::script('MOD_OPUS_SAMPLE_TL3_TITLE');
        Text::script('MOD_OPUS_SAMPLE_TL3_TEXT');
        Text::script('MOD_OPUS_SAMPLE_TL4');
        Text::script('MOD_OPUS_SAMPLE_TL4_TITLE');
        Text::script('MOD_OPUS_SAMPLE_TL4_TEXT');
        Text::script('MOD_OPUS_TABS_LABEL');
        Text::script('MOD_OPUS_TAB_N');
        Text::script('MOD_OPUS_SAMPLE_TAB1');
        Text::script('MOD_OPUS_SAMPLE_TAB1_SUB');
        Text::script('MOD_OPUS_SAMPLE_TAB2_SUB');
        Text::script('MOD_OPUS_SAMPLE_TAB3_SUB');
        Text::script('MOD_OPUS_SAMPLE_TAB1_TEXT');
        Text::script('MOD_OPUS_SAMPLE_TAB2');
        Text::script('MOD_OPUS_SAMPLE_TAB2_TEXT');
        Text::script('MOD_OPUS_SAMPLE_TAB3');
        Text::script('MOD_OPUS_SAMPLE_TAB3_TEXT');
        Text::script('MOD_OPUS_SAMPLE_TABS_TITLE');
        Text::script('MOD_OPUS_SAMPLE_TILE1');
        Text::script('MOD_OPUS_SAMPLE_TILE2');
        Text::script('MOD_OPUS_SAMPLE_TILE3');
        Text::script('MOD_OPUS_SAMPLE_TILE_TEXT');

        Text::script('MOD_OPUS_SAMPLE_STEPS_TITLE');
        Text::script('MOD_OPUS_SAMPLE_STEP1');
        Text::script('MOD_OPUS_SAMPLE_STEP2');
        Text::script('MOD_OPUS_SAMPLE_STEP3');
        Text::script('MOD_OPUS_SAMPLE_STEP_TEXT');
        Text::script('MOD_OPUS_SAMPLE_PRICE1_TITLE');
        Text::script('MOD_OPUS_SAMPLE_PRICE2_TITLE');
        Text::script('MOD_OPUS_SAMPLE_PRICE3_TITLE');
        Text::script('MOD_OPUS_SAMPLE_PRICE3');
        Text::script('MOD_OPUS_SAMPLE_PRICE_BEST');
        Text::script('MOD_OPUS_SAMPLE_PRICE1');
        Text::script('MOD_OPUS_SAMPLE_PRICE2');
        Text::script('MOD_OPUS_SAMPLE_PRICE_UNIT');
        Text::script('MOD_OPUS_SAMPLE_PRICE_ITEMS');
        Text::script('MOD_OPUS_SAMPLE_PRICE_BUTTON');
        Text::script('MOD_OPUS_SAMPLE_FAQ_TITLE');
        Text::script('MOD_OPUS_SAMPLE_FAQ1');
        Text::script('MOD_OPUS_SAMPLE_FAQ2');
        Text::script('MOD_OPUS_SAMPLE_FAQ3');
        Text::script('MOD_OPUS_SAMPLE_FAQ_TEXT');
        Text::script('MOD_OPUS_SAMPLE_CARD_TEXT');
        Text::script('MOD_OPUS_SAMPLE_STATE_OK');
        Text::script('MOD_OPUS_SAMPLE_STATE_WIP');
        Text::script('MOD_OPUS_SAMPLE_STATE_TODO');
        Text::script('MOD_OPUS_SAMPLE_PORTRAIT1_NAME');
        Text::script('MOD_OPUS_SAMPLE_PORTRAIT2_NAME');
        Text::script('MOD_OPUS_SAMPLE_PORTRAIT3_NAME');
        Text::script('MOD_OPUS_SAMPLE_PORTRAIT_ROLE');
        Text::script('MOD_OPUS_SAMPLE_QUOTE1');
        Text::script('MOD_OPUS_SAMPLE_QUOTE2');
        Text::script('MOD_OPUS_SAMPLE_QUOTE3');
        Text::script('MOD_OPUS_SAMPLE_QUOTE_SOURCE');
        Text::script('MOD_OPUS_BLOCK_PORTRAITS');
        Text::script('MOD_OPUS_BLOCK_ROW_LABEL');
        Text::script('MOD_OPUS_MAP_NOBLOCK');
        Text::script('MOD_OPUS_MAP_NOCONTENT');
        Text::script('MOD_OPUS_MAP_NOROW');
        Text::script('MOD_OPUS_SETTINGS_TITLE');
        Text::script('MOD_OPUS_TOOLS');
        Text::script('MOD_OPUS_FOLD');
        Text::script('MOD_OPUS_FOLD_ALL');
        Text::script('JCANCEL');
        Text::script('JHELP');
        Text::script('MOD_OPUS_LINK_GROUP');
        Text::script('MOD_OPUS_ELEMENT_HEADING');
        Text::script('MOD_OPUS_ELEMENT_SUBHEADING');
        Text::script('MOD_OPUS_ELEMENT_TEXT');
        Text::script('MOD_OPUS_ELEMENT_SEPARATOR');
        Text::script('MOD_OPUS_ELEMENT_BUTTONS');
        Text::script('MOD_OPUS_ELEMENT_LIST');
        Text::script('MOD_OPUS_ELEMENT_ALERT');
        Text::script('MOD_OPUS_ELEMENT_POINTS');
        Text::script('MOD_OPUS_ELEMENT_QUOTE');
        Text::script('MOD_OPUS_ELEMENT_FIGURES');
        Text::script('MOD_OPUS_ELEMENT_ACCORDION');
        Text::script('MOD_OPUS_ELEMENT_LINKS');
        Text::script('MOD_OPUS_MAP_OUTOF');
        Text::script('MOD_OPUS_MAP_HIDDENPL');
        Text::script('MOD_OPUS_MAP_SLIDES');
        Text::script('MOD_OPUS_MAP_IMAGES');
        Text::script('MOD_OPUS_MAP_NOTE');

        // Le panneau des modeles de depart et ses textes d'exemple.
        Text::script('MOD_OPUS_MODELS_TITLE');
        Text::script('MOD_OPUS_MODELS_DESC');
        Text::script('MOD_OPUS_MODEL_CAROUSEL');
        Text::script('MOD_OPUS_MODEL_GALLERY');
        Text::script('MOD_OPUS_MODEL_TEXTIMAGE');
        Text::script('MOD_OPUS_MODEL_PORTRAITS');
        Text::script('MOD_OPUS_MODEL_TODO');
        Text::script('MOD_OPUS_MODEL_REPLACE_WARN');
        Text::script('MOD_OPUS_ADD_EMPTY');
        Text::script('MOD_OPUS_MODEL_REPLACE_TITLE');

        // Les mots des deux boutons de la fenetre du coeur.
        Text::script('JYES');
        Text::script('JNO');
        Text::script('MOD_OPUS_SAMPLE_TITLE');
        Text::script('MOD_OPUS_SAMPLE_TEXT');
        Text::script('MOD_OPUS_SAMPLE_BUTTON');
        Text::script('MOD_OPUS_SAMPLE_CARD1_TITLE');
        Text::script('MOD_OPUS_SAMPLE_CARD1_TEXT');
        Text::script('MOD_OPUS_SAMPLE_CARD2_TITLE');
        Text::script('MOD_OPUS_SAMPLE_CARD2_TEXT');
        Text::script('MOD_OPUS_SAMPLE_CARD3_TITLE');
        Text::script('MOD_OPUS_SAMPLE_CARD3_TEXT');

        // Le rang lu en tete de chaque carte, renumerote a chaque changement.
        Text::script('MOD_OPUS_CARD_N');
        Text::script('MOD_OPUS_ITEM_IMAGE');
        Text::script('MOD_OPUS_ITEM_SLIDE');
        Text::script('MOD_OPUS_LIST_IMAGES');
        Text::script('MOD_OPUS_LIST_SLIDES');
        Text::script('MOD_OPUS_BRICKS_TITLE');
        Text::script('MOD_OPUS_MODEL_HOME');
        Text::script('MOD_OPUS_SAMPLE_HOME_TITLE');
        Text::script('MOD_OPUS_SAMPLE_HOME_LEAD');
        Text::script('MOD_OPUS_SAMPLE_HOME_BUTTON');
        Text::script('MOD_OPUS_SAMPLE_HOME_BUTTON2');
        Text::script('MOD_OPUS_SAMPLE_HOME_NOTE');
        Text::script('MOD_OPUS_SAMPLE_HOME_ALERT_TITLE');
        Text::script('MOD_OPUS_SAMPLE_HOME_ALERT_TEXT');
        Text::script('MOD_OPUS_SAMPLE_HOME_SUMMARY');
        Text::script('MOD_OPUS_SAMPLE_HOME_LINK1');
        Text::script('MOD_OPUS_SAMPLE_HOME_LINK2');
        Text::script('MOD_OPUS_SAMPLE_HOME_LINK3');
        Text::script('MOD_OPUS_SAMPLE_HOME_LINK4');
        Text::script('MOD_OPUS_SAMPLE_HOME_LINK5');
        Text::script('MOD_OPUS_SAMPLE_HOME_LINK6');

        Text::script('MOD_OPUS_CARDS_LABEL');
        Text::script('MOD_OPUS_SAMPLE_GAL1');
        Text::script('MOD_OPUS_SAMPLE_GAL2');
        Text::script('MOD_OPUS_SAMPLE_GAL3');
        Text::script('MOD_OPUS_SAMPLE_SLIDE1_TITLE');
        Text::script('MOD_OPUS_SAMPLE_SLIDE1_TEXT');
        Text::script('MOD_OPUS_SAMPLE_SLIDE2_TITLE');
        Text::script('MOD_OPUS_SAMPLE_SLIDE2_TEXT');
        Text::script('MOD_OPUS_SAMPLE_SLIDE3_TITLE');
        Text::script('MOD_OPUS_SAMPLE_SLIDE3_TEXT');

        /*
         * LE PONT VERS L'ONGLET CSS, depuis le panneau de la roue.
         */
        Text::script('MOD_OPUS_CSS_WRITE');
        Text::script('MOD_OPUS_CSS_WRITE_EMPTY');

        // La note de poids sous le chemin d une image, et ses deux alertes.
        Text::script('MOD_OPUS_IMG_WEIGHT');
        Text::script('MOD_OPUS_IMG_WEIGHT_HEAVY');
        Text::script('MOD_OPUS_IMG_WEIGHT_WIDE');

        // Le bouton d'enregistrement de l'onglet Icones, 25 septembre 2026.
        Text::script('MOD_OPUS_MYICONS_SAVE');

        // Cote site : l'avis et le bouton vers l'administration. Les textes du
        // script sont deja publies au-dessus : l'ecran de contenu en a besoin.
        if (Factory::getApplication()->isClient('site') && Factory::getApplication()->getInput()->getCmd('tmpl') === 'component') {
            // Dans la grande fenetre, l'ecran est complet : pas d'avis.
            return '';
        }

        if (Factory::getApplication()->isClient('site')) {
            $id  = (int) $this->form->getValue('id');
            $url = Uri::root() . 'administrator/index.php?option=com_modules&task=module.edit&id=' . $id;

            return '<div class="opus-site" role="note">'
                . '<p><strong>' . htmlspecialchars(Text::_('MOD_OPUS_SITE_TITLE'), ENT_QUOTES, 'UTF-8') . '</strong></p>'
                . '<p>' . htmlspecialchars(Text::_('MOD_OPUS_SITE_DESC'), ENT_QUOTES, 'UTF-8') . '</p>'
                . '<a class="btn btn-primary" href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '">'
                . htmlspecialchars(Text::_('MOD_OPUS_SITE_BUTTON'), ENT_QUOTES, 'UTF-8') . '</a>'
                . '</div>';
        }

        $numero = $this->numero();
        $version = $numero !== ''
            ? '<span class="blocs-entete__version">' . htmlspecialchars($this->lisible($numero), ENT_QUOTES, 'UTF-8') . '</span>'
            : '';

        /*
         * LA PRESENTATION SUIT CELLE DE CORPUS, 25 septembre 2026.
         *
         * « Remodele l'onglet au meme format que Corpus », Cyrille. L'onglet
         * Details du template pose une vignette a gauche, le nom et la version
         * en tete, un titre, un paragraphe, une liste de ce que l'extension
         * apporte, et la mention de licence. Opus reprend cette forme : deux
         * extensions de la meme gamme ne doivent pas se presenter de deux
         * facons differentes.
         *
         * LA VIGNETTE EST UN CARRE GRIS EN ATTENDANT L'IMAGE. Elle sera
         * remplacee par une capture du module, que Cyrille fournira. Le carre
         * garde la place et le rapport, pour que l'ajout de l'image ne deplace
         * rien.
         *
         * `aria-hidden` SUR LA VIGNETTE : elle n'apprend rien qui ne soit
         * ecrit a cote, et un carre vide annonce serait un bruit de plus.
         */
        $titre  = Text::_('MOD_OPUS_INTRO_LABEL');
        $texte  = Text::_('MOD_OPUS_INTRO_DESC');
        $points = Text::_('MOD_OPUS_INTRO_POINTS');
        $nom    = Text::_('MOD_OPUS_INTRO_NAME');

        /*
         * LA LICENCE EST ECRITE, PAS DEDUITE. Le module est distribue sous GNU
         * GPL version 2 ou ulterieure, comme Joomla lui-meme et comme Corpus,
         * et le dire ici evite d'avoir a ouvrir le manifeste pour le savoir.
         */
        $licence = Text::_('MOD_OPUS_INTRO_LICENCE');

        return '<div class="blocs-presentation">'
            . '<div class="blocs-presentation__vignette" aria-hidden="true"></div>'
            . '<div class="blocs-presentation__corps">'
            .     '<p class="blocs-presentation__marque">Opus' . $version . '</p>'
            .     '<h3 class="blocs-presentation__titre">' . $titre . '</h3>'
            .     '<div class="blocs-presentation__texte">' . $texte . '</div>'
            .     '<ul class="blocs-presentation__points">' . $points . '</ul>'
            .     '<p class="blocs-presentation__nom">' . $nom . '</p>'
            .     '<p class="blocs-presentation__licence">' . $licence . '</p>'
            . '</div>'
            . '</div>';
    }
}
