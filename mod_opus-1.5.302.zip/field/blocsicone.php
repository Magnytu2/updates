<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * CHAMP : UN PICTOGRAMME DE LA PLANCHE DE CORPUS.
 *
 * LE MODULE NE TIENT AUCUN CATALOGUE D'ICONES, et c'est la meme regle que pour
 * les dispositions : il lit la planche du template et propose ce qu'il y
 * trouve. Une icone ajoutee dans Corpus apparait donc ici le jour meme, sans
 * que ce module soit relivre ; une icone retiree disparait de la liste au lieu
 * de sortir un carre vide dans la page.
 *
 * Recopier les 34 noms dans ce fichier aurait marche le premier jour et menti
 * le second. Le piege est documente dans `legend.php` de Corpus, ou il a mordu
 * DEUX fois : un groupe declare avec une icone qui n'existait pas rendait une
 * chaine vide, sans erreur, et le rail n'affichait rien.
 *
 * LA LECTURE EST BORNEE ET SANS EXECUTION. On ne fait qu'une expression
 * reguliere sur les `id` des `<symbol>` : le fichier de la planche n'est jamais
 * inclus ni execute, et rien de ce qu'il contient ne peut agir ici.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\ListField;
use Joomla\CMS\Language\Text;
use Joomla\Registry\Registry;

class JFormFieldBlocsIcone extends ListField
{
    protected $type = 'BlocsIcone';

    /**
     * Le chemin de la planche, relatif a la racine du site.
     *
     * DEUX SOURCES, DANS CET ORDRE. Celle du TEMPLATE d'abord : un site sous
     * Corpus, ou un template enfant qui a redessine ses icones, garde les
     * siennes, et le module ne les remplace pas. A defaut, CELLE DU MODULE,
     * livree avec lui, qui rend Opus utilisable sous Cassiopeia comme sous
     * n'importe quel autre template.
     *
     * C'est la meme regle qu'en page publique, ou le repartiteur ne pose la
     * planche du module que s'il n'a pas trouve celle du template.
     */
    protected function planche(): string
    {
        $template = (string) $this->element['template'];
        $template = $template !== '' ? preg_replace('#\W#', '', $template) : 'corpus';

        $duTemplate = 'templates/' . $template . '/html/layouts/corpus/pictogrammes.php';

        if (is_file(JPATH_ROOT . '/' . $duTemplate)) {
            return $duTemplate;
        }

        return 'media/mod_opus/icones/pictogrammes.svg';
    }

    /**
     * Les noms de pictogrammes trouves dans la planche, tries.
     *
     * Rend un tableau vide si la planche est introuvable : le champ propose
     * alors « aucune » et rien d'autre. Un module qui tourne sans Corpus perd
     * le choix des icones, il ne tombe pas en panne.
     */
    protected function pictogrammes(): array
    {
        $fichier = JPATH_ROOT . '/' . $this->planche();

        if (!is_file($fichier) || !is_readable($fichier)) {
            return [];
        }

        $contenu = file_get_contents($fichier);

        if ($contenu === false) {
            return [];
        }

        preg_match_all('#<symbol\s+id="(i-[a-z0-9-]+)"#i', $contenu, $trouves);

        $noms = array_values(array_unique($trouves[1] ?? []));

        sort($noms, SORT_STRING);

        return $noms;
    }

    /**
     * Les icones que l'administrateur a declarees dans l'onglet Icones.
     *
     * ELLES SE DECLARENT UNE FOIS ET SERVENT PARTOUT. Le champ ne va pas les
     * chercher dans la base : elles sont dans le FORMULAIRE en cours, donc a
     * jour meme si l'administrateur vient d'en ajouter une et n'a pas encore
     * enregistre. `getValue` sur le groupe `params` est le seul moyen de lire
     * un autre champ du meme formulaire.
     *
     * Rend un tableau nom => fichier. Une ligne sans nom ou sans fichier est
     * une ligne en cours de saisie : elle ne rentre pas dans la liste.
     */
    protected function mesIcones(): array
    {
        /*
         * LES ICONES SE LISENT DANS LE MODULE, PAS DANS LE FORMULAIRE, ET IL A
         * FALLU S'Y REPRENDRE.
         *
         * CE CHAMP VIT DANS UN SOUS-FORMULAIRE : un bouton est dans une pile
         * d'elements, elle-meme dans un bloc. `$this->form` n'est alors PAS le
         * formulaire du module mais celui de la LIGNE, qui ne contient que ses
         * propres champs. `getValue('iconesPerso')` y rendait donc toujours
         * vide, et les icones a soi n'apparaissaient dans aucune liste. Mesure
         * sur le banc le 25 septembre 2026 : 35 entrees, aucune en « perso: ».
         *
         * ON CHARGE DONC LE MODULE, une fois pour tout l'ecran : `static`
         * garde le resultat, et une page qui compte trente boutons ne fait
         * qu'une seule lecture.
         *
         * LE FORMULAIRE RESTE ESSAYE EN PREMIER, parce qu'il porte la saisie en
         * cours quand il est le bon : dans l'onglet Icones, une ligne ajoutee
         * et pas encore enregistree s'y voit.
         */
        static $enCache = null;

        $brut = null;

        if ($this->form) {
            $groupe = $this->group !== '' ? $this->group : 'params';
            $brut   = $this->form->getValue('iconesPerso', $groupe);
        }

        if ($brut === null || $brut === '' || $brut === []) {
            if ($enCache !== null) {
                return $enCache;
            }

            $brut = $this->iconesDuModule();
        }

        /*
         * TROIS FORMES POSSIBLES POUR LA MEME DONNEE, ET IL FAUT LES TROIS.
         *
         * Un sous-formulaire arrive en tableau quand il vient d'etre envoye,
         * en objet quand il sort du Registry des parametres, et en CHAINE JSON
         * quand le Registry n'a pas encore ete decode. La troisieme est celle
         * qui manquait : `is_array` rendait faux, la methode rendait un
         * tableau vide, et la grille disait « aucune icone declaree » alors que
         * le formulaire juste en dessous en montrait une. Vu le 25 septembre
         * 2026.
         */
        if (\is_string($brut)) {
            $decode = json_decode($brut);
            $brut   = $decode === null ? [] : $decode;
        }

        if (\is_object($brut)) {
            $brut = (array) $brut;
        }

        if (!\is_array($brut)) {
            return [];
        }

        $miennes = [];

        foreach ($brut as $ligne) {
            $ligne = (array) $ligne;

            $nom     = trim((string) ($ligne['nom'] ?? ''));
            $fichier = trim((string) ($ligne['fichier'] ?? ''));

            if ($nom === '' || $fichier === '') {
                continue;
            }

            /*
             * LE NOM EST RAMENE A CE QUI PEUT SERVIR DE NOM. Il finit dans une
             * classe CSS et dans un nom de variable, et une saisie libre y
             * mettrait des espaces ou des accents. Le manifeste pose deja
             * `validate="CssIdentifier"` ; ceci couvre une valeur arrivee par
             * un import.
             */
            $nom = strtolower(preg_replace('#[^A-Za-z0-9-]#', '-', $nom));

            if ($nom === '' || $nom === '-') {
                continue;
            }

            $miennes[$nom] = $fichier;
        }

        ksort($miennes, SORT_STRING);

        $enCache = $miennes;

        return $miennes;
    }

    /**
     * Les icones declarees, lues dans le module enregistre.
     *
     * L'IDENTIFIANT VIENT DE L'ADRESSE, comme pour tout l'ecran d'edition d'un
     * module. Sur un module qui n'a jamais ete enregistre, il vaut zero et il
     * n'y a rien a lire : c'est le cas normal d'un module qu'on vient de
     * creer, pas une panne.
     */
    protected function iconesDuModule()
    {
        $app = Factory::getApplication();

        if (!$app->isClient('administrator')) {
            return null;
        }

        $id = (int) $app->getInput()->getInt('id');

        if ($id < 1) {
            return null;
        }

        $bd = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);

        $requete = $bd->getQuery(true)
            ->select($bd->quoteName('params'))
            ->from($bd->quoteName('#__modules'))
            ->where($bd->quoteName('id') . ' = :id')
            ->bind(':id', $id, \Joomla\Database\ParameterType::INTEGER);

        $bd->setQuery($requete);

        $params = (string) $bd->loadResult();

        if ($params === '') {
            return null;
        }

        $registre = new Registry($params);

        return $registre->get('iconesPerso');
    }

    protected function getOptions()
    {
        $options = [];

        // « Aucune » en tete, et selectionnee par defaut : un bouton sans icone
        // est le cas ordinaire, il ne doit demander aucun geste.
        $options[] = (object) [
            'value'    => '',
            'text'     => Text::_('MOD_OPUS_ICON_NONE'),
            'disable'  => false,
        ];

        foreach ($this->pictogrammes() as $nom) {
            /*
             * L'INTITULE EST LE NOM DU PICTOGRAMME, pas une traduction.
             *
             * `i-fleche` se retrouve dans la planche, dans le HTML produit et
             * dans le CSS ; un intitule traduit obligerait a faire le chemin
             * inverse pour savoir de quoi on parle. La liste est courte et les
             * noms sont en francais, comme le reste du vocabulaire du projet.
             */
            $options[] = (object) [
                'value'   => $nom,
                'text'    => $nom,
                'disable' => false,
            ];
        }

        /*
         * MES ICONES VIENNENT APRES CELLES DE LA PLANCHE, et leur valeur porte
         * un prefixe, `perso:`. Deux raisons : un nom a soi ne peut alors
         * jamais masquer une icone livree, et la mise en page sait au premier
         * coup d'oeil laquelle des deux mecaniques employer, le symbole ou le
         * masque, sans avoir a relire la liste des icones declarees.
         */
        foreach ($this->mesIcones() as $nom => $fichier) {
            $options[] = (object) [
                'value'   => 'perso:' . $nom,
                'text'    => $nom,
                'disable' => false,
            ];
        }

        return array_merge($options, parent::getOptions());
    }

    protected function getInput()
    {
        $liste = parent::getInput();

        if ($this->pictogrammes() !== []) {
            return $liste;
        }

        // La planche est introuvable : on le dit, plutot que de laisser une
        // liste vide que l'on croirait cassee.
        return $liste
            . '<small class="form-text">' . Text::_('MOD_OPUS_ICON_NO_SHEET') . '</small>';
    }
}
