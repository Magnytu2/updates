/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LA CARTE DU MONTAGE.
 *
 * Elle dit CE QUI SORTIRA, pas ce qui est saisi : un element masque n'y figure
 * pas, un bouton sans libelle non plus, une rangee vide est signalee. Un apercu
 * qui ment une seule fois ne sert plus a rien.
 *
 * ELLE SE REDESSINE SUR TROIS BRANCHEMENTS, ET C'EST LE POINT IMPORTANT :
 *
 *   1. un `change` delegue au formulaire, qui attrape tous les champs, y
 *      compris ceux qui n'existaient pas au chargement ;
 *   2. `subform-row-add` et `subform-row-remove`, SANS prefixe `joomla:` : les
 *      evenements du composant du coeur s'appellent ainsi, et un ecouteur pose
 *      sur le mauvais nom ne se declenche jamais sans rien signaler ;
 *   3. un dessin AU CHARGEMENT.
 *
 * C'est ce troisieme branchement qui manque dans Corpus aujourd'hui, et c'est
 * pourquoi sa carte reste vide tant qu'on n'a rien selectionne.
 */
(function () {
  'use strict';

  var FIELDSET = 'fieldset-montage';

  /**
   * LA ZONE DE CSS PERSONNALISE, ET IL Y EN A DEUX SELON LE SITE.
   *
   * Depuis le 25 septembre 2026, le champ est un EDITEUR : CodeMirror quand le
   * plugin est actif, une zone de texte nue sinon. Dans les deux cas le
   * `textarea` existe, c'est lui qui porte la valeur envoyee ; mais avec
   * CodeMirror il est MASQUE, et ce qu'on y ecrit directement n'apparait pas a
   * l'ecran tant que l'editeur ne l'a pas relu.
   *
   * Ces trois fonctions sont le seul endroit qui connait cette difference.
   */
  function zoneCss() {
    return document.getElementById('jform_params_customCss');
  }

  /**
   * L'ELEMENT A DEPLACER QUAND ON RANGE L'ECRAN.
   *
   * Avec CodeMirror, deplacer le `textarea` seul laisserait l'editeur derriere
   * lui : c'est l'enveloppe entiere qu'il faut prendre. Sans lui, l'enveloppe
   * n'existe pas et la zone de texte se deplace elle-meme.
   */
  function blocCss(zone) {
    return zone.closest('joomla-editor-codemirror, joomla-editor-none, .js-editor, .editor') || zone;
  }

  /** La valeur, lue par l'editeur s'il y en a un. */
  function lireCss(zone) {
    var e = window.Joomla && Joomla.editors && Joomla.editors.instances
      ? Joomla.editors.instances[zone.id] : null;

    return e && e.getValue ? e.getValue() : zone.value;
  }

  /**
   * La valeur, ECRITE par l'editeur s'il y en a un.
   *
   * ON PASSE PAR SON API, jamais par `zone.value` : CodeMirror tient son
   * propre document et ne relit pas le `textarea`. Ecrire directement dedans
   * marchait hier, avec une zone de texte nue, et ne montrerait plus rien
   * aujourd'hui.
   */
  function ecrireCss(zone, valeur) {
    var e = window.Joomla && Joomla.editors && Joomla.editors.instances
      ? Joomla.editors.instances[zone.id] : null;

    if (e && e.setValue) {
      e.setValue(valeur);
    } else {
      zone.value = valeur;
    }

    /*
     * ON PREVIENT TOUJOURS, ET DEPUIS LA ZONE. La jauge de remplissage et le
     * releve des regles orphelines ecoutent `input`, sur le champ ou sur le
     * formulaire. CodeMirror, lui, n'emet rien quand on lui pose une valeur
     * par son API : sans cette ligne, la jauge restait sur le chiffre d'avant
     * jusqu'a la frappe suivante.
     */
    zone.dispatchEvent(new Event('input', { bubbles: true }));
    zone.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function texte(cle, defaut) {
    if (window.Joomla && Joomla.Text && Joomla.Text._) {
      var t = Joomla.Text._(cle);
      if (t && t !== cle) { return t; }
    }
    return defaut;
  }

  /**
   * Les lignes d'un sous-formulaire, lues dans le DOM.
   *
   * On lit les champs la ou ils sont, sans jamais deplacer un noeud : le
   * composant du coeur renumerote les `name` de toute la ligne a chaque ajout
   * ou retrait, et un champ sorti de sa ligne perdrait sa valeur en silence.
   *
   * `rangeesDe` EST OBLIGATOIRE DEPUIS QUE LES LISTES SONT IMBRIQUEES.
   * `querySelectorAll('.subform-repeatable-group')` descend dans TOUT le
   * sous-arbre : sur la liste des blocs, il ramenait aussi les lignes des
   * listes de contenu qui vivent a l'interieur de chaque bloc. La carte
   * comptait alors quinze blocs la ou il y en avait trois.
   */
  function rangeesDe(hote) {
    return [].slice.call(hote.querySelectorAll('.subform-repeatable-group'))
      .filter(function (g) {
        return g.closest('joomla-field-subform') === hote;
      });
  }

  /**
   * Lit un champ d'une ligne, en restant dans cette ligne.
   *
   * ON NE PREND PAS LE PREMIER TROUVE, ON PREND LE PREMIER QUI EST A NOUS.
   *
   * La ligne d'un bloc contient une liste de contenu, et chaque ligne de cette
   * liste porte les memes noms de champ : `type`, `label`, `title`, `show`.
   * Dans le document, celles-la viennent AVANT les siens. Un
   * `querySelector` simple ramenait donc la carte au lieu du bloc, et le garde
   * qui s'en apercevait rendait une chaine vide au lieu de chercher plus loin.
   *
   * CE QUE CELA COUTAIT : `affiche` valait `'' !== '0'`, donc toujours vrai. Un
   * bloc a l'oeil ferme restait dans la carte du montage, qui annonce pourtant
   * de ne montrer que ce qui sortira. Vu sur le banc le 21 septembre 2026, en
   * mettant le bloc Cartes de cote pour regarder l'Ouverture seule. Le meme
   * silence valait pour `type`, `label`, `body`, `title` et `button1Text`.
   *
   * LE `:checked` SE CHERCHE DANS LA MEME LISTE, et non dans toute la ligne :
   * sinon un bouton radio d'une carte repondait pour le bloc.
   */
  function champDe(ligne, suffixe) {
    var miens = [].slice.call(ligne.querySelectorAll('[name$="[' + suffixe + ']"]'))
      .filter(function (e) {
        return e.closest('.subform-repeatable-group') === ligne;
      });

    if (miens.length === 0) { return ''; }

    if (miens[0].type === 'radio') {
      var coche = miens.filter(function (e) { return e.checked; })[0];

      return coche ? coche.value : '';
    }

    return miens[0].value;
  }

  /**
   * Le libelle du premier bouton d'une ligne d'element.
   *
   * DEPUIS LE 22 SEPTEMBRE 2026, LES BOUTONS SONT UNE LISTE. La carte du
   * montage lisait `button1Text`, un champ plat qui n'existe plus. Elle ne
   * cherche donc plus un champ mais la premiere ligne de la liste `[boutons]`
   * de CETTE ligne-ci : `querySelectorAll` descendrait sinon dans les listes
   * des lignes voisines, et c'est le piege numero un.
   */
  function premierBouton(ligne) {
    var liste = hoteListe(ligne, 'boutons');

    if (!liste) { return ''; }

    var premiere = rangeesDe(liste)[0];

    return premiere ? champDe(premiere, 'text') : '';
  }

  function lignes(champ) {
    var hote = document.querySelector('joomla-field-subform[name="jform[params][' + champ + ']"]');
    if (!hote) { return []; }

    return rangeesDe(hote).map(function (g) {
      return {
        noeud:   g,
        type:    champDe(g, 'type'),
        label:   champDe(g, 'label'),
        body:    champDe(g, 'body'),
        titre:   champDe(g, 'title'),
        bouton:  premierBouton(g),
        rapport:  champDe(g, 'rapport'),
        colonnes: champDe(g, 'colonnes'),
        rangee:   champDe(g, 'rangee'),
        colonne:  champDe(g, 'colonne'),
        fond:     champDe(g, 'fond'),
        affiche: champDe(g, 'show') !== '0'
      };
    });
  }

  /**
   * Les lignes d'une liste de contenu INTERIEURE a un bloc.
   *
   * Le nom de la liste imbriquee est stable : `[elements]`, `[cartes]` ou
   * `[diapos]`. On la cherche donc dans la ligne du bloc, et on ne compte que
   * ses propres lignes.
   */
  function contenuDe(ligneBloc, nom) {
    var hote = [].slice.call(ligneBloc.querySelectorAll('joomla-field-subform'))
      .filter(function (s) {
        return (s.getAttribute('name') || '').slice(-(nom.length + 2)) === '[' + nom + ']';
      })[0];

    if (!hote) { return []; }

    return rangeesDe(hote).map(function (g) {
      return {
        noeud:   g,
        type:    champDe(g, 'type'),
        label:   champDe(g, 'label'),
        body:    champDe(g, 'body'),
        titre:   champDe(g, 'title'),
        bouton:  premierBouton(g),
        affiche: champDe(g, 'show') !== '0'
      };
    });
  }

  /**
   * Le nom lisible d'un element, pour la carte.
   *
   * ELLE NE COUVRAIT QUE CINQ TYPES SUR DIX-NEUF, et le repli `|| l.type` le
   * cachait : la carte affichait « onglets », « barres », « chiffres » en
   * minuscule, le nom interne, au milieu de noms propres. Mesure du 24
   * septembre 2026, apres la remarque de Cyrille sur « Ce qui sortira ».
   *
   * LA LISTE COMPLETE, ET L'ORDRE EST CELUI DU MANIFESTE, pour qu'un type
   * ajoute demain se voie manquant d'un coup d'oeil.
   */
  function nomElement(l) {
    var libelles = {
      heading:    texte('MOD_OPUS_ELEMENT_HEADING', 'Titre'),
      subheading: texte('MOD_OPUS_ELEMENT_SUBHEADING', 'Sous-titre'),
      text:       texte('MOD_OPUS_ELEMENT_TEXT', 'Texte'),
      separator:  texte('MOD_OPUS_ELEMENT_SEPARATOR', 'Separateur'),
      buttons:    texte('MOD_OPUS_ELEMENT_BUTTONS', 'Bouton'),
      image:      texte('MOD_OPUS_BLOCK_IMAGE', 'Image'),
      liste:      texte('MOD_OPUS_ELEMENT_LIST', 'Liste'),
      alerte:     texte('MOD_OPUS_ELEMENT_ALERT', 'Alerte'),
      points:     texte('MOD_OPUS_ELEMENT_POINTS', 'Points cles'),
      citation:   texte('MOD_OPUS_ELEMENT_QUOTE', 'Citation'),
      chiffres:   texte('MOD_OPUS_ELEMENT_FIGURES', 'Chiffres cles'),
      barres:     texte('MOD_OPUS_ELEMENT_BARS', 'Barres'),
      accordeon:  texte('MOD_OPUS_ELEMENT_ACCORDION', 'Accordeon'),
      liens:      texte('MOD_OPUS_ELEMENT_LINKS', 'Liens'),
      etat:       texte('MOD_OPUS_ELEMENT_STATE', 'Etat'),
      adresse:    texte('MOD_OPUS_ELEMENT_ADDRESS', 'Adresse'),
      contact:    texte('MOD_OPUS_ELEMENT_CONTACT', 'Contact'),
      fiche:      texte('MOD_OPUS_ELEMENT_SPECS', 'Fiche')
    };
    return libelles[l.type] || l.type || '?';
  }

  /**
   * Un element sortira-t-il ?
   *
   * Masque : non. Sans contenu : non plus, et la mise en page fait exactement
   * le meme test. Les deux doivent dire la meme chose, sinon l'apercu ment.
   */
  function sort(l) {
    if (!l.affiche) { return false; }
    if (l.type === 'heading' || l.type === 'subheading') { return l.label.trim() !== ''; }
    if (l.type === 'text') { return l.body.trim() !== ''; }
    if (l.type === 'buttons') { return l.bouton.trim() !== ''; }
    return true;
  }

  function jeton(libelle, classes) {
    var s = document.createElement('span');
    s.className = 'blocs-carte__jeton' + (classes ? ' ' + classes : '');
    s.textContent = libelle;
    return s;
  }

  /** Une rangee de la carte : son intitule, puis ses jetons. */
  function rangee(intitule) {
    var r = document.createElement('div');
    r.className = 'blocs-carte__rangee';

    var n = document.createElement('div');
    n.className = 'blocs-carte__num';
    n.textContent = intitule;
    r.appendChild(n);

    return r;
  }

  function vide(r) {
    var v = document.createElement('span');
    v.className = 'blocs-carte__vide';
    v.textContent = texte('MOD_OPUS_MAP_EMPTY', 'Aucun element pour l\'instant.');
    r.appendChild(v);
  }

  /** Le nom lisible d'un type de bloc. */
  function nomBloc(type) {
    var libelles = {
      ouverture: texte('MOD_OPUS_BLOCK_OPENING', 'Ouverture'),
      cartes:    texte('MOD_OPUS_BLOCK_CARDS', 'Cartes'),
      carrousel: texte('MOD_OPUS_BLOCK_CAROUSEL', 'Carrousel'),
      onglets:   texte('MOD_OPUS_BLOCK_TABS', 'Onglets'),
      frise:     texte('MOD_OPUS_BLOCK_TIMELINE', 'Frise'),
      galerie:   texte('MOD_OPUS_BLOCK_GALLERY', 'Galerie'),
      portraits: texte('MOD_OPUS_BLOCK_PORTRAITS', 'Portraits'),
      image:     texte('MOD_OPUS_BLOCK_IMAGE', 'Image'),
      liste:     texte('MOD_OPUS_ELEMENT_LIST', 'Liste'),
      alerte:    texte('MOD_OPUS_ELEMENT_ALERT', 'Alerte'),
      points:    texte('MOD_OPUS_ELEMENT_POINTS', 'Points cles'),
      citation:  texte('MOD_OPUS_ELEMENT_QUOTE', 'Citation'),
      chiffres:  texte('MOD_OPUS_ELEMENT_FIGURES', 'Chiffres cles'),
      accordeon: texte('MOD_OPUS_ELEMENT_ACCORDION', 'Accordeon'),
      liens:     texte('MOD_OPUS_ELEMENT_LINKS', 'Liens'),
      etat:      texte('MOD_OPUS_ELEMENT_STATE', 'Etat'),
      /*
       * LA TABLE ETAIT INCOMPLETE, et le repli `|| type` le cachait : la carte
       * du montage affichait « onglets » en minuscule, le nom interne, au
       * milieu de noms propres. Mesure du 24 septembre 2026. Dix types y
       * manquaient, dont les six ajoutes depuis le 23.
       */
      heading:    texte('MOD_OPUS_ELEMENT_HEADING', 'Titre'),
      subheading: texte('MOD_OPUS_ELEMENT_SUBHEADING', 'Sous-titre'),
      text:       texte('MOD_OPUS_ELEMENT_TEXT', 'Texte'),
      separator:  texte('MOD_OPUS_ELEMENT_SEPARATOR', 'Separateur'),
      buttons:    texte('MOD_OPUS_ELEMENT_BUTTONS', 'Boutons'),
      adresse:    texte('MOD_OPUS_ELEMENT_ADDRESS', 'Adresse'),
      contact:    texte('MOD_OPUS_ELEMENT_CONTACT', 'Contact'),
      fiche:      texte('MOD_OPUS_ELEMENT_SPECS', 'Fiche'),
      barres:     texte('MOD_OPUS_ELEMENT_BARS', 'Barres')
    };

    return libelles[type] || type || '?';
  }

  /** Quelle liste de contenu ce type de bloc emploie-t-il ? */
  function listeDe(type) {
    if (type === 'ouverture') { return 'elements'; }
    if (type === 'onglets') { return 'onglets'; }
    if (type === 'frise') { return 'etapes'; }
    return 'cartes';
  }

  /** Les jetons d'un bloc : son nom, puis ce qu'il contient. */
  function jetonsBloc(cellule, bloc) {
    cellule.appendChild(jeton(nomBloc(bloc.type), 'blocs-carte__jeton--fort'));

    var contenu = contenuDe(bloc.noeud, listeDe(bloc.type));

    if (contenu.length === 0) {
      cellule.appendChild(jeton(
        texte('MOD_OPUS_MAP_NOCONTENT', 'a remplir'),
        'blocs-carte__jeton--masque'
      ));

      return;
    }

    if (bloc.type === 'ouverture') {
      /*
       * L'OUVERTURE MONTRE SES ELEMENTS UN PAR UN, les autres blocs se
       * comptent. Une pile de cinq elements, on veut savoir LESQUELS ; une
       * grille de douze cartes, on veut savoir COMBIEN.
       */
      contenu.forEach(function (l) {
        var nom = nomElement(l);

        if (!sort(l)) {
          cellule.appendChild(jeton(
            nom + ' · ' + texte(l.affiche ? 'MOD_OPUS_MAP_NOLABEL' : 'MOD_OPUS_MAP_HIDDEN', 'vide'),
            'blocs-carte__jeton--masque'
          ));

          return;
        }

        cellule.appendChild(jeton(nom));
      });

      return;
    }

    var sortent = contenu.filter(function (l) { return l.affiche; });
    var mots = {
      carrousel: texte('MOD_OPUS_MAP_SLIDES', 'diapos'),
      galerie:   texte('MOD_OPUS_MAP_IMAGES', 'images')
    };

    var mot = mots[bloc.type] || texte('MOD_OPUS_MAP_CARDS', 'cartes');

    cellule.appendChild(jeton(
      sortent.length === contenu.length
        ? sortent.length + ' ' + mot
        : sortent.length + ' ' + mot + ' ' + texte('MOD_OPUS_MAP_OUTOF', 'sur') + ' ' + contenu.length
    ));

    if (sortent.length < contenu.length) {
      cellule.appendChild(jeton(
        (contenu.length - sortent.length) + ' ' + texte('MOD_OPUS_MAP_HIDDENPL', 'masquees'),
        'blocs-carte__jeton--masque'
      ));
    }
  }

  /**
   * La carte du montage : une rangee par rangee, une case par colonne.
   *
   * ELLE SUIT LE RAPPORT, PAS UNE GRILLE GENERIQUE : le vis-a-vis qu'on y voit
   * est celui qui sortira. Une carte qui montre deux colonnes egales quand le
   * rapport est 3/9 ment une fois, et ne sert plus jamais.
   */
  function dessiner() {
    /*
     * LES RANGS SUIVENT LE MEME RYTHME QUE LA CARTE DU MONTAGE : un retrait
     * ou un deplacement la redessine, et il renumerote donc les cartes dans
     * le meme souffle. Sans cela, la carte 3 gardait son nom apres le retrait
     * de la 2.
     */
    numeroterCartes();

    /*
     * LES PICTOGRAMMES SE REPLACENT AU MEME RYTHME. Changer le type d un
     * element change les champs visibles de sa ligne : le premier outil n est
     * plus le meme, et le vide qui le precede doit changer de case. Le poser
     * une seule fois, a la creation de la ligne, ne tenait qu une seconde.
     */
    [].slice.call(document.querySelectorAll('#' + FIELDSET + ' div.subform-repeatable-group'))
      .forEach(outilsADroite);

    /*
     * LES INTITULES SE RECALCULENT AU MEME RYTHME, ET POUR LA MEME RAISON :
     * changer le type d'une ligne peut la detacher du groupe du dessus, ou l'y
     * rattacher. Pose une seule fois a la creation, le marquage mentirait des
     * le premier changement de type.
     */
    [].slice.call(document.querySelectorAll('#' + FIELDSET + ' joomla-field-subform[name$="[elements]"]'))
      .forEach(marquerRepetitions);

    allumerModeles();

    var carte = document.getElementById('blocs-carte');
    if (!carte) { return; }

    carte.textContent = '';

    var lesRangees = lignes('rangees');
    var lesBlocs = lignes('blocs').filter(function (b) { return b.affiche; });

    if (lesRangees.length === 0) {
      var r0 = rangee(texte('MOD_OPUS_MAP_NOROW', 'Aucune rangee pour l\'instant.'));
      carte.appendChild(r0);
      noter(carte);
      return;
    }

    lesRangees.forEach(function (rg, i) {
      var numero = i + 1;

      /*
       * LE MEME CALCUL QUE L'ASSISTANT, ET C'EST OBLIGATOIRE.
       *
       * Nombre de colonnes plafonne a trois, rapport en douziemes qui retombe
       * sur des parts egales quand il ne correspond pas, codes p, g, c, d. Si
       * les deux comptes divergent d'un cheveu, la carte montre une rangee et
       * la page en sort une autre : elle ment une fois, et ne sert plus.
       */
      var colonnes = Math.max(1, Math.min(3, parseInt(rg.colonnes, 10) || 1));
      var codes = colonnes >= 3 ? ['g', 'c', 'd'] : (colonnes === 2 ? ['g', 'd'] : ['p']);
      var parts = (rg.rapport || '').split('-').map(function (p) { return parseInt(p, 10); })
        .filter(function (n) { return !isNaN(n); });

      if (parts.length !== colonnes || parts.reduce(function (a, b) { return a + b; }, 0) !== 12) {
        var egal = Math.floor(12 / colonnes);
        parts = [];
        for (var k = 0; k < colonnes; k++) { parts.push(egal); }
        parts[0] += 12 - (egal * colonnes);
      }

      var intitule = texte('MOD_OPUS_BLOCK_ROW_LABEL', 'Rangee') + ' ' + numero
        + ' · ' + parts.join(' / ');

      /*
       * PLUS DE RANGEE MASQUEE : l'oeil a quitte la rangee le 21 septembre
       * 2026. Le `-` la supprime, et une rangee sans bloc ne sort pas. La
       * carte n'a donc plus d'etat « masquee » a annoncer a ce niveau.
       */

      var dedans = lesBlocs.filter(function (b) { return (parseInt(b.rangee, 10) || 1) === numero; });

      if (dedans.length === 0) {
        var rv = rangee(intitule);
        rv.appendChild(jeton(texte('MOD_OPUS_MAP_NOBLOCK', 'aucun bloc, ne sortira pas'), 'blocs-carte__jeton--masque'));
        carte.appendChild(rv);
        return;
      }

      var entete = document.createElement('div');
      entete.className = 'blocs-carte__num';
      entete.textContent = intitule;
      carte.appendChild(entete);

      var grille = document.createElement('div');
      grille.className = 'blocs-carte__duo';
      grille.style.gridTemplateColumns = parts.map(function (p) { return p + 'fr'; }).join(' ');

      codes.forEach(function (code) {
        var cellule = document.createElement('div');
        cellule.className = 'blocs-carte__rangee';

        var ici = dedans.filter(function (b) {
          var c = (b.colonne || 'p').charAt(0);

          // Un code hors de la rangee retombe sur sa premiere colonne,
          // exactement comme dans l'assistant.
          if (codes.indexOf(c) === -1) { c = codes[0]; }

          return c === code;
        });

        if (ici.length === 0) {
          vide(cellule);
        } else {
          ici.forEach(function (b) { jetonsBloc(cellule, b); });
        }

        grille.appendChild(cellule);
      });

      carte.appendChild(grille);
    });

    noter(carte);
  }

  /**
   * LA PHRASE SOUS LA CARTE REPOND A LA SEULE QUESTION QU'ELLE SOULEVE :
   * pourquoi un element saisi n'apparait-il pas. Elle est toujours visible, et
   * c'est voulu : cachee derriere un bouton, elle serait lue une fois par an,
   * c'est-a-dire jamais au moment ou elle servirait.
   */
  function noter(carte) {
    var p = document.createElement('p');
    p.className = 'blocs-carte__note';
    p.textContent = texte(
      'MOD_OPUS_MAP_NOTE',
      'Elle dit ce qui sortira, pas ce qui est saisi : un element a l\'oeil barre n\'y figure pas, un bouton sans libelle non plus.'
    );
    carte.appendChild(p);
  }

  /*
   * IL N'Y A PLUS DE BLOCS ENCADRES, ET C'ETAIT MON INVENTION.
   *
   * J'avais enveloppe chaque section dans un cadre avec un chevron, un
   * pictogramme et un « i », en lisant la maquette au pied de la lettre. Les
   * onglets Template blog et Template article de Corpus ne font rien de tout
   * cela : un intitule, un bouton d'ajout, un tableau, une aide en dessous. Ce
   * sont deux cent trente lignes de script qui servaient a imiter, mal, ce que
   * le gabarit du coeur fait tout seul.
   *
   * Decision de Cyrille le 21 septembre 2026 : s'inspirer a cent pour cent des
   * templates de Corpus.
   */

  /* ==========================================================================
     LES OUTILS D'UNE RANGEE

     Deux choses que Joomla ne fournit pas : dupliquer une rangee, et montrer
     les alignements par des pictogrammes plutot que par des mots.

     LES PICTOGRAMMES SONT DESSINES ICI, EN SVG, ET NON PRIS DANS CORPUS.

     Le champ `legend` du template dessine les siens de la meme facon, dans son
     propre fichier. La raison est la meme : quinze traits de SVG coutent moins
     qu'une dependance a une planche d'icones qu'il faudrait tenir a jour des
     deux cotes. Ils heritent de la couleur du texte, donc ils suivent le mode
     sombre sans une regle de plus.
     ========================================================================== */

  var PICTOGRAMMES = {
    /*
     * LES DEUX FAMILLES PORTENT LES MEMES VALEURS, et c'est le piege.
     *
     * « Alignement » et « Contenu dans la hauteur » valent tous deux start,
     * center et end : ce sont les mots de CSS, et ils ne disent pas dans quel
     * sens. Choisir le dessin sur la seule valeur donnait les traits
     * horizontaux au reglage vertical, sans que rien ne le signale, le dessin
     * etant plausible dans les deux cas.
     *
     * La famille se lit donc sur le NOM du champ, pas sur sa valeur.
     */
    'h-start':  '<path d="M3 5h18M3 10h10M3 15h18M3 20h10"/>',
    'h-center': '<path d="M3 5h18M7 10h10M3 15h18M7 20h10"/>',
    'h-end':    '<path d="M3 5h18M11 10h10M3 15h18M11 20h10"/>',
    'v-start':  '<path d="M4 4h16M8 9v11M12 9v7M16 9v11"/>',
    'v-center': '<path d="M4 12h16M8 6v12M12 8v8M16 6v12"/>',
    'v-end':    '<path d="M4 20h16M8 4v11M12 8v7M16 4v11"/>',

    /*
     * LE SENS D'UNE RANGEE DE BOUTONS : une fleche, et rien d'autre.
     *
     * Ce n'est pas un alignement, c'est une direction, et les deux se
     * confondraient : trois traits pour « a gauche », trois traits pour
     * « l'un sous l'autre », l'oeil ne les departagerait pas. Une fleche vers
     * la droite, une fleche vers le bas, on lit la direction sans la
     * connaitre.
     */
    's-row':    '<path d="M4 12h14M13 7l5 5-5 5"/>',
    's-column': '<path d="M12 4v14M7 13l5 5 5-5"/>',
    'copier':   '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h8"/>',

    /* L'oeil ouvert et l'oeil barre. LE TRAIT EN DIAGONALE NE SUFFIT PAS A LUI
       SEUL : l'etat coche change aussi le trait du bouton, et le mot
       « Masque » reste dans le document. Deux signaux pour un etat qu'on lit
       d'un coup d'oeil et qui se trompe cher.

       LE MEME OEIL DANS LES DEUX ETATS, ET C'EST TOUT LE SUJET.

       L'oeil barre etait dessine avec deux arcs INTERROMPUS, la paupiere du
       haut et celle du bas, ecartees pour laisser passer la barre. A seize
       pixels ces deux arcs se rejoignent visuellement et se referment en
       tache : « l'oeil rouge bizarre », 21 septembre 2026, verifie a la loupe.

       On reprend donc le trace de l'oeil OUVERT, entier, et l'on pose la barre
       par-dessus. Les deux etats montrent le meme objet, l'un raye.

       SANS LA PUPILLE, ET C'EST MESURE. Les trois variantes ont ete dessinees
       cote a cote dans la page, a 64 px et a 16 px. A 16 px, la pupille et la
       barre se croisent au centre et forment un point plein : c'etait, deja,
       le « point rouge au milieu ». L'oeil barre n'a donc pas de pupille. Il
       n'en manque rien : un oeil ferme ne regarde pas. */
    'oeil-1':   '<path d="M2 12s3.6-6 10-6 10 6 10 6-3.6 6-10 6-10-6-10-6z"/><circle cx="12" cy="12" r="2.6"/>',
    'oeil-0':   '<path d="M2 12s3.6-6 10-6 10 6 10 6-3.6 6-10 6-10-6-10-6z"/><path d="M4 4l16 16"/>'
  };

  /**
   * La famille de pictogrammes d'un champ, d'apres son nom.
   *
   * Rend `null` pour tout autre champ : un groupe de boutons radio qui n'est
   * pas un alignement garde ses mots. C'est ce qui evite de transformer en
   * dessins des reglages qui n'en ont pas.
   */
  function famille(nom) {
    nom = String(nom || '');

    /*
     * LE CHAMP DE L'ALIGNEMENT VERTICAL S'APPELLE MAINTENANT `hauteur`.
     *
     * Il s'appelait `rowVerticalAlign` avant le modele rangees + blocs, et
     * seul ce nom etait teste : depuis, sa case du tableau des rangees
     * n'affichait plus qu'un carre vide, sans la moindre erreur pour le dire.
     * Les deux noms sont reconnus, l'ancien parce qu'un module regle avant la
     * bascule le porte encore.
     */
    if (/vertical/i.test(nom) || /\[hauteur\]$/.test(nom)) { return 'v-'; }
    if (/\[align\]$/.test(nom)) { return 'h-'; }

    /*
     * LE SENS D'UNE RANGEE DE BOUTONS, depuis le 22 septembre 2026. Il prend
     * la place de l'alignement sur une ligne de boutons, qui n'y a plus de
     * sens : une rangee de boutons suit l'alignement de son bloc.
     */
    if (/\[sens\]$/.test(nom)) { return 's-'; }
    if (/\[show\]$/.test(nom)) { return 'oeil-'; }

    return null;
  }

  function pictogramme(cle) {
    if (!PICTOGRAMMES[cle]) { return null; }

    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('width', '16');
    svg.setAttribute('height', '16');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', '2');
    svg.setAttribute('stroke-linecap', 'round');
    svg.setAttribute('stroke-linejoin', 'round');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    svg.innerHTML = PICTOGRAMMES[cle];

    return svg;
  }

  /* --- Les alignements en pictogrammes ----------------------------------- */

  /**
   * Remplace le MOT d'un bouton d'alignement par son dessin.
   *
   * LE MOT RESTE DANS LE DOCUMENT, cache a l'oeil seulement. Un lecteur
   * d'ecran annonce donc toujours « A gauche », « Au centre », « A droite » :
   * le pictogramme ne remplace pas l'information, il la montre autrement.
   *
   * On ne touche qu'au contenu d'un `label` : aucun element personnalise n'est
   * deplace ni reconstruit, c'est la contrainte de tout cet ecran.
   */
  function iconiser(racine) {
    /*
     * `.btn-group` EST SUR UN DIV, PAS SUR LE FIELDSET.
     *
     * Le gabarit `joomla.form.field.radio.buttons` rend un `fieldset` qui
     * contient une legende PUIS un `div.btn-group`. Vise en
     * `fieldset.btn-group`, ce selecteur ne trouvait rien : les boutons
     * restaient avec leurs mots, sans la moindre erreur pour le dire. Releve
     * dans le navigateur le 19 septembre 2026 apres installation.
     *
     * `.controls` EN TETE, et ce n'est pas un ornement : la barre de commandes
     * d'une rangee de sous-formulaire porte elle aussi un `.btn-group`, et
     * elle n'est pas dans `.controls`. Sans ce prefixe, l'habillage des
     * boutons d'alignement retombait sur la colonne des commandes.
     */
    var groupes = racine.querySelectorAll('.controls .btn-group');

    [].slice.call(groupes).forEach(function (groupe) {
      [].slice.call(groupe.querySelectorAll('input[type="radio"]')).forEach(function (radio) {
        var prefixe = famille(radio.name);
        if (!prefixe) { return; }

        var dessin = pictogramme(prefixe + radio.value);
        if (!dessin) { return; }

        var etiquette = groupe.querySelector('label[for="' + radio.id + '"]');
        if (!etiquette || etiquette.dataset.opusIconise) { return; }

        var mot = etiquette.textContent.trim();

        etiquette.textContent = '';
        etiquette.appendChild(dessin);

        var cache = document.createElement('span');
        cache.className = 'visually-hidden';
        cache.textContent = mot;
        etiquette.appendChild(cache);

        // L'infobulle : le meme mot, pour qui voit mais ne devine pas le dessin.
        etiquette.title = mot;
        etiquette.dataset.opusIconise = '1';
      });

      /*
       * LES DESSINS D'ABORD, LA FORME ENSUITE, ET L'ORDRE COMPTE : les deux
       * fonctions recopient le dessin du choix retenu, il leur faut donc
       * exister. A deux valeurs on bascule, a trois et plus on replie.
       */
      bascule(groupe);
      replierChoix(groupe);
    });
  }


  /**
   * Remplace un choix a deux valeurs par UN bouton qui bascule.
   *
   * C'EST L'OEIL DE LA MAQUETTE, son `oeil-bascule` : un seul carre, qui montre
   * l'oeil ouvert ou l'oeil barre selon l'etat, et qui change au clic. Deux
   * carres cote a cote demandaient de comparer lequel est allume avant de
   * cliquer ; un seul dit l'etat sans qu'on ait rien a comparer.
   *
   * LES DEUX RADIOS RESTENT DANS LE FORMULAIRE. Ce sont elles qui portent le
   * `name` et la valeur enregistree, et le composant du coeur les renumerote a
   * chaque ajout de rangee. Le bouton ne fait que les commander.
   *
   * LE GROUPE PASSE EN `aria-hidden` ET SES RADIOS HORS TABULATION. Sans cela,
   * la meme information serait annoncee deux fois, et la touche Tab s'arreterait
   * sur trois commandes la ou il n'y en a qu'une a l'ecran. `aria-pressed` sur
   * le bouton porte l'etat, c'est le motif prevu pour un interrupteur.
   */
  function bascule(groupe) {
    if (groupe.dataset.opusBascule) { return; }

    var radios = [].slice.call(groupe.querySelectorAll('input[type="radio"]'));

    if (radios.length !== 2) { return; }

    var fset = groupe.closest('fieldset');
    var hote = fset ? fset.parentNode : null;

    if (!fset || !hote) { return; }

    // Sans pictogrammes, deux boutons avec leurs mots restent plus clairs
    // qu'un seul bouton muet : on laisse le groupe tel quel.
    if (!groupe.querySelector('label svg')) { return; }

    groupe.dataset.opusBascule = '1';

    var bouton = document.createElement('button');
    bouton.type = 'button';

    /*
     * DEUX NATURES DE BASCULE, ET LA FEUILLE LES DISTINGUE. Un oui/non porte
     * un etat, dont l'un se signale en rouge ; deux valeurs qui se valent, le
     * sens d'une rangee de boutons par exemple, n'ont pas d'etat fautif. La
     * valeur `0` est la seule qui dise « non » dans ce manifeste.
     */
    bouton.className = 'blocs-bascule blocs-bascule--'
      + (radios.filter(function (r) { return r.value === '0'; }).length ? 'etat' : 'choix');

    hote.insertBefore(bouton, fset);

    fset.setAttribute('aria-hidden', 'true');
    radios.forEach(function (r) { r.tabIndex = -1; });

    /*
     * LES DEUX DESSINS SONT POSES UNE FOIS POUR TOUTES, ET LA FEUILLE CHOISIT.
     *
     * Avant, le pictogramme etait RECOPIE de l'etiquette cochee a chaque
     * changement. Deux sources pour une meme verite, l'attribut et le dessin,
     * et elles finissaient par diverger : un oeil ferme, donc rouge, mais
     * portant le dessin de l'oeil OUVERT, pupille comprise. C'est le « point
     * rouge au milieu » du 21 septembre 2026.
     *
     * Les deux dessins vivent maintenant cote a cote dans le bouton, et
     * `aria-pressed` decide lequel se voit. Une seule source, plus de
     * divergence possible, et plus rien a recopier a chaque clic.
     *
     * LA VALEUR D'ABORD, LE RANG EN SECOURS, ET C'EST UNE CORRECTION DU
     * 22 SEPTEMBRE 2026.
     *
     * La bascule ne connaissait qu'un couple : `0` et le reste, parce qu'elle
     * n'avait jamais servi qu'a l'oeil. Le sens d'une rangee de boutons vaut
     * `row` et `column` : les DEUX dessins recevaient donc la classe du oui,
     * aucun ne portait celle du non, et la feuille n'en cachait aucun. Deux
     * fleches se superposaient dans un carre de 28 px. « Cela ne fonctionne
     * pas et ne s'affiche pas correctement », et c'etait exact.
     *
     * Le premier etat reste celui que la valeur `0` designe quand elle
     * existe, sinon c'est le premier du manifeste. Le comportement de l'oeil
     * ne change pas d'un pixel, et n'importe quel couple marche desormais.
     */
    var refNon = radios.filter(function (r) { return r.value === '0'; })[0] || radios[0];

    var poserDessins = function () {
      bouton.textContent = '';

      radios.forEach(function (r) {
        var etiquette = groupe.querySelector('label[for="' + r.id + '"]');
        var dessin = etiquette ? etiquette.querySelector('svg') : null;

        if (!dessin) { return; }

        var copie = dessin.cloneNode(true);
        copie.setAttribute('class', r === refNon
          ? 'blocs-bascule__non'
          : 'blocs-bascule__oui');

        bouton.appendChild(copie);
      });
    };

    poserDessins();

    var montrer = function () {
      var coche = groupe.querySelector('input[type="radio"]:checked') || radios[0];
      var etiquette = groupe.querySelector('label[for="' + coche.id + '"]');
      var mot = etiquette ? (etiquette.title || etiquette.textContent.trim()) : '';

      bouton.setAttribute('aria-pressed', coche === refNon ? 'false' : 'true');
      bouton.title = mot;
      bouton.setAttribute('aria-label', mot);
    };

    montrer();

    bouton.addEventListener('click', function () {
      var coche = groupe.querySelector('input[type="radio"]:checked') || radios[0];
      var autre = radios.filter(function (r) { return r !== coche; })[0];

      autre.checked = true;

      /*
       * ON MET L'ATTRIBUT A JOUR SOI-MEME, AVANT D'ANNONCER LE CHANGEMENT.
       * D'autres scripts ecoutent ce meme `change` ; si l'un d'eux echoue ou
       * remanie la ligne, le bouton doit deja etre juste.
       */
      montrer();

      autre.dispatchEvent(new Event('change', { bubbles: true }));
    });

    // Le `change` peut aussi venir d'ailleurs : le bouton suit dans tous les cas.
    groupe.addEventListener('change', montrer);
  }

  /**
   * Replie un groupe de choix derriere un seul bouton.
   *
   * C'EST LE `pick3` DE LA MAQUETTE : un bouton qui montre le choix retenu, et
   * qui ouvre les autres au clic. Trois boutons d'alignement par ligne, sur
   * douze lignes, ce sont trente-six cibles alignees dont trente-quatre ne
   * servent jamais ; replies, il en reste douze, et la ligne tient.
   *
   * UN `<details>`, PAS UN MENU FABRIQUE A LA MAIN. Le navigateur lui donne
   * l'ouverture au clavier, la fermeture par Echap et l'etat annonce aux
   * lecteurs d'ecran. Un `div` avec un ecouteur de clic n'a rien de tout cela,
   * et il faut l'ecrire, puis le maintenir.
   *
   * LES RADIOS NE SONT PAS RECREES, ELLES SONT DEPLACEES : ce sont elles qui
   * portent le `name` et la valeur enregistree. En fabriquer de nouvelles
   * aurait demande de les renumeroter a chaque ajout de rangee, exactement ce
   * que le composant du coeur fait deja pour les siennes.
   */
  function replierChoix(groupe) {
    if (groupe.dataset.opusPick) { return; }

    var etiquettes = [].slice.call(groupe.querySelectorAll('label'));

    // A deux choix, un bouton qui en cache un seul autre ne fait rien gagner.
    if (etiquettes.length < 3) { return; }

    groupe.dataset.opusPick = '1';

    var det = document.createElement('details');
    det.className = 'blocs-pick' + (groupe.classList.contains('blocs-grille9') ? ' blocs-pick--grille9' : '');

    var som = document.createElement('summary');

    var libelle = document.createElement('span');
    libelle.className = 'visually-hidden';
    som.appendChild(libelle);

    det.appendChild(som);

    groupe.parentNode.insertBefore(det, groupe);
    det.appendChild(groupe);

    var montrer = function () {
      var coche = groupe.querySelector('input[type="radio"]:checked');
      var source = coche ? groupe.querySelector('label[for="' + coche.id + '"]') : null;
      var dessin = source ? source.querySelector('svg') : null;

      // Le dessin du choix retenu, recopie sur le bouton : c'est lui qui dit
      // ce qui est choisi sans qu'on ait a ouvrir.
      [].slice.call(som.querySelectorAll('svg')).forEach(function (e) { e.remove(); });

      if (dessin) { som.insertBefore(dessin.cloneNode(true), libelle); }

      libelle.textContent = source ? source.title || source.textContent.trim() : '';
    };

    montrer();

    groupe.addEventListener('change', function () {
      montrer();
      det.open = false;
    });

    /*
     * LE PANNEAU EST PLACE EN COORDONNEES D'ECRAN, ET NON SOUS SON BOUTON.
     *
     * Pose en `position: absolute`, il etait COUPE : le tableau des rangees
     * defile horizontalement, donc il porte `overflow: auto`, et un ancetre en
     * overflow rogne tout descendant positionne, sans rien signaler. Vu sur le
     * banc le 21 septembre 2026, le choix d'alignement sortait a moitie sous
     * la barre de defilement.
     *
     * AU-DESSUS ET CENTRE SUR LE BOUTON, comme demande : on choisit un
     * alignement en regardant la ligne, et un panneau pose dessous cache
     * justement ce qu'on veut voir. Il retombe dessous s'il n'y a pas la place
     * en haut, et il reste dans l'ecran a gauche comme a droite.
     */
    var placer = function () {
      var panneau = det.querySelector('.btn-group');

      if (!det.open || !panneau) { return; }

      // On mesure a plat : une mesure prise sur un panneau deja deplace
      // rendrait la position precedente, et le panneau derivait a chaque clic.
      panneau.style.left = '0px';
      panneau.style.top = '0px';

      var bouton = som.getBoundingClientRect();
      var boite = panneau.getBoundingClientRect();
      var marge = 8;

      var gauche = bouton.left + (bouton.width / 2) - (boite.width / 2);
      gauche = Math.max(marge, Math.min(gauche, window.innerWidth - boite.width - marge));

      var haut = bouton.top - boite.height - 6;

      if (haut < marge) { haut = bouton.bottom + 6; }

      panneau.style.left = Math.round(gauche) + 'px';
      panneau.style.top = Math.round(haut) + 'px';
    };

    det.addEventListener('toggle', placer);

    // Le panneau suit son bouton quand la page ou le tableau defile.
    window.addEventListener('scroll', placer, true);
    window.addEventListener('resize', placer);

    /*
     * UN CLIC AILLEURS REFERME, comme tout menu. Sans cela, ouvrir le
     * quatrieme selecteur laisserait les trois premiers ouverts par-dessus les
     * champs voisins.
     */
    document.addEventListener('click', function (ev) {
      if (det.open && !det.contains(ev.target)) { det.open = false; }
    });
  }

  /*
   * IL N'Y A PLUS DE BOUTON « DUPLIQUER » SUR UNE RANGEE.
   *
   * Demande de Cyrille le 19 septembre 2026 : l'icone de copie sert a un BLOC
   * entier, pas a une ligne, exactement comme le `−` en haut a droite d'une
   * recette dans l'onglet « Template article » de Corpus. A gauche d'une ligne
   * il n'y a que trois commandes, les siennes : ajouter, retirer, deplacer.
   *
   * `poserDuplicateur()` et `recopier()` ont donc ete retirees d'ici. Elles
   * restent dans le paquet 1.0.7 si le duplicateur revient un jour au niveau
   * du bloc.
   */

  /* ==========================================================================
     LES SOUS-BLOCS DE BOUTONS

     La maquette ne montre pas vingt-quatre champs alignes : elle montre trois
     petits blocs, « Bouton 1 », « Bouton 2 », « Bouton 3 », chacun avec son
     cadre, son libelle, son format, ses deux icones, et son lien dans un
     encadre pointille.

     Le manifeste, lui, ne peut pas les grouper : un `<fieldset>` dans une
     rangee de sous-formulaire deviendrait un onglet de plus dans
     com_modules, et un `<fields name="...">` renommerait les champs, donc
     casserait la lecture cote site. Le groupement se fait donc ici.

     ON NE DEPLACE QUE DES `.control-group`, ET JAMAIS UN CHAMP HORS DE SA
     RANGEE : le composant du coeur renumerote les `name` de toute la rangee a
     chaque ajout, et un champ sorti perdrait sa valeur en silence. Les
     sous-blocs restent donc a l'interieur de la rangee.
     ========================================================================== */

  var LARGEUR_OUTILS = '6rem';

  /*
   * UNE COLONNE D'ICONES EST LARGE COMME LE PAS DES COMMANDES DE GAUCHE.
   *
   * Les deux partageaient d'abord `LARGEUR_OUTILS`, 6 rem, qui est la mesure
   * de TROIS boutons cote a cote : l'oeil se retrouvait seul au milieu d'un
   * couloir. Puis 2,5 rem, ce qui restait large. Mesure dans le navigateur le
   * 21 septembre 2026 : a gauche, un bouton de 28 px et un ecart de .15 rem,
   * donc un pas de 29 px. C'est cette valeur, et la feuille retire en meme
   * temps le retrait horizontal de ces cellules, sinon le `td` d'Atum en
   * rajoute 5,6 de chaque cote.
   */
  var LARGEUR_ICONE = '1.8125rem';

  /*
   * `sousblocs()` A ETE SUPPRIMEE LE 22 SEPTEMBRE 2026.
   *
   * Elle fabriquait les trois panneaux « Bouton 1 », « Bouton 2 », « Bouton 3 »
   * autour des champs plats du manifeste. Ces champs n'existent plus : les
   * boutons sont une liste, et le composant du coeur dessine ses lignes
   * lui-meme. Une fonction qui habille des champs disparus est du code mort
   * qui a l'air vivant.
   */
  /**
   * LES COMMANDES PASSENT EN PREMIERE COLONNE.
   *
   * Le gabarit `repeatable-table` du coeur pose la cellule des `+ − ⣿` en
   * DERNIER. Corpus les montre a gauche, et c'est la regle qu'on suit : la
   * main les cherche au meme endroit d'un ecran a l'autre.
   *
   * IL N'Y A RIEN A FABRIQUER, JUSTE A DEPLACER. Releve dans le formulaire le
   * 21 septembre 2026 : la ligne d'en-tete compte bien autant de cellules que
   * les lignes de contenu, mais sa derniere est un `<td>` vide et non un
   * `<th>`. C'est la place des commandes, deja prevue. J'ai d'abord cru devoir
   * en ajouter une, et les intitules se sont decales d'un cran.
   */
  function outilsEnTete(tableau) {
    /*
     * LE MARQUEUR VA SUR LA LIGNE, PAS SUR LE TABLEAU.
     *
     * Pose sur le tableau, il faisait de la premiere passe la seule : toute
     * ligne ajoutee ENSUITE gardait ses commandes a droite. C'est ce qu'on
     * voyait sur une ligne dupliquee, sans `+ - ⣿` a gauche et avec un `+`
     * egare tout au bout. Vu le 21 septembre 2026, et c'etait vrai de
     * n'importe quelle ligne ajoutee, pas seulement d'une copie.
     */
    var lignes = [].slice.call(tableau.querySelectorAll('thead tr, tbody tr'));

    if (tableau.querySelectorAll('tbody tr').length === 0) {
      // Sans ligne de contenu, il n'y a rien a ranger : on retentera a l'ajout.
      return;
    }

    lignes.forEach(function (l) {
      if (l.dataset.opusOutils) { return; }

      var derniere = l.lastElementChild;

      if (!derniere || derniere === l.firstElementChild) { return; }

      /*
       * ON RECONNAIT LA CELLULE DES COMMANDES A CE QU'ELLE CONTIENT, pas a son
       * rang : dans l'en-tete elle est vide, dans une ligne elle porte les
       * boutons. Les deux fois, c'est la derniere.
       */
      var estOutils = derniere.tagName === 'TD'
        && (derniere.querySelector('.btn-group button') || derniere.textContent.trim() === '');

      if (!estOutils) { return; }

      derniere.style.width = LARGEUR_OUTILS;
      derniere.style.minWidth = LARGEUR_OUTILS;

      if (l.parentNode.tagName === 'THEAD') {
        derniere.setAttribute('aria-label', texte('MOD_OPUS_TOOLS', 'Commandes de la ligne'));
      }

      l.insertBefore(derniere, l.firstElementChild);
      l.dataset.opusOutils = '1';
    });
  }

  /**
   * MARQUE LES COLONNES ETROITES, DE L'EN-TETE AU DERNIER RANG.
   *
   * La feuille s'en sert pour retirer le retrait horizontal du `td`, qui
   * ajoute 5,6 px de chaque cote et casserait le pas des boutons.
   *
   * ELLE REPART DES EN-TETES A CHAQUE FOIS, ET NE SE GARDE PAS.
   *
   * Le marquage se faisait avant DANS la passe qui rend les en-tetes muettes,
   * laquelle ne repasse pas sur un en-tete deja traite. Une ligne ajoutee
   * ensuite n'etait donc jamais marquee : ses cellules gardaient leur retrait,
   * et ses trois icones glissaient de six pixels par rapport a celles du
   * dessus. Vu le 21 septembre 2026, « un decalage qui se cree sur les icones
   * de droite quand j'ajoute une ligne ».
   *
   * MEME FAMILLE QUE LES DEUX PANNES PRECEDENTES : un garde pose sur l'objet
   * qui dure, alors que le travail porte sur des objets qui naissent. Le garde
   * va donc sur la CELLULE, qui est ce qu'on marque, et la passe peut repasser
   * autant de fois qu'on veut.
   */
  function colonnesEtroites(tableau) {
    var premiere = tableau.querySelector('thead tr');

    if (!premiere) { return; }

    [].slice.call(premiere.children).forEach(function (tete, index) {
      if (!tete.dataset.opusMuette && !tete.dataset.opusRoueTete) { return; }

      [].slice.call(tableau.querySelectorAll('thead tr, tbody tr')).forEach(function (l) {
        var cellule = l.children[index];

        if (cellule) { cellule.dataset.opusEtroite = '1'; }
      });
    });
  }

  /**
   * LE `+` DE L'EN-TETE S'EFFACE DES QU'UNE LIGNE EXISTE.
   *
   * Le coeur en pose un dans la ligne d'en-tete, et un autre dans CHAQUE
   * ligne. Des qu'une ligne existe, celui du haut fait double emploi, et il
   * n'est meme pas a cote de ce qu'il ajoute. Demande de Cyrille le
   * 21 septembre 2026 : « supprime le plus, il y a deja un plus avec les trois
   * boutons ».
   *
   * IL REPARAIT SI L'ON VIDE LA LISTE, parce qu'alors il est le seul. C'est
   * pour cela qu'on le cache au lieu de le retirer, et qu'on repasse a chaque
   * ajout comme a chaque retrait.
   */
  function plusDeTete(tableau) {
    var bouton = tableau.querySelector('thead .group-add');

    if (!bouton) { return; }

    bouton.hidden = tableau.querySelectorAll('tbody tr').length > 0;
  }

  /**
   * UNE COLONNE D'ICONES N'A PAS D'INTITULE.
   *
   * Regle de Cyrille : « Affiche » ou « Alignement » ecrits au-dessus d'un
   * petit carre, ce sont des mots qui disent ce que le dessin dit deja. Corpus
   * n'ecrit rien non plus au-dessus de sa roue dentee.
   *
   * LE MOT N'EST PAS SUPPRIME, IL EST DEPLACE dans `aria-label` : une colonne
   * sans intitule est une colonne muette pour qui n'a pas l'ecran.
   *
   * ELLE PASSE APRES L'HABILLAGE, et pas avant : c'est `iconiser` qui pose les
   * pictogrammes, et c'est a leur presence qu'on reconnait une colonne
   * d'icones. Appelee trop tot, elle ne trouverait que des mots.
   */
  function entetesMuettes(tableau) {
    var ligne = tableau.querySelector('tbody tr');

    /*
     * ON COMPTE TOUTES LES CELLULES D'EN-TETE, PAS SEULEMENT LES `th`.
     *
     * La ligne d'en-tete se termine par un `td` vide : c'est la place des
     * commandes, que `outilsEnTete` vient de passer devant. L'ignorer decalait
     * la correspondance d'un cran, et les colonnes muettes tombaient sur
     * « Appliquer a », « Contenu dans la hauteur » et « Classe » au lieu des
     * deux colonnes a icone. Mesure sur le banc le 21 septembre 2026 :
     * « Classe » etait vide et « Affiche » gardait son mot.
     */
    var premiere = tableau.querySelector('thead tr');
    var entetes  = premiere ? premiere.children : [];

    if (!ligne || entetes.length === 0) { return; }

    [].slice.call(ligne.children).forEach(function (cellule, i) {
      var tete = entetes[i];

      if (!tete || tete.dataset.opusMuette) { return; }

      if (!cellule.querySelector('.blocs-bascule, .blocs-pick')) { return; }

      var mot = tete.textContent.trim().split('\n')[0];

      /*
       * LE MOT EST RANGE SUR LA CELLULE AVANT D'ETRE EFFACE. Dans un tableau,
       * c'est l'en-tete qui porte l'intitule d'une colonne : une fois muette,
       * plus rien dans la page ne nomme le champ, et le panneau de la roue
       * sortait deux champs sans etiquette.
       */
      tete.dataset.opusNom = mot;
      tete.textContent = '';
      tete.setAttribute('aria-label', mot);
      tete.style.width = LARGEUR_ICONE;
      tete.style.minWidth = LARGEUR_ICONE;
      tete.dataset.opusMuette = '1';
    });
  }

  /**
   * Les cellules d'une ligne qui vivent derriere la roue, dans l'ordre.
   */
  function cellulesReglage(ligne) {
    return [].slice.call(ligne.children).filter(function (cellule) {
      return !!cellule.querySelector('.blocs-reglage');
    });
  }

  /*
   * DEUX INDEX, ET C'EST TOUT LE PIEGE. Corpus l'a rencontre le 19 aout 2026,
   * nous le 21 septembre, et c'est le meme : dans le CORPS, `outilsEnTete` a
   * mis la cellule des commandes EN TETE, donc les champs commencent au rang 1 ;
   * dans l'EN-TETE, `thead th` saute le `td` des commandes, donc les champs
   * commencent au rang 0. Un seul index pour les deux decale d'un cran, et
   * c'est « Identifiant » qui se masque a la place de « Classe », qui reste
   * vide et large. Vu sur le banc : la roue sous un en-tete « Classe ».
   *
   * ON COMPTE DONC LE RANG PARMI LES CELLULES DE CHAMP, en ignorant celle des
   * commandes ou qu'elle soit. Ce rang vaut pour l'en-tete ; la cellule du
   * corps, elle, se masque directement, sans index.
   */
  function rangDeCellule(ligne, cible) {
    var rang = 0;

    for (var i = 0; i < ligne.children.length; i++) {
      var cellule = ligne.children[i];

      if (cellule === cible) { return rang; }

      if (cellule.querySelector('[name]')) { rang++; }
    }

    return -1;
  }

  /*
   * UN INTITULE SANS CHAMP SE TAIT, 26 septembre 2026.
   *
   * `showon` cache un champ qui n'a pas de sens (le rapport d'une rangee a une
   * colonne, « Appliquer a » sans fond), mais l'en-tete du tableau restait :
   * « Il me manque deux champs », Cyrille, devant un intitule au-dessus d'une
   * case vide. L'en-tete s'efface quand AUCUNE ligne ne montre son champ, et
   * revient des qu'une ligne le montre. `visibility` et non `display` : la
   * colonne garde sa place, les autres ne bougent pas.
   */
  function tetesVides(tableau) {
    var entetes = [].slice.call(tableau.querySelectorAll('thead th'));
    var lignes = [].slice.call(tableau.querySelectorAll('tbody tr')).map(function (l) {
      return [].slice.call(l.children).filter(function (c) { return c.querySelector('[name]'); });
    });

    entetes.forEach(function (tete, rang) {
      if (tete.dataset.opusRoueTete) { return; }

      var vide = lignes.length > 0 && lignes.every(function (cellules) {
        var groupes = cellules[rang] ? [].slice.call(cellules[rang].querySelectorAll('.control-group')) : [];

        return groupes.length > 0 && groupes.every(function (g) { return g.classList.contains('hidden'); });
      });

      tete.classList.toggle('opus-tete-vide', vide);
    });
  }

  /*
   * `showon` reagit a `change` : on repasse juste apres lui, sur le seul
   * tableau touche.
   */
  document.addEventListener('change', function (e) {
    var tableau = e.target && e.target.closest ? e.target.closest('joomla-field-subform table') : null;

    if (tableau) { setTimeout(function () { tetesVides(tableau); }, 0); }
  });

  function masquerColonnes(tableau) {
    var ligne = tableau.querySelector('tbody tr');

    if (!ligne) { return; }

    var rangs = cellulesReglage(ligne).map(function (cellule) {
      return rangDeCellule(ligne, cellule);
    }).filter(function (rang) { return rang >= 0; });

    if (rangs.length === 0) { return; }

    var entetes = tableau.querySelectorAll('thead th');

    /*
     * LA PREMIERE COLONNE CACHEE DEVIENT CELLE DE LA ROUE, les autres
     * disparaissent. Une colonne de plus aurait demande un champ de plus dans
     * le manifeste, pour un bouton qui n'enregistre rien.
     */
    rangs.forEach(function (rang, i) {
      var tete = entetes[rang];

      if (!tete) { return; }

      if (i > 0) {
        tete.hidden = true;

        return;
      }

      /*
       * L'EN-TETE PERD SON TEXTE MAIS GARDE UN NOM pour qui n'a pas l'ecran :
       * une colonne sans intitule est une colonne muette.
       */
      if (!tete.dataset.opusRoueTete) {
        // Le mot d'abord, l'effacement ensuite : voir `entetesMuettes`.
        tete.dataset.opusNom = tete.textContent.trim().split('\n')[0];
        tete.textContent = '';
        tete.setAttribute('aria-label', texte('MOD_OPUS_SETTINGS_TITLE', 'Reglages de la ligne'));
        tete.dataset.opusRoueTete = '1';
      }

      tete.hidden = false;
      tete.style.width = LARGEUR_ICONE;
      tete.style.minWidth = LARGEUR_ICONE;
    });

    /*
     * LA CELLULE DU CORPS SE MASQUE DIRECTEMENT, SANS INDEX. C'est la moitie
     * du remede de Corpus : l'index ne sert qu'a retrouver l'en-tete.
     */
    [].slice.call(tableau.querySelectorAll('tbody tr')).forEach(function (l) {
      cellulesReglage(l).forEach(function (cellule, i) {
        if (i > 0) {
          cellule.hidden = true;

          return;
        }

        cellule.hidden = false;
        cellule.style.textAlign = 'center';

        // Le champ lui-meme se cache, la cellule reste pour accueillir la roue.
        [].slice.call(cellule.querySelectorAll('.control-group')).forEach(function (g) {
          g.hidden = true;
        });
      });
    });
  }

  /* ==========================================================================
     LA ROUE DENTEE ET SON PANNEAU

     D'OU CELA VIENT : de `admin/assets/js/gabarits.js` du template Corpus, qui
     pose exactement ce bouton dans ses onglets « Template blog » et « Template
     article ». La feuille recopiee plus haut habille deja `.opus-roue` en
     violet et `.opus-reglages` en panneau : on reprend donc le mecanisme, pas
     seulement l'apparence.

     POURQUOI UN PANNEAU PLUTOT QUE DEUX CASES DE PLUS. Une classe et un
     identifiant sont vides sur presque toutes les lignes. Affiches, ce sont
     deux colonnes de vide qui poussent la saisie utile hors de l'ecran ; caches
     derriere une roue, ils ne coutent rien tant qu'on ne les demande pas.

     LE CHAMP DU PANNEAU EST UN MIROIR, PAS LE VRAI CHAMP. Le vrai reste dans sa
     rangee, ou le composant du coeur le renumerote a chaque ajout ; la copie
     n'a pas de `name`, ne part donc jamais a l'enregistrement, et recopie sa
     valeur a chaque frappe. C'est la methode de Corpus, et c'est la seule qui
     survit a un deplacement de rangee.
     ========================================================================== */

  var panneauReglages = null;

  /**
   * LE PANNEAU DES REGLAGES, DANS LA COLONNE DE DROITE ET NON EN MODALE.
   *
   * Question de Cyrille, 22 septembre 2026 : « avec une fenetre popup, je me
   * demande si c'est bien pratique, et que cela ne pose pas de probleme
   * d'accessibilite et de comprehension ».
   *
   * LE `<dialog>` N'ETAIT PAS LE DEFAUT, c'etait meme le plus sur : Echap, le
   * focus piege et l'arriere-plan inerte, tout cela etait natif. Le defaut est
   * ailleurs, une modale CACHE la ligne qu'on regle, et interrompt au lieu
   * d'accompagner. La colonne de droite est deja collante : le panneau y reste
   * visible pendant qu'on fait defiler la liste, a cote de sa ligne.
   *
   * CE QUE LE `<dialog>` DONNAIT GRATUITEMENT EST DONC ECRIT ICI, et ce n'est
   * pas optionnel : `aria-expanded` sur la roue, le focus qui entre dans le
   * panneau a l'ouverture, Echap qui ferme et REND le focus a la roue, un
   * titre qui dit quelle ligne on regle. Sans les deux du milieu, on perdrait
   * au clavier ce qu'on gagne a l'oeil : le panneau est tres loin de la roue
   * dans le document, la tabulation partirait dans la ligne suivante.
   */
  function construirePanneau() {
    if (panneauReglages) { return panneauReglages; }

    var boite = section(texte('MOD_OPUS_SETTINGS_TITLE', 'Reglages de la ligne'), false, '');
    boite.id = 'blocs-reglages';
    boite.classList.add('blocs-section--reglages');

    /*
     * UNE REGION NOMMEE PAR SON TITRE. Le focus y entre a l'ouverture ; sans
     * nom, le lecteur d'ecran annonce le premier champ sans dire dans quoi
     * l'on vient d'entrer.
     */
    var titreReglages = boite.querySelector('h3');

    if (titreReglages) {
      titreReglages.id = titreReglages.id || 'blocs-reglages-titre';
      boite.setAttribute('role', 'region');
      boite.setAttribute('aria-labelledby', titreReglages.id);
    }
    boite.hidden = true;

    var fermer = document.createElement('button');
    fermer.type = 'button';
    fermer.className = 'opus-reglages__fermer';
    fermer.setAttribute('aria-label', texte('JCANCEL', 'Fermer'));
    fermer.addEventListener('click', function () { fermerReglages(true); });
    boite.querySelector('h3').appendChild(fermer);

    var corps = document.createElement('div');
    corps.className = 'opus-reglages__corps';
    boite.appendChild(corps);

    /*
     * ECHAP FERME, OU QUE SOIT LE FOCUS DANS LE PANNEAU. Un `<dialog>` le
     * faisait seul ; une boite ordinaire ne le fait pas, et c'est le geste que
     * tout le monde a dans les doigts.
     */
    boite.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') {
        ev.stopPropagation();
        fermerReglages(true);
      }
    });

    panneauReglages = boite;

    return boite;
  }

  /**
   * Ferme le panneau et, si on le lui demande, rend le focus a la roue.
   *
   * `rendreLeFocus` EST FAUX QUAND C'EST UNE AUTRE ROUE QUI OUVRE : le focus
   * appartient alors a celle-la, le lui reprendre serait le renvoyer d'ou il
   * vient.
   */
  function fermerReglages(rendreLeFocus) {
    var boite = document.getElementById('blocs-reglages');

    if (!boite || boite.hidden) { return; }

    boite.hidden = true;
    boite.querySelector('.opus-reglages__corps').textContent = '';

    var roue = routeOuverte;
    routeOuverte = null;
    ligneReglee(null);

    if (roue) {
      roue.setAttribute('aria-expanded', 'false');

      if (rendreLeFocus) { roue.focus(); }
    }

    dessiner();
  }

  /** Le lisere violet sur la ligne dont le panneau est ouvert, et sur elle seule. */
  function ligneReglee(rangee) {
    [].slice.call(document.querySelectorAll('.blocs-ligne--reglee')).forEach(function (n) {
      n.classList.remove('blocs-ligne--reglee');
    });

    if (rangee) { rangee.classList.add('blocs-ligne--reglee'); }
  }

  /**
   * L'INTITULE D'UN CHAMP, CHERCHE LA OU IL EST.
   *
   * Dans une liste en `div`, le coeur pose un `.control-label` par champ.
   * Dans un TABLEAU, il n'en pose aucun : l'intitule d'une colonne vit dans
   * son en-tete, une seule fois pour toutes les lignes. Chercher le premier
   * partout rendait donc une chaine vide des qu'on ouvrait la roue d'une
   * rangee, et le panneau sortait deux champs anonymes. Vu le 21 septembre
   * 2026 en verifiant si le groupe des rangees pouvait servir de reference.
   *
   * L'en-tete peut avoir ete rendu muet entre-temps ; son mot est alors range
   * dans `data-opus-nom`, justement pour ce cas.
   */
  function intituleDe(champ, groupe) {
    var propre = groupe.querySelector('.control-label label, .control-label legend');

    if (propre) {
      /*
       * L'AIDE VIT DANS L'INTITULE DEPUIS QUE LA PASTILLE EXISTE, et l'oublier
       * donnait des titres a rallonge : « ClasseUne classe CSS posee sur cette
       * ligne seule. Elle sert a... », suivi du meme texte en dessous, puisque
       * le miroir affiche l'aide a part. Releve le 22 septembre 2026.
       *
       * On lit donc une COPIE debarrassee de la pastille et de sa bulle. La
       * copie, pas l'original : retirer les noeuds du vrai intitule les
       * ferait disparaitre de l'ecran.
       */
      var copie = propre.cloneNode(true);

      [].slice.call(copie.querySelectorAll('.icon-info-circle, [role="tooltip"]'))
        .forEach(function (n) { n.remove(); });

      return copie.textContent.trim();
    }

    var cellule = champ.closest ? champ.closest('td') : null;
    var ligne = cellule ? cellule.parentNode : null;
    var tableau = cellule ? cellule.closest('table') : null;
    var entete = tableau ? tableau.querySelector('thead tr') : null;

    if (!entete || !ligne) { return ''; }

    var rang = [].slice.call(ligne.children).indexOf(cellule);
    var tete = entete.children[rang];

    if (!tete) { return ''; }

    return tete.dataset.opusNom || tete.textContent.trim().split('\n')[0];
  }

  /** Une commande miroir : elle recopie dans le vrai champ a chaque frappe. */
  function miroir(vrai, intitule, aide) {
    var enveloppe = document.createElement('div');
    enveloppe.className = 'opus-reglages__champ';

    // Le panneau se met a jour sans se refaire : il faut savoir quel champ
    // chaque enveloppe commande.
    enveloppe.dataset.champ = vrai.name;

    /*
     * CE QUI PREND TOUTE LA LARGEUR EST DECIDE PAR LE CHAMP, PAS PAR SA FORME.
     *
     * Releve de Cyrille, 22 septembre 2026 : « pour les reglages du deuxieme
     * bouton, la presentation est differente avec Adresse qui prend toute la
     * largeur ». Mesure faite sur les deux panneaux : le premier bouton pointe
     * un element de MENU, le second une ADRESSE. Seule l'adresse s'etalait, et
     * deux panneaux qui reglent la meme chose ne se ressemblaient plus.
     *
     * TROISIEME VERSION, ET C'EST LA BONNE : la cible reste en bas, en pleine
     * largeur, et c'est « Ouvrir dans un nouvel onglet » qui monte a droite du
     * type de lien. Arbitrage de Cyrille, 22 septembre 2026.
     *
     * L'ORDRE VIENT DU MANIFESTE, PAS D'UN `order` EN CSS. Les champs du lien
     * y sont desormais ranges type, nouvel onglet, element de menu, adresse :
     * ce qui est lu au clavier suit donc ce qui est vu a l'ecran. Un `order`
     * aurait fait diverger les deux, et c'est une regle du projet.
     *
     * ON VISE LE `name`, JAMAIS L'INTITULE : un nom de champ ne se traduit
     * pas.
     */
    if (/\[(body|label|linkMenu|linkUrl)\]$/.test(vrai.name)
      || vrai.tagName === 'TEXTAREA'
      || vrai.type === 'url') {
      enveloppe.classList.add('opus-reglages__champ--large');
    }

    var id = 'blocs-miroir-' + Math.abs(vrai.name.split('').reduce(function (a, c) {
      return ((a << 5) - a + c.charCodeAt(0)) | 0;
    }, 0));

    var etiquette = document.createElement('label');
    etiquette.setAttribute('for', id);
    etiquette.textContent = intitule;
    enveloppe.appendChild(etiquette);

    var copie = vrai.cloneNode(true);
    copie.id = id;
    copie.removeAttribute('name');
    copie.value = vrai.value;

    var suivre = function () {
      vrai.value = copie.value;
      vrai.dispatchEvent(new Event('change', { bubbles: true }));
    };

    copie.addEventListener('input', suivre);
    copie.addEventListener('change', suivre);
    enveloppe.appendChild(copie);

    /*
     * L'AIDE PASSE DERRIERE UNE PASTILLE, COMME PARTOUT AILLEURS.
     *
     * Demande de Cyrille, 22 septembre 2026 : « pour les textes d'aide, la
     * aussi utilise les i a droite des titres des champs ». Le panneau les
     * ecrivait en toutes lettres sous chaque champ : cinq champs faisaient
     * cinq paragraphes, et la saisie se perdait dedans. C'est exactement le
     * defaut qu'on avait corrige dans les lignes, et qui etait revenu ici.
     *
     * `pastilleDe` est la meme fonction que pour les titres de section : une
     * pastille, puis sa bulle en voisine immediate, et Atum l'ouvre au survol
     * comme au focus sans une ligne de script.
     */
    pastilleDe(etiquette, aide);

    /*
     * LE PONT VERS L'ONGLET CSS, 25 septembre 2026.
     *
     * « Creer un lien entre les classes CSS de l'onglet Mise en page vers
     * l'onglet CSS personnalise depuis le bloc violet quand il s'ouvre »,
     * Cyrille.
     *
     * LE CHEMIN EXISTAIT DEJA DANS L'AUTRE SENS : le panneau « Classes
     * produites » de l'onglet CSS montre ce que le montage ecrit. Il manquait
     * l'aller : on nomme une classe ici, et il fallait ensuite changer
     * d'onglet, retrouver la zone, et retaper le nom sans se tromper.
     *
     * SEULEMENT SUR UN CHAMP DE CLASSE : on vise le `name`, jamais l'intitule,
     * qui se traduit. Les cinq champs concernes sont `classe`, `classeValeur`,
     * `classeMesure`, `classeSource` et `classeBarre`.
     */
    if (/\[classe[A-Za-z]*\]$/.test(vrai.name)) {
      enveloppe.appendChild(pontCss(copie));
    }

    return enveloppe;
  }

  /*
   * LA PLANCHE DES PICTOGRAMMES : UN CLIC COPIE LE NOM, 25 septembre 2026.
   *
   * LE CHAMP DESSINE LA GRILLE, LE SCRIPT NE FAIT QUE LA COPIE. Le PHP a lu la
   * planche et pose les cases ; il n'avait aucune raison d'y ajouter un script
   * a lui. Ici on branche un seul ecouteur sur la grille entiere, jamais un par
   * case : trente-quatre ecouteurs pour un meme geste, c'est trente-trois de
   * trop.
   *
   * LE PRESSE-PAPIERS PEUT REFUSER, et c'est prevu. `navigator.clipboard`
   * n'existe pas partout et demande un contexte sur : le repli selectionne le
   * nom dans la case, de sorte qu'un Ctrl+C suffise. Rien ne se perd.
   */
  function brancherPlancheIcones() {
    /*
     * DEUX GRILLES DEPUIS LE 25 SEPTEMBRE 2026 : celle de la planche et celle
     * des icones du client. `querySelector` n'en prenait que la premiere, et
     * les cases de la seconde ne copiaient rien.
     */
    var grilles = document.querySelectorAll('.blocs-icones__grille');

    if (!grilles.length) { return; }

    Array.prototype.forEach.call(grilles, function (grille) {
    grille.addEventListener('click', function (ev) {
      var case_ = ev.target.closest('.blocs-icones__case');

      if (!case_) { return; }

      var nom = case_.dataset.icone || '';

      if (nom === '') { return; }

      var dire = function () {
        /*
         * LE RETOUR SE POSE SUR LA CASE, deux secondes. Une alerte en haut de
         * page demanderait un geste pour la fermer, et le regard est ici.
         */
        case_.classList.add('blocs-icones__case--copiee');

        window.setTimeout(function () {
          case_.classList.remove('blocs-icones__case--copiee');
        }, 1800);
      };

      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(nom).then(dire, function () { selectionner(case_); });

        return;
      }

      selectionner(case_);
    });
    });
  }

  /**
   * UNE LIGNE D'ICONE AJOUTEE PART VIERGE.
   *
   * LE `+` DU COEUR DUPLIQUE LA LIGNE, IL N'EN CREE PAS UNE VIDE.
   *
   * MESURE SUR LE BANC, 25 septembre 2026, sur le module de Cyrille : deux
   * lignes enregistrees, toutes deux nommees « superman2 », avec le meme
   * fichier. Il avait bien ajoute une ligne et change son image ; le NOM, lui,
   * etait reste celui de la copie. Comme le nom sert de clef, les deux icones
   * n'en faisaient qu'une, et la premiere paraissait effacee. « J'essaie
   * toujours d'afficher mes deux icones et cela ne fonctionne pas, il m'en
   * reste qu'un. »
   *
   * C'est le comportement normal du composant, et il ARRANGE une liste de
   * blocs, ou l'on repart volontiers d'une ligne voisine. Ici, deux icones
   * n'ont jamais le meme nom ni le meme fichier : repartir d'une copie ne fait
   * gagner que l'occasion de se tromper.
   *
   * LE VIDAGE EST POSE SUR L'EVENEMENT DU COEUR, pas dans notre bouton : le
   * `+` range dans le coin de la ligne passe par la lui aussi, et les deux
   * chemins donnent donc le meme resultat. Un seul endroit a tenir.
   *
   * LE CHAMP IMAGE SE VIDE PAR SON PROPRE BOUTON « Effacer » : il tient son
   * apercu et son etat, et remettre son `input` a vide laisserait l'image
   * affichee sous un champ devenu vide.
   */
  /**
   * UNE SEULE ZONE DE DEPOT, ET LA GRILLE FAIT LA LISTE.
   *
   * « Je n'ai pas besoin de deux zones de telechargement, une seule suffit. »
   * Cyrille, 25 septembre 2026. Le sous-formulaire montrait une ligne par
   * icone, donc un champ image par icone : dix icones auraient donne dix zones
   * de depot empilees, alors que la grille juste au-dessus les montre deja
   * toutes.
   *
   * LES LIGNES REMPLIES SONT MASQUEES, PAS SUPPRIMEES. Leurs champs restent
   * dans le formulaire et partent a l'enregistrement : c'est ce qui permet de
   * n'en montrer qu'une sans rien perdre. La grille les represente, et la
   * croix rouge les retire.
   *
   * UNE LIGNE VIDE EST TOUJOURS PRETE. S'il n'en reste aucune, on en demande
   * une au composant du coeur, que `viderLigneIcone` nettoie au passage. Une
   * ligne vide ne s'enregistre pas : le champ ecarte toute ligne sans nom ou
   * sans fichier, et c'est ce qui rend cette mecanique sans danger.
   */
  /**
   * Une seule tentative de preparer la zone vide, par chargement de page.
   * Voir la note dans `uneSeuleZone` : c'est ce drapeau qui interdit la
   * boucle, parce qu'il est pose AVANT le clic et jamais remis a zero.
   */
  var zonePreparee = false;

  function uneSeuleZone() {
    var champ = document.querySelector('#fieldset-icones joomla-field-subform');

    if (!champ) { return; }

    var lignes = [].slice.call(champ.querySelectorAll('div.subform-repeatable-group'));

    /*
     * LE GARDE-FOU, POSE APRES COUP ET QUI RESTE.
     *
     * Le 25 septembre 2026, une boucle a produit mille lignes en quelques
     * secondes, et elles ont ete enregistrees. Personne ne declare cinquante
     * icones a soi : au-dela, ce n'est plus une saisie, c'est un emballement.
     * On s'arrete, on ne touche a rien, et on le dit dans la console plutot
     * que d'aggraver en masquant ou en supprimant des lignes.
     *
     * UN GARDE-FOU NE REPARE PAS LA CAUSE, il borne les degats. La cause est
     * traitee plus bas : le script ne cree plus aucune ligne.
     */
    if (lignes.length > 50) {
      if (window.console && console.warn) {
        console.warn('[Opus] ' + lignes.length + ' lignes d\'icones : rangement interrompu.');
      }

      return;
    }

    var vides = [];

    lignes.forEach(function (ligne) {
      var nom = ligne.querySelector('input[name$="[nom]"]');
      var fic = ligne.querySelector('input[name$="[fichier]"]');

      var remplie = nom && fic && nom.value.trim() !== '' && fic.value.trim() !== '';

      ligne.classList.toggle('blocs-icone-rangee', !!remplie);

      if (!remplie) { vides.push(ligne); }
    });

    /*
     * UNE SEULE LIGNE VIDE, LA DERNIERE. Deux lignes a moitie remplies
     * remettraient deux zones de depot a l'ecran, ce que l'on vient de retirer.
     */
    vides.slice(0, -1).forEach(function (ligne) {
      var oter = ligne.querySelector('.group-remove');

      if (oter) { oter.click(); }
    });

    /*
     * PLUS DE BOUTON « Ajouter une icone » - 25 septembre 2026. « Le bouton
     * ajouter une icone ne sert a rien », Cyrille, et c'est exact depuis qu'une
     * zone vide attend toujours : il ne pouvait qu'en ouvrir une seconde, ce
     * que l'on venait justement de retirer.
     */

    /*
     * UNE ZONE PRETE A L'OUVERTURE, ET UNE SEULE FOIS PAR PAGE.
     *
     * « Je n'ai pas de zone de telechargement. » Cyrille, 25 septembre 2026.
     * Apres la correction de l'emballement, le script ne creait plus rien du
     * tout : quand toutes les lignes etaient remplies, donc toutes masquees,
     * l'ecran n'offrait plus ou deposer, et il fallait savoir cliquer
     * « Ajouter une icone ». Une zone vide doit attendre, c'est ce qu'on
     * attend d'un formulaire.
     *
     * LE DRAPEAU EST POSE AVANT LE CLIC, ET C'EST TOUTE LA DIFFERENCE AVEC LA
     * VERSION QUI A BOUCLE. Que la ligne creee arrive vide ou non, qu'elle
     * arrive ou pas, on ne retentera pas : une seule tentative par chargement
     * de page. L'emballement du matin venait d'un clic REPETE tant que le
     * resultat ne convenait pas ; ici, on agit une fois et on n'y revient
     * jamais.
     */
    if (vides.length === 0 && !zonePreparee) {
      zonePreparee = true;

      var dernier = lignes.length ? lignes[lignes.length - 1] : null;
      var plus = dernier ? dernier.querySelector('.group-add') : champ.querySelector('.group-add');

      if (plus) { plus.click(); }
    }

    /*
     * LE SCRIPT NE CREE PLUS JAMAIS DE LIGNE - 25 septembre 2026, apres degat.
     *
     * CE QUI S'EST PASSE, ET IL FAUT L'ECRIRE EN ENTIER. Cette fonction
     * cliquait le `+` du coeur quand il ne restait aucune ligne vide. Le `+`
     * DUPLIQUE la ligne au lieu d'en creer une vide ; `viderLigneIcone` devait
     * la nettoyer derriere, et il n'y arrivait pas sur une ligne masquee. La
     * nouvelle ligne arrivait donc remplie, la fonction ne trouvait toujours
     * aucune ligne vide, recliquait, et ainsi de suite : MILLE LIGNES en
     * quelques secondes, enregistrees, et le module annonce a 100 pour cent de
     * sa capacite. « Je n'ai plus de zone de telechargement et le module
     * m'indique qu'il est a 100 pour cent de ses capacites ! »
     *
     * LA LECON, ET ELLE VAUT POUR TOUT LE RESTE : un script ne declenche pas
     * une action dont il verifie ensuite le resultat pour decider de la
     * REdeclencher. C'est une boucle des que l'action echoue, et une action
     * finit toujours par echouer. On agit, ou on constate, jamais les deux en
     * cercle.
     *
     * CE QUI REMPLACE : le bouton « Ajouter une icone » est revenu, et c'est
     * UN GESTE DE L'UTILISATEUR qui cree la ligne. Une main ne boucle pas.
     */
  }

  function viderLigneIcone(ligne) {
    [].slice.call(ligne.querySelectorAll('input[type="text"]')).forEach(function (champTexte) {
      champTexte.value = '';
      champTexte.dispatchEvent(new Event('change', { bubbles: true }));
    });

    [].slice.call(ligne.querySelectorAll('joomla-field-media')).forEach(function (media) {
      var effacer = media.querySelector('.button-clear');

      if (effacer) {
        effacer.click();

        return;
      }

      if (media.setValue) { media.setValue(''); }
    });

    // Le curseur se pose dans le nom, la ou l'on va ecrire.
    var premier = ligne.querySelector('input[name$="[nom]"]');

    if (premier) { premier.focus(); }
  }

  /**
   * LA CROIX QUI RETIRE UNE ICONE A SOI.
   *
   * « Il me manque le moyen de les supprimer de la liste. » Cyrille,
   * 25 septembre 2026.
   *
   * ELLE NE SUPPRIME RIEN ELLE-MEME : elle retrouve la LIGNE du formulaire qui
   * porte ce nom et clique son bouton de retrait, celui du coeur. C'est lui
   * qui sait renumeroter les champs restants ; retirer les noeuds a la main
   * laisserait des index en trous, et la ligne suivante perdrait sa valeur en
   * silence.
   *
   * LE RETRAIT N'EST PAS ENREGISTRE TANT QU'ON N'ENREGISTRE PAS, et c'est le
   * comportement de tout le formulaire : le bouton est juste en dessous.
   */
  function brancherRetraitIcone() {
    var grille = document.querySelector('.blocs-icones--miennes .blocs-icones__grille');

    if (!grille) { return; }

    grille.addEventListener('click', function (ev) {
      var croix = ev.target.closest('.blocs-icones__ote');

      if (!croix) { return; }

      var nom = croix.dataset.ote || '';
      var sub = document.querySelector('#fieldset-icones joomla-field-subform');

      if (nom === '' || !sub) { return; }

      var lignes = [].slice.call(sub.querySelectorAll('div.subform-repeatable-group'));

      for (var i = 0; i < lignes.length; i++) {
        var champ = lignes[i].querySelector('input[name$="[nom]"]');

        if (!champ) { continue; }

        /*
         * LE MEME NETTOYAGE QUE DU COTE PHP. Le nom montre sous le dessin est
         * passe en minuscules et ses signes remplaces par des traits d'union :
         * comparer les deux bruts raterait « Mon Logo » contre « mon-logo ».
         */
        var propre = String(champ.value).trim().toLowerCase().replace(/[^a-z0-9-]/g, '-');

        if (propre !== nom) { continue; }

        var oter = lignes[i].querySelector('.group-remove');

        if (oter) { oter.click(); }

        break;
      }

      /*
       * LA CASE PART TOUT DE SUITE. La grille est produite par le PHP au
       * chargement ; elle ne se refait pas toute seule, et laisser la case en
       * place ferait croire que le clic n'a rien fait.
       */
      var boite = croix.closest('.blocs-icones__boite');

      if (boite) { boite.remove(); }
    });
  }

  /**
   * UNE LIGNE D'ICONE AJOUTEE RECOIT SES PASTILLES.
   *
   * Le composant du coeur clone une ligne modele a chaque `+`, et la copie
   * arrive avec ses paves bleus. `joomla:subform-row-add` est l'evenement que
   * le coeur emet alors, et c'est le meme que l'onglet Mise en page ecoute
   * pour ses propres lignes.
   */
  function pastillerLesLignesDIcones() {
    var champ = document.querySelector('#fieldset-icones joomla-field-subform');

    if (!champ) { return; }

    /*
     * LE NOM DE L'EVENEMENT EST `subform-row-add`, SANS PREFIXE, ET LA LIGNE
     * EST DANS `detail.row`.
     *
     * MESURE DANS LE NAVIGATEUR, 25 septembre 2026, en interceptant
     * `dispatchEvent` : le coeur emet « subform-row-add » sur le champ, et non
     * « joomla:subform-row-add ». J'ecoutais donc un evenement qui n'arrive
     * jamais, et rien ne vidait la ligne clonee : c'est la cause derniere de
     * tout ce qui a suivi, de la ligne qui repartait pleine jusqu'a
     * l'emballement.
     *
     * LES DEUX NOMS SONT ECOUTES : le prefixe existe ailleurs dans Joomla, et
     * une version future peut le reintroduire. Un evenement qui n'arrive pas
     * ne coute rien ; un evenement manque coute une journee.
     *
     * LA CIBLE EST LE CHAMP, PAS LA LIGNE : `ev.target` designe le
     * `joomla-field-subform`. La ligne neuve voyage dans `ev.detail.row`, et
     * si elle manquait, la derniere du champ fait foi.
     */
    var surAjout = function (ev) {
      var ligne = (ev.detail && ev.detail.row) || null;

      if (!ligne) {
        var toutes = champ.querySelectorAll('div.subform-repeatable-group');
        ligne = toutes.length ? toutes[toutes.length - 1] : null;
      }

      if (!ligne || !ligne.querySelectorAll) { return; }

      pastiller(ligne);

      /*
       * LE VIDAGE ATTEND UN TOUR DE BOUCLE, ET CE DETAIL EST LE DERNIER
       * MAILLON.
       *
       * MESURE, 25 septembre 2026 : vide dans l'ecouteur, la ligne repart
       * pleine ; vide dans un `setTimeout` a zero, elle est vide. Le coeur
       * emet l'evenement PUIS recopie les valeurs de la ligne d'origine dans
       * la copie. Nettoyer avant qu'il ait fini, c'est nettoyer ce qu'il va
       * reecrire.
       */
      window.setTimeout(function () {
        viderLigneIcone(ligne);
        uneSeuleZone();
      }, 0);
    };

    champ.addEventListener('subform-row-add', surAjout);
    champ.addEventListener('joomla:subform-row-add', surAjout);

    var surRetrait = function () {
      window.setTimeout(uneSeuleZone, 0);
    };

    champ.addEventListener('subform-row-remove', surRetrait);
    champ.addEventListener('joomla:subform-row-remove', surRetrait);

    /*
     * ON RANGE APRES UNE SAISIE, mais `uneSeuleZone` ne cree plus rien : elle
     * ne fait que masquer les lignes completes. Une fonction qui se contente
     * de constater peut etre rappelee sans fin sans consequence.
     */
    champ.addEventListener('change', function () {
      window.setTimeout(uneSeuleZone, 0);
    });

    uneSeuleZone();
  }

  /**
   * LE BOUTON QUI ENREGISTRE APRES UN AJOUT D'ICONE.
   *
   * « Il manque un bouton enregistrer ou valider. » Cyrille, 25 septembre 2026.
   * Une icone ajoutee dans l'onglet Icones n'apparait dans le champ Icone des
   * boutons qu'une fois le module enregistre : le champ construit sa liste au
   * rendu du formulaire, et rien ne la rafraichit en cours de saisie. Sans ce
   * bouton, il fallait le savoir, remonter en haut de l'ecran, enregistrer,
   * puis redescendre.
   *
   * IL APPELLE LE BOUTON D'ENREGISTREMENT DU COEUR, il n'envoie pas le
   * formulaire lui-meme : `module.apply` passe par les validations de Joomla,
   * garde l'ecran ouvert et revient sur l'onglet courant. Poser un `submit` a
   * la main sauterait tout cela.
   */
  function poserBoutonValider() {
    var champ = document.querySelector('#fieldset-icones joomla-field-subform');

    if (!champ || document.querySelector('.blocs-valider')) { return; }

    var bouton = document.createElement('button');
    bouton.type = 'button';
    bouton.className = 'blocs-valider';
    bouton.textContent = texte('MOD_OPUS_MYICONS_SAVE', 'Enregistrer et voir mes icones');

    bouton.addEventListener('click', function () {
      if (window.Joomla && Joomla.submitbutton) {
        Joomla.submitbutton('module.apply');

        return;
      }

      /*
       * SANS LE COEUR, ON NE FAIT RIEN PLUTOT QU'AUTRE CHOSE. Envoyer le
       * formulaire a la main sauterait les validations, et un module a moitie
       * valide enregistre est pire qu'un bouton qui n'a pas marche.
       */
      bouton.disabled = true;
    });

    champ.parentNode.appendChild(bouton);

    /*
     * L'AIDE DESCEND SOUS LE BOUTON - 25 septembre 2026.
     *
     * « Place ce module d'aide des images sous le bouton enregistrer et
     * voir. » Cyrille. Elle est PRODUITE par le champ « Mes icones », en haut
     * de la colonne, parce que c'est ce champ qui sait de quoi il parle ; elle
     * se LIT en bas, apres le formulaire qu'elle explique, ou l'on arrive
     * justement quand on prepare un fichier.
     *
     * UN `details` SE DEPLACE SANS RISQUE. C'est du balisage inerte, sans etat
     * ni ecouteur : le deplacer ne lui fait rien perdre. C'est tout le
     * contraire d'un `joomla-field-subform`, qui se deconnecte et se
     * reconnecte, et c'est pourquoi le formulaire, lui, n'a pas bouge d'un
     * noeud de tout ce chantier.
     */
    /*
     * LES DEUX BLOCS DESCENDENT, DANS LEUR ORDRE. Ils portent la meme classe,
     * et `querySelector` n'en prenait que le premier : l'aide descendait sous
     * le bouton, la liste des sources restait en haut, coincee dans la grille
     * des icones. « Il n'y a rien », 25 septembre 2026, et pour cause : elle
     * n'etait pas la ou elle etait attendue.
     *
     * `insertBefore` AVEC UN REPERE QUI AVANCE : poser les deux sur
     * `bouton.nextSibling` les aurait mis dans l'ordre inverse.
     */
    var apres = bouton;

    [].slice.call(document.querySelectorAll('#fieldset-icones .blocs-icones__aide'))
      .forEach(function (bloc) {
        apres.parentNode.insertBefore(bloc, apres.nextSibling);
        apres = bloc;
      });
  }

  /** Le repli : on selectionne le nom, Ctrl+C fait le reste. */
  function selectionner(case_) {
    var mot = case_.querySelector('.blocs-icones__nom');

    if (!mot || !window.getSelection) { return; }

    var plage = document.createRange();
    plage.selectNodeContents(mot);

    var choix = window.getSelection();
    choix.removeAllRanges();
    choix.addRange(plage);
  }

  /**
   * LE BOUTON QUI OUVRE L'ONGLET CSS ET Y ECRIT LA REGLE.
   *
   * IL ECRIT UN SQUELETTE, IL NE SE CONTENTE PAS DE CHANGER D'ONGLET. Arriver
   * sur une zone de texte vide ne fait gagner qu'un clic ; arriver avec
   * `.ma-classe {` deja ecrit et le curseur a l'interieur fait gagner le nom,
   * les accolades, et le risque de faute de frappe qui va avec. Une classe mal
   * recopiee ne provoque aucune erreur : la regle ne s'applique simplement
   * jamais, et on cherche la cause ailleurs.
   *
   * IL NE REECRIT PAS UNE REGLE QUI EXISTE : si la zone contient deja cette
   * classe, on y emmene le curseur au lieu d'en ajouter une seconde.
   *
   * LE CHAMP VIDE EST DIT, PAS DEVINE. Sans nom de classe, le bouton le
   * signale et rend le focus au champ ; ecrire `. {` serait pire que rien.
   */
  function pontCss(champ) {
    var bouton = document.createElement('button');
    bouton.type = 'button';
    bouton.className = 'btn btn-sm opus-pont-css';
    bouton.textContent = texte('MOD_OPUS_CSS_WRITE', 'Ecrire le CSS');

    bouton.addEventListener('click', function () {
      var nom = (champ.value || '').trim();

      if (nom === '') {
        bouton.classList.add('opus-pont-css--vide');
        bouton.textContent = texte('MOD_OPUS_CSS_WRITE_EMPTY', 'Nommez d\'abord la classe');
        champ.focus();

        window.setTimeout(function () {
          bouton.classList.remove('opus-pont-css--vide');
          bouton.textContent = texte('MOD_OPUS_CSS_WRITE', 'Ecrire le CSS');
        }, 2600);

        return;
      }

      ouvrirOngletCss(nom);
    });

    return bouton;
  }

  /**
   * Bascule sur l'onglet CSS personnalise et pose le curseur dans la regle.
   *
   * L'ONGLET SE CHANGE EN CLIQUANT SON BOUTON, jamais en manipulant les
   * attributs a la main : `joomla-tab` tient son propre etat, `aria-selected`,
   * `tabindex`, le panneau montre et les autres caches. Le forcer de
   * l'exterieur laisserait l'element et l'affichage en desaccord.
   *
   * LE PREFIXE DU MODULE EST POSE D'OFFICE. Ce qui est ecrit dans cette zone
   * part dans l'en-tete de la page et vaut pour le site entier ; `.opus` devant
   * la regle en limite la portee au module, et c'est ce que l'aide de l'onglet
   * recommande deja en toutes lettres.
   */
  function ouvrirOngletCss(nom) {
    var onglet = document.querySelector('button[role="tab"][aria-controls="attrib-css"]');
    var zone = zoneCss();

    if (!onglet || !zone) { return; }

    onglet.click();

    var regle = '.opus .' + nom;
    var contenu = lireCss(zone);

    if (contenu.indexOf(regle) === -1) {
      var avant = contenu.replace(/\s+$/, '');
      var saut = avant === '' ? '' : '\n\n';

      contenu = avant + saut + regle + ' {\n  \n}\n';

      ecrireCss(zone, contenu);
    }

    /*
     * LE CURSEUR SE POSE DANS LES ACCOLADES, la ou l'on va ecrire. Sur une
     * regle qui existait deja, il se pose juste apres son accolade ouvrante.
     *
     * SEULEMENT SUR UNE ZONE DE TEXTE NUE. `setSelectionRange` n'existe que
     * la ; CodeMirror tient son propre curseur, et le placer demanderait son
     * API interne, que Joomla n'expose pas. On se contente alors d'amener la
     * zone sous les yeux, ce qui est l'essentiel : la regle est ecrite, elle
     * est visible, et le clic suivant est dans les accolades.
     */
    var ou = contenu.indexOf(regle);
    var accolade = contenu.indexOf('{', ou);
    var bloc = blocCss(zone);

    window.setTimeout(function () {
      if (zone.setSelectionRange && zone.offsetParent !== null) {
        zone.focus();

        if (accolade !== -1) {
          var place = contenu.indexOf('\n', accolade);
          place = place === -1 ? accolade + 1 : place + 3;
          zone.setSelectionRange(place, place);
        }
      }

      bloc.scrollIntoView({ block: 'center' });
    }, 60);
  }

  /** L'intitule de la ligne, pour que le panneau dise de quoi il parle. */
  function nomDeLigne(rangee) {
    var type = rangee.querySelector('[name$="[type]"]');

    if (type && type.options && type.selectedIndex >= 0) {
      return type.options[type.selectedIndex].text;
    }

    var titre = rangee.querySelector('[name$="[title]"]');

    return titre && titre.value.trim() !== '' ? titre.value.trim() : '';
  }

  var peuplerCourant = function () {};
  var routeOuverte = null;

  function ouvrirReglages(rangee, roue) {
    var dlg = construirePanneau();
    var corps = dlg.querySelector('.opus-reglages__corps');

    // Une autre roue etait ouverte : elle se referme sans reprendre le focus,
    // qui appartient desormais a celle qu'on vient de cliquer.
    if (routeOuverte && routeOuverte !== roue) { fermerReglages(false); }

    corps.textContent = '';

    /*
     * LE TITRE DIT QUELLE LIGNE ON REGLE. Le panneau ne se superpose plus a
     * l'ecran, il vit a cote : rien ne dit plus d'ou il vient, sinon ce mot.
     */
    var intitule = nomDeLigne(rangee);
    var titre = dlg.querySelector('h3');
    var mot = titre.querySelector('.opus-reglages__brique');

    if (!mot) {
      mot = document.createElement('span');
      mot.className = 'opus-reglages__brique';
      titre.insertBefore(mot, titre.querySelector('.opus-reglages__fermer'));
    }

    mot.textContent = intitule ? ' · ' + intitule : '';

    /*
     * ON NE MET EN MIROIR QUE LES CHAMPS VISIBLES A CET INSTANT.
     *
     * Les champs de lien d'une carte dependent les uns des autres par des
     * `showon` : l'adresse ne se montre que pour un lien d'adresse, l'element
     * de menu que pour un lien de menu. Ces regles s'appliquent au VRAI champ,
     * dans sa ligne ; le miroir, lui, n'a pas de nom et ne les recoit pas.
     * Recopier un champ que le manifeste a eteint afficherait donc les deux
     * sortes de lien a la fois, et l'une des deux ne servirait a rien.
     *
     * Le panneau montre donc l'etat du moment. Changer le type de lien puis
     * rouvrir la roue montre les champs qui vont avec.
     */
    /*
     * LE PANNEAU SUIT LES `showon`, IL NE LES FIGE PAS.
     *
     * « Un element de menu devrait nous ouvrir la liste quelque part »,
     * Cyrille, 22 septembre 2026. Il avait raison : on choisissait « Element
     * de menu » dans le panneau, et la liste des menus n'apparaissait pas. Le
     * panneau etait peuple UNE fois, a l'ouverture, avec les champs visibles a
     * cet instant ; la liste des menus, elle, ne se montre qu'une fois le type
     * de lien choisi. Il fallait fermer et rouvrir pour la voir.
     *
     * `peupler()` est donc rejoue a chaque changement, et il ne refait pas le
     * panneau : il ajoute ce qui vient d'apparaitre, retire ce qui vient de
     * disparaitre, et laisse le reste en place. Sans cela le champ qu'on vient
     * de changer serait recree sous les doigts, et le focus partirait avec.
     *
     * LE TOUR SUIVANT, ET PAS AVANT : `showon` du coeur ecoute le meme
     * `change` que nous. Lu a l'instant meme, le formulaire porte encore
     * l'etat d'avant.
     */
    var peupler = function () {
      var attendus = {};
      var vus = {};

      [].slice.call(rangee.querySelectorAll('.blocs-reglage')).forEach(function (champ) {
        var groupe = champ.closest('.control-group');

        if (!groupe || groupe.classList.contains('hidden')) { return; }

        /*
         * ON NE PREND PAS LE PREMIER TROUVE, ON PREND CE QUI EST A NOUS.
         *
         * La ligne d'un bloc CONTIENT la liste de ses elements, et chaque
         * element porte lui aussi une classe et un identifiant derriere sa
         * propre roue. `querySelectorAll` descend dans tout, donc la roue du
         * bloc montrait aussi les reglages de ses quatre elements : « c'est quoi
         * ces deux kilometres de reglages », Cyrille, 22 septembre 2026. Quatre
         * elements donnaient neuf champs au lieu de deux.
         *
         * Le garde `vus[champ.name]` ne pouvait rien : les noms different d'une
         * ligne a l'autre, c'est meme tout leur objet.
         *
         * C'est le piege numero un du dossier de passation, et il a deja mordu
         * quatre fois. Le remede est toujours le meme : remonter au conteneur de
         * ligne et verifier que c'est bien le notre.
         */
        if (champ.closest('.subform-repeatable-group') !== rangee) { return; }

        /*
         * UN CHAMP SANS NOM N'EST PAS UN CHAMP, ET IL NE DOIT PLUS RIEN CASSER.
         *
         * Joomla pose la classe demandee sur le `fieldset` qui enveloppe un
         * groupe de boutons radio, et un fieldset n'a pas de `name`. Le miroir
         * tombait dessus avec « Cannot read properties of undefined », et comme
         * `peupler` s'arretait la, `ouvrirReglages` n'atteignait jamais la ligne
         * qui montre le panneau : la roue semblait morte. « L'icone n'ouvre
         * rien », Cyrille, 23 septembre 2026.
         *
         * LE MANIFESTE A ETE CORRIGE, ET CE GARDE RESTE. Un reglage mal declare
         * doit couter le reglage, jamais le panneau entier.
         */
        if (!champ.name) { return; }

        // Un groupe de radios porte le meme nom plusieurs fois.
        if (vus[champ.name]) { return; }

        vus[champ.name] = 1;

        var aide = groupe.querySelector('.form-text, .field-description');

        attendus[champ.name] = 1;

        if (corps.querySelector('[data-champ="' + champ.name + '"]')) { return; }

        corps.appendChild(miroir(
          champ,
          intituleDe(champ, groupe),
          aide ? aide.textContent.trim() : ''
        ));
      });

      // Ce qui n'est plus visible dans la ligne quitte le panneau.
      [].slice.call(corps.querySelectorAll('[data-champ]')).forEach(function (env) {
        if (!attendus[env.dataset.champ]) { env.remove(); }
      });
    };

    peupler();

    /*
     * LE GARDE EST SUR LE PANNEAU, QUI DURE, et c'est voulu ici : le panneau
     * est unique et reutilise d'une roue a l'autre, l'ecouteur ne doit donc
     * etre pose qu'une fois. La ligne courante, elle, est relue a chaque
     * appel, par `peuplerCourant`.
     */
    if (!dlg.dataset.opusSuivi) {
      dlg.dataset.opusSuivi = '1';

      corps.addEventListener('change', function () {
        window.setTimeout(function () {
          /*
           * `dlg.hidden`, ET SURTOUT PAS `dlg.open`.
           *
           * « Quand je choisis element de menu ou adresse, il faut que
           * j'enregistre pour voir les champs de selection », Cyrille,
           * 24 septembre 2026. Mesure faite sur le banc, dans son propre
           * ecran : le vrai champ passait bien a « url », le `showon` du coeur
           * masquait bien la liste des menus et montrait bien l'adresse, et le
           * panneau, lui, ne bougeait pas d'un poil.
           *
           * LA CAUSE TIENT EN UN MOT : ce panneau est un `div`, pas un
           * `dialog`. Il s'ouvre et se ferme par `hidden`, jamais par
           * `showModal()`. `dlg.open` valait donc `undefined` sur un `div`,
           * la condition etait TOUJOURS fausse, et `peuplerCourant()` n'a
           * jamais ete appele depuis que cette ligne existe. Tout le mecanisme
           * decrit trente lignes plus haut etait ecrit, juste, et mort.
           *
           * Le commentaire de 1990 disait deja « le panneau suit les showon,
           * il ne les fige pas ». Il le disait au futur sans que personne
           * verifie le present. Une condition qui rend `undefined` ne leve
           * aucune erreur : elle se contente de ne jamais rien faire.
           */
          if (!dlg.hidden) { peuplerCourant(); }
        }, 0);
      });
    }

    peuplerCourant = peupler;

    dlg.hidden = false;

    if (roue) {
      roue.setAttribute('aria-expanded', 'true');
      routeOuverte = roue;
    }

    ligneReglee(rangee);

    /*
     * LE FOCUS ENTRE DANS LE PANNEAU, ET C'EST OBLIGATOIRE. Il est le dernier
     * enfant du fieldset, la roue est au milieu de la liste : sans ce saut, la
     * tabulation continuerait dans la ligne suivante et le panneau serait
     * inatteignable autrement qu'en tabulant sur tout le formulaire.
     */
    var premier = corps.querySelector('input, select, textarea, button');

    if (premier) { premier.focus(); }
  }

  /**
   * Pose la roue d'une rangee.
   *
   * ELLE N'EST PAS DANS LE GROUPE DES `+ − ⣿`, ET C'EST LE CHOIX DE CORPUS :
   * ajouter, retirer et deplacer agissent sur la LIGNE, la roue agit sur son
   * CONTENU. Melangees, on cliquerait un jour sur l'une en visant l'autre.
   */
  function poserRoue(rangee) {
    if (rangee.dataset.opusRoue) { return; }
    if (!rangee.querySelector('.blocs-reglage')) { return; }

    var bouton = document.createElement('button');
    bouton.type = 'button';
    bouton.className = 'opus-roue btn btn-sm';

    var titre = texte('MOD_OPUS_SETTINGS_TITLE', 'Reglages de la ligne');
    bouton.title = titre;
    bouton.setAttribute('aria-label', titre);

    bouton.setAttribute('aria-expanded', 'false');
    bouton.setAttribute('aria-controls', 'blocs-reglages');

    /*
     * C'EST L'ETAT AFFICHE QUI FAIT FOI, PAS LE SOUVENIR QU'ON EN A.
     *
     * « L'icone n'ouvre rien », Cyrille, 23 septembre 2026. Mesure faite sur le
     * banc : le panneau etait `hidden`, et pourtant `routeOuverte` le croyait
     * ouvert pour cette roue. Le premier clic le FERMAIT donc, sans rien
     * montrer, et il fallait cliquer deux fois pour le voir.
     *
     * La variable et l'ecran peuvent diverger : le panneau se masque aussi
     * quand on le replie, quand on ferme sa section, ou quand un redessin le
     * reconstruit. Une seule de ces deux sources est verifiable par
     * l'utilisateur, et c'est celle qu'il regarde.
     *
     * ON NE CHERCHE DONC PLUS A SAVOIR QUI A MASQUE QUOI : si le panneau n'est
     * pas visible, un clic l'ouvre. C'est la seule reponse qui ne puisse jamais
     * surprendre.
     */
    bouton.addEventListener('click', function () {
      var boite = document.getElementById('blocs-reglages');
      var visible = boite && !boite.hidden && boite.offsetParent !== null;

      if (routeOuverte === bouton && visible) {
        fermerReglages(true);

        return;
      }

      ouvrirReglages(rangee, bouton);
    });

    /*
     * DANS UN TABLEAU, LA ROUE VA DANS LA CELLULE DE LA CLASSE : c'est le
     * choix de Corpus, et il tient a une raison simple. Ajouter, retirer et
     * deplacer agissent sur la LIGNE, la roue agit sur son CONTENU : melangees
     * dans le meme groupe, on cliquerait un jour sur l'une en visant l'autre.
     */
    var cases = rangee.tagName === 'TR' ? cellulesReglage(rangee) : [];

    (cases[0] || rangee).appendChild(bouton);
    rangee.dataset.opusRoue = '1';
  }

  /** Les outils d'une rangee : le duplicateur et les pictogrammes. */
  function outils(rangee) {
    poserRoue(rangee);
    iconiser(rangee);
    outilsADroite(rangee);
  }

  /**
   * LES TROIS PICTOGRAMMES FERMENT LA LIGNE, TOUJOURS AU MEME ENDROIT.
   *
   * Regle de Cyrille, 22 septembre 2026 : « passe toujours les boutons
   * alignement, oeil, reglage a droite, qu il y ait une harmonie de position
   * des symboles ».
   *
   * POURQUOI ILS NE L ETAIENT PAS. La ligne est une bande souple : les
   * pictogrammes tombent a droite tant qu un champ s etire devant eux. Sur une
   * ligne Image ou Texte, le contenu passe DESSOUS sur toute la largeur : il ne
   * reste devant eux que le choix de l element, qui ne s etire pas, et les
   * trois symboles se collaient au milieu. Trois lignes de suite, trois
   * positions differentes.
   *
   * LE VIDE SE MET AVANT LE PREMIER, ET NON APRES LE DERNIER. Une marge
   * automatique a gauche du premier pictogramme mange tout l espace libre :
   * ce qui le suit part a droite, y compris la roue. Quand un champ s etire
   * deja, il ne reste rien a manger et la ligne ne bouge pas.
   *
   * LA CLASSE SE POSE EN JAVASCRIPT PARCE QUE LE CSS NE SAIT PAS DIRE
   * « LE PREMIER DE CEUX-LA ». Les cases masquees par la roue restent des
   * freres entre les pictogrammes : aucun selecteur d adjacence ne voit jamais
   * deux pictogrammes cote a cote, et `:first-of-type` ne connait que les
   * balises.
   */
  /**
   * UNE LIGNE QUI PORTE UNE IMAGE SE RECONNAIT PAR UNE CLASSE.
   *
   * ELLE NE PEUT PAS S ECRIRE EN CSS, et c est mesure : il faudrait
   * `:has(> .control-group:has(joomla-field-media))`, or un `:has()` dans un
   * `:has()` est invalide. Le selecteur entier est alors ignore, sans erreur,
   * et la feuille semble juste ne rien faire. Sans le `>` interieur, on
   * attraperait toutes les lignes dont la pile contient une image.
   */
  function marquerLigneImage(rangee) {
    var media = rangee.querySelector('joomla-field-media');
    var sienne = !!media && media.closest('.subform-repeatable-group') === rangee;

    /*
     * SEULEMENT SUR UNE LIGNE D'ELEMENT, et c'est la correction du 24 septembre
     * 2026. « Le backend est un peu melange », Cyrille, devant les onglets.
     *
     * LA MISE EN PAGE QUI SUIT CETTE CLASSE EST TAILLEE POUR LA LIGNE
     * D'ELEMENT, au pixel : une marge haute negative de 2,75 rem pour remonter
     * la zone de depot sous le choix d'element, une colonne de 11 rem pour la
     * caler sur le champ de contenu des autres lignes, et 6,2 rem reserves aux
     * trois pictogrammes de droite. Trois nombres mesures sur CETTE ligne-la.
     *
     * POSEE SUR LA LIGNE D'UN ONGLET, qui n'a ni choix d'element ni
     * pictogrammes, elle remontait la zone par-dessus le champ du dessus et la
     * serrait a 192 pixels : l'apercu, la description et le bouton
     * « Selectionner » se chevauchaient. Le defaut n'etait pas dans le champ
     * media, il etait dans une regle appliquee la ou elle n'avait rien a faire.
     *
     * CE QUI DISTINGUE LES DEUX : une ligne d'element porte SON choix de type,
     * en enfant direct. Une ligne de sous-sous-formulaire n'en a pas.
     */
    var element = !!rangee.querySelector(':scope > .control-group select[name$="[type]"]');

    rangee.classList.toggle('blocs-ligne-image', sienne && element);
  }

  /**
   * CE QUE PESE L IMAGE CHOISIE, SOUS SON CHEMIN.
   *
   * « Une image, c est la premiere source de probleme », Cyrille, 23 septembre
   * 2026. Le poids ne se REGLE pas, il se CONSTATE : redimensionner appartient
   * au gestionnaire de medias, et un champ « poids maximal » dans ce module ne
   * ferait qu afficher une regle que personne n applique.
   *
   * DEUX MESURES, DEUX SOURCES. Les dimensions viennent de l image elle-meme,
   * que le navigateur a deja chargee pour l apercu : `naturalWidth` ne coute
   * rien. Le poids demande une requete, et on ne demande que l en-tete
   * (`HEAD`) : le fichier n est pas retelecharge.
   *
   * DEUX SEUILS, ET ILS SE JUSTIFIENT. Au-dela de 300 Ko une image ralentit
   * une page sur un reseau ordinaire ; au-dela de 2000 pixels de large elle est
   * plus grande que le plus grand des emplacements de ce module, et le
   * navigateur la reduira a l affichage apres l avoir telechargee en entier.
   */
  var SEUIL_POIDS = 300 * 1024;
  var SEUIL_LARGEUR = 2000;

  function lisiblePoids(octets) {
    if (octets >= 1024 * 1024) {
      return (Math.round(octets / (1024 * 1024) * 10) / 10) + ' Mo';
    }

    return Math.round(octets / 1024) + ' Ko';
  }

  function direLePoids(media) {
    var img = media.querySelector('.field-media-preview img');
    var chemin = media.querySelector('.field-media-input');

    if (!img || !chemin) { return; }

    /*
     * LA NOTE VIT DANS LA LIGNE, PAS DANS LA CASE DE L IMAGE.
     *
     * « Peux-tu afficher le poids a droite, sous les trois icones ? »,
     * Cyrille, 23 septembre 2026. Cette place existe deja : c est la gouttiere
     * de 6,2 rem que la case laisse a droite pour les pictogrammes, vide sur
     * toute sa hauteur. Posee dans la case, la note aurait suivi la grille des
     * champs ; posee dans la ligne, elle se cale sur cette gouttiere.
     */
    /*
     * ELLE VIT DANS LA CASE DE L IMAGE, ET C EST UNE CORRECTION.
     *
     * Posee dans la LIGNE, elle se calait sur un ancetre lointain : 2,2 rem
     * comptes depuis le haut de la ligne la mettaient a 927 px, pile sur les
     * pictogrammes (928 a 956), qui ne repondaient plus au clic. Mesure faite
     * sur le banc apres la premiere livraison.
     *
     * DANS LA CASE, qui est le bloc positionne, les memes 2,2 rem tombent sous
     * eux. Et `pointer-events: none` en ceinture : une note ne se clique pas,
     * elle ne doit jamais retenir un clic qui ne lui est pas destine.
     */
    var cadre = media.closest('.control-group');

    if (!cadre) { return; }

    var note = [].slice.call(cadre.children).filter(function (e) {
      return e.classList && e.classList.contains('blocs-poids');
    })[0];

    if (!note) {
      note = document.createElement('p');
      note.className = 'blocs-poids';
      cadre.appendChild(note);
    }

    var valeur = (chemin.value || '').split('#')[0];

    // Pas d image choisie : pas de note, et pas de requete non plus.
    if (valeur === '') {
      note.textContent = '';
      note.hidden = true;

      return;
    }

    var large = img.naturalWidth || 0;
    var haut  = img.naturalHeight || 0;

    /*
     * ON ATTEND QUE L IMAGE SOIT LUE. Tant que le navigateur ne l a pas
     * decodee, `naturalWidth` vaut 0 : mesure faite sur le banc, une note
     * ecrite trop tot annoncait « 0 x 0 ».
     */
    if (large === 0) {
      img.addEventListener('load', function () { direLePoids(media); }, { once: true });

      return;
    }

    var poser = function (octets) {
      var taille = octets === null ? '?' : lisiblePoids(octets);
      var lourde = octets !== null && octets > SEUIL_POIDS;
      var vaste  = large > SEUIL_LARGEUR;
      var clef = 'MOD_OPUS_IMG_WEIGHT';

      if (lourde) { clef += '_HEAVY'; }
      else if (vaste) { clef += '_WIDE'; }

      var modele = texte(clef, '%1$s x %2$s pixels, %3$s');

      note.textContent = modele
        .replace('%1$s', large)
        .replace('%2$s', haut)
        .replace('%3$s', taille);

      note.classList.toggle('blocs-poids--alerte', lourde || vaste);
      note.hidden = false;
    };

    /*
     * `HEAD` ET NON `GET` : on veut la taille annoncee par le serveur, pas le
     * fichier. Si la reponse ne la donne pas, on le dit plutot que de mentir.
     */
    if (media.dataset.opusPoidsPour === img.src) { return; }

    media.dataset.opusPoidsPour = img.src;

    fetch(img.src, { method: 'HEAD' })
      .then(function (r) {
        var t = r.headers.get('content-length');

        poser(t ? parseInt(t, 10) : null);
      })
      .catch(function () { poser(null); });
  }

  /** Branche la note sur une ligne d image, une seule fois. */
  function suivreLePoids(rangee) {
    var media = rangee.querySelector('joomla-field-media');

    if (!media || media.closest('.subform-repeatable-group') !== rangee) { return; }

    direLePoids(media);

    if (media.dataset.opusPoids) { return; }

    media.dataset.opusPoids = '1';

    /*
     * LE CHAMP NE CHANGE PAS TOUT SEUL : c est la fenetre du gestionnaire de
     * medias qui y ecrit, et elle n emet pas d evenement que l on puisse
     * attendre. On observe donc l apercu, qui change en meme temps.
     */
    var oeil = new MutationObserver(function () { direLePoids(media); });

    oeil.observe(media, { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] });
  }

  /**
   * UN INTITULE NE SE REPETE QUE S'IL DIT LA MEME CHOSE QUE CELUI DU DESSUS.
   *
   * La regle du 22 septembre 2026 (« supprime tous les titres qui se repetent
   * et qui me prennent de la place ») masquait les intitules de TOUTES les
   * lignes sauf la premiere. Elle etait juste tant que les lignes portaient
   * les memes champs : quatre fois « Element » et quatre fois « Texte », la
   * premiere ligne servait d'en-tete au reste.
   *
   * ELLE A CESSE D'ETRE JUSTE LE JOUR OU LES LIGNES ONT EU DES CHAMPS
   * DIFFERENTS. « Il me manque des titres au-dessus des champs tel, email,
   * adresse », Cyrille, 24 septembre 2026 : une ligne Contact posee sous une
   * ligne Titre perdait « Telephone », « Courriel » et « Informations », et
   * rien au-dessus ne les annoncait. Trois champs sans nom.
   *
   * CE QUI DECIDE, DESORMAIS, C'EST LE TYPE DE LA LIGNE PRECEDENTE. Meme type
   * que celle du dessus : les intitules sont deja ecrits, on les tait. Type
   * different : la ligne ouvre son propre groupe et porte ses intitules, comme
   * une premiere ligne. Trois cartes de suite restent donc aussi sobres
   * qu'avant, et un Contact isole garde ses trois noms.
   *
   * LA CLASSE EST POSEE ICI ET LA FEUILLE NE FAIT QUE LA SUIVRE : le CSS ne
   * sait pas comparer la valeur de deux listes deroulantes.
   */
  function marquerRepetitions(sf) {
    var precedent = null;

    [].slice.call(sf.children).forEach(function (rangee) {
      if (!rangee.classList || !rangee.classList.contains('subform-repeatable-group')) { return; }

      var choix = rangee.querySelector(':scope > .control-group select[name$="[type]"]');
      var type  = choix ? choix.value : '';

      rangee.classList.toggle('blocs-ligne--repete', precedent !== null && type === precedent);

      precedent = type;
    });
  }

  /**
   * LA ROUE DIT COMBIEN DE REGLAGES SONT POSES, COMME UNE NOTIFICATION.
   *
   * PREMIER ESSAI, ABANDONNE : un asterisque violet dans l'angle de chaque
   * champ concerne. Cyrille, 24 septembre 2026 : « l'asterisque n'est pas
   * visible, et je ne vois pas comment generaliser son affichage sur tous les
   * elements ». Les deux reproches etaient justes. Invisible parce qu'il se
   * posait dans l'angle d'un groupe dont l'angle est occupe par l'intitule ;
   * ingeneralisable parce qu'il demandait qu'un reglage designe un champ, donc
   * une convention de nommage a tenir sur vingt-cinq elements.
   *
   * SA PROPOSITION EST MEILLEURE, ET C'EST ELLE QUI EST ECRITE ICI : « faire
   * comme les notifications sur smartphone, une pastille violette en haut a
   * droite avec le nombre de changements dans les reglages ». Elle ne demande
   * AUCUNE convention : on compte les champs `blocs-reglage` de la ligne qui
   * ne sont pas a leur valeur par defaut, et on ecrit le nombre. Un element
   * neuf en profite sans qu'on touche a une ligne de ce fichier.
   *
   * CE QUI COMPTE COMME « REGLE » : un champ dont la valeur differe de celle
   * que le MANIFESTE lui donne.
   *
   * ET C'EST LA QUE LA PREMIERE VERSION S'EST TROMPEE. Elle comparait a
   * `defaultValue` et `defaultSelected`, en croyant que le navigateur gardait
   * le defaut du manifeste. Il garde la valeur SERVIE dans le HTML, donc celle
   * deja enregistree : sur un module enregistre, la pastille restait a zero
   * quels que soient les reglages. « Je ne vois pas la pastille », Cyrille,
   * 24 septembre 2026, et la mesure sur le banc a donne sept roues et zero
   * pastille. C'est le critere du poincon ROUGE du coeur, « change depuis le
   * chargement », pas celui qu'on veut.
   *
   * SEUL LE MANIFESTE SAIT : `blocsinfo.php` le lit au montage du formulaire
   * et passe la table des defauts par `addScriptOptions`.
   *
   * LA PASTILLE N'EST PAS DECORATIVE, DONC ELLE EST ANNONCEE : le nombre entre
   * dans l'intitule du bouton, et un lecteur d'ecran lit « Reglages de la
   * ligne, 3 poses » au lieu de « Reglages de la ligne ».
   */
  /** La table des valeurs par defaut, lue une fois dans le manifeste. */
  function defauts() {
    if (window.Joomla && Joomla.getOptions) {
      return Joomla.getOptions('mod_opus.defauts', {});
    }

    return {};
  }

  function compterReglages(rangee) {
    var roue = rangee.querySelector(':scope > .opus-roue');

    if (!roue) { return; }

    var table = defauts();
    var poses = 0;

    [].slice.call(rangee.querySelectorAll('.blocs-reglage')).forEach(function (champ) {
      if (champ.closest('.subform-repeatable-group') !== rangee) { return; }

      /*
       * LE `blocs-reglage` PEUT ETRE LE CHAMP OU SON ENVELOPPE, selon le type :
       * le coeur pose la classe sur l'element rendu, qui est parfois un
       * `fieldset` de radios. On redescend donc au premier champ reel.
       */
      var reel = champ.matches('input, select, textarea') ? champ : champ.querySelector('input, select, textarea');

      if (!reel || !reel.name) { return; }

      var nom = (reel.name.match(/\[([^\[\]]+)\]$/) || [])[1] || '';

      if (!nom) { return; }

      /*
       * UNE CASE A COCHER N'A PAS DE VALEUR MAIS UN ETAT, et son defaut
       * s'ecrit `1` ou vide dans le manifeste.
       */
      var valeur = (reel.type === 'checkbox' || reel.type === 'radio')
        ? (reel.checked ? (reel.value || '1') : '')
        : String(reel.value);

      var defaut = String(table[nom] === undefined ? '' : table[nom]);

      if (valeur !== defaut) { poses += 1; }
    });

    roue.classList.toggle('blocs-roue--posee', poses > 0);

    if (poses > 0) {
      roue.dataset.poses = String(poses);
    } else {
      delete roue.dataset.poses;
    }

    var titre = texte('MOD_OPUS_SETTINGS_TITLE', 'Reglages de la ligne');

    if (poses > 0) {
      titre += ' (' + poses + ')';
    }

    roue.title = titre;
    roue.setAttribute('aria-label', titre);
  }

  function outilsADroite(rangee) {
    marquerLigneImage(rangee);
    compterReglages(rangee);
    suivreLePoids(rangee);

    var debut = null;

    [].slice.call(rangee.children).forEach(function (enfant) {
      enfant.classList.remove('blocs-outils-debut');

      // Une case masquee n a pas de boite : elle ne peut pas porter le vide.
      if (enfant.classList.contains('hidden') || enfant.hidden) { return; }

      /*
       * LE PICTOGRAMME TROUVE DOIT ETRE CELUI DE CETTE LIGNE.
       *
       * `querySelector` descend dans TOUT le sous-arbre, donc dans la pile
       * d elements de la carte : le premier « outil » rencontre etait la case
       * de la pile elle-meme, parce qu un de ses elements porte un
       * alignement. Le vide se posait donc devant la pile, qui est deja en
       * pleine largeur, et les pictogrammes de la carte ne bougeaient pas.
       *
       * C est le meme piege que partout ailleurs dans ce fichier, et c est la
       * sixieme fois qu il se referme : toute recherche depuis une ligne se
       * verifie par `closest('.subform-repeatable-group')`.
       */
      var picto = enfant.querySelector('.blocs-bascule, .blocs-pick');

      var estOutil = enfant.classList.contains('opus-roue')
        || enfant.classList.contains('blocs-copie')
        || (picto && picto.closest('.subform-repeatable-group') === rangee);

      if (estOutil && !debut) { debut = enfant; }
    });

    if (debut) { debut.classList.add('blocs-outils-debut'); }
  }

  /**
   * L'AIDE D'UN CHAMP PASSE DERRIERE UNE PASTILLE, COMME DANS UN EN-TETE.
   *
   * D'OU CELA VIENT : de l'ecran des styles de Corpus, ou chaque intitule de
   * colonne porte un petit cercle a sa droite et rend son texte au survol.
   * Regle de Cyrille du 21 septembre 2026 : « les i information sont a droite
   * des titres, et ouvrent une popup d'aide ».
   *
   * LE COEUR NE LE FAIT QUE DANS LES TABLEAUX. `repeatable-table.php` ecrit la
   * pastille dans ses `<th>` (l. 69) ; partout ailleurs, la description sort
   * en pave bleu sous le champ. Dans une liste de blocs, cela faisait six
   * paves pour une ligne de six champs : la saisie se perdait dedans.
   *
   * IL N'Y A RIEN A CHARGER POUR QUE CELA S'OUVRE. Atum s'en charge en une
   * regle, `template.css` l. 14863 : `:focus + [role="tooltip"], :hover +
   * [role="tooltip"] { display: block }`. Le balisage suffit donc, et c'est
   * pour cela qu'on ecrit EXACTEMENT celui du coeur : une pastille, puis sa
   * bulle en voisine immediate.
   *
   * LE PAVE N'EST PAS SUPPRIME, IL EST MASQUE. Le panneau de la roue lit
   * `.form-text` pour legender ses miroirs : le retirer laissait le panneau
   * muet. Masque, il reste lisible par `querySelector` et invisible a l'oeil.
   *
   * UNE COLONNE D'ICONES N'A PAS DE TITRE, donc pas de pastille : son intitule
   * est un `legend` masque, et une pastille posee la n'aurait rien a cote de
   * quoi se mettre.
   */
  function pastiller(portee) {
    [].slice.call(portee.querySelectorAll('.control-group')).forEach(function (groupe) {
      if (groupe.dataset.opusPastille) { return; }

      /*
       * LE PREMIER PAVE TROUVE N'EST PAS FORCEMENT LE SIEN. Dans la case qui
       * porte une liste imbriquee, les paves des lignes filles viennent avant
       * le sien dans le document : un `querySelector` simple rendait celui
       * d'une carte, et la case gardait son pave bleu pour toujours.
       */
      var boite = [].slice.call(
        groupe.querySelectorAll('.controls .form-text, .controls .field-description')
      ).filter(function (b) {
        return b.closest('.control-group') === groupe;
      })[0];

      if (!boite) { return; }

      groupe.dataset.opusPastille = '1';

      var aide = boite.textContent.trim();

      if (aide === '') { return; }

      // Le pave et son enveloppe, quand elle ne porte que lui.
      var cache = boite;

      if (cache.parentElement
        && cache.parentElement.children.length === 1
        && cache.parentElement.className === '') {
        cache = cache.parentElement;
      }

      cache.hidden = true;

      var etiquette = groupe.querySelector('.control-label label, .control-label legend');

      if (!etiquette || etiquette.classList.contains('visually-hidden')) { return; }

      var pastille = document.createElement('span');
      pastille.className = 'icon-info-circle';
      pastille.setAttribute('aria-hidden', 'true');
      pastille.setAttribute('tabindex', '0');

      var bulle = document.createElement('div');
      bulle.setAttribute('role', 'tooltip');
      bulle.textContent = aide;

      etiquette.appendChild(pastille);
      etiquette.appendChild(bulle);
    });
  }

  /**
   * UN INTITULE QUI NE TIENT PAS DEVIENT UNE INDICATION DANS LE CHAMP.
   *
   * Le champ image d'une cellule de tableau est un sous-formulaire a trois
   * etages, chacun avec son intitule sur sa propre ligne : 31 px chaque fois,
   * pour redire ce que l'en-tete de colonne dit deja. La feuille les retire ;
   * cette passe en sauve le texte, qui devient l'indication du champ.
   *
   * ON N'ECRASE JAMAIS UNE INDICATION EXISTANTE : le manifeste peut en poser
   * une, et elle est plus precise que l'intitule.
   */
  function indications(portee) {
    [].slice.call(portee.querySelectorAll('td .subform-wrapper > .control-group'))
      .forEach(function (groupe) {
        var etiquette = groupe.querySelector('.control-label label');
        var champ = groupe.querySelector('input.form-control, input[type="text"], textarea');

        if (!etiquette || !champ || champ.type === 'checkbox') { return; }

        if (champ.getAttribute('placeholder')) { return; }

        champ.setAttribute('placeholder', etiquette.textContent.trim());
      });
  }

  /**
   * LA LARGEUR SE PARTAGE ENTRE LES COLONNES DE TEXTE, ET ENTRE ELLES SEULES.
   *
   * Le coeur ecrit `width: 92/n %` sur chaque en-tete, puis un tableau en
   * `table-layout: auto` distribue tout le reste au prorata : les colonnes a
   * icone, qui n'ont rien a montrer, en recevaient autant que les autres. Sur
   * le banc, l'oeil de la rangee flottait a 180 px de son voisin.
   *
   * On donne donc aux colonnes de texte des parts qui font 100 % a elles
   * seules. Il ne reste rien a distribuer, et les colonnes a icone retombent
   * sur la largeur qu'on leur declare.
   *
   * LA CELLULE DES COMMANDES GARDE LA SIENNE : trois boutons cote a cote, et
   * elle n'est pas un `th`, donc elle n'entre dans aucun des deux partages.
   */
  function repartirLargeurs(tableau) {
    var premiere = tableau.querySelector('thead tr');

    if (!premiere) { return; }

    var visibles = [].slice.call(premiere.children).filter(function (c) {
      return !c.hidden;
    });

    var etroites = visibles.filter(function (c) {
      return c.tagName !== 'TH' || c.dataset.opusMuette || c.dataset.opusRoueTete;
    });

    var larges = visibles.filter(function (c) { return etroites.indexOf(c) < 0; });

    if (larges.length === 0) { return; }

    var icones = etroites.filter(function (c) { return c.tagName === 'TH'; }).length;
    var commandes = etroites.filter(function (c) { return c.tagName === 'TD'; }).length;

    /*
     * `calc`, ET NON UN SIMPLE `100 / n`. Des parts qui font 100 % a elles
     * seules s'ajoutent aux largeurs fixes des icones : le tableau depassait
     * alors son cadre par la droite. On retire d'abord ce qui est fixe.
     */
    var fixe = '(' + icones + ' * ' + LARGEUR_ICONE + ' + ' + commandes + ' * ' + LARGEUR_OUTILS + ')';
    var part = 'calc((100% - ' + fixe + ') / ' + larges.length + ')';

    larges.forEach(function (c) { c.style.width = part; });

    etroites.forEach(function (c) {
      c.style.width = c.tagName === 'TD' ? LARGEUR_OUTILS : LARGEUR_ICONE;
    });
  }

  /** La derniere passe sur les tableaux, une fois les pictogrammes poses. */
  function taireLesEntetes() {
    var fs = document.getElementById(FIELDSET);

    if (!fs) { return; }

    [].slice.call(fs.querySelectorAll('joomla-field-subform table')).forEach(function (tbl) {
      entetesMuettes(tbl);
      colonnesEtroites(tbl);
      repartirLargeurs(tbl);
      plusDeTete(tbl);
    });

    indications(fs);
  }

  /**
   * LE CHEVRON D'UNE LISTE IMBRIQUEE, A GAUCHE DE SON INTITULE.
   *
   * Demande de Cyrille du 22 septembre 2026, en deux temps. D'abord :
   * « sous elements remplace le + par le chevron pour ouvrir ou replier tous
   * les elements ». Puis, l'ayant vu : « cela ne replie pas tous les elements,
   * il ne doit me rester qu'une ligne, et il me faut le bouton a gauche du
   * titre Elements, au meme format que Les rangees ou Les blocs ».
   *
   * PREMIERE VERSION FAUSSE, ET LA RAISON EST INSTRUCTIVE. Elle posait le
   * chevron dans la barre du `+` et pliait chaque ligne avec `opus-replie`,
   * qui ne masque que les champs SUIVANT le premier : douze elements plies
   * laissaient douze lignes a l'ecran. Plier une liste et plier une ligne ne
   * sont pas le meme geste.
   *
   * ICI, PLIER C'EST MASQUER LA LISTE ENTIERE et ne garder que l'intitule,
   * exactement ce que fait le chevron d'une section sur ses freres.
   *
   * LE BOUTON EST POSE AVANT LE `<label>`, PAS DEDANS. Un bouton dans un
   * `label` ferait du clic sur le chevron un clic sur le champ.
   *
   * LE GARDE EST SUR LA CASE, PAS SUR LA LISTE : la liste dure, la case est ce
   * qu'on transforme.
   */
  function chevronDeListe(sousForm) {
    var case_ = sousForm.closest('.control-group');

    if (!case_ || case_.dataset.opusPli) { return; }

    var intitule = case_.querySelector(':scope > .control-label');

    if (!intitule) { return; }

    case_.dataset.opusPli = '1';
    case_.classList.add('blocs-liste');

    if (!sousForm.id) {
      sousForm.id = 'blocs-liste-' + (++chevronDeListe.compteur);
    }

    var bouton = document.createElement('button');
    bouton.type = 'button';
    bouton.className = 'blocs-chevron';
    bouton.setAttribute('aria-expanded', 'true');
    bouton.setAttribute('aria-controls', sousForm.id);

    var titre = texte('MOD_OPUS_FOLD_ALL', 'Plier ou deplier tous les elements');
    bouton.title = titre;
    bouton.setAttribute('aria-label', titre);

    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');

    var trait = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    trait.setAttribute('d', 'M6 9l6 6 6-6');
    svg.appendChild(trait);
    bouton.appendChild(svg);

    bouton.addEventListener('click', function () {
      var ferme = bouton.getAttribute('aria-expanded') === 'true';

      bouton.setAttribute('aria-expanded', ferme ? 'false' : 'true');
      case_.classList.toggle('blocs-liste--replie', ferme);
    });

    intitule.insertBefore(bouton, intitule.firstChild);
  }

  chevronDeListe.compteur = 0;

  /**
   * LE NOM DE LA CARTE RESTE DANS SON CADRE, COMME « Cartes » ET « Les boutons ».
   *
   * Deux essais avant de trouver. Le premier laissait deux cadres embollites,
   * la ligne de la carte puis sa pile titree : « un niveau de trop », et
   * c etait vrai a l oeil. J ai alors fait remonter le nom sur la barre de
   * commandes, et Cyrille a tranche autrement, capture a l appui,
   * 22 septembre 2026 : « deplace les titres des cartes dans le bloc qui les
   * concerne, avec le bouton pour le replier, comme le bloc Cartes ».
   *
   * LA REGLE EST CELLE DE TOUT L ECRAN, et elle etait deja ecrite ailleurs :
   * une boite porte son nom EN DEDANS, en haut a gauche, avec son chevron.
   * « Les rangees », « Les blocs », « Cartes », « Les boutons » : le nom d une
   * carte ne fait pas exception. La barre au-dessus garde les commandes.
   *
   * Cette fonction ne deplace donc plus rien : elle rend l intitule la ou le
   * coeur l a pose, pour que la numerotation ecrive dedans.
   */
  function teteDeCarte(carte) {
    var pile = hoteListe(carte, 'elements');

    if (!pile) { return null; }

    var case_ = pile.closest('.control-group');

    return case_ ? case_.querySelector(':scope > .control-label') : null;
  }

  /**
   * DUPLIQUER UNE CARTE, AVEC TOUT CE QU ELLE CONTIENT.
   *
   * « Il me faut un bouton pour simplement dupliquer une carte, par experience
   * on duplique souvent une carte », Cyrille, 22 septembre 2026.
   *
   * LE COEUR NE SAIT PAS LE FAIRE. Son `+` ajoute une ligne VIDE, prise dans le
   * gabarit ; il n existe aucun bouton de copie dans `joomla-field-subform`,
   * relu avant d ecrire. Copier le balisage a la main ne marcherait pas non
   * plus : les noms des champs portent le rang de la ligne, et deux lignes de
   * meme nom s ecrasent a l enregistrement.
   *
   * ON FABRIQUE LA LIGNE PAR LE `+` DE LA SOURCE, donc juste apres elle et
   * numerotee par le coeur, PUIS on recopie les valeurs. En deux temps : la
   * forme d abord, autant de lignes filles que la source en a, a toute
   * profondeur ; les valeurs ensuite, champ par champ, dans l ordre du
   * document. Les deux arbres etant alors identiques, l ordre suffit et aucun
   * nom n est a reconstruire.
   */
  function dupliquerCarte(carte) {
    /*
     * ON CLIQUE LE `+` DE LA CARTE, ET RIEN DE PLUS.
     *
     * La copie existe deja : un ecouteur retient la ligne dont le `+` a ete
     * clique, et `dupliquerLigne` recopie ses champs et ses listes filles
     * dans la ligne neuve. Ce bouton ne refait donc pas le travail, il le
     * NOMME : un plus qui duplique ne se devine pas, un dessin de deux
     * feuilles si.
     */
    var plus = carte.querySelector(':scope > .btn-toolbar .group-add');

    if (plus) { plus.click(); }
  }

  /**
   * LE BOUTON DE COPIE, A COTE DU PLUS ET DU MOINS.
   *
   * IL VA DANS LA BARRE DU COEUR ET NON A DROITE : c est une commande de
   * ligne, comme ajouter, retirer et deplacer, et non un reglage. Les quatre
   * se lisent ensemble, dans l ordre ou l on s en sert.
   */
  function boutonCopie(carte) {
    if (carte.querySelector(':scope > .blocs-copie')) { return; }

    var barre = carte.querySelector(':scope > .btn-toolbar');

    if (!barre) { return; }
    var titre = texte('MOD_OPUS_CARD_COPY', 'Dupliquer cette carte');

    var bouton = document.createElement('button');
    bouton.type = 'button';
    bouton.className = 'btn btn-sm blocs-copie';
    bouton.title = titre;
    bouton.setAttribute('aria-label', titre);

    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');

    // Deux feuilles decalees : le dessin de la copie, partout le meme.
    var fond = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    fond.setAttribute('x', '9');
    fond.setAttribute('y', '9');
    fond.setAttribute('width', '11');
    fond.setAttribute('height', '11');
    fond.setAttribute('rx', '2');
    svg.appendChild(fond);

    var dessus = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    dessus.setAttribute('d', 'M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1');
    svg.appendChild(dessus);

    bouton.appendChild(svg);
    bouton.addEventListener('click', function () { dupliquerCarte(carte); });

    /*
     * IL OUVRE LE GROUPE DE DROITE : copie, alignement, oeil, roue.
     *
     * « Deplace le bouton dupliquer en premier des quatre et aligne-les »,
     * Cyrille, 22 septembre 2026. Il etait entre l oeil et la roue, glisse la
     * par son `order` : on le pose maintenant DANS LE DOCUMENT devant la
     * premiere case d outil, et il n a plus besoin d ordre a lui. Quatre
     * pictogrammes de meme taille, au meme pas, dans l ordre ou on les lit.
     *
     * LE REPERE EST LE PREMIER OUTIL DE CETTE LIGNE, verifie par `closest` :
     * sans cela on viserait un pictogramme de la pile d elements, qui est un
     * descendant comme un autre pour `querySelector`.
     */
    var repere = [].slice.call(carte.children).filter(function (enfant) {
      var picto = enfant.querySelector && enfant.querySelector('.blocs-bascule, .blocs-pick');

      return picto && picto.closest('.subform-repeatable-group') === carte;
    })[0];

    carte.insertBefore(bouton, repere || carte.querySelector(':scope > .opus-roue'));
  }

  /**
   * CHAQUE CARTE PORTE SON RANG, ET SA PILE PORTE SON NOM.
   *
   * Une carte n a plus de champ sur sa ligne : tout est derriere la roue, et
   * la ligne ne disait donc plus rien. Trois cadres identiques empiles, on ne
   * sait plus lequel on remplit. L intitule de la pile, « Elements », devient
   * « Carte 1 », « Carte 2 » : c est le seul endroit ou le rang se lit, et il
   * est deja au bon endroit, en tete du cadre.
   *
   * LE RANG SE RECALCULE A CHAQUE FOIS, jamais au moment de la pose : retirer
   * la carte 2 fait de la 3 une 2, et un numero fige mentirait des le premier
   * retrait comme des le premier deplacement.
   */
  /**
   * LE TYPE DU BLOC QUI PORTE CETTE LISTE.
   *
   * PIEGE N. 1 DU DOSSIER, ENCORE : une ligne de bloc contient les champs
   * `type` de ses elements, qui portent le meme nom et viennent avant dans le
   * document. `querySelector` depuis la ligne rendrait donc le type d'un
   * element. On ne garde que le champ QUI EST A NOUS, verifie par `closest`.
   */
  function typeDuBloc(liste) {
    var ligne = liste.closest ? liste.closest('.subform-repeatable-group') : null;

    if (!ligne) { return 'cartes'; }

    var champ = [].slice.call(ligne.querySelectorAll('[name$="[type]"]'))
      .filter(function (c) { return c.closest('.subform-repeatable-group') === ligne; })[0];

    return champ ? champ.value : 'cartes';
  }

  /**
   * LE MOT QUI NOMME UNE LIGNE DE CETTE LISTE.
   *
   * La meme liste sert trois formes, et elle ne porte pas le meme nom dans les
   * trois : on remplit des cartes, des images ou des diapositives. « Carte 1 »
   * au-dessus d'une image de galerie serait un mot faux a l'endroit exact ou
   * l'on cherche a savoir ce que l'on remplit.
   */
  function motDeLigne(type) {
    if (type === 'galerie') { return texte('MOD_OPUS_ITEM_IMAGE', 'Image'); }
    if (type === 'carrousel') { return texte('MOD_OPUS_ITEM_SLIDE', 'Diapositive'); }
    if (type === 'onglets') { return texte('MOD_OPUS_TAB_N', 'Onglet'); }
    if (type === 'frise') { return texte('MOD_OPUS_STEP_N', 'Etape'); }

    return texte('MOD_OPUS_CARD_N', 'Carte');
  }

  /**
   * LE NOM DU CADRE SUIT LE TYPE DU BLOC, LUI AUSSI.
   *
   * « Dans le bloc Carrousel, tu as gardé le nom de bloc Cartes », Cyrille,
   * 23 septembre 2026. Exact : les LIGNES avaient ete renommees le matin meme,
   * le CADRE qui les contient non. Un cadre « Cartes » qui contient des
   * « Diapositive 1, 2, 3 » se contredit a deux lignes d'ecart.
   *
   * L'intitule vient du `label` du champ dans le manifeste, et un manifeste ne
   * sait pas dire « selon le type choisi » : c'est donc ici, au meme endroit et
   * au meme rythme que les rangs.
   */
  function motDeListe(type) {
    if (type === 'galerie') { return texte('MOD_OPUS_LIST_IMAGES', 'Images'); }
    if (type === 'carrousel') { return texte('MOD_OPUS_LIST_SLIDES', 'Diapositives'); }
    if (type === 'onglets') { return texte('MOD_OPUS_TABS_LABEL', 'Les onglets'); }
    if (type === 'frise') { return texte('MOD_OPUS_STEPS_LABEL', 'Les etapes'); }

    return texte('MOD_OPUS_CARDS_LABEL', 'Cartes');
  }

  /**
   * Reecrit UN noeud de texte, celui qui porte le mot, et rien d'autre.
   *
   * Meme precaution que pour les rangs : l'intitule contient aussi le chevron
   * que nous avons pose et la pastille d'aide. Ecrire `textContent` les
   * emporterait tous les deux.
   */
  function renommer(porteur, mot) {
    if (!porteur) { return; }

    [].slice.call(porteur.childNodes).forEach(function (noeud) {
      if (noeud.nodeType === 3 && noeud.textContent.trim() !== '') {
        noeud.textContent = mot;
      }
    });
  }

  function numeroterCartes() {
    var listes = [].slice.call(document.querySelectorAll('joomla-field-subform'))
      /*
       * LES DEUX LISTES DE CONTENANTS, 24 septembre 2026. Le bloc Onglets est
       * arrive avec sa propre liste, `[onglets]`, et la numerotation ne visait
       * que `[cartes]` : les onglets sortaient sans rang ni bouton de copie.
       */
      .filter(function (sf) { return /\[(cartes|onglets|etapes)\]$/.test(sf.getAttribute('name') || ''); });

    listes.forEach(function (liste) {
      var type       = typeDuBloc(liste);
      var nomDeLigne = motDeLigne(type);

      /*
       * LE CADRE DE LA LISTE PORTE LE NOM DE CE QU'IL CONTIENT. On vise le
       * `label` du groupe qui HEBERGE la liste, jamais le premier trouve : une
       * liste de blocs contient les cadres de ses cartes, qui portent le meme
       * balisage.
       */
      var groupe = liste.closest('.control-group');

      if (groupe) {
        renommer(groupe.querySelector(':scope > .control-label label'), motDeListe(type));
      }

      rangeesDe(liste).forEach(function (carte, i) {
        // La tete remonte dans la ligne de la carte, puis porte son rang.
        var intitule = teteDeCarte(carte);

        if (!intitule) { return; }

        boutonCopie(carte);

        var mot = nomDeLigne + ' ' + (i + 1);

        /*
         * ON NE REECRIT QU UN NOEUD DE TEXTE, ET C EST MESURE.
         *
         * L intitule d une liste contient, dans l ordre : le chevron que nous
         * avons pose, puis un `label` dont le premier enfant est le mot, suivi
         * de la pastille d aide et de son infobulle. Ecrire `textContent` sur
         * l un ou l autre emporte donc le chevron ou la pastille : le
         * pictogramme d aide a disparu au premier essai, sur le banc.
         */
        var porteur = intitule.querySelector('label') || intitule;

        [].slice.call(porteur.childNodes).forEach(function (noeud) {
          if (noeud.nodeType === 3 && noeud.textContent.trim() !== '') {
            noeud.textContent = mot;
          }
        });
      });
    });
  }

  /**
   * LA PASTILLE DE MODIFICATION QUAND UNE LIGNE CHANGE DE PLACE.
   *
   * « Quand je deplace un element ou un bouton, je n'ai pas mon point rouge »,
   * Cyrille, 22 septembre 2026. Exact, et la raison est mecanique :
   * `legend.js` de Corpus pose `modified` sur un champ dont la VALEUR change.
   * Deplacer une ligne ne change aucune valeur, il change leur ORDRE, et
   * l'ordre est pourtant ce qui sortira sur la page.
   *
   * ON OBSERVE LE DOM, FAUTE D'EVENEMENT. Le composant du coeur emet
   * `subform-row-add` et `subform-row-remove`, relus dans sa source : il
   * n'emet rien pour un deplacement. Un observateur de mutations sur la liste
   * voit les lignes changer de rang, et c'est la seule facon de le savoir.
   *
   * LA PASTILLE VA SUR LE PREMIER CHAMP DE LA LIGNE, celui qui la nomme :
   * Element, Bloc, Libelle. C'est deja lui qu'on lit pour reconnaitre une
   * ligne, et le dessin de la pastille existe pour ce cas-la.
   */
  function surveillerOrdre(sousForm) {
    if (sousForm.dataset.opusOrdre) { return; }

    sousForm.dataset.opusOrdre = '1';

    var rangs = rangeesDe(sousForm);

    var observateur = new MutationObserver(function () {
      var neufs = rangeesDe(sousForm);

      // Un ajout ou un retrait n'est pas un deplacement : le compte change.
      if (neufs.length !== rangs.length) {
        rangs = neufs;

        return;
      }

      neufs.forEach(function (ligne, i) {
        if (rangs[i] === ligne) { return; }

        var premier = [].slice.call(ligne.children).filter(function (c) {
          return c.classList.contains('control-group') && !c.classList.contains('hidden');
        })[0];

        if (premier) { premier.classList.add('modified'); }
      });

      rangs = neufs;
    });

    observateur.observe(sousForm, { childList: true, subtree: true });
  }

  /**
   * LE `+` DE LA LISTE DES BLOCS OUVRE UN CHOIX, ET C'EST LA QU'ON COMPILE.
   *
   * Decision de Cyrille, 22 septembre 2026 : « quand on clique sur le + des
   * blocs, c'est la que l'on compile avec un autre montage qui serait par
   * exemple Cartes ». La vignette bascule, le `+` ajoute : deux gestes, deux
   * endroits, et plus aucun des deux ne fait le travail de l'autre en silence.
   *
   * « BLOC VIDE » RESTE EN TETE, et ce n'est pas une politesse : c'etait le
   * seul geste du `+` jusqu'ici, et le supprimer aurait rendu impossible
   * l'ajout d'un bloc qu'on remplit soi-meme.
   *
   * UN MENU, PAS UNE MODALE. On ajoute une ligne, on ne detruit rien :
   * interrompre l'ecran entier serait hors de proportion. Echap le ferme et
   * rend le focus au `+`, comme le panneau des reglages.
   */
  function menuAjout(bouton) {
    if (document.querySelector('.blocs-ajout')) {
      document.querySelector('.blocs-ajout').remove();

      return;
    }

    var menu = document.createElement('div');
    menu.className = 'blocs-ajout';
    menu.setAttribute('role', 'menu');

    var fermer = function (rendre) {
      menu.remove();

      if (rendre) { bouton.focus(); }
    };

    var entree = function (libelle, action) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'blocs-ajout__choix';
      b.setAttribute('role', 'menuitem');
      b.textContent = libelle;
      b.addEventListener('click', function () {
        fermer(true);
        action();
      });
      menu.appendChild(b);
    };

    entree(texte('MOD_OPUS_ADD_EMPTY', 'Bloc vide'), function () {
      bouton.dataset.opusDirect = '1';
      bouton.click();
      delete bouton.dataset.opusDirect;
    });

    catalogue().forEach(function (item) {
      if (!item.cle) { return; }

      entree(item.nom, function () { appliquerModele(item.cle); });
    });

    /*
     * LES BRIQUES SE RETROUVENT ICI AUSSI, ET C'ETAIT LA DEMANDE : « il faut
     * que je puisse les retrouver quand je cree les blocs ». Le panneau sert a
     * partir d'une page vide, le `+` a completer une page commencee : la meme
     * liste doit etre a portee des deux.
     *
     * UN INTITULE LES SEPARE, il n'est pas cliquable et n'est pas un
     * `menuitem` : un lecteur d'ecran annonce alors un groupe, pas une entree
     * morte.
     */
    var famille = document.createElement('p');
    famille.className = 'blocs-ajout__famille';
    famille.textContent = texte('MOD_OPUS_BRICKS_TITLE', 'Ou un seul element');
    menu.appendChild(famille);

    briques().forEach(function (item) {
      entree(item.nom, function () { appliquerModele(item.cle); });
    });

    menu.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') { fermer(true); }
    });

    var pose = bouton.getBoundingClientRect();
    menu.style.top = (pose.bottom + window.scrollY + 4) + 'px';
    menu.style.left = (pose.left + window.scrollX) + 'px';

    document.body.appendChild(menu);
    menu.querySelector('button').focus();

    /*
     * UN CLIC AILLEURS FERME, SANS RENDRE LE FOCUS : il est deja parti ou
     * l'utilisateur l'a envoye.
     */
    window.setTimeout(function () {
      document.addEventListener('click', function ailleurs(ev) {
        if (menu.contains(ev.target)) { return; }

        document.removeEventListener('click', ailleurs);
        fermer(false);
      });
    }, 0);
  }

  /** Branche le menu sur les `+` de la liste des blocs, et sur eux seuls. */
  function ajoutParModele(hoteBlocs) {
    if (!hoteBlocs || hoteBlocs.dataset.opusAjout) { return; }

    hoteBlocs.dataset.opusAjout = '1';

    hoteBlocs.addEventListener('click', function (ev) {
      var plus = ev.target.closest ? ev.target.closest('.group-add') : null;

      if (!plus || plus.dataset.opusDirect) { return; }

      // Le `+` d'une liste imbriquee ajoute un element, pas un bloc.
      if (plus.closest('joomla-field-subform') !== hoteBlocs) { return; }

      ev.preventDefault();
      ev.stopPropagation();

      menuAjout(plus);
    }, true);
  }

  /**
   * LES PASTILLES D'AIDE SE LISENT AU LECTEUR D'ECRAN, 25 septembre 2026.
   *
   * Mesure faite ce jour-la dans l'onglet Mise en page : 36 pastilles ⓘ
   * atteignables a la tabulation, et AUCUNE ne porte de nom. Le coeur les
   * ecrit ainsi (`repeatable-table.php` l. 69) : `tabindex="0"` ET
   * `aria-hidden="true"` sur le meme element. Le clavier s'y arrete, le
   * lecteur d'ecran n'y lit rien : un arret muet a chaque colonne. Nos propres
   * pastilles, copiees sur ce modele, avaient le meme defaut.
   *
   * ON NE DEPLACE RIEN ET ON NE RECODE PAS L'INFOBULLE : elle reste celle de
   * Joomla, qui s'affiche au focus par la seule feuille d'Atum. On ne fait que
   * nommer : `role="img"` et « Aide » pour la pastille, `aria-describedby` vers
   * la bulle, qui est deja sa voisine. Une bulle masquee se lit quand meme en
   * description : c'est ce que prevoit le calcul du nom accessible.
   *
   * Idempotente : une pastille deja traitee porte `data-opus-aide`.
   */
  aideLisible.compteur = 0;

  function aideLisible(racine) {
    if (!racine) { return; }

    [].slice.call(racine.querySelectorAll('.icon-info-circle[tabindex]:not([data-opus-aide])'))
      .forEach(function (pastille) {
        var bulle = pastille.nextElementSibling;

        if (!bulle || bulle.getAttribute('role') !== 'tooltip') { return; }

        if (!bulle.id) {
          aideLisible.compteur += 1;
          bulle.id = 'opus-aide-' + aideLisible.compteur;
        }

        pastille.dataset.opusAide = '1';
        pastille.removeAttribute('aria-hidden');
        pastille.setAttribute('role', 'img');
        pastille.setAttribute('aria-label', texte('JHELP', 'Aide'));
        pastille.setAttribute('aria-describedby', bulle.id);
      });
  }

  function outillerTout() {
    var fs = document.getElementById(FIELDSET);
    if (!fs) { return; }

    // Trois classes posees sur ce qui existe : ni deplacement, ni mesure.
    marquerSections();

    ajoutParModele(document.querySelector('joomla-field-subform[name="jform[params][blocs]"]'));

    // Les alignements hors sous-formulaire, comme celui de la rangee.
    iconiser(fs);

    // L'aide passe derriere sa pastille avant tout le reste : une ligne
    // debarrassee de ses paves bleus tient sur une ligne, et les mesures de
    // largeur qui suivent portent alors sur la vraie ligne.
    pastiller(fs);

    /*
     * L'ONGLET ICONES RECOIT LES MEMES PASTILLES - 25 septembre 2026.
     *
     * « Utilise les i a droite des titres comme tout Opus le fait. » Cyrille.
     * `outillerTout` ne regardait que l'onglet Mise en page, et les trois
     * champs de l'onglet Icones gardaient leur pave bleu sous l'intitule, a la
     * mode de Joomla.
     *
     * LA PASSE EST LA MEME, appelee sur une autre portee : ecrire une seconde
     * mecanique pour trois champs les aurait fait diverger au premier
     * changement. `pastiller` marque ce qu'il a deja traite, il peut donc etre
     * rappele sans risque quand une ligne s'ajoute.
     */
    var fsIcones = document.getElementById('fieldset-icones');

    if (fsIcones) { pastiller(fsIcones); }

    /*
     * L'ORDRE DE CES TROIS PASSES COMPTE.
     *
     * Les commandes passent devant, puis les colonnes de la roue se cachent
     * (la roue a besoin de sa cellule), puis l'habillage pose les pictogrammes,
     * et seulement ensuite les en-tetes d'icones se taisent : c'est aux
     * pictogrammes qu'on reconnait une colonne d'icones.
     */
    [].slice.call(fs.querySelectorAll('joomla-field-subform table')).forEach(function (tbl) {
      outilsEnTete(tbl);
      masquerColonnes(tbl);
      tetesVides(tbl);
    });

    [].slice.call(fs.querySelectorAll('joomla-field-subform')).forEach(function (sf) {
      [].slice.call(sf.querySelectorAll('.subform-repeatable-group')).forEach(function (rangee) {
        outils(rangee);
      });

      /*
       * LE NOM DU CHAMP, JAMAIS SON INTITULE : un `name` ne se traduit pas.
       * Seules les listes posees DANS une ligne de bloc recoivent le chevron ;
       * la liste des blocs, elle, garde son `+`.
       */
      if (/\[(elements|boutons|cartes)\]$/.test(sf.getAttribute('name') || '')) {
        chevronDeListe(sf);
      }

      if (/\[elements\]$/.test(sf.getAttribute('name') || '')) {
        marquerRepetitions(sf);
      }

      surveillerOrdre(sf);
    });

    taireLesEntetes();
    numeroterCartes();

    // Les pastilles d'aide, celles du coeur comme les notres, deviennent
    // lisibles au lecteur d'ecran. Voir `aideLisible`.
    aideLisible(document.getElementById('module-form'));
  }

  /**
   * Cree le conteneur de la carte, une seule fois.
   *
   * IL EST ENFANT DIRECT DU FIELDSET, ET CE N'EST PAS INDIFFERENT. La grille
   * du vis-a-vis est posee sur `fieldset.options-form`, et une grille ne place
   * que ses enfants DIRECTS. Un niveau de plus, et la carte retombe dans le
   * flux de la colonne des reglages.
   *
   * Son identifiant suffit : le dessin recopie de `gabarits.css` pose
   * `#blocs-carte` en colonne 2, collant, avec une hauteur plafonnee. Ce qu'il
   * contient reste notre affaire.
   */
  /* ==========================================================================
     LES MODELES DE DEPART

     D'OU CELA VIENT : de `maquette-module-corpus_3.html`, ou le panneau
     s'appelle « Choisir une mise en page » et ou chaque vignette est une
     GRILLE CSS de petits blocs, pas une image. On reprend sa geometrie a
     l'identique (l. 119 a 130 de la maquette) : rien a dessiner, rien a
     charger, et une vignette qui suit le theme clair ou sombre toute seule.

     CE QUE CE N'EST PLUS. Dans la maquette c'etait un choix EXCLUSIF : une
     mise en page, et les champs suivaient par `showon`. Le module ne marche
     plus ainsi depuis le modele rangees + blocs. Ces boutons sont donc des
     TAMPONS, au sens de TinyMCE : un clic pose une rangee, ses blocs et des
     textes d'exemple, puis on modifie. Rien n'est efface, on ajoute a la
     suite : un tampon qui remplace la saisie serait un tampon qu'on n'ose
     plus cliquer.
     ========================================================================== */

  /** Le contenu d'exemple d'un modele, traduit au moment du clic. */
  function exemple(cle, defaut) {
    return texte('MOD_OPUS_SAMPLE_' + cle, defaut);
  }

  /**
   * LA DESCRIPTION D'UN MODELE.
   *
   * L'ORDRE DES CLEFS COMPTE : `type` passe en premier, et ce n'est pas une
   * coquetterie. Les listes de contenu sont derriere un `showon` sur le type
   * du bloc ; remplir le type en dernier posait les cartes dans une liste
   * encore masquee, que le coeur ne renumerotait pas.
   */
  function modeles() {
    return {
      /*
       * L'OUVERTURE EST LE TAMPON « HERO - TITRE ET DEUX BOUTONS » DE CORPUS,
       * CHAMP POUR CHAMP.
       *
       * Demande de Cyrille, 22 septembre 2026 : « retrouve le tampon dans
       * Corpus qui correspond a cela et remplis les champs comme si c'etait
       * pour le tampon ». Un clic sur la vignette doit donner ce qu'un
       * redacteur obtient en posant ce tampon dans TinyMCE, sinon le module et
       * l'editeur racontent deux histoires differentes.
       *
       * Relu dans `corpus/html/tinymce/Hero - Titre et deux boutons.html` : un
       * `h1`, un paragraphe `lead`, deux boutons cote a cote dont le second en
       * format secondaire, et une precision courte en dessous. Pas d'image,
       * c'est ce qui distingue ce heros des autres ; pas de separateur non
       * plus, le filet vient de la balise du titre.
       */
      ouverture: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [
            { type: 'heading', label: exemple('TITLE', 'Le titre qui porte la promesse') },
            { type: 'subheading', label: exemple('LEAD', 'Une phrase, deux au plus, qui disent a qui s\'adresse la page et ce qu\'on peut y faire.') },
            {
              type: 'buttons',
              boutons: [
                { text: exemple('BUTTON', 'Action principale') },
                { text: exemple('BUTTON2', 'Action secondaire'), variant: 'second' }
              ]
            },
            { type: 'text', body: exemple('NOTE', 'Une precision courte sous les boutons : prix, duree, ou condition. Retirez cette ligne si vous n\'en avez pas.') }
          ]
        }]
      },

      /*
       * LE REFERENTIEL DES CARTES, COMME UN TAMPON DE CORPUS.
       *
       * Demande de Cyrille, 23 septembre 2026 : « cree-toi un referentiel de
       * trois cartes, comme nous avons dans les tampons de Corpus ».
       *
       * IL POSE UNE VRAIE IMAGE, celle que les tampons emploient deja :
       * `emplacement-16x9.svg`, livree avec le template. Un modele qui laisse
       * la zone d image vide ne montre pas ce qu il fait ; celui-ci sort une
       * rangee de trois cartes qui se tiennent des le premier clic, et il ne
       * reste qu a remplacer les images.
       *
       * LA CASE « image decorative » EST COCHEE : un emplacement gris ne
       * decrit rien, et un texte de remplacement invente serait pire que pas
       * de texte du tout. Elle se decoche en posant la vraie image.
       *
       * TROIS, PARCE QU UNE RANGEE DE CARTES SE LIT PAR TROIS. Deux font une
       * comparaison, quatre une liste ; trois, c est une offre. C est aussi
       * ce que font « Grille - 3 colonnes » et « Grille - Cartes avec etat ».
       */
      cartes: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'cartes', colonne: 'p' },
          liste: 'cartes',
          contenu: [
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-16x9.svg',
                  alt_empty: '1',
                  imgPose: 'banniere',
                  imgFormat: '16-9'
                },
                { type: 'heading', label: exemple('CARD1_TITLE', 'Premiere carte') },
                { type: 'text', body: exemple('CARD1_TEXT', 'Une ou deux phrases qui disent de quoi il s\'agit.') }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-16x9.svg',
                  alt_empty: '1',
                  imgPose: 'banniere',
                  imgFormat: '16-9'
                },
                { type: 'heading', label: exemple('CARD2_TITLE', 'Deuxieme carte') },
                { type: 'text', body: exemple('CARD2_TEXT', 'Une ou deux phrases, de la meme longueur que la premiere.') }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-16x9.svg',
                  alt_empty: '1',
                  imgPose: 'banniere',
                  imgFormat: '16-9'
                },
                { type: 'heading', label: exemple('CARD3_TITLE', 'Troisieme carte') },
                { type: 'text', body: exemple('CARD3_TEXT', 'Et une troisieme, pour que la rangee soit pleine.') }
              ]
            }
          ]
        }]
      },

      /*
       * LA GALERIE : SIX VIGNETTES CARREES, AVEC UNE LEGENDE SUR LES TROIS
       * PREMIERES SEULEMENT.
       *
       * SIX, PARCE QU'UNE GALERIE SE MONTRE PLEINE. Trois images ressemblent a
       * une rangee de cartes ratee ; six remplissent deux lignes sur un ecran
       * large et disent ce que la forme sait faire.
       *
       * TROIS LEGENDES, PAS SIX, et c'est voulu : la galerie doit montrer du
       * premier coup que la legende est facultative, et qu'une vignette sans
       * legende garde exactement la meme forme que les autres.
       *
       * LA LEGENDE EST UN REGLAGE DE L IMAGE, `imgLegende`, depuis le
       * 23 septembre 2026. Elle etait un element de texte pose sous l image :
       * il fallait donc deux lignes pour legender une photo, et ce texte
       * n avait aucun moyen de suivre l image dans la visionneuse.
       */
      galerie: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'galerie', colonne: 'p' },
          liste: 'cartes',
          contenu: [
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-carre.svg',
                  alt_empty: '1',
                  imgFormat: '1-1',
                  imgLegende: exemple('GAL1', '')
                }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-carre.svg',
                  alt_empty: '1',
                  imgFormat: '1-1',
                  imgLegende: exemple('GAL2', '')
                }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-carre.svg',
                  alt_empty: '1',
                  imgFormat: '1-1',
                  imgLegende: exemple('GAL3', '')
                }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-carre.svg',
                  alt_empty: '1',
                  imgFormat: '1-1'
                }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-carre.svg',
                  alt_empty: '1',
                  imgFormat: '1-1'
                }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-carre.svg',
                  alt_empty: '1',
                  imgFormat: '1-1'
                }
              ]
            }
          ]
        }]
      },

      /*
       * LE CARROUSEL : TROIS DIAPOSITIVES, IMAGE EN FOND ET TEXTE DESSUS.
       *
       * `imgPose: banniere` SUR LE FOND : c'est le meme mot que dans une carte,
       * et il y dit la meme chose, l'image tient la boite et le reste se pose
       * par-dessus. Un deuxieme vocabulaire pour la meme idee couterait plus
       * cher qu'un mot un peu large.
       *
       * TROIS, PARCE QU'AU-DELA PERSONNE NE VA AU BOUT. C'est aussi le nombre
       * qu'il faut pour que les pastilles aient un sens.
       */
      carrousel: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'carrousel', colonne: 'p' },
          liste: 'cartes',
          contenu: [
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-16x9.svg',
                  alt_empty: '1',
                  imgPose: 'banniere',
                  imgFormat: '16-9'
                },
                { type: 'heading', label: exemple('SLIDE1_TITLE', '') },
                { type: 'text', body: exemple('SLIDE1_TEXT', '') }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-16x9.svg',
                  alt_empty: '1',
                  imgPose: 'banniere',
                  imgFormat: '16-9'
                },
                { type: 'heading', label: exemple('SLIDE2_TITLE', '') },
                { type: 'text', body: exemple('SLIDE2_TEXT', '') }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-16x9.svg',
                  alt_empty: '1',
                  imgPose: 'banniere',
                  imgFormat: '16-9'
                },
                { type: 'heading', label: exemple('SLIDE3_TITLE', '') },
                { type: 'text', body: exemple('SLIDE3_TEXT', '') }
              ]
            }
          ]
        }]
      },

      /*
       * LA PAGE D'ACCUEIL, RELEVEE SUR landing.joomanji.eu LE 23 SEPTEMBRE 2026.
       *
       * « Cree-le comme mise en page de reference a cote de la galerie et du
       * carrousel. C'est un montage complexe donc interessant », Cyrille.
       *
       * MESURE FAITE SUR LA PAGE, PAS DE MEMOIRE : une rangee `.grille` a deux
       * colonnes 6/6. A gauche un `h1`, un `p.lead`, deux boutons et une note.
       * A droite un `div.message.rule` puis un encadre `.sommaire` contenant un
       * titre et un `ol` de huit liens en `column-count: 2`.
       *
       * ELLE EMPLOIE TROIS BLOCS, ET C'EST LE POINT INTERESSANT : les deux
       * derniers partagent la colonne de droite, et seul le troisieme est
       * encadre. C'est ce que le reglage « Cadre » vient d'apporter ; avec un
       * fond de rangee, l'alerte aurait ete encadree elle aussi.
       *
       * C'EST LA PREMIERE VIGNETTE QUI POSE UNE COMBINAISON, et elle ne
       * contredit pas la regle du 22 septembre : les combinaisons toutes faites
       * ne sont pas au catalogue parce qu'elles se multiplient a l'infini.
       * Celle-ci est une page REELLE, relevee, qui sert de reference et
       * d'exemple de ce que les blocs savent faire ensemble.
       */
      accueil: {
        rangees: [{ colonnes: '2', rapport: '6-6' }],
        blocs: [
          {
            champs: { type: 'ouverture', colonne: 'g' },
            liste: 'elements',
            contenu: [
              { type: 'heading', label: exemple('HOME_TITLE', 'Un template complet, lisible et solide') },
              { type: 'subheading', label: exemple('HOME_LEAD', 'Simple a prendre en main, complet a l\'usage.') },
              {
                type: 'buttons',
                boutons: [
                  { text: exemple('HOME_BUTTON', 'Voir les tampons') },
                  { text: exemple('HOME_BUTTON2', 'La typographie'), variant: 'second' }
                ]
              },
              { type: 'text', body: exemple('HOME_NOTE', 'Une precision courte sous les boutons.') }
            ]
          },
          {
            champs: { type: 'ouverture', colonne: 'd' },
            liste: 'elements',
            contenu: [
              {
                type: 'alerte',
                alertTon: 'info',
                label: exemple('HOME_ALERT_TITLE', 'Une demonstration, pas un theme'),
                body: exemple('HOME_ALERT_TEXT', 'Ce que cette page montre, et ce qu\'elle ne montre pas.')
              }
            ]
          },
          {
            champs: { type: 'ouverture', colonne: 'd', cadre: 'doux' },
            liste: 'elements',
            contenu: [
              { type: 'heading', label: exemple('HOME_SUMMARY', 'Sommaire') },
              {
                type: 'liens',
                liensStyle: 'numeros',
                liensColonnes: '2',
                /*
                 * SIX LIENS SANS CIBLE, ET C'EST VOULU.
                 *
                 * La premiere version posait « index.php » dans chaque entree,
                 * faute de savoir vers quoi pointer. « Pourquoi index.php ? »,
                 * Cyrille, 23 septembre 2026 : une adresse inventee n'apprend
                 * rien et se retrouve telle quelle en ligne si on l'oublie.
                 *
                 * Chaque entree arrive donc avec son intitule et SANS cible :
                 * le selecteur de page de Joomla attend a cote, et tant qu'il
                 * n'a pas servi, la ligne sort en simple texte. Rien ne ment.
                 */
                liens: [
                  { text: exemple('HOME_LINK1', 'La premiere page'), linkType: 'none' },
                  { text: exemple('HOME_LINK2', 'La deuxieme page'), linkType: 'none' },
                  { text: exemple('HOME_LINK3', 'La troisieme page'), linkType: 'none' },
                  { text: exemple('HOME_LINK4', 'La quatrieme page'), linkType: 'none' },
                  { text: exemple('HOME_LINK5', 'La cinquieme page'), linkType: 'none' },
                  { text: exemple('HOME_LINK6', 'La sixieme page'), linkType: 'none' }
                ]
              }
            ]
          }
        ]
      },

      /*
       * LES QUATRE MONTAGES DU 23 SEPTEMBRE 2026, tires des tampons de Corpus
       * et demandes par Cyrille : « dans les montages, je voudrais Logos ou
       * Partenaires, Temoignages, Portraits », et les cartes a pastille de
       * couleur, « celui que je te joins en illustration ».
       *
       * AUCUN N'AJOUTE DE FORME : ce sont quatre reglages des Cartes et de la
       * Galerie, poses d'avance. C'est precisement ce que le catalogue doit
       * contenir depuis que les formes et les montages y sont distingues.
       */
      etats: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'cartes', colonne: 'p' },
          liste: 'cartes',
          contenu: [
            {
              elements: [
                {
                  type: 'heading',
                  label: exemple('CARD1_TITLE', 'Premiere entree')
                },
                {
                  type: 'text',
                  body: exemple('CARD_TEXT', 'Une ou deux phrases qui disent de quoi il s\'agit.')
                },
                {
                  type: 'etat',
                  etatTon: 'succes',
                  label: exemple('STATE_OK', 'Disponible')
                }
              ]
            },
            {
              elements: [
                {
                  type: 'heading',
                  label: exemple('CARD2_TITLE', 'Deuxieme entree')
                },
                {
                  type: 'text',
                  body: exemple('CARD_TEXT', 'Une ou deux phrases qui disent de quoi il s\'agit.')
                },
                {
                  type: 'etat',
                  etatTon: 'alerte',
                  label: exemple('STATE_WIP', 'En cours')
                }
              ]
            },
            {
              elements: [
                {
                  type: 'heading',
                  label: exemple('CARD3_TITLE', 'Troisieme entree')
                },
                {
                  type: 'text',
                  body: exemple('CARD_TEXT', 'Une ou deux phrases qui disent de quoi il s\'agit.')
                },
                {
                  type: 'etat',
                  etatTon: 'neutre',
                  label: exemple('STATE_TODO', 'Prevu')
                }
              ]
            }
          ]
        }]
      },

      portraits: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'cartes', colonne: 'p' },
          liste: 'cartes',
          contenu: [
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-carre.svg',
                  alt_empty: '1',
                  imgFormat: '1-1',
                  imgHabillage: 'ronde',
                  imgLargeur: 'limitee',
                  imgMax: '8',
                  imgMaxUnite: 'rem',
                  align: 'center'
                },
                {
                  type: 'heading',
                  label: exemple('PORTRAIT1_NAME', 'Prenom Nom'),
                  align: 'center'
                },
                {
                  type: 'text',
                  body: exemple('PORTRAIT_ROLE', 'Fonction et organisme'),
                  align: 'center'
                }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-carre.svg',
                  alt_empty: '1',
                  imgFormat: '1-1',
                  imgHabillage: 'ronde',
                  imgLargeur: 'limitee',
                  imgMax: '8',
                  imgMaxUnite: 'rem',
                  align: 'center'
                },
                {
                  type: 'heading',
                  label: exemple('PORTRAIT2_NAME', 'Prenom Nom'),
                  align: 'center'
                },
                {
                  type: 'text',
                  body: exemple('PORTRAIT_ROLE', 'Fonction et organisme'),
                  align: 'center'
                }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-carre.svg',
                  alt_empty: '1',
                  imgFormat: '1-1',
                  imgHabillage: 'ronde',
                  imgLargeur: 'limitee',
                  imgMax: '8',
                  imgMaxUnite: 'rem',
                  align: 'center'
                },
                {
                  type: 'heading',
                  label: exemple('PORTRAIT3_NAME', 'Prenom Nom'),
                  align: 'center'
                },
                {
                  type: 'text',
                  body: exemple('PORTRAIT_ROLE', 'Fonction et organisme'),
                  align: 'center'
                }
              ]
            }
          ]
        }]
      },

      temoignages: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'cartes', colonne: 'p' },
          liste: 'cartes',
          contenu: [
            {
              elements: [
                {
                  type: 'citation',
                  body: exemple('QUOTE1', 'La phrase que la personne a reellement dite.'),
                  quoteSource: exemple('QUOTE_SOURCE', 'Prenom Nom, fonction et organisme')
                }
              ]
            },
            {
              elements: [
                {
                  type: 'citation',
                  body: exemple('QUOTE2', 'La phrase que la personne a reellement dite.'),
                  quoteSource: exemple('QUOTE_SOURCE', 'Prenom Nom, fonction et organisme')
                }
              ]
            },
            {
              elements: [
                {
                  type: 'citation',
                  body: exemple('QUOTE3', 'La phrase que la personne a reellement dite.'),
                  quoteSource: exemple('QUOTE_SOURCE', 'Prenom Nom, fonction et organisme')
                }
              ]
            }
          ]
        }]
      },

      /*
       * LES LOGOS SONT UNE GALERIE, PAS DES CARTES : pas de cadre, pas de
       * legende, pas de format impose, et des images NUES. Un logo dans une
       * carte bordee se lit comme un produit.
       */
      logos: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'galerie', colonne: 'p', galFormat: '', galLegende: 'aucune', galAgrandir: '0', galMini: '10' },
          liste: 'cartes',
          contenu: [
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-bandeau.svg',
                  alt_empty: '1',
                  imgFormat: '',
                  imgHabillage: 'nue'
                }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-bandeau.svg',
                  alt_empty: '1',
                  imgFormat: '',
                  imgHabillage: 'nue'
                }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-bandeau.svg',
                  alt_empty: '1',
                  imgFormat: '',
                  imgHabillage: 'nue'
                }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-bandeau.svg',
                  alt_empty: '1',
                  imgFormat: '',
                  imgHabillage: 'nue'
                }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-bandeau.svg',
                  alt_empty: '1',
                  imgFormat: '',
                  imgHabillage: 'nue'
                }
              ]
            },
            {
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-bandeau.svg',
                  alt_empty: '1',
                  imgFormat: '',
                  imgHabillage: 'nue'
                }
              ]
            }
          ]
        }]
      },

      /*
       * TROIS MONTAGES DE PLUS, TOUJOURS TIRES DE LA PLANCHE DES TAMPONS
       * (`corpus/maquettes/blocs-corpus.html`, donnee par Cyrille le
       * 23 septembre 2026).
       *
       * AUCUN N'AJOUTE DE FORME NI D'ELEMENT : les etapes sont des points cles
       * numerotes, les tarifs sont deux cartes, la FAQ est un accordeon. Ils
       * n'apportent que le reglage et le contenu d'exemple, c'est-a-dire le
       * temps qu'on ne passe pas a les monter.
       */
      etapes: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [
            { type: 'heading', label: exemple('STEPS_TITLE', 'Comment ca se passe') },
            {
              type: 'points',
              pointsMarque: 'numero',
              points: [
                { titre: exemple('STEP1', 'Premiere etape'), texte: exemple('STEP_TEXT', '') },
                { titre: exemple('STEP2', 'Deuxieme etape'), texte: exemple('STEP_TEXT', '') },
                { titre: exemple('STEP3', 'Troisieme etape'), texte: exemple('STEP_TEXT', '') }
              ]
            }
          ]
        }]
      },

      /*
       * LES DEUX TARIFS SONT DEUX CARTES, ET LE PRIX EST UN CHIFFRE CLE : le
       * tampon de l'editeur ecrit sa taille en dur, faute de mieux ; ici,
       * l'element Chiffres cles le fait avec les jetons du template.
       */
      /*
       * TROIS FORMULES, ET CELLE DU MILIEU EST MISE EN AVANT.
       *
       * « Il faudrait que ce soit sur trois cartes, et que l'on puisse choisir
       * une carte primaire, secondaire ou neutre », Cyrille, 23 septembre
       * 2026, devant la premiere version a deux cartes.
       *
       * TROIS, PARCE QU'UNE GRILLE DE TARIFS SE LIT PAR TROIS : deux formules
       * font un choix binaire, trois font une echelle, et celle du milieu est
       * celle qu'on recommande. C'est aussi ce que fait tout le monde, et pour
       * une fois la convention a raison.
       *
       * LA CARTE DU MILIEU PORTE UN ETAT EN PLUS DE SA COULEUR : « Le plus
       * choisi » est ecrit, donc lisible par qui ne voit pas le contour. La
       * couleur ne porte jamais l'information seule.
       *
       * LE PRIX EST EN GRANDE TAILLE ET SON UNITE A COTE : « 39 EUR par an »
       * est une phrase, pas deux lignes.
       */
      /*
       * TROIS FORMULES, ET CELLE DU MILIEU EST MISE EN AVANT.
       *
       * « Il faudrait que ce soit sur trois cartes, et que l'on puisse choisir
       * une carte primaire, secondaire ou neutre », Cyrille, 23 septembre
       * 2026, devant la premiere version a deux cartes.
       *
       * TROIS, PARCE QU'UNE GRILLE DE TARIFS SE LIT PAR TROIS : deux formules
       * font un choix binaire, trois font une echelle, et celle du milieu est
       * celle qu'on recommande.
       *
       * CE MODELE EST CELUI QUE CYRILLE A MONTE LUI-MEME, RELEVE DANS SON
       * FORMULAIRE LE 23 SEPTEMBRE AU SOIR. Trois ecarts avec ma version, et
       * les trois ont une raison :
       *
       * 1. L'ETAT PASSE AVANT LE PRIX. « Le plus choisi » qualifie la formule,
       *    pas son tarif : on le lit avant de regarder combien ca coute, comme
       *    une etiquette posee sur la carte.
       * 2. LE PRIX DE LA CARTE MISE EN AVANT EST « ENORME », les deux autres
       *    « grande ». La hierarchie se voit alors dans le chiffre lui-meme,
       *    et pas seulement dans le contour de la carte.
       * 3. LES BOUTONS DES DEUX AUTRES SONT EN SECONDAIRE, celui du milieu
       *    reste principal. Trois boutons pleins cote a cote ne recommandent
       *    rien ; un seul, si.
       */
      tarifs: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'cartes', colonne: 'p' },
          liste: 'cartes',
          contenu: [
            {
              elements: [
                { type: 'heading', label: exemple('PRICE1_TITLE', '') },
                {
                  type: 'chiffres',
                  chiffresTaille: 'grande',
                  chiffresPose: 'droite',
                  chiffres: [{ valeur: exemple('PRICE1', ''), mesure: exemple('PRICE_UNIT', 'par an') }]
                },
                { type: 'liste', listStyle: 'puces', listItems: exemple('PRICE_ITEMS', '').replace(/\\n/g, '\n') },
                { type: 'buttons', boutons: [{ text: exemple('PRICE_BUTTON', 'Choisir cette formule'), variant: 'second' }] }
              ]
            },
            {
              ton: 'primaire',
              elements: [
                { type: 'heading', label: exemple('PRICE2_TITLE', '') },
                { type: 'etat', etatTon: 'succes', label: exemple('PRICE_BEST', '') },
                {
                  type: 'chiffres',
                  chiffresTaille: 'enorme',
                  chiffresPose: 'droite',
                  chiffres: [{ valeur: exemple('PRICE2', ''), mesure: exemple('PRICE_UNIT', 'par an') }]
                },
                { type: 'liste', listStyle: 'puces', listItems: exemple('PRICE_ITEMS', '').replace(/\\n/g, '\n') },
                { type: 'buttons', boutons: [{ text: exemple('PRICE_BUTTON', 'Choisir cette formule') }] }
              ]
            },
            {
              ton: 'secondaire',
              elements: [
                { type: 'heading', label: exemple('PRICE3_TITLE', '') },
                {
                  type: 'chiffres',
                  chiffresTaille: 'grande',
                  chiffresPose: 'droite',
                  chiffres: [{ valeur: exemple('PRICE3', ''), mesure: exemple('PRICE_UNIT', 'par an') }]
                },
                { type: 'liste', listStyle: 'puces', listItems: exemple('PRICE_ITEMS', '').replace(/\\n/g, '\n') },
                { type: 'buttons', boutons: [{ text: exemple('PRICE_BUTTON', 'Choisir cette formule'), variant: 'second' }] }
              ]
            }
          ]
        }]
      },

      /*
       * LE BANDEAU D'APPEL EST LE TAMPON « APPEL - BANDEAU ACTION » DE CORPUS.
       *
       * Relu dans `corpus/html/tinymce/Appel - Bandeau action.html` : une
       * boite teintee, un `h2`, une phrase, UN SEUL BOUTON.
       *
       * UN SEUL BOUTON, ET C'EST LE TAMPON QUI LE DIT, pas moi : « Deux
       * actions de meme poids cote a cote, c'est une decision de plus a
       * prendre pour le visiteur, et le taux de clic baisse. » Le modele ne
       * pose donc pas de second bouton. Celui qui en veut un l'ajoute, en
       * connaissance de cause.
       *
       * `cadre: 'teinte'` EST CE QUI FAIT LE BANDEAU. Sans lui, ce montage ne
       * serait qu'une ouverture avec un bouton de moins : c'est l'aplat qui
       * detache l'appel du texte qui le precede, et c'est pour cela que le
       * reglage existe deja sur le bloc. Aucun code neuf ici, que du
       * remplissage.
       *
       * LE TITRE RESTE A GAUCHE, comme dans le tampon. Un bandeau centre se
       * fait en trois clics avec le reglage d'alignement ; l'inverse aussi.
       * On suit le tampon, l'editeur et le module racontent la meme histoire.
       */
      /*
       * LA COMPARAISON EST LE TAMPON « GRILLE - COMPARAISON EN DEUX COLONNES ».
       *
       * DEUX CARTES QUI SE REPONDENT, PAS DEUX COLONNES. Le tampon prend soin
       * de le dire : « Deux idees de meme rang se posent avec Grille :
       * 2 colonnes. Ici les deux blocs se repondent, et l'ordre compte : a
       * gauche ce qu'on quitte, a droite ce qu'on propose. »
       *
       * C'EST POURQUOI C'EST UN BLOC « CARTES » A DEUX CARTES, et non une
       * rangee a deux colonnes avec un bloc dans chacune. Sur telephone les
       * deux cartes s'empilent dans l'ordre du code, la gauche d'abord, ce qui
       * est exactement la lecture voulue. Une rangee a deux colonnes ne
       * garantirait pas cet ordre.
       *
       * PAS DE TITRE, UN SOUS-TITRE. Le tampon emploie un `p.lead.fw-semibold`
       * et non un `h3` : les deux faces d'une comparaison ne sont pas deux
       * sections de la page, et deux titres de plus dans le plan de lecture
       * n'aideraient personne.
       *
       * PAS D'IMAGE NON PLUS, a la difference du referentiel des cartes : ce
       * qui se compare ici, ce sont deux textes, exactement sur le meme point.
       */
      /*
       * LES COORDONNEES : DEUX BLOCS, DEUX ELEMENTS, AUCUN CHAMP VIDE.
       *
       * DEUX VERSIONS ONT ETE REJETEES AVANT CELLE-CI, ET LES DEUX POUR LA MEME
       * RAISON MAL COMPRISE PAR MOI.
       *
       * La premiere posait deux elements « Coordonnees » identiques, chacun ne
       * remplissant que la moitie de ses champs. « Je ne comprends pas les
       * champs vides dans les coordonnees », Cyrille, 24 septembre 2026 : un
       * champ vide au milieu de champs remplis se lit comme un oubli.
       *
       * La seconde, ma correction, fondait tout dans un seul element sur une
       * seule colonne. Elle reglait les champs vides en perdant le decoupage,
       * qui lui est juste : « il faut deux blocs, avec des champs differents ».
       *
       * LA VRAIE REPONSE N'ETAIT NI L'UNE NI L'AUTRE : ce ne sont pas deux
       * moities d'un element, ce sont DEUX ELEMENTS. `adresse` porte
       * l'organisme et l'adresse, `contact` le telephone, le courriel et les
       * informations. Chacun n'a que ses champs, aucun ne sort vide, et le
       * decoupage du tampon est tenu.
       *
       * L'ADRESSE EST AUSSI LA PIECE DE LA FUTURE CARTE : c'est sur elle que se
       * poseront les coordonnees geographiques. La separer du contact n'est pas
       * qu'une affaire de formulaire.
       */
      coordonnees: {
        rangees: [{ colonnes: '2', rapport: '6-6' }],
        blocs: [
          {
            champs: { type: 'ouverture', colonne: 'g' },
            liste: 'elements',
            contenu: [
              { type: 'heading', label: exemple('COORD_FIND', 'Nous trouver'), headingLevel: 'h2' },
              {
                type: 'adresse',
                coordNom: exemple('COORD_ORG', 'Nom de l\'organisme'),
                coordAdresse: exemple('COORD_ADDRESS', '12 rue de l\'Exemple\n75000 Ville').replace(/\\n/g, '\n')
              }
            ]
          },
          {
            champs: { type: 'ouverture', colonne: 'd' },
            liste: 'elements',
            contenu: [
              { type: 'heading', label: exemple('COORD_REACH', 'Nous joindre'), headingLevel: 'h2' },
              {
                type: 'contact',
                coordTel: exemple('COORD_PHONE', '01 00 00 00 00'),
                coordCourriel: exemple('COORD_MAIL', 'contact@example.org'),
                coordHoraires: exemple('COORD_HOURS', 'Ouvert du lundi au vendredi, de 9 h a 17 h.')
              }
            ]
          }
        ]
      },

      /*
       * LES CHIFFRES VERIFIABLES, TAMPON « DONNEES - CHIFFRES VERIFIABLES ».
       *
       * TROIS CHIFFRES, ET SOUS CHACUN D'OU IL VIENT. C'est le seul ecart avec
       * les chiffres cles, et il change tout : « 1 200 personnes
       * accompagnees » est une affirmation, « chiffre issu du rapport
       * d'activite 2026, page 12 » est une donnee que le lecteur peut aller
       * verifier. Le champ Source, ajoute aux chiffres le 24 septembre 2026,
       * sert exactement a cela.
       *
       * UN SEUL ELEMENT CHIFFRES, PAS TROIS CARTES : les trois valeurs se
       * lisent ensemble, et le `dl` dit qu'elles forment un jeu. Le tampon les
       * pose en trois colonnes ; notre element le fait tout seul.
       *
       * TAILLE « GRANDE » ET NON « ENORME » : un chiffre verifiable se lit, il
       * ne frappe pas. L'enorme est pour un prix, seul dans sa carte.
       */
      preuves: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [
            { type: 'heading', label: exemple('PROOF_TITLE', 'Ce que nous avons fait'), headingLevel: 'h2' },
            {
              type: 'chiffres',
              chiffresTaille: 'grande',
              chiffres: [
                {
                  valeur: exemple('PROOF1', '1 200'),
                  mesure: exemple('PROOF1_LABEL', 'Personnes accompagnees en 2026'),
                  source: exemple('PROOF1_SOURCE', 'Chiffre issu du rapport d\'activite 2026, page 12.')
                },
                {
                  valeur: exemple('PROOF2', '48'),
                  mesure: exemple('PROOF2_LABEL', 'Communes couvertes par le dispositif'),
                  source: exemple('PROOF2_SOURCE', 'La liste complete est publiee sur la page du dispositif.')
                },
                {
                  valeur: exemple('PROOF3', '96 %'),
                  mesure: exemple('PROOF3_LABEL', 'De reponses en moins de trois jours'),
                  source: exemple('PROOF3_SOURCE', 'Mesure sur les 340 demandes recues au premier trimestre.')
                }
              ]
            }
          ]
        }]
      },

      /*
       * LA REPARTITION : DES BARRES.
       *
       * « Ce qui manque : des barres graphe », Cyrille, 24 septembre 2026, avec
       * deux maquettes sous les yeux : des anneaux en pour cent, et des barres
       * couchees avec leur intitule a gauche. Les barres d'abord, parce qu'un
       * anneau demande du SVG ou un degrade conique, et qu'une liste de six
       * anneaux se compare mal : l'oeil sait juger deux longueurs cote a cote,
       * pas deux arcs de cercle.
       *
       * LES QUATRE TONS DIFFERENTS SONT UNE DEMONSTRATION, pas une
       * recommandation : le montage sert aussi a montrer ce que le champ
       * Couleur du trait sait faire. Une vraie repartition garde souvent un
       * seul ton, et laisse la longueur parler.
       */
      repartition: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [
            { type: 'heading', label: exemple('BARS_TITLE', 'Ou passe le budget'), headingLevel: 'h2' },
            { type: 'text', body: exemple('BARS_INTRO', 'Repartition des depenses de l\'annee, en pour cent du total.') },
            {
              type: 'barres',
              barresForme: 'traits',
              barresTrait: 'normale',
              barresNombre: '1',
              barres: [
                { terme: exemple('BARS1', 'Accompagnement'), part: '46', tonBarre: 'accent' },
                { terme: exemple('BARS2', 'Formation'), part: '27', tonBarre: 'succes' },
                { terme: exemple('BARS3', 'Fonctionnement'), part: '18', tonBarre: 'alerte' },
                { terme: exemple('BARS4', 'Communication'), part: '9', tonBarre: '' }
              ]
            }
          ]
        }]
      },

      /*
       * LES ONGLETS ET L'IMAGE, 24 septembre 2026.
       *
       * C'EST UN BLOC, ET PLUS UN ELEMENT. J'en avais fait un element a quatre
       * champs fixes ; Cyrille a tranche en montrant la mise en page Cartes :
       * « je veux la meme chose, mais pour des onglets ». Un onglet porte son
       * titre, qui fait le bouton, et une PILE d'elements qu'on ordonne
       * librement, exactement comme une carte.
       *
       * TROIS ONGLETS, CHACUN PARTAGE EN DEUX : le texte d'un cote, l'image de
       * l'autre. Le reglage `dispo` de l'onglet dit lequel, et le gabarit range
       * les elements de type Image d'un cote, tout le reste de l'autre.
       *
       * LES ONGLETS SONT HORIZONTAUX, la pose la plus frequente, et le repli a
       * 768 pixels les transforme en accordeon sur telephone. Le sens vertical
       * est a un clic, en clair sur la ligne du bloc, pour une colonne
       * laterale.
       */
      onglets: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'onglets', colonne: 'p', ongletsSens: 'horizontal', ongletsRepli: '768' },
          liste: 'onglets',
          contenu: [
            {
              titre: exemple('TAB1', 'Accompagner'),
              dispo: 'media-droite',
              actif: '1',
              elements: [
                { type: 'subheading', label: exemple('TAB1_SUB', '') },
                { type: 'text', body: exemple('TAB1_TEXT', '') },
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-16x9.svg',
                  alt_empty: '1'
                }
              ]
            },
            {
              titre: exemple('TAB2', 'Former'),
              dispo: 'media-droite',
              actif: '0',
              elements: [
                { type: 'subheading', label: exemple('TAB2_SUB', '') },
                { type: 'text', body: exemple('TAB2_TEXT', '') },
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-16x9.svg',
                  alt_empty: '1'
                }
              ]
            },
            {
              titre: exemple('TAB3', 'Outiller'),
              dispo: 'media-droite',
              actif: '0',
              elements: [
                { type: 'subheading', label: exemple('TAB3_SUB', '') },
                { type: 'text', body: exemple('TAB3_TEXT', '') },
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-16x9.svg',
                  alt_empty: '1'
                }
              ]
            }
          ]
        }]
      },

      /*
       * LA FRISE, 24 septembre 2026.
       *
       * « Un montage sur deux axes pour presenter une echelle de temps, par
       * exemple une entreprise qui evolue », Cyrille, avec les exemples de
       * MDBootstrap sous les yeux.
       *
       * HORIZONTALE, arbitrage de Cyrille le 24 septembre 2026 : c'est la
       * forme qu'on attend quand on dit « frise ». Elle demande des textes
       * courts, et les quatre etapes de demonstration en tiennent compte.
       * La verticale est a un clic, sur la ligne du bloc, et l'horizontale y
       * retombe toute seule sous 48 rem.
       *
       * QUATRE ETAPES, ET LA DERNIERE EST « AUJOURD'HUI » : une frise
       * d'entreprise raconte d'ou l'on vient, elle doit donc arriver quelque
       * part.
       */
      frise: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'frise', colonne: 'p', friseSens: 'horizontal', frisePose: 'cote' },
          liste: 'etapes',
          contenu: [
            {
              repere: exemple('TL1', '2019'),
              elements: [
                { type: 'subheading', label: exemple('TL1_TITLE', '') },
                { type: 'text', body: exemple('TL1_TEXT', '') }
              ]
            },
            {
              repere: exemple('TL2', '2021'),
              elements: [
                { type: 'subheading', label: exemple('TL2_TITLE', '') },
                { type: 'text', body: exemple('TL2_TEXT', '') }
              ]
            },
            {
              repere: exemple('TL3', '2024'),
              elements: [
                { type: 'subheading', label: exemple('TL3_TITLE', '') },
                { type: 'text', body: exemple('TL3_TEXT', '') }
              ]
            },
            {
              repere: exemple('TL4', "Aujourd'hui"),
              tonEtape: 'accent',
              elements: [
                { type: 'subheading', label: exemple('TL4_TITLE', '') },
                { type: 'text', body: exemple('TL4_TEXT', '') }
              ]
            }
          ]
        }]
      },

      /*
       * LES TUILES, TAMPON « GRILLE - TUILES ».
       *
       * DES CARTES DONT LE TITRE EST UN LIEN : c'est tout ce qui les distingue
       * d'une rangee de cartes ordinaire, et c'est ce qui en fait une porte
       * vers d'autres pages plutot qu'un contenu qui se suffit.
       *
       * PAS D'IMAGE, et le tampon non plus : une tuile est un intitule et une
       * phrase. Les images, c'est la Mosaique, juste en dessous.
       *
       * LES LIENS ARRIVENT SANS CIBLE, comme le sommaire de l'Accueil : une
       * adresse inventee n'apprend rien et se retrouve telle quelle en ligne si
       * on l'oublie. Le selecteur de page de Joomla attend a cote, et tant
       * qu'il n'a pas servi le titre sort en simple texte. Rien ne ment.
       */
      tuiles: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'cartes', colonne: 'p' },
          liste: 'cartes',
          contenu: [
            {
              linkType: 'none',
              elements: [
                { type: 'heading', label: exemple('TILE1', 'Premiere entree') },
                { type: 'text', body: exemple('TILE_TEXT', 'Une ou deux phrases qui disent ce qu\'on trouve derriere le lien.') }
              ]
            },
            {
              linkType: 'none',
              elements: [
                { type: 'heading', label: exemple('TILE2', 'Deuxieme entree') },
                { type: 'text', body: exemple('TILE_TEXT', 'Une ou deux phrases qui disent ce qu\'on trouve derriere le lien.') }
              ]
            },
            {
              linkType: 'none',
              elements: [
                { type: 'heading', label: exemple('TILE3', 'Troisieme entree') },
                { type: 'text', body: exemple('TILE_TEXT', 'Une ou deux phrases qui disent ce qu\'on trouve derriere le lien.') }
              ]
            }
          ]
        }]
      },

      /*
       * LA MOSAIQUE, TAMPON « IMAGES - MOSAIQUE ».
       *
       * QUATRE ENTREES : une image, un titre lie, une ligne.
       *
       * AVEC LEUR CADRE, ET C'EST UN ECART ASSUME AVEC LE TAMPON. Le tampon
       * « Images - Mosaique » ne pose aucun contour, et le modele l'a d'abord
       * suivi a la lettre. « Il me manque une bordure sur les cartes
       * mosaique », Cyrille, 24 septembre 2026, devant le resultat : sans
       * contour, les quatre entrees flottent et on ne voit plus ou finit l'une
       * et ou commence l'autre. Il a raison a l'ecran, et le tampon a raison
       * dans un article, ou le texte autour donne deja la limite.
       *
       * LA FORME RESTE REGLABLE EN DEUX CLICS, derriere la roue du bloc. Ce
       * n'est donc pas le tampon qu'on contredit, c'est son defaut qu'on
       * choisit autrement ici.
       *
       * C'EST CE MONTAGE QUI A FAIT BRANCHER LA FORME DES CARTES, le
       * 24 septembre 2026 : les deux variantes dormaient dans la feuille depuis
       * leur ecriture sans que personne les pose.
       *
       * QUATRE TIENNENT SUR UNE LIGNE parce que la grille est en `auto-fit`
       * avec une largeur minimale de 11 rem : rien a regler, elles se replient
       * toutes seules a l'etroit.
       */
      mosaique: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'cartes', colonne: 'p' },
          liste: 'cartes',
          contenu: [1, 2, 3, 4].map(function (n) {
            return {
              linkType: 'none',
              elements: [
                {
                  type: 'image',
                  imagefile: 'media/mod_opus/images/emplacement-16x9.svg',
                  alt_empty: '1',
                  imgPose: 'banniere',
                  imgFormat: '16-9'
                },
                { type: 'heading', label: exemple('MOSAIC_TITLE', 'Titre de la realisation') },
                { type: 'text', body: exemple('MOSAIC_TEXT', 'Une ligne qui dit de quoi il s\'agit.') }
              ]
            };
          })
        }]
      },

      /*
       * LES ATOUTS, TAMPON « GRILLE - 6 ATOUTS ».
       *
       * SIX ENTREES, SANS CADRE, ET LA C'EST LE TAMPON QUI A RAISON. La
       * mosaique a recu son contour le 24 septembre parce que ses images
       * flottaient sans lui ; six blocs de texte, eux, se lisent tres bien en
       * colonnes, et six cadres empiles feraient un mur. La regle n'est donc
       * pas « toujours un cadre » ni « jamais » : un cadre borne ce qui n'a pas
       * de bord a soi, et une image n'en a pas, un paragraphe si.
       *
       * SIX TITRES DE NIVEAU 3, SOUS UN TITRE DE SECTION, et j'avais d'abord
       * ecrit l'inverse.
       *
       * « Et aucun titre ? Accessibilite ? », Cyrille, 24 septembre 2026. Ma
       * premiere version posait six SOUS-TITRES, en suivant le tampon qui
       * emploie un paragraphe appuye. Mesure faite apres sa question : dans ce
       * module, `opus__soustitre` n'est habille NULLE PART. Un
       * sous-titre sortait donc en paragraphe ordinaire, sans aucune mise en
       * valeur. Chaque atout perdait son intitule dans son texte, et le bloc
       * n'offrait aucun point d'entree a la navigation par titres.
       *
       * UN INTITULE QUI ANNONCE UN CONTENU EST UN TITRE, et ce n'est pas une
       * question de taille : c'est ce qui donne au lecteur d'ecran la liste des
       * six atouts et permet d'y sauter. Le tampon a le droit de s'en passer
       * dans un article ou les titres viennent du texte autour ; un module qui
       * pose six blocs de sa propre autorite, non.
       *
       * LE TITRE DE SECTION VIENT AVEC : six `h3` sans `h2` au-dessus feraient
       * un trou dans le plan de la page.
       *
       * IL EST DANS LA MEME RANGEE QUE LES CARTES, dans la meme colonne. Ma
       * premiere version lui donnait une rangee a lui. « Il semble qu'il y ait
       * une rangee pour rien », Cyrille, 24 septembre 2026 : exact. Verifie
       * dans `default.php` l. 117, la mise en page parcourt les blocs d'une
       * colonne et les empile. Deux blocs dans la meme colonne s'ecrivent donc
       * l'un sous l'autre, et une rangee de plus n'ajoutait qu'un niveau de
       * grille inutile a regler.
       *
       * SIX, ET LA GRILLE S'EN CHARGE : en `auto-fit` a partir de 11 rem, ils
       * se posent en trois par trois sur une page large et se replient seuls a
       * l'etroit. Rien a regler.
       */
      atouts: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [
          {
            champs: { type: 'ouverture', colonne: 'p' },
            liste: 'elements',
            contenu: [
              { type: 'heading', label: exemple('BENEFITS_TITLE', 'Ce que cela vous apporte'), headingLevel: 'h2' }
            ]
          },
          {
            champs: { type: 'cartes', colonne: 'p', cartesForme: 'none' },
            liste: 'cartes',
            contenu: [1, 2, 3, 4, 5, 6].map(function (n) {
              return {
                elements: [
                  { type: 'heading', label: exemple('BENEFIT' + n, 'Atout ' + n), headingLevel: 'h3' },
                  { type: 'text', body: exemple('BENEFIT_TEXT', 'Deux lignes qui disent ce que cela apporte au visiteur.') }
                ]
              };
            })
          }
        ]
      },

      comparaison: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'cartes', colonne: 'p' },
          liste: 'cartes',
          contenu: [
            {
              ton: 'secondaire',
              elements: [
                { type: 'heading', label: exemple('COMPARE1_TITLE', 'Ce qui se passait avant'), headingLevel: 'h3' },
                { type: 'text', body: exemple('COMPARE1_TEXT', 'Decrivez la situation qu\'on quitte, sans caricature : le lecteur l\'a vecue, il verra tout de suite si vous exagerez.') }
              ]
            },
            {
              ton: 'primaire',
              elements: [
                { type: 'heading', label: exemple('COMPARE2_TITLE', 'Ce qui se passe maintenant'), headingLevel: 'h3' },
                { type: 'text', body: exemple('COMPARE2_TEXT', 'Decrivez la reponse sur le meme point exactement, avec le meme niveau de detail. C\'est ce parallele qui fait la demonstration.') }
              ]
            }
          ]
        }]
      },

      appel: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p', cadre: 'teinte' },
          liste: 'elements',
          contenu: [
            { type: 'heading', label: exemple('CTA_TITLE', 'Un titre qui dit ce qu\'on propose'), headingLevel: 'h2' },
            { type: 'text', body: exemple('CTA_TEXT', 'Une phrase qui leve la derniere hesitation.') },
            {
              type: 'buttons',
              boutons: [
                { text: exemple('CTA_BUTTON', 'Action principale') }
              ]
            }
          ]
        }]
      },

      faq: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [
            { type: 'heading', label: exemple('FAQ_TITLE', 'Questions frequentes') },
            {
              type: 'accordeon',
              volets: [
                { titre: exemple('FAQ1', 'La premiere question'), texte: exemple('FAQ_TEXT', ''), ouvert: '1' },
                { titre: exemple('FAQ2', 'La deuxieme question'), texte: exemple('FAQ_TEXT', ''), ouvert: '0' },
                { titre: exemple('FAQ3', 'La troisieme question'), texte: exemple('FAQ_TEXT', ''), ouvert: '0' }
              ]
            }
          ]
        }]
      },

      /*
       * LES ELEMENTS SEULS, 23 septembre 2026.
       *
       * « Pour que je puisse faire des combinaisons, exemple Texte / Image, il
       * me faut les champs en mode unique », Cyrille. Une mise en page pose une
       * forme entiere ; ceux-ci posent UNE brique, dans une ouverture, et c'est
       * tout. Deux clics et un rapport de colonnes donnent alors n'importe quel
       * assemblage, sans qu'aucun assemblage n'entre au catalogue.
       *
       * C'EST LA SUITE LOGIQUE DE LA REGLE DU 22 SEPTEMBRE : si les
       * combinaisons ne se livrent pas toutes faites, il faut que les pieces
       * soient a portee de main.
       *
       * ILS N'ONT PAS DE CONTENU D'EXEMPLE, ou presque : une brique posee seule
       * est destinee a etre remplie tout de suite. Un faux texte a effacer
       * ferait perdre le temps qu'on vient de gagner.
       */
      uniqueTitre: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'heading', label: '' }]
        }]
      },

      /*
       * LE SOUS-TITRE MANQUAIT A LA LISTE DES BRIQUES, 24 septembre 2026.
       * « Dans les elements je ne vois pas sous-titre », Cyrille. Le TYPE
       * existait depuis le debut, dans les quatre piles ; c'est sa vignette qui
       * n'avait jamais ete posee, et on ne pouvait donc pas l'ajouter d'un clic
       * comme les quinze autres.
       */
      uniqueSousTitre: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'subheading', label: '' }]
        }]
      },

      uniqueTexte: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'text', body: '' }]
        }]
      },

      uniqueImage: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'image', imgFormat: '16-9' }]
        }]
      },

      uniqueBoutons: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'buttons', boutons: [{ text: exemple('BUTTON', 'Action principale') }] }]
        }]
      },

      uniqueSeparateur: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'separator' }]
        }]
      },

      uniqueListe: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'liste', listStyle: 'puces' }]
        }]
      },

      uniqueAlerte: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'alerte', alertTon: 'info' }]
        }]
      },

      /*
       * TROIS POINTS, PARCE QU'UN SEUL NE SE LIT PAS COMME UNE LISTE. Le
       * modele pose donc la forme complete, a remplir, et non une ligne que
       * l'on prendrait pour un paragraphe mal habille.
       */
      uniquePoints: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'points', pointsMarque: 'numero' }]
        }]
      },

      uniqueEtat: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'etat', etatTon: 'succes', label: exemple('STATE_OK', 'Disponible') }]
        }]
      },

      uniqueCitation: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'citation' }]
        }]
      },

      uniqueChiffres: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'chiffres' }]
        }]
      },

      uniqueBarres: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'barres' }]
        }]
      },

      uniqueAccordeon: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'accordeon' }]
        }]
      },

      uniqueAdresse: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'adresse' }]
        }]
      },

      uniqueContact: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'contact' }]
        }]
      },

      /*
       * LA BRIQUE « LIENS » MANQUAIT AUSSI, 24 septembre 2026. Relevé en
       * comparant les dix-huit types du manifeste aux vignettes posées, apres
       * la question de Cyrille : « il en manque d'autres ? ». Deux sur
       * dix-huit, le sous-titre et les liens ; `outils/briques-completes.py`
       * refait cette comparaison avant chaque livraison.
       */
      uniqueLiens: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'liens' }]
        }]
      },

      uniqueFiche: {
        rangees: [{ colonnes: '1', rapport: '' }],
        blocs: [{
          champs: { type: 'ouverture', colonne: 'p' },
          liste: 'elements',
          contenu: [{ type: 'fiche' }]
        }]
      }
    };
  }

  /** L'hote d'une liste, par le nom que porte son `joomla-field-subform`. */
  function hoteListe(portee, nom) {
    return [].slice.call(portee.querySelectorAll('joomla-field-subform'))
      .filter(function (s) {
        return (s.getAttribute('name') || '').slice(-(nom.length + 2)) === '[' + nom + ']';
      })[0] || null;
  }

  /**
   * Ajoute une ligne a une liste et rend la ligne neuve.
   *
   * ON CLIQUE LE `+` DE LA DERNIERE LIGNE, pas celui de la liste : le coeur
   * insere APRES la ligne dont on clique le bouton. Partir du premier `+`
   * aurait pose les lignes d'un modele a l'envers.
   */
  function ajouterLigne(hote) {
    if (!hote) { return null; }

    var avant = rangeesDe(hote);
    var bouton = avant.length
      ? avant[avant.length - 1].querySelector('.group-add')
      : hote.querySelector('.group-add');

    if (!bouton) { return null; }

    /*
     * ON PASSE DEVANT LE MENU DU `+`.
     *
     * Depuis que le `+` de la liste des blocs ouvre un menu (Bloc vide,
     * Ouverture, Cartes), un clic programme ne pose plus de ligne : il
     * deroule le menu et attend. Une vignette ajoutait donc sa rangee et
     * aucun bloc, mesure sur le banc le 22 septembre 2026.
     *
     * `opusDirect` est le laissez-passer que `ajoutParModele` lit deja.
     * Il ne vaut que le temps du clic : le `+` retrouve son menu juste
     * apres, pour la main de l utilisateur.
     */
    bouton.dataset.opusDirect = "1";
    bouton.click();
    delete bouton.dataset.opusDirect;

    var apres = rangeesDe(hote);

    return apres.length > avant.length ? apres[apres.length - 1] : null;
  }

  /**
   * Ecrit des valeurs dans une ligne.
   *
   * MEME REGLE QUE `champDe` : on prend le premier champ QUI EST A NOUS, et
   * non le premier trouve, parce qu'une ligne de bloc contient les champs de
   * ses cartes, qui portent les memes noms et viennent avant dans le document.
   */
  function remplirLigne(ligne, valeurs) {
    Object.keys(valeurs).forEach(function (cle) {
      var champs = [].slice.call(ligne.querySelectorAll('[name$="[' + cle + ']"]'))
        .filter(function (e) {
          return estUnChamp(e) && e.closest('.subform-repeatable-group') === ligne;
        });

      if (champs.length === 0) { return; }

      var valeur = valeurs[cle];

      /*
       * UNE CASE SE COCHE. Ecrire `value = '1'` sur une case a cocher ne la
       * coche pas : cela change la valeur qu elle enverra SI elle est cochee.
       * Le referentiel des cartes pose `alt_empty`, la case « image
       * decorative » du champ media, et sans ceci elle restait vide.
       */
      if (champs[0].type === 'checkbox') {
        champs[0].checked = valeur === '1' || valeur === true;
        champs[0].dispatchEvent(new Event('change', { bubbles: true }));

        return;
      }

      if (champs[0].type === 'radio') {
        champs.forEach(function (e) { e.checked = e.value === valeur; });
        champs[0].dispatchEvent(new Event('change', { bubbles: true }));

        return;
      }

      champs[0].value = valeur;
      champs[0].dispatchEvent(new Event('input', { bubbles: true }));
      champs[0].dispatchEvent(new Event('change', { bubbles: true }));
    });
  }

  /* ==========================================================================
     LE `+` D'UNE LIGNE LA DUPLIQUE

     Demande de Cyrille le 21 septembre 2026 : « quand je clique sur le plus
     des rangees, cela doit tout me doubler ». Le coeur, lui, insere une ligne
     VIERGE : on venait de regler une rangee en deux colonnes 5/7, on cliquait
     `+` pour la meme en dessous, et on recevait une rangee a une colonne qu'il
     fallait re-regler entierement.

     TOUT, C'EST AUSSI LE CONTENU. Dupliquer un bloc sans ses cartes ne double
     rien : c'est la saisie qui coute, pas la ligne. On descend donc dans les
     listes imbriquees, autant de niveaux qu'il y en a.

     L'IDENTIFIANT NE SE COPIE JAMAIS. Il doit etre unique dans la page, et
     deux fois le meme, le navigateur ne trouve que le premier : l'ancre d'un
     menu menerait toujours a la premiere copie. L'aide du champ le dit deja.
     ========================================================================== */

  /** Le suffixe d'un nom de champ : `jform[params][...][colonnes]` -> `colonnes`. */
  function clefDe(nom) {
    var m = /\[([^\[\]]+)\]$/.exec(nom || '');

    return m ? m[1] : '';
  }

  /**
   * UN CHAMP, C'EST UN `input`, UN `select` OU UN `textarea`. RIEN D'AUTRE.
   *
   * `joomla-field-subform` porte lui aussi un attribut `name` : un selecteur
   * sur `[name]` ramenait donc les listes imbriquees parmi les champs, et la
   * copie leur affectait une valeur. Mesure sur le banc le 21 septembre 2026 :
   * `elements=undefined` et `cartes=undefined` dans la liste des champs d'un
   * bloc.
   */
  function estUnChamp(noeud) {
    return noeud.tagName === 'INPUT'
      || noeud.tagName === 'SELECT'
      || noeud.tagName === 'TEXTAREA';
  }

  /** Les champs qui appartiennent en propre a cette ligne. */
  function champsPropres(ligne) {
    return [].slice.call(ligne.querySelectorAll('[name]')).filter(function (e) {
      return estUnChamp(e) && e.closest('.subform-repeatable-group') === ligne;
    });
  }

  /** Les listes imbriquees qui appartiennent en propre a cette ligne. */
  function listesPropres(ligne) {
    return [].slice.call(ligne.querySelectorAll('joomla-field-subform')).filter(function (sf) {
      return sf.closest('.subform-repeatable-group') === ligne;
    });
  }

  /** Recopie une ligne dans une autre, contenu compris. */
  function dupliquerLigne(source, cible) {
    var valeurs = {};

    champsPropres(source).forEach(function (champ) {
      var clef = clefDe(champ.name);

      if (clef === '' || clef === 'identifiant') { return; }

      if (champ.type === 'radio') {
        if (champ.checked) { valeurs[clef] = champ.value; }

        return;
      }

      if (champ.type === 'checkbox') {
        valeurs[clef] = champ.checked ? champ.value : '';

        return;
      }

      valeurs[clef] = champ.value;
    });

    /*
     * LE TYPE PASSE EN PREMIER, comme pour les modeles : les listes de contenu
     * sont derriere un `showon`, et une liste encore masquee ne recoit rien.
     */
    var ordonnees = {};

    if (Object.prototype.hasOwnProperty.call(valeurs, 'type')) {
      ordonnees.type = valeurs.type;
    }

    Object.keys(valeurs).forEach(function (k) {
      if (k !== 'type') { ordonnees[k] = valeurs[k]; }
    });

    remplirLigne(cible, ordonnees);

    // Et le contenu, liste par liste, dans l'ordre ou elles se presentent.
    var sources = listesPropres(source);
    var cibles  = listesPropres(cible);

    sources.forEach(function (sf, i) {
      var vers = cibles[i];

      if (!vers) { return; }

      rangeesDe(sf).forEach(function (fille) {
        var neuve = ajouterLigne(vers);

        if (neuve) { dupliquerLigne(fille, neuve); }
      });
    });
  }

  /**
   * POSE UN MODELE A LA SUITE DE CE QUI EXISTE DEJA.
   *
   * LE NUMERO DE RANGEE EST CALCULE, PAS ECRIT DANS LE MODELE. Les blocs
   * designent leur rangee par son rang, et le modele ne sait pas combien de
   * rangees existent avant lui : un `rangee: 1` en dur aurait envoye les blocs
   * du deuxieme tampon dans la rangee du premier.
   */
  /**
   * VIDER LE MONTAGE, RANGEES ET BLOCS, AVANT D'EN POSER UN AUTRE.
   *
   * `remplacement` COUPE LE MENAGE AUTOMATIQUE. Retirer une rangee declenche
   * normalement le retrait de ses blocs et la renumerotation des autres : ici
   * tout part, et laisser les deux mecaniques se courir apres ferait retirer
   * deux fois les memes lignes.
   *
   * ON RETIRE PAR LA FIN. Chaque retrait renumerote les lignes suivantes :
   * partir du debut, c'est viser a chaque tour une ligne qui a change de nom.
   */
  var remplacement = false;

  /*
   * LE DRAPEAU DU MENAGE VIT AVEC `remplacement`, PAS DANS `demarrer()`.
   *
   * Il y etait, et `viderMontage` levait donc `menage is not defined` : la
   * fenetre disait oui, et rien ne se passait. L erreur ne se voyait nulle
   * part parce qu elle tombait dans le `.then` de la promesse, qui l avale.
   * Mesure du 22 septembre 2026, apres le passage a la fenetre de Joomla.
   *
   * Les deux drapeaux commandent la meme chose, le dessin de la carte : ils
   * restent desormais cote a cote, au niveau du module, ou tout le monde les
   * voit.
   */
  var dessinDemande = null;
  var menage = false;

  function viderMontage() {
    var hoteRangees = document.querySelector('joomla-field-subform[name="jform[params][rangees]"]');
    var hoteBlocs   = document.querySelector('joomla-field-subform[name="jform[params][blocs]"]');

    remplacement = true;
    menage = true;

    [hoteBlocs, hoteRangees].forEach(function (hote) {
      if (!hote) { return; }

      rangeesDe(hote).reverse().forEach(function (ligne) {
        var moins = ligne.querySelector('.group-remove');

        if (moins) { moins.click(); }
      });
    });

    remplacement = false;
    menage = false;
  }

  /** Le montage porte-t-il quelque chose qu'un remplacement detruirait ? */
  function montageRempli() {
    var hoteRangees = document.querySelector('joomla-field-subform[name="jform[params][rangees]"]');
    var hoteBlocs   = document.querySelector('joomla-field-subform[name="jform[params][blocs]"]');

    return (hoteRangees && rangeesDe(hoteRangees).length > 0)
      || (hoteBlocs && rangeesDe(hoteBlocs).length > 0);
  }

  /**
   * UNE VIGNETTE REMPLACE LE MONTAGE, ET PREVIENT AVANT.
   *
   * Decision de Cyrille, 22 septembre 2026 : « il faut une alerte pour dire
   * quand on clique : attention tout va etre supprime ou remplace par les
   * elements du nouveau choix de montage ».
   *
   * CE N'EST PLUS UN TAMPON. Jusqu'a ce jour la vignette AJOUTAIT a la suite,
   * et il n'y avait aucun moyen de changer de mise en page sans vider le
   * montage a la main, ligne par ligne. Elle bascule desormais ; ce qui
   * s'ajoute, c'est le `+` de la liste des blocs.
   *
   * UNE CONFIRMATION NATIVE, PAS UNE FENETRE A NOUS. `confirm()` donne le
   * clavier, Echap, et la lecture d'ecran sans une ligne de code ; et une
   * suppression totale est exactement le cas ou une modale se justifie, parce
   * qu'elle demande d'arreter ce qu'on fait.
   */
  function choisirModele(cle) {
    if (!montageRempli()) {
      appliquerModele(cle);

      return;
    }

    var avertissement = texte(
      'MOD_OPUS_MODEL_REPLACE_WARN',
      'Attention : tout le montage actuel va etre supprime et remplace par la mise en page choisie.'
    );

    var titre = texte('MOD_OPUS_MODEL_REPLACE_TITLE', 'Remplacer la mise en page');

    var poser = function (oui) {
      if (!oui) { return; }

      viderMontage();
      appliquerModele(cle);
    };

    /*
     * LA FENETRE EST CELLE DE JOOMLA, PAS CELLE DU NAVIGATEUR.
     *
     * « Plutot que cette presentation d'erreur, tu ne peux pas utiliser une
     * fenetre popup Joomla ? », Cyrille, 22 septembre 2026. Il a raison sur le
     * fond : `confirm()` affiche « 127.0.0.1:8120 indique », ce qui ressemble
     * a une panne du navigateur et non a une question du module.
     *
     * `JoomlaDialog.confirm()` rend une promesse, relue dans
     * `media/system/js/joomla-dialog.js` l. 606 : vrai pour Oui, faux pour
     * Non. La classe se prend par `customElements`, puisque le fichier du
     * coeur est un module ES et n'expose rien sur `window`.
     *
     * LE REPLI RESTE. Si le composant n'a pas ete charge, mieux vaut la
     * fenetre du navigateur qu'une suppression sans question.
     */
    var Fenetre = window.customElements ? window.customElements.get('joomla-dialog') : null;

    if (Fenetre && typeof Fenetre.confirm === 'function') {
      /*
       * LE `.catch` N EST PAS DECORATIF. Une promesse avale les erreurs de
       * son `.then` : le 22 septembre 2026, `menage is not defined` y est
       * tombee, la fenetre repondait oui et la page ne bougeait pas, sans
       * une ligne dans la console. On les renvoie donc au moteur.
       */
      Fenetre.confirm(avertissement, titre).then(poser).catch(function (e) {
        window.setTimeout(function () { throw e; }, 0);
      });

      return;
    }

    poser(window.confirm(avertissement));
  }

  /**
   * Pose une ligne dans une liste, avec tout ce qu elle contient.
   *
   * UNE CLEF QUI PORTE UNE LISTE N EST PAS UN CHAMP. `boutons` ou `elements`
   * designent la liste imbriquee de la ligne, pas un champ nomme `[boutons]` :
   * les passer a `remplirLigne` lui ferait chercher un champ qui n existe pas,
   * et perdre le contenu en silence. On les met de cote, on remplit la ligne,
   * puis on recommence dessous.
   *
   * ELLE EST RECURSIVE DEPUIS LE 22 SEPTEMBRE 2026, et ce n est pas un luxe :
   * une carte est desormais une pile d elements, dont un porte ses boutons.
   * Cela fait quatre niveaux, `blocs > cartes > elements > boutons`, la ou la
   * pose deroulee n en savait poser que trois. Le quatrieme s etait perdu sans
   * un mot.
   */
  function poserLigne(hote, valeurs) {
    var ligne = ajouterLigne(hote);

    if (!ligne) { return null; }

    var listes = {};
    var champs = {};

    Object.keys(valeurs).forEach(function (k) {
      if (Array.isArray(valeurs[k])) {
        listes[k] = valeurs[k];
      } else {
        champs[k] = valeurs[k];
      }
    });

    remplirLigne(ligne, champs);

    Object.keys(listes).forEach(function (nom) {
      var fille = hoteListe(ligne, nom);

      listes[nom].forEach(function (v) { poserLigne(fille, v); });
    });

    return ligne;
  }

  function appliquerModele(cle) {
    var tous = modeles();
    var modele = tous[cle];

    if (!modele) { return; }

    var hoteRangees = document.querySelector('joomla-field-subform[name="jform[params][rangees]"]');
    var hoteBlocs   = document.querySelector('joomla-field-subform[name="jform[params][blocs]"]');

    if (!hoteRangees || !hoteBlocs) { return; }

    var premiere = rangeesDe(hoteRangees).length + 1;

    modele.rangees.forEach(function (valeurs) {
      var ligne = ajouterLigne(hoteRangees);

      if (ligne) { remplirLigne(ligne, valeurs); }
    });

    modele.blocs.forEach(function (bloc) {
      var ligne = ajouterLigne(hoteBlocs);

      if (!ligne) { return; }

      var champs = {};
      Object.keys(bloc.champs).forEach(function (k) { champs[k] = bloc.champs[k]; });
      champs.rangee = String(premiere);

      remplirLigne(ligne, champs);

      var sous = hoteListe(ligne, bloc.liste);

      (bloc.contenu || []).forEach(function (valeurs) {
        poserLigne(sous, valeurs);
      });
    });

    outillerTout();
    numeroterCartes();
    dessiner();
  }

  /** Une vignette : le dessin, puis le nom. */
  function vignette(classe, cellules) {
    var ap = document.createElement('span');
    ap.className = 'blocs-modele__ap ' + classe;

    for (var i = 0; i < cellules; i++) {
      ap.appendChild(document.createElement('i'));
    }

    return ap;
  }

  /*
   * LE CATALOGUE : LES FORMES DE BASE, PUIS CE QUI N'EXISTE PAS ENCORE. Les
   * modeles a maquetter sont la pour que l'on voie ou l'on va ; ils ne sont
   * pas cliquables, et le disent.
   *
   * AUCUNE COMBINAISON TOUTE FAITE ICI, ET C'EST LA REGLE. Decision de Cyrille
   * du 22 septembre 2026 : « je veux avoir des formes de base et ensuite les
   * combiner ». « Ouverture et cartes » etait une ouverture et des cartes
   * posees ensemble, donc un assemblage que l'administrateur obtient deja en
   * cliquant les deux formes l'une apres l'autre. Livrer les assemblages, ce
   * serait livrer toutes leurs variantes, et le panneau deviendrait un
   * catalogue que personne ne lit.
   *
   * CONSEQUENCE POUR LA SUITE : une forme nouvelle entre ici quand elle
   * n'est PAS obtenable en combinant celles qui existent.
   *
   * DEUX ENTREES SONT SORTIES LE 23 SEPTEMBRE 2026, par application de cette
   * regle et non par manque de temps :
   *
   * - « Texte et image » etait une rangee a deux colonnes avec une ouverture
   *   d'un cote et une ouverture ne portant qu'une image de l'autre. Cyrille
   *   l'a composee lui-meme sur le banc, sans une ligne de code : c'est un
   *   assemblage, pas une forme.
   * - « Portraits » etait une grille de cartes dont l'image est ronde et
   *   carree (`imgHabillage: ronde`, `imgFormat: 1-1`), un titre et une ligne
   *   de fonction. Depuis que l'habillage rond existe, c'est un reglage des
   *   Cartes, pas une forme de plus.
   *
   * RESTENT QUATRE FORMES, et les deux dernieres sont arrivees le meme jour :
   * la galerie, parce qu'une grille d'images a legendes n'est pas une grille
   * de cartes (une figure, une legende liee, un agrandissement), et le
   * carrousel, parce que rien de ce qui existe ne fait defiler.
   */
  function catalogue() {
    return [
      /*
       * LA VIGNETTE GARDE LE MOT « OUVERTURE », LE TYPE DE BLOC NON.
       *
       * Arbitrage de Cyrille, 23 septembre 2026 : le type s'appelle desormais
       * « Bloc simple », parce qu'on l'emploie partout, y compris pour un
       * sommaire en bas de colonne, et que « Ouverture » promettait un haut de
       * page. La vignette, elle, pose bien un haut de page : elle garde donc
       * son nom, et les deux clefs de langue sont distinctes.
       */
      { cle: 'ouverture', nom: texte('MOD_OPUS_MODEL_OPENING', 'Ouverture'), ap: 'blocs-modele__ap--pile', cases: 3 },
      { cle: 'cartes', nom: texte('MOD_OPUS_BLOCK_CARDS', 'Cartes'), ap: 'blocs-modele__ap--3', cases: 3 },
      { cle: 'galerie', nom: texte('MOD_OPUS_BLOCK_GALLERY', 'Galerie'), ap: 'blocs-modele__ap--6', cases: 6 },
      { cle: 'carrousel', nom: texte('MOD_OPUS_BLOCK_CAROUSEL', 'Carrousel'), ap: 'blocs-modele__ap--1', cases: 1 },
      { cle: 'accueil', nom: texte('MOD_OPUS_MODEL_HOME', 'Accueil'), ap: 'blocs-modele__ap--accueil', cases: 3 },
      { cle: 'etats', nom: texte('MOD_OPUS_MODEL_STATES', 'Cartes a etat'), ap: 'blocs-modele__ap--etats', cases: 3 },
      { cle: 'portraits', nom: texte('MOD_OPUS_MODEL_PORTRAITS', 'Portraits'), ap: 'blocs-modele__ap--portraits', cases: 6 },
      { cle: 'temoignages', nom: texte('MOD_OPUS_MODEL_QUOTES', 'Temoignages'), ap: 'blocs-modele__ap--temoignages', cases: 3 },
      { cle: 'logos', nom: texte('MOD_OPUS_MODEL_LOGOS', 'Logos'), ap: 'blocs-modele__ap--6', cases: 6 },
      { cle: 'etapes', nom: texte('MOD_OPUS_MODEL_STEPS', 'Etapes'), ap: 'blocs-modele__ap--etapes', cases: 4 },
      { cle: 'tarifs', nom: texte('MOD_OPUS_MODEL_PRICES', 'Tarifs'), ap: 'blocs-modele__ap--tarifs', cases: 2 },
      { cle: 'faq', nom: texte('MOD_OPUS_MODEL_FAQ', 'FAQ'), ap: 'blocs-modele__ap--accordeon', cases: 3 },
      { cle: 'appel', nom: texte('MOD_OPUS_MODEL_CTA', 'Bandeau d\'appel'), ap: 'blocs-modele__ap--appel', cases: 2 },
      { cle: 'comparaison', nom: texte('MOD_OPUS_MODEL_COMPARE', 'Comparaison'), ap: 'blocs-modele__ap--comparaison', cases: 4 },
      { cle: 'coordonnees', nom: texte('MOD_OPUS_MODEL_CONTACT', 'Coordonnees'), ap: 'blocs-modele__ap--coordonnees', cases: 6 },
      { cle: 'preuves', nom: texte('MOD_OPUS_MODEL_PROOF', 'Chiffres verifiables'), ap: 'blocs-modele__ap--preuves', cases: 6 },
      { cle: 'repartition', nom: texte('MOD_OPUS_MODEL_BARS', 'Repartition'), ap: 'blocs-modele__ap--barres', cases: 4 },
      { cle: 'onglets', nom: texte('MOD_OPUS_MODEL_TABS', 'Onglets et image'), ap: 'blocs-modele__ap--onglets', cases: 4 },
      { cle: 'frise', nom: texte('MOD_OPUS_MODEL_TIMELINE', 'Frise'), ap: 'blocs-modele__ap--frise', cases: 4 },
      { cle: 'tuiles', nom: texte('MOD_OPUS_MODEL_TILES', 'Tuiles'), ap: 'blocs-modele__ap--tuiles', cases: 6 },
      { cle: 'mosaique', nom: texte('MOD_OPUS_MODEL_MOSAIC', 'Mosaique'), ap: 'blocs-modele__ap--mosaique', cases: 8 },
      { cle: 'atouts', nom: texte('MOD_OPUS_MODEL_BENEFITS', 'Atouts'), ap: 'blocs-modele__ap--atouts', cases: 6 }
    ];
  }

  /*
   * LES BRIQUES : UNE OUVERTURE, UN SEUL ELEMENT DEDANS.
   *
   * Elles vivent a cote du catalogue, et non dedans, parce qu'elles ne
   * repondent pas a la meme question. Le catalogue dit « quelle forme » ; les
   * briques disent « quelle piece ». Melangees, on ne saurait plus lequel des
   * deux on choisit.
   */
  function briques() {
    return [
      { cle: 'uniqueTitre', nom: texte('MOD_OPUS_ELEMENT_HEADING', 'Titre'), ap: 'blocs-modele__ap--titre', cases: 1 },
      { cle: 'uniqueSousTitre', nom: texte('MOD_OPUS_ELEMENT_SUBHEADING', 'Sous-titre'), ap: 'blocs-modele__ap--soustitre', cases: 1 },
      { cle: 'uniqueTexte', nom: texte('MOD_OPUS_ELEMENT_TEXT', 'Texte'), ap: 'blocs-modele__ap--texte', cases: 3 },
      { cle: 'uniqueImage', nom: texte('MOD_OPUS_BLOCK_IMAGE', 'Image'), ap: 'blocs-modele__ap--image', cases: 1 },
      { cle: 'uniqueBoutons', nom: texte('MOD_OPUS_ELEMENT_BUTTONS', 'Boutons'), ap: 'blocs-modele__ap--boutons', cases: 2 },
      { cle: 'uniqueListe', nom: texte('MOD_OPUS_ELEMENT_LIST', 'Liste'), ap: 'blocs-modele__ap--liste', cases: 6 },
      { cle: 'uniqueAlerte', nom: texte('MOD_OPUS_ELEMENT_ALERT', 'Alerte'), ap: 'blocs-modele__ap--alerte', cases: 2 },
      { cle: 'uniquePoints', nom: texte('MOD_OPUS_ELEMENT_POINTS', 'Points cles'), ap: 'blocs-modele__ap--points', cases: 4 },
      { cle: 'uniqueCitation', nom: texte('MOD_OPUS_ELEMENT_QUOTE', 'Citation'), ap: 'blocs-modele__ap--citation', cases: 2 },
      { cle: 'uniqueEtat', nom: texte('MOD_OPUS_ELEMENT_STATE', 'Etat'), ap: 'blocs-modele__ap--etat', cases: 1 },
      { cle: 'uniqueChiffres', nom: texte('MOD_OPUS_ELEMENT_FIGURES', 'Chiffres cles'), ap: 'blocs-modele__ap--chiffres', cases: 3 },
      { cle: 'uniqueBarres', nom: texte('MOD_OPUS_ELEMENT_BARS', 'Barres'), ap: 'blocs-modele__ap--barres', cases: 4 },
      { cle: 'uniqueAccordeon', nom: texte('MOD_OPUS_ELEMENT_ACCORDION', 'Accordeon'), ap: 'blocs-modele__ap--accordeon', cases: 3 },
      { cle: 'uniqueAdresse', nom: texte('MOD_OPUS_ELEMENT_ADDRESS', 'Adresse'), ap: 'blocs-modele__ap--adresse', cases: 3 },
      { cle: 'uniqueContact', nom: texte('MOD_OPUS_ELEMENT_CONTACT', 'Contact'), ap: 'blocs-modele__ap--contact', cases: 3 },
      { cle: 'uniqueLiens', nom: texte('MOD_OPUS_ELEMENT_LINKS', 'Liens'), ap: 'blocs-modele__ap--liens', cases: 3 },
      { cle: 'uniqueFiche', nom: texte('MOD_OPUS_ELEMENT_SPECS', 'Fiche'), ap: 'blocs-modele__ap--fiche', cases: 6 },
      { cle: 'uniqueSeparateur', nom: texte('MOD_OPUS_ELEMENT_SEPARATOR', 'Separateur'), ap: 'blocs-modele__ap--filet', cases: 1 }
    ];
  }

  /* ==========================================================================
     LES SECTIONS PLIABLES

     LA MAQUETTE EN FAIT DES `fieldset` : un contour, un rayon, la legende en
     ligne avec un chevron carre, et `fieldset.replie > *:not(legend)` qui
     cache le reste (l. 38 a 40 de `maquette-module-corpus_3.html`).

     ICI CE SONT DES `div`, ET C'EST OBLIGE. Un `fieldset` porte deja un sens
     dans un formulaire Joomla, et com_modules en fabrique un par onglet : en
     imbriquer d'autres brouillerait l'arbre lu par les lecteurs d'ecran. Le
     dessin est le meme, le balisage non.
     ========================================================================== */

  /** Le chevron carre d'une section, et le pli qu'il commande. */
  /**
   * Le chevron d'une boite, et le pli qu'il commande.
   *
   * `replier` DIT CE QUE PLIER VEUT DIRE, ET CHAQUE APPELANT LE SAIT SEUL.
   *
   * J'avais mis ce savoir ici : « masquer tous les enfants de la boite sauf
   * l'en-tete ». Vrai pour les deux panneaux du flanc, que le script fabrique
   * de bout en bout. FAUX pour une section du manifeste, ou la boite est
   * l'enveloppe du titre : le titre lui-meme y etait masque, et le chevron
   * avec. « Quand je ferme les blocs tout disparait », 21 septembre 2026, et
   * il n'y avait plus aucun bouton pour rouvrir.
   *
   * Le chevron ne connait donc plus que son bouton et sa classe. Ce qui
   * disparait, c'est l'appelant qui le nomme.
   */
  function poserChevron(section, titre, replie, replier) {
    if (!section.id) {
      section.id = 'blocs-section-' + (++poserChevron.compteur);
    }

    var bouton = document.createElement('button');
    bouton.type = 'button';
    bouton.className = 'blocs-chevron';
    bouton.setAttribute('aria-expanded', replie ? 'false' : 'true');
    bouton.setAttribute('aria-controls', section.id);
    bouton.setAttribute('aria-label', texte('MOD_OPUS_FOLD', 'Plier ou deplier'));

    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');

    var trait = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    trait.setAttribute('d', 'M6 9l6 6 6-6');
    svg.appendChild(trait);
    bouton.appendChild(svg);

    bouton.addEventListener('click', function () {
      var ferme = section.classList.toggle('blocs-section--replie');
      bouton.setAttribute('aria-expanded', ferme ? 'false' : 'true');

      if (replier) { replier(ferme); }
    });

    titre.insertBefore(bouton, titre.firstChild);
  }

  poserChevron.compteur = 0;

  /** Une pastille d'aide posee a droite d'un intitule de section. */
  function pastilleDe(titre, aide) {
    if (!aide) { return; }

    var pastille = document.createElement('span');
    pastille.className = 'icon-info-circle';
    pastille.setAttribute('tabindex', '0');

    var bulle = document.createElement('div');
    bulle.setAttribute('role', 'tooltip');
    bulle.textContent = aide;

    titre.appendChild(pastille);
    titre.appendChild(bulle);
  }

  /** Une boite pliable toute neuve, avec son intitule. */
  function section(intitule, replie, aide) {
    var boite = document.createElement('div');
    boite.className = 'blocs-section' + (replie ? ' blocs-section--replie' : '');

    var titre = document.createElement('h3');
    titre.className = 'legend blocs-section__tete';
    titre.appendChild(document.createTextNode(intitule));
    boite.appendChild(titre);

    /*
     * ICI, PLIER C'EST MASQUER LES ENFANTS DE LA BOITE, l'en-tete excepte.
     * L'attribut `hidden` plutot qu'une regle de feuille : une regle peut
     * perdre un duel de specificite sans rien signaler, un attribut non.
     */
    poserChevron(boite, titre, replie, function (ferme) {
      [].slice.call(boite.children).forEach(function (enfant) {
        if (enfant === titre) { return; }

        enfant.hidden = ferme;
      });
    });

    pastilleDe(titre, aide);

    return boite;
  }

  /**
   * ENCADRE LES SECTIONS AVEC TROIS CLASSES, ET RIEN DE PLUS.
   *
   * TROISIEME ECRITURE, ET LA BONNE. La premiere enveloppait les champs dans
   * un `div` : elle deconnectait les composants du coeur. La deuxieme
   * dessinait un cadre absolu par-dessus : il fallait mesurer, observer,
   * remesurer, et les cadres finissaient collants les uns aux autres, sans
   * marge. Mesure du 21 septembre 2026 : 180..493, 494..2686, 2687..3153.
   *
   * CELLE-CI NE MESURE RIEN ET NE DEPLACE RIEN. Elle pose trois classes, et
   * la feuille trace le trait : le haut sur l'intitule, les cotes sur chaque
   * champ, le bas sur le dernier. Un bord dessine sur les elements eux-memes
   * suit leur hauteur sans qu'on la calcule, et les marges sont celles de la
   * feuille, la ou on les lit.
   *
   * Ce qui disparait avec cette version : la mesure, `ResizeObserver`, l'ecoute
   * du redimensionnement, l'evenement de remesure et le placement absolu.
   */
  function marquerSections() {
    var fs = document.getElementById(FIELDSET);

    if (!fs) { return; }

    var grille = [].slice.call(fs.children).filter(function (c) {
      return c.classList.contains('form-grid');
    })[0];

    if (!grille || grille.dataset.opusCadres) { return; }

    var groupes = [];
    var courant = null;

    [].slice.call(grille.children).forEach(function (noeud) {
      /*
       * COTE SITE, CHAQUE GROUPE EST DANS UN `li` : `com_config` rend les
       * champs en liste (`default_options.php`). On regarde le groupe qu'il
       * porte ; le `li`, lui, passe en `display: contents` dans la feuille.
       */
      if (noeud.tagName === 'LI' && noeud.firstElementChild) { noeud = noeud.firstElementChild; }

      var titre = noeud.classList.contains('top-legend-group')
        ? noeud.querySelector('h3.legend')
        : null;

      if (titre) {
        courant = { tete: noeud, titre: titre, membres: [] };
        groupes.push(courant);

        return;
      }

      if (courant) { courant.membres.push(noeud); }
    });

    /*
     * `legend.js` de Corpus remanie les legendes au chargement : selon l'ordre
     * des ecouteurs, on peut passer avant elles. On retente, sans se declarer
     * fait, et l'on cesse au bout de trois secondes.
     */
    if (groupes.length === 0) {
      marquerSections.essais = (marquerSections.essais || 0) + 1;

      if (marquerSections.essais < 10) { window.setTimeout(marquerSections, 300); }

      return;
    }

    grille.dataset.opusCadres = '1';
    grille.classList.add('blocs-grille');

    groupes.forEach(function (g) {
      g.tete.classList.add('blocs-tete');
      g.membres.forEach(function (m) { m.classList.add('blocs-corps'); });

      /*
       * « LES BLOCS », PUIS « BLOCS » JUSTE DESSOUS : UN DE TROP.
       *
       * Remarque de Cyrille le 22 septembre 2026. Le titre de la section vient
       * d'un champ `legend` du manifeste, l'intitule d'en dessous est celui du
       * sous-formulaire : deux fois le meme mot, a deux lignes d'ecart.
       *
       * ON NE MASQUE QUE SI C'EST VRAIMENT UN DOUBLE. Le titre doit contenir
       * l'intitule : « Les blocs » contient « Blocs », « Les rangees » contient
       * « Rangees ». Un intitule qui dit autre chose reste affiche, et c'est
       * voulu : la regle ne connait aucun nom de champ par coeur.
       *
       * L'AIDE NE SE PERD PAS, ELLE MONTE. La pastille de l'intitule masque
       * serait masquee avec lui : son texte est recopie dans une pastille
       * neuve, a droite du titre. Rien n'est deplace, tout est recree.
       */
      var premier = g.membres[0];
      var etiquette = premier && premier.querySelector(':scope > .control-label > label');

      if (etiquette) {
        var copie = etiquette.cloneNode(true);

        [].slice.call(copie.querySelectorAll('.icon-info-circle, [role="tooltip"]'))
          .forEach(function (n) { n.remove(); });

        var mot = copie.textContent.trim();
        var chapeau = g.titre.textContent.trim();

        if (mot !== '' && chapeau.toLowerCase().indexOf(mot.toLowerCase()) !== -1) {
          var bulle = etiquette.querySelector('[role="tooltip"]');

          pastilleDe(g.titre, bulle ? bulle.textContent.trim() : '');
          premier.classList.add('blocs-titre-double');
        }
      }

      if (g.membres.length) {
        g.membres[g.membres.length - 1].classList.add('blocs-fin');
      } else {
        g.tete.classList.add('blocs-seule');
      }

      /*
       * ICI, PLIER C'EST MASQUER LES VOISINS, pas les enfants : la boite est
       * l'enveloppe du titre, et les champs de la section sont ses freres.
       */
      poserChevron(g.tete, g.titre, false, function (ferme) {
        g.membres.forEach(function (m) { m.hidden = ferme; });

        // Repliee, la boite se ferme sur son intitule : il porte alors le
        // trait du bas et les quatre angles.
        g.tete.classList.toggle('blocs-seule', ferme);
      });
    });
  }

  /**
   * LE PANNEAU DES MODELES, REPLIE.
   *
   * Replie au depart, parce qu'on choisit un modele une fois et qu'on regarde
   * la carte du montage tout le temps.
   */
  /** Une grille de vignettes, pour une famille donnee. */
  /**
   * ALLUMER LES VIGNETTES DONT LE CONTENU EST DEJA POSE.
   *
   * LA TABLE DIT CE QUE CHAQUE VIGNETTE POSE, et elle est lue dans les modeles
   * eux-memes : aucune liste a tenir a jour. Un modele pose des blocs qui ont
   * un `type`, et des elements qui en ont un aussi ; on ramasse les deux.
   *
   * ELLE SE RECALCULE A CHAQUE REDESSIN, au meme rythme que la carte du
   * montage : ajouter une galerie doit allumer sa vignette sans recharger.
   */
  /*
   * LA SIGNATURE D'UN MODELE : CHAQUE TYPE AVEC SON NOMBRE.
   *
   * « Pourquoi si je clique sur Accueil et que j'enregistre, j'ai aussi
   * Ouverture et Bandeau d'appel qui ont une bordure ? », Cyrille, 24 septembre
   * 2026. La premiere version demandait seulement que TOUS les types du modele
   * soient PRESENTS dans le montage. Or Ouverture et Bandeau d'appel n'emploient
   * que des types qu'Accueil emploie aussi : poser Accueil les rendait vrais
   * tous les trois, mecaniquement. Un sous-ensemble passait pour l'ensemble.
   *
   * ON COMPARE DONC LES NOMBRES, PAS LA PRESENCE. Deux titres et un bouton ne
   * valent pas un titre et un bouton. Un sous-ensemble echoue alors, puisqu'il
   * lui manque forcement une unite quelque part.
   *
   * L'ORDRE N'ENTRE PAS DANS LA COMPARAISON : la signature est triee. Remonter
   * un bloc dans le montage ne doit pas eteindre la marque, ce n'est pas un
   * autre montage.
   */
  function signature(comptes) {
    return Object.keys(comptes).sort().map(function (t) {
      return t + '*' + comptes[t];
    }).join('|');
  }

  /*
   * LES TYPES D'ELEMENTS D'UN MODELE, SANS LE TYPE DU BLOC QUI LES PORTE.
   *
   * « Pourquoi dans la liste j'ai tous les elements avec une bordure ? »,
   * Cyrille, 24 septembre 2026. La premiere version ramassait aussi
   * `bloc.champs.type`, qui vaut `ouverture` pour toutes les briques sans
   * exception. Un montage quelconque pose forcement un bloc, donc `ouverture`
   * etait toujours present, donc les quinze briques s'allumaient ensemble. La
   * marque ne disait plus rien.
   *
   * ON NE REGARDE DONC QUE LE CONTENU. Une brique est un element, elle se
   * mesure a son element.
   */
  function typesDuModele(cle) {
    var modele = modeles()[cle];

    if (!modele) { return []; }

    var vus = {};

    (modele.blocs || []).forEach(function (bloc) {
      (bloc.contenu || []).forEach(function (ligne) {
        if (ligne.type) { vus[ligne.type] = 1; }

        (ligne.elements || []).forEach(function (el) {
          if (el.type) { vus[el.type] = 1; }
        });
      });
    });

    return Object.keys(vus);
  }

  function signatureDuModele(cle) {
    var modele = modeles()[cle];

    if (!modele) { return ''; }

    var vus = {};

    function compte(t) {
      if (t) { vus[t] = (vus[t] || 0) + 1; }
    }

    (modele.blocs || []).forEach(function (bloc) {
      if (bloc.champs) { compte(bloc.champs.type); }

      (bloc.contenu || []).forEach(function (ligne) {
        compte(ligne.type);

        (ligne.elements || []).forEach(function (el) { compte(el.type); });
      });
    });

    return signature(vus);
  }

  function allumerModeles() {
    var vus = {};

    [].slice.call(document.querySelectorAll('#' + FIELDSET + ' select[name$="[type]"]'))
      .forEach(function (sel) {
        if (sel.value) { vus[sel.value] = (vus[sel.value] || 0) + 1; }
      });

    var ici = signature(vus);

    [].slice.call(document.querySelectorAll('#blocs-modeles .blocs-modele'))
      .forEach(function (case_) {
        var cle = case_.dataset.cle;

        if (!cle) { return; }

        var marque;

        if (case_.dataset.forme === 'brique') {
          marque = (typesDuModele(cle) || []).some(function (t) { return vus[t]; });
        } else {
          var sienne = signatureDuModele(cle);

          marque = sienne !== '' && sienne === ici;
        }

        case_.classList.toggle('blocs-modele--pose', marque);
      });
  }

  /** Le compte des entrees, entre parentheses, colle a droite d'un intitule. */
  function compter(hote, combien) {
    if (!hote) { return; }

    var mot = document.createElement('span');
    mot.className = 'blocs-modeles__compte';
    mot.textContent = '(' + combien + ')';

    /*
     * `aria-hidden` : LE NOMBRE EST UN REPERE POUR L'OEIL, PAS UNE
     * INFORMATION. Un lecteur d'ecran annonce deja le nombre d'elements d'une
     * liste ; le repeter dans le titre ferait entendre « Choisir une mise en
     * page (19) », qui ne veut rien dire.
     */
    mot.setAttribute('aria-hidden', 'true');

    /*
     * IL SE POSE JUSTE APRES LE MOT, PAS AU BOUT DE LA LIGNE. L'intitule du
     * panneau porte aussi une pastille d'aide, ajoutee ailleurs : un simple
     * `appendChild` mettrait le compte derriere elle. On cherche donc le
     * premier noeud de texte non vide, qui est l'intitule lui-meme, et on
     * glisse le compte a sa suite. Sans ce noeud, on retombe sur la fin.
     */
    var mots = null;

    for (var i = 0; i < hote.childNodes.length; i++) {
      var n = hote.childNodes[i];

      if (n.nodeType === 3 && n.textContent.trim() !== '') { mots = n; break; }
    }

    if (mots && mots.nextSibling) {
      hote.insertBefore(mot, mots.nextSibling);
    } else {
      hote.appendChild(mot);
    }
  }

  function grilleDeModeles(items, remplace) {
    var grille = document.createElement('div');
    grille.className = 'blocs-modeles__grille';

    items.forEach(function (item) {
      var pret = !!item.cle;
      var case_ = document.createElement(pret ? 'button' : 'span');

      case_.className = 'blocs-modele' + (pret ? '' : ' blocs-modele--attente');

      if (pret) {
        case_.type = 'button';
        case_.addEventListener('click', function () {
          /*
           * UNE BRIQUE S'AJOUTE, UNE MISE EN PAGE REMPLACE.
           *
           * `choisirModele` demande confirmation et vide le montage : c'est
           * juste pour une forme entiere, qui redefinit la page. Une brique,
           * elle, se pose A LA SUITE, comme un tampon : on en met trois, on
           * les range, on recommence. Lui faire effacer le montage la rendrait
           * inutilisable, et personne n'oserait plus la cliquer.
           */
          if (remplace) {
            choisirModele(item.cle);

            return;
          }

          appliquerModele(item.cle);
        });
      }

      /*
       * LA VIGNETTE DIT CE QUI EST DEJA DANS LE MONTAGE.
       *
       * « Dans la liste des mises en page, il faudrait une bordure de couleur
       * pour dire laquelle est active », Cyrille, 24 septembre 2026.
       *
       * « ACTIVE » DEMANDE UNE DEFINITION, et c'est tout le sujet. Ces
       * vignettes sont des TAMPONS : un clic pose quelque chose, il ne
       * selectionne rien, et rien ne garde le souvenir du tampon employe. Un
       * montage fait a la main n'est issu d'aucune vignette.
       *
       * DEUX MESURES, PARCE QU'IL Y A DEUX SORTES DE VIGNETTES.
       *
       * UNE MISE EN PAGE SE COMPARE EN ENTIER : sa signature, c'est-a-dire
       * chaque type avec son nombre, doit etre exactement celle du montage.
       * C'est la correction du 24 septembre 2026. La version d'avant demandait
       * seulement que ses types soient presents, et « Ouverture » comme
       * « Bandeau d'appel » s'allumaient des qu'on posait « Accueil », dont ils
       * sont des sous-ensembles. La vignette disait alors une chose fausse.
       *
       * UNE BRIQUE SE CONTENTE D'ETRE LA : elle ne pretend pas definir la page,
       * elle s'y ajoute. « Titre » s'allume donc des qu'un titre est pose, ce
       * qui est ce qu'elle promet, et rien de plus.
       */
      case_.dataset.cle = item.cle || '';
      /*
       * LA NATURE DE LA VIGNETTE, pour que la marque sache quoi mesurer : une
       * mise en page se compare en entier, une brique se contente d'etre la.
       * Voir `allumerModeles`.
       */
      case_.dataset.forme = remplace ? 'montage' : 'brique';
      case_.appendChild(vignette(item.ap, item.cases));

      var nom = document.createElement('span');
      nom.className = 'blocs-modele__nom';
      nom.textContent = item.nom;
      case_.appendChild(nom);

      if (!pret) {
        var etat = document.createElement('small');
        etat.textContent = texte('MOD_OPUS_MODEL_TODO', 'a maquetter');
        case_.appendChild(etat);
      }

      grille.appendChild(case_);
    });

    return grille;
  }

  function panneauModeles() {
    var panneau = section(
      texte('MOD_OPUS_MODELS_TITLE', 'Choisir une mise en page'),
      true,
      texte('MOD_OPUS_MODELS_DESC', '')
    );
    panneau.id = 'blocs-modeles';

    /*
     * LE NOMBRE A DROITE DE L'INTITULE.
     *
     * « Ajoute le nombre de mises en page a sa droite, et idem a droite de Ou
     * un seul element », Cyrille, 24 septembre 2026. Dix-neuf formes et quinze
     * briques : le compte dit d'un coup d'oeil ce que le panneau contient, et
     * il dit surtout qu'il en contient BEAUCOUP, ce qu'une grille repliee ne
     * laisse pas deviner.
     *
     * IL EST CALCULE, JAMAIS ECRIT : un modele ajoute demain le fait monter
     * tout seul.
     */
    compter(panneau.querySelector('.blocs-section__tete'), catalogue().length);

    panneau.appendChild(grilleDeModeles(catalogue(), true));

    /*
     * LES BRIQUES, SOUS LEUR PROPRE INTITULE.
     *
     * « Il me faut les champs en mode unique, pour faire des combinaisons »,
     * Cyrille, 23 septembre 2026. Elles sont dans le meme panneau parce qu'on
     * y vient pour la meme raison, poser quelque chose ; elles ont leur
     * intitule parce qu'elles ne remplacent pas le montage, elles s'y ajoutent.
     */
    var titre = document.createElement('p');
    titre.className = 'blocs-modeles__famille';
    titre.textContent = texte('MOD_OPUS_BRICKS_TITLE', 'Ou un seul element');
    compter(titre, briques().length);
    panneau.appendChild(titre);

    panneau.appendChild(grilleDeModeles(briques(), false));

    return panneau;
  }

  function poser() {
    var fs = document.getElementById(FIELDSET);
    if (!fs || document.getElementById('blocs-carte')) { return false; }

    /*
     * LES DEUX PANNEAUX PARTAGENT UNE COLONNE, ET C'EST CE QUI LES COLLE.
     *
     * La grille du vis-a-vis est posee sur `fieldset.options-form`, et une
     * grille ne place que ses enfants DIRECTS. Deux enfants separes auraient
     * pris deux rangees de cette grille, dont la hauteur est dictee par la
     * colonne des reglages : le panneau des modeles se serait retrouve a
     * flotter loin de la carte. Un seul enfant, et les deux s'empilent dedans.
     */
    var flanc = document.createElement('div');
    flanc.id = 'blocs-flanc';

    flanc.appendChild(panneauModeles());

    /*
     * LA CARTE AUSSI EST UNE SECTION, et son intitule quitte donc son corps.
     * `dessiner()` vide `#blocs-carte` a chaque redessin : un titre pose
     * dedans aurait ete efface puis reecrit vingt fois, et le chevron avec.
     */
    var boite = section(texte('MOD_OPUS_MAP_TITLE', 'Ce qui sortira'), false, '');
    boite.classList.add('blocs-section--carte');

    var carte = document.createElement('div');
    carte.id = 'blocs-carte';
    carte.className = 'blocs-carte';
    boite.appendChild(carte);
    flanc.appendChild(boite);

    // Le panneau des reglages vit sous la carte, dans la meme colonne collante.
    flanc.appendChild(construirePanneau());

    fs.appendChild(flanc);

    return true;
  }

  /**
   * LES BLOCS N'ATTENDENT PLUS PERSONNE, 25 septembre 2026.
   *
   * Jusqu'au 25 septembre 2026, la classe `top-legend-group` sur laquelle le
   * decoupage s'appuie etait posee par `legend.js` de Corpus, dans un rappel
   * jQuery « ready » qui passe APRES les ecouteurs natifs. Il fallait donc
   * attendre son signal, `corpus:formulaire-pret`, avec un delai de secours.
   *
   * Opus porte desormais son propre champ de titre (`field/opuslegende.php`)
   * et le manifeste pose la classe par `parentclass` : elle est dans le HTML
   * des le chargement. On garde un tour de boucle, pour laisser les elements
   * personnalises du coeur (`joomla-field-subform`) se brancher avant nous.
   */
  function quandLeFormulaireEstPret(faire) {
    window.setTimeout(faire, 0);
  }

  /**
   * LA JAUGE DU CSS PERSONNALISE.
   *
   * POURQUOI ELLE EXISTE, ET CE N'EST PAS UNE COQUETTERIE. Tous les reglages
   * d'un module tiennent dans UNE colonne de la base, `#__modules.params`, et
   * MySQL la declare en `text` : 65 535 octets. Au-dela, l'enregistrement se
   * TRONQUE, sans message et sans erreur. On perd la fin de sa saisie et on
   * l'apprend en relisant. La maquette `maquette-module-corpus_3.html` le dit
   * a cet endroit precis, et c'est la seule piece de son panneau CSS qui
   * manquait au module.
   *
   * ON MESURE TOUT LE FORMULAIRE, PAS LA SEULE FEUILLE. C'est l'ensemble des
   * reglages qui remplit la colonne : trente elements bien remplis y entrent
   * pour bien plus que le CSS. Une jauge qui ne compterait que le CSS
   * rassurerait a tort.
   *
   * EN OCTETS ET NON EN CARACTERES : « é » pese deux octets en UTF-8, et c'est
   * la limite de MySQL qui compte, pas celle de JavaScript. `TextEncoder` le
   * sait, `length` non.
   *
   * LE MOT EST ECRIT, LA BARRE NE FAIT QUE L'ILLUSTRER : une barre qui
   * rougirait sans rien dire ne serait lue par personne au lecteur d'ecran,
   * et la perte est silencieuse par nature.
   */
  function jauger() {
    var zone = zoneCss();

    if (!zone) { return; }

    var groupe = zone.closest('.control-group');

    if (!groupe) { return; }

    var LIMITE = 65535;

    var barre = groupe.querySelector('.blocs-jauge');
    var mot;

    if (!barre) {
      barre = document.createElement('div');
      barre.className = 'blocs-jauge';
      barre.appendChild(document.createElement('i'));

      mot = document.createElement('p');
      mot.className = 'blocs-jauge__mot';

      var apres = blocCss(zone).parentNode;
      apres.appendChild(barre);
      apres.appendChild(mot);
    } else {
      mot = groupe.querySelector('.blocs-jauge__mot');
    }

    var mesurer = function () {
      var form = zone.closest('form');

      if (!form) { return; }

      /*
       * ON MESURE LE JSON, PAS LE FORMULAIRE, ET L'ECART EST ENORME.
       *
       * « C'est notre construction qui prend autant de place ? Il me semblait
       * qu'elle etait legere, au contraire d'un page builder. » Cyrille,
       * 24 septembre 2026. Question juste, et c'etait la jauge qui mentait.
       *
       * Mesure faite sur son propre module : ma premiere version annoncait
       * 50 070 octets, le JSON reellement enregistre en pesait 12 448. Trois
       * quarts de trop.
       *
       * LA CAUSE : j'additionnais la valeur de chaque champ ET LA LONGUEUR DE
       * SON NOM DANS LE FORMULAIRE. Or un nom de formulaire est un chemin
       * complet, `jform[params][blocs][blocs0][cartes][cartes0][elements]
       * [elements0][chiffres][chiffres0][classeValeur]`, une centaine de
       * caracteres ; dans le JSON, la meme chose s'ecrit `classeValeur`, douze.
       * Sept cent quatre-vingts champs, et l'erreur se multiplie d'autant.
       *
       * ON RECONSTRUIT DONC L'ARBRE que Joomla va enregistrer, a partir des
       * crochets des noms, et on pese son JSON. C'est exactement ce qui part
       * en base, aux guillemets pres.
       *
       * ET LA REPONSE A SA QUESTION EST OUI : ce module est leger. Un montage
       * complet de dix-neuf blocs tient dans un cinquieme de la place.
       */
      var arbre = {};

      [].slice.call(form.elements).forEach(function (champ) {
        if (!champ.name || champ.name.indexOf('jform[params]') !== 0) { return; }
        if ((champ.type === 'checkbox' || champ.type === 'radio') && !champ.checked) { return; }

        var clefs = (champ.name.match(/\[([^\]]*)\]/g) || []).map(function (c) {
          return c.slice(1, -1);
        }).slice(1);

        if (!clefs.length) { return; }

        var noeud = arbre;

        clefs.forEach(function (clef, i) {
          if (i === clefs.length - 1) {
            noeud[clef] = String(champ.value || '');
            return;
          }

          if (typeof noeud[clef] !== 'object' || noeud[clef] === null) { noeud[clef] = {}; }

          noeud = noeud[clef];
        });
      });

      var json = JSON.stringify(arbre);
      var encodeur = window.TextEncoder ? new TextEncoder() : null;
      var octets = encodeur ? encodeur.encode(json).length : json.length;

      var part = Math.min(100, Math.round((octets / LIMITE) * 100));

      barre.firstChild.style.width = part + '%';
      barre.classList.toggle('blocs-jauge--pleine', part >= 90);

      /*
       * LE MOT DIT LA PLACE, PAS LES OCTETS.
       *
       * Premiere version : « 50 070 octets sur 65 535 pour l'ensemble des
       * reglages de ce module. Au-dela, l'enregistrement se tronque sans
       * message. » Cyrille, 24 septembre 2026 : « ceci n'est toujours pas
       * comprehensible pour le neophyte ». Trois mots de jargon dans une seule
       * phrase, « octets », « tronque », « sans message », et deux nombres que
       * personne ne rapporte l'un a l'autre de tete.
       *
       * ON DIT DONC UN POURCENTAGE, et l'ennui seulement quand il approche.
       * Sous 90 %, il n'y a rien a faire, donc rien a lire : une seule phrase
       * qui constate. Au-dela, la phrase dit ce qu'on risque et en quels
       * termes : « la fin de ce que vous ecrivez ne sera pas enregistree ».
       * Ni octet, ni troncature, ni silence.
       */
      var clef = part >= 90 ? 'MOD_OPUS_GAUGE_FULL' : 'MOD_OPUS_GAUGE';
      var phrase = texte(clef, '');

      mot.textContent = phrase ? phrase.replace('%s', part) : part + ' %';
    };

    mesurer();

    var form = zone.closest('form');

    if (form && !form.dataset.opusJauge) {
      form.dataset.opusJauge = '1';
      form.addEventListener('input', mesurer);
      form.addEventListener('change', mesurer);
    }
  }

  /**
   * LE PANNEAU DES CLASSES PRODUITES.
   *
   * D'OU CELA VIENT : de `maquette-module-corpus_3.html`, panneau « CSS
   * personnalise ». A droite de la zone de code, la liste des classes que le
   * module ecrit, chacune etiquetee « a vous », « Corpus » ou « Bootstrap »,
   * cliquable pour voir sa description et ses regles.
   *
   * POURQUOI TROIS FAMILLES, ET POURQUOI TROIS COULEURS : on ne touche pas aux
   * trois de la meme facon. La NOTRE se surcharge sans consequence, elle
   * n'existe que dans ce module. Celle de CORPUS sert aussi les articles et
   * les autres modules : la modifier deplace des choses ailleurs, d'ou
   * l'avertissement. Celle de BOOTSTRAP est livree par Joomla a tout le site,
   * extensions comprises.
   *
   * LES DONNEES VIENNENT DU CATALOGUE, produit a la livraison. Rien n'est
   * devine ici : ni le nom d'une classe, ni ses regles. Le panneau ne sait
   * qu'afficher.
   *
   * SANS CATALOGUE, PAS DE PANNEAU, et le reste de l'ecran ne bouge pas. Un
   * module installe depuis un zip plus ancien s'ouvre comme avant.
   *
   * CLIQUER SUR UN NOM LE COPIE dans le presse-papier : c'est le geste qu'on
   * fait vingt fois en ecrivant une feuille, et le retaper est la premiere
   * source de faute de frappe silencieuse.
   */
  /**
   * LES REGLES QUI NE VISENT PLUS RIEN.
   *
   * « Je viens de changer de mise en page et d'enregistrer. Or dans l'onglet
   * CSS, j'ai toujours le contenu de la classe que j'avais essayee. Il
   * faudrait un systeme de nettoyage de la zone de CSS s'il n'y a plus de lien
   * avec l'onglet mise en page. » Cyrille, 24 septembre 2026.
   *
   * ON SIGNALE, ON NE SUPPRIME PAS TOUT SEUL, et c'est le seul point sur
   * lequel je m'ecarte de la demande. Cette zone contient du code ecrit a la
   * main, parfois long a retrouver ; un nettoyage automatique qui se trompe
   * une fois sur cent coute plus cher que les quatre-vingt-dix-neuf fois ou il
   * a vu juste. Le bouton fait le travail, mais apres avoir montre ce qu'il
   * va retirer.
   *
   * CE QU'EST UNE REGLE ORPHELINE : une regle dont AUCUNE classe n'est
   * employee. Une seule suffit a la garder, parce qu'un selecteur comme
   * `.promo .opus__chiffre-valeur` reste utile tant que `promo` est
   * pose quelque part, meme si les chiffres ont disparu du montage.
   *
   * CE QUI COMPTE COMME EMPLOYE : les classes que le montage ecrit (le
   * catalogue filtre sur les types presents), toutes les valeurs saisies dans
   * un champ Classe, le suffixe de classe du module, et les classes de
   * Corpus, qui vivent en dehors de ce module et ne peuvent pas etre jugees
   * ici.
   *
   * LES REGLES @media ET LES AUTRES BLOCS A ACCOLADES SONT LAISSES : un
   * decoupage naif les couperait en deux. Mieux vaut ne rien proposer que
   * proposer de casser une feuille.
   */
  function reglesOrphelines(css, employees) {
    var sortie = [];

    // Les commentaires partent : ils peuvent contenir des accolades.
    var sansNotes = css.replace(/\/\*[\s\S]*?\*\//g, function (bloc) {
      return bloc.replace(/[^\n]/g, ' ');
    });

    var motif = /([^{}@]+)\{([^{}]*)\}/g;
    var trouve;

    while ((trouve = motif.exec(sansNotes)) !== null) {
      var selecteur = trouve[1].trim();

      if (!selecteur || selecteur.indexOf('@') !== -1) { continue; }

      var classes = (selecteur.match(/\.[a-zA-Z_][a-zA-Z0-9_-]*/g) || [])
        .map(function (c) { return c.slice(1); });

      if (!classes.length) { continue; }

      var servie = classes.some(function (c) { return employees[c]; });

      if (servie) { continue; }

      sortie.push({
        debut: trouve.index,
        fin: motif.lastIndex,
        selecteur: selecteur,
        classes: classes
      });
    }

    return sortie;
  }

  function panneauClasses() {
    var zone = zoneCss();

    if (!zone) { return; }

    var groupe = zone.closest('.control-group');

    if (!groupe || groupe.dataset.opusClasses) { return; }

    var catalogue = (window.Joomla && Joomla.getOptions)
      ? Joomla.getOptions('mod_opus.classes', [])
      : [];

    if (!catalogue.length) { return; }

    groupe.dataset.opusClasses = '1';

    var boite = document.createElement('div');
    boite.className = 'blocs-classes';

    var titre = document.createElement('h4');
    titre.className = 'blocs-classes__titre';
    titre.textContent = texte('MOD_OPUS_CLASSES_TITLE', 'Classes produites');
    boite.appendChild(titre);

    var aide = document.createElement('p');
    aide.className = 'blocs-classes__aide';
    aide.textContent = texte('MOD_OPUS_CLASSES_HELP', 'Cliquez un nom pour le copier.');
    boite.appendChild(aide);

    /*
     * LA LEGENDE DES TROIS COULEURS.
     *
     * « Il me faut une legende pour les couleurs de classes », Cyrille,
     * 24 septembre 2026. Juste : chaque jeton porte deja son mot, mais en fin
     * de ligne et en petit ; ce qu'on lit en balayant la liste, c'est le filet
     * de gauche, et rien ne disait ce qu'il signifie.
     *
     * ELLE DIT CE QU'ON A LE DROIT DE FAIRE, pas d'ou vient la classe : c'est
     * la seule question qu'on se pose en ecrivant une feuille.
     */
    var legende = document.createElement('p');
    legende.className = 'blocs-classes__legende';

    [
      ['module', texte('MOD_OPUS_CLASSES_LEG_MINE', '')],
      ['corpus', texte('MOD_OPUS_CLASSES_LEG_CORPUS', '')],
      ['bootstrap', texte('MOD_OPUS_CLASSES_LEG_VENDOR', '')]
    ].forEach(function (paire) {
      var cle = document.createElement('span');
      cle.className = 'blocs-classes__cle blocs-classes__cle--' + paire[0];
      cle.textContent = paire[1];
      legende.appendChild(cle);
    });

    boite.appendChild(legende);

    /*
     * LE DETAIL EST AU-DESSUS DE LA LISTE, ET C'EST UNE CORRECTION.
     *
     * « Je parlais du visionneur de code des classes qui apparait quand on
     * clique dessus », Cyrille, 24 septembre 2026, apres que j'ai deplace la
     * mauvaise chose. Sous la liste, il poussait les jetons hors de vue des
     * qu'une classe portait trois regles : on cliquait, et ce qu'on venait de
     * cliquer remontait hors de l'ecran.
     *
     * AU-DESSUS, LA LISTE NE BOUGE PAS. On passe d'une classe a l'autre en
     * regardant toujours au meme endroit.
     */
    var detail = document.createElement('div');
    detail.className = 'blocs-classes__detail';
    detail.hidden = true;
    boite.appendChild(detail);

    var liste = document.createElement('div');
    liste.className = 'blocs-classes__liste';
    boite.appendChild(liste);

    var montrer = function (entree) {
      detail.textContent = '';
      detail.hidden = false;

      var nom = document.createElement('h5');
      nom.className = 'blocs-classes__nom';
      nom.textContent = '.' + entree.nom;
      detail.appendChild(nom);

      if (entree.description) {
        var desc = document.createElement('p');
        desc.className = 'blocs-classes__desc';
        desc.textContent = entree.description;
        detail.appendChild(desc);
      }

      (entree.regles || []).forEach(function (regle) {
        var pre = document.createElement('pre');
        pre.textContent = regle;
        detail.appendChild(pre);
      });

      /*
       * « COPIER SOUS UN AUTRE NOM », le dernier geste de la maquette.
       *
       * D'OU CELA VIENT : `maquette-module-corpus_3.html` l. 1052. « La copie
       * est ecrite dans la feuille de ce module, sous le nouveau nom et
       * prefixee par la classe du montage. La classe de Corpus n'est pas
       * touchee, donc rien ne bouge ailleurs. »
       *
       * C'EST LA REPONSE AU SEUL VRAI DANGER DE CE PANNEAU. Montrer les regles
       * d'une classe partagee donne envie de les changer, et les changer
       * deplace des choses dans les articles et les autres modules. Ce bouton
       * offre la seule sortie qui ne casse rien : on copie, on renomme, on
       * modifie sa copie.
       *
       * LE PREFIXE VIENT DU SUFFIXE DE CLASSE DU MODULE, celui de Joomla, dans
       * Parametres avances. S'il est vide, on prefixe par `opus`, qui
       * limite au moins la regle aux modules de ce type plutot qu'au site
       * entier.
       */
      if ((entree.regles || []).length) {
        var renommer = document.createElement('div');
        renommer.className = 'blocs-classes__copier';

        var champ = document.createElement('input');
        champ.type = 'text';
        champ.className = 'form-control form-control-sm';
        champ.placeholder = texte('MOD_OPUS_CLASSES_NEWNAME', 'nom-de-ma-copie');

        var bouton = document.createElement('button');
        bouton.type = 'button';
        bouton.className = 'btn btn-sm';
        bouton.textContent = texte('MOD_OPUS_CLASSES_COPY', 'Copier sous un autre nom');

        bouton.addEventListener('click', function () {
          var neuf = champ.value.trim().replace(/^\./, '');

          if (!neuf) { champ.focus(); return; }

          var sfx = document.querySelector('[name*="moduleclass_sfx"]');
          var portee = sfx && sfx.value.trim() ? sfx.value.trim().replace(/^\s*\.?/, '') : 'opus';

          var copie = (entree.regles || []).map(function (regle) {
            return regle.split('.' + entree.nom).join('.' + neuf);
          }).map(function (regle) {
            return '.' + portee + ' ' + regle;
          }).join('\n\n');

          ecrireCss(
            zone,
            (lireCss(zone).trim() ? lireCss(zone).replace(/\s+$/, '') + '\n\n' : '')
              + '/* ' + texte('MOD_OPUS_CLASSES_COPIED', 'Copie de') + ' .' + entree.nom + ' */\n'
              + copie + '\n'
          );

          champ.value = '';
        });

        renommer.appendChild(champ);
        renommer.appendChild(bouton);
        detail.appendChild(renommer);
      }

      if (entree.famille !== 'module') {
        var garde = document.createElement('p');
        garde.className = 'blocs-classes__garde';
        garde.textContent = entree.famille === 'corpus'
          ? texte('MOD_OPUS_CLASSES_SHARED', '')
          : texte('MOD_OPUS_CLASSES_VENDOR', '');
        detail.appendChild(garde);
      }
    };

    /*
     * CE QUE LE MONTAGE EMPLOIE, RELU A CHAQUE FOIS.
     *
     * « Ici ne doit s'afficher que les classes utilisees par la mise en page
     * utilisee », Cyrille, 24 septembre 2026. Cent trente-quatre classes dont
     * cent ne servent pas, c'est une liste qu'on ne lit pas.
     *
     * ON LIT LES TYPES CHOISIS DANS LE FORMULAIRE, blocs et elements
     * confondus : un `select` dont le nom finit par `[type]` porte l'un ou
     * l'autre, et le catalogue les range sous le meme mot. Pas besoin de
     * savoir lequel est lequel.
     *
     * UNE CLASSE SANS TYPE EST TOUJOURS MONTREE : ce sont les conteneurs, la
     * rangee, la colonne, le cadre, ecrits quel que soit le montage.
     */
    var employes = function () {
      var vus = {};

      [].slice.call(document.querySelectorAll('#' + FIELDSET + ' select[name$="[type]"]'))
        .forEach(function (sel) {
          if (sel.value) { vus[sel.value] = 1; }
        });

      return vus;
    };

    var dessiner = function () {
      var vus = employes();

      liste.textContent = '';

      catalogue.forEach(function (entree) {
        var types = entree.types || [];

        if (types.length) {
          var servi = types.some(function (t) { return vus[t]; });

          if (!servi) { return; }
        }

        liste.appendChild(jetonDe(entree));
      });

      var compte = liste.children.length;

      aide.textContent = texte('MOD_OPUS_CLASSES_HELP', '')
        .replace('%d', compte) || (compte + ' classes');
    };

    var jetonDe = function (entree) {
      var jeton = document.createElement('button');
      jeton.type = 'button';
      jeton.className = 'blocs-classe blocs-classe--' + entree.famille;
      jeton.textContent = '.' + entree.nom;

      var marque = document.createElement('em');
      marque.textContent = entree.famille === 'module'
        ? texte('MOD_OPUS_CLASSES_MINE', 'a vous')
        : (entree.famille === 'corpus' ? 'Corpus' : 'Bootstrap');
      jeton.appendChild(marque);

      jeton.addEventListener('click', function () {
        montrer(entree);

        if (navigator.clipboard) {
          navigator.clipboard.writeText('.' + entree.nom).catch(function () {});
        }
      });

      return jeton;
    };

    /*
     * L'AVERTISSEMENT DES REGLES ORPHELINES, sous la zone de code.
     *
     * IL NE SE MONTRE QUE QUAND IL A QUELQUE CHOSE A DIRE : une feuille saine
     * n'affiche rien du tout. Un avertissement permanent qui dit « tout va
     * bien » finit par ne plus etre lu, et celui qui compte avec lui.
     */
    var alerte = document.createElement('div');
    alerte.className = 'blocs-orphelines';
    alerte.hidden = true;

    var alerteMot = document.createElement('p');
    alerteMot.className = 'blocs-orphelines__mot';
    alerte.appendChild(alerteMot);

    var alerteListe = document.createElement('ul');
    alerte.appendChild(alerteListe);

    var alerteBouton = document.createElement('button');
    alerteBouton.type = 'button';
    alerteBouton.className = 'btn btn-sm';
    alerteBouton.textContent = texte('MOD_OPUS_ORPHAN_CLEAN', 'Retirer ces regles');
    alerte.appendChild(alerteBouton);

    var orphelines = [];

    var verifier = function () {
      var employees = {};

      // Ce que le montage ecrit, d'apres le catalogue filtre sur les types.
      var vus = employes();

      catalogue.forEach(function (entree) {
        var types = entree.types || [];

        if (!types.length || types.some(function (t) { return vus[t]; })) {
          employees[entree.nom] = 1;
        }

        // Une classe de Corpus vit en dehors de ce module : on ne la juge pas.
        if (entree.famille !== 'module') { employees[entree.nom] = 1; }
      });

      // Tout ce qui est saisi dans un champ Classe, a quelque niveau que ce soit.
      [].slice.call(document.querySelectorAll('#' + FIELDSET + ' input'))
        .forEach(function (champ) {
          if (!champ.name || !/\[(classe|classe[A-Z]\w*)\]$/.test(champ.name)) { return; }

          String(champ.value || '').split(/\s+/).forEach(function (c) {
            if (c) { employees[c] = 1; }
          });
        });

      var sfx = document.querySelector('[name*="moduleclass_sfx"]');

      if (sfx) {
        String(sfx.value || '').split(/\s+/).forEach(function (c) {
          if (c) { employees[c.replace(/^\./, '')] = 1; }
        });
      }

      orphelines = reglesOrphelines(lireCss(zone), employees);

      alerte.hidden = orphelines.length === 0;

      if (!orphelines.length) { return; }

      alerteMot.textContent = texte('MOD_OPUS_ORPHAN_WARN', '')
        .replace('%s', orphelines.length);

      alerteListe.textContent = '';

      orphelines.forEach(function (o) {
        var li = document.createElement('li');
        li.textContent = o.selecteur;
        alerteListe.appendChild(li);
      });
    };

    alerteBouton.addEventListener('click', function () {
      var texteCss = lireCss(zone);

      // A REBOURS : retirer par la fin garde les positions des precedentes.
      orphelines.slice().reverse().forEach(function (o) {
        texteCss = texteCss.slice(0, o.debut) + texteCss.slice(o.fin);
      });

      ecrireCss(zone, texteCss.replace(/\n{3,}/g, '\n\n').trim());
      zone.dispatchEvent(new Event('input', { bubbles: true }));
      verifier();
    });

    dessiner();
    verifier();

    /*
     * L'EXEMPLE COMMENTE, SOUS LA LISTE.
     *
     * « Ceci n'est pas facile a comprendre. Dessous il me faudrait un exemple
     * de creation d'une classe, ou l'on voit comment changer une couleur, les
     * marges, padding, bordures, epaisseur. Un code complet, mais simple. »
     * Cyrille, 24 septembre 2026.
     *
     * IL EST REPLIE PAR DEFAUT : celui qui sait ecrire du CSS n'a pas a le
     * voir chaque fois qu'il ouvre l'onglet, et celui qui ne sait pas le
     * trouve la ou il cherche, juste sous la liste des classes.
     *
     * LE BOUTON L'INSERE DANS LA FEUILLE plutot que de le faire recopier :
     * c'est un exemple pour partir, pas un texte a admirer. Il s'ajoute a la
     * suite de ce qui est deja ecrit, il n'efface rien.
     */
    var aExemple = null;

    var exemple = (window.Joomla && Joomla.getOptions)
      ? Joomla.getOptions('mod_opus.exemple', '')
      : '';

    if (exemple) {
      var pliant = document.createElement('details');
      pliant.className = 'blocs-classes__exemple';

      var poignee = document.createElement('summary');
      poignee.textContent = texte('MOD_OPUS_EXAMPLE_TITLE', 'Un exemple complet');
      pliant.appendChild(poignee);

      var code = document.createElement('pre');
      code.textContent = exemple;
      pliant.appendChild(code);

      var poser = document.createElement('button');
      poser.type = 'button';
      poser.className = 'btn btn-sm blocs-classes__poser';
      poser.textContent = texte('MOD_OPUS_EXAMPLE_INSERT', 'Inserer dans la feuille');

      poser.addEventListener('click', function () {
        ecrireCss(zone, (lireCss(zone).trim() ? lireCss(zone).replace(/\s+$/, '') + '\n\n' : '') + exemple);
        zone.dispatchEvent(new Event('input', { bubbles: true }));
        zone.focus();
      });

      pliant.appendChild(poser);

      /*
       * L'EXEMPLE VA SOUS LA ZONE DE CODE, PAS SOUS LES CLASSES. « Place-le
       * sous la zone de feuille de style », Cyrille, 24 septembre 2026 : il
       * parle de ce qu'on ECRIT, pas de ce qu'on peut viser. La colonne de
       * droite repond a « quoi cibler », celle de gauche a « comment
       * l'ecrire ». Chaque colonne garde sa question.
       */
      aExemple = pliant;
    }

    /*
     * LA LISTE SUIT LE MONTAGE. Ajouter une galerie doit faire apparaitre ses
     * classes sans recharger l'ecran, sinon la liste ment des le premier
     * changement. Le `change` du formulaire suffit : c'est le seul moment ou un
     * type peut changer.
     */
    var form = zone.closest('form');

    if (form && !form.dataset.opusClassesSuivi) {
      form.dataset.opusClassesSuivi = '1';

      form.addEventListener('change', function () {
        dessiner();
        verifier();
      });

      // La feuille se relit a la frappe : on ne signale pas une regle a moitie
      // ecrite, mais on cesse de signaler celle qu'on vient de corriger.
      zone.addEventListener('input', verifier);

      /*
       * ET SUR L'EDITEUR AUSSI. CodeMirror ecrit dans un element editable qui
       * n'est pas le `textarea` : la frappe ne passe donc jamais par lui. Son
       * enveloppe, elle, voit remonter les `input` de cet element.
       */
      var blocFrappe = blocCss(zone);

      if (blocFrappe !== zone) { blocFrappe.addEventListener('input', verifier); }
    }

    /*
     * DEUX COLONNES, 40 POUR LA FEUILLE ET 60 POUR LES CLASSES.
     *
     * TROIS DISPOSITIONS EN UNE HEURE, et c'est la troisieme qui tient. Le
     * panneau sous le champ, puis a droite en `1.5fr 1fr` comme la maquette,
     * puis en pile parce que j'avais mal lu « mettre le visionneur de code en
     * haut » : il parlait du visionneur DES CLASSES, pas du champ. La demande
     * exacte : « la colonne des classes doit etre de 60 % de la largeur sur la
     * droite. »
     *
     * POURQUOI 60 ET NON LE TIERS DE LA MAQUETTE : elle dessinait une page
     * entiere, ou un tiers laisse la place d'un nom de classe. Dans l'onglet
     * d'un module, ce tiers fait vingt caracteres et un nom en fait quarante.
     * C'est la liste qui a besoin de largeur, pas la zone de code, ou l'on
     * ecrit des lignes courtes.
     *
     * L'EDITEUR NE BOUGE PAS, 25 septembre 2026.
     *
     * « L'onglet CSS est double dans son contenu », Cyrille. Deux zones de code
     * l'une sous l'autre, pour un seul champ. Mesure : UN seul
     * `joomla-editor-codemirror`, qui contient DEUX `.cm-editor`. La version
     * precedente creait un enrobage et y DEPLACAIT l'editeur ; deplacer un
     * element personnalise le deconnecte puis le reconnecte, et CodeMirror se
     * construit une seconde fois. C'est la regle n. 1 du formulaire, violee.
     *
     * POURQUOI CELA NE SE VOYAIT PAS AVANT : `legend.js` de Corpus, charge
     * jusqu'a la 1.4.199, surveillait tous les editeurs de la page et effacait
     * le double (`dedupliquerEditeurs`, ecrit pour le meme defaut chez
     * Corpus). Opus n'ayant plus rien de Corpus, le defaut est apparu.
     *
     * DESORMAIS la grille se pose sur le parent ou Joomla a mis l'editeur, et
     * ce sont NOS elements qui viennent se ranger autour de lui : la liste des
     * classes, la jauge, l'alerte, l'exemple. L'editeur reste ou il est ne.
     */
    var blocZone = blocCss(zone);
    var hote = blocZone.parentNode;

    hote.classList.add('blocs-css-deux');

    var suite = document.createElement('div');
    suite.className = 'blocs-css-deux__suite';

    /*
     * LA JAUGE SUIT LA ZONE DE CODE dans la colonne de gauche : elle parle
     * d'elle, pas des classes. Elle a ete posee avant ce panneau, donc elle
     * est deja la, et on la deplace plutot que de la refaire. Ce sont des
     * elements a nous : les deplacer ne reveille rien.
     */
    [].slice.call(hote.querySelectorAll(':scope > .blocs-jauge, :scope > .blocs-jauge__mot'))
      .forEach(function (e) { suite.appendChild(e); });

    suite.appendChild(alerte);

    if (aExemple) { suite.appendChild(aExemple); }

    hote.insertBefore(suite, blocZone.nextSibling);
    hote.appendChild(boite);
  }

  /**
   * LES PASTILLES DE MODIFICATION, PORTEES DANS LE MODULE, 25 septembre 2026.
   *
   * Elles etaient posees par `legend.js` de Corpus (l. 379 a 443 en 2.1.53),
   * que le champ `legend` chargeait. Opus ne le charge plus : sans ce qui
   * suit, les pastilles rouges disparaissaient sans un message, et l'on ne
   * voyait plus ce qu'on avait change avant d'enregistrer.
   *
   * LA REGLE EST LA MEME, a la lettre : un champ dont la valeur differe de
   * celle du chargement porte `modified` sur son groupe, et le titre de la
   * section le porte tant qu'un de ses champs le porte. `admin.css` dessine
   * deja la pastille pour ces deux cas.
   *
   * CE QUI CHANGE, ET POURQUOI :
   *   - un seul ecouteur, pose sur le formulaire, au lieu d'un par champ. Un
   *     champ ne dans une ligne ajoutee plus tard est donc suivi aussi ; il
   *     n'a pas de valeur d'origine, et une ligne neuve EST une modification ;
   *   - le groupe du champ se trouve par `closest('.control-group')` : c'est
   *     SON groupe, jamais celui d'une liste imbriquee (piege n. 1) ;
   *   - la section se retrouve en remontant les freres du groupe de premier
   *     niveau, pas par une donnee jQuery posee au chargement, qui ignorait
   *     les lignes nees ensuite (piege n. 2).
   */
  function valeurDe(champ) {
    if (champ.type === 'radio') {
      var coche = champ.form
        ? champ.form.querySelector('input[type="radio"][name="' + champ.name + '"]:checked')
        : null;

      return coche ? coche.value : '';
    }

    if (champ.type === 'checkbox') { return champ.checked ? '1' : '0'; }

    return champ.value;
  }

  function sectionDe(groupe) {
    var grille = groupe.closest('.form-grid');

    if (!grille) { return null; }

    var haut = groupe;

    while (haut && haut.parentElement !== grille) { haut = haut.parentElement; }

    for (var n = haut; n; n = n.previousElementSibling) {
      if (n.classList.contains('top-legend-group')) { return n; }

      // Cote site, le groupe est l'enfant du `li` (voir `marquerSections`).
      if (n.tagName === 'LI' && n.firstElementChild && n.firstElementChild.classList.contains('top-legend-group')) {
        return n.firstElementChild;
      }
    }

    return null;
  }

  function suivreModifications() {
    var formulaire = document.getElementById('module-form');

    if (!formulaire || formulaire.dataset.opusSuivi) { return; }

    formulaire.dataset.opusSuivi = '1';

    var perimetre = '#fieldset-montage, #fieldset-icones';
    var origine = new WeakMap();

    [].slice.call(formulaire.querySelectorAll(
      '#fieldset-montage :is(input, select, textarea), #fieldset-icones :is(input, select, textarea)'
    )).forEach(function (champ) {
      origine.set(champ, valeurDe(champ));
    });

    formulaire.addEventListener('change', function (e) {
      var champ = e.target;

      if (!champ.matches || !champ.matches('input, select, textarea') || !champ.closest(perimetre)) {
        return;
      }

      var groupe = champ.closest('.control-group');

      if (!groupe) { return; }

      var change = !origine.has(champ) || origine.get(champ) !== valeurDe(champ);

      groupe.classList.toggle('modified', change);

      var section = sectionDe(groupe);

      if (!section) { return; }

      if (change) {
        section.classList.add('modified');

        return;
      }

      // La section ne s'eteint que si plus aucun de ses champs n'est modifie.
      var encore = false;

      for (var n = section.nextElementSibling; n && !n.classList.contains('top-legend-group'); n = n.nextElementSibling) {
        if (n.classList.contains('modified') || n.querySelector('.control-group.modified')) {
          encore = true;
          break;
        }
      }

      section.classList.toggle('modified', encore);
    });
  }

  /**
   * LE MODE SITE : L'ECRAN DU MONTAGE, CONTENU SEUL, 25 septembre 2026.
   *
   * « Obtenir une mise en page proche du module en backend avec uniquement
   * les champs modifiables, sans acces aux reglages », Cyrille. C'est la
   * premiere question que poseront les clients : on modifie un texte depuis
   * le crayon du module, sur la page, sans passer par l'administration.
   *
   * CE QUE LE SITE DONNE : `com_config` rend le formulaire dans un accordeon
   * Bootstrap (`default_options.php`), chaque groupe de champs dans un `li`.
   * Aucun des reperes de l'administration n'y est : pas d'onglet
   * `attrib-montage`, pas de fieldset `fieldset-montage`, pas de `form-grid`.
   * On les POSE sur ce qui existe (des identifiants et des classes, aucun
   * noeud deplace), et tout l'ecran s'y accroche comme en administration.
   *
   * L'identifiant du volet change : le bouton de l'accordeon le vise par
   * `data-bs-target` et `aria-controls`, on les recale ensemble.
   *
   * CE QUI RESTE MODIFIABLE est une LISTE BLANCHE de champs de contenu : un
   * champ absent de la liste est masque, jamais retire. Masque, il repart
   * avec le formulaire, intact ; retire, un enregistrement depuis le site
   * effacerait le montage. Les commandes de structure (ajouter, retirer,
   * deplacer), les roues de reglages et le choix des mises en page sont
   * masques par la feuille, sous `html.opus-mode-site`.
   */
  var SITE_CONTENU = [
    'label', 'text', 'body', 'texte', 'titre', 'nom', 'terme', 'valeur', 'mesure',
    'source', 'quoteSource', 'repere', 'part', 'listItems', 'image', 'linkType',
    'linkUrl', 'linkMenu', 'coordNom', 'coordAdresse', 'coordTel', 'coordCourriel',
    'coordHoraires', 'imgLegende'
  ];

  function modeSite() {
    return !!(window.Joomla && Joomla.getOptions && Joomla.getOptions('mod_opus.site'));
  }

  /**
   * DANS LA GRANDE FENETRE, L'ECRAN EST COMPLET, 25 septembre 2026 au soir.
   *
   * « Si c'est possible je prefere la totale », Cyrille. Le crayon d'Opus
   * ouvre cet ecran dans une fenetre presque plein ecran (`edition.js`),
   * sans le template (`tmpl=component`) : il a donc toute la largeur, et l'on
   * y montre tout, reglages compris. La page du site, elle, reste en mode
   * « contenu seul » : c'est la qu'on arrive sans script.
   */
  function modeFenetre() {
    return !!(window.Joomla && Joomla.getOptions && Joomla.getOptions('mod_opus.fenetre'));
  }

  function preparerSite() {
    /*
     * LES TROIS VOLETS D'OPUS, reconnus par le champ qu'ils portent et non
     * par leur titre, qui se traduit. Chacun recoit les identifiants de son
     * onglet d'administration : la feuille et le script s'y accrochent.
     */
    var volets = [
      { champ: 'joomla-field-subform[name="jform[params][blocs]"]', onglet: 'attrib-montage', fieldset: FIELDSET },
      { champ: '[name="jform[params][customCss]"]', onglet: 'attrib-css', fieldset: 'fieldset-css' },
      { champ: 'joomla-field-subform[name="jform[params][iconesPerso]"]', onglet: 'attrib-icones', fieldset: 'fieldset-icones' }
    ];

    if (document.getElementById(FIELDSET)) { return; }

    document.documentElement.classList.add('opus-mode-site');
    document.documentElement.classList.add(modeFenetre() ? 'opus-mode-fenetre' : 'opus-mode-contenu');

    volets.forEach(function (v, rang) {
      var repere = document.querySelector(v.champ);
      var liste = repere ? repere.closest('ul') : null;
      var corps = liste ? liste.parentElement : null;
      var volet = corps ? corps.closest('.accordion-collapse') : null;

      if (!liste || !corps || !volet) { return; }

      var ancien = volet.id;
      var bouton = ancien ? document.querySelector('[aria-controls="' + ancien + '"]') : null;

      volet.id = v.onglet;
      corps.id = v.fieldset;
      liste.classList.add('form-grid');

      if (!bouton) { return; }

      /*
       * Le bouton de l'accordeon vise le volet par ces deux attributs : on
       * les recale sur le nouvel identifiant, sinon il n'ouvrirait plus rien.
       */
      bouton.setAttribute('aria-controls', v.onglet);
      if (bouton.hasAttribute('data-bs-target')) { bouton.setAttribute('data-bs-target', '#' + v.onglet); }

      // Le volet du montage s'ouvre : c'est pour lui qu'on a clique sur le crayon.
      if (rang === 0) {
        volet.classList.add('show');
        bouton.classList.remove('collapsed');
        bouton.setAttribute('aria-expanded', 'true');
      }
    });

    // L'avis pose par `blocsinfo` monte en tete du volet : c'est la qu'on le lit.
    var avis = document.querySelector('.opus-site');
    var corpsMontage = document.getElementById(FIELDSET);

    if (avis && corpsMontage) { corpsMontage.insertBefore(avis, corpsMontage.firstChild); }

    if (modeFenetre()) {
      completerTemplate(document);
      ongletsFenetre();

      // Les fenetres de Joomla ouvertes depuis la notre (le gestionnaire de medias) : meme remede.
      document.addEventListener('load', function (e) {
        if (e.target && e.target.tagName === 'IFRAME') {
          try { completerTemplate(e.target.contentDocument); } catch (x) { /* autre origine : rien a faire */ }
        }
      }, true);
    }
  }

  /**
   * SANS BOOTSTRAP, LES ECRANS DE JOOMLA SONT CASSES, 26 septembre 2026.
   *
   * Corpus ne charge pas Bootstrap. Dans la fenetre, rendue par le template
   * (`tmpl=component`), les boutons Enregistrer, Enregistrer et fermer et
   * Annuler prenaient l'aspect gris du navigateur, et le gestionnaire de
   * medias, qui s'ouvre dans une fenetre de plus, perdait sa mise en page :
   * « moche », « tout est un peu casse », Cyrille.
   *
   * On prend alors ce que JOOMLA livre lui-meme (`media/vendor/bootstrap`, les
   * icones de `media/system`), place AVANT les feuilles du template : le
   * template garde le dernier mot sur tout ce qu'il dessine. Rien n'est ajoute
   * quand le template a deja Bootstrap (Cassiopeia) : la sonde est un `.btn`,
   * que le navigateur seul laisse a 6 px de marge interieure.
   *
   * `body.modal` : le `component.php` de Corpus pose cette classe sur le corps,
   * et Bootstrap cache tout `.modal`. `.hidden` : la classe de `showon` et du
   * champ d'envoi des medias, que Bootstrap ne connait pas.
   */
  function completerTemplate(doc) {
    if (!doc || !doc.head || !doc.body || doc.documentElement.hasAttribute('data-opus-complete')) { return; }

    doc.documentElement.setAttribute('data-opus-complete', '');

    var sonde = doc.createElement('button');
    sonde.className = 'btn';
    doc.body.appendChild(sonde);
    var brut = doc.defaultView.getComputedStyle(sonde).paddingLeft === '6px';
    sonde.remove();

    if (!brut) { return; }

    var chemins = window.Joomla && Joomla.getOptions ? Joomla.getOptions('system.paths') : null;
    var racine = chemins && chemins.rootFull ? chemins.rootFull : '/';
    var premiere = doc.head.querySelector('link[rel="stylesheet"], style');

    ['media/vendor/bootstrap/css/bootstrap.min.css', 'media/system/css/joomla-fontawesome.min.css'].forEach(function (chemin) {
      var lien = doc.createElement('link');
      lien.rel = 'stylesheet';
      lien.href = racine + chemin;
      doc.head.insertBefore(lien, premiere);
    });

    var style = doc.createElement('style');
    /*
     * Corpus masque les icones vides (`span[class^="icon-"]:empty`), faute de
     * fonte d'icones sur le site. Ici la fonte est chargee : on les rend, meme
     * poids de selecteur, ecrit apres.
     */
    style.textContent = 'body.modal{display:block;position:static;overflow:visible;width:auto;height:auto;z-index:auto}'
      + '.hidden{display:none!important}'
      + 'span[class^="icon-"]:empty,span[class*=" icon-"]:empty,span[class^="fa-"]:empty,span[class*=" fa-"]:empty,'
      + 'i[class^="icon-"]:empty,i[class*=" icon-"]:empty{display:inline-block}';
    doc.head.appendChild(style);
  }

  /**
   * DES ONGLETS AU LIEU DE L'ACCORDEON, 26 septembre 2026.
   *
   * « Dans le backend de Joomla tout est presente avec des onglets en haut.
   * Peut-on retrouver cette mise en page ? », Cyrille. Le formulaire du site
   * range les volets dans un accordeon Bootstrap. On ne deplace AUCUN volet :
   * l'editeur du CSS se dedouble quand on le deplace (lecon du 24 septembre).
   * On pose une barre d'onglets au-dessus de l'accordeon, on masque ses
   * en-tetes, et chaque onglet montre son volet en posant `show`, la classe
   * que Bootstrap lui-meme emploie. Les motifs ARIA des onglets : fleches,
   * Debut, Fin, un seul onglet dans l'ordre de tabulation.
   *
   * LES CHAMPS DE JOOMLA VONT DANS « PARAMETRES » (titre, position, statut,
   * dates, acces, tri, note). « Remets les champs dans Parametres, avec la
   * meme presentation », Cyrille, 26 septembre. Ils vivent dans le meme bloc
   * que l'accordeon, AVANT lui : la barre d'onglets est posee en tete de ce
   * bloc, et les champs ne s'affichent qu'avec le premier onglet. Ils restent
   * a leur place dans le document (le selecteur de position est un element
   * personnalise, on ne le deplace pas). Un champ invalide ramene a cet
   * onglet : le titre est obligatoire, vide et cache, l'enregistrement serait
   * refuse sur un champ qu'on ne voit pas.
   */
  function ongletsFenetre() {
    var accordeon = document.querySelector('#options > .accordion');
    var options = document.getElementById('options');
    var noyau = options ? options.parentElement : null;

    if (!accordeon || accordeon.classList.contains('opus-onglets-actifs')) { return; }

    var elements = [].slice.call(accordeon.children).filter(function (i) {
      return i.classList.contains('accordion-item') && i.querySelector(':scope > .accordion-collapse');
    });

    if (elements.length < 2) { return; }

    var barre = document.createElement('div');
    barre.className = 'opus-onglets';
    barre.setAttribute('role', 'tablist');

    var onglets = elements.map(function (item, rang) {
      var volet = item.querySelector(':scope > .accordion-collapse');
      var entete = item.querySelector(':scope > .accordion-header .accordion-button');
      var onglet = document.createElement('button');

      onglet.type = 'button';
      onglet.className = 'opus-onglets__onglet';
      onglet.id = 'opus-onglet-' + rang;
      onglet.setAttribute('role', 'tab');
      onglet.setAttribute('aria-controls', volet.id);
      onglet.textContent = entete ? entete.textContent.trim() : String(rang + 1);

      volet.setAttribute('role', 'tabpanel');
      volet.setAttribute('aria-labelledby', onglet.id);
      volet.removeAttribute('data-bs-parent');

      // « Parametres avances » et les volets de Joomla qui suivent : deux colonnes (Cyrille, 26 septembre).
      var liste = rang > 0 && !/^attrib-/.test(volet.id) ? volet.querySelector('.accordion-body > ul') : null;

      if (liste) { liste.classList.add('opus-deux-colonnes'); }

      barre.appendChild(onglet);

      return onglet;
    });

    function choisir(rang, focus) {
      elements.forEach(function (item, i) {
        var actif = i === rang;

        item.classList.toggle('opus-onglet-actif', actif);
        item.querySelector(':scope > .accordion-collapse').classList.toggle('show', actif);
        onglets[i].setAttribute('aria-selected', actif ? 'true' : 'false');
        onglets[i].tabIndex = actif ? 0 : -1;
      });

      if (noyau) { noyau.classList.toggle('opus-noyau--replie', rang !== 0); }

      if (focus) { onglets[rang].focus(); }
    }

    barre.addEventListener('click', function (e) {
      var i = onglets.indexOf(e.target.closest('.opus-onglets__onglet'));

      if (i > -1) { choisir(i, false); }
    });

    barre.addEventListener('keydown', function (e) {
      var i = onglets.indexOf(document.activeElement);
      var n = onglets.length;
      var cible = { ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: n - 1 }[e.key];

      if (i < 0 || cible === undefined) { return; }

      e.preventDefault();
      choisir((cible + n) % n, true);
    });

    if (noyau) {
      noyau.classList.add('opus-noyau');
      noyau.insertBefore(barre, noyau.firstChild);
    } else {
      accordeon.parentNode.insertBefore(barre, accordeon);
    }

    accordeon.classList.add('opus-onglets-actifs');

    // Le montage d'abord : c'est pour lui qu'on a clique sur le crayon.
    var montage = elements.map(function (i) { return i.querySelector(':scope > .accordion-collapse').id; }).indexOf('attrib-montage');

    choisir(montage > -1 ? montage : 0, false);

    var formulaire = noyau ? noyau.closest('form') : null;

    if (!formulaire) { return; }

    function horsOptions(c) { return !options.contains(c) && noyau.contains(c); }

    // Capture : `invalid` ne remonte pas. Le validateur de Joomla, lui, pose `.invalid`.
    formulaire.addEventListener('invalid', function (e) {
      if (horsOptions(e.target)) { choisir(0, false); }
    }, true);

    // On n'observe que les champs de Joomla : le montage, lui, change de classe sans cesse.
    var guet = new MutationObserver(function (changes) {
      if (changes.some(function (c) { return c.target.classList.contains('invalid'); })) { choisir(0, false); }
    });

    [].slice.call(noyau.children).forEach(function (enfant) {
      if (enfant !== options && enfant !== barre) {
        guet.observe(enfant, { subtree: true, attributes: true, attributeFilter: ['class'] });
      }
    });
  }

  /** La derniere clef du nom d'un champ : `...[elements0][label]` -> `label`. */
  function clefDe(champ) {
    var m = /\[([^\[\]]+)\](\[\])?$/.exec(champ.name || '');

    return m ? m[1] : '';
  }

  function filtrerSite() {
    var fs = document.getElementById(FIELDSET);

    if (!fs) { return; }

    [].slice.call(fs.querySelectorAll('.control-group')).forEach(function (groupe) {
      if (groupe.dataset.opusSite) { return; }

      // Un groupe qui porte une liste imbriquee reste : ce sont ses champs qui comptent.
      /*
       * LE SOUS-FORMULAIRE N'EST PAS UN ENFANT DIRECT DE `.controls`, et un
       * champ cache du coeur porte son nom (`jform[params][blocs]`, vide,
       * pour le cas ou la liste n'a aucune ligne). La premiere version
       * cherchait l'enfant direct, ne le trouvait pas, lisait ce champ cache
       * et masquait toute la liste : plus rien de visible (mesure sur le
       * banc, 25 septembre au soir). On cherche la liste dont CE groupe est
       * le plus proche.
       */
      var liste = [].slice.call(groupe.querySelectorAll('joomla-field-subform'))
        .filter(function (s) { return s.closest('.control-group') === groupe; })[0];

      if (liste) {
        groupe.dataset.opusSite = '1';

        // Les rangees ne sont que de la structure.
        if (/\[rangees\]$/.test(liste.getAttribute('name') || '')) { groupe.classList.add('opus-site-cache'); }

        return;
      }

      var champ = [].slice.call(groupe.querySelectorAll('input[name], select[name], textarea[name]'))
        .filter(function (c) { return c.closest('.control-group') === groupe; })[0];

      // Un titre de section, un champ d'information : rien a saisir, on laisse.
      if (!champ) { return; }

      groupe.dataset.opusSite = '1';

      if (SITE_CONTENU.indexOf(clefDe(champ)) === -1) { groupe.classList.add('opus-site-cache'); }
    });

    // La section des rangees : son titre part avec elle.
    [].slice.call(fs.querySelectorAll('.top-legend-group')).forEach(function (tete) {
      var suivant = tete.parentElement.tagName === 'LI' ? tete.parentElement.nextElementSibling : tete.nextElementSibling;
      var membre = suivant && suivant.tagName === 'LI' ? suivant.firstElementChild : suivant;

      if (membre && membre.classList.contains('opus-site-cache')) { tete.classList.add('opus-site-cache'); }
    });
  }

  function demarrer() {
    if (modeSite()) { preparerSite(); }

    suivreModifications();

    quandLeFormulaireEstPret(function () {
      outillerTout();
      dessiner();
    });

    if (!poser()) { return; }

    var form = document.getElementById('module-form') || document.querySelector('form[name="adminForm"]');
    if (!form) { return; }

    // 1. Tous les champs, y compris ceux ajoutes plus tard : delegation.
    form.addEventListener('change', redessiner);
    form.addEventListener('input', redessiner);

    // 2. Les evenements du sous-formulaire du coeur. SANS prefixe : relu dans
    //    media/system/js/fields/joomla-field-subform.js avant d'ecrire.
    form.addEventListener('subform-row-add', redessiner);

    /*
     * AU RETRAIT, ON ATTEND LE TOUR SUIVANT, ET C'EST MESURE.
     *
     * « Le dessin ne se met pas a jour », Cyrille, 22 septembre 2026. Mesure
     * faite sur le banc : au moment ou `subform-row-remove` est emis, la ligne
     * retiree est ENCORE dans le document. La carte se redessinait donc en la
     * comptant, et montrait l'etat d'AVANT le retrait. Le defaut ne se voyait
     * qu'une fois sur deux : au retrait suivant, elle rattrapait le precedent.
     *
     * `setTimeout(…, 0)` rend la main au coeur, qui retire sa ligne, puis la
     * carte lit un document a jour. A l'ajout, la ligne est deja posee quand
     * l'evenement part : rien a attendre.
     */
    form.addEventListener('subform-row-remove', function () {
      window.setTimeout(redessiner, 0);
    });

    /*
     * VIDER UNE LISTE DOIT RENDRE LE `+` DE L'EN-TETE, sinon la liste devient
     * un cul-de-sac : plus une seule ligne, donc plus un seul bouton pour en
     * remettre une.
     */
  /**
   * UNE RANGEE QUI PART EMPORTE SES BLOCS, ET DECALE LES SUIVANTS.
   *
   * Decouverte de Cyrille, 22 septembre 2026 : « si je supprime une rangee, il
   * faut que cela supprime les elements en relation avec cette rangee ».
   *
   * CE QUI SE PASSAIT SANS CELA, ET C'EST PIRE QU'UN OUBLI. Un bloc designe sa
   * rangee par son NUMERO. Retirez la rangee 2 sur trois : les blocs de la 2
   * pointent une rangee qui n'existe plus et disparaissent de la page, et
   * surtout les blocs de la 3 pointent toujours « 3 » alors que leur rangee
   * s'appelle desormais 2. Ils disparaissent aussi, sans que rien ne le dise.
   * Le montage se vidait en silence a chaque retrait.
   *
   * ON NE SUPPRIME QUE CE QUI DESIGNE LA RANGEE PARTIE. Les autres blocs sont
   * RENUMEROTES, pas jetes : leur rangee existe toujours, elle a juste change
   * de numero.
   *
   * LE NUMERO SE LIT AVANT, LE MENAGE SE FAIT APRES : au moment ou le coeur
   * emet l'evenement, la ligne retiree est ENCORE dans le document, mesure
   * faite le matin meme sur la carte du montage. Son rang se lit donc
   * maintenant, et le reste au tour suivant.
   */
  /*
   * UN SEUL REDESSIN PAR SALVE, ET LE MONTAGE NE CLIGNOTE PLUS.
   *
   * « J'ai eu l'impression que tout avait bugge puis c'est revenu », Cyrille,
   * 22 septembre 2026, en retirant une rangee. Mesure sur le banc : la carte
   * etait redessinee TROIS fois pour un seul retrait, et les etats
   * intermediaires sont faux par construction. Entre le moment ou la rangee
   * part et celui ou ses blocs sont retires, le montage designe une rangee qui
   * n'existe plus : la carte le disait, et c'etait juste, mais illisible.
   *
   * `menage` SUSPEND LE DESSIN LE TEMPS D'UNE OPERATION EN PLUSIEURS TEMPS.
   * Rien ne se perd : le dessin final montre l'etat final, et lui seul.
   */
  function redessiner() {
    if (menage || dessinDemande) { return; }

    dessinDemande = window.setTimeout(function () {
      dessinDemande = null;
      dessiner();
    }, 0);
  }

  function rangeeRetiree(ligne) {
    var hoteRangees = document.querySelector('joomla-field-subform[name="jform[params][rangees]"]');
    var hoteBlocs   = document.querySelector('joomla-field-subform[name="jform[params][blocs]"]');

    if (!hoteRangees || !hoteBlocs || !ligne) { return; }

    var rangs = rangeesDe(hoteRangees);
    var numero = rangs.indexOf(ligne) + 1;

    if (numero === 0) { return; }

    // Un remplacement vide tout : le menage ligne a ligne n'a rien a y faire.
    if (remplacement) { return; }

    menage = true;

    window.setTimeout(function () {
      var aRetirer = [];

      rangeesDe(hoteBlocs).forEach(function (bloc) {
        var champ = [].slice.call(bloc.querySelectorAll('[name$="[rangee]"]'))
          .filter(function (e) {
            return e.closest('.subform-repeatable-group') === bloc;
          })[0];

        if (!champ) { return; }

        var vise = parseInt(champ.value, 10) || 1;

        if (vise === numero) {
          aRetirer.push(bloc);

          return;
        }

        if (vise > numero) {
          champ.value = String(vise - 1);
          champ.dispatchEvent(new Event('change', { bubbles: true }));
        }
      });

      /*
       * ON RETIRE APRES AVOIR TOUT LU. Chaque retrait reecrit les noms de
       * toutes les lignes suivantes : lire et retirer dans la meme boucle,
       * c'est lire des lignes qui ne sont deja plus celles qu'on croit.
       */
      aRetirer.forEach(function (bloc) {
        var moins = bloc.querySelector('.group-remove');

        if (moins) { moins.click(); }
      });

      menage = false;
      dessiner();
    }, 0);
  }

    form.addEventListener('subform-row-remove', function (ev) {
      var ligne = ev.detail && ev.detail.row;
      var liste = ligne && ligne.closest ? ligne.closest('joomla-field-subform') : null;

      if (liste && liste.getAttribute('name') === 'jform[params][rangees]') {
        rangeeRetiree(ligne);
      }
    });

    form.addEventListener('subform-row-remove', function (ev) {
      var rangee = ev.detail && ev.detail.row;
      var tableau = rangee && rangee.closest ? rangee.closest('table') : null;

      /*
       * ON COMPTE AU TOUR SUIVANT. Au moment de l evenement la ligne retiree
       * est ENCORE dans le document : compter tout de suite, c est compter une
       * ligne de trop, et le `+` de l en-tete restait cache sur une liste
       * devenue vide. Plus aucune rangee ne pouvait alors etre ajoutee. Mesure
       * du 22 septembre 2026, meme piege que la carte du montage le matin.
       */
      if (tableau) { window.setTimeout(function () { plusDeTete(tableau); }, 0); }
    });

    /*
     * Les outils d'une rangee se posent a l'ajout AUSSI, et pas seulement au
     * chargement : une rangee neuve sort du gabarit, elle n'a ni roue, ni
     * sous-blocs, ni pictogrammes. L'evenement s'appelle `subform-row-add`,
     * SANS prefixe `joomla:`.
     */
    /*
     * ON RETIENT LA LIGNE D'OU VIENT LE CLIC, EN PHASE DE CAPTURE.
     *
     * Le coeur n'annonce pas QUI a demande l'ajout : son evenement porte la
     * ligne neuve, pas le bouton. On note donc la ligne du `+` avant que le
     * clic n'atteigne le composant, et on s'en sert juste apres.
     *
     * LE `+` DE L'EN-TETE N'EST PAS DANS UNE LIGNE : il n'y a alors rien a
     * copier, et la ligne neuve reste vierge. C'est la bonne reponse, c'est
     * la premiere.
     */
    var sourceDuPlus = null;

    form.addEventListener('click', function (ev) {
      var bouton = ev.target.closest ? ev.target.closest('.group-add') : null;

      /*
       * UN CLIC PROGRAMME NE DUPLIQUE PAS, ET IL FALLAIT LE DIRE.
       *
       * Le `+` d une ligne la duplique, c est voulu depuis le 21 septembre.
       * Mais `ajouterLigne` s en sert aussi pour poser les lignes d un
       * modele : la deuxieme carte naissait donc avec le contenu de la
       * premiere, puis recevait le sien par-dessus. Trois cartes, et la
       * troisieme en portait neuf elements. Releve en front le 23 septembre
       * 2026, apres le referentiel des cartes.
       *
       * `opusDirect` EST LE MEME LAISSEZ-PASSER QUE POUR LE MENU DU `+`,
       * pose par `ajouterLigne` le temps du clic. Une main qui clique ne le
       * porte jamais.
       */
      sourceDuPlus = (bouton && !bouton.dataset.opusDirect)
        ? bouton.closest('.subform-repeatable-group')
        : null;
    }, true);

    /*
     * UN DRAPEAU, PARCE QUE LA COPIE SE MORD LA QUEUE. Dupliquer un bloc
     * ajoute ses cartes, chaque ajout relance cet ecouteur, et l'on copierait
     * la copie. Le temps d'une duplication, on ne duplique plus.
     */
    var enCopie = false;

    form.addEventListener('subform-row-add', function (ev) {
      var rangee = ev.detail && ev.detail.row;

      if (!rangee) { return; }

      var source = sourceDuPlus;
      sourceDuPlus = null;

      if (source && !enCopie && source !== rangee
        && source.parentNode === rangee.parentNode) {
        enCopie = true;

        try {
          dupliquerLigne(source, rangee);
        } finally {
          enCopie = false;
        }
      }

      pastiller(rangee);
      outils(rangee);

      /*
       * UNE LIGNE NEUVE APPORTE SES PROPRES LISTES, ET ELLES ARRIVENT NUES.
       *
       * « J ai cree une troisieme carte et je n ai pas le chevron pour la
       * replier », Cyrille, 22 septembre 2026. Exact : le chevron se posait au
       * chargement, sur les listes presentes a ce moment-la. Une carte ajoutee
       * apres coup amene sa pile d elements, que personne n outillait.
       *
       * LE NOM DU CHAMP, JAMAIS SON INTITULE : un `name` ne se traduit pas.
       */
      [].slice.call(rangee.querySelectorAll('joomla-field-subform')).forEach(function (sf) {
        if (/\[(elements|boutons|cartes)\]$/.test(sf.getAttribute('name') || '')) {
          chevronDeListe(sf);
          surveillerOrdre(sf);
        }
      });

      /*
       * UNE LISTE VIDE N'A PAS DE COLONNES A RANGER, et c'est pourquoi on
       * recommence ici. Tant qu'aucune ligne n'existe, il n'y a rien pour dire
       * quelle colonne porte la roue ni laquelle porte des icones : le tableau
       * garde tous ses intitules. La premiere ligne ajoutee donne la reponse.
       */
      var tableau = rangee.closest ? rangee.closest('table') : null;

      if (tableau) {
        outilsEnTete(tableau);
        masquerColonnes(tableau);
        tetesVides(tableau);
        entetesMuettes(tableau);
        colonnesEtroites(tableau);
        repartirLargeurs(tableau);
        plusDeTete(tableau);
      }

      if (rangee.querySelector) { indications(rangee); }
    });

    jauger();
    panneauClasses();
    allumerModeles();
    brancherPlancheIcones();
    poserBoutonValider();
    pastillerLesLignesDIcones();
    brancherRetraitIcone();

    // 3. Le dessin au chargement, celui qu'on oublie.
    outillerTout();
    numeroterCartes();
    dessiner();

    if (modeSite() && !modeFenetre()) {
      filtrerSite();
      quandLeFormulaireEstPret(filtrerSite);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', demarrer);
  } else {
    demarrer();
  }
})();
