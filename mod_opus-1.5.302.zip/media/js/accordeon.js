/**
 * UN SEUL VOLET OUVERT A LA FOIS - 24 septembre 2026
 *
 * « Il faudrait qu'il n'y ait toujours qu'une ligne qui reste ouverte, que ce
 * soit pour Corpus ou Cassiopeia. » Cyrille.
 *
 * POURQUOI UN FICHIER A PART, ET CHARGE TOUJOURS. L'ouverture d'un volet est
 * faite par `template.js` de Corpus quand il est la, et par `sans-corpus.js`
 * quand il ne l'est pas. La FERMETURE DES AUTRES n'appartient ni a l'un ni a
 * l'autre : c'est une regle du module, et elle doit valoir dans les deux cas.
 * Ecrite en double, elle aurait divergé au premier changement.
 *
 * IL NE FAIT RIEN D'AUTRE QUE FERMER LES VOISINS. C'est le clic qui l'appelle,
 * apres que l'autre script a fait son travail : le volet vise est deja ouvert
 * ou ferme quand nous arrivons. On ne touche qu'aux AUTRES, ce qui evite de se
 * battre avec lui pour savoir qui decide.
 *
 * ON N'INTERCEPTE RIEN. Pas de `preventDefault`, pas de `stopPropagation` :
 * deux scripts qui se disputent le meme clic finissent toujours par se
 * contredire un jour. Celui-ci passe apres et range.
 *
 * REFERMER UN VOLET RESTE POSSIBLE : cliquer sur celui qui est ouvert le
 * ferme, et la page n'a alors plus rien d'ouvert. Forcer un volet ouvert en
 * permanence empecherait de tout replier pour voir la liste des questions,
 * qui est souvent ce qu'on cherche.
 */
(function () {
	'use strict';

	document.addEventListener('click', function (e) {
		var bouton = e.target.closest ? e.target.closest('.accordeon__bouton') : null;

		if (!bouton) { return; }

		var accordeon = bouton.closest('.opus .accordeon');

		if (!accordeon) { return; }

		/*
		 * LE TOUR SUIVANT, ET PAS AVANT. Les deux autres scripts ecoutent le
		 * meme clic ; lu a l'instant meme, `aria-expanded` porte encore l'etat
		 * d'avant. Meme piege que le panneau de reglages du formulaire
		 * d'administration, et meme remede.
		 */
		window.setTimeout(function () {
			if (bouton.getAttribute('aria-expanded') !== 'true') { return; }

			Array.prototype.forEach.call(
				accordeon.querySelectorAll('.accordeon__bouton'),
				function (autre) {
					if (autre === bouton) { return; }
					if (autre.closest('.accordeon') !== accordeon) { return; }
					if (autre.getAttribute('aria-expanded') !== 'true') { return; }

					autre.setAttribute('aria-expanded', 'false');

					var volet = document.getElementById(autre.getAttribute('aria-controls'));

					if (volet) { volet.hidden = true; }
				}
			);
		}, 0);
	});
})();
