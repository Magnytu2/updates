/**
 * LE COMPORTEMENT, POUR UN SITE QUI N'EMPLOIE PAS CORPUS - 24 septembre 2026
 *
 * DEUX CHOSES SEULEMENT, ET AUCUNE N'EST DECORATIVE.
 *
 *   1. L'ACCORDEON. Sans lui, les volets ne s'ouvrent pas : ce n'est pas une
 *      question de style, c'est une fonction morte. Douze lignes dans
 *      `template.js` de Corpus (l. 634), reprises telles quelles.
 *
 *   2. LA VISIONNEUSE DE LA GALERIE. Sans elle, les images restent visibles
 *      avec leur legende et la page garde tout son sens : c'est un manque, pas
 *      une panne. Elle est reprise quand meme, parce qu'une galerie qui ne
 *      s'agrandit pas n'est plus une galerie.
 *
 * IL NE SE CHARGE QUE SANS CORPUS, comme `sans-corpus.css` : le repartiteur
 * regarde si `template.corpus` est declare. Zero octet pour les utilisateurs de
 * Corpus, et aucun risque que les deux scripts se marchent dessus.
 *
 * LES INTITULES VIENNENT DES LANGUES DU MODULE, pas de celles du template :
 * `TPL_CORPUS_*` n'existe pas sur un site sans Corpus.
 */
(function () {
	'use strict';

	function dire(cle, repli) {
		if (window.Joomla && Joomla.Text && Joomla.Text._) {
			var t = Joomla.Text._(cle);

			if (t && t !== cle) { return t; }
		}

		return repli;
	}

	/* ---------------------------------------------------------------------
	   L'ACCORDEON

	   LE BALISAGE EST CELUI DU TAMPON DE CORPUS, a la lettre : le bouton porte
	   `aria-expanded` et `aria-controls`, le volet porte `hidden`. On ne fait
	   que basculer les deux, ce qui suffit a l'annoncer correctement.
	   --------------------------------------------------------------------- */
	Array.prototype.forEach.call(
		document.querySelectorAll('.opus .accordeon__bouton'),
		function (b) {
			b.addEventListener('click', function () {
				var ouvert = b.getAttribute('aria-expanded') === 'true';

				b.setAttribute('aria-expanded', String(!ouvert));

				var volet = document.getElementById(b.getAttribute('aria-controls'));

				if (volet) { volet.hidden = ouvert; }
			});
		}
	);

	/* ---------------------------------------------------------------------
	   LA VISIONNEUSE DE LA GALERIE

	   POURQUOI `<dialog>` ET PAS UNE BIBLIOTHEQUE, et la raison est celle de
	   Corpus : `showModal()` enferme le clavier dans la boite et rend la touche
	   Echap, gratuitement. Une bibliotheque tierce refait ces deux choses a la
	   main, moins bien, et ajoute un fichier a charger.

	   SI LE NAVIGATEUR NE CONNAIT PAS `showModal()`, ON NE FAIT RIEN : les
	   images restent visibles avec leur legende, la page garde tout son sens.
	   --------------------------------------------------------------------- */
	Array.prototype.forEach.call(
		document.querySelectorAll('.opus .galerie-agrandir'),
		function (galerie) {
			var boutons = Array.prototype.slice.call(galerie.querySelectorAll('button'));

			if (!boutons.length
				|| typeof HTMLDialogElement === 'undefined'
				|| !HTMLDialogElement.prototype.showModal) { return; }

			var boite = document.createElement('dialog');
			boite.className = 'opus-visionneuse';
			boite.innerHTML = '<div class="opus-visionneuse__corps">'
				+ '<img src="" alt="">'
				+ '<p class="opus-visionneuse__legende"></p>'
				+ '<div class="opus-visionneuse__pied">'
				+ '<button type="button" data-aller="-1"></button>'
				+ '<button type="button" data-aller="1"></button>'
				+ '<p class="opus-visionneuse__rang" aria-live="polite"></p>'
				+ '<button type="button" data-fermer></button>'
				+ '</div></div>';
			document.body.appendChild(boite);

			var image = boite.querySelector('img');
			var legende = boite.querySelector('.opus-visionneuse__legende');
			var rang = boite.querySelector('.opus-visionneuse__rang');
			var precedente = boite.querySelector('[data-aller="-1"]');
			var suivante = boite.querySelector('[data-aller="1"]');

			precedente.textContent = dire('MOD_OPUS_GAL_PREV', 'Precedente');
			suivante.textContent = dire('MOD_OPUS_GAL_NEXT', 'Suivante');
			boite.querySelector('[data-fermer]').textContent = dire('MOD_OPUS_GAL_CLOSE', 'Fermer');

			// Une seule image : les deux fleches n'ont plus d'objet. On les
			// retire plutot que de les desactiver, un bouton grise se lit
			// quand meme.
			if (boutons.length === 1) { precedente.remove(); suivante.remove(); }

			var courant = 0;
			var depart = null;

			function montrer(i) {
				courant = (i + boutons.length) % boutons.length;

				var vignette = boutons[courant].querySelector('img');

				if (!vignette) { return; }

				image.src = vignette.getAttribute('data-grande') || vignette.src;
				image.alt = vignette.alt;

				// LA LEGENDE EST LE `figcaption` DE LA FIGURE D'OU L'ON PART,
				// pas un attribut de plus. LE TEXTE, PAS LE BALISAGE : rien de
				// ce qui vient du contenu ne devient du HTML dans la boite.
				var figure = boutons[courant].closest('figure');
				var source = figure ? figure.querySelector('figcaption') : null;
				var dit = source ? source.textContent.trim().replace(/\s+/g, ' ') : '';

				legende.textContent = dit;
				legende.hidden = dit === '';

				rang.textContent = dire('MOD_OPUS_GAL_RANK', '%1$s / %2$s')
					.replace('%1$s', courant + 1)
					.replace('%2$s', boutons.length);
			}

			boutons.forEach(function (b, i) {
				b.setAttribute('aria-haspopup', 'dialog');

				b.addEventListener('click', function () {
					depart = b;
					montrer(i);
					boite.showModal();
				});
			});

			if (boutons.length > 1) {
				precedente.addEventListener('click', function () { montrer(courant - 1); });
				suivante.addEventListener('click', function () { montrer(courant + 1); });

				boite.addEventListener('keydown', function (e) {
					if (e.key === 'ArrowLeft') { montrer(courant - 1); }
					if (e.key === 'ArrowRight') { montrer(courant + 1); }
				});
			}

			boite.querySelector('[data-fermer]').addEventListener('click', function () {
				boite.close();
			});

			// Echap est rendu par `<dialog>`. On n'ecoute que la fermeture,
			// pour rendre le focus : sans cela la personne au clavier repart du
			// haut de la page et doit refaire tout le chemin.
			boite.addEventListener('close', function () {
				if (depart) { depart.focus(); }
			});
		}
	);
})();
