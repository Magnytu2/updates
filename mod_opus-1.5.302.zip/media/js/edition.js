/**
 * Opus : le crayon du module ouvre une grande fenetre.
 *
 * Charge seulement pour une personne connectee qui peut modifier un module
 * Opus de la page (voir `ouvrirEnFenetre` dans le repartiteur). Un visiteur
 * ne le recoit jamais.
 *
 * POURQUOI UNE FENETRE : l'ecran de modification de Joomla s'affiche, sur le
 * site, dans la colonne de contenu du template, 575 px chez Corpus. L'ecran
 * d'Opus n'y tient pas. Dans la fenetre, il est rendu sans le template
 * (`tmpl=component`) et prend toute la largeur, comme en administration.
 *
 * LE `dialog` NATIF apporte Echap, le piegeage du clavier et le fond inerte,
 * mieux faits que ce qu'on ecrirait.
 *
 * SOUS 62 rem DE LARGE, ON NE L'OUVRE PAS. Decision de Cyrille : pas de
 * telephone. 62 rem est le seuil ou l'ecran d'administration d'Opus passe
 * deja sur une colonne : en dessous, on dit pourquoi, au lieu d'ouvrir un
 * ecran inutilisable.
 */
(function () {
  'use strict';

  var LARGEUR_MIN = 62 * 16;

  function texte(cle, defaut) {
    var v = window.Joomla && Joomla.Text ? Joomla.Text._(cle) : '';

    return v && v !== cle ? v : defaut;
  }

  function ids() {
    var o = window.Joomla && Joomla.getOptions ? Joomla.getOptions('mod_opus.edition') : null;

    return o && o.ids ? o.ids : [];
  }

  function avecTmpl(url) {
    return /[?&]tmpl=component\b/.test(url) ? url : url + (url.indexOf('?') === -1 ? '?' : '&') + 'tmpl=component';
  }

  function ouvrir(url) {
    // Une seule fenetre a la fois : un double clic en ouvrait deux, l'une sous l'autre.
    if (document.querySelector('dialog.opus-fenetre[open]')) { return; }

    var fenetre = document.createElement('dialog');
    fenetre.className = 'opus-fenetre';
    fenetre.setAttribute('aria-label', texte('MOD_OPUS_WINDOW_TITLE', 'Opus'));

    var fermer = document.createElement('button');
    fermer.type = 'button';
    fermer.className = 'opus-fenetre__fermer';
    fermer.setAttribute('aria-label', texte('MOD_OPUS_WINDOW_CLOSE', 'Fermer'));
    fermer.textContent = '×';
    fermer.addEventListener('click', function () { fenetre.close(); });
    fenetre.appendChild(fermer);

    if (window.innerWidth < LARGEUR_MIN) {
      var avis = document.createElement('div');
      avis.className = 'opus-fenetre__avis';

      var titre = document.createElement('p');
      titre.className = 'opus-fenetre__titre';
      titre.textContent = texte('MOD_OPUS_WINDOW_SMALL_TITLE', 'Ecran trop etroit');

      var desc = document.createElement('p');
      desc.textContent = texte('MOD_OPUS_WINDOW_SMALL_DESC', '');

      avis.appendChild(titre);
      avis.appendChild(desc);
      fenetre.appendChild(avis);
      fenetre.classList.add('opus-fenetre--etroite');
    } else {
      var cadre = document.createElement('iframe');
      cadre.className = 'opus-fenetre__cadre';
      cadre.title = texte('MOD_OPUS_WINDOW_TITLE', 'Opus');
      cadre.src = avecTmpl(url);

      /*
       * APRES CHAQUE CHARGEMENT DU CADRE. « Enregistrer et fermer » et
       * « Annuler » renvoient a la page d'origine : le cadre n'est plus sur
       * `com_config`, on ferme et on recharge la page pour montrer le
       * resultat. « Enregistrer » revient sur le formulaire, mais le coeur
       * oublie `tmpl=component` en chemin : on le remet, une fois.
       */
      cadre.addEventListener('load', function () {
        var ici;

        try { ici = cadre.contentWindow.location.href; } catch (e) { return; }

        if (!/[?&]option=com_config\b/.test(ici)) {
          fenetre.close();
          window.location.reload();

          return;
        }

        if (!/[?&]tmpl=component\b/.test(ici)) { cadre.src = avecTmpl(ici); }
      });

      fenetre.appendChild(cadre);
    }

    fenetre.addEventListener('close', function () { fenetre.remove(); });
    document.body.appendChild(fenetre);
    fenetre.showModal();
    fermer.focus();
  }

  /*
   * LE CRAYON EST CELUI DU COEUR (`a.jmodedit`, pose par
   * `layouts/joomla/edit/frontediting_modules.php`). On l'ecoute en phase de
   * capture, et seulement pour les modules Opus de la liste : les crayons
   * des autres modules gardent leur comportement.
   */
  document.addEventListener('click', function (ev) {
    var lien = ev.target && ev.target.closest ? ev.target.closest('a.jmodedit') : null;

    if (!lien) { return; }

    var m = /[?&]id=(\d+)/.exec(lien.getAttribute('href') || '');

    if (!m || ids().indexOf(parseInt(m[1], 10)) === -1) { return; }

    ev.preventDefault();
    ev.stopPropagation();
    ouvrir(lien.href);
  }, true);
})();
