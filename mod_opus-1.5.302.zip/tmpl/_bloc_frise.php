<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE BLOC FRISE : UNE SUITE D'ETAPES LE LONG D'UN AXE.
 *
 * Demande de Cyrille, 24 septembre 2026 : « un montage sur deux axes pour
 * presenter une echelle de temps, par exemple une entreprise qui evolue ».
 *
 * MEME MECANIQUE QUE LES ONGLETS ET LES CARTES, A LA LETTRE. Une etape porte
 * son repere, la date ou le jalon, et une pile d'elements qu'on ordonne
 * librement. Rien de neuf a apprendre pour qui a deja rempli une carte.
 *
 * UNE LISTE ORDONNEE, ET C'EST LE POINT DE BALISAGE QUI COMPTE. `ol` dit que
 * l'ordre porte du sens, ce qui est exactement le cas d'une frise : 2019 vient
 * avant 2021. Une suite de `div` ne le dirait a personne, et un lecteur d'ecran
 * annonce « liste de six elements », ce qui situe d'emblee.
 *
 * PAS UNE LIGNE DE JAVASCRIPT. L'axe est une bordure, les pastilles des
 * pseudo-elements, l'alternance une grille. Les exemples de MDBootstrap qui ont
 * servi de reference font pareil, et c'est la seule chose qu'on leur emprunte :
 * ni leur balisage, ni leurs classes, ni leurs couleurs.
 *
 * LE NOM COMMENCE PAR UN UNDERSCORE : le champ `modulelayout` du coeur liste
 * les mises en page avec `Folder::files($chemin, '^[^_]*\.php$')`, et ce
 * morceau n'a rien a faire dans cette liste.
 */

\defined('_JEXEC') or die;

/*
 * LE SENS ET LA POSE, LUS UNE FOIS, CONTRE DES LISTES FERMEES.
 *
 * L'alternance n'existe qu'a la verticale : a l'horizontale, les etapes sont
 * deja de part et d'autre de l'axe par construction, et « alterne » n'y voudrait
 * rien dire. Le manifeste le dit par un `showon`, on le redit ici parce qu'un
 * montage enregistre avant un changement de sens garde son ancienne valeur.
 */
$sens = ($bloc->friseSens ?? 'vertical') === 'horizontal' ? 'horizontal' : 'vertical';
$pose = ($bloc->frisePose ?? 'cote') === 'alterne' ? 'alterne' : 'cote';

$habits = ['opus__frise', 'opus__frise--' . $sens];

if ($sens === 'vertical' && $pose === 'alterne') {
    $habits[] = 'opus__frise--alterne';
}

if ($bloc->classe !== '') {
    $habits[] = $bloc->classe;
}
?>
<ol class="<?php echo implode(' ', $habits); ?>"<?php echo $bloc->attrId; ?>>

	<?php foreach ($bloc->etapes as $etape) : ?>
		<?php
		$habitsEtape = ['opus__etape'];

		if ($etape->ton !== '') {
			$habitsEtape[] = 'opus__etape--' . $etape->ton;
		}
		?>
		<li class="<?php echo implode(' ', $habitsEtape); ?>">

			<?php if ($etape->repere !== '') : ?>
				<?php
				/*
				 * LE REPERE EST DU TEXTE LIBRE, PAS UNE DATE MACHINE.
				 *
				 * Pas de `<time datetime="...">` : une frise d'entreprise porte
				 * « 2019 », « Printemps 2021 », « Aujourd'hui ». Ecrire un
				 * attribut `datetime` demanderait d'inventer un jour et un mois
				 * que personne n'a saisis, et une date fausse dans le balisage
				 * est pire qu'une date absente.
				 */
				?>
				<p class="opus__etape-repere"><?php echo htmlspecialchars($etape->repere, ENT_QUOTES, 'UTF-8'); ?></p>
			<?php endif; ?>

			<div class="opus__etape-corps">
				<?php
				$liste       = $etape->pile;
				$classeImage = 'opus__image';

				require \Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_opus', '_elements');
				?>
			</div>

		</li>
	<?php endforeach; ?>

</ol>
