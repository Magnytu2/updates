<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * L'AIGUILLAGE D'UN BLOC.
 *
 * Il ne fait qu'une chose : appeler le morceau qui sait dessiner ce type de
 * bloc. Un integrateur qui veut changer UN type de bloc surcharge ce
 * morceau-la et rien d'autre.
 *
 * LE NOM COMMENCE PAR UN UNDERSCORE : le champ `modulelayout` du coeur liste
 * les mises en page avec `Folder::files($chemin, '^[^_]*\.php$')`, et ce
 * fichier n'a rien a faire dans cette liste.
 *
 * Il attend `$bloc` et `$clefBloc`, poses par default.php, et partage toutes
 * les autres variables.
 */

\defined('_JEXEC') or die;

/*
 * UN BLOC VIDE NE SORT PAS, ET CE N'EST PAS LA MEME CHOSE QU'UN BLOC MASQUE.
 *
 * Masque, il est ecarte plus tot, par l'assistant. Vide, c'est qu'on l'a
 * ajoute et pas encore rempli : il ne doit pas laisser un cadre et une
 * gouttiere dans la page en attendant.
 */

/*
 * ON REPREND L'ASSISTANT DU REPARTITEUR, ON N'EN FABRIQUE PAS UN AUTRE.
 *
 * Ce fichier ecrivait `new BlocsHelper()`, ce qui n'avait l'air de rien : les
 * methodes employees ici ne dependaient d'aucun etat. Depuis le 25 septembre
 * 2026, l'assistant PORTE la liste des icones declarees, posee une fois par le
 * repartiteur. Une seconde instance arrive vide, et `$helper` etant une
 * variable partagee par tous les fichiers de `tmpl/`, elle remplacait la bonne
 * pour tout le reste de la page : les boutons ne dessinaient plus aucune icone
 * a soi, sans erreur, alors que l'administration les proposait bien. Mesure
 * sur le banc le 25 septembre 2026.
 *
 * UN OBJET QUI PORTE UN ETAT NE SE REFABRIQUE PAS AU MILIEU D'UN RENDU. Le
 * repli `?? new` couvre un gabarit recopie dans un template qui n'aurait pas
 * recu la variable.
 */
$helper = $helper ?? new \Joomanji\Module\Opus\Site\Helper\BlocsHelper();

if (!$helper->blocRempli($bloc)) {
    return;
}

/*
 * LE FICHIER EST CHOISI PAR UNE LISTE BLANCHE, JAMAIS PAR LE TYPE BRUT.
 *
 * `require '_bloc_' . $bloc->type . '.php'` aurait marche, et aurait aussi
 * laisse une valeur venue de la base decider quel fichier est inclus. La
 * valeur ne peut pas sortir du manifeste aujourd'hui ; elle le pourrait apres
 * un import, une migration ou une saisie directe en base.
 */
$connus = [
    'ouverture' => '_bloc_ouverture',
    'cartes'    => '_bloc_cartes',
    'galerie'   => '_bloc_galerie',
    'carrousel' => '_bloc_carrousel',
    'onglets'   => '_bloc_onglets',
    'frise'     => '_bloc_frise',
];

if (!isset($connus[$bloc->type])) {
    return;
}

require \Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_opus', $connus[$bloc->type]);
