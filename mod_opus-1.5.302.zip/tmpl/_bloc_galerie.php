<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE BLOC GALERIE : une grille d'images, chacune avec sa legende.
 *
 * L'AGRANDISSEMENT EST CELUI DE CORPUS, PAS LE NOTRE.
 *
 * Premiere version ecrite le 23 septembre 2026 : un visionneur a moi, dans un
 * `dialog`. Reponse de Cyrille, le jour meme : « ce n'est pas le format de
 * visionneuse que nous avions mis en place dans Corpus ». Exact, et c'etait
 * deux fois une faute : un deuxieme visionneur a maintenir, et deux
 * agrandissements differents sur le meme site selon qu'on passe par un tampon
 * de l'editeur ou par le module.
 *
 * LE TEMPLATE FAIT TOUT, ET IL LE FAIT DEJA : `template.js` l. 665 branche
 * `.galerie-agrandir`, fabrique la boite `.visionneuse`, ses boutons traduits,
 * la position « 2 sur 3 » en zone `aria-live`, les fleches du clavier, Echap,
 * et rend le focus a la vignette de depart. `template.css` l. 2811 a 2880
 * l'habille. Le module n'a donc qu'une chose a faire : ecrire le balisage que
 * ce script attend, celui du tampon « Images - Galerie agrandissable » :
 *
 *     .galerie-agrandir > figure > button > img   +   figcaption
 *
 * SANS CORPUS, ON ECRIT UN LIEN, PAS UN BOUTON. Un bouton sans le script du
 * template ne ferait rien du tout : l'agrandissement disparaitrait sans que
 * rien ne le remplace. Le lien, lui, ouvre l'image. La presence du script se
 * lit par `assetExists`, comme le Dispatcher le fait deja pour la feuille.
 *
 * POURQUOI CE N'EST PAS UNE GRILLE DE CARTES. Une carte est une boite qu'on
 * remplit ; une vignette de galerie EST son image. Trois differences la
 * tiennent a part : la legende est LIEE a l'image par `figure` + `figcaption`,
 * le format s'impose a toutes sinon la grille ondule, et l'image s'agrandit au
 * lieu de mener a une page.
 *
 * LA SOURCE DE DONNEES EST CELLE DES CARTES, ET C'EST VOULU. Une entree de
 * galerie est une pile d'elements comme les autres : la premiere image est la
 * vignette, tout ce qui suit devient la legende. Le manifeste n'a donc pas une
 * troisieme copie de la pile a tenir synchronisee.
 *
 * LE NOM COMMENCE PAR UN UNDERSCORE : le champ `modulelayout` du coeur liste
 * les mises en page avec `Folder::files($chemin, '^[^_]*\.php$')`.
 *
 * Appele par `_bloc.php`, il partage ses variables et attend `$bloc`.
 */

\defined('_JEXEC') or die;

$format   = (string) ($bloc->galFormat ?? '1-1');
$mini     = (int) ($bloc->galMini ?? 12);
$ecart    = (string) ($bloc->galEcart ?? 'normal');
$legendes = (string) ($bloc->galLegende ?? 'dessous');
$agrandir = (int) ($bloc->galAgrandir ?? 1) === 1;

// Une borne qui corrige en silence est un bug : hors bornes, on retombe sur
// le defaut, qui est la seule valeur que l'on puisse justifier.
if ($mini < 4 || $mini > 60) {
    $mini = 12;
}

/*
 * LA VISIONNEUSE DU TEMPLATE EST-ELLE LA ?
 *
 * `template.corpus` est le script du template, declare par son `index.php`.
 *
 * IL N'EST PLUS LE SEUL A SAVOIR AGRANDIR - 24 septembre 2026. Depuis que
 * `sans-corpus.js` existe, un site sans Corpus recoit sa propre visionneuse,
 * posee par le repartiteur dans les memes conditions. La question n'est donc
 * plus « Corpus est-il la ? » mais « un script saura-t-il prendre le bouton
 * en charge ? », et la reponse est oui dans les deux cas.
 *
 * ON GARDE LA MESURE, parce qu'un integrateur peut avoir surcharge cette mise
 * en page dans son template : `$avecCorpus` reste lisible pour qui en a
 * besoin, il ne commande simplement plus l'agrandissement.
 */
$avecCorpus = $app->getDocument()->getWebAssetManager()->assetExists('script', 'template.corpus');

$classes = ['opus__galerie', 'opus__galerie--ecart-' . $ecart];

if ($format !== '') {
    $classes[] = 'opus__galerie--' . $format;
}

if ($legendes === 'survol') {
    $classes[] = 'opus__galerie--survol';
}

// La classe que le script du template cherche. Elle n'est posee que s'il y a
// quelque chose a agrandir : sinon elle promettrait un geste qui n'existe pas.
if ($agrandir) {
    $classes[] = 'galerie-agrandir';
}

if ($bloc->classe !== '') {
    $classes[] = $bloc->classe;
}
?>
<div class="<?php echo implode(' ', $classes); ?>"
     style="--opus-vignette-mini: <?php echo $mini; ?>rem"<?php echo $bloc->attrId; ?>>

	<?php foreach ($bloc->cartes as $carte) : ?>
		<?php
		$pile   = $carte->pile ?? [];
		$visuel = null;

		/*
		 * LA VIGNETTE EST LA PREMIERE IMAGE DE LA PILE, ou qu'elle soit. On la
		 * detache avant de dessiner la legende, pour ne pas la dessiner deux
		 * fois.
		 */
		foreach ($pile as $rang => $el) {
			if (($el->type ?? '') === 'image' && !empty($el->visuel)) {
				$visuel = $el;
				unset($pile[$rang]);
				break;
			}
		}

		/*
		 * UNE ENTREE SANS IMAGE NE SORT PAS : dans une galerie il n'y a rien a
		 * montrer a sa place, et la case vide prendrait la hauteur de ses
		 * voisines.
		 */
		if ($visuel === null) {
			continue;
		}

		$pile = array_values($pile);
		$lien = $carte->lien ?? [];
		$href = $lien['href'] ?? '';

		/*
		 * LE LIEN CHOISI L'EMPORTE SUR L'AGRANDISSEMENT. Une image qui mene a
		 * une page ne doit pas mener a elle-meme : l'agrandissement est un
		 * repli, jamais une surcharge.
		 */
		$bouton = $agrandir && $href === '';
		$vers   = $href !== '' ? $href : ($agrandir ? $visuel->visuel['src'] : '');

		/*
		 * LE NOM DU BOUTON EST LA DESCRIPTION DE L'IMAGE, comme dans le tampon
		 * de l'editeur. Une image decorative n'en a pas : sa legende prend
		 * alors le relais, faute de quoi le bouton ne dirait rien du tout.
		 */
		/*
		 * LA LEGENDE VIENT DE L IMAGE, ET SEULEMENT SINON DE LA PILE.
		 *
		 * Le champ « Legende » vit derriere la roue de l element image depuis le
		 * 23 septembre 2026 : c est la ou on l attend, et c est le seul endroit
		 * d ou elle peut suivre l image dans la visionneuse. Le reste de la pile
		 * reste accepte, pour les galeries montees avant ce champ et pour qui
		 * veut une legende de plusieurs elements.
		 */
		$dite = trim((string) ($visuel->imgLegende ?? ''));

		$nom = trim((string) $visuel->visuel['alt']);

		if ($nom === '') {
			$nom = $dite;
		}

		if ($nom === '' && $pile !== []) {
			$nom = trim(strip_tags((string) ($pile[0]->body ?? $pile[0]->label ?? '')));
		}

		$img = '<img class="opus__vignette-image"'
			. ' src="' . htmlspecialchars($visuel->visuel['src'], ENT_QUOTES, 'UTF-8') . '"'
			. ' alt="' . htmlspecialchars($visuel->visuel['alt'], ENT_QUOTES, 'UTF-8') . '"'
			. ($visuel->visuel['width'] ? ' width="' . (int) $visuel->visuel['width'] . '"' : '')
			. ($visuel->visuel['height'] ? ' height="' . (int) $visuel->visuel['height'] . '"' : '')
			. (!empty($visuel->imageCharge) ? ' loading="eager" fetchpriority="high"' : ' loading="lazy"')
			. ' decoding="async">';
		?>
		<figure class="opus__vignette<?php echo $carte->blocsBrut !== '' ? ' ' . $carte->blocsBrut : ''; ?>"<?php echo $carte->attrId; ?>>

			<?php if ($bouton) : ?>
				<button type="button"<?php echo $nom !== '' ? ' aria-label="' . htmlspecialchars($nom, ENT_QUOTES, 'UTF-8') . '"' : ''; ?>>
					<?php echo $img; ?>
				</button>
			<?php elseif ($vers !== '') : ?>
				<a class="opus__vignette-lien"
				   href="<?php echo htmlspecialchars($vers, ENT_QUOTES, 'UTF-8'); ?>"
				   <?php if (!empty($lien['target'])) : ?>
				   target="<?php echo $lien['target']; ?>" rel="<?php echo $lien['rel']; ?>"
				   <?php endif; ?>>
					<?php echo $img; ?>
					<?php if (!empty($lien['mention'])) : ?>
						<span class="visually-hidden"><?php echo $lien['mention']; ?></span>
					<?php endif; ?>
				</a>
			<?php else : ?>
				<?php echo $img; ?>
			<?php endif; ?>

			<?php if ($legendes !== 'aucune' && ($dite !== '' || $pile !== [])) : ?>
				<figcaption class="opus__legende">
					<?php if ($dite !== '') : ?>
						<?php echo htmlspecialchars($dite, ENT_QUOTES, 'UTF-8'); ?>
					<?php else : ?>
						<?php
						$liste       = $pile;
						$classeImage = 'opus__image';
						$lienCarte   = [];

						require \Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_opus', '_elements');
						?>
					<?php endif; ?>
				</figcaption>
			<?php endif; ?>

		</figure>
	<?php endforeach; ?>

</div>
