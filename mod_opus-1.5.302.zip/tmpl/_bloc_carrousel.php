<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE BLOC CARROUSEL : des diapositives qui defilent.
 *
 * C'EST LA SEULE FORME QUE L'ON N'OBTIENT PAS EN COMBINANT LES AUTRES. Une
 * pile, une grille de cartes et une galerie montrent tout en meme temps ;
 * celle-ci montre une chose a la fois et donne le moyen de passer a la
 * suivante. Rien dans ce qui existait ne fait defiler.
 *
 * LE DEFILEMENT VIENT DU COEUR, PAS DE NOUS.
 * `HTMLHelper::_('bootstrap.carousel')` charge le composant que Joomla livre
 * deja : le clavier, le balayage au doigt, l'arret au survol, la pause quand
 * l'onglet passe en arriere-plan. Ecrire cela a la main, ce serait dix fois
 * plus de code pour dix fois moins de cas couverts, et un defaut de plus a
 * corriger a chaque navigateur. Corpus charge `bootstrap.min.css`
 * (`index.php` l. 85), donc les classes `carousel-*` sont habillees.
 *
 * UNE DIAPOSITIVE EST UNE PILE, COMME UNE CARTE. La premiere image est le
 * fond, tout ce qui suit se pose par-dessus. Le manifeste n'a donc pas une
 * troisieme copie de la pile a tenir synchronisee.
 *
 * UNE DIAPOSITIVE SANS IMAGE NE SORT PAS : un carrousel est fait d'images, et
 * une diapositive vide laisserait un trou qui defile.
 *
 * L'IDENTIFIANT PORTE LE RANG DU BLOC. Les fleches et les pastilles designent
 * leur carrousel par `data-bs-target="#..."` : deux carrousels dans le meme
 * module avec le meme identifiant, et les fleches du second piloteraient le
 * premier, sans la moindre erreur pour le signaler.
 *
 * LE NOM COMMENCE PAR UN UNDERSCORE : le champ `modulelayout` du coeur liste
 * les mises en page avec `Folder::files($chemin, '^[^_]*\.php$')`.
 *
 * Appele par `_bloc.php`, il partage ses variables et attend `$bloc` et
 * `$clefBloc`.
 */

\defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

$format    = (string) ($bloc->carFormat ?? '16-9');
$voile     = (string) ($bloc->carVoile ?? 'doux');
$commandes = (string) ($bloc->carCommandes ?? 'cotes');
$pastilles = (int) ($bloc->carPastilles ?? 1) === 1;
$boucle    = (int) ($bloc->carBoucle ?? 1) === 1;
$auto      = (int) ($bloc->carAuto ?? 0);

/*
 * LES DIAPOSITIVES QUI ONT UNE IMAGE, ET LEUR FOND DETACHE DE LA PILE.
 *
 * Le tri se fait avant d'ecrire quoi que ce soit : le carrousel a besoin de
 * savoir COMBIEN il en reste pour decider s'il pose ses commandes, et laquelle
 * est la premiere pour lui donner `active`.
 */
$diapos = [];

foreach ($bloc->cartes as $carte) {
    $pile = $carte->pile ?? [];
    $fond = null;

    foreach ($pile as $rang => $el) {
        if (($el->type ?? '') === 'image' && !empty($el->visuel)) {
            $fond = $el;
            unset($pile[$rang]);
            break;
        }
    }

    if ($fond === null) {
        continue;
    }

    $diapos[] = (object) [
        'carte'   => $carte,
        'fond'    => $fond,
        'dessus'  => array_values($pile),
    ];
}

if ($diapos === []) {
    return;
}

$total = \count($diapos);
/*
 * LA CIBLE EST LA CLEF DU BLOC, TELLE QUELLE.
 *
 * `default.php` l. 121 la fabrique deja unique et stable :
 * `opus-<module>-<rangee>-<colonne>-<rang>`. Elle porte donc
 * l'identifiant du module, et le lui rajouter ecrirait deux fois le meme
 * prefixe.
 */
$cible = $clefBloc;

HTMLHelper::_('bootstrap.carousel', '#' . $cible, [
    'interval' => $auto > 0 ? $auto * 1000 : 0,
    'ride'     => $auto > 0 ? 'carousel' : false,
    'keyboard' => true,
    'pause'    => 'hover',
    'wrap'     => $boucle,
]);

$classes = [
    'opus__carrousel',
    'opus__carrousel--' . $format,
    'opus__carrousel--commandes-' . $commandes,
    'carousel',
    'slide',
];

if ($bloc->classe !== '') {
    $classes[] = $bloc->classe;
}
?>
<div class="<?php echo implode(' ', $classes); ?>" id="<?php echo htmlspecialchars($cible, ENT_QUOTES, 'UTF-8'); ?>">

	<div class="carousel-inner">
		<?php foreach ($diapos as $rang => $diapo) : ?>
			<div class="carousel-item<?php echo $rang === 0 ? ' active' : ''; ?>">
				<div class="opus__diapo">

					<?php
					/*
					 * LA PREMIERE IMAGE N'EST PAS DIFFEREE. `loading="lazy"`
					 * sur une image visible au chargement retarde son
					 * affichage au lieu de l'accelerer : le navigateur attend
					 * la mise en page avant de la demander.
					 */
					?>
					<img class="opus__diapo-image"
					     src="<?php echo htmlspecialchars($diapo->fond->visuel['src'], ENT_QUOTES, 'UTF-8'); ?>"
					     alt="<?php echo htmlspecialchars($diapo->fond->visuel['alt'], ENT_QUOTES, 'UTF-8'); ?>"
					     <?php if ($diapo->fond->visuel['width']) : ?>width="<?php echo (int) $diapo->fond->visuel['width']; ?>"<?php endif; ?>
					     <?php if ($diapo->fond->visuel['height']) : ?>height="<?php echo (int) $diapo->fond->visuel['height']; ?>"<?php endif; ?>
					     <?php echo $rang === 0 ? 'fetchpriority="high"' : 'loading="lazy"'; ?> decoding="async">

					<?php if ($diapo->dessus !== []) : ?>
						<?php
						/*
						 * LE VOILE EST SOUS LE TEXTE, PAS SUR L'IMAGE.
						 *
						 * Pose sur l'image, il s'appliquerait aussi la ou il
						 * n'y a rien a lire, et assombrirait la photo pour
						 * rien. Pose sur le bloc de contenu, il ne couvre que
						 * ce qu'il faut couvrir pour que le texte reste
						 * lisible.
						 */
						?>
						<div class="opus__diapo-contenu opus__diapo-contenu--voile-<?php echo $voile; ?><?php echo $diapo->carte->alignement === 'start' ? '' : ' opus__carte--' . $diapo->carte->alignement; ?>">
							<?php
							$liste       = $diapo->dessus;
							$classeImage = 'opus__image';
							$lienCarte   = $diapo->carte->lien ?? [];

							require \Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_opus', '_elements');
							?>
						</div>
					<?php endif; ?>

				</div>
			</div>
		<?php endforeach; ?>
	</div>

	<?php if ($total > 1 && $commandes !== 'aucune') : ?>
		<?php
		/*
		 * EN COIN, CE SONT LES BOUTONS DE CORPUS, PAS DES FLECHES.
		 *
		 * « Je pensais plus a des boutons comme la visionneuse de galerie, et
		 * qu'on les positionne en bas a droite des slides », Cyrille,
		 * 23 septembre 2026. La visionneuse du template emploie ses propres
		 * boutons, avec leur intitule ecrit dessus ; le carrousel fait donc
		 * pareil, et les deux se ressemblent parce qu'ils sont la meme chose.
		 *
		 * `bouton` ET `bouton--second` SONT DU TEMPLATE (`template.css`
		 * l. 2156 et 2193). Le module n'invente aucune forme de bouton : il
		 * pose la classe et herite de la teinte, du rayon, de la graisse et du
		 * survol, y compris en theme sombre.
		 *
		 * L'INTITULE EST AU MODULE, ET IL A FALLU EN PASSER PAR LA. `JPREV` et
		 * `JNEXT` du coeur semblaient tout indiques, mais ils ne sont pas
		 * charges cote site : le bouton sortait « Prev », en anglais, sur un
		 * site en francais. Mesure faite sur le banc le 23 septembre 2026.
		 */
		/*
		 * LES DEUX POSITIONS HORS DES COTES PORTENT LE MEME BOUTON.
		 *
		 * « Ca me semble bien moins bien integre que la visionneuse d'images »,
		 * Cyrille, 23 septembre 2026. La visionneuse pose ses boutons DANS UN
		 * PIED, hors de l'image, sur le fond de la boite ; le carrousel les
		 * posait sur la photo. « Sous l'image » est donc la position qui lui
		 * ressemble le plus, et elle doit employer le meme dessin.
		 *
		 * Restent les fleches en pastille pour « sur les cotes », ou un bouton
		 * a intitule mangerait l'image.
		 */
		$enCoin   = $commandes === 'coin';
		$enBouton = $enCoin || $commandes === 'dessous';
		$habits   = $enBouton ? ' bouton bouton--second' : '';
		?>
		<div class="opus__commandes">

			<button class="carousel-control-prev<?php echo $habits; ?>" type="button"
			        data-bs-target="#<?php echo htmlspecialchars($cible, ENT_QUOTES, 'UTF-8'); ?>" data-bs-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<?php if ($enBouton) : ?>
					<span class="opus__commande-mot"><?php echo Text::_('MOD_OPUS_SLIDE_PREV_SHORT'); ?></span>
					<span class="visually-hidden"><?php echo Text::_('MOD_OPUS_SLIDE_PREV'); ?></span>
				<?php else : ?>
					<span class="visually-hidden"><?php echo Text::_('MOD_OPUS_SLIDE_PREV'); ?></span>
				<?php endif; ?>
			</button>

			<button class="carousel-control-next<?php echo $habits; ?>" type="button"
			        data-bs-target="#<?php echo htmlspecialchars($cible, ENT_QUOTES, 'UTF-8'); ?>" data-bs-slide="next">
				<?php if ($enBouton) : ?>
					<span class="opus__commande-mot"><?php echo Text::_('MOD_OPUS_SLIDE_NEXT_SHORT'); ?></span>
					<span class="visually-hidden"><?php echo Text::_('MOD_OPUS_SLIDE_NEXT'); ?></span>
				<?php endif; ?>
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<?php if (!$enBouton) : ?>
					<span class="visually-hidden"><?php echo Text::_('MOD_OPUS_SLIDE_NEXT'); ?></span>
				<?php endif; ?>
			</button>

		</div>
	<?php endif; ?>

	<?php if ($total > 1 && $pastilles) : ?>
		<div class="carousel-indicators">
			<?php foreach ($diapos as $rang => $diapo) : ?>
				<?php
				/*
				 * CHAQUE PASTILLE PORTE UN NOM, PAS UN NUMERO. « Diapositive 3 »
				 * ne dit rien ; le titre de la diapositive, si. Faute de titre,
				 * on retombe sur le rang, qui vaut mieux que rien.
				 */
				$nom = '';

				foreach ($diapo->dessus as $el) {
					if (\in_array(($el->type ?? ''), ['heading', 'subheading'], true)) {
						$nom = trim(strip_tags((string) ($el->label ?? '')));
						break;
					}
				}

				$nom = $nom !== '' ? $nom : Text::sprintf('MOD_OPUS_SLIDE_N', $rang + 1);
				?>
				<button type="button"
				        data-bs-target="#<?php echo htmlspecialchars($cible, ENT_QUOTES, 'UTF-8'); ?>"
				        data-bs-slide-to="<?php echo $rang; ?>"
				        <?php echo $rang === 0 ? 'class="active" aria-current="true"' : ''; ?>
				        aria-label="<?php echo htmlspecialchars($nom, ENT_QUOTES, 'UTF-8'); ?>"></button>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

</div>
