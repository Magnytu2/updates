<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE BLOC CARTES : une grille qui se compte toute seule.
 *
 * ON DECLARE UNE LARGEUR, JAMAIS UN NOMBRE DE COLONNES. Trois cartes sur un
 * ecran large, deux quand la colonne se resserre, une sur un telephone, sans
 * qu'aucun reglage ne change. Ajouter une carte ne demande donc rien d'autre
 * que d'ajouter la carte.
 *
 * UNE CARTE EST UNE PILE D'ELEMENTS DEPUIS LE 22 SEPTEMBRE 2026. Elle portait
 * trois champs fixes, image, titre et texte, et rien d'autre n'y entrait : pas
 * un deuxieme paragraphe, pas un bouton. Elle emploie desormais les memes
 * formes de base que l'ouverture, par `_elements.php`, et c'est le meme fichier
 * qui les dessine des deux cotes.
 *
 * LA STRUCTURE RESTE CELLE DE CORPUS, A LA LETTRE :
 *
 *     .carte > img.carte__image + .carte__corps > h_.carte__titre + p
 *
 * `.carte__corps` EST LE CONTENEUR INTERIEUR, PAS LE TEXTE. Mesure faite dans
 * `media/css/template.css` du template, l. 2260 : `.carte` porte `padding: 0`,
 * et c'est `.carte__corps` qui porte `padding: var(--e-4)`, la colonne
 * flexible et l'ecart entre ses enfants.
 *
 * L'IMAGE SORT DU CORPS QUAND ELLE EST EN TETE DE PILE. Corpus colle
 * `.carte__image` au bord haut de la carte, sans marge : posee dans le corps,
 * elle heriterait du retrait et flotterait au milieu d'un cadre blanc. Une
 * image placee plus bas dans la pile, elle, reste dans le corps : c'est alors
 * une illustration, pas la banniere de la carte.
 *
 * LE NOM COMMENCE PAR UN UNDERSCORE : le champ `modulelayout` du coeur liste
 * les mises en page avec `Folder::files($chemin, '^[^_]*\.php$')`, et ce
 * morceau n'a rien a faire dans cette liste.
 *
 * Appele par `_bloc.php`, il partage ses variables et attend `$bloc`.
 */

\defined('_JEXEC') or die;

/*
 * LES DEUX DEFAUTS TIENNENT LIEU DE REGLAGE POUR L'INSTANT.
 *
 * Les champs « Largeur minimale d'une carte » et « Carte entierement
 * cliquable » ont quitte l'ecran le 22 septembre 2026. Ils reviendront derriere
 * la roue d'une ligne Cartes.
 */
$mini      = (int) $params->get('cardMinWidth', 11);
$cliquable = (int) $params->get('cardClickable', 1) === 1;
$cartes    = $bloc->cartes;
?>
<?php
/*
 * LA FORME DES CARTES, branchee le 24 septembre 2026.
 *
 * Les deux variantes vivaient dans la feuille sans que personne les pose. La
 * liste est FERMEE ici : une valeur inventee ecrirait une classe qui n'existe
 * pas, et la grille resterait muette sans qu'on sache pourquoi.
 */
$forme = (string) ($bloc->cartesForme ?? '');

/*
 * « calme » A EXISTE UNE DEMI-HEURE, le 24 septembre 2026 : c'etait une
 * quatrieme forme qui eteignait le survol, et elle melangeait deux questions.
 * Le reglage est devenu un champ a part. Ce repli garde les rares montages
 * enregistres entre les deux versions : le cadre est le defaut, et le survol
 * s'eteint comme il le demandait.
 */
$calme = $forme === 'calme';

if ($calme) {
    $forme = '';
}

$forme = \in_array($forme, ['shadow', 'none'], true) ? ' opus__cartes--' . $forme : '';

if ($calme || (int) ($bloc->cartesSurvol ?? 1) === 0) {
    $forme .= ' opus__cartes--calme';
}
?>
<div class="opus__cartes<?php echo ($bloc->sens ?? 'row') === 'column' ? ' opus__cartes--pile' : ''; ?><?php echo $forme; ?><?php echo $cliquable ? '' : ' opus__cartes--inerte'; ?><?php echo $bloc->classe !== '' ? ' ' . $bloc->classe : ''; ?>"
     style="--opus-carte-mini: <?php echo $mini; ?>rem"<?php echo $bloc->attrId; ?>>

	<?php foreach ($cartes as $carte) : ?>
		<?php
		/*
		 * UNE CARTE SANS RIEN A MONTRER NE SORT PAS. Elle ferait une case vide
		 * de plus dans la grille, et une grille etire ses cellules : la case
		 * vide prendrait la hauteur de ses voisines.
		 */
		if (empty($carte->pile)) {
			continue;
		}

		$lien = $carte->lien ?? [];

		/*
		 * LA BANNIERE EST LE PREMIER ELEMENT, ET SEULEMENT S'IL EST UNE IMAGE.
		 * On la detache de la pile avant de dessiner le corps, pour ne pas la
		 * dessiner deux fois.
		 */
		$pile     = $carte->pile;
		$banniere = null;

		/*
		 * ELLE SE DEMANDE, ELLE NE SE DEDUIT PLUS DE LA POSITION.
		 *
		 * Jusqu au 23 septembre 2026, toute image en tete de pile devenait la
		 * banniere. « L affichage est different et il n y a pas de marge
		 * au-dessus », a releve Cyrille, qui ne pouvait pas le deviner : la meme
		 * image, un cran plus bas, se dessinait autrement. C est le reglage
		 * « Pose » qui le dit maintenant.
		 *
		 * ELLE DOIT QUAND MEME ETRE EN TETE : collee au bord haut de la carte,
		 * elle ne peut pas suivre un titre, qui passerait dessous. Demandee plus
		 * bas dans la pile, elle reste une image ordinaire.
		 */
		if (($pile[0]->type ?? '') === 'image'
			&& ($pile[0]->imgPose ?? 'corps') === 'banniere'
			&& !empty($pile[0]->visuel)) {
			$banniere = array_shift($pile);
		}
		?>
		<?php
		/*
		 * LE TON D'UNE CARTE : une classe, et Corpus fait le reste.
		 *
		 * Demande de Cyrille, 23 septembre 2026, pour une rangee de tarifs ou
		 * l'une des trois est celle qu'on recommande.
		 */
		$ton = (string) ($carte->ton ?? '');
		?>
		<div class="carte<?php echo \in_array($ton, ['primaire', 'secondaire'], true) ? ' opus__carte--' . $ton : ''; ?><?php echo $carte->blocsBrut !== '' ? ' ' . $carte->blocsBrut : ''; ?>"<?php echo $carte->attrId; ?>>

			<?php if ($banniere !== null) : ?>
				<?php
				/*
				 * LA BANNIERE GARDE LES REGLAGES DE SON ELEMENT, SAUF LE FORMAT.
				 *
				 * Corpus impose deja 16/9 a `.carte__image` (`template.css` l. 2253) :
				 * c est ce qui fait qu une rangee de cartes se tient, quelles que
				 * soient les photos. Un format choisi ici entrerait en conflit avec
				 * lui pour rien. Le cadrage, l habillage et le chargement, eux, valent
				 * aussi bien en banniere qu ailleurs.
				 */
				/*
				 * ON RETIRE DES MOTS, PAS DES MORCEAUX DE MOTS.
				 *
				 * Premiere version ecrite avec `str_replace` : elle otait la chaine
				 * `opus__image` partout ou elle apparaissait, donc aussi au
				 * debut de `opus__image--plafond`, et la page sortait une
				 * classe `--plafond` que rien n habille. Releve en front le
				 * 23 septembre 2026.
				 *
				 * LA LISTE DES FORMATS EST CELLE DU HELPER, et c est voulu qu elle
				 * soit ecrite en toutes lettres : un format ajoute la-bas doit etre
				 * ajoute ici, et le silence serait pire qu une erreur.
				 */
				$otes = [
				    'opus__image',
				    'opus__image--16-9',
				    'opus__image--4-3',
				    'opus__image--1-1',
				    'opus__image--3-4',
				];

				$habits = implode(' ', array_filter(
				    preg_split('/\s+/', trim((string) ($banniere->imageClasses ?? ''))),
				    function ($mot) use ($otes) {
				        return $mot !== '' && !\in_array($mot, $otes, true);
				    }
				));
				?>
				<img class="carte__image<?php echo $habits !== '' ? ' ' . $habits : ''; ?><?php echo $banniere->classe !== '' ? ' ' . $banniere->classe : ''; ?>"
				     src="<?php echo htmlspecialchars($banniere->visuel['src'], ENT_QUOTES, 'UTF-8'); ?>"
				     alt="<?php echo htmlspecialchars($banniere->visuel['alt'], ENT_QUOTES, 'UTF-8'); ?>"
				     <?php if ($banniere->visuel['width']) : ?>width="<?php echo (int) $banniere->visuel['width']; ?>"<?php endif; ?>
				     <?php if ($banniere->visuel['height']) : ?>height="<?php echo (int) $banniere->visuel['height']; ?>"<?php endif; ?>
				     <?php if (!empty($banniere->imageCharge)) : ?>
				     loading="eager" fetchpriority="high"
				     <?php else : ?>
				     loading="lazy"
				     <?php endif; ?>
				     decoding="async"<?php echo $banniere->imageStyle ?? ''; ?><?php echo $banniere->attrId; ?>>
			<?php endif; ?>

			<div class="carte__corps<?php echo $carte->alignement === 'start' ? '' : ' opus__carte--' . $carte->alignement; ?>">

				<?php
				/*
				 * LE LIEN DE LA CARTE S'ACCROCHE A SON PREMIER TITRE.
				 *
				 * `template.css` l. 2291 donne a `.carte__titre a` un `::after`
				 * en `position: absolute; inset: 0`, et `.carte` porte
				 * `position: relative` : le lien du titre couvre donc la carte
				 * tout seul, avec le survol et le `:focus-within` qui vont
				 * avec. Pas de `stretched-link` de Bootstrap, il ferait double
				 * emploi.
				 *
				 * LE VRAI LIEN RESTE SUR LE TITRE : clic partout a la souris,
				 * une seule tabulation, et le lecteur d'ecran annonce le titre
				 * plutot que toute la carte.
				 */
				$liste       = $pile;
				$classeImage = 'opus__image';
				$lienCarte   = $lien;

				require \Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_opus', '_elements');
				?>

			</div>

		</div>
	<?php endforeach; ?>

</div>
