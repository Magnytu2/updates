<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LA MISE EN PAGE, ET IL N'Y EN A PLUS QU'UNE.
 *
 * Elle parcourt les rangees, et dans chaque rangee les colonnes, et dans
 * chaque colonne les blocs. C'est le modele de l'onglet « Template article »
 * de Corpus, et c'est aussi SON BALISAGE.
 *
 * `grille` ET `colonne-N` SONT LES CLASSES DU TEMPLATE, PAS LES NOTRES.
 * `media/css/template.css` l. 469 pose `.grille` en grille de douze colonnes,
 * `.colonne-1` a `.colonne-12` en `grid-column: span N`, et l. 8529 les fait
 * toutes retomber sur douze sous 62 rem. Le module ecrit donc exactement ce
 * qu'ecrit un gabarit d'article, et il herite pour rien des douze rapports, de
 * la gouttiere et du repli. Ce sont une trentaine de regles que nous n'avons
 * plus a ecrire ni a suivre.
 *
 * CE FICHIER NE DECIDE RIEN. L'assistant a deja ecarte les blocs orphelins,
 * les rangees vides et les elements masques, normalise le rapport en douziemes
 * et prepare les titres, les liens et les images. Un integrateur qui copie ce
 * fichier dans html/mod_opus/ de son template n'a aucune regle a
 * redecouvrir.
 *
 * LA LARGEUR NE SE REGLE PAS ICI, elle vient de la section de page qui
 * accueille le module, dans Layout Configuration de Corpus.
 */

\defined('_JEXEC') or die;

/*
 * UN MODULE QUI N'A RIEN A DIRE NE SORT RIEN.
 *
 * Sans ce garde, le module rendait son conteneur vide : un bloc invisible mais
 * bien present, qui prend sa marge dans la page et que l'on cherche dans
 * l'inspecteur. Vu sur le banc le 19 septembre 2026.
 */

if ($rangees === []) {
    return;
}
?>
<?php if ($planche !== '') : ?>
	<?php
	/*
	 * LA PLANCHE DE PICTOGRAMMES, SUR UN SITE QUI N'A PAS CORPUS.
	 *
	 * Elle est VIDE sous Corpus : le template a deja pose la sienne, et le
	 * repartiteur ne remplit cette variable que lorsqu'il ne l'a pas trouvee.
	 * Elle est vide aussi pour le deuxieme module d'une meme page, parce que
	 * des identifiants de symboles en double casseraient les `<use>`.
	 *
	 * ELLE SORT TELLE QUELLE, SANS ECHAPPEMENT, et c'est voulu : c'est du
	 * balisage, pas du texte. Le fichier est livre avec le module, il ne vient
	 * ni de la base ni d'une saisie.
	 *
	 * ELLE NE SE VOIT PAS : `width="0"`, `position:absolute`, `aria-hidden`.
	 * Elle ne fait que tenir les traces que les boutons appellent.
	 */
	echo $planche;
	?>
<?php endif; ?>
<div class="<?php echo $racine; ?>">

	<?php foreach ($rangees as $rang => $rangee) : ?>
		<?php
		$classesRangee = ['grille', 'opus__rangee'];

		/*
		 * « AU MILIEU » EST LE DEFAUT DEPUIS LE 23 SEPTEMBRE 2026, et c'est la
		 * feuille qui le porte : la classe ne s'ecrit donc que pour les deux
		 * autres valeurs. Une rangee enregistree avant ce jour porte « en
		 * haut » en clair, et garde son alignement.
		 */
		if ($rangee->hauteur !== 'center' && $rangee->hauteur !== '') {
			$classesRangee[] = 'opus__rangee--v-' . $rangee->hauteur;
		}

		// Le fond part sur la rangee entiere quand aucune colonne n'est visee.
		if ($rangee->fond !== '' && $rangee->fondSur === '') {
			$classesRangee[] = 'opus__fond';
			$classesRangee[] = $rangee->fond;
		}

		if ($rangee->classe !== '') {
			$classesRangee[] = $rangee->classe;
		}
		?>
		<div class="<?php echo implode(' ', $classesRangee); ?>"<?php echo $rangee->attrId; ?>>

			<?php foreach ($rangee->codes as $index => $code) : ?>
				<?php
				$dedans = $rangee->cases[$code];

				/*
				 * UNE COLONNE VIDE N'EST PAS ECRITE.
				 *
				 * La grille compte alors une part de moins, et la colonne
				 * voisine occupe le reste : sans cela, le contenu restait
				 * enferme dans ses cinq douziemes et la moitie droite de la
				 * page etait blanche. Vu sur le banc le 21 septembre 2026.
				 */
				/*
				 * UNE COLONNE VIDE QUI PRECEDE DU CONTENU SORT QUAND MEME,
				 * VIDE, et c'est ce qui rend le rapport exact.
				 *
				 * `.grille` place ses enfants les uns apres les autres : sans
				 * cette cale, un bloc pose a DROITE d'une rangee 5/7 se
				 * retrouverait collé au bord gauche, avec la bonne largeur et
				 * la mauvaise place. L'assistant a deja retire les colonnes
				 * vides de fin : celles qui restent en precedent forcement une
				 * qui a du contenu.
				 *
				 * Elle ne porte aucun texte et aucun role : un lecteur d'ecran
				 * n'a rien a y annoncer.
				 */
				if ($dedans === []) {
					?>
					<div class="colonne-<?php echo (int) $rangee->parts[$index]; ?>" aria-hidden="true"></div>
					<?php
					continue;
				}

				$classesColonne = ['colonne-' . (int) $rangee->parts[$index], 'opus__colonne'];

				if ($rangee->fond !== '' && $rangee->fondSur === $code) {
					$classesColonne[] = 'opus__fond';
					$classesColonne[] = $rangee->fond;
				}
				?>
				<div class="<?php echo implode(' ', $classesColonne); ?>">
					<?php foreach ($dedans as $numero => $bloc) : ?>
						<?php
						/*
						 * L'IDENTIFIANT D'UN BLOC EST UNIQUE DANS LA PAGE, et
						 * le carrousel en a besoin : ses fleches et ses
						 * pastilles designent leur carrousel par cet
						 * identifiant. Deux carrousels dans le meme module,
						 * c'est maintenant possible, donc le numero du module
						 * ne suffit plus.
						 */
						$clefBloc = $identifiant . '-' . ($rang + 1) . '-' . $code . '-' . ($numero + 1);
						require \Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_opus', '_bloc');
						?>
					<?php endforeach; ?>
				</div>
			<?php endforeach; ?>

		</div>
	<?php endforeach; ?>

</div>
