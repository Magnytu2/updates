<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE BLOC ONGLETS : DES PANNEAUX DONT UN SEUL SE VOIT.
 *
 * MEME MECANIQUE QUE LES CARTES, A LA LETTRE. « Voila un exemple avec la mise
 * en page Cartes. Je veux la meme chose, mais pour des onglets », Cyrille,
 * 24 septembre 2026. Un onglet porte son titre, qui fait le bouton, et une
 * pile d'elements qu'on ordonne librement, comme une carte.
 *
 * J'EN AVAIS FAIT UN ELEMENT, avec quatre champs fixes, titre, sous-titre,
 * texte, image. C'etait la meme faute que celle corrigee sur les cartes le
 * 22 septembre : un onglet sans image gardait sa colonne vide, un onglet a
 * deux paragraphes n'avait nulle part ou les mettre, et un bouton y etait
 * impossible.
 *
 * LE COMPORTEMENT EST CELUI DU COEUR, PAS LE NOTRE. `joomla-tab` est livre
 * avec Joomla depuis la 4 : il fabrique les boutons, pose `role="tablist"` et
 * `aria-selected`, branche les fleches du clavier et replie la rangee en
 * accordeon sous `breakpoint`. Le module ecrit deux balises, et pas une ligne
 * de JavaScript. Sa FEUILLE, elle, n'est pas chargee : elle ecrit des gris en
 * dur qui ne suivraient ni la charte du site ni le mode sombre.
 *
 * LE NOM COMMENCE PAR UN UNDERSCORE : le champ `modulelayout` du coeur liste
 * les mises en page avec `Folder::files($chemin, '^[^_]*\.php$')`, et ce
 * morceau n'a rien a faire dans cette liste.
 */

\defined('_JEXEC') or die;

/*
 * LE SENS ET LE REPLI, LUS UNE FOIS, ET CONTRE DES LISTES FERMEES.
 *
 * Une valeur venue d'ailleurs qu'du manifeste ecrirait un attribut que
 * `joomla-tab` ne connait pas, et la rangee resterait muette sans qu'on sache
 * pourquoi.
 */
$sens  = ($bloc->ongletsSens ?? 'horizontal') === 'vertical' ? 'vertical' : 'horizontal';
$repli = (int) ($bloc->ongletsRepli ?? 768);

$habits = ['opus__onglets'];

if ($bloc->classe !== '') {
    $habits[] = $bloc->classe;
}

/*
 * UN SEUL ONGLET ACTIF. Si l'administrateur en coche trois, `joomla-tab`
 * garderait trois panneaux ouverts au premier affichage. On ne laisse donc
 * passer que le premier ; si aucun n'est coche, le coeur ouvre le premier tout
 * seul.
 */
$dejaActif = false;
$rangOng   = 0;
?>
<joomla-tab
	class="<?php echo implode(' ', $habits); ?>"
	orientation="<?php echo $sens; ?>"
	<?php if ($repli > 0) : ?>breakpoint="<?php echo $repli; ?>"<?php endif; ?>
	<?php echo $bloc->attrId; ?>>

	<?php foreach ($bloc->onglets as $onglet) : ?>
		<?php
		$rangOng++;

		$actif = $onglet->actif && !$dejaActif;

		if ($actif) {
			$dejaActif = true;
		}

		/*
		 * LE PARTAGE DU PANNEAU SE FAIT SUR LES IMAGES.
		 *
		 * « Avec la possibilite de diviser le contenu d'un onglet et organiser
		 * l'interieur. Exemple pouvoir deplacer les images a gauche et le
		 * sous-titre, texte, a droite », Cyrille, 24 septembre 2026.
		 *
		 * SANS UN CHAMP DE PLUS SUR CHAQUE ELEMENT : poser une « zone » sur
		 * chaque ligne de la pile aurait alourdi les TROIS copies du
		 * sous-formulaire, y compris celle de l'Ouverture, ou elle n'a aucun
		 * sens. Ici les elements de type Image vont d'un cote, tout le reste de
		 * l'autre, et le reglage de l'onglet dit lequel.
		 *
		 * L'ORDRE DU DOCUMENT NE CHANGE JAMAIS : le texte reste ecrit avant
		 * l'image, quel que soit le cote choisi. Seule la feuille les replace.
		 * Un lecteur d'ecran entend donc toujours le titre de l'onglet, puis ce
		 * qu'il raconte, puis l'illustration.
		 */
		$partage = $onglet->dispo !== 'empile';
		$corps   = $onglet->pile;
		$visuels = [];

		if ($partage) {
			$corps   = [];
			$visuels = [];

			foreach ($onglet->pile as $piece) {
				if (($piece->type ?? '') === 'image') {
					$visuels[] = $piece;

					continue;
				}

				$corps[] = $piece;
			}

			/*
			 * PAS D'IMAGE, PAS DE PARTAGE. Une demi-colonne blanche a cote d'un
			 * texte n'est pas une mise en page, c'est un oubli qui se voit.
			 */
			if ($visuels === []) {
				$partage = false;
				$corps   = $onglet->pile;
			}
		}
		?>
		<joomla-tab-element
			id="<?php echo htmlspecialchars($clefBloc . '-ong-' . $rangOng, ENT_QUOTES, 'UTF-8'); ?>"
			name="<?php echo htmlspecialchars($onglet->titre, ENT_QUOTES, 'UTF-8'); ?>"
			<?php echo $actif ? 'active' : ''; ?>>

			<div class="opus__onglet<?php echo $partage ? ' opus__onglet--' . $onglet->dispo : ''; ?>">

				<div class="opus__onglet-corps">
					<?php
					$liste       = $corps;
					$classeImage = 'opus__image';

					require \Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_opus', '_elements');
					?>
				</div>

				<?php if ($partage) : ?>
					<div class="opus__onglet-media">
						<?php
						$liste       = $visuels;
						$classeImage = 'opus__image';

						require \Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_opus', '_elements');
						?>
					</div>
				<?php endif; ?>

			</div>

		</joomla-tab-element>
	<?php endforeach; ?>

</joomla-tab>
