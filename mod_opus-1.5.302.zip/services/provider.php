<?php

/**
 * @package     Opus
 * @subpackage  mod_opus
 *
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE FOURNISSEUR DE SERVICES DU MODULE.
 *
 * Copie de celui de mod_articles_category du coeur, puis un seul changement :
 * le namespace. Une copie reecrite « en mieux » diverge a la premiere version
 * de Joomla et personne ne sait plus pourquoi.
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Extension\Service\Provider\HelperFactory;
use Joomla\CMS\Extension\Service\Provider\Module;
use Joomla\CMS\Extension\Service\Provider\ModuleDispatcherFactory;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class () implements ServiceProviderInterface {
    /**
     * Registers the service provider with a DI container.
     *
     * @param   Container  $container  The DI container.
     *
     * @return  void
     */
    public function register(Container $container)
    {
        $container->registerServiceProvider(new ModuleDispatcherFactory('\\Joomanji\\Module\\Opus'));
        $container->registerServiceProvider(new HelperFactory('\\Joomanji\\Module\\Opus\\Site\\Helper'));

        $container->registerServiceProvider(new Module());
    }
};
