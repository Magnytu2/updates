<?php

/**
 * @package     Markus Editor
 * @subpackage  plg_editors_markus
 * @copyright   (C) 2026 joomanji.eu
 * @license     GNU General Public License version 2 or later
 */

namespace Joomanji\Plugin\Editors\Markus\Field;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormField;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

/**
 * LA PAGE D'ACCUEIL DE MARKUS EDITOR (1.0.200, 30 octobre 2026).
 *
 * Decision de Cyrille du 11 octobre 2026 (markus/CLAUDE.md, § 4) : l'accueil
 * d'un plugin se pose comme celui d'un module, seul dans l'onglet « Plugin » ;
 * les reglages vont dans l'onglet « Parametrages ». Meme dessin que les autres
 * produits (CLAUDE.md commun, § 6 ; composant « accueil » de la charte).
 *
 * Au-dessus, l'encadre « Mises a jour Joomanji » (composant « majs », ligne U7
 * d'A-FAIRE) : seulement pour qui peut gerer les extensions ; lecture et mise
 * a jour passent par com_installer.
 *
 * PAS DE CADRE JED : Markus Editor n'y est pas encore (markus/CLAUDE.md, § 9).
 * Une adresse inventee serait pire qu'un cadre absent.
 *
 * Adresses relevees sur joomanji.eu le 30 octobre 2026. Le site n'a que le
 * francais et l'anglais : toute autre langue va vers l'anglais.
 *
 * Rien a enregistrer : ce champ n'ecrit aucune valeur. Les feuilles et le
 * script de l'accueil ne sont charges que sur cet ecran, jamais avec
 * l'editeur.
 */
class MarkuspresentationField extends FormField
{
    protected $type = 'Markuspresentation';

    protected function getLabel()
    {
        return '';
    }

    protected function getInput()
    {
        $app = Factory::getApplication();

        if (!$app->isClient('administrator')) {
            return '';
        }

        $doc = $app->getDocument();
        $wa  = $doc->getWebAssetManager();
        $wa->registerAndUseStyle('plg_editors_markus.accueil', 'plg_editors_markus/charte-accueil.css', ['version' => 'auto']);

        // La presentation prend toute la largeur de l'onglet : sans ces trois
        // regles, Joomla la poserait dans la zone de saisie d'un champ, a cote
        // d'un libelle vide (meme reglage qu'Astus, reglages.css).
        $wa->addInlineStyle(
            '#general .control-group:has(.blocs-presentation){margin:0 0 1.75rem}'
            . '#general .control-group:has(.blocs-presentation)>:is(.control-label,.visually-hidden){display:none}'
            . '#general .control-group:has(.blocs-presentation)>.controls{width:auto;max-width:none;margin:0}'
        );

        // Dans la fenetre des reglages ouverte depuis l'editeur (`tmpl=component`),
        // pas d'encadre : « Tout mettre a jour » quitterait l'article en cours.
        $fenetre = $app->getInput()->getCmd('tmpl') === 'component';

        if (!$fenetre && $app->getIdentity()->authorise('core.manage', 'com_installer')) {
            $doc->addScriptOptions('jmj-majs', ['jeton' => Session::getFormToken()]);

            foreach (['JMJ_MAJS_RECHERCHE', 'JMJ_MAJS_TITRE_1', 'JMJ_MAJS_TITRE', 'JMJ_MAJS_VERSIONS', 'JMJ_MAJS_BOUTON', 'JMJ_MAJS_EN_COURS', 'JMJ_MAJS_DECOUVRIR', 'JMJ_MAJS_NOUVELLE_FENETRE'] as $cle) {
                Text::script($cle);
            }

            $wa->registerAndUseScript('plg_editors_markus.accueil', 'plg_editors_markus/charte-accueil.js', ['version' => 'auto'], ['defer' => true], ['core']);
        }

        $esc     = static fn ($s): string => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
        $version = $this->version();
        $fr      = str_starts_with($app->getLanguage()->getTag(), 'fr');
        $img     = Uri::root() . 'media/plg_editors_markus/images/markus-presentation-' . ($fr ? 'fr' : 'en') . '.svg';
        $site    = $fr
            ? ['doc' => 'https://joomanji.eu/fr/composants-gratuits/markus/manuel-dutilisation-markus', 'aide' => 'https://joomanji.eu/fr/assistance', 'dl' => 'https://joomanji.eu/fr/telechargements/markus', 'corpus' => 'https://joomanji.eu/fr/corpus']
            : ['doc' => 'https://joomanji.eu/en/free-components/markus-en/user-manual-markus', 'aide' => 'https://joomanji.eu/en/help', 'dl' => 'https://joomanji.eu/en/download/markus-editor-en', 'corpus' => 'https://joomanji.eu/en/corpus-en'];
        $neuf    = '<span class="visually-hidden"> ' . $esc(Text::_('PLG_EDITORS_MARKUS_PRES_NEW_WINDOW')) . '</span>';
        $lien    = static function (string $url, string $cle, string $classe = '') use ($esc, $neuf): string {
            return '<a' . ($classe !== '' ? ' class="' . $classe . '"' : '') . ' href="' . $esc($url) . '" target="_blank" rel="noopener">'
                . $esc(Text::_($cle)) . $neuf . '</a>';
        };

        return '<div class="blocs-presentation">'
            . '<div class="blocs-presentation__cote">'
            .   '<img class="blocs-presentation__vignette" src="' . $esc($img) . '" alt="" width="1210" height="682" loading="lazy">'
            .   '<div class="blocs-presentation__appel blocs-presentation__appel--corpus">'
            .     '<p>' . $esc(Text::_('PLG_EDITORS_MARKUS_PRES_CORPUS_TEXT')) . '</p>'
            .     $lien($site['corpus'], 'PLG_EDITORS_MARKUS_PRES_CORPUS_LINK', 'btn btn-primary btn-sm')
            .   '</div>'
            .   '<div class="blocs-presentation__liens-bloc">'
            .     '<h2 class="blocs-presentation__soustitre">' . $esc(Text::_('PLG_EDITORS_MARKUS_PRES_HELP_TITLE')) . '</h2>'
            .     '<ul class="blocs-presentation__liens">'
            .       '<li>' . $lien($site['doc'], 'PLG_EDITORS_MARKUS_PRES_LINK_DOC') . '</li>'
            .       '<li>' . $lien($site['aide'], 'PLG_EDITORS_MARKUS_PRES_LINK_HELP') . '</li>'
            .       '<li>' . $lien($site['dl'], 'PLG_EDITORS_MARKUS_PRES_LINK_DOWNLOAD') . '</li>'
            .     '</ul>'
            .   '</div>'
            .   '<p class="blocs-presentation__licence">' . Text::_('PLG_EDITORS_MARKUS_PRES_LICENCE') . '</p>'
            . '</div>'
            . '<div class="blocs-presentation__corps">'
            .   '<p class="blocs-presentation__marque">Markus Editor'
            .     ($version !== '' ? '<span class="blocs-entete__version">' . $esc($version) . '</span>' : '')
            .   '</p>'
            .   '<h2 class="blocs-presentation__titre">' . $esc(Text::_('PLG_EDITORS_MARKUS_PRES_TITRE')) . '</h2>'
            .   '<div class="blocs-presentation__texte"><p>' . $esc(Text::_('PLG_EDITORS_MARKUS_PRES_TEXTE')) . '</p></div>'
            .   '<ul class="blocs-presentation__points">' . Text::_('PLG_EDITORS_MARKUS_PRES_POINTS') . '</ul>'
            .   '<p class="blocs-presentation__nom">' . Text::_('PLG_EDITORS_MARKUS_PRES_NOM') . '</p>'
            . '</div>'
            . '</div>';
    }

    /**
     * Le numero lu dans le manifeste installe : il ne peut pas diverger de la
     * version reellement en place.
     */
    private function version(): string
    {
        $manifeste = JPATH_PLUGINS . '/editors/markus/markus.xml';

        if (!is_file($manifeste)) {
            return '';
        }

        $xml = @simplexml_load_file($manifeste);

        return $xml === false ? '' : trim((string) $xml->version);
    }
}
