/*
 * LA CHARTE JOOMANJI DANS MARKUS EDITOR, PAGE D'ACCUEIL.
 *
 * FICHIER ECRIT EN ENTIER PAR `_charte/charte.py` : n'y rien ecrire a la
 * main. Une amelioration se fait dans `_charte/composants`, puis
 * `python3 _charte/charte.py recopier markus-accueil`. La livraison refuse un fichier
 * qui diverge (`charte.py verifier markus-accueil`).
 *
 * Composants : jetons v8, accueil v1, majs v1.
 */

// >>> CHARTE JOOMANJI : majs v1 (ne pas modifier ici : _charte/composants) >>>
/*
 * LES MISES A JOUR JOOMANJI. Charte Joomanji, composant « majs », v1,
 * 17 octobre 2026.
 *
 * Decision de Cyrille, 17 octobre 2026 : la page de presentation de chaque
 * produit dit « N mises a jour Joomanji disponibles », les liste (nom, version
 * installee, version proposee) et offre « Tout mettre a jour ». Rien du tout
 * s'il n'y en a aucune.
 *
 * AUCUN CODE A NOUS COTE SERVEUR. Tout passe par com_installer, le coeur de
 * Joomla, comme la vignette « Mises a jour des extensions » du tableau de
 * bord (plg_quickicon_extensionupdate) :
 *
 * - LIRE : `index.php?option=com_installer&view=update&task=update.ajax`,
 *   jeton en GET. Cherche les mises a jour (cache d'une heure), puis rend en
 *   JSON les lignes de la vue « Mettre a jour » : `update_id`, `name`,
 *   `version` (proposee), `current_version` (installee), `detailsurl`
 *   (l'adresse du site de mise a jour). Verifie dans Joomla 6.1.2,
 *   UpdateController::ajax() et UpdateModel::translate().
 * - FILTRER : une mise a jour Joomanji est une ligne dont `detailsurl` (ou
 *   `infourl`) commence par `https://magnytu2.github.io/updates/`.
 * - METTRE A JOUR : le formulaire du coeur, poste a
 *   `index.php?option=com_installer&view=update`, `task=update.update`,
 *   `cid[]` des seules lignes Joomanji, jeton CSRF. Joomla installe, puis
 *   affiche son propre ecran « Mettre a jour » avec ses messages.
 *
 * C'est Joomla qui calcule ce qu'il propose : le verrou des versions
 * (`targetplatform`) et la stabilite minimale restent les siens.
 *
 * CE QUE LE PRODUIT FAIT, sur sa page de presentation SEULEMENT, et
 * seulement si l'utilisateur a `core.manage` sur com_installer :
 *
 *   $doc->addScriptOptions('jmj-majs', ['jeton' => Session::getFormToken()]);
 *   Text::script() des clefs JMJ_MAJS_* ci-dessous ;
 *   charger charte.js.
 *
 * Sans l'option `jmj-majs`, ou sans `.blocs-presentation` dans la page, ce
 * composant ne fait rien. Option facultative `decouvrir` : une liste
 * `[{nom, url}]` de produits Joomanji non installes, en une ligne
 * « Decouvrir aussi : » dans l'encadre (le produit fournit les adresses,
 * relevees sur joomanji.eu ; la charte n'en invente aucune).
 *
 * Textes (fichiers de langue de chaque produit, par `Text::script`) :
 * JMJ_MAJS_RECHERCHE, JMJ_MAJS_TITRE_1, JMJ_MAJS_TITRE (%d),
 * JMJ_MAJS_VERSIONS (%1$s installee, %2$s proposee), JMJ_MAJS_BOUTON,
 * JMJ_MAJS_EN_COURS, JMJ_MAJS_DECOUVRIR, JMJ_MAJS_NOUVELLE_FENETRE.
 *
 * ACCESSIBILITE : un vrai `button` ; une zone d'etat (`role="status"`) qui
 * existe des le debut et n'est jamais deplacee : lue, pas vue, pendant
 * « Recherche des mises a jour Joomanji... », puis visible a cote du bouton
 * pour « Mise a jour en cours... ». Le bouton presse garde le focus
 * (`aria-disabled`, pas `disabled`) et ne repart pas une seconde fois.
 *
 * Pour la demonstration sans Joomla (`charte.html`), `demarrer()` accepte
 * `lire` (une fonction qui rend une promesse de lignes) et `envoyer` (une
 * fonction qui recoit les `update_id`).
 */
(function () {
  'use strict';

  var VERSION = 1;

  if (window.JoomanjiMajs && (window.JoomanjiMajs.version || 0) >= VERSION) {
    return;
  }

  var PREFIXE = 'https://magnytu2.github.io/updates/';

  function mot(cle, defaut) {
    if (window.Joomla && Joomla.Text && Joomla.Text._) {
      var t = Joomla.Text._(cle);
      if (t && t !== cle) { return t; }
    }

    return defaut;
  }

  function joomanji(ligne) {
    return [ligne.detailsurl, ligne.infourl].some(function (u) {
      return typeof u === 'string' && u.indexOf(PREFIXE) === 0;
    });
  }

  function lireJoomla(jeton) {
    var url = 'index.php?option=com_installer&view=update&task=update.ajax&'
      + encodeURIComponent(jeton) + '=1&cache_timeout=3600&eid=0';
    var demande;

    // Comme la vignette du tableau de bord : en file, jamais en meme temps
    // qu'elle (joomla-cms #38001).
    if (window.Joomla && Joomla.enqueueRequest) {
      demande = Joomla.enqueueRequest({ url: url, method: 'GET', promise: true })
        .then(function (xhr) { return xhr.responseText; });
    } else {
      demande = fetch(url, { credentials: 'same-origin' }).then(function (r) { return r.text(); });
    }

    return demande.then(function (texte) {
      var lignes = JSON.parse(texte);

      if (!Array.isArray(lignes)) { throw new Error('reponse'); }

      return lignes;
    });
  }

  function envoyerJoomla(jeton, ids) {
    var f = document.createElement('form');
    f.method = 'post';
    f.action = 'index.php?option=com_installer&view=update';
    f.hidden = true;

    function champ(nom, valeur) {
      var c = document.createElement('input');
      c.type = 'hidden';
      c.name = nom;
      c.value = valeur;
      f.appendChild(c);
    }

    champ('task', 'update.update');
    champ('boxchecked', String(ids.length));
    champ(jeton, '1');
    ids.forEach(function (id) { champ('cid[]', String(id)); });
    document.body.appendChild(f);
    f.submit();
  }

  function element(nom, classe, texte) {
    var e = document.createElement(nom);
    if (classe) { e.className = classe; }
    if (texte != null) { e.textContent = texte; }
    return e;
  }

  function dessiner(boite, etat, lignes, o) {
    var n = lignes.length;
    var titre = element('h2', 'jmj-majs__titre', n === 1
      ? mot('JMJ_MAJS_TITRE_1', '1 mise à jour Joomanji disponible')
      : mot('JMJ_MAJS_TITRE', '%d mises à jour Joomanji disponibles').replace('%d', String(n)));
    titre.id = 'jmj-majs-titre';
    boite.setAttribute('role', 'region');
    boite.setAttribute('aria-labelledby', titre.id);

    var liste = element('ul', 'jmj-majs__liste');
    var modele = mot('JMJ_MAJS_VERSIONS', 'installée : %1$s, proposée : %2$s');

    lignes.forEach(function (l) {
      var li = element('li');
      li.appendChild(element('span', 'jmj-majs__nom', l.name || ''));
      li.appendChild(document.createTextNode(' '));
      li.appendChild(element('span', 'jmj-majs__versions', '(' + modele
        .replace('%1$s', l.current_version || '?')
        .replace('%2$s', l.version || '?') + ')'));
      liste.appendChild(li);
    });

    var actions = element('div', 'jmj-majs__actions');
    var bouton = element('button', 'btn btn-primary btn-sm jmj-majs__bouton', mot('JMJ_MAJS_BOUTON', 'Tout mettre à jour'));
    bouton.type = 'button';
    actions.appendChild(bouton);

    // L'ordre dans la boite : titre, liste, actions (le bouton puis l'etat),
    // decouvrir. La zone d'etat ne bouge pas : on pose le reste autour d'elle.
    boite.insertBefore(titre, etat);
    boite.insertBefore(liste, etat);
    boite.insertBefore(actions, etat);
    actions.appendChild(etat);

    if (Array.isArray(o.decouvrir) && o.decouvrir.length) {
      var p = element('p', 'jmj-majs__decouvrir', mot('JMJ_MAJS_DECOUVRIR', 'Découvrir aussi :') + ' ');
      var neuf = mot('JMJ_MAJS_NOUVELLE_FENETRE', '(nouvelle fenêtre)');

      o.decouvrir.forEach(function (d, i) {
        if (i) { p.appendChild(document.createTextNode(', ')); }
        var a = element('a', '', d.nom);
        a.href = d.url;
        a.target = '_blank';
        a.rel = 'noopener';
        a.appendChild(element('span', 'jmj-majs__lu', ' ' + neuf));
        p.appendChild(a);
      });

      boite.appendChild(p);
    }

    // Le resultat de la recherche est lu (le titre vient d'apparaitre), sans
    // etre affiche une seconde fois a cote du bouton.
    boite.classList.remove('jmj-majs--cherche');
    etat.textContent = '';
    etat.appendChild(element('span', 'jmj-majs__lu', titre.textContent));

    var parti = false;

    bouton.addEventListener('click', function () {
      if (parti) { return; }

      parti = true;
      bouton.setAttribute('aria-disabled', 'true');
      etat.textContent = mot('JMJ_MAJS_EN_COURS', 'Mise à jour en cours…');

      var ids = lignes.map(function (l) { return l.update_id; });

      // Laisser a la zone d'etat le temps d'etre lue avant de quitter la page.
      setTimeout(function () { o.envoyer(ids); }, 300);
    });
  }

  function demarrer(o) {
    o = o || {};
    var racine = o.racine || document.querySelector('.blocs-presentation');

    if (!racine || !racine.parentNode) { return; }

    // Une seule boite par page, meme si deux produits chargent la charte.
    if (document.querySelector('.jmj-majs')) { return; }

    if (!o.lire && !o.jeton) { return; }

    var lire = o.lire || function () { return lireJoomla(o.jeton); };
    o.envoyer = o.envoyer || function (ids) { envoyerJoomla(o.jeton, ids); };

    var boite = element('div', 'jmj-majs jmj-majs--cherche');
    var etat = element('p', 'jmj-majs__etat');
    etat.setAttribute('role', 'status');
    boite.appendChild(etat);
    racine.parentNode.insertBefore(boite, racine);

    // Posee vide, remplie ensuite : une zone d'etat ne lit que ce qui change.
    setTimeout(function () {
      if (boite.classList.contains('jmj-majs--cherche') && etat.textContent === '') {
        etat.textContent = mot('JMJ_MAJS_RECHERCHE', 'Recherche des mises à jour Joomanji…');
      }
    }, 50);

    function rien() {
      if (boite.parentNode) { boite.parentNode.removeChild(boite); }
    }

    Promise.resolve().then(lire).then(function (lignes) {
      var vues = {};
      var nos = (lignes || []).filter(function (l) {
        if (!l || !l.update_id || vues[l.update_id] || !joomanji(l)) { return false; }
        vues[l.update_id] = true;
        return true;
      }).sort(function (a, b) { return String(a.name).localeCompare(String(b.name)); });

      if (!nos.length) { rien(); return; }

      dessiner(boite, etat, nos, o);
    }).catch(rien);
  }

  function auto() {
    var o = window.Joomla && Joomla.getOptions ? Joomla.getOptions('jmj-majs') : null;

    if (!o || !o.jeton) { return; }

    demarrer({ jeton: o.jeton, decouvrir: o.decouvrir });
  }

  window.JoomanjiMajs = { version: VERSION, demarrer: demarrer, auto: auto };

  function lancer() { window.JoomanjiMajs.auto(); }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', lancer);
  } else {
    lancer();
  }
})();
// <<< CHARTE JOOMANJI : majs <<<
