<?php

/**
 * Oculus — Plugin client de surveillance (groupe ajax).
 * Point d'accès JSON en LECTURE SEULE, sécurisé par token.
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

namespace Joomanji\Plugin\Ajax\Sitemonitor\Extension;

\defined('_JEXEC') or die;

use Joomla\CMS\Access\Access;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Updater\Updater;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Event\Event;
use Joomla\Event\SubscriberInterface;

final class Sitemonitor extends CMSPlugin implements SubscriberInterface
{
    use DatabaseAwareTrait;

    public const VERSION = '0.18.0';

    public static function getSubscribedEvents(): array
    {
        return [
            'onAjaxSitemonitor' => 'onAjaxSitemonitor',
        ];
    }

    /**
     * Version RÉELLEMENT installée, lue dans le manifeste enregistré par Joomla
     * à l'installation (source unique : le <version> du fichier XML). La constante
     * VERSION ci-dessus n'est plus qu'un secours si la lecture échoue — plus aucune
     * valeur à maintenir en double.
     */
    public static function installedVersion(): string
    {
        try {
            $db    = \Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
            $cache = $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('manifest_cache'))
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                    ->where($db->quoteName('folder') . ' = ' . $db->quote('ajax'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('sitemonitor'))
            )->loadResult();

            $manifest = json_decode((string) $cache, true) ?: [];
            $version  = (string) ($manifest['version'] ?? '');

            return $version !== '' ? $version : self::VERSION;
        } catch (\Throwable $e) {
            return self::VERSION;
        }
    }

    /**
     * Point d'entrée : index.php?option=com_ajax&plugin=sitemonitor&format=raw&token=...
     */
    public function onAjaxSitemonitor(Event $event): void
    {
        $app = $this->getApplication();

        $secret = trim((string) $this->params->get('token', ''));
        $given  = (string) $app->getInput()->getString('token', '');

        // Refus si aucun token configuré, ou si le token ne correspond pas.
        if ($secret === '' || $given === '' || !hash_equals($secret, $given)) {
            $this->sendJson(['status' => 'error', 'message' => 'Acces refuse'], 403);

            return;
        }

        // Action spéciale : rafraîchir la liste des mises à jour
        // (équivalent du bouton « Chercher les mises à jour » du backend).
        // Sans visite d'administrateur, Joomla ne vérifie jamais les mises
        // à jour d'extensions : le central déclenche ce contrôle 1x/jour.
        if ($app->getInput()->getString('refresh') === 'updates') {
            try {
                @set_time_limit(180);

                $db = $this->getDatabase();

                // Force un VRAI re-contrôle : Joomla met en cache le résultat des
                // sites de mise à jour pendant 1 h. On réinitialise l'horodatage de
                // contrôle puis on vérifie SANS cache (0), pour voir tout de suite un
                // changement récent du canal.
                //
                // IMPORTANT : on NE purge PAS #__updates. findUpdates rafraîchit les
                // enregistrements des serveurs joignables et CONSERVE ceux des serveurs
                // temporairement injoignables (éditeurs à serveur intermittent comme
                // JoomShaper). Purger ferait perdre une MàJ déjà détectée si le serveur
                // de l'éditeur est down pile au moment du re-contrôle.
                $db->setQuery(
                    $db->getQuery(true)
                        ->update($db->quoteName('#__update_sites'))
                        ->set($db->quoteName('last_check_timestamp') . ' = 0')
                )->execute();

                Updater::getInstance()->findUpdates(0, 0);

                $this->sendJson([
                    'status'    => 'ok',
                    'refreshed' => true,
                    'generated' => gmdate('c'),
                ]);
            } catch (\Throwable $e) {
                $this->sendJson(['status' => 'error', 'message' => $e->getMessage()], 500);
            }

            return;
        }

        // Action : mise à jour d'une extension à distance (ÉCRITURE).
        if ($app->getInput()->getString('action') === 'update') {
            $this->handleRemoteUpdate();

            return;
        }

        // Action : sauvegarde Akeeba à distance (ÉCRITURE).
        if ($app->getInput()->getString('action') === 'backup') {
            $this->handleRemoteBackup();

            return;
        }

        // Action : application d'un bloc de durcissement .htaccess (ÉCRITURE).
        if ($app->getInput()->getString('action') === 'htaccess') {
            $this->handleRemoteHtaccess();

            return;
        }

        // Action : nettoyage tmp / caches (SUPPRESSION).
        if ($app->getInput()->getString('action') === 'clean') {
            $this->handleRemoteClean();

            return;
        }

        $core      = $this->collect('getCoreInfo');
        $auto      = $this->collect('getAutoUpdate');
        $backend   = $this->collect('getBackendUsers');
        $total     = $this->collect('getUsersTotal');
        $backup    = $this->collect('getBackup');
        $files     = $this->collect('getPhpFiles');
        $updates   = $this->collect('getUpdates');
        $exts      = $this->collect('getExtensions');
        $supers    = $this->collect('getSuperUsers');
        $tasks     = $this->collect('getScheduledTasks');
        $logs      = $this->collect('getActionLogs');
        $dbSchema  = $this->collect('getDatabaseSchema');
        $secFiles  = $this->collect('getSecurityFiles');
        $maint     = $this->collect('getMaintenance');

        // Résumé compact, lisible d'un coup d'œil en tête de réponse.
        $summary = [
            'joomla'            => $core['joomla_version'] ?? null,
            'php'               => $core['php_version'] ?? null,
            'offline'           => $core['offline'] ?? null,
            'auto_update'       => $auto['enabled'] ?? null,
            'extensions_total'  => \is_array($exts) && !isset($exts['error']) ? \count($exts) : null,
            'updates_available' => $updates['count'] ?? null,
            'super_users'       => \is_array($supers) && !isset($supers['error']) ? \count($supers) : null,
            'backend_users'     => \is_array($backend) && !isset($backend['error']) ? \count($backend) : null,
            'users_total'       => \is_array($total) && isset($total['total']) ? $total['total'] : null,
            'backup_installed'  => \is_array($backup) && isset($backup['installed']) ? $backup['installed'] : null,
            'last_backup'       => \is_array($backup) && isset($backup['last_backup']) ? $backup['last_backup'] : null,
            'scheduled_tasks'   => \is_array($tasks) && !isset($tasks['error']) ? \count($tasks) : null,
            'action_logs'       => \is_array($logs) && !isset($logs['error']) ? \count($logs) : null,
            'db_schema_checked'  => \is_array($dbSchema) && isset($dbSchema['checked']) ? $dbSchema['checked'] : null,
            'db_schema_problems' => \is_array($dbSchema) && isset($dbSchema['problems']) ? \count($dbSchema['problems']) : null,
        ];

        $data = [
            'status'          => 'ok',
            'plugin_version'  => self::installedVersion(),
            'generated'       => gmdate('c'),
            'summary'         => $summary,
            'core'            => $core,
            'auto_update'     => $auto,
            'updates'         => $updates,
            'extensions'      => $exts,
            'super_users'     => $supers,
            'backend_users'   => $backend,
            'backup'          => $backup,
            'php_files'       => $files,
            'scheduled_tasks' => $tasks,
            'action_logs'     => $logs,
            'db_schema'       => $dbSchema,
            'security_files'  => $secFiles,
            'maintenance'     => $maint,
        ];

        $this->sendJson($data);
    }

    /**
     * Déclenche une sauvegarde Akeeba à distance via l'URL de « sauvegarde
     * front-end » d'Akeeba Pro (la méthode « cron URL », stable et documentée,
     * également utilisée par Panopticon). Le mot secret est lu automatiquement
     * dans la configuration d'Akeeba (ou fourni via un paramètre du plugin).
     *
     * Akeeba Core n'expose pas cette API : la sauvegarde à distance nécessite Pro.
     */
    private function handleRemoteBackup(): void
    {
        $app = $this->getApplication();

        // Même opt-in que les mises à jour (action d'écriture à distance).
        if (!$this->params->get('allow_updates', 0)) {
            $this->sendJson([
                'status'  => 'error',
                'code'    => 'disabled',
                'message' => 'Actions à distance désactivées sur ce site (à activer dans la configuration du plugin Oculus Client).',
            ], 403);

            return;
        }

        $allowIps = trim((string) $this->params->get('update_ips', ''));

        if ($allowIps !== '') {
            $ips    = array_filter(array_map('trim', preg_split('/[,;\s]+/', $allowIps)));
            $remote = (string) ($_SERVER['REMOTE_ADDR'] ?? '');

            if (!\in_array($remote, $ips, true)) {
                $this->sendJson(['status' => 'error', 'code' => 'ip', 'message' => 'Adresse IP non autorisée : ' . $remote], 403);

                return;
            }
        }

        // Localiser le composant Akeeba (moderne com_akeebabackup en priorité).
        $component = null;

        foreach (['com_akeebabackup', 'com_akeeba'] as $candidate) {
            if (is_dir(JPATH_ADMINISTRATOR . '/components/' . $candidate)) {
                $component = $candidate;
                break;
            }
        }

        if ($component === null) {
            $this->sendJson(['status' => 'error', 'code' => 'no_akeeba', 'message' => 'Akeeba Backup introuvable sur ce site.'], 404);

            return;
        }

        $profile = (int) $this->params->get('backup_profile', 1) ?: 1;

        // Édition Akeeba : la sauvegarde front-end distante n'existe qu'en Pro.
        $edition = 'unknown';

        if (method_exists($this, 'detectAkeebaEdition')) {
            $det     = $this->detectAkeebaEdition($component);
            $edition = (string) ($det[0] ?? 'unknown');
        }

        // Mot secret de la sauvegarde front-end : override manuel du plugin, sinon
        // lecture automatique dans la configuration d'Akeeba.
        $secret = trim((string) $this->params->get('backup_secret', ''));
        $cfg    = ['secret' => '', 'frontend_enable' => null, 'keys' => []];

        if ($secret === '') {
            $cfg    = $this->readAkeebaConfig($component);
            $secret = (string) $cfg['secret'];
        }

        if ($secret === '') {
            $this->sendJson([
                'status'  => 'error',
                'code'    => 'no_secret',
                'message' => $edition === 'core'
                    ? 'Sauvegarde à distance impossible : Akeeba Core ne propose pas de sauvegarde front-end (Akeeba Pro requis).'
                    : 'Aucun « mot secret » de sauvegarde front-end trouvé automatiquement. Dans Akeeba : Options → activer « Sauvegarde front-end héritée » et définir un mot secret ; ou renseigne le champ « Mot secret sauvegarde » dans la config du plugin Oculus Client. [clés Akeeba lues : ' . (implode(', ', $cfg['keys']) ?: 'aucune') . ']',
            ], 400);

            return;
        }

        // URL de sauvegarde front-end Akeeba (méthode « cron URL », stable et
        // documentée). Akeeba déroule la sauvegarde par étapes via des redirections
        // HTTP que curl suit jusqu'au bout.
        $root = rtrim(\Joomla\CMS\Uri\Uri::root(), '/');
        $url  = $root . '/index.php?option=' . rawurlencode($component)
            . '&view=backup&key=' . rawurlencode($secret) . '&profile=' . $profile;

        @set_time_limit(0);
        @ignore_user_abort(true);

        // Fichier de cookies : Akeeba suit l'état de la sauvegarde en cours via la
        // SESSION. Sans conserver les cookies, l'état est perdu à chaque étape et la
        // sauvegarde cale (c'est ce qui s'est passé avant).
        $cookie = @tempnam(sys_get_temp_dir(), 'oculus_bk_');

        // UN SEUL appel : l'API front-end avance par redirections HTTP (302) et curl
        // suit toute la chaîne jusqu'à la fin. Un nouvel appel de haut niveau
        // démarrerait une NOUVELLE sauvegarde — d'où l'appel unique.
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            \CURLOPT_RETURNTRANSFER => true,
            \CURLOPT_FOLLOWLOCATION => true,
            \CURLOPT_MAXREDIRS      => 100000,
            \CURLOPT_TIMEOUT        => 1800,
            \CURLOPT_CONNECTTIMEOUT => 30,
            \CURLOPT_SSL_VERIFYPEER => false,
            \CURLOPT_SSL_VERIFYHOST => 0,
            \CURLOPT_USERAGENT      => 'OculusClient/' . self::VERSION,
            \CURLOPT_COOKIEFILE     => (string) $cookie,
            \CURLOPT_COOKIEJAR      => (string) $cookie,
        ]);

        $body  = (string) curl_exec($ch);
        $errno = curl_errno($ch);
        $cerr  = curl_error($ch);
        $code  = (int) curl_getinfo($ch, \CURLINFO_HTTP_CODE);
        $nredir = (int) curl_getinfo($ch, \CURLINFO_REDIRECT_COUNT);
        curl_close($ch);

        if (\is_string($cookie) && $cookie !== '') {
            @unlink($cookie);
        }

        $head = trim(mb_substr($body, 0, 300));

        if ($errno !== 0) {
            $this->auditBackup(false, $cerr);
            $this->sendJson([
                'status'  => 'error',
                'code'    => 'curl',
                'message' => 'Sauvegarde interrompue : ' . $cerr . ' [redirections=' . $nredir . ']',
            ], 500);

            return;
        }

        // Fin normale : la dernière réponse commence par « 200 ».
        if ($code === 200 && preg_match('/^\s*200\b/', $body)) {
            $this->auditBackup(true, '');
            $this->sendJson([
                'status'    => 'ok',
                'backed_up' => true,
                'profile'   => $profile,
                'steps'     => $nredir,
                'generated' => gmdate('c'),
            ]);

            return;
        }

        // Clé invalide ou sauvegarde front-end désactivée.
        if ($code === 403 || preg_match('/^\s*40[13]\b/', $body) || stripos($body, 'not allowed') !== false) {
            $this->auditBackup(false, 'HTTP ' . $code . ' ' . $head);
            $this->sendJson([
                'status'  => 'error',
                'code'    => 'forbidden',
                'message' => 'Accès refusé par Akeeba (HTTP ' . $code . '). Vérifie dans Akeeba → Options : « Sauvegarde front-end héritée » activée + mot secret correct. Réponse : ' . $head,
            ], 403);

            return;
        }

        // Autre : erreur moteur ou réponse inattendue.
        $this->auditBackup(false, 'HTTP ' . $code . ' ' . $head);
        $this->sendJson([
            'status'  => 'error',
            'code'    => 'backup_failed',
            'message' => 'Sauvegarde non terminée (HTTP ' . $code . ', redirections=' . $nredir . ') : ' . ($head !== '' ? $head : '(vide)'),
        ], 500);
    }

    /** Marqueurs délimitant le bloc géré par Oculus dans le .htaccess. */
    private const HT_BEGIN = '#---OCULUS BEGIN--- (bloc géré par Oculus, ne pas modifier à la main)';
    private const HT_END   = '#---OCULUS END---';

    /**
     * Applique (ou retire) un bloc de durcissement dans le .htaccess racine.
     *
     * Sécurité : on n'écrit QUE dans notre bloc délimité, jamais dans le reste du
     * fichier. Le fichier est sauvegardé avant écriture, puis le site est testé :
     * si la page d'accueil renvoie une erreur serveur (500), la sauvegarde est
     * restaurée automatiquement. Le pire cas est donc « rien n'a changé ».
     */
    private function handleRemoteHtaccess(): void
    {
        $app = $this->getApplication();

        if (!$this->params->get('allow_updates', 0)) {
            $this->sendJson([
                'status'  => 'error',
                'code'    => 'disabled',
                'message' => 'Actions à distance désactivées sur ce site (config du plugin Oculus Client).',
            ], 403);

            return;
        }

        $allowIps = trim((string) $this->params->get('update_ips', ''));

        if ($allowIps !== '') {
            $ips    = array_filter(array_map('trim', preg_split('/[,;\s]+/', $allowIps)));
            $remote = (string) ($_SERVER['REMOTE_ADDR'] ?? '');

            if (!\in_array($remote, $ips, true)) {
                $this->sendJson(['status' => 'error', 'code' => 'ip', 'message' => 'Adresse IP non autorisée : ' . $remote], 403);

                return;
            }
        }

        // Le bloc arrive encodé en base64 (il contient sauts de ligne et symboles).
        $raw   = (string) $app->getInput()->get('block', '', 'RAW');
        $block = $raw === '' ? '' : (string) base64_decode($raw, true);

        if ($raw !== '' && $block === '') {
            $this->sendJson(['status' => 'error', 'code' => 'bad_block', 'message' => 'Bloc illisible (base64 invalide).'], 400);

            return;
        }

        if (\strlen($block) > 16384) {
            $this->sendJson(['status' => 'error', 'code' => 'too_big', 'message' => 'Bloc trop volumineux (16 Ko maximum).'], 400);

            return;
        }

        // Un bloc contenant nos propres marqueurs casserait le découpage.
        if ($block !== '' && (strpos($block, self::HT_BEGIN) !== false || strpos($block, self::HT_END) !== false)) {
            $this->sendJson(['status' => 'error', 'code' => 'bad_block', 'message' => 'Le bloc ne doit pas contenir les marqueurs Oculus.'], 400);

            return;
        }

        // GARDE-FOU : un bloc entièrement commenté (typiquement des sauts de ligne
        // perdus en route, tout se retrouvant derrière un « # ») s'écrit sans erreur
        // et ne protège RIEN. On refuse plutôt que de rapporter un faux succès.
        if (trim($block) !== '' && trim((string) preg_replace('/^\s*#.*$/m', '', $block)) === '') {
            $this->sendJson([
                'status'  => 'error',
                'code'    => 'inert_block',
                'message' => 'Le bloc ne contient aucune directive active (tout est en commentaire) : '
                    . 'il ne protégerait rien. Vérifiez que les sauts de ligne sont bien conservés dans le réglage du module.',
            ], 400);

            return;
        }

        $file = rtrim(JPATH_ROOT, '/\\') . '/.htaccess';

        try {
            $existed = is_file($file);
            $current = $existed ? (string) @file_get_contents($file) : '';

            if ($existed && !is_writable($file)) {
                $this->sendJson([
                    'status'  => 'error',
                    'code'    => 'not_writable',
                    'message' => 'Le fichier .htaccess n\'est pas modifiable (permissions).',
                ], 403);

                return;
            }

            // Sauvegarde horodatée, conservée sur le site.
            $backupFile = null;

            if ($existed) {
                $backupFile = $file . '.oculus-' . gmdate('Ymd-His') . '.bak';

                if (@copy($file, $backupFile) === false) {
                    $this->sendJson([
                        'status'  => 'error',
                        'code'    => 'backup_failed',
                        'message' => 'Impossible de sauvegarder le .htaccess avant modification — opération annulée.',
                    ], 500);

                    return;
                }
            }

            // Retire un éventuel bloc Oculus précédent (application idempotente).
            $withoutOculus = preg_replace(
                '/' . preg_quote(self::HT_BEGIN, '/') . '.*?' . preg_quote(self::HT_END, '/') . '\R?/s',
                '',
                $current
            );
            $withoutOculus = $withoutOculus === null ? $current : $withoutOculus;

            if (trim($block) === '') {
                // Bloc vide = retrait pur et simple du durcissement Oculus.
                $new = $withoutOculus;
            } else {
                // EN TÊTE de fichier : les règles de blocage doivent primer sur la
                // réécriture Joomla, sinon un .php déposé dans /images serait servi
                // directement par Apache avant d'atteindre nos règles.
                $new = self::HT_BEGIN . "\n" . trim($block) . "\n" . self::HT_END . "\n\n" . ltrim($withoutOculus);
            }

            if (@file_put_contents($file, $new, \LOCK_EX) === false) {
                $this->sendJson(['status' => 'error', 'code' => 'write_failed', 'message' => 'Écriture du .htaccess impossible.'], 500);

                return;
            }

            // FILET DE SÉCURITÉ : le site répond-il toujours ?
            [$httpCode, $curlError] = $this->probeSite();
            $broken = ($curlError !== '') || ($httpCode >= 500);

            if ($broken) {
                // Restauration immédiate.
                if ($backupFile !== null && is_file($backupFile)) {
                    @copy($backupFile, $file);
                } elseif (!$existed) {
                    @unlink($file);
                }

                $this->auditHtaccess(false, 'HTTP ' . $httpCode . ' ' . $curlError);
                $this->sendJson([
                    'status'  => 'error',
                    'code'    => 'rolled_back',
                    'message' => 'Le site est tombé en erreur après modification ('
                        . ($curlError !== '' ? $curlError : 'HTTP ' . $httpCode)
                        . ') — le .htaccess précédent a été RESTAURÉ. Rien n\'a changé.',
                ], 500);

                return;
            }

            // VÉRIFICATION RÉELLE : écrire la règle ne prouve pas que le serveur
            // l'applique (nginx ignore les .htaccess ; Apache peut avoir
            // AllowOverride restreint). On teste donc pour de bon.
            $probe       = null;
            $probeReason = '';

            if (trim($block) !== '') {
                [$probe, $probeReason] = $this->probeHardening();

                // On n'inscrit le résultat QUE si le test a réellement eu lieu.
                // Un test impossible ne prouve rien : inscrire un code fictif ferait
                // croire à tort que la protection est inopérante.
                $stamp = self::HT_BEGIN . "\n" . trim($block)
                    . ($probe === null ? '' : "\n# oculus-verify: " . $probe . ' @ ' . gmdate('c'))
                    . "\n" . self::HT_END;

                $withStamp = preg_replace(
                    '/' . preg_quote(self::HT_BEGIN, '/') . '.*?' . preg_quote(self::HT_END, '/') . '/s',
                    str_replace('$', '\\$', $stamp),
                    (string) @file_get_contents($file),
                    1
                );

                if (\is_string($withStamp) && $withStamp !== '') {
                    @file_put_contents($file, $withStamp, \LOCK_EX);
                }
            }

            // 403 ET 404 valent « bloqué » : certains serveurs renvoient 404 plutôt
            // que 403 pour ne rien révéler. Le témoin de contrôle a déjà prouvé que
            // l'URL testée est la bonne, sans quoi $probe serait null.
            $blocked = \in_array($probe, [403, 404], true);

            $this->auditHtaccess(true, $blocked ? '' : 'protection non verifiee');
            $this->sendJson([
                'status'       => 'ok',
                'applied'      => trim($block) !== '',
                'created'      => !$existed,
                'backup'       => $backupFile !== null ? basename($backupFile) : null,
                'http_code'    => $httpCode,
                'verified'     => $blocked,
                'probe_code'   => $probe,
                'probe_reason' => $probeReason,
                'server'       => (string) ($_SERVER['SERVER_SOFTWARE'] ?? ''),
                'generated'    => gmdate('c'),
            ]);
        } catch (\Throwable $e) {
            $this->auditHtaccess(false, $e->getMessage());
            $this->sendJson(['status' => 'error', 'message' => 'Erreur .htaccess : ' . $e->getMessage()], 500);
        }
    }

    /**
     * TEST RÉEL du durcissement : dépose un fichier témoin inoffensif dans
     * images/, l'appelle en HTTP, puis le supprime immédiatement.
     *
     * 403 = le serveur applique bien la règle. 200 = la règle est écrite mais
     * ignorée (nginx, ou Apache avec AllowOverride restreint) : la protection
     * est illusoire, et il vaut mieux le savoir.
     *
     * @return array{0:?int, 1:string} [code HTTP ou null si test impossible, raison]
     */
    private function probeHardening(): array
    {
        $dir = rtrim(JPATH_ROOT, '/\\') . '/images';

        if (!is_dir($dir)) {
            return [null, 'dossier images/ absent'];
        }

        if (!is_writable($dir)) {
            return [null, 'dossier images/ non inscriptible'];
        }

        // PAS de point en tête : un fichier caché serait bloqué par les règles
        // « dotfiles » de nombreux serveurs, ce qui produirait un 403 trompeur
        // sans rapport avec notre protection.
        $rand    = bin2hex(random_bytes(4));
        $phpName = 'oculus-probe-' . $rand . '.php';
        $txtName = 'oculus-probe-' . $rand . '.txt';
        $probe   = $dir . '/' . $phpName;
        $control = $dir . '/' . $txtName;

        if (@file_put_contents($probe, "<?php echo 'oculus-probe';\n") === false) {
            return [null, 'écriture du fichier témoin impossible'];
        }

        // TÉMOIN DE CONTRÔLE : un .txt au même endroit. S'il n'est pas servi en 200,
        // c'est que l'URL testée ne correspond pas au dossier où l'on écrit — et
        // alors un 403/404 sur le .php ne prouverait rien.
        @file_put_contents($control, "oculus-control\n");

        $code   = null;
        $reason = '';

        try {
            $base = rtrim(\Joomla\CMS\Uri\Uri::root(), '/') . '/images/';

            [$ctrlCode, $ctrlErr] = $this->httpStatus($base . $txtName . '?oc=' . time());

            if ($ctrlErr !== '') {
                // Le site n'arrive pas à s'appeler lui-même (boucle locale bloquée,
                // DNS interne, pare-feu sortant…). Test impossible, rien à conclure.
                $reason = 'le site ne peut pas s\'appeler lui-même en HTTP (' . $ctrlErr . ')';
            } elseif ($ctrlCode !== 200) {
                // Le dossier écrit n'est pas celui servi à cette URL : un 403/404 sur
                // le .php ne prouverait rien. On refuse de conclure.
                $reason = 'le dossier images/ n\'est pas atteignable à l\'URL testée'
                    . ' (fichier de contrôle : HTTP ' . $ctrlCode . ') — test non concluant';
            } else {
                [$code, $err] = $this->httpStatus($base . $phpName . '?oc=' . time());

                if ($err !== '') {
                    $code   = null;
                    $reason = 'appel du témoin PHP impossible (' . $err . ')';
                }
            }
        } catch (\Throwable $e) {
            $reason = $e->getMessage();
        } finally {
            // Les témoins ne doivent JAMAIS subsister.
            @unlink($probe);
            @unlink($control);
        }

        return [$code, $reason];
    }

    /**
     * Code HTTP d'une URL, sans suivre les redirections.
     *
     * @return array{0:?int, 1:string} [code, erreur curl]
     */
    private function httpStatus(string $url): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            \CURLOPT_RETURNTRANSFER => true,
            \CURLOPT_FOLLOWLOCATION => false,
            \CURLOPT_TIMEOUT        => 15,
            \CURLOPT_CONNECTTIMEOUT => 10,
            \CURLOPT_SSL_VERIFYPEER => false,
            \CURLOPT_SSL_VERIFYHOST => 0,
            \CURLOPT_USERAGENT      => 'OculusClient/' . self::VERSION,
        ]);

        curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $code  = (int) curl_getinfo($ch, \CURLINFO_HTTP_CODE);
        curl_close($ch);

        return $errno === 0 ? [$code, ''] : [null, $error];
    }

    /**
     * Interroge la page d'accueil du site pour vérifier qu'il répond encore.
     *
     * @return array{0:int, 1:string} [code HTTP, erreur curl]
     */
    private function probeSite(): array
    {
        $ch = curl_init(rtrim(\Joomla\CMS\Uri\Uri::root(), '/') . '/');
        curl_setopt_array($ch, [
            \CURLOPT_RETURNTRANSFER => true,
            \CURLOPT_FOLLOWLOCATION => true,
            \CURLOPT_MAXREDIRS      => 5,
            \CURLOPT_TIMEOUT        => 20,
            \CURLOPT_CONNECTTIMEOUT => 10,
            \CURLOPT_SSL_VERIFYPEER => false,
            \CURLOPT_SSL_VERIFYHOST => 0,
            \CURLOPT_USERAGENT      => 'OculusClient/' . self::VERSION,
        ]);

        curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $code  = (int) curl_getinfo($ch, \CURLINFO_HTTP_CODE);
        curl_close($ch);

        return [$code, $errno !== 0 ? $error : ''];
    }

    /** Journalise une modification de .htaccess (audit). */
    private function auditHtaccess(bool $ok, string $error): void
    {
        try {
            \Joomla\CMS\Log\Log::add(
                'Oculus - Modification .htaccess : ' . ($ok ? 'succes' : 'echec/restauration')
                . ($error !== '' ? ' - ' . $error : ''),
                $ok ? \Joomla\CMS\Log\Log::INFO : \Joomla\CMS\Log\Log::WARNING,
                'oculus'
            );
        } catch (\Throwable $e) {
            // best-effort
        }
    }

    /**
     * Lit la configuration d'Akeeba (options du composant) pour récupérer le
     * mot secret de la sauvegarde front-end et l'état d'activation.
     *
     * @return array{secret:string, frontend_enable:?int, keys:array}
     */
    private function readAkeebaConfig(string $component): array
    {
        $out = ['secret' => '', 'frontend_enable' => null, 'keys' => []];

        try {
            $db     = $this->getDatabase();
            $params = $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('params'))
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote($component))
            )->loadResult();

            $cfg = json_decode((string) $params, true);

            if (\is_array($cfg)) {
                $out['keys'] = array_keys($cfg);

                foreach (['secret_word', 'frontend_secret_word', 'secretword', 'secret'] as $k) {
                    if (!empty($cfg[$k])) {
                        $out['secret'] = (string) $cfg[$k];
                        break;
                    }
                }

                foreach (['frontend_enable', 'legacyapi_enabled', 'legacyapi'] as $k) {
                    if (isset($cfg[$k])) {
                        $out['frontend_enable'] = (int) $cfg[$k];
                        break;
                    }
                }
            }
        } catch (\Throwable $e) {
            // best-effort
        }

        return $out;
    }

    /**
     * Localise le dossier de la plateforme Joomla du moteur Akeeba en parcourant
     * l'arborescence du composant (le nom varie : BackupPlatform/Joomla,
     * Platform/Joomla, platform/Joomla…).
     */
    private function findAkeebaPlatformDir(string $base): ?string
    {
        try {
            $it = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($base, \FilesystemIterator::SKIP_DOTS | \FilesystemIterator::FOLLOW_SYMLINKS),
                \RecursiveIteratorIterator::SELF_FIRST
            );
            $count = 0;

            foreach ($it as $entry) {
                if (++$count > 40000) {
                    break;
                }

                if (!$entry->isDir()) {
                    continue;
                }

                $path = str_replace('\\', '/', $entry->getPathname());

                // Un dossier « …/…platform/Joomla » contenant le code de plateforme.
                if (preg_match('#/[A-Za-z]*platform/Joomla$#i', $path)) {
                    return realpath($entry->getPathname()) ?: $entry->getPathname();
                }
            }
        } catch (\Throwable $e) {
            // scan impossible
        }

        return null;
    }

    /** Journalise une sauvegarde à distance (audit). */
    private function auditBackup(bool $ok, string $error): void
    {
        try {
            \Joomla\CMS\Log\Log::add(
                'Oculus - Sauvegarde Akeeba distante : ' . ($ok ? 'succes' : 'echec') . ($error !== '' ? ' - ' . $error : ''),
                $ok ? \Joomla\CMS\Log\Log::INFO : \Joomla\CMS\Log\Log::WARNING,
                'oculus'
            );
        } catch (\Throwable $e) {
            // best-effort
        }
    }

    /**
     * Met à jour une extension à distance (déclenché par le central Oculus).
     * Sécurité : opt-in par site (allow_updates), restriction IP optionnelle,
     * garde-fou de sauvegarde (< 24 h pour les composants/paquets/templates
     * tiers), journal d'audit. Installation via le moteur natif de com_installer.
     */
    private function handleRemoteUpdate(): void
    {
        $app = $this->getApplication();

        // 1. Opt-in obligatoire : les MàJ distantes sont désactivées par défaut.
        if (!$this->params->get('allow_updates', 0)) {
            $this->sendJson([
                'status'  => 'error',
                'code'    => 'disabled',
                'message' => 'Mises à jour à distance désactivées sur ce site (à activer dans la configuration du plugin Oculus Client).',
            ], 403);

            return;
        }

        // 2. Restriction par IP (optionnelle) : seul le serveur Oculus autorisé.
        $allowIps = trim((string) $this->params->get('update_ips', ''));

        if ($allowIps !== '') {
            $ips    = array_filter(array_map('trim', preg_split('/[,;\s]+/', $allowIps)));
            $remote = (string) ($_SERVER['REMOTE_ADDR'] ?? '');

            if (!\in_array($remote, $ips, true)) {
                $this->sendJson(['status' => 'error', 'code' => 'ip', 'message' => 'Adresse IP non autorisée : ' . $remote], 403);

                return;
            }
        }

        $eid = $app->getInput()->getInt('eid', 0);

        if ($eid <= 0) {
            $this->sendJson(['status' => 'error', 'message' => 'Extension non précisée.'], 400);

            return;
        }

        $db  = $this->getDatabase();
        $ext = $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName(['extension_id', 'name', 'type', 'element', 'folder', 'client_id']))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('extension_id') . ' = ' . $eid)
        )->loadObject();

        if (!$ext) {
            $this->sendJson(['status' => 'error', 'message' => 'Extension introuvable.'], 404);

            return;
        }

        // 3. Garde-fou sauvegarde : requis pour composant/paquet/template tiers.
        if ($this->backupRequiredFor($ext)) {
            $age = $this->lastBackupAgeHours();

            if ($age === null || $age > 24) {
                $this->sendJson([
                    'status'  => 'error',
                    'code'    => 'backup_stale',
                    'message' => $age === null
                        ? 'Aucune sauvegarde récente : lance une sauvegarde avant de mettre à jour.'
                        : 'Dernière sauvegarde de plus de 24 h (' . $age . ' h) : lance une sauvegarde avant de mettre à jour.',
                ], 409);

                return;
            }
        }

        try {
            @set_time_limit(300);

            $oldVersion = $this->extensionVersion($eid);

            // Force la détection de mise à jour, puis récupère la version cible.
            Updater::getInstance()->findUpdates($eid, 0);

            $updateRow = $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName(['update_id', 'version']))
                    ->from($db->quoteName('#__updates'))
                    ->where($db->quoteName('extension_id') . ' = ' . $eid)
            )->loadObject();

            if (!$updateRow || (int) $updateRow->update_id <= 0) {
                $this->sendJson(['status' => 'error', 'code' => 'no_update', 'message' => 'Aucune mise à jour disponible pour cette extension.'], 404);

                return;
            }

            $updateId      = (int) $updateRow->update_id;
            $targetVersion = (string) $updateRow->version;

            // Installation via le modèle natif (comme le bouton « Mettre à jour »).
            $model = $app->bootComponent('com_installer')
                ->getMVCFactory()
                ->createModel('Update', 'Administrator', ['ignore_request' => true]);

            // Capture des messages de l'installeur pour diagnostic.
            $before = \count($app->getMessageQueue());

            $model->update([$updateId]);

            $messages = \array_slice($app->getMessageQueue(), $before);
            $detail   = implode(' | ', array_filter(array_map(
                static fn ($m) => \is_array($m) ? trim(strip_tags((string) ($m['message'] ?? ''))) : '',
                $messages
            )));

            $newVersion = $this->extensionVersion($eid);

            // SUCCÈS = la version installée a RÉELLEMENT changé (fin des faux positifs).
            $ok = $newVersion !== null && $newVersion !== $oldVersion;

            // Cohérence : le processus d'installation purge la ligne #__updates même
            // en cas d'échec. On re-détecte donc les MàJ pour qu'Oculus ne « perde »
            // pas une mise à jour restée en attente (sinon le badge disparaîtrait à
            // tort après un échec).
            try {
                Updater::getInstance()->findUpdates($eid, 0);
            } catch (\Throwable $e) {
                // best-effort
            }

            $this->auditUpdate($ext, $ok, $newVersion, $ok ? '' : ('version inchangee ' . (string) $oldVersion . ' ' . $detail));

            if ($ok) {
                $this->sendJson([
                    'status'    => 'ok',
                    'updated'   => true,
                    'name'      => $ext->name,
                    'version'   => $newVersion,
                    'detail'    => $detail,
                    'generated' => gmdate('c'),
                ]);
            } else {
                $this->sendJson([
                    'status'  => 'error',
                    'code'    => 'install_failed',
                    'message' => 'La mise à jour n\'a pas abouti : version toujours ' . (string) ($oldVersion ?? '?')
                        . ' (cible ' . $targetVersion . ').'
                        . ($detail !== '' ? ' Détail : ' . $detail : ' Aucun message renvoyé par l\'installeur.'),
                ], 500);
            }
        } catch (\Throwable $e) {
            $this->auditUpdate($ext, false, null, $e->getMessage());
            $this->sendJson(['status' => 'error', 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Une sauvegarde préalable est-elle exigée pour cette extension ?
     * Non pour les plugins (petits/peu risqués) ni pour nos propres extensions ;
     * oui pour les composants, paquets et templates tiers.
     */
    private function backupRequiredFor(object $ext): bool
    {
        $type = (string) $ext->type;

        if ($type === 'plugin') {
            return false;
        }

        $el = strtolower((string) $ext->element);

        if (\in_array($el, ['sitemonitor', 'oculusgate', 'oculus', 'pkg_oculus_agent'], true)
            || stripos((string) $ext->name, 'oculus') !== false
            || stripos($el, 'oculus') !== false) {
            return false;
        }

        return \in_array($type, ['component', 'package', 'template'], true);
    }

    /** Âge en heures de la dernière sauvegarde Akeeba réussie (null si aucune). */
    private function lastBackupAgeHours(): ?int
    {
        $backup = $this->getBackup();
        $last   = $backup['last_backup'] ?? null;

        if (!$last) {
            return null;
        }

        $ts = strtotime((string) $last);

        return $ts === false ? null : (int) floor((time() - $ts) / 3600);
    }

    /** Version installée (manifest_cache) d'une extension. */
    private function extensionVersion(int $eid): ?string
    {
        $db  = $this->getDatabase();
        $raw = $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName('manifest_cache'))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('extension_id') . ' = ' . $eid)
        )->loadResult();

        $manifest = json_decode((string) $raw, true) ?: [];

        return $manifest['version'] ?? null;
    }

    /** Journalise une mise à jour à distance (audit). */
    private function auditUpdate(object $ext, bool $ok, ?string $version, string $error = ''): void
    {
        try {
            \Joomla\CMS\Log\Log::add(
                sprintf(
                    'Oculus - MaJ distante %s (%s) : %s%s',
                    $ext->name,
                    $ext->element,
                    $ok ? 'succes v' . $version : 'echec',
                    $error !== '' ? ' - ' . $error : ''
                ),
                $ok ? \Joomla\CMS\Log\Log::INFO : \Joomla\CMS\Log\Log::WARNING,
                'oculus'
            );
        } catch (\Throwable $e) {
            // Audit best-effort : on n'interrompt jamais pour ça.
        }
    }

    /**
     * Exécute une section de collecte : une erreur dans une section
     * n'empêche pas les autres d'être renvoyées.
     */
    private function collect(string $method)
    {
        try {
            return $this->{$method}();
        } catch (\Throwable $e) {
            return ['error' => $e->getMessage()];
        }
    }

    // ------------------------------------------------------------------
    // Sections de collecte (v0.1)
    // ------------------------------------------------------------------

    private function getCoreInfo(): array
    {
        $db = $this->getDatabase();

        return [
            'joomla_version' => JVERSION,
            'php_version'    => PHP_VERSION,
            'db_type'        => $db->getServerType(),
            'db_version'     => $db->getVersion(),
            // « offline » réel : si la passerelle Oculus Gate a levé la maintenance
            // pour cette requête, elle laisse un marqueur pour qu'on rapporte quand
            // même l'état de maintenance au central.
            'offline'        => (bool) $this->getApplication()->get('offline', 0)
                || (bool) $this->getApplication()->get('oculus.maintenance', false),
        ];
    }

    // ------------------------------------------------------------------
    // Sections de collecte (nouveautés v0.2)
    // ------------------------------------------------------------------

    /**
     * Surveillance du schéma de la base de données.
     *
     * Réutilise le modèle natif de com_installer (le moteur exact de l'écran
     * « Système → Maintenance : Base de données ») pour vérifier, extension par
     * extension, que la structure des tables est à jour. Après une mise à jour,
     * une extension peut laisser son schéma en erreur sans que le site tombe :
     * c'est précisément ce qu'on veut faire remonter ici.
     *
     * @return array{checked:int, problems:array<int, array{name:string, errors:int}>}
     */
    private function getDatabaseSchema(): array
    {
        $app = $this->getApplication();

        // Le modèle vit côté administration ; on l'instancie sans lire la requête.
        $model = $app->bootComponent('com_installer')
            ->getMVCFactory()
            ->createModel('Database', 'Administrator', ['ignore_request' => true]);

        if (!$model) {
            return ['error' => 'Modèle com_installer indisponible'];
        }

        // Amorce l'état (filtres/tri par défaut) puis lève la pagination :
        // la liste des extensions à schéma est courte, on veut la totalité.
        $model->getState();
        $model->setState('list.limit', 0);
        $model->setState('list.start', 0);

        $items    = $model->getItems();
        $problems = [];
        $checked  = 0;

        foreach ((array) $items as $it) {
            $checked++;

            $errors = (int) ($it->errorsCount ?? 0);

            if ($errors > 0) {
                $name = (string) ($it->name ?? $it->element ?? '?');

                $problems[] = [
                    'name'    => $name,
                    'element' => (string) ($it->element ?? ''),
                    'errors'  => $errors,
                ];
            }
        }

        return [
            'checked'  => $checked,
            'problems' => $problems,
        ];
    }

    /**
     * État des mises à jour automatiques du cœur (Joomla 5.4+/6),
     * lu dans la configuration de com_joomlaupdate.
     * NB : le paramètre update_token n'est JAMAIS exposé.
     */
    private function getAutoUpdate(): array
    {
        $db = $this->getDatabase();

        $raw = $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName('params'))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('component'))
                ->where($db->quoteName('element') . ' = ' . $db->quote('com_joomlaupdate'))
        )->loadResult();

        $params = json_decode((string) $raw, true) ?: [];

        $supported = version_compare(JVERSION, '5.4.0', 'ge');
        $enabled   = $supported && !empty($params['autoupdate']);

        // Enregistrement auprès du serveur de MàJ automatique : un token secret est
        // stocké. On n'expose JAMAIS sa valeur, seulement sa présence.
        $hasToken = !empty($params['update_token']);

        // Horodatage de la dernière vérification. Peut être un timestamp Unix ou une
        // date SQL selon la version : on normalise.
        $lastRaw = $params['update_last_check'] ?? null;
        $lastTs  = null;

        if (is_numeric($lastRaw)) {
            $lastTs = (int) $lastRaw;
        } elseif (is_string($lastRaw) && $lastRaw !== '' && strpos($lastRaw, '0000-00-00') !== 0) {
            $lastTs = strtotime($lastRaw) ?: null;
        }

        // Le serveur Joomla contrôle la santé de l'auto-MàJ ~toutes les 24 h. On
        // tolère 48 h avant de considérer la connexion comme « endormie ».
        $recent = $lastTs !== null && (time() - $lastTs) <= 172800;

        // « Sain » (pastille verte côté Joomla) = fonction activée, site enregistré
        // (token présent) ET vérification récente. Tout le reste correspond au message
        // « Mise à jour auto. indisponible » de Joomla.
        $healthy = $enabled && $hasToken && $recent;

        return [
            'supported'  => $supported,
            'enabled'    => $enabled,
            'has_token'  => $hasToken,
            'healthy'    => $healthy,
            'status'     => $params['autoupdate_status'] ?? null,
            'last_check' => $lastTs !== null ? gmdate('c', $lastTs) : null,
        ];
    }

    /**
     * Extensions installées (composants, plugins, modules, templates, etc.).
     */
    private function getExtensions(): array
    {
        $db    = $this->getDatabase();
        $query = $db->getQuery(true)
            ->select($db->quoteName([
                'extension_id', 'name', 'type', 'element',
                'folder', 'client_id', 'enabled', 'manifest_cache', 'package_id',
            ]))
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('state') . ' >= 0')
            ->order($db->quoteName('type') . ', ' . $db->quoteName('folder') . ', ' . $db->quoteName('element'));

        $rows = $db->setQuery($query)->loadObjectList();
        $list = [];

        foreach ($rows as $row) {
            $manifest = json_decode((string) $row->manifest_cache, true) ?: [];

            $list[] = [
                'id'        => (int) $row->extension_id,
                'name'      => $this->translateExtensionName($row),
                'type'      => $row->type,
                'element'   => $row->element,
                'folder'    => $row->folder,
                'client_id' => (int) $row->client_id,
                'enabled'    => (bool) $row->enabled,
                'version'    => $manifest['version'] ?? null,
                'package_id' => (int) ($row->package_id ?? 0),
            ];
        }

        return $list;
    }

    /**
     * Mises à jour disponibles (telles que connues du site lors de
     * sa dernière vérification des mises à jour).
     */
    private function getUpdates(): array
    {
        $db = $this->getDatabase();

        // Date de la dernière vérification des mises à jour par le site.
        $lastCheck = $db->setQuery(
            $db->getQuery(true)
                ->select('MAX(' . $db->quoteName('last_check_timestamp') . ')')
                ->from($db->quoteName('#__update_sites'))
                ->where($db->quoteName('enabled') . ' = 1')
        )->loadResult();

        $query = $db->getQuery(true)
            ->select([
                $db->quoteName('u.extension_id', 'extension_id'),
                $db->quoteName('u.name', 'name'),
                $db->quoteName('u.element', 'element'),
                $db->quoteName('u.type', 'type'),
                $db->quoteName('u.folder', 'folder'),
                $db->quoteName('u.client_id', 'client_id'),
                $db->quoteName('u.version', 'new_version'),
                $db->quoteName('e.manifest_cache', 'manifest_cache'),
            ])
            ->from($db->quoteName('#__updates', 'u'))
            ->join(
                'LEFT',
                $db->quoteName('#__extensions', 'e')
                . ' ON ' . $db->quoteName('e.extension_id') . ' = ' . $db->quoteName('u.extension_id')
            )
            // Exclut le catalogue des extensions non installées
            // (packs de langue proposés, etc.) : extension_id = 0.
            ->where($db->quoteName('u.extension_id') . ' > 0')
            ->order($db->quoteName('u.name'));

        $rows      = $db->setQuery($query)->loadObjectList();
        $available = [];

        foreach ($rows as $row) {
            $manifest = json_decode((string) $row->manifest_cache, true) ?: [];
            $current  = $manifest['version'] ?? null;
            $new      = $row->new_version;

            // Ligne « fantôme » : Joomla laisse parfois dans #__updates une entrée
            // dont la version cible n'est PAS supérieure à celle installée (typique
            // du cœur après une mise à jour : « 6.1.2 → 6.1.2 »). On l'ignore, sinon
            // Oculus alerte pour rien. Si la version installée est inconnue, on garde
            // l'entrée par prudence (mieux vaut sur-signaler que rater une MàJ).
            if ($current !== null && $new !== null && version_compare((string) $new, (string) $current, '<=')) {
                continue;
            }

            $available[] = [
                'extension_id'    => (int) $row->extension_id,
                'name'            => $row->name,
                'element'         => $row->element,
                'type'            => $row->type,
                'folder'          => $row->folder,
                'client_id'       => (int) $row->client_id,
                'current_version' => $current,
                'new_version'     => $new,
            ];
        }

        return [
            'last_check' => $lastCheck ? gmdate('c', (int) $lastCheck) : null,
            'count'      => \count($available),
            'available'  => $available,
        ];
    }

    /**
     * Utilisateurs appartenant à un groupe ayant le droit "core.admin"
     * (Super Users), avec leur statut 2FA si disponible.
     */
    private function getSuperUsers(): array
    {
        $db = $this->getDatabase();

        // Groupes disposant du droit core.admin.
        $groupIds = $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName('id'))
                ->from($db->quoteName('#__usergroups'))
        )->loadColumn();

        $superGroups = [];

        foreach ($groupIds as $groupId) {
            if (Access::checkGroup((int) $groupId, 'core.admin')) {
                $superGroups[] = (int) $groupId;
            }
        }

        if ($superGroups === []) {
            return [];
        }

        // Identifiants des utilisateurs membres de ces groupes.
        $userIds = $db->setQuery(
            $db->getQuery(true)
                ->select('DISTINCT ' . $db->quoteName('user_id'))
                ->from($db->quoteName('#__user_usergroup_map'))
                ->whereIn($db->quoteName('group_id'), $superGroups)
        )->loadColumn();

        if ($userIds === []) {
            return [];
        }

        $query = $db->getQuery(true)
            ->select($db->quoteName([
                'id', 'name', 'username', 'email', 'block',
                'registerDate', 'lastvisitDate',
            ]))
            ->from($db->quoteName('#__users'))
            ->whereIn($db->quoteName('id'), array_map('intval', $userIds))
            ->order($db->quoteName('id'));

        $rows = $db->setQuery($query)->loadObjectList();
        $list = [];

        foreach ($rows as $row) {
            $list[] = [
                'id'             => (int) $row->id,
                'name'           => $row->name,
                'username'       => $row->username,
                'email'          => $row->email,
                'blocked'        => (bool) $row->block,
                'register_date'  => $row->registerDate,
                'last_visit'     => $row->lastvisitDate,
                'mfa_enabled'    => $this->hasMfa((int) $row->id),
            ];
        }

        return $list;
    }

    /**
     * Indique si un utilisateur a au moins une méthode 2FA active.
     */
    private function hasMfa(int $userId): ?bool
    {
        try {
            $db    = $this->getDatabase();
            $count = $db->setQuery(
                $db->getQuery(true)
                    ->select('COUNT(*)')
                    ->from($db->quoteName('#__user_mfa'))
                    ->where($db->quoteName('user_id') . ' = :userid')
                    ->where($db->quoteName('method') . ' != ' . $db->quote('backupcodes'))
                    ->bind(':userid', $userId, \Joomla\Database\ParameterType::INTEGER)
            )->loadResult();

            return ((int) $count) > 0;
        } catch (\Throwable $e) {
            return null; // Table absente ou inaccessible.
        }
    }

    /**
     * Utilisateurs ayant accès à l'administration : membres des groupes
     * disposant de core.admin (Super Users) ou core.login.admin
     * (Administrator, Manager...). Inclut donc les super users.
     */
    private function getBackendUsers(): array
    {
        $db = $this->getDatabase();

        $groups = $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName(['id', 'title']))
                ->from($db->quoteName('#__usergroups'))
        )->loadObjectList();

        $backendGroups = [];

        foreach ($groups as $group) {
            $gid = (int) $group->id;

            if (Access::checkGroup($gid, 'core.admin') || Access::checkGroup($gid, 'core.login.admin')) {
                $backendGroups[$gid] = $group->title;
            }
        }

        if ($backendGroups === []) {
            return [];
        }

        // Appartenances aux groupes backend.
        $memberships = $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName(['user_id', 'group_id']))
                ->from($db->quoteName('#__user_usergroup_map'))
                ->whereIn($db->quoteName('group_id'), array_keys($backendGroups))
        )->loadObjectList();

        $userGroups = [];

        foreach ($memberships as $m) {
            $userGroups[(int) $m->user_id][] = $backendGroups[(int) $m->group_id];
        }

        if ($userGroups === []) {
            return [];
        }

        $rows = $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName([
                    'id', 'name', 'username', 'email', 'block',
                    'registerDate', 'lastvisitDate',
                ]))
                ->from($db->quoteName('#__users'))
                ->whereIn($db->quoteName('id'), array_keys($userGroups))
                ->order($db->quoteName('id'))
        )->loadObjectList();

        $list = [];

        foreach ($rows as $row) {
            $list[] = [
                'id'            => (int) $row->id,
                'name'          => $row->name,
                'username'      => $row->username,
                'email'         => $row->email,
                'blocked'       => (bool) $row->block,
                'groups'        => array_values(array_unique($userGroups[(int) $row->id])),
                'register_date' => $row->registerDate,
                'last_visit'    => $row->lastvisitDate,
                'mfa_enabled'   => $this->hasMfa((int) $row->id),
            ];
        }

        return $list;
    }

    /**
     * Surveillance des pièces maîtresses de sécurité à la racine :
     *  - configuration.php : empreinte + date de modif (le central/tâche alerte
     *    sur tout changement) ;
     *  - .htaccess : scan de motifs dangereux (portes dérobées) en NEUTRALISANT
     *    d'abord le bloc géré par CG Secure, pour éviter les faux positifs.
     */
    private function getSecurityFiles(): array
    {
        $base   = rtrim(JPATH_ROOT, '/\\');
        $result = [
            'config_hash'      => null,
            'config_modified'  => null,
            'config_mode'      => null,
            'htaccess_present' => false,
            'htaccess_mode'    => null,
            'htaccess_suspect' => [],
            // Bloc de durcissement géré par Oculus : null = indéterminé (fichier
            // absent/illisible), false = absent, true = présent. L'empreinte permet
            // au central de distinguer « appliqué et à jour » de « appliqué mais
            // différent du bloc actuellement configuré ».
            'htaccess_oculus'      => null,
            'htaccess_oculus_hash' => null,
            // Code HTTP obtenu lors du dernier test réel de la protection
            // (403 = règle appliquée par le serveur, 200 = écrite mais ignorée).
            'htaccess_verify'      => null,
            // Serveur web : indique si les .htaccess ont un sens ici.
            'server_software'      => (string) ($_SERVER['SERVER_SOFTWARE'] ?? ''),
        ];

        // configuration.php : empreinte + date de dernière modification.
        $config = $base . '/configuration.php';

        if (is_file($config)) {
            $hash  = @md5_file($config);
            $mtime = @filemtime($config);
            $perms = @fileperms($config);
            $result['config_hash']     = $hash !== false ? $hash : null;
            $result['config_modified'] = $mtime ? gmdate('c', $mtime) : null;
            $result['config_mode']     = $perms !== false ? substr(sprintf('%o', $perms), -3) : null;
        }

        // .htaccess : scan du contenu HORS bloc CG Secure.
        $ht = $base . '/.htaccess';

        if (is_file($ht)) {
            $result['htaccess_present'] = true;

            $perms = @fileperms($ht);
            $result['htaccess_mode'] = $perms !== false ? substr(sprintf('%o', $perms), -3) : null;

            $content = (string) @file_get_contents($ht, false, null, 0, 262144);

            // Bloc Oculus présent ? (il est écrit en tête, donc toujours dans la
            // portion lue). L'empreinte porte sur le contenu normalisé, pour ne pas
            // dépendre des fins de ligne.
            if (preg_match(
                '/' . preg_quote(self::HT_BEGIN, '/') . '\R(.*?)' . preg_quote(self::HT_END, '/') . '/s',
                $content,
                $mBlock
            )) {
                $inner = str_replace("\r\n", "\n", $mBlock[1]);

                // La ligne de vérification est ajoutée par Oculus après le test réel :
                // on l'extrait, puis on l'exclut de l'empreinte pour ne comparer que
                // le bloc de règles lui-même à celui configuré sur le central.
                if (preg_match('/^\s*#\s*oculus-verify:\s*(\d{3})/m', $inner, $mVer)) {
                    $result['htaccess_verify'] = (int) $mVer[1];
                }

                $rules = preg_replace('/^\s*#\s*oculus-verify:.*$/m', '', $inner);

                $result['htaccess_oculus']      = true;
                $result['htaccess_oculus_hash'] = md5(trim((string) $rules));
            } else {
                $result['htaccess_oculus'] = false;
            }

            // Retire les blocs gérés par CG Secure (# … CG SECURE … BEGIN … END),
            // version-agnostique, pour ne juger que le reste du fichier.
            $stripped = preg_replace(
                '/#[^\n]*CG SECURE[^\n]*BEGIN.*?#[^\n]*CG SECURE[^\n]*END[^\n]*/is',
                '',
                $content
            );

            if (!\is_string($stripped)) {
                $stripped = $content;
            }

            // Signatures PRÉCISES (directives), pour ne pas confondre avec les
            // règles de pare-feu qui BLOQUENT ces mots-clés (7G/8G, anti-exploit
            // Joomla…). On ne cherche que ce qui INSTALLE réellement une porte
            // dérobée via .htaccess :
            $signatures = [
                // Charge un script PHP à chaque requête (auto_prepend/append_file).
                'php_auto_include' => '/php_(?:admin_)?(?:value|flag)\s+auto_(?:prepend|append)_file/i',
                // Rend une image / un .txt exécutable comme du PHP.
                'exec_non_php'     => '/(?:Add(?:Handler|Type))\s+[^\n]*x-httpd-php[^\n]*\.(?:jpe?g|png|gif|ico|bmp|txt)/i',
                'sethandler_media' => '/SetHandler\s+[^\n]*x-httpd-php[^\n]*\.(?:jpe?g|png|gif|ico|bmp|txt)/i',
            ];

            foreach ($signatures as $label => $pattern) {
                if (preg_match($pattern, $stripped)) {
                    $result['htaccess_suspect'][] = $label;
                }
            }
        }

        return $result;
    }

    /**
     * Inventaire des fichiers .php présents dans les emplacements sensibles :
     * racine (non récursif), puis media/, images/, tmp/ (récursifs).
     * Sert de base à la détection de portes dérobées déposées par un attaquant.
     * Renvoie : chemin relatif => taille en octets.
     */
    /** Extensions de fichiers exécutables par le serveur PHP (toutes casses). */
    private const SCRIPT_EXTENSIONS = ['php', 'phtml', 'pht', 'php7', 'php5', 'php4', 'php3', 'phar', 'phps'];

    /**
     * Fichiers de protection d'un dossier : JAMAIS supprimés, jamais comptés.
     * Les retirer rouvrirait le listing du répertoire et ferait sauter un
     * éventuel blocage posé par l'hébergeur ou un outil de sécurité.
     */
    private const KEEP_FILES = ['index.html', 'index.htm', 'index.php', '.htaccess', 'web.config'];

    /**
     * Volumétrie des dossiers de travail (tmp et caches), pour proposer un
     * nettoyage à distance uniquement quand il y a matière.
     */
    private function getMaintenance(): array
    {
        $base = rtrim(JPATH_ROOT, '/\\');

        $cache  = $this->dirStats($base . '/cache');
        $cacheA = $this->dirStats($base . '/administrator/cache');

        return [
            'tmp'   => $this->dirStats($base . '/tmp'),
            'cache' => [
                'files' => $cache['files'] + $cacheA['files'],
                'bytes' => $cache['bytes'] + $cacheA['bytes'],
            ],
        ];
    }

    /**
     * Compte les fichiers « nettoyables » d'un dossier (hors fichiers de
     * protection), avec leur poids total. Borné pour rester léger.
     *
     * @return array{files:int, bytes:int}
     */
    private function dirStats(string $dir): array
    {
        $out = ['files' => 0, 'bytes' => 0];

        if (!is_dir($dir)) {
            return $out;
        }

        try {
            $it    = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS)
            );
            $guard = 0;

            foreach ($it as $file) {
                if (++$guard > 20000) {
                    break;
                }

                if (!$file->isFile()) {
                    continue;
                }

                if (\in_array(strtolower($file->getFilename()), self::KEEP_FILES, true)) {
                    continue;
                }

                $out['files']++;
                $out['bytes'] += (int) $file->getSize();
            }
        } catch (\Throwable $e) {
            // dossier illisible : on renvoie ce qu'on a
        }

        return $out;
    }

    /**
     * Vide à distance le dossier tmp ou les caches (SUPPRESSION).
     *
     * Garde-fous : périmètre strictement borné à la racine du site, fichiers de
     * protection préservés, et fichiers écrits dans les 15 dernières minutes
     * ignorés (une installation ou un rendu peut être en cours).
     */
    private function handleRemoteClean(): void
    {
        $app = $this->getApplication();

        if (!$this->params->get('allow_updates', 0)) {
            $this->sendJson([
                'status'  => 'error',
                'code'    => 'disabled',
                'message' => 'Actions à distance désactivées sur ce site (config du plugin Oculus Client).',
            ], 403);

            return;
        }

        $allowIps = trim((string) $this->params->get('update_ips', ''));

        if ($allowIps !== '') {
            $ips    = array_filter(array_map('trim', preg_split('/[,;\s]+/', $allowIps)));
            $remote = (string) ($_SERVER['REMOTE_ADDR'] ?? '');

            if (!\in_array($remote, $ips, true)) {
                $this->sendJson(['status' => 'error', 'code' => 'ip', 'message' => 'Adresse IP non autorisée : ' . $remote], 403);

                return;
            }
        }

        $target = $app->getInput()->getCmd('target', 'tmp');

        if (!\in_array($target, ['tmp', 'cache'], true)) {
            $this->sendJson(['status' => 'error', 'code' => 'bad_target', 'message' => 'Cible inconnue.'], 400);

            return;
        }

        $base = rtrim(JPATH_ROOT, '/\\');
        $dirs = $target === 'cache'
            ? [$base . '/cache', $base . '/administrator/cache']
            : [$base . '/tmp'];

        $deleted = 0;
        $bytes   = 0;
        $skipped = 0;

        try {
            @set_time_limit(300);

            foreach ($dirs as $dir) {
                $this->cleanDir($dir, $deleted, $bytes, $skipped);
            }

            $this->auditClean($target, $deleted, $bytes);

            $this->sendJson([
                'status'    => 'ok',
                'target'    => $target,
                'deleted'   => $deleted,
                'bytes'     => $bytes,
                'skipped'   => $skipped,
                'generated' => gmdate('c'),
            ]);
        } catch (\Throwable $e) {
            $this->sendJson(['status' => 'error', 'message' => 'Erreur de nettoyage : ' . $e->getMessage()], 500);
        }
    }

    /** Supprime le contenu nettoyable d'un dossier (le dossier lui-même est conservé). */
    private function cleanDir(string $dir, int &$deleted, int &$bytes, int &$skipped): void
    {
        $real = realpath($dir);
        $root = realpath(JPATH_ROOT);

        // Périmètre : on refuse tout ce qui sortirait de la racine du site.
        if ($real === false || $root === false || strpos($real, $root) !== 0 || !is_dir($real)) {
            return;
        }

        $now   = time();
        $guard = 0;

        try {
            $it = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($real, \FilesystemIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::CHILD_FIRST
            );

            foreach ($it as $item) {
                if (++$guard > 50000) {
                    break;
                }

                if ($item->isDir()) {
                    @rmdir($item->getPathname()); // n'aboutit que si le dossier est vide

                    continue;
                }

                if (\in_array(strtolower($item->getFilename()), self::KEEP_FILES, true)) {
                    continue;
                }

                // Écriture très récente : installation ou rendu probablement en cours.
                if ($now - (int) $item->getMTime() < 900) {
                    $skipped++;

                    continue;
                }

                $size = (int) $item->getSize();

                if (@unlink($item->getPathname())) {
                    $deleted++;
                    $bytes += $size;
                }
            }
        } catch (\Throwable $e) {
            // dossier illisible : on s'arrête là sans casser la réponse
        }
    }

    /** Journalise un nettoyage à distance (audit). */
    private function auditClean(string $target, int $deleted, int $bytes): void
    {
        try {
            \Joomla\CMS\Log\Log::add(
                'Oculus - Nettoyage ' . $target . ' : ' . $deleted . ' fichier(s), ' . $bytes . ' octets liberes.',
                \Joomla\CMS\Log\Log::INFO,
                'oculus'
            );
        } catch (\Throwable $e) {
            // best-effort
        }
    }

    private function getPhpFiles(): array
    {
        $base = rtrim(JPATH_ROOT, '/\\');
        $list = [];

        // 1. Racine : un site sain n'y a comme scripts que index.php et configuration.php.
        //    Tout autre script à la racine est signalé.
        $rootWhitelist = ['index.php', 'configuration.php'];

        foreach (glob($base . '/*.*') ?: [] as $file) {
            if (!is_file($file)) {
                continue;
            }

            if (!\in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), self::SCRIPT_EXTENSIONS, true)) {
                continue;
            }

            $name = basename($file);

            if (!\in_array($name, $rootWhitelist, true)) {
                $list[$name] = (int) @filesize($file);
            }
        }

        // 2a. Dossiers d'upload STRICTS : images/ et tmp/ ne contiennent jamais de
        //     PHP légitime (hors index.php/index.html de protection). Tout script
        //     y est signalé, quel que soit son contenu : un dropper commence
        //     souvent par un fichier d'apparence anodine.
        foreach (['images', 'tmp'] as $dir) {
            $this->scanScripts($base, $dir, $list, false, 500, true);
        }

        // 2b. media/ : les extensions y déposent parfois du PHP légitime
        //     (style.php, class.php...). On y juge sur le CONTENU pour éviter
        //     une avalanche de faux positifs.
        $this->scanScripts($base, 'media', $list, false, 500, false);

        // 3. Dossiers cache : n'y remonter que les scripts ANORMAUX. Un webshell
        //    (ex. d.php) s'y planque parmi des centaines de fichiers légitimes ;
        //    on filtre ces derniers pour ne signaler que les intrus.
        foreach (['cache', 'administrator/cache'] as $dir) {
            $this->scanScripts($base, $dir, $list, true, 200);
        }

        ksort($list);

        return $list;
    }

    /**
     * Parcourt un dossier et ajoute à $list les fichiers-scripts trouvés.
     * Si $filterCache, ignore les fichiers de cache Joomla légitimes.
     */
    private function scanScripts(string $base, string $dir, array &$list, bool $filterCache, int $limit, bool $strict = false): void
    {
        $root = $base . '/' . $dir;

        if (!is_dir($root)) {
            return;
        }

        try {
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS)
            );

            $count = 0;

            foreach ($iterator as $file) {
                if (!$file->isFile()) {
                    continue;
                }

                if (!\in_array(strtolower($file->getExtension()), self::SCRIPT_EXTENSIONS, true)) {
                    continue;
                }

                if (++$count > $limit) {
                    break;
                }

                $relative = substr($file->getPathname(), \strlen($base) + 1);

                if ($filterCache) {
                    // Dossier cache : on ignore les fichiers de cache Joomla connus,
                    // puis on JUGE SUR LE CONTENU (comme ailleurs) — et non plus sur
                    // le simple fait qu'un nom soit inconnu. Les frameworks modernes
                    // (T4/JoomlArt, Gantry, Helix...) y compilent légitimement des
                    // classes nommées (FileLayout.php, Router.php...) : les épingler
                    // par emplacement générait des faux positifs en masse. On garde
                    // toutefois l'alerte sur les extensions exécutables « exotiques »
                    // (.phar/.pht/.PHP...), jamais légitimes dans un cache.
                    if ($this->isLegitCacheFile($file->getFilename())) {
                        continue;
                    }

                    $exoticExt = $file->getExtension() !== 'php';

                    if ($exoticExt || $this->looksMalicious($file->getPathname(), (int) $file->getSize())) {
                        $list[$relative] = (int) $file->getSize();
                    }

                    continue;
                }

                // Dossiers d'upload : un script dans un dossier d'ASSETS (polices,
                // icônes...) peut être anormal. Mais certains fichiers .php légitimes
                // y vivent (style.php, class.php...). On ne signale par EMPLACEMENT que
                // les scripts à extension « exotique » ou en casse trafiquée
                // (.phar, .pht, .PHP, .Php... = techniques d'évasion des webshells) ;
                // un simple « .php » minuscule n'est jugé que sur son CONTENU.
                $isProtection = \in_array(strtolower($file->getFilename()), ['index.php', 'index.html'], true);

                // Mode STRICT (images/, tmp/) : aucun script n'y est légitime,
                // hormis les index.php/index.html de protection. On ne regarde
                // ni l'extension ni le contenu.
                if ($strict) {
                    if (!$isProtection) {
                        $list[$relative] = (int) $file->getSize();
                    }

                    continue;
                }

                $inAssetDir   = (bool) preg_match('#/(fonts|iconfont|css|js|images|webfonts)/#i', $relative);
                $exoticExt    = $file->getExtension() !== 'php';

                if (($inAssetDir && !$isProtection && $exoticExt) || $this->looksMalicious($file->getPathname(), (int) $file->getSize())) {
                    $list[$relative] = (int) $file->getSize();
                }
            }
        } catch (\Throwable $e) {
            // Dossier illisible : on ignore, sans casser la collecte.
        }
    }

    /**
     * Analyse le CONTENU d'un fichier à la recherche de signatures de webshell.
     * Ne lit que le début du fichier (payloads en tête) et se limite aux
     * fichiers de taille raisonnable, pour rester léger.
     */
    private function looksMalicious(string $path, int $size): bool
    {
        if ($size === 0 || $size > 2097152) {
            return false;
        }

        $code = @file_get_contents($path, false, null, 0, 65536);

        if ($code === false || $code === '') {
            return false;
        }

        $signatures = [
            // Exécution de code obfusqué.
            '/eval\s*\(\s*(?:base64_decode|gzinflate|gzuncompress|gzdecode|str_rot13)\s*\(/i',
            // Exécution directe d\'une entrée utilisateur.
            '/(?:eval|assert)\s*\(\s*\$_(?:POST|GET|REQUEST|COOKIE|SERVER)/i',
            '/\b(?:system|exec|shell_exec|passthru|popen|proc_open)\s*\(\s*\$_(?:POST|GET|REQUEST|COOKIE)/i',
            // Variable superglobale utilisée comme fonction : $_POST[x]($_POST[y]).
            '/\$_(?:POST|GET|REQUEST|COOKIE)\s*\[[^\]]*\]\s*\(/',
            // preg_replace avec modificateur /e (exécution de code).
            '/preg_replace\s*\(\s*([\x27\x22]).*?\/[a-z]*e[a-z]*\1/i',
            // Uploader.
            '/move_uploaded_file\s*\(\s*\$_FILES/i',
            // Gros bloc encodé = charge utile cachée.
            '/base64_decode\s*\(\s*[\x27\x22][A-Za-z0-9+\/=]{300,}/',
            '/(?:str_rot13|gzinflate|gzuncompress|gzdecode)\s*\(\s*base64_decode/i',
            // Fonctions anonymes dynamiques classiques des webshells.
            '/\bcreate_function\s*\(/i',
        ];

        foreach ($signatures as $pattern) {
            if (preg_match($pattern, $code)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Vrai si le nom correspond à un fichier de cache Joomla légitime
     * (cache de langue, cache de données, autoload) — donc PAS un intrus.
     */
    private function isLegitCacheFile(string $name): bool
    {
        // Cache de langue : xxx.ini.<timestamp>.php
        if (preg_match('/\\.ini\\.\\d+\\.php$/i', $name)) {
            return true;
        }

        // Cache de données / _media_version : nom commençant par un hash md5.
        if (preg_match('/^[0-9a-f]{32}/i', $name)) {
            return true;
        }

        // Marqueur de cache Joomla, ou fichiers cache connus.
        if (strpos($name, '-cache-') !== false) {
            return true;
        }

        return \in_array($name, ['autoload_psr4.php', 'fatal_error.php'], true);
    }

    /**
     * Dernière sauvegarde Akeeba Backup réussie.
     * Essaie la table moderne (Akeeba 9/10) puis l'ancienne (8 et avant).
     */
    private function getBackup(): array
    {
        $db = $this->getDatabase();

        // Chaque entrée : [table des sauvegardes, composant correspondant].
        foreach ([
            ['#__akeebabackup_backups', 'com_akeebabackup'],
            ['#__ak_stats', 'com_akeeba'],
        ] as $probe) {
            [$table, $component] = $probe;

            try {
                $last = $db->setQuery(
                    $db->getQuery(true)
                        ->select('MAX(' . $db->quoteName('backupstart') . ')')
                        ->from($db->quoteName($table))
                        ->where($db->quoteName('status') . ' = ' . $db->quote('complete'))
                )->loadResult();

                [$edition, $version] = $this->detectAkeebaEdition($component);

                // État « prêt pour la sauvegarde à distance » : Pro + actions
                // autorisées + mot secret Akeeba disponible (lu ou paramétré).
                [$remoteReady, $remoteReason] = $this->backupRemoteReady($component, $edition);

                return [
                    'installed'     => true,
                    'last_backup'   => $last ?: null,
                    'component'     => $component,
                    'edition'       => $edition,   // 'pro' | 'core' | 'unknown'
                    'version'       => $version,
                    'remote_ready'  => $remoteReady,
                    'remote_reason' => $remoteReason,
                ];
            } catch (\Throwable $e) {
                // Table absente : on essaie la suivante.
            }
        }

        return ['installed' => false, 'last_backup' => null];
    }

    /**
     * La sauvegarde à distance est-elle possible sur ce site ?
     * Conditions : Akeeba Pro + actions à distance autorisées + mot secret
     * disponible (paramètre du plugin ou lu dans la config d'Akeeba).
     *
     * @return array{0: bool, 1: string}  [prêt, raison lisible]
     */
    private function backupRemoteReady(string $component, string $edition): array
    {
        if ($edition !== 'pro') {
            return [false, 'Akeeba Core : sauvegarde à distance indisponible (Pro requis).'];
        }

        if (!$this->params->get('allow_updates', 0)) {
            return [false, 'Actions à distance désactivées dans la config du plugin Oculus Client.'];
        }

        $secret = trim((string) $this->params->get('backup_secret', ''));

        if ($secret === '') {
            $cfg    = $this->readAkeebaConfig($component);
            $secret = (string) $cfg['secret'];
        }

        if ($secret === '') {
            return [false, 'Mot secret de sauvegarde front-end Akeeba introuvable (à activer/définir dans Akeeba → Options).'];
        }

        return [true, 'Prêt : sauvegarde à distance opérationnelle.'];
    }

    /**
     * Nom lisible d'une extension : reproduit la logique de l'écran « Gérer »
     * de Joomla (chargement du fichier de langue .sys de l'extension, puis
     * Text::_()). Sans cela, on ne renvoie qu'une clé brute (« COM_CGSECURE »).
     * La traduction se fait dans la langue d'administration du site (souvent FR).
     */
    private function translateExtensionName(object $row): string
    {
        $original = (string) ($row->name ?? '');

        try {
            $lang    = $this->getApplication()->getLanguage();
            $element = (string) ($row->element ?? '');
            $folder  = (string) ($row->folder ?? '');
            $path    = (int) ($row->client_id ?? 0) ? JPATH_ADMINISTRATOR : JPATH_SITE;

            switch ((string) ($row->type ?? '')) {
                case 'component':
                    $lang->load($element . '.sys', $path)
                        || $lang->load($element . '.sys', $path . '/components/' . $element);
                    break;

                case 'file':
                    $lang->load('files_' . $element . '.sys', JPATH_SITE);
                    break;

                case 'library':
                    $lang->load('lib_' . $element . '.sys', $path)
                        || $lang->load('lib_' . $element . '.sys', $path . '/libraries/' . $element);
                    break;

                case 'module':
                    $lang->load($element . '.sys', $path)
                        || $lang->load($element . '.sys', $path . '/modules/' . $element);
                    break;

                case 'plugin':
                    $ext = 'plg_' . $folder . '_' . $element;
                    $lang->load($ext . '.sys', JPATH_ADMINISTRATOR)
                        || $lang->load($ext . '.sys', JPATH_PLUGINS . '/' . $folder . '/' . $element);
                    break;

                case 'template':
                    $lang->load('tpl_' . $element . '.sys', $path)
                        || $lang->load('tpl_' . $element . '.sys', $path . '/templates/' . $element);
                    break;

                default: // package, language...
                    $lang->load($element . '.sys', JPATH_SITE);
                    break;
            }
        } catch (\Throwable $e) {
            return $original;
        }

        $translated = Text::_($original);

        return $translated !== '' ? $translated : $original;
    }

    /**
     * Détecte l'édition d'Akeeba Backup (Pro / Core) et sa version, en lisant
     * le fichier version.php d'Akeeba — la source qu'Akeeba utilise elle-même
     * (constante AKEEBABACKUP_PRO / AKEEBA_PRO). Lecture seule, sans risque.
     *
     * @return array{0: string, 1: ?string}  [edition, version]
     */
    private function detectAkeebaEdition(string $component): array
    {
        $base = JPATH_ADMINISTRATOR . '/components/' . $component;

        $candidates = [
            $base . '/version.php',
            $base . '/src/version.php',
            $base . '/fof/version.php',
        ];

        foreach ($candidates as $file) {
            if (!is_file($file) || !is_readable($file)) {
                continue;
            }

            $src = (string) @file_get_contents($file);

            if ($src === '') {
                continue;
            }

            $edition = 'unknown';

            if (preg_match('/AKEEBA(?:BACKUP)?_PRO[\'"]?\s*(?:,|=)\s*[\'"]?([01])/', $src, $m)) {
                $edition = $m[1] === '1' ? 'pro' : 'core';
            }

            $version = null;

            if (preg_match('/AKEEBA(?:BACKUP)?_VERSION[\'"]?\s*(?:,|=)\s*[\'"]([^\'"]+)/', $src, $m)) {
                $version = $m[1];
            }

            if ($edition !== 'unknown' || $version !== null) {
                return [$edition, $version];
            }
        }

        return ['unknown', null];
    }

    /**
     * Nombre total de comptes utilisateurs (détection de créations en masse).
     */
    private function getUsersTotal(): array
    {
        $db = $this->getDatabase();

        $total = $db->setQuery(
            $db->getQuery(true)
                ->select('COUNT(*)')
                ->from($db->quoteName('#__users'))
        )->loadResult();

        return ['total' => (int) $total];
    }

    /**
     * Tâches planifiées (com_scheduler, Joomla 4.1+).
     */
    private function getScheduledTasks(): array
    {
        $db    = $this->getDatabase();
        $query = $db->getQuery(true)
            ->select($db->quoteName([
                'id', 'title', 'type', 'state', 'execution_rules',
                'last_execution', 'next_execution', 'last_exit_code',
                'times_executed', 'times_failed',
            ]))
            ->from($db->quoteName('#__scheduler_tasks'))
            ->order($db->quoteName('id'));

        $rows = $db->setQuery($query)->loadObjectList();
        $list = [];

        foreach ($rows as $row) {
            $list[] = [
                'id'              => (int) $row->id,
                'title'           => $row->title,
                'type'            => $row->type,
                'enabled'         => ((int) $row->state) === 1,
                'execution_rules' => json_decode((string) $row->execution_rules, true),
                'last_execution'  => $row->last_execution,
                'next_execution'  => $row->next_execution,
                'last_exit_code'  => $row->last_exit_code === null ? null : (int) $row->last_exit_code,
                'times_executed'  => (int) $row->times_executed,
                'times_failed'    => (int) $row->times_failed,
            ];
        }

        return $list;
    }

    /**
     * Dernières entrées du journal d'actions (com_actionlogs).
     */
    private function getActionLogs(): array
    {
        $db    = $this->getDatabase();
        $query = $db->getQuery(true)
            ->select([
                $db->quoteName('a.id', 'id'),
                $db->quoteName('a.message_language_key', 'message_language_key'),
                $db->quoteName('a.message', 'message'),
                $db->quoteName('a.log_date', 'log_date'),
                $db->quoteName('a.extension', 'extension'),
                $db->quoteName('u.username', 'username'),
            ])
            ->from($db->quoteName('#__action_logs', 'a'))
            ->join(
                'LEFT',
                $db->quoteName('#__users', 'u')
                . ' ON ' . $db->quoteName('u.id') . ' = ' . $db->quoteName('a.user_id')
            )
            ->order($db->quoteName('a.id') . ' DESC')
            ->setLimit(20);

        $rows = $db->setQuery($query)->loadObjectList();
        $list = [];

        foreach ($rows as $row) {
            $list[] = [
                'id'          => (int) $row->id,
                'key'         => $row->message_language_key,
                'details'     => json_decode((string) $row->message, true),
                'date'        => $row->log_date,
                'extension'   => $row->extension,
                'username'    => $row->username,
            ];
        }

        return $list;
    }

    // ------------------------------------------------------------------
    // Sortie
    // ------------------------------------------------------------------

    /**
     * Envoie la réponse JSON directement et ferme l'application,
     * pour un format stable quelles que soient les versions de Joomla.
     */
    private function sendJson(array $data, int $status = 200): void
    {
        if ($status !== 200) {
            http_response_code($status);
        }

        header('Content-Type: application/json; charset=utf-8');
        header('X-Robots-Tag: noindex, nofollow');
        // Interdit toute mise en cache serveur (LiteSpeed/N0C) ou intermédiaire :
        // une réponse en cache rendrait le site « invalide » aux yeux d'Oculus.
        header('X-LiteSpeed-Cache-Control: no-cache');
        header('Cache-Control: no-store, no-cache, must-revalidate');

        echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        $this->getApplication()->close();
    }
}
