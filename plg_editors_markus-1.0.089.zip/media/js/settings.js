/**
 * Markus Editor: the settings of a block, behind its gear.
 *
 * They open in the charter's side panel, as Opus does: the article stays in
 * view and every change shows at once. One undo step covers the whole
 * session (Ctrl+Z after closing the panel).
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

import { t, escape } from 'plg_editors_markus.i18n';
import { iconSvg, cleanSvg } from 'plg_editors_markus.icons';
import { COL, TEXT_TYPES, calloutLines, emptyColumns, kept, moduleId } from 'plg_editors_markus.blocks';
import { openPanel, switcher, wireOwnIcons, boxForm, wireHues, bulletsForm, buttonsForm, calloutForm, imageForm, imageActions, tableForm, columnsForm, codeForm, listForm, quoteForm, TABLE_COLOURS } from 'plg_editors_markus.dialogs';

const bodyOf = (block) => block.querySelector(':scope > .mk-body');

function dropEmptyClass(...nodes) {
  nodes.forEach((n) => {
    if (n.hasAttribute('class') && !n.classList.length) {
      n.removeAttribute('class');
    }
  });
}

/* IMAGE ---------------------------------------------------------------- */

/** The classes the image settings manage; any other class of the image is kept. */
const COLOURS = ['primary', 'secondary', 'success', 'danger', 'warning', 'info', 'dark', 'light'];
const MANAGED = ['float-start', 'float-end', 'mx-auto', 'd-block', 'img-fluid', 'w-25', 'w-50', 'w-75', 'w-100',
  'rounded', 'rounded-4', 'rounded-circle', 'border', 'border-0', 'border-3', 'img-thumbnail', 'shadow', 'shadow-sm', 'shadow-lg',
  ...COLOURS.map((c) => `border-${c}`)];

/** The pieces of an image block: its container, the optional link, the image. */
function imageParts(block) {
  const body = bodyOf(block);
  const img = body.tagName === 'IMG' ? body : body.querySelector('img');
  const link = img.parentElement && img.parentElement.tagName === 'A' ? img.parentElement : null;
  const zoomer = img.parentElement && img.parentElement.tagName === 'BUTTON' ? img.parentElement : null;

  return { body, img, link, zoomer, pop: body.querySelector(':scope > [popover]'), figure: body.tagName === 'FIGURE' ? body : null };
}

/*
 * THE IMAGE SHOWN LARGER ON A CLICK (Cyrille: "dans Markus"), with no script
 * and no style sheet on the site: HTML's own `popover`. The image sits in a
 * button that opens a copy of it, as large as the window allows, over a veil;
 * Escape, a click beside it or its close button shut it. Every browser of
 * today knows it; the template has nothing to load.
 */
function zoomPopover(img, id) {
  const pop = document.createElement('div');
  const big = img.cloneNode(false);

  pop.id = id;
  pop.setAttribute('popover', '');
  // Written in the style: every template draws it the same, Bootstrap's utilities or not (Corpus has few).
  pop.setAttribute('style', 'padding:0;border:0;background:none;max-width:95vw;max-height:95vh;overflow:visible;'
    + 'box-shadow:0 0 0 100vmax color-mix(in srgb, CanvasText 70%, transparent)');
  ['width', 'height', 'loading', 'class', 'style', 'contenteditable', 'draggable'].forEach((a) => big.removeAttribute(a));
  big.setAttribute('style', 'display:block;max-width:95vw;max-height:95vh;width:auto;height:auto');
  pop.append(big);
  pop.insertAdjacentHTML('beforeend', `<button type="button" class="btn btn-light btn-sm" style="position:absolute;top:.5rem;right:.5rem" popovertarget="${id}"`
    + ` popovertargetaction="hide" aria-label="${escape(t('ZOOM_CLOSE'))}">\u00d7</button>`);

  return pop;
}

function readImage(block) {
  const { img, link, zoomer, figure } = imageParts(block);
  const has = (c) => img.classList.contains(c);
  const pick = (list) => list.find(has) || '';

  return {
    alt: img.getAttribute('alt') || '',
    decorative: img.getAttribute('alt') === '',
    caption: !!(figure && figure.querySelector('figcaption')),
    href: link ? link.getAttribute('href') : '',
    zoom: !!zoomer,
    blank: !!(link && link.target === '_blank'),
    width: img.getAttribute('width') || '',
    height: img.getAttribute('height') || '',
    fit: pick(['img-fluid', 'w-25', 'w-50', 'w-75', 'w-100']),
    align: ['float-start', 'float-end'].find((c) => has(c) || (figure && figure.classList.contains(c)))
      || (has('mx-auto') ? 'mx-auto d-block' : ''),
    rounded: pick(['rounded-circle', 'rounded-4', 'rounded']),
    border: has('border-0') ? 'border-0' : has('img-thumbnail') ? 'img-thumbnail' : (has('border-3') ? 'border border-3' : (has('border') ? 'border' : '')),
    borderColour: COLOURS.find((c) => has(`border-${c}`)) || '',
    shadow: pick(['shadow-sm', 'shadow-lg', 'shadow']),
    lazy: img.getAttribute('loading') === 'lazy',
  };
}

function applyImage(m, block, v) {
  const { body, img, link, figure } = imageParts(block);
  let { zoomer, pop } = imageParts(block);
  const zoom = !!v.zoom && !v.href.trim();

  // A link and the larger view do not go together: the link wins.
  if (zoomer && !zoom) {
    zoomer.replaceWith(img);
    zoomer = null;
  }

  img.setAttribute('alt', v.decorative ? '' : v.alt.trim());

  ['width', 'height'].forEach((a) => {
    if (/^\d+$/.test(String(v[a]).trim())) {
      img.setAttribute(a, String(v[a]).trim());
    } else {
      img.removeAttribute(a);
    }
  });

  if (v.lazy) {
    img.setAttribute('loading', 'lazy');
  } else {
    img.removeAttribute('loading');
  }

  // The look: Bootstrap classes only, drawn by the site's template.
  img.classList.remove(...MANAGED);

  const classes = [v.fit, v.align === 'mx-auto d-block' ? v.align : '', v.rounded, v.border,
    v.border && v.borderColour && !['img-thumbnail', 'border-0'].includes(v.border) ? `border-${v.borderColour}` : '', v.shadow];

  classes.join(' ').split(' ').filter(Boolean).forEach((c) => img.classList.add(c));

  // The link around the image. A new tab is said to screen readers, as for a text link.
  let anchor = link;
  const href = v.href.trim();

  if (href && !anchor) {
    anchor = document.createElement('a');
    img.replaceWith(anchor);
    anchor.appendChild(img);
  } else if (!href && anchor) {
    anchor.replaceWith(img);
    anchor = null;
  }

  if (anchor) {
    anchor.setAttribute('href', href);
    anchor.querySelectorAll('.visually-hidden').forEach((n) => n.remove());

    if (v.blank) {
      anchor.target = '_blank';
      anchor.rel = 'noopener noreferrer';
      anchor.insertAdjacentHTML('beforeend', `<span class="visually-hidden"> ${escape(t('NEW_WINDOW'))}</span>`);
    } else {
      anchor.removeAttribute('target');
      anchor.removeAttribute('rel');
    }
  }

  if (zoom && !zoomer) {
    zoomer = document.createElement('button');
    zoomer.type = 'button';
    zoomer.setAttribute('style', 'padding:0;border:0;background:none;cursor:zoom-in');
    img.replaceWith(zoomer);
    zoomer.append(img);
    zoomer.insertAdjacentHTML('beforeend', `<span class="visually-hidden"> ${escape(t('ZOOM_OPEN'))}</span>`);
  }

  // A caption or the larger view need a <figure>; without them, the image sits in a <p>, as TinyMCE puts it.
  const piece = anchor || zoomer || img;
  const needFigure = v.caption || zoom;
  let el = body;
  let fresh = false;

  if (needFigure && !figure) {
    el = document.createElement('figure');
    el.append(piece);
  } else if (!needFigure && body.tagName !== 'P') {
    el = document.createElement('p');
    el.append(piece);
  }

  if (el.tagName === 'FIGURE') {
    const caption = el.querySelector(':scope > figcaption');

    if (v.caption && !caption) {
      piece.after(document.createElement('figcaption'));
      fresh = true;
    } else if (!v.caption && caption) {
      caption.remove();
    }

    // The larger copy, made again: it follows the image (its address, its words).
    const id = (pop && pop.id) || `zoom-${Math.random().toString(36).slice(2, 8)}`;

    if (pop) {
      pop.remove();
    }

    pop = null;

    if (zoom) {
      zoomer.setAttribute('popovertarget', id);
      el.append(zoomPopover(img, id));
    }
  }

  // A figure floats as a whole; an image in a paragraph carries the class itself.
  el.classList.remove('float-start', 'float-end');

  if (v.align === 'float-start' || v.align === 'float-end') {
    (el.tagName === 'FIGURE' ? el : img).classList.add(v.align);
  }

  dropEmptyClass(el, img);
  el.classList.add('mk-body');

  if (el !== body || fresh) {
    m.makeEditable('image', el, m.typeName('image'));
  }

  if (el !== body) {
    body.replaceWith(el);
  }

  m.changed();
}

function image(m, block) {
  const { img } = imageParts(block);

  return ({
    title: t('IMAGE_SETTINGS'),
    body: imageForm(readImage(block)),
    actions: imageActions(),
    ready: (form, panel) => {
      const alt = form.querySelector('[name="alt"]');
      const deco = form.querySelector('[name="decorative"]');
      const width = form.querySelector('[name="width"]');
      const height = form.querySelector('[name="height"]');
      const ratio = form.querySelector('[name="ratio"]');
      const proportion = (img.naturalWidth && img.naturalHeight) ? img.naturalWidth / img.naturalHeight
        : (Number(width.value) && Number(height.value) ? Number(width.value) / Number(height.value) : 0);
      const sync = () => { alt.disabled = deco.checked; };

      // Width and height keep the image's proportions, unless asked otherwise.
      width.addEventListener('input', () => {
        if (ratio.checked && proportion && Number(width.value)) {
          height.value = Math.round(Number(width.value) / proportion);
        }
      });
      height.addEventListener('input', () => {
        if (ratio.checked && proportion && Number(height.value)) {
          width.value = Math.round(Number(height.value) * proportion);
        }
      });
      deco.addEventListener('change', sync);
      sync();
      form.querySelector('[data-mk-replace]').addEventListener('click', () => {
        panel.fermer();
        m.runXtd(m.imageButton(), { block, replace: true });
      });
    },
    apply: (v) => applyImage(m, block, v),
    cancel: () => m.undo(),
    place: m.sideColumn(),
  });
}

/* TABLE ---------------------------------------------------------------- */

/** Header row in <thead> with scope="col"; header column with <th scope="row">. */
function tableHeads(table, row, col) {
  const swap = (cell, tag, scope) => {
    if (cell.tagName.toLowerCase() === tag && (!scope || cell.getAttribute('scope') === scope)) {
      return;
    }

    const n = document.createElement(tag);

    [...cell.attributes].forEach((a) => n.setAttribute(a.name, a.value));
    n.removeAttribute('scope');

    if (scope) {
      n.setAttribute('scope', scope);
    }

    n.append(...cell.childNodes);
    cell.replaceWith(n);
  };

  if (row && !table.tHead && table.tBodies[0] && table.tBodies[0].rows[0]) {
    const first = table.tBodies[0].rows[0];

    table.createTHead().appendChild(first);
    [...first.cells].forEach((c) => swap(c, 'th', 'col'));
  } else if (!row && table.tHead) {
    const tbody = table.tBodies[0] || table.createTBody();

    [...table.tHead.rows].reverse().forEach((r) => {
      [...r.cells].forEach((c) => swap(c, 'td'));
      tbody.prepend(r);
    });
    table.tHead.remove();
  }

  [...table.tBodies].forEach((tb) => [...tb.rows].forEach((r) => {
    if (r.cells[0]) {
      swap(r.cells[0], col ? 'th' : 'td', col ? 'row' : '');
    }
  }));
}

/** The colour of a `prefix-*` class on an element, or "". */
function colourOf(el, prefix, colours) {
  return (el && colours.find((c) => el.classList.contains(`${prefix}-${c}`))) || '';
}

/** The table of a block and its Bootstrap wrapper (`table-responsive`), when it has one. */
function tableParts(block) {
  const body = bodyOf(block);
  const table = body.tagName === 'TABLE' ? body : body.querySelector('table');

  return { body, table, wrap: body.tagName === 'TABLE' ? null : body };
}

/*
 * THE WIDTHS OF THE COLUMNS (Cyrille: "the columns are not the same size"):
 * by the text (the browser's way, nothing written), equal, or chosen, in
 * percent of the table. Written in a <colgroup>, HTML's own place for it;
 * no column, no <colgroup>.
 */
const columnCount = (table) => Math.max(0, ...[...table.rows].map((r) => r.cells.length));

function readWidths(table) {
  const cols = [...table.querySelectorAll(':scope > colgroup > col')];
  const widths = cols.map((c) => parseFloat(c.style.width) || '');
  const n = columnCount(table);
  const first = table.rows[0] ? [...table.rows[0].cells] : [];
  const colNames = Array.from({ length: n }, (_, i) => (first[i] && first[i].tagName === 'TH' && first[i].textContent.trim()) || t('TABLE_COLUMN_N', i + 1));
  let colMode = 'auto';

  if (cols.length) {
    colMode = cols.length === n && widths.every((w) => w && Math.abs(w - 100 / n) < .1) ? 'equal' : 'custom';
  }

  return { colMode, widths, colNames };
}

/** Writes the widths: none, equal, or the ones chosen (`w0`, `w1`...). */
function writeWidths(table, mode, v = {}) {
  let group = table.querySelector(':scope > colgroup');
  const n = columnCount(table);

  if (mode === 'auto' || !n) {
    if (group) {
      group.remove();
    }

    return;
  }

  if (!group) {
    group = document.createElement('colgroup');

    // After the caption, before the rows: the order HTML asks for.
    if (table.caption) {
      table.caption.after(group);
    } else {
      table.prepend(group);
    }
  }

  group.replaceChildren(...Array.from({ length: n }, (_, i) => {
    const col = document.createElement('col');
    const w = mode === 'equal' ? Math.round(10000 / n) / 100 : parseFloat(v[`w${i}`]);

    if (w > 0) {
      col.style.width = `${w}%`;
    }

    return col;
  }));
}

/*
 * THE FOOT OF A TABLE (a line of totals): HTML's <tfoot>, read by screen
 * readers as such and repeated by browsers on each printed page. Turned on,
 * the last line of the body goes down into it (a new line when the body has
 * only one); turned off, its lines go back to the end of the body.
 */
function tableFoot(table, on) {
  const tbody = table.tBodies[0] || table.createTBody();

  if (on && !table.tFoot) {
    const foot = table.createTFoot();

    if (tbody.rows.length > 1) {
      foot.appendChild(tbody.rows[tbody.rows.length - 1]);
    } else {
      const row = foot.insertRow();

      for (let i = 0; i < columnCount(table); i += 1) {
        row.insertCell();
      }
    }
  } else if (!on && table.tFoot) {
    tbody.append(...table.tFoot.rows);
    table.tFoot.remove();
  }
}

function readTable(block) {
  const { table, wrap } = tableParts(block);
  const has = (c) => table.classList.contains(c);
  const framed = !!wrap && wrap.classList.contains('border');
  const round = !!wrap && wrap.classList.contains('rounded-3');

  return {
    caption: table.caption ? table.caption.textContent : '',
    headRow: !!table.tHead,
    headCol: !!table.querySelector('tbody th[scope="row"]'),
    footRow: !!table.tFoot,
    border: has('table-borderless') ? 'none' : (has('table-bordered') ? 'grid' : (framed && !round ? 'frame' : 'lines')),
    borderColour: colourOf(table, 'border', TABLE_COLOURS) || colourOf(wrap, 'border', TABLE_COLOURS),
    shape: round ? 'round' : 'square',
    headBack: colourOf(table.tHead, 'table', [...TABLE_COLOURS, 'dark']),
    back: colourOf(table, 'table', TABLE_COLOURS),
    striped: has('table-striped'),
    hover: has('table-hover'),
    small: has('table-sm'),
    ...readWidths(table),
  };
}

function applyTable(m, block, v) {
  let { body, table, wrap } = tableParts(block);
  const framed = v.border === 'frame' || v.shape === 'round';

  // A frame or round corners are drawn by the wrapper: the table gets one when it needs it.
  if (framed && !wrap) {
    wrap = document.createElement('div');
    wrap.className = 'table-responsive';
    body.replaceWith(wrap);
    wrap.appendChild(table);
    table.classList.remove('mk-body');
    wrap.classList.add('mk-body');
    body = wrap;
  }

  table.classList.add('table');
  table.classList.remove('table-borderless', 'table-bordered', 'table-striped', 'table-hover', 'table-sm',
    ...TABLE_COLOURS.map((c) => `border-${c}`), ...TABLE_COLOURS.map((c) => `table-${c}`));
  [[v.border === 'none', 'table-borderless'], [v.border === 'grid', 'table-bordered'], [v.striped, 'table-striped'],
    [v.hover, 'table-hover'], [v.small, 'table-sm']].forEach(([on, c]) => { if (on) { table.classList.add(c); } });

  if (v.back) {
    table.classList.add(`table-${v.back}`);
  }

  if (v.borderColour && v.border !== 'none') {
    table.classList.add(`border-${v.borderColour}`);
  }

  if (wrap) {
    wrap.classList.remove('border', 'rounded-3', ...TABLE_COLOURS.map((c) => `border-${c}`));

    if (framed) {
      wrap.classList.add('border');

      if (v.borderColour) {
        wrap.classList.add(`border-${v.borderColour}`);
      }
    }

    if (v.shape === 'round') {
      wrap.classList.add('rounded-3');
    }

    // In a frame, the table's own bottom margin would leave a gap inside it.
    table.classList.toggle('mb-0', framed);
  }

  if (v.caption.trim()) {
    (table.caption || table.createCaption()).textContent = v.caption.trim();
  } else if (table.caption) {
    table.caption.remove();
  }

  // Bootstrap writes a caption under the table; a title is read before the table: Bootstrap's `caption-top`.
  table.classList.toggle('caption-top', !!table.caption);
  writeWidths(table, v.colMode, v);

  tableHeads(table, v.headRow, v.headCol);
  tableFoot(table, v.footRow);

  if (table.tHead) {
    table.tHead.classList.remove(...[...TABLE_COLOURS, 'dark'].map((c) => `table-${c}`));

    if (v.headBack) {
      table.tHead.classList.add(`table-${v.headBack}`);
    }
  }

  dropEmptyClass(table, ...(table.tHead ? [table.tHead] : []), ...(wrap ? [wrap] : []));
  m.makeEditable('table', body, m.typeName('table'));
  m.changed();
}

/** Rows and columns, added at the end or removed at the cell of the cursor. */
function tableCells(m, block, op, cell) {
  const { body, table } = tableParts(block);
  const rows = [...table.rows];
  const widths = readWidths(table);
  const gone = op === '-col' && cell ? cell.cellIndex : -1;

  if (op === 'row') {
    m.tableRow(block, true, false);

    return '';
  }

  if (op === 'col') {
    rows.forEach((r) => {
      const head = r.parentNode.tagName === 'THEAD';
      const c = document.createElement(head ? 'th' : 'td');

      if (head) {
        c.setAttribute('scope', 'col');
      }

      r.appendChild(c);
    });
  } else if (!cell || !table.contains(cell)) {
    return 'TABLE_PLACE';
  } else if (op === '-row') {
    if (table.tBodies[0] && table.tBodies[0].rows.length === 1 && cell.parentNode.parentNode.tagName === 'TBODY') {
      return 'TABLE_LAST_ROW';
    }

    cell.parentNode.remove();
  } else {
    if (cell.parentNode.cells.length === 1) {
      return 'TABLE_LAST_COL';
    }

    const i = cell.cellIndex;

    rows.forEach((r) => { if (r.cells[i]) { r.cells[i].remove(); } });
  }

  // A column more or less: equal widths stay equal; chosen ones keep theirs, a new column takes the rest.
  if (widths.colMode !== 'auto') {
    const kept = widths.widths.filter((w, i) => i !== gone);

    writeWidths(table, widths.colMode, Object.fromEntries(kept.map((w, i) => [`w${i}`, w])));
  }

  m.makeEditable('table', body, m.typeName('table'));
  m.changed();

  return '';
}

/** The cell of the last caret in the text (the panel keeps it while open), or null. */
function caretCell(m) {
  const at = m.range && m.range.startContainer;

  return at && at.isConnected ? (at.nodeType === Node.ELEMENT_NODE ? at : at.parentNode).closest('td, th') : null;
}

const H_PLACES = ['text-start', 'text-center', 'text-end'];
const V_PLACES = ['align-top', 'align-middle', 'align-bottom'];

/**
 * The place of the text in cells: across (Bootstrap `text-*`) or down
 * (`align-*`), for the cell of the caret, its column, its row or every cell.
 * Left and top are the site's own: no class at all.
 */
function placeText(m, block, scope, value, cell) {
  const { table } = tableParts(block);
  const cells = [...table.querySelectorAll('th, td')];
  let targets = cells;

  if (scope !== 'table') {
    if (!cell || !table.contains(cell) || cell.tagName === 'CAPTION') {
      return 'TABLE_PLACE';
    }

    targets = { cell: [cell], row: [...cell.parentNode.cells], col: cells.filter((c) => c.cellIndex === cell.cellIndex) }[scope];
  }

  const family = H_PLACES.includes(value) ? H_PLACES : V_PLACES;

  targets.forEach((c) => {
    c.classList.remove(...family);

    if (value !== 'text-start' && value !== 'align-top') {
      c.classList.add(value);
    }

    dropEmptyClass(c);
  });
  m.changed();

  return 'TABLE_PLACED';
}

function table(m, block) {
  return ({
    title: t('TABLE_SETTINGS'),
    body: tableForm(readTable(block)),
    ready: (form) => {
      switcher(form, 'colMode');
      form.querySelectorAll('[data-mk-op]').forEach((b) => b.addEventListener('click', () => {
        const said = tableCells(m, block, b.dataset.mkOp, caretCell(m));

        m.say(t(said || `TABLE_DONE_${b.dataset.mkOp.replace('-', 'DEL_').toUpperCase()}`));
      }));
      form.querySelectorAll('[data-mk-place]').forEach((b) => b.addEventListener('click', () => {
        const scope = form.querySelector('[name="placeScope"]:checked').value;

        m.say(t(placeText(m, block, scope, b.dataset.mkPlace, caretCell(m))));
      }));
    },
    apply: (v) => applyTable(m, block, v),
    cancel: () => m.undo(),
    place: m.sideColumn(),
  });
}

/* COLUMNS -------------------------------------------------------------- */

function readColumns(block) {
  const row = bodyOf(block);
  const widths = [...row.querySelectorAll(':scope > .mk-column')]
    .map((c) => [...c.classList].map((k) => COL.exec(k)).find(Boolean)).filter(Boolean);
  const valign = ['center', 'end'].find((v) => row.classList.contains(`align-items-${v}`)) || '';

  return { layout: widths.map((w) => w[2]).join('-'), stack: (widths[0] && widths[0][1]) || 'md', valign };
}

function columns(m, block) {
  const body = bodyOf(block);

  return ({
    title: t('COLUMNS_SETTINGS'),
    body: columnsForm(readColumns(block)),
    apply: (v) => {
      const cols = [...body.querySelectorAll(':scope > .mk-column')];
      const parts = v.layout.split('-');

      // Fewer columns: the blocks of the removed ones move to the last kept column.
      while (cols.length > parts.length) {
        const gone = cols.pop();

        cols[cols.length - 1].querySelector(':scope > .mk-add--column').before(...m.blocksIn(gone));
        gone.remove();
      }

      while (cols.length < parts.length) {
        const col = emptyColumns([parts[cols.length]]).firstElementChild;

        body.appendChild(col);
        m.makeColumn(col);
        cols.push(col);
      }

      cols.forEach((col, i) => {
        [...col.classList].filter((k) => COL.test(k)).forEach((k) => col.classList.remove(k));
        col.classList.add(`col-${v.stack}-${parts[i]}`);
      });

      // The columns' own height, top, middle or bottom of the row: Bootstrap's `align-items-*`.
      body.classList.remove('align-items-center', 'align-items-end');

      if (v.valign) {
        body.classList.add(`align-items-${v.valign}`);
      }

      m.nameColumns(body);
      m.changed();
    },
    cancel: () => m.undo(),
    place: m.sideColumn(),
  });
}

/* CALLOUT ---------------------------------------------------------------- */

/*
 * Corpus's alert zones and panel (html/tinymce of Corpus). The pictogram of a
 * message is NOT written: Corpus paints the one of its nature itself
 * (`.message:not(:has(svg))::before`), as in its own models. An `svg` an
 * author put there is kept.
 */
const NATURES = ['info', 'succes', 'alerte', 'erreur'];
// A Bootstrap alert written before: its nature.
const FROM_ALERT = { success: 'succes', warning: 'alerte', danger: 'erreur' };


function readCallout(block) {
  const body = bodyOf(block);
  const lines = calloutLines(body);
  const first = lines.firstElementChild;
  const c = body.classList;
  const nature = NATURES.find((n) => c.contains(`message--${n}`))
    || FROM_ALERT[(['success', 'warning', 'danger'].find((x) => c.contains(`alert-${x}`)))] || 'info';
  const panel = body.tagName === 'ASIDE' || c.contains('card');
  const found = panel ? headingIcon(first) : null;
  const named = found && found.svg.getAttribute('data-icon');

  return {
    kind: panel ? 'panel' : 'message',
    nature,
    level: first && /^H[2-4]$/.test(first.tagName) ? first.tagName[1] : '2',
    titled: !!(first && (first.classList.contains('message__titre') || /^H[2-6]$/.test(first.tagName))),
    align: ['center', 'end'].find((a) => c.contains(`text-${a}`)) || '',
    icon: found ? (named && iconSvg(named) ? named : 'own') : '',
    svg: found && !(named && iconSvg(named)) ? found.svg.outerHTML : '',
    iconAt: found ? found.at : '',
  };
}

/*
 * The pictogram of a panel lives in its heading, so that it follows the
 * heading's alignment: before or after the words ('', 'right'), or on a line
 * of its own, a <br> away, above or under them.
 */
function headingIcon(head) {
  if (!head || !/^H[2-6]$/.test(head.tagName)) {
    return null;
  }

  const nodes = [...head.childNodes].filter((n) => !(n.nodeType === Node.TEXT_NODE && !n.textContent.trim()));
  const isSvg = (n) => !!n && n.nodeName.toLowerCase() === 'svg';
  const isBr = (n) => !!n && n.nodeName === 'BR';
  const first = nodes[0];
  const last = nodes[nodes.length - 1];

  if (isSvg(first)) {
    return { svg: first, br: isBr(nodes[1]) ? nodes[1] : null, at: isBr(nodes[1]) ? 'above' : '' };
  }

  if (isSvg(last)) {
    const br = isBr(nodes[nodes.length - 2]) ? nodes[nodes.length - 2] : null;

    return { svg: last, br, at: br ? 'under' : 'right' };
  }

  return null;
}

/** Puts the chosen pictogram in the heading of a panel. */
function putHeadingIcon(head, v) {
  const drawn = v.icon === 'own' ? cleanSvg(v.svg) : iconSvg(v.icon);

  if (!drawn) {
    return;
  }

  const holder = document.createElement('span');

  holder.innerHTML = drawn;

  const svg = holder.firstElementChild;
  const apart = v.iconAt === 'above' || v.iconAt === 'under';

  // Beside the words: the size of the letters. On a line of its own: twice as big.
  svg.setAttribute('width', apart ? '2em' : '1em');
  svg.setAttribute('height', apart ? '2em' : '1em');
  svg.setAttribute('contenteditable', 'false');

  if (!apart) {
    svg.setAttribute('style', 'vertical-align:-0.125em');
  }

  if (v.iconAt === 'above') {
    head.prepend(svg, document.createElement('br'));
  } else if (v.iconAt === 'under') {
    head.append(document.createElement('br'), svg);
  } else if (v.iconAt === 'right') {
    head.append(' ', svg);
  } else {
    head.prepend(svg, ' ');
  }
}

/** Rebuilds the stored element of a callout in place: the block stays, its lines are kept. */
function applyCallout(m, block, v, before) {
  const old = bodyOf(block);
  const lines = calloutLines(old);
  const first = lines.firstElementChild;
  const hadTitle = !!(first && (first.classList.contains('message__titre') || /^H[2-6]$/.test(first.tagName)));
  // The words of the title, without the pictogram of a panel (put again below).
  const words = hadTitle ? first.cloneNode(true) : null;
  const found = words ? headingIcon(words) : null;

  if (found) {
    found.svg.remove();

    if (found.br) {
      found.br.remove();
    }
  }

  let title = words ? words.innerHTML.trim() : '';
  const rest = [...lines.childNodes].filter((n) => !(hadTitle && n === first));
  const titleWords = words ? words.textContent.trim() : '';

  // The title said the old nature in its words: it says the new one.
  if (!title || titleWords === t(`CALLOUT_${before.nature.toUpperCase()}`)) {
    title = escape(t(`CALLOUT_${v.kind === 'panel' ? 'PANEL_TITLE' : v.nature.toUpperCase()}`));
  }

  let el;
  let box;

  if (v.kind === 'panel') {
    el = document.createElement('aside');
    el.className = 'panneau__boite';
    box = el;
  } else {
    el = document.createElement('div');
    el.className = `message rule message--${v.nature}`;
    el.setAttribute('role', 'note');

    const icon = old.querySelector(':scope > svg');

    if (icon) {
      el.appendChild(icon);
    }

    box = el.appendChild(document.createElement('div'));
  }

  // The classes and style of the knife go with the element.
  [...old.classList].filter((c) => !/^(mk-|message|rule$|panneau__|alert|card|text-(start|center|end)$)/.test(c)).forEach((c) => el.classList.add(c));

  if (v.align) {
    el.classList.add(`text-${v.align}`);
  }

  if (old.getAttribute('style')) {
    el.setAttribute('style', old.getAttribute('style'));
  }

  if (v.titled) {
    const head = document.createElement(v.kind === 'panel' ? `h${v.level || 2}` : 'p');

    if (v.kind !== 'panel') {
      head.className = 'message__titre';
    }

    head.innerHTML = title;

    if (v.kind === 'panel') {
      putHeadingIcon(head, v);
    }

    box.appendChild(head);
  }

  box.append(...rest);

  if (!box.querySelector(':scope > :not(.message__titre, h2, h3, h4, h5, h6)')) {
    box.appendChild(document.createElement('p')).appendChild(document.createElement('br'));
  }

  el.classList.add('mk-body');
  old.replaceWith(el);
  m.makeEditable('callout', el, m.typeName('callout'));
  m.changed();
}

function callout(m, block) {
  let before = readCallout(block);

  return ({
    title: t('CALLOUT_SETTINGS'),
    body: calloutForm(before),
    ready: (form) => {
      switcher(form, 'kind');
      wireOwnIcons(form);
    },
    apply: (v) => {
      applyCallout(m, block, v, before);
      before = { ...before, ...v };
    },
    cancel: () => m.undo(),
    place: m.sideColumn(),
  });
}

/* BUTTONS ---------------------------------------------------------------- */

const BTN_STYLE = /^btn-(outline-)?(primary|secondary|success|danger|warning|info|light|dark|link)$/;
const PLACES = { center: 'justify-content-center', end: 'justify-content-end' };
/*
 * Buttons are written with Bootstrap's classes only: every Bootstrap template
 * draws them. Corpus's own classes (`bouton`, written by Markus 1.0.048 and
 * 1.0.049, or by hand) are read as their Bootstrap match and rewritten so.
 */
const BUTTON_LINKS = ':scope > a.btn, :scope > a.bouton';

function lookOf(a) {
  const c = a.classList;
  const hit = [...c].map((x) => BTN_STYLE.exec(x)).find(Boolean);

  if (hit) {
    return { style: hit[2], outline: !!hit[1] };
  }

  if (c.contains('bouton--tertiaire')) {
    return { style: 'link', outline: false };
  }

  return { style: c.contains('bouton--second') ? 'secondary' : 'primary', outline: false };
}

function readButtons(block, m) {
  const body = bodyOf(block);
  const links = [...body.querySelectorAll(BUTTON_LINKS)];
  const has = (c) => body.classList.contains(c);

  return {
    buttons: links.map((a) => {
      const look = lookOf(a);
      const hidden = a.querySelector('.visually-hidden');

      const svg = a.querySelector(':scope > svg');
      const named = svg && svg.getAttribute('data-icon');

      return {
        text: [...a.childNodes].filter((n) => n !== hidden && n !== svg).map((n) => n.textContent).join('').trim(),
        href: a.getAttribute('href') === '#' ? '' : (a.getAttribute('href') || ''),
        style: look.style,
        outline: look.outline,
        blank: a.target === '_blank',
        icon: svg ? (named && iconSvg(named) ? named : 'own') : '',
        svg: svg && !(named && iconSvg(named)) ? svg.outerHTML : '',
        iconAt: svg && svg !== a.firstElementChild && a.firstChild !== svg ? 'after' : '',
      };
    }),
    // Joomla's windows that give an address: a page, or a file of the media (Iris, or Joomla's own).
    pages: [...['article', 'contact', 'menu'].filter((p) => m.xtd(p)), ...(m.xtd(m.imageButton()) ? ['file'] : [])],
    // Corpus draws Bootstrap's buttons its own way: said in the panel (dialogs.js).
    corpus: !!m.options.corpus,
    size: links.some((a) => a.classList.contains('btn-lg')) ? 'lg'
      : (links.some((a) => a.classList.contains('btn-sm') || a.classList.contains('bouton--petit')) ? 'sm' : ''),
    place: Object.keys(PLACES).find((k) => has(PLACES[k])) || (links[0] && links[0].classList.contains('ms-auto') ? 'end' : ''),
    wide: has('d-grid'),
  };
}

/** One look for every button, the place for all; the container is a flex row once there are two. */
function applyButtons(m, block, v) {
  const body = bodyOf(block);
  const links = [...body.querySelectorAll(BUTTON_LINKS)];

  links.forEach((a, i) => {
    const style = v[`b${i}style`] || 'primary';
    const href = String(v[`b${i}href`] || '').trim().replace(/^www\./i, 'https://www.');
    let hidden = a.querySelector('.visually-hidden');

    [...a.classList].filter((c) => BTN_STYLE.test(c) || /^(btn|btn-sm|btn-lg|bouton|bouton--(second|tertiaire|petit))$/.test(c))
      .forEach((c) => a.classList.remove(c));

    a.classList.add('btn', `btn-${v[`b${i}outline`] && style !== 'link' ? 'outline-' : ''}${style}`);

    if (v.size) {
      a.classList.add(`btn-${v.size}`);
    }

    a.setAttribute('href', href || '#');

    // The pictogram: one of the set, or the author's own SVG, before or after the words.
    a.querySelectorAll(':scope > svg').forEach((s) => s.remove());
    a.classList.remove('d-inline-flex', 'align-items-center', 'gap-2');

    const icon = v[`b${i}icon`] === 'own' ? cleanSvg(v[`b${i}svg`]) : iconSvg(v[`b${i}icon`]);

    if (icon) {
      const holder = document.createElement('span');

      holder.innerHTML = icon;

      const svg = holder.firstElementChild;

      svg.setAttribute('contenteditable', 'false');

      if (v[`b${i}iconAt`] === 'after') {
        const spoken = a.querySelector(':scope > .visually-hidden');

        if (spoken) {
          spoken.before(svg);
        } else {
          a.append(svg);
        }
      } else {
        a.prepend(svg);
      }

      a.classList.add('d-inline-flex', 'align-items-center', 'gap-2');
    }

    // A new tab is said to screen readers (RGAA 13.2), as the links of Markus do.
    if (v[`b${i}blank`]) {
      a.target = '_blank';
      a.rel = 'noopener noreferrer';

      if (!hidden) {
        a.insertAdjacentHTML('beforeend', `<span class="visually-hidden"> ${escape(t('NEW_WINDOW'))}</span>`);
      }
    } else {
      a.removeAttribute('target');
      a.removeAttribute('rel');

      if (hidden) {
        hidden.remove();
        hidden = null;
      }
    }
  });

  body.classList.remove('d-flex', 'd-grid', 'flex-wrap', 'gap-2', 'boutons', ...Object.values(PLACES));
  links.forEach((a) => a.classList.remove('ms-auto'));

  if (v.wide) {
    body.classList.add('d-grid', 'gap-2');
  } else if (links.length > 1 || v.place) {
    body.classList.add('d-flex', 'flex-wrap', 'gap-2');

    if (v.place) {
      body.classList.add(PLACES[v.place]);
    }
  }

  dropEmptyClass(body, ...links);
  m.changed();
}

function buttons(m, block) {
  const body = bodyOf(block);

  // Adding or removing a button rebuilds the panel: its settings follow.
  const again = (change) => {
    window.JoomanjiPanneau && document.querySelector('.jmj-panneau__croix') && document.querySelector('.jmj-panneau__croix').click();
    m.remember();
    change();
    m.makeEditable('buttons', body, m.typeName('buttons'));
    m.changed();
    openSettings(m, block);
  };

  return ({
    title: t('BUTTONS_SETTINGS'),
    body: buttonsForm(readButtons(block, m)),
    ready: (form) => {
      // Article, Contact, Menu: Joomla's window gives the address, put in the field.
      form.querySelectorAll('[data-mk-pick]').forEach((b) => b.addEventListener('click', async () => {
        const href = await m.pickLink(b.dataset.mkPick === 'file' ? m.imageButton() : b.dataset.mkPick);
        const input = form.querySelector(`[name="${b.dataset.mkFor}"]`);

        input.value = href;
        input.dispatchEvent(new Event('change', { bubbles: true }));
      }));
      wireOwnIcons(form);
      form.querySelector('[data-mk-button-add]').addEventListener('click', () => again(() => {
        const last = [...body.querySelectorAll(BUTTON_LINKS)].pop();
        const a = last.cloneNode(false);

        a.removeAttribute('contenteditable');
        a.setAttribute('href', '#');
        a.removeAttribute('target');
        a.removeAttribute('rel');
        body.append(' ', a);
      }));
      form.querySelectorAll('[data-mk-button-remove]').forEach((b) => b.addEventListener('click', () => again(() => {
        const a = body.querySelectorAll(BUTTON_LINKS)[Number(b.dataset.mkButtonRemove)];

        if (a) {
          a.remove();
        }
      })));
    },
    apply: (v) => applyButtons(m, block, v),
    cancel: () => m.undo(),
    place: m.sideColumn(),
  });
}

/* BULLETED LIST ---------------------------------------------------------- */

/*
 * The browser's own bullets (`circle`, `square`) or a sign of ours, written
 * as a string of `list-style-type`; "None" is Bootstrap's `list-unstyled`.
 * The style is read and written as text (styleOf), as the knife does.
 */
// Single quotes inside: the saved HTML stays readable (no &quot;).
const BULLET_TYPES = { circle: 'circle', square: 'square', dash: "'- '", check: "'\u2713 '", arrow: "'\u2192 '" };

function readBullets(block) {
  const body = bodyOf(block);

  if (body.classList.contains('list-unstyled')) {
    return { bullet: 'none' };
  }

  const type = (styleOf(body).find(([p]) => p === 'list-style-type') || [])[1] || '';
  const same = (x) => x.replace(/"/g, "'").replace(/\s+/g, ' ');
  const hit = Object.entries(BULLET_TYPES).find(([, v]) => same(v) === same(type));

  return { bullet: hit ? hit[0] : '' };
}

function bullets(m, block) {
  const body = bodyOf(block);

  return ({
    title: t('BULLETS_SETTINGS'),
    body: bulletsForm(readBullets(block)),
    apply: (v) => {
      const style = styleOf(body).filter(([p]) => p !== 'list-style-type');

      body.classList.toggle('list-unstyled', v.bullet === 'none');

      if (BULLET_TYPES[v.bullet]) {
        style.push(['list-style-type', BULLET_TYPES[v.bullet]]);
      }

      setStyle(body, style);
      dropEmptyClass(body);
      m.changed();
    },
    cancel: () => m.undo(),
    place: m.sideColumn(),
  });
}

/* NUMBERED LIST ---------------------------------------------------------- */

function readList(block) {
  const body = bodyOf(block);

  return { start: body.getAttribute('start') || '', reversed: body.hasAttribute('reversed'), kind: body.getAttribute('type') || '' };
}

function list(m, block) {
  const body = bodyOf(block);

  return ({
    title: t('LIST_SETTINGS'),
    body: listForm(readList(block)),
    apply: (v) => {
      const start = String(v.start).trim();

      // 1 is where a list starts anyway: no attribute for it.
      if (/^-?\d+$/.test(start) && start !== '1') {
        body.setAttribute('start', start);
      } else {
        body.removeAttribute('start');
      }

      body.toggleAttribute('reversed', !!v.reversed);

      if (v.kind) {
        body.setAttribute('type', v.kind);
      } else {
        body.removeAttribute('type');
      }

      m.changed();
    },
    cancel: () => m.undo(),
    place: m.sideColumn(),
  });
}

/* QUOTE ------------------------------------------------------------------ */

function readQuote(block) {
  const body = bodyOf(block);
  const now = body.querySelector(':scope > footer');
  const cite = now && now.querySelector('cite');
  const work = cite ? cite.textContent : '';

  return {
    author: now ? now.textContent.replace(work, '').replace(/[,\s]+$/, '').trim() : '',
    work,
    url: body.getAttribute('cite') || '',
  };
}

function quote(m, block) {
  const body = bodyOf(block);
  const footer = () => body.querySelector(':scope > footer');

  return ({
    title: t('QUOTE_SETTINGS'),
    body: quoteForm(readQuote(block)),
    apply: (v) => {
      const author = v.author.trim();
      const title = v.work.trim();
      let f = footer();

      body.classList.add('blockquote');

      if (author || title) {
        if (!f) {
          f = document.createElement('footer');
          body.appendChild(f);
        }

        f.className = 'blockquote-footer';
        f.textContent = author + (author && title ? ', ' : '');

        if (title) {
          f.appendChild(document.createElement('cite')).textContent = title;
        }
      } else if (f) {
        f.remove();
      }

      if (v.url.trim()) {
        body.setAttribute('cite', v.url.trim());
      } else {
        body.removeAttribute('cite');
      }

      m.makeEditable('blockquote', body, m.typeName('blockquote'));
      m.changed();
    },
    cancel: () => m.undo(),
    place: m.sideColumn(),
  });
}

/* CODE ----------------------------------------------------------------- */

function readCode(block) {
  const body = bodyOf(block);
  const current = body.querySelector('code') || body;

  return { language: (current.className.match(/language-([\w-]+)/) || [])[1] || '' };
}

function code(m, block) {
  const body = bodyOf(block);

  return ({
    title: t('CODE_SETTINGS'),
    body: codeForm(readCode(block)),
    apply: (v) => {
      let target = body.querySelector('code');

      // The language goes on a <code> inside the <pre>, where highlighters look for it.
      if (!target) {
        target = document.createElement('code');
        target.textContent = body.textContent;
        body.replaceChildren(target);
        body.removeAttribute('contenteditable');
        body.removeAttribute('aria-label');
        m.makeEditable('pre', body, m.typeName('pre'));
      }

      target.className = target.className.replace(/\blanguage-[\w-]+/, '').trim();

      if (v.language.trim()) {
        target.classList.add(`language-${v.language.trim().replace(/[^\w-]/g, '')}`);
      }

      dropEmptyClass(target);
      m.changed();
    },
    cancel: () => m.undo(),
    place: m.sideColumn(),
  });
}

/* MODULE: Joomla's module form, in the panel ---------------------------- */

/**
 * THE DOORS OF OUR PRODUCTS. Opus, Formulus and Iris open their modules in
 * their own window, the one they improved for TinyMCE; each registers it as
 * `window.JoomanjiModules[<module type>] = (id, done) => ...`. Any other
 * module opens Joomla's module form in the side panel.
 */
function module(m, block) {
  const id = moduleId(kept(block));
  const known = (m.options.modules || {})[id];
  const door = known && (window.JoomanjiModules || {})[known.module];

  if (door) {
    door(id, () => {
      delete m.options.modules[id];
      m.nameModules();
    });

    return;
  }

  const token = Joomla.getOptions('csrf.token', '');
  let done = false;

  const finish = (panel) => {
    done = true;
    window.removeEventListener('message', listen);
    delete window.JoomlaExpectingPostMessage;
    delete m.options.modules[id];
    m.nameModules();
    panel.fermer();
  };

  // Joomla's modal form says "saved and closed" or "cancelled" by a message.
  let current = null;
  const listen = (e) => {
    if (e.origin === window.location.origin && e.data && /^joomla:(content-select|cancel)$/.test(e.data.messageType) && current) {
      finish(current);
    }
  };

  window.JoomlaExpectingPostMessage = true;
  window.addEventListener('message', listen);

  current = window.JoomanjiPanneau.ouvrir({
    titre: t('MODULE_SETTINGS'),
    cle: 'markus-module',
    onglets: [{
      titre: t('MODULE_SETTINGS'),
      remplir: (zone, panel) => {
        panel.large(true);
        zone.innerHTML = `<iframe class="mk-module-frame" title="${escape(t('MODULE_SETTINGS'))}"`
          + ` src="index.php?option=com_modules&amp;task=module.edit&amp;layout=modal&amp;tmpl=component&amp;id=${id}"></iframe>`;
      },
    }],
    // Closed by its cross, Escape or a click beside it: the module is checked in again.
    fermeture: () => {
      if (done) {
        return;
      }

      window.removeEventListener('message', listen);
      delete window.JoomlaExpectingPostMessage;

      const form = new FormData();

      form.append('task', 'module.cancel');
      form.append(token, '1');
      fetch(`index.php?option=com_modules&layout=edit&id=${id}`, { method: 'POST', body: form });
    },
  });
}

/* THE SWISS ARMY KNIFE: spacing, border, corners, background (boxForm) ----- */

const BOX_COLOURS = TABLE_COLOURS.join('|');
const BOX = {
  pad: [/^p-([0-5])$/, (v) => [`p-${v}`]],
  mt: [/^mt-([0-5])$/, (v) => [`mt-${v}`]],
  mb: [/^mb-([0-5])$/, (v) => [`mb-${v}`]],
  gutter: [/^g-([0-5])$/, (v) => [`g-${v}`]],
  border: [/^border-([2-5])$/, (v) => (v === '1' ? ['border'] : ['border', `border-${v}`])],
  borderColour: [new RegExp(`^border-(${BOX_COLOURS})$`), (v) => [`border-${v}`]],
  radius: [/^rounded-([0-5]|pill)$/, (v) => [`rounded-${v}`]],
  back: [new RegExp(`^bg-(${BOX_COLOURS})-subtle$`), (v) => [`bg-${v}-subtle`]],
  fs: [/^(lead|small|fs-[1-6])$/, (v) => [v]],
  fw: [/^fw-(light|normal|semibold|bold)$/, (v) => [`fw-${v}`]],
  // Line height and letter case (Cyrille: "police, graisse, interligne, casse"): Bootstrap's `lh-*`, `text-*case`.
  lh: [/^lh-(1|sm|base|lg)$/, (v) => [`lh-${v}`]],
  tt: [/^text-(lowercase|uppercase|capitalize)$/, (v) => [`text-${v}`]],
};

/*
 * THE CLASSES OF ONE'S OWN: every class that is none of Bootstrap's nor of
 * Markus. A class that looks like Bootstrap's stays on the block but is not
 * shown in the field (Markus cannot tell it from its own).
 */
const KNOWN = /^(mk-|btn|boutons?($|--)|alert|card|message|rule$|panneau__|table|row$|col|g-|gx-|gy-|p[trblxy]?-|m[trblxy]?-|border|rounded|bg-|text-|align-|justify-|d-|flex-|gap-|float-|mx-|w-|h-|img-|shadow|caption-|list-|lead$|small$|fs-|fw-|fst-|lh-|blockquote|language-|figure|ratio|clearfix|visually-|position-|overflow-|order-|font-)/;
const ownClasses = (el) => [...el.classList].filter((c) => !KNOWN.test(c));

/** What each type of block takes. A table and an image draw their own frame: spacing only. */
function boxKinds(block) {
  const type = block.dataset.type;
  const body = bodyOf(block);

  // A callout draws its own frame (Corpus's message or panel): the knife leaves its border alone.
  if (type === 'callout') {
    return ['pad', 'mt', 'mb', 'radius', 'fs', 'fw', 'lh', 'tt', 'back', 'cls', 'anchor'];
  }

  if (TEXT_TYPES.includes(type)) {
    return ['pad', 'mt', 'mb', 'border', 'radius', 'fs', 'fw', 'lh', 'tt', 'back', 'cls', 'anchor'];
  }

  if (type === 'columns') {
    return ['pad', 'mt', 'mb', 'gutter', 'border', 'radius', 'back', 'cls', 'anchor'];
  }

  if (type === 'table' || type === 'buttons' || (type === 'image' && body && !/^(IMG|A)$/.test(body.tagName))) {
    return ['mt', 'mb', 'cls', 'anchor'];
  }

  return [];
}

/*
 * A locked hue of the knife is a colour pair in the style (dialogs.js,
 * hueSwatches). A BORDER of a locked hue is written whole, without the
 * `border` class: `border: 2px solid light-dark(...)`. Bootstrap's `.border`
 * is !important (Atum's and the sites'), and no colour written beside it
 * would show (Cyrille: the colour did not show).
 */
const HUE_STYLE = { back: ['background-color'] };
const PAIR = /^light-dark\(#[0-9a-f]{6}, ?#[0-9a-f]{6}\)$/i;
const HUE_BORDER = /^([1-5])px solid (light-dark\(#[0-9a-f]{6}, ?#[0-9a-f]{6}\))$/i;
// Written by 1.0.037 and 1.0.038, and taken away when the block is set again.
const OLD_BORDER = ['border-color', '--bs-border-color'];

/*
 * The style is read and written AS TEXT, as colours.js does: through the
 * CSSOM, the browser would rewrite the pair in rgb() and the hue would be
 * lost to the next reading.
 */
function styleOf(el) {
  return String(el.getAttribute('style') || '').split(';').map((d) => d.trim()).filter(Boolean)
    .map((d) => [d.slice(0, d.indexOf(':')).trim().toLowerCase(), d.slice(d.indexOf(':') + 1).trim()]);
}

function setStyle(el, list) {
  const text = list.map(([k, v]) => `${k}: ${v}`).join('; ');

  if (text) {
    el.setAttribute('style', text);
  } else {
    el.removeAttribute('style');
  }
}

function readBox(el) {
  const o = {};
  const classes = [...el.classList];

  Object.entries(BOX).forEach(([k, [re]]) => {
    const hit = classes.map((c) => re.exec(c)).find(Boolean);

    o[k] = hit ? hit[1] : '';
  });

  if (!o.border && el.classList.contains('border')) {
    o.border = '1';
  }

  o.cls = ownClasses(el).join(' ');
  o.anchor = el.id || '';

  const style = styleOf(el);

  Object.entries(HUE_STYLE).forEach(([k, props]) => {
    const hit = style.find(([p, v]) => props.includes(p) && PAIR.test(v));

    if (!o[k] && hit) {
      o[k] = `css:${hit[1]}`;
    }
  });

  const whole = style.map(([p, v]) => (p === 'border' ? HUE_BORDER.exec(v) : null)).find(Boolean);
  const old = style.find(([p, v]) => OLD_BORDER.includes(p) && PAIR.test(v));

  if (whole) {
    o.border = whole[1];
    o.borderColour = `css:${whole[2]}`;
  } else if (old && !o.borderColour) {
    o.borderColour = `css:${old[1]}`;
  }

  return o;
}

function applyBox(el, v, kinds) {
  const keys = { pad: 'boxPad', mt: 'boxMt', mb: 'boxMb', gutter: 'boxGutter', border: 'boxBorder', borderColour: 'boxBorderColour', radius: 'boxRadius', back: 'boxBack', fs: 'boxFs', fw: 'boxFw', lh: 'boxLh', tt: 'boxTt' };
  const take = (k) => kinds.includes(k) || (k === 'borderColour' && kinds.includes('border'));

  Object.entries(BOX).forEach(([k, [re]]) => {
    if (!take(k)) {
      return;
    }

    [...el.classList].filter((c) => re.test(c)).forEach((c) => el.classList.remove(c));

    if (k === 'border') {
      el.classList.remove('border');
    }
  });
  let style = styleOf(el).filter(([p, value]) => !Object.entries(HUE_STYLE).some(([k, props]) => take(k) && props.includes(p) && PAIR.test(value))
    && !(take('border') && ((p === 'border' && HUE_BORDER.test(value)) || (OLD_BORDER.includes(p) && PAIR.test(value)))));
  const hued = take('border') && v.boxBorder && String(v.boxBorderColour || '').startsWith('css:');

  Object.entries(BOX).forEach(([k, [, make]]) => {
    const value = v[keys[k]];

    // A border colour without a border would draw nothing; a hued border is written whole, below.
    if (!take(k) || !value || (k === 'borderColour' && !v.boxBorder) || (hued && (k === 'border' || k === 'borderColour'))) {
      return;
    }

    if (value.startsWith('css:')) {
      style = [...style, ...HUE_STYLE[k].map((prop) => [prop, value.slice(4)])];
    } else {
      el.classList.add(...make(value));
    }
  });

  if (hued) {
    style = [...style, ['border', `${v.boxBorder}px solid ${v.boxBorderColour.slice(4)}`]];
  }

  // The anchor of the block (Cyrille, comparison with Gutenberg): a name for a link to it, `#name`.
  if (kinds.includes('anchor')) {
    let id = String(v.boxAnchor || '').trim().replace(/^#/, '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '');

    if (id && !/^[a-z]/.test(id)) {
      id = `a-${id}`;
    }

    // Unique in the page: a second "contact" becomes "contact-2".
    const base = id;

    for (let i = 2; id && document.getElementById(id) && document.getElementById(id) !== el; i += 1) {
      id = `${base}-${i}`;
    }

    if (id) {
      el.id = id;
    } else {
      el.removeAttribute('id');
    }
  }

  if (kinds.includes('cls')) {
    el.classList.remove(...ownClasses(el));
    String(v.boxClass || '').split(/\s+/).filter((c) => /^-?[A-Za-z_][\w-]*$/.test(c)).forEach((c) => el.classList.add(c));
  }

  setStyle(el, style);
  dropEmptyClass(el);
}

/*
 * THE COUNT ON THE GEAR, as in Opus (`compterReglages()` of mod_opus
 * admin.js): the number of settings of a block that are not those of a new
 * block of its type. What a block SAYS (the alternative text, the sizes of an
 * image, the title of a table) is its content, not a setting: not counted.
 */
const DEFAULTS = {
  image: [readImage, { decorative: false, caption: false, href: '', blank: false, fit: '', align: '', rounded: '', border: '', borderColour: '', shadow: '' }],
  table: [readTable, { headRow: true, headCol: false, footRow: false, border: 'lines', borderColour: '', shape: 'square', headBack: '', back: '', striped: false, hover: false, small: false, colMode: 'auto' }],
  columns: [readColumns, { layout: '6-6', stack: 'md', valign: '' }],
  ol: [readList, { start: '', reversed: false, kind: '' }],
  ul: [readBullets, { bullet: '' }],
  callout: [readCallout, { kind: 'message', nature: 'info', level: '2', titled: true, align: '', icon: '', iconAt: '' }],
  blockquote: [readQuote, { author: '', work: '', url: '' }],
  pre: [readCode, { language: '' }],
};

/** The number of settings of `block` away from those of a new block. */
export function countSettings(block) {
  const known = DEFAULTS[block.dataset.type];

  if (!known) {
    return countBox(block);
  }

  let now;

  try {
    now = known[0](block);
  } catch (err) {
    // A block half built (an image without its <img> yet): nothing to count.
    return 0;
  }

  return Object.keys(known[1]).filter((k) => String(now[k] ?? '') !== String(known[1][k])).length + countBox(block);
}

/** The settings of the Swiss army knife that are set. */
function countBox(block) {
  const kinds = boxKinds(block);
  const body = bodyOf(block);

  if (!kinds.length || !body) {
    return 0;
  }

  const o = readBox(body);

  return [...kinds, ...(kinds.includes('border') ? ['borderColour'] : [])].filter((k) => o[k]).length;
}

/** Opens the settings of a block. Returns false when the block has none. */
export function openSettings(m, block) {
  const open = { image, buttons, table, columns, pre: code, ol: list, ul: bullets, blockquote: quote, callout, module }[block.dataset.type];
  const kinds = boxKinds(block);

  if (block.dataset.type === 'module' && !m.options.admin) {
    return false;
  }

  m.remember();

  // A block without settings of its own (a paragraph, a title) has the knife alone.
  let spec = open ? open(m, block) : {
    title: t('SETTINGS', m.typeName(block.dataset.type)),
    body: '',
    apply: () => m.changed(),
    cancel: () => m.undo(),
    place: m.sideColumn(),
  };

  // The knife comes last, after the block's own settings; it works on the block's saved element.
  if (spec && kinds.length) {
    const own = spec;

    spec = {
      ...own,
      body: own.body + boxForm(readBox(bodyOf(block)), kinds),
      ready: (form, panel) => {
        if (own.ready) {
          own.ready(form, panel);
        }

        wireHues(form);
      },
      apply: (v) => {
        own.apply(v);
        applyBox(bodyOf(block), v, kinds);
        m.changed();
      },
    };
  }

  // A module opens its own window (or Joomla's form); the others, the side panel.
  if (spec) {
    const had = block.classList.contains('mk-block--modified');
    const type = block.dataset.type;
    const body = bodyOf(block);
    const hideable = !!body && !['html', 'separator', 'readmore'].includes(type);
    const hidden = () => !!body && body.hasAttribute('data-mk-hidden');
    // Short words on the buttons, the whole sentence in their title.
    // Pictograms alone (Cyrille), their sentence in the title and for screen readers.
    const button = (name, icon, label, title) => `<button type="button" class="btn btn-sm btn-outline-${name === 'remove' ? 'danger' : 'secondary'} mk-ibtn mk-ibtn--seul mk-ibtn--${icon}"`
      + ` data-mk-block="${name}" title="${escape(title)}" aria-label="${escape(title)}"></button>`;
    const own = spec.ready;

    // THE BLOCK ITSELF, at the top on the left: move up and down, duplicate, hide on the site (`hidden`), remove.
    // Moving by a click, not only by dragging the handle: WCAG 2.2, 2.5.7.
    const name = m.typeName(type);
    spec = {
      ...spec,
      blockActions: button('up', 'monter', '', t('MOVE_UP', name))
        + button('down', 'descendre', '', t('MOVE_DOWN', name))
        + button('duplicate', 'dupliquer', t('BLOCK_DUPLICATE_SHORT'), t('CTX_DUPLICATE'))
        + (hideable ? button('hide', hidden() ? 'afficher' : 'masquer', t(hidden() ? 'BLOCK_SHOW_SHORT' : 'BLOCK_HIDE_SHORT'), t(hidden() ? 'BLOCK_SHOW' : 'BLOCK_HIDE')) : '')
        + button('remove', 'supprimer', t('BLOCK_REMOVE_SHORT'), t('REMOVE', m.typeName(type))),
      ready: (form, panel) => {
        if (own) {
          own(form, panel);
        }

        // No way further: the arrow is disabled, at the top or the bottom of its list.
        const ends = () => {
          const list = m.blocksIn(block.parentNode);

          form.querySelector('[data-mk-block="up"]').disabled = list[0] === block;
          form.querySelector('[data-mk-block="down"]').disabled = list[list.length - 1] === block;
        };

        ['up', 'down'].forEach((way) => form.querySelector(`[data-mk-block="${way}"]`).addEventListener('click', (e) => {
          m.move(block, way === 'up' ? -1 : 1, true);
          block.scrollIntoView({ block: 'nearest' });
          ends();

          // At an end, the focus goes to the other arrow rather than nowhere.
          if (e.currentTarget.disabled) {
            form.querySelector(`[data-mk-block="${way === 'up' ? 'down' : 'up'}"]`).focus();
          }
        }));
        ends();

        form.querySelector('[data-mk-block="duplicate"]').addEventListener('click', () => {
          panel.fermer();
          m.duplicate(block);
        });
        form.querySelector('[data-mk-block="remove"]').addEventListener('click', () => {
          panel.fermer();
          m.remove(block);
        });

        const hide = form.querySelector('[data-mk-block="hide"]');

        if (hide) {
          hide.addEventListener('click', () => {
            const now = !hidden();

            body.toggleAttribute('data-mk-hidden', now);
            hide.title = t(now ? 'BLOCK_SHOW' : 'BLOCK_HIDE');
            hide.setAttribute('aria-label', hide.title);
            hide.classList.toggle('mk-ibtn--masquer', !now);
            hide.classList.toggle('mk-ibtn--afficher', now);
            m.changed();
            m.say(t(now ? 'BLOCK_HIDDEN' : 'BLOCK_SHOWN', m.typeName(type)));
          });
        }
      },
    };

    block.classList.add('mk-block--setting');
    openPanel({
      ...spec,
      apply: (v) => {
        spec.apply(v);
        m.markSettings(block);
      },
      cancel: () => {
        block.classList.toggle('mk-block--modified', had);
        spec.cancel();
      },
      // The violet outline: this block has changes the article has not saved yet.
      modified: (n) => block.classList.toggle('mk-block--modified', had || n > 0),
      closed: () => block.classList.remove('mk-block--setting'),
    });
  }

  return true;
}
