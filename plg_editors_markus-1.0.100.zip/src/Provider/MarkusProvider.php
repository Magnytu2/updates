<?php

/**
 * @package     Markus
 * @subpackage  plg_editors_markus
 *
 * @copyright   (C) 2026 joomanji.eu
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomanji\Plugin\Editors\Markus\Provider;

use Joomanji\Plugin\Editors\Markus\Helper\ModulesHelper;
use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\Editor\AbstractEditorProvider;
use Joomla\CMS\Language\LanguageHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Uri\Uri;
use Joomla\Database\DatabaseInterface;
use Joomla\Event\DispatcherInterface;
use Joomla\Registry\Registry;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

/**
 * Markus Editor provider.
 *
 * The output follows plg_editors_none: a custom element around the form's
 * <textarea>, then the editor buttons. The textarea keeps the HTML that is
 * saved; the browser script builds the blocks in front of it.
 */
final class MarkusProvider extends AbstractEditorProvider
{
    /**
     * Strings of Joomla's core used by the charter's window and panel.
     */
    private const CORE_STRINGS = ['JCANCEL', 'JCLOSE'];

    /**
     * @param   Registry                 $params       The plugin parameters.
     * @param   CMSApplicationInterface  $application  The application.
     * @param   DispatcherInterface      $dispatcher   The dispatcher, for the editor buttons.
     * @param   DatabaseInterface        $db           The database, for the names of the modules.
     */
    public function __construct(
        private Registry $params,
        private CMSApplicationInterface $application,
        DispatcherInterface $dispatcher,
        private DatabaseInterface $db
    ) {
        $this->setDispatcher($dispatcher);
    }

    /**
     * @return  string
     */
    public function getName(): string
    {
        return 'markus';
    }

    /**
     * Gets the editor HTML markup.
     *
     * @param   string  $name        Input name.
     * @param   string  $content     The content of the field, already escaped by the editor field.
     * @param   array   $attributes  Associative array of editor attributes.
     * @param   array   $params      Associative array of editor parameters.
     *
     * @return  string
     */
    public function display(string $name, string $content = '', array $attributes = [], array $params = []): string
    {
        $id       = $attributes['id'] ?? '' ?: $name;
        $height   = $attributes['height'] ?? '';
        $readonly = !empty($params['readonly']) ? ' readonly' : '';

        // The buttons of Joomla and of the other extensions (Article, Image, Opus, Iris...).
        $buttons = $this->getButtons($params['buttons'] ?? true, [
            'asset'    => $params['asset'] ?? 0,
            'author'   => $params['author'] ?? 0,
            'editorId' => $id,
        ]);

        $this->loadAssets();

        $options = [
            'root'    => Uri::root(),
            'admin'   => $this->application->isClient('administrator'),
            'height'  => is_numeric($height) ? $height . 'px' : ($height ?: '30rem'),
            'buttons' => array_map(static fn ($button) => $button->getButtonName(), $buttons),
            'modules' => $this->modules(html_entity_decode($content, ENT_QUOTES, 'UTF-8')),
            'corpus'  => $this->corpus(),
            'spell'   => $this->spell(),
        ] + $this->about();

        return '<joomla-editor-markus options="' . htmlspecialchars(json_encode($options), ENT_QUOTES, 'UTF-8') . '">'
            . '<textarea name="' . $name . '" id="' . $id . '" rows="20"' . $readonly . '>' . $content . '</textarea>'
            . ($buttons ? LayoutHelper::render('joomla.editors.buttons', $buttons) : '')
            . '</joomla-editor-markus>';
    }

    /**
     * At the top of Markus, as in every product of ours: its version, read in
     * its manifest (never written by hand), then the way to its settings, for
     * whoever may change them (Joomla's form of the plugin, in a window).
     *
     * @return  array  `version`, and `settings` (the id of the plugin) when allowed.
     */
    private function about(): array
    {
        $out  = [];
        $file = JPATH_PLUGINS . '/editors/markus/markus.xml';
        $xml  = is_file($file) ? simplexml_load_file($file) : false;

        if ($xml && isset($xml->version)) {
            $out['version'] = (string) $xml->version;
        }

        $user = $this->application->getIdentity();

        if ($this->application->isClient('administrator') && $user && $user->authorise('core.manage', 'com_plugins')) {
            try {
                $query = $this->db->getQuery(true)
                    ->select($this->db->quoteName('extension_id'))
                    ->from($this->db->quoteName('#__extensions'))
                    ->where($this->db->quoteName('type') . ' = ' . $this->db->quote('plugin'))
                    ->where($this->db->quoteName('folder') . ' = ' . $this->db->quote('editors'))
                    ->where($this->db->quoteName('element') . ' = ' . $this->db->quote('markus'));

                $id = (int) $this->db->setQuery($query, 0, 1)->loadResult();

                if ($id) {
                    $out['settings'] = $id;
                }
            } catch (\RuntimeException) {
                // No link to the settings: the editor works without it.
            }
        }

        return $out;
    }

    /**
     * Spelling and grammar (spell.js): LanguageTool's public service, the
     * site's own LanguageTool server, or none. The address of a server is
     * completed with the path of its API (`/v2/check`) when it is not given.
     *
     * @return  array|null  The address of the API and whether mistakes are underlined live.
     */
    private function spell(): ?array
    {
        $mode = $this->params->get('spell', 'public');

        if ($mode === 'off') {
            return null;
        }

        $url = 'https://api.languagetool.org/v2/check';
        $own = rtrim(trim((string) $this->params->get('spell_url', '')), '/');

        if ($mode === 'own' && preg_match('#^https?://#i', $own)) {
            $url = preg_match('#/v2/check$#', $own) ? $own : $own . (preg_match('#/v2$#', $own) ? '/check' : '/v2/check');
        } else {
            $mode = 'public';
        }

        return [
            'url'    => $url,
            'public' => $mode === 'public',
            'live'   => (bool) $this->params->get('spell_live', 1),
        ];
    }

    /**
     * Whether the site's default template is Corpus. Corpus draws every button
     * of an article with its own look (`.contenu .btn` is always full), so the
     * editor then offers Corpus's buttons (`bouton`, `bouton--second`...).
     *
     * @return  bool
     */
    private function corpus(): bool
    {
        try {
            $query = $this->db->getQuery(true)
                ->select($this->db->quoteName('template'))
                ->from($this->db->quoteName('#__template_styles'))
                ->where($this->db->quoteName('client_id') . ' = 0')
                ->where($this->db->quoteName('home') . ' = ' . $this->db->quote('1'));

            return $this->db->setQuery($query, 0, 1)->loadResult() === 'corpus';
        } catch (\RuntimeException) {
            return false;
        }
    }

    /**
     * Registers the scripts, the style sheets and the strings of the editor.
     *
     * @return  void
     */
    private function loadAssets(): void
    {
        $wa = $this->application->getDocument()->getWebAssetManager();

        $wa->getRegistry()->addExtensionRegistryFile('plg_editors_markus');
        $wa->useStyle('plg_editors_markus')->useScript('webcomponent.editor-markus');

        // Joomla's CodeMirror colours the source code. Only mapped here: it loads
        // when the author opens the source view, never before.
        $wa->getRegistry()->addExtensionRegistryFile('plg_editors_codemirror');

        if ($wa->assetExists('script', 'codemirror')) {
            $wa->useScript('codemirror');
        }

        // Every string of the editor is used by its script.
        $strings = LanguageHelper::parseIniFile(JPATH_PLUGINS . '/editors/markus/language/en-GB/plg_editors_markus.ini');

        foreach (array_merge(array_keys($strings), self::CORE_STRINGS) as $key) {
            Text::script($key);
        }
    }

    /**
     * The titles of the modules loaded in the content with {loadmoduleid N}.
     *
     * @param   string  $content  The content.
     *
     * @return  array
     */
    private function modules(string $content): array
    {
        preg_match_all('/\{loadmoduleid\s+(\d+)\s*\}/', $content, $matches);

        return ModulesHelper::titles($this->db, $matches[1]);
    }
}
