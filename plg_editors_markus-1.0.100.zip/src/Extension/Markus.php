<?php

/**
 * @package     Markus
 * @subpackage  plg_editors_markus
 *
 * @copyright   (C) 2026 joomanji.eu
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomanji\Plugin\Editors\Markus\Extension;

use Joomanji\Plugin\Editors\Markus\Helper\ModulesHelper;
use Joomanji\Plugin\Editors\Markus\Provider\MarkusProvider;
use Joomla\CMS\Event\Editor\EditorSetupEvent;
use Joomla\CMS\Event\Plugin\AjaxEvent;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Event\DispatcherAwareInterface;
use Joomla\Event\DispatcherAwareTrait;
use Joomla\Event\SubscriberInterface;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

/**
 * Markus Editor: a block editor that writes plain, semantic HTML.
 *
 * Registered like Joomla's own editors: the plugin only adds its provider
 * to the editors registry, the provider does the work.
 */
final class Markus extends CMSPlugin implements SubscriberInterface, DispatcherAwareInterface, DatabaseAwareInterface
{
    use DispatcherAwareTrait;
    use DatabaseAwareTrait;

    /**
     * The language strings are needed by the editor itself.
     *
     * @var  boolean
     */
    protected $autoloadLanguage = true;

    /**
     * @return  array
     */
    public static function getSubscribedEvents(): array
    {
        return [
            'onEditorSetup' => 'onEditorSetup',
            'onAjaxMarkus'  => 'onAjaxMarkus',
        ];
    }

    /**
     * Adds Markus to the editors registry.
     *
     * @param   EditorSetupEvent  $event  The event.
     *
     * @return  void
     */
    public function onEditorSetup(EditorSetupEvent $event): void
    {
        $event->getEditorsRegistry()->add(
            new MarkusProvider($this->params, $this->getApplication(), $this->getDispatcher(), $this->getDatabase())
        );
    }

    /**
     * The names of modules placed while writing (com_ajax, plugin "markus").
     * Only for a signed-in author, with the form token: the site's visitors
     * have no use for it.
     *
     * @param   AjaxEvent  $event  The event.
     *
     * @return  void
     */
    public function onAjaxMarkus(AjaxEvent $event): void
    {
        $app = $this->getApplication();

        if ($app->getIdentity()->guest || !Session::checkToken('get')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }

        $ids = explode(',', $app->getInput()->getString('ids', ''));

        $event->updateEventResult(ModulesHelper::titles($this->getDatabase(), $ids));
    }
}
