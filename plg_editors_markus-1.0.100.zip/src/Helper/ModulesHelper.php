<?php

/**
 * @package     Markus
 * @subpackage  plg_editors_markus
 *
 * @copyright   (C) 2026 joomanji.eu
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomanji\Plugin\Editors\Markus\Helper;

use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

/**
 * The names of the modules placed in an article with {loadmoduleid N}, so
 * that their cards show "Cards, home page" rather than a number.
 */
final class ModulesHelper
{
    /**
     * @param   DatabaseInterface  $db   The database.
     * @param   int[]              $ids  The module ids.
     *
     * @return  array  [id => ['id' => ..., 'title' => ..., 'module' => ...]]
     */
    public static function titles(DatabaseInterface $db, array $ids): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));

        if (!$ids) {
            return [];
        }

        $query = $db->getQuery(true)
            ->select($db->quoteName(['id', 'title', 'module']))
            ->from($db->quoteName('#__modules'))
            ->whereIn($db->quoteName('id'), $ids, ParameterType::INTEGER);

        return $db->setQuery($query)->loadAssocList('id');
    }
}
