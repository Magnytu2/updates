<?php

/**
 * @package     Markus
 * @subpackage  plg_editors_markus
 *
 * @copyright   (C) 2026 joomanji.eu
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Installer\InstallerScript;

/**
 * Refuses an install on a Joomla older than the one Markus is built for:
 * Joomla's own installer script does the check and says which version to use.
 */
class PlgEditorsMarkusInstallerScript extends InstallerScript
{
    /**
     * @var  string
     */
    protected $minimumJoomla = '6.2.0';

    /**
     * @var  string
     */
    protected $minimumPhp = '8.3.0';

    /**
     * Same check as InstallerScript, with our own message: it names the
     * version of Markus and the Joomla it needs, in the site language.
     *
     * @param   string  $type    install, update or discover_install
     * @param   object  $parent  the installer adapter
     *
     * @return  boolean
     */
    public function preflight($type, $parent)
    {
        if ($type !== 'uninstall' && version_compare(JVERSION, $this->minimumJoomla, '<')) {
            $lang = \Joomla\CMS\Factory::getApplication()->getLanguage();
            $lang->load('plg_editors_markus.sys', JPATH_ADMINISTRATOR)
                || $lang->load('plg_editors_markus.sys', $parent->getParent()->getPath('source'));

            $version = (string) ($parent->getManifest()->version ?? '');
            $message = \Joomla\CMS\Language\Text::sprintf('PLG_EDITORS_MARKUS_JOOMLA_TOO_OLD', $version);

            if ($message === 'PLG_EDITORS_MARKUS_JOOMLA_TOO_OLD') {
                $message = 'Markus Editor ' . $version . ' requires Joomla 6.2 or newer. Please update Joomla first.';
            }

            \Joomla\CMS\Log\Log::add($message, \Joomla\CMS\Log\Log::WARNING, 'jerror');

            return false;
        }

        return parent::preflight($type, $parent);
    }
}
