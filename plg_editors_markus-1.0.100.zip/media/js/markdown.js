/**
 * MARKUS: THE MARKDOWN TO HTML CONVERTER (and its way back).
 *
 * Cyrille's decision, 11 October 2026: a home-made converter rather than a
 * library. Measured the same day: marked 14.1.4 weighs 36,546 bytes,
 * markdown-it 14 weighs 125,451. This one covers only what `markus/CLAUDE.md`
 * (section 3) asks for, and produces exactly the HTML wanted.
 *
 * ONE CONVERTER ONLY: pasting, opening a .md file and the Markdown view of
 * the editor all call the same functions, with the same settings.
 *
 *   import { markdownToHtml, htmlToMarkdown, headings } from './markdown.js';
 *
 *   const html = markdownToHtml(text, {
 *     shift: 1,                        // "#" gives h2 (the article title is the h1)
 *     minLevel: 1,                     // never below this level (2 in automatic mode)
 *     externalLinks: true,             // new tab, rel, spoken mention
 *     domain: 'example.com',           // a link to another domain is external
 *     newWindow: '(nouvelle fenêtre)', // the spoken mention of an external link
 *     noteBackLabel: 'Revenir au texte', // aria-label of a footnote's back link
 *     tableClass: true,                // Bootstrap `table` class and alignment classes
 *     takenIds: ['intro']              // the ids already present in the article
 *   });
 *
 * Defaults: shift 1 (clamped to 0..5), minLevel 1 (clamped to 1..6),
 * externalLinks true (only `false` turns it off), domain `location.hostname`
 * when there is one (else ''), newWindow '(nouvelle fenêtre)' when empty,
 * noteBackLabel 'Revenir au texte' when empty, tableClass true, takenIds [].
 *
 * WHAT IS COVERED: headings # to ###### and underlined ones (= and -),
 * paragraphs, line breaks (two spaces or \ at the end of a line), bold,
 * italic, strikethrough (~~), inline code, nested bulleted and numbered
 * lists, links (inline, by reference, bare addresses), images, quotes, code
 * blocks (``` or ~~~, language as a language-xxx class), tables (GitHub
 * syntax), horizontal rule, footnotes, task lists, and Joomla's "Read more"
 * (a `<!-- readmore -->` line).
 *
 * WHAT IS REFUSED, DELIBERATELY:
 *  - HTML written in the Markdown comes out as TEXT: a pasted <script> never
 *    becomes a tag (section 3: "typed text is escaped");
 *  - javascript:, vbscript:, data: and file: addresses: the link is not
 *    made, its text stays;
 *  - HTML outside a short list of harmless text tags (br, kbd, sup, sub,
 *    mark, u, ins, small, abbr...).
 *
 * NO STYLE, NO INVENTED CLASS, NO wrapping <div>. Only known classes:
 * `language-xxx` (the convention of code highlighters), `visually-hidden`
 * (Bootstrap's and Joomla's) for the spoken "(nouvelle fenêtre)" mention, and
 * Bootstrap's `table` / `text-start` / `text-center` / `text-end` on tables.
 *
 * LOSS CODES returned by htmlToMarkdown() in `losses[].code`. They are data
 * keys (language strings are built on them), so their values never change:
 *   'style'        a style attribute
 *   'classe'       a class attribute (detail: the class value)
 *   'attribut'     any other attribute (detail: the attribute name)
 *   'commentaire'  an HTML comment
 *   'balise'       a tag Markdown cannot write (detail: the tag name)
 *   'titre-haut'   a heading above what the settings allow (detail: 'h1'...)
 *   'saut-page'    a Joomla page break (hr.system-pagebreak)
 */

/* --------------------------------------------------------------------------
   TOOLS
   -------------------------------------------------------------------------- */

/*
 * The apostrophe is not encoded: every attribute written here is between
 * double quotes, and "l&#39;onglet" in the article would only bother whoever
 * reads the HTML code.
 */
const HTML_ENTITIES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' };

const escapeHtml = (text) => String(text).replace(/[&<>"]/g, (c) => HTML_ENTITIES[c]);

// ASCII punctuation, the characters a backslash makes literal.
const PUNCTUATION = '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~';

const isPunctuation = (c) => !!c && (PUNCTUATION.indexOf(c) >= 0 || /[\u2000-\u206f\u2e00-\u2e7f\u00a1-\u00bf]/.test(c));

const isBlank = (c) => !c || /\s/.test(c);

// Removes the \ before punctuation (for addresses and link titles).
const removeBackslashes = (text) => text.replace(/\\([!-\/:-@\[-`{-~])/g, '$1');

// The bare text of a piece of HTML produced here (for ids and alt texts).
const plainText = (html) => html.replace(/<[^>]*>/g, '')
  .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
  .replace(/&amp;/g, '&');

/*
 * THE ID OF A HEADING: lowercase, no accents, hyphens (section 3).
 * "Œuvre complète" gives `oeuvre-complete`. No duplicate in the article:
 * `taken` holds the ids already there.
 */
const makeId = (text, taken) => {
  const base = text.toLowerCase()
    .replace(/œ/g, 'oe').replace(/æ/g, 'ae').replace(/ß/g, 'ss')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'titre';
  let id = base;
  let n = 2;

  while (taken[id]) { id = `${base}-${n++}`; }

  taken[id] = true;

  return id;
};

/*
 * A SAFE ADDRESS, or null. Protocols that run code or read the disk are
 * refused; the rest is escaped later for the attribute.
 */
const safeUrl = (url) => {
  const u = removeBackslashes(String(url).trim());
  const cleaned = u.replace(/[\u0000-\u0020]/g, '').toLowerCase();

  if (/^(javascript|vbscript|data|file):/.test(cleaned)) { return null; }

  return u.replace(/ /g, '%20');
};

const isExternal = (url, settings) => {
  if (!settings.externalLinks) { return false; }

  const m = /^(?:https?:)?\/\/([^\/?#:]+)/i.exec(url);

  if (!m) { return false; }

  const host = m[1].toLowerCase().replace(/^www\./, '');
  const site = String(settings.domain || '').toLowerCase().replace(/^www\./, '');

  return host !== site;
};

/* --------------------------------------------------------------------------
   INLINE TEXT: bold, italic, code, links, images
   -------------------------------------------------------------------------- */

const link = (textHtml, url, title, settings) => {
  const safe = safeUrl(url);

  if (safe === null) { return textHtml; }

  let a = `<a href="${escapeHtml(safe)}"`;

  if (title) { a += ` title="${escapeHtml(removeBackslashes(title))}"`; }

  if (isExternal(safe, settings)) {
    return `${a} target="_blank" rel="noopener noreferrer">${textHtml}`
      + `<span class="visually-hidden"> ${escapeHtml(settings.newWindow)}</span></a>`;
  }

  return `${a}>${textHtml}</a>`;
};

const image = (alt, url, title) => {
  const safe = safeUrl(url);
  const altText = plainText(alt);

  if (safe === null) { return escapeHtml(altText); }

  return `<img src="${escapeHtml(safe)}" alt="${escapeHtml(altText)}"`
    + (title ? ` title="${escapeHtml(removeBackslashes(title))}"` : '') + '>';
};

/*
 * THE END OF A BRACKET: `[` ... `]`, taking nested brackets, escapes and
 * inline code into account. Returns the index of the `]`.
 */
const closingBracket = (t, i) => {
  let depth = 0;

  for (let j = i; j < t.length; j++) {
    const c = t[j];

    if (c === '\\') { j++; continue; }

    if (c === '`') {
      let n = 1;
      while (t[j + n] === '`') { n++; }
      const end = t.indexOf(t.slice(j, j + n), j + n);
      if (end > 0) { j = end + n - 1; continue; }
      j += n - 1;
      continue;
    }

    if (c === '[') { depth++; }

    if (c === ']') {
      depth--;
      if (depth === 0) { return j; }
    }
  }

  return -1;
};

/*
 * THE DESTINATION OF A LINK: `(address "title")`, from the opening
 * parenthesis. Returns { url, title, end } or null.
 */
const linkDestination = (t, i) => {
  if (t[i] !== '(') { return null; }

  let j = i + 1;
  while (t[j] === ' ' || t[j] === '\n') { j++; }

  let url = '';

  if (t[j] === '<') {
    const close = t.indexOf('>', j);
    if (close < 0) { return null; }
    url = t.slice(j + 1, close);
    j = close + 1;
  } else {
    let depth = 0;
    const start = j;

    for (; j < t.length; j++) {
      const c = t[j];
      if (c === '\\') { j++; continue; }
      if (c === ' ' || c === '\n') { break; }
      if (c === '(') { depth++; }
      if (c === ')') {
        if (depth === 0) { break; }
        depth--;
      }
    }

    url = t.slice(start, j);
  }

  while (t[j] === ' ' || t[j] === '\n') { j++; }

  let title = '';
  const open = t[j];

  if (open === '"' || open === "'" || open === '(') {
    const close = open === '(' ? ')' : open;
    let k = j + 1;

    while (k < t.length && t[k] !== close) {
      if (t[k] === '\\') { k++; }
      k++;
    }

    if (k >= t.length) { return null; }

    title = t.slice(j + 1, k);
    j = k + 1;
    while (t[j] === ' ' || t[j] === '\n') { j++; }
  }

  if (t[j] !== ')') { return null; }

  return { url, title, end: j + 1 };
};

const referenceKey = (text) => text.trim().replace(/\s+/g, ' ').toLowerCase();

/*
 * BARE ADDRESSES (as on GitHub): https://example.com becomes a link. The
 * final punctuation stays outside: "see https://a.fr.". Found on the RAW
 * text, before escaping: on the escaped text, an adjacent double quote
 * (&quot;) got into the address.
 */
const autolinkText = (raw, settings) => {
  let html = '';
  let last = 0;
  // As GitHub does: https://..., www.... (linked as https) and e-mail addresses.
  const re = /\b(?:https?:\/\/|www\.)[^\s<>"]+|[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(?:\.[A-Za-z0-9\-]+)+/g;
  let m;

  while ((m = re.exec(raw))) {
    let u = m[0];

    while (/[.,;:!?'*_~\-]$/.test(u) || (/\)$/.test(u) && u.split('(').length < u.split(')').length)) {
      u = u.slice(0, -1);
    }

    const target = /^www\./i.test(u) ? `https://${u}` : /@/.test(u) && !/^https?:/i.test(u) ? `mailto:${u}` : u;

    html += escapeHtml(raw.slice(last, m.index)) + link(escapeHtml(u), target, '', settings);
    last = m.index + u.length;
    re.lastIndex = last;
  }

  return html + escapeHtml(raw.slice(last));
};

const SAFE_HTML = /^<(\/?)(br|wbr|kbd|sup|sub|mark|u|ins|small|abbr|q|cite|var|samp|dfn)(\s+title="([^"<>]*)")?\s*\/?>/i;

const inline = (t, settings, noLinks) => {
  const pieces = [];
  let text = '';
  let i = 0;

  // The safe HTML tags opened here: a closing tag without an opening one
  // stays text, an opening tag without a closing one is closed at the end.
  const open = [];

  const pushText = () => {
    if (text) {
      pieces.push({ html: noLinks ? escapeHtml(text) : autolinkText(text, settings) });
      text = '';
    }
  };

  const pushHtml = (h) => {
    pushText();
    pieces.push({ html: h });
  };

  while (i < t.length) {
    const c = t[i];

    // Escape: \* stays a star; \ at the end of a line makes a break.
    if (c === '\\') {
      if (t[i + 1] === '\n') {
        pushHtml('<br>\n');
        i += 2;
        while (t[i] === ' ') { i++; }
        continue;
      }
      if (t[i + 1] && PUNCTUATION.indexOf(t[i + 1]) >= 0) { text += t[i + 1]; i += 2; continue; }
      text += c; i++; continue;
    }

    // Hard line break: two spaces or more before the end of the line.
    if (c === '\n') {
      const before = text.match(/ {2,}$/);
      text = text.replace(/ +$/, '');
      if (before) { pushHtml('<br>\n'); } else { text += '\n'; }
      i++;
      while (t[i] === ' ') { i++; }
      continue;
    }

    // Inline code.
    if (c === '`') {
      let n = 1;
      while (t[i + n] === '`') { n++; }
      const marker = t.slice(i, i + n);
      let j = i + n;
      let end = -1;

      while ((j = t.indexOf(marker, j)) >= 0) {
        if (t[j + n] !== '`' && t[j - 1] !== '`') { end = j; break; }
        while (t[j] === '`') { j++; }
      }

      if (end < 0) { text += marker; i += n; continue; }

      let code = t.slice(i + n, end).replace(/\n/g, ' ');
      if (/^ .*[^ ].* $/.test(code)) { code = code.slice(1, -1); }
      pushHtml(`<code>${escapeHtml(code)}</code>`);
      i = end + n;
      continue;
    }

    /*
     * A LITTLE HTML, HARMLESS (like GitHub, which lets a list of it through):
     * text tags, without attributes except the `title` of an abbreviation.
     * `<br>` is mostly used in table cells. Everything else (script, style,
     * iframe, on... attributes) comes out as TEXT.
     */
    if (c === '<') {
      const tag = SAFE_HTML.exec(t.slice(i));

      if (tag) {
        const name = tag[2].toLowerCase();
        const titleAttr = tag[3] && name === 'abbr' ? ` title="${escapeHtml(tag[4])}"` : '';

        const isVoid = name === 'br' || name === 'wbr';
        const closing = !!tag[1];
        const k = open.lastIndexOf(name);

        if ((tag[3] && name !== 'abbr') || (closing && (isVoid || k < 0))) {
          /* an attribute, or an orphan closing tag: refused, kept as text */
        } else {
          if (isVoid) {
            pushHtml(`<${name}>`);
          } else if (closing) {
            open.splice(k, 1);
            pushHtml(`</${name}>`);
          } else {
            open.push(name);
            pushHtml(`<${name}${titleAttr}>`);
          }
          i += tag[0].length;
          continue;
        }
      }
    }

    // An HTML comment inside a sentence is not displayed either.
    if (c === '<' && t.slice(i, i + 4) === '<!--') {
      const commentEnd = t.indexOf('-->', i + 4);
      if (commentEnd >= 0) { i = commentEnd + 3; continue; }
    }

    // An entity (&copy;, &#233;, &#x2014;) passes as is: the browser
    // displays it. A lone & stays a &.
    if (c === '&') {
      const entity = /^&(?:#[0-9]{1,7}|#[xX][0-9a-fA-F]{1,6}|[a-zA-Z][a-zA-Z0-9]{1,31});/.exec(t.slice(i));

      if (entity) { pushHtml(entity[0]); i += entity[0].length; continue; }
    }

    // Footnote reference: [^1] (as on GitHub), if it has its definition.
    if (c === '[' && t[i + 1] === '^' && !noLinks) {
      const ref = /^\[\^([^\]\s]+)\]/.exec(t.slice(i));
      const note = ref && settings.notes[referenceKey(ref[1])];

      if (note) {
        if (!note.number) { note.number = ++settings.noteCount; settings.noteOrder.push(note); }
        pushHtml(`<sup id="${note.refId}${note.refCount++ ? `-${note.refCount}` : ''}"><a href="#${note.id}">${note.number}</a></sup>`);
        i += ref[0].length;
        continue;
      }
    }

    // Automatic link: <https://example.com> or <name@example.com>.
    if (c === '<' && !noLinks) {
      const auto = /^<([a-zA-Z][a-zA-Z0-9+.\-]{1,31}:[^\s<>]*)>/.exec(t.slice(i));
      const email = /^<([a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~\-]+@[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*)>/.exec(t.slice(i));

      if (auto) { pushHtml(link(escapeHtml(auto[1]), auto[1], '', settings)); i += auto[0].length; continue; }
      if (email) { pushHtml(link(escapeHtml(email[1]), `mailto:${email[1]}`, '', settings)); i += email[0].length; continue; }
    }

    // Image or link.
    if ((c === '!' && t[i + 1] === '[') || (c === '[' && !noLinks)) {
      const isImage = c === '!';
      const o = isImage ? i + 1 : i;
      const f = closingBracket(t, o);

      if (f > 0) {
        const inside = t.slice(o + 1, f);
        const dest = linkDestination(t, f + 1);
        let ref = null;
        let next = f + 1;

        if (!dest) {
          // By reference: [text][key], [text][], or [text].
          const m = /^\[([^\]]*)\]/.exec(t.slice(f + 1));
          const key = m ? (m[1] || inside) : inside;
          ref = settings.references[referenceKey(key)] || null;
          if (ref && m) { next = f + 1 + m[0].length; }
        }

        if (dest || ref) {
          const url = dest ? dest.url : ref.url;
          const title = dest ? dest.title : ref.title;

          if (isImage) {
            pushHtml(image(inline(inside, settings, true), url, title));
          } else {
            pushHtml(link(inline(inside, settings, true), url, title, settings));
          }

          i = dest ? dest.end : next;
          continue;
        }
      }
    }

    // Emphasis delimiters: *, _ and ~.
    if (c === '*' || c === '_' || c === '~') {
      let k = 1;
      while (t[i + k] === c) { k++; }

      const previous = i > 0 ? t[i - 1] : '';
      const following = t[i + k] || '';
      const leftFlanking = !isBlank(following) && (!isPunctuation(following) || isBlank(previous) || isPunctuation(previous));
      const rightFlanking = !isBlank(previous) && (!isPunctuation(previous) || isBlank(following) || isPunctuation(following));
      let opens = leftFlanking;
      let closes = rightFlanking;

      // `_` does not split a word: file_name_here stays as it is.
      if (c === '_') {
        opens = leftFlanking && (!rightFlanking || isPunctuation(previous));
        closes = rightFlanking && (!leftFlanking || isPunctuation(following));
      }

      pushText();
      pieces.push({ char: c, n: k, opens, closes });
      i += k;
      continue;
    }

    text += c;
    i++;
  }

  pushText();

  while (open.length) { pieces.push({ html: `</${open.pop()}>` }); }

  return resolveEmphasis(pieces);
};

const renderPiece = (piece) => (piece.char ? piece.char.repeat(piece.n) : piece.html);

/*
 * EMPHASIS: each closing delimiter looks backwards for an opening one of the
 * same character. Two on each side give <strong> (or <del> for ~~), a single
 * one gives <em>. What is left without a partner comes out as is.
 */
const resolveEmphasis = (m) => {
  for (let c = 0; c < m.length; c++) {
    const closer = m[c];

    if (!closer.char || !closer.closes || closer.n === 0) { continue; }

    for (let o = c - 1; o >= 0; o--) {
      const opener = m[o];

      if (!opener.char || opener.char !== closer.char || !opener.opens || opener.n === 0) { continue; }

      let tag;
      let used;

      if (closer.char === '~') {
        if (opener.n < 2 || closer.n < 2) { continue; }
        tag = 'del';
        used = 2;
      } else {
        used = opener.n >= 2 && closer.n >= 2 ? 2 : 1;
        tag = used === 2 ? 'strong' : 'em';
      }

      const inside = m.slice(o + 1, c).map(renderPiece).join('');

      opener.n -= used;
      closer.n -= used;
      m.splice(o + 1, c - o - 1, { html: `<${tag}>${inside}</${tag}>` });
      // The closer is now at o + 2: the loop comes back to it, and if it
      // still has delimiters left (***a***), it looks again.
      c = o + 1;

      break;
    }
  }

  return m.map(renderPiece).join('');
};

/* --------------------------------------------------------------------------
   BLOCKS
   -------------------------------------------------------------------------- */

const RE = {
  blank: /^\s*$/,
  fence: /^( {0,3})(`{3,}|~{3,})(.*)$/,
  heading: /^ {0,3}(#{1,6})(?:[ \t]+(.*?))?(?:[ \t]+#+)?[ \t]*$/,
  rule: /^ {0,3}([-*_])(?:[ \t]*\1){2,}[ \t]*$/,
  quote: /^ {0,3}> ?(.*)$/,
  bullet: /^( {0,3})([-*+]|\d{1,9}[.)])([ \t]+|$)(.*)$/,
  underline: /^ {0,3}(=+|-+)[ \t]*$/,
  delimiters: /^ *\|? *:?-+:? *(\| *:?-+:? *)*\|? *$/,
  readMore: /^ {0,3}<!--[ \t]*readmore[ \t]*-->[ \t]*$/i,
  comment: /^ {0,3}<!--/
};

const indentOf = (line) => line.match(/^ */)[0].length;

const splitCells = (line) => {
  const l = line.trim().replace(/^\|/, '').replace(/(^|[^\\])\|$/, '$1');
  const list = [];
  let current = '';

  for (let i = 0; i < l.length; i++) {
    if (l[i] === '\\' && l[i + 1] === '|') { current += '|'; i++; continue; }
    if (l[i] === '|') { list.push(current.trim()); current = ''; continue; }
    current += l[i];
  }

  list.push(current.trim());

  return list;
};

const isTable = (lines, i) => {
  const head = lines[i];
  const below = lines[i + 1];

  if (below === undefined || head.indexOf('|') < 0) { return false; }
  if (!RE.delimiters.test(below) || (below.indexOf('|') < 0 && head.indexOf('|') < 0)) { return false; }

  return splitCells(head).length === splitCells(below).length;
};

/*
 * A LINE THAT OPENS ANOTHER BLOCK: it stops a paragraph. A numbered list
 * interrupts a paragraph only if it starts at 1 (otherwise "in\n1998. Then"
 * would cut the sentence).
 */
const startsBlock = (line) => {
  if (RE.heading.test(line) || RE.fence.test(line) || RE.rule.test(line) || RE.quote.test(line)
    || RE.comment.test(line)) {
    return true;
  }

  const p = RE.bullet.exec(line);

  return !!(p && p[4].trim() !== '' && (/^[-*+]$/.test(p[2]) || /^1[.)]$/.test(p[2])));
};

const renderHeading = (level, text, settings) => {
  // `minLevel`: 2 when the article title holds the h1 (automatic mode);
  // never below h6.
  const n = Math.min(6, Math.max(settings.minLevel, level + settings.shift));
  const html = inline(text.trim(), settings, false);
  const id = makeId(plainText(html), settings.taken);

  return `<h${n} id="${id}">${html}</h${n}>`;
};

const blocks = (lines, settings, tight) => {
  const output = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];
    let m;

    if (RE.blank.test(line)) { i++; continue; }

    /*
     * INDENTED CODE: four leading spaces (original Markdown). Added on
     * 11 October 2026 ("all known Markdown must be understood", Cyrille).
     * An indented line that CONTINUES a paragraph stays text: only a block
     * separated by a blank line is code.
     */
    if (/^ {4}/.test(line)) {
      const indented = [];

      while (i < lines.length && (/^ {4}/.test(lines[i]) || RE.blank.test(lines[i]))) {
        indented.push(lines[i].replace(/^ {4}/, ''));
        i++;
      }

      while (indented.length && RE.blank.test(indented[indented.length - 1])) { indented.pop(); }

      output.push(`<pre><code>${escapeHtml(indented.join('\n'))}\n</code></pre>`);
      continue;
    }

    // Code block: ``` or ~~~, up to the closing fence (or the end).
    if ((m = RE.fence.exec(line)) && !(m[2][0] === '`' && m[3].indexOf('`') >= 0)) {
      const indent = m[1].length;
      const marker = m[2];
      const language = m[3].trim().split(/\s+/)[0].replace(/[^\w+#.\-]/g, '');
      const code = [];
      const closing = new RegExp(`^ {0,3}${marker[0]}{${marker.length},}[ \\t]*$`);

      i++;

      while (i < lines.length && !closing.test(lines[i])) {
        code.push(lines[i].replace(new RegExp(`^ {0,${indent}}`), ''));
        i++;
      }

      i++;
      output.push(`<pre><code${language ? ` class="language-${escapeHtml(language)}"` : ''}>`
        + escapeHtml(code.join('\n')) + (code.length ? '\n' : '') + '</code></pre>');
      continue;
    }

    // Heading: the level is SHIFTED (section 3), never below h6.
    if ((m = RE.heading.exec(line))) {
      output.push(renderHeading(m[1].length, m[2] || '', settings));
      i++;
      continue;
    }

    /*
     * JOOMLA'S "READ MORE" (Cyrille's decision, 11 October 2026): a line
     * holding only `<!-- readmore -->` gives `<hr id="system-readmore">`, the
     * tag the core "Read more" button inserts. It is the only HTML Markus
     * lets through, and only alone on its line: elsewhere, text stays text.
     * An HTML comment, because any other Markdown reader (GitHub, a text
     * editor) hides it instead of displaying it.
     */
    if (RE.readMore.test(line)) {
      output.push('<hr id="system-readmore">');
      i++;
      continue;
    }

    /*
     * AN HTML COMMENT (<!-- ... -->, on one or several lines) is not
     * displayed, as on GitHub. A .md file exported from a blog often starts
     * with one (original address, date): it came out as text and hid the
     * "#" of the heading (seen by Cyrille, 11 October 2026).
     */
    if (RE.comment.test(line)) {
      while (i < lines.length && lines[i].indexOf('-->') < 0) { i++; }
      i++;
      continue;
    }

    if (RE.rule.test(line)) {
      output.push('<hr>');
      i++;
      continue;
    }

    // Quote: the `>` lines, and those that continue its sentence.
    if (RE.quote.test(line)) {
      const inside = [];

      while (i < lines.length) {
        const q = RE.quote.exec(lines[i]);

        if (q) {
          inside.push(q[1]);
        } else if (!RE.blank.test(lines[i]) && inside.length && !RE.blank.test(inside[inside.length - 1]) && !startsBlock(lines[i])) {
          inside.push(lines[i]);
        } else {
          break;
        }

        i++;
      }

      output.push(`<blockquote>\n${blocks(inside, settings, false)}\n</blockquote>`);
      continue;
    }

    if (RE.bullet.test(line)) {
      const list = renderList(lines, i, settings);
      output.push(list.html);
      i = list.end;
      continue;
    }

    if (isTable(lines, i)) {
      const table = renderTable(lines, i, settings);
      output.push(table.html);
      i = table.end;
      continue;
    }

    // Paragraph, or underlined heading (= or - under the text).
    const para = [line];
    let level = 0;

    i++;

    while (i < lines.length && !RE.blank.test(lines[i])) {
      const s = RE.underline.exec(lines[i]);

      if (s) { level = s[1][0] === '=' ? 1 : 2; i++; break; }
      if (startsBlock(lines[i]) || isTable(lines, i)) { break; }

      para.push(lines[i]);
      i++;
    }

    const text = para.join('\n').replace(/^ +/, '').replace(/\s+$/, '');

    if (level) {
      output.push(renderHeading(level, text, settings));
    } else {
      const html = inline(text, settings, false);
      output.push(tight ? html : `<p>${html}</p>`);
    }
  }

  return output.join('\n');
};

/*
 * LISTS, NESTED. A line belongs to the current item if it is indented
 * relative to its bullet, or if it continues its sentence. Deliberate
 * tolerance: "1. a" followed by "- b" indented by two spaces nests, as
 * whoever typed it expects, even though the strict rule asks for three.
 */
const renderList = (lines, i, settings) => {
  const first = RE.bullet.exec(lines[i]);
  const ordered = /\d/.test(first[2]);
  const sign = first[2].slice(-1);
  const start = ordered ? parseInt(first[2], 10) : 1;
  const items = [];
  let loose = false;

  const sameList = (l) => {
    const p = l === undefined ? null : RE.bullet.exec(l);

    return !!p && /\d/.test(p[2]) === ordered && p[2].slice(-1) === sign;
  };

  while (i < lines.length) {
    if (!sameList(lines[i])) { break; }

    const m = RE.bullet.exec(lines[i]);

    const bulletIndent = m[1].length;
    const content = m[3].length > 4 ? bulletIndent + m[2].length + 1 : bulletIndent + m[2].length + m[3].length;
    const body = [m[3].length > 4 ? m[3].slice(1) + m[4] : m[4]];
    let blankBefore = false;

    i++;

    while (i < lines.length) {
      const l = lines[i];

      if (RE.blank.test(l)) { body.push(''); blankBefore = true; i++; continue; }

      const r = indentOf(l);

      if (r > bulletIndent && (r >= content || RE.bullet.test(l))) {
        body.push(l.slice(Math.min(r, content)));
        blankBefore = false;
        i++;
        continue;
      }

      // Lazy continuation: the sentence goes on without indentation.
      if (!blankBefore && !startsBlock(l) && !RE.bullet.test(l) && !isTable(lines, i)) {
        body.push(l);
        i++;
        continue;
      }

      break;
    }

    // Blank lines at the end of an item separate it from the next one, if
    // that one belongs to the same list (a list with another sign starts
    // another list).
    while (body.length && body[body.length - 1] === '') {
      body.pop();
      if (sameList(lines[i])) { loose = true; }
    }

    if (body.indexOf('') >= 0) { loose = true; }

    /*
     * TASK LIST (GitHub): "- [ ] to do", "- [x] done". A disabled checkbox,
     * as on GitHub: a screen reader says "checkbox, checked" or "not
     * checked".
     */
    const task = /^\[([ xX])\][ \t]+/.exec(body[0]);

    if (task) { body[0] = body[0].slice(task[0].length); }

    items.push({ body, task: task ? (task[1] === ' ' ? 'unchecked' : 'checked') : '' });

    if (i < lines.length && RE.blank.test(lines[i - 1] || '') && !RE.bullet.test(lines[i])) { break; }
  }

  const tag = ordered ? 'ol' : 'ul';
  const html = `<${tag}${ordered && start !== 1 ? ` start="${start}"` : ''}>\n`
    + items.map((item) => {
      let itemHtml = blocks(item.body, settings, !loose);

      if (item.task) {
        const box = `<input type="checkbox" disabled${item.task === 'checked' ? ' checked' : ''}> `;
        itemHtml = /^<p>/.test(itemHtml) ? `<p>${box}${itemHtml.slice(3)}` : box + itemHtml;
      }

      return `<li>${itemHtml}</li>`;
    }).join('\n')
    + `\n</${tag}>`;

  return { html, end: i };
};

const renderTable = (lines, i, settings) => {
  const head = splitCells(lines[i]);
  const width = head.length;
  const body = [];

  /*
   * ALIGNMENT (:--- :---: ---:) and DRESSING (Cyrille's decision, 11 October
   * 2026): a table without a class stays bare under a Bootstrap template.
   * With the "dressed tables" setting (the default), Markus sets Bootstrap's
   * `table` class, and the alignment through its `text-start`,
   * `text-center`, `text-end` classes. Never a `style=""`. Without the
   * setting, neither class nor alignment.
   */
  const alignments = splitCells(lines[i + 1]).map((d) => {
    const left = /^:/.test(d);
    const right = /:$/.test(d);
    return left && right ? 'text-center' : right ? 'text-end' : left ? 'text-start' : '';
  });

  i += 2;

  while (i < lines.length && !RE.blank.test(lines[i]) && lines[i].indexOf('|') >= 0 && !startsBlock(lines[i])) {
    body.push(splitCells(lines[i]));
    i++;
  }

  const row = (list, tag) => {
    const cells = [];

    for (let k = 0; k < width; k++) {
      const cls = settings.tableClass && alignments[k] ? ` class="${alignments[k]}"` : '';
      cells.push(`<${tag}${cls}>${inline(list[k] || '', settings, false)}</${tag}>`);
    }

    return `<tr>${cells.join('')}</tr>`;
  };

  const html = `<table${settings.tableClass ? ` class="${settings.tableClass}"` : ''}>\n<thead>\n${row(head, 'th')}\n</thead>`
    + (body.length ? `\n<tbody>\n${body.map((l) => row(l, 'td')).join('\n')}\n</tbody>` : '')
    + '\n</table>';

  return { html, end: i };
};

/*
 * REFERENCE DEFINITIONS: `[key]: https://example.com "Title"`. Collected
 * first (they can be used before they are written), then removed from the
 * text. Never inside a code block.
 */
const collectReferences = (lines) => {
  const found = {};
  const notes = {};
  const kept = [];
  let fence = null;
  let currentNote = null;

  lines.forEach((l) => {
    const b = RE.fence.exec(l);

    // The rest of a footnote: indented lines under its definition.
    if (currentNote && !fence) {
      if (/^ {2,}\S/.test(l)) { currentNote.text += `\n${l.trim()}`; return; }
      currentNote = null;
    }

    if (fence) {
      if (b && b[2][0] === fence[0] && b[2].length >= fence.length && !b[3].trim()) { fence = null; }
      kept.push(l);
      return;
    }

    if (b) { fence = b[2]; kept.push(l); return; }

    // Footnote (GitHub): [^1]: The text of the note.
    const n = /^ {0,3}\[\^([^\]\s]+)\]:[ \t]*(.*)$/.exec(l);

    if (n) {
      const noteKey = referenceKey(n[1]);
      if (!notes[noteKey]) { notes[noteKey] = currentNote = { key: n[1], text: n[2] }; }
      return;
    }

    const d = /^ {0,3}\[([^\]]+)\]:[ \t]*<?([^\s>]+)>?(?:[ \t]+(?:"([^"]*)"|'([^']*)'|\(([^)]*)\)))?[ \t]*$/.exec(l);

    if (d) {
      const key = referenceKey(d[1]);
      if (!found[key]) { found[key] = { url: d[2], title: d[3] || d[4] || d[5] || '' }; }
      return;
    }

    kept.push(l);
  });

  return { lines: kept, found, notes };
};

// The default domain: the current host, when there is one (not in Node).
const currentHost = () => (globalThis.location ? globalThis.location.hostname : '');

const clampShift = (value) => (value === undefined ? 1 : Math.max(0, Math.min(5, parseInt(value, 10) || 0)));

// `tableClass`: true (the default) or any truthy value gives Bootstrap's `table`.
const tableClassOf = (value) => (value === undefined ? 'table' : (value ? 'table' : ''));

const makeSettings = (o) => {
  const settings = {
    shift: clampShift(o.shift),
    minLevel: o.minLevel === undefined ? 1 : Math.max(1, Math.min(6, parseInt(o.minLevel, 10) || 1)),
    externalLinks: o.externalLinks !== false,
    domain: o.domain || currentHost(),
    newWindow: o.newWindow || '(nouvelle fenêtre)',
    noteBackLabel: o.noteBackLabel || 'Revenir au texte',
    tableClass: tableClassOf(o.tableClass),
    taken: {},
    references: {},
    notes: {},
    noteOrder: [],
    noteCount: 0
  };

  (o.takenIds || []).forEach((id) => { settings.taken[id] = true; });

  return settings;
};

// Windows line endings, tabs at the start of a line, byte order mark.
const splitLines = (text) => String(text || '').replace(/^\ufeff/, '').replace(/\r\n?/g, '\n').split('\n')
  .map((l) => l.replace(/^[ \t]+/, (r) => r.replace(/\t/g, '    ')));

/**
 * Converts Markdown to HTML (see the options at the top of this file).
 *
 * @param {string} text     The Markdown.
 * @param {object} options  shift, minLevel, externalLinks, domain, newWindow,
 *                          noteBackLabel, tableClass, takenIds.
 * @returns {string} The HTML.
 */
export const markdownToHtml = (text, options) => {
  const o = options || {};
  const settings = makeSettings(o);
  const refs = collectReferences(splitLines(text));

  settings.references = refs.found;

  // Footnotes: their ids are taken before everything else, so that the
  // reference and the note carry the same one, with no duplicate in the
  // article.
  Object.keys(refs.notes).forEach((key) => {
    const n = refs.notes[key];
    n.id = makeId(`note-${n.key}`, settings.taken);
    n.refId = makeId(`appel-${n.key}`, settings.taken);
    n.refCount = 0;
  });
  settings.notes = refs.notes;

  let html = blocks(refs.lines, settings, false);

  /*
   * FOOTNOTES, AT THE END: a horizontal rule, then the numbered list in the
   * order of the references. Each one ends with a back link to its
   * reference, named for screen readers. A note never referenced does not
   * come out (as on GitHub).
   */
  if (settings.noteOrder.length) {
    html += '\n<hr>\n<ol>\n' + settings.noteOrder.map((n) => `<li id="${n.id}">${inline(n.text, settings, false)}`
      + ` <a href="#${n.refId}" aria-label="${escapeHtml(settings.noteBackLabel)}">\u21a9</a></li>`).join('\n') + '\n</ol>';
  }

  return html;
};

/**
 * THE LEVEL 1 HEADINGS OF THE TEXT (automatic mode, Cyrille's decisions,
 * 11 October 2026). In Markdown, "#" is the document title. THE FIRST "#",
 * wherever it is, becomes the article title and leaves the body; "##" then
 * gives h2. Only after that: if other "#" remain, `others` counts them, and
 * the panel offers to shift everything one step (# to h2, ## to h3...). Code
 * blocks and HTML comments do not count.
 *
 * Returns { title, rest, others }:
 *   title   the plain text of the first level 1 heading, or null if none;
 *   rest    the Markdown without that heading (the whole text if none);
 *   others  how many other level 1 headings the text holds.
 *
 *   headings('<!-- note -->\n# My title\n\nText')
 *   // { title: 'My title', rest: '<!-- note -->\n\nText', others: 0 }
 *
 * @param {string} text  The Markdown.
 * @returns {{title: (string|null), rest: string, others: number}}
 */
export const headings = (text) => {
  const lines = splitLines(text);
  let fence = null;
  let inComment = false;
  let title = null;
  let start = -1;
  let end = -1;
  let others = 0;
  let previous = '';

  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    const b = RE.fence.exec(l);

    if (inComment) {
      if (l.indexOf('-->') >= 0) { inComment = false; }
      previous = '';
      continue;
    }
    if (fence) {
      if (b && b[2][0] === fence[0] && b[2].length >= fence.length && !b[3].trim()) { fence = null; }
      previous = '';
      continue;
    }
    if (b) { fence = b[2]; previous = ''; continue; }
    if (RE.comment.test(l)) {
      inComment = l.indexOf('-->') < 0;
      previous = '';
      continue;
    }

    const h = /^ {0,3}#(?:[ \t]+(.*?))?(?:[ \t]+#+)?[ \t]*$/.exec(l);
    // A heading underlined with "=": the line before is plain text.
    const underlined = !h && /^ {0,3}=+[ \t]*$/.test(l) && previous && !startsBlock(previous)
      && !/^ {4}/.test(previous) && !RE.bullet.test(previous);

    if (h || underlined) {
      if (title === null) {
        title = (h ? h[1] || '' : previous).trim();
        start = h ? i : i - 1;
        end = i;
      } else {
        others++;
      }
    }

    previous = RE.blank.test(l) || h ? '' : l;
  }

  if (title === null) { return { title: null, rest: text, others }; }

  const settings = makeSettings({});
  const plain = plainText(inline(title, settings, true)).replace(/\s+/g, ' ').trim();

  return { title: plain, rest: lines.slice(0, start).concat(lines.slice(end + 1)).join('\n'), others };
};

/* ==========================================================================
   THE WAY BACK: FROM THE ARTICLE'S HTML TO MARKDOWN
   ==========================================================================

   Cyrille's request, 11 October 2026: "how do I correct a text in a Joomla
   article in Markdown?". The selection (or the whole article) is taken back
   as Markdown, corrected, and "Replace" puts the HTML back.

   THE RULE: WHAT COMES BACK MUST GIVE THE SAME HTML AGAIN. Taking back a
   passage written by Markus, then replacing it without touching it, changes
   nothing in the article (the round trip tests).

   WHAT MARKDOWN CANNOT WRITE is NEVER removed silently (common CLAUDE.md,
   section 6): a style, a class, an image dimension, a page break, a video, a
   frame... Each loss is counted and returned with the text; the panel shows
   it BEFORE taking back, and the user chooses.

     const r = htmlToMarkdown(html, { shift: 1, domain: 'site.fr' });
     r.text     // the Markdown
     r.losses   // [{ code: 'style', detail: '', n: 2 }, ...]
   ========================================================================== */

// Containers with no meaning of their own: opened, their content stays.
// (FONT and CENTER are opened too, but count as a lost tag.)
const NEUTRAL = { DIV: 1, SPAN: 1, FONT: 0, CENTER: 0 };

// Blocks that are opened, but whose tag itself carries a lost meaning.
const WRAPPERS = {
  SECTION: 1, ARTICLE: 1, ASIDE: 1, NAV: 1, HEADER: 1, FOOTER: 1, MAIN: 1,
  FIGURE: 1, FIGCAPTION: 1, DETAILS: 1, SUMMARY: 1, ADDRESS: 1, CENTER: 1,
  DL: 1, DT: 1, DD: 1, FORM: 1, FIELDSET: 1
};

// What disappears entirely: nothing to get out of it as text.
const DROPPED = {
  IFRAME: 1, VIDEO: 1, AUDIO: 1, OBJECT: 1, EMBED: 1, CANVAS: 1, SVG: 1,
  SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, INPUT: 1, SELECT: 1, TEXTAREA: 1,
  BUTTON: 1, MAP: 1, PICTURE: 0, SOURCE: 1
};

const HTML_BLOCKS = /^(P|H[1-6]|UL|OL|LI|BLOCKQUOTE|PRE|TABLE|THEAD|TBODY|TFOOT|TR|HR|DIV|SECTION|ARTICLE|ASIDE|NAV|HEADER|FOOTER|MAIN|FIGURE|FIGCAPTION|DETAILS|SUMMARY|ADDRESS|CENTER|DL|DT|DD|FORM|FIELDSET|IFRAME|VIDEO|AUDIO|OBJECT|EMBED|CANVAS|SCRIPT|STYLE|NOSCRIPT)$/;

const addLoss = (ctx, code, detail) => {
  const key = `${code}|${detail || ''}`;
  ctx.losses[key] = (ctx.losses[key] || 0) + 1;
};

/*
 * ATTRIBUTES: those Markdown can say again pass, and so do those Markus sets
 * by itself (the `id` of a heading, `target` and `rel` of an external link).
 * Everything else is a loss, named.
 */
const checkAttributes = (el, ctx, allowed) => {
  for (let i = 0; i < el.attributes.length; i++) {
    const name = el.attributes[i].name.toLowerCase();

    if (allowed.indexOf(name) >= 0) { continue; }
    if (name === 'style') { addLoss(ctx, 'style'); continue; }
    if (name === 'class') { addLoss(ctx, 'classe', el.getAttribute('class')); continue; }
    if (/^data-mce-/.test(name)) { continue; }

    addLoss(ctx, 'attribut', name);
  }
};

// A text of the article, said in Markdown: its signs must trigger nothing.
// "2 * 3" or "file_name" stay what they are.
const escapeMd = (t) => {
  /*
   * BRACKETS are escaped only if they would make a link: "[text](...)" or
   * "[text][...]". Escaped everywhere, the boxes of a task list ("[ ] to
   * do") came back as "\[ \]", unreadable (seen by Cyrille on the test
   * bench, 11 October 2026).
   */
  return t.replace(/([\\`*_~])/g, '\\$1')
    .replace(/\[([^\[\]]*)\](?=[(\[])/g, '\\[$1\\]')
    // A "&copy;" written out in the article stays text.
    .replace(/&(?=(?:#[0-9]{1,7}|#[xX][0-9a-fA-F]{1,6}|[a-zA-Z][a-zA-Z0-9]{1,31});)/g, '\\&')
    // A "<kbd>" or "<https://...>" written as text does not become a tag.
    .replace(/<(?=\/?(?:br|wbr|kbd|sup|sub|mark|u|ins|small|abbr|q|cite|var|samp|dfn)\b|[a-zA-Z][a-zA-Z0-9+.\-]{1,31}:)/gi, '\\<');
};

// What, at the start of a line, would open a block: a heading, a quote, a
// list, a horizontal rule (and a comment, a footnote, an underline).
const escapeLineStart = (line) => line
  .replace(/^(\s*)([#>+])/, '$1\\$2')
  .replace(/^(\s*)(<!--|\[\^)/, '$1\\$2')
  .replace(/^(\s*)-(?=\s|-|$)/, '$1\\-')
  .replace(/^(\s*)=/, '$1\\=')
  .replace(/^(\s*)(\d{1,9})([.)])(?=\s|$)/, '$1$2\\$3');

const wrapMarker = (marker, inside) => {
  // "** bold **" would no longer be bold: the spaces go outside.
  const m = /^(\s*)([\s\S]*?)(\s*)$/.exec(inside);

  return m[2] ? m[1] + marker + m[2] + marker + m[3] : inside;
};

const inlineCode = (text) => {
  let longest = 0;
  (text.match(/`+/g) || []).forEach((r) => { longest = Math.max(longest, r.length); });

  const marker = '`'.repeat(longest + 1);
  const pad = /^`|`$/.test(text) || /^ .* $/.test(text) ? ' ' : '';

  return marker + pad + text + pad + marker;
};

const urlMd = (url) => {
  // An address with a space or an unbalanced parenthesis is written <in angle brackets>.
  const opening = (url.match(/\(/g) || []).length;
  const closing = (url.match(/\)/g) || []).length;

  return /[\s<>]/.test(url) || opening !== closing ? `<${url.replace(/>/g, '%3E')}>` : url;
};

const titleMd = (title) => (title ? ` "${title.replace(/"/g, '\\"')}"` : '');

// "One<br>\ntwo": the HTML line break became a space at the start of the
// next line.
const trimAfterBreak = (t) => t.replace(/\\\n +/g, '\\\n');

const inlineMd = (nodes, ctx) => {
  let output = '';

  for (let i = 0; i < nodes.length; i++) { output += nodeInline(nodes[i], ctx); }

  return trimAfterBreak(output);
};

// The text tags Markus lets through: they come back as they are.
const safeHtmlMd = (n, ctx) => {
  const name = n.nodeName.toLowerCase();
  const title = name === 'abbr' && n.getAttribute('title');

  checkAttributes(n, ctx, name === 'abbr' ? ['title'] : []);

  if (name === 'br' || name === 'wbr') { return `<${name}>`; }

  return `<${name}${title ? ` title="${title.replace(/"/g, '&quot;')}"` : ''}>`
    + inlineMd(n.childNodes, ctx) + `</${name}>`;
};

const linkMd = (a, ctx) => {
  const href = a.getAttribute('href');

  /*
   * THE "(nouvelle fenêtre)" MENTION that Markus set goes away: it will come
   * back by itself on replacement. Another `visually-hidden` is the author's
   * text: it comes out as a class loss.
   */
  const children = Array.from(a.childNodes).filter((e) => !(e.nodeType === 1 && e.nodeName.toUpperCase() === 'SPAN'
    && e.getAttribute('class') === 'visually-hidden'
    && e.textContent.trim() === ctx.newWindow));

  const external = href && isExternal(href, ctx);
  const allowed = ['href', 'title'];

  // `target` and `rel`: those Markus sets on an external link pass.
  if (external && a.getAttribute('target') === '_blank') { allowed.push('target'); }
  if (external && /^\s*noopener noreferrer\s*$/.test(a.getAttribute('rel') || '')) { allowed.push('rel'); }

  checkAttributes(a, ctx, allowed);

  const text = inlineMd(children, ctx);

  if (!href) { return text; }

  const raw = plainText(text.replace(/\\(.)/g, '$1'));
  const title = a.getAttribute('title');

  // <https://example.com> rather than the bare address: a "_" in the
  // address never opens an italic there.
  if (!title && raw === href && /^https?:\/\//i.test(href)) { return `<${href}>`; }
  if (!title && `mailto:${raw}` === href) { return `<${raw}>`; }

  return `[${text}](${urlMd(href)}${titleMd(title)})`;
};

const nodeInline = (n, ctx) => {
  if (n.nodeType === 3) {
    // HTML white space comes down to one space; the non-breaking space stays.
    return escapeMd(n.nodeValue.replace(/[ \t\n\r\f]+/g, ' '));
  }

  if (n.nodeType === 8) { addLoss(ctx, 'commentaire'); return ''; }
  if (n.nodeType !== 1) { return ''; }

  const name = n.nodeName.toUpperCase();

  if (DROPPED[name]) { addLoss(ctx, 'balise', name.toLowerCase()); return ''; }

  switch (name) {
    case 'STRONG': case 'B':
      checkAttributes(n, ctx, []);
      return wrapMarker('**', inlineMd(n.childNodes, ctx));

    case 'EM': case 'I':
      checkAttributes(n, ctx, []);
      return wrapMarker('*', inlineMd(n.childNodes, ctx));

    case 'DEL': case 'S': case 'STRIKE':
      checkAttributes(n, ctx, []);
      return wrapMarker('~~', inlineMd(n.childNodes, ctx));

    case 'CODE':
      checkAttributes(n, ctx, []);
      return inlineCode(n.textContent.replace(/\n/g, ' '));

    case 'BR':
      // In a table cell, the break is written <br> (safe HTML).
      if (ctx.inTable) { return '<br>'; }
      // The white space following a <br> in the HTML has no meaning: it
      // goes (see `trimAfterBreak`).
      return '\\\n';

    case 'IMG':
      checkAttributes(n, ctx, ['src', 'alt', 'title']);
      return `![${escapeMd(n.getAttribute('alt') || '')}](${urlMd(n.getAttribute('src') || '')}`
        + `${titleMd(n.getAttribute('title'))})`;

    case 'A':
      return linkMd(n, ctx);

    case 'SPAN':
      if (n.attributes.length) { checkAttributes(n, ctx, []); }
      return inlineMd(n.childNodes, ctx);

    case 'SUP': {
      // The reference of a footnote set by Markus: [^key].
      const ref = n.firstElementChild;
      if (/^appel-/.test(n.getAttribute('id') || '') && n.children.length === 1 && ref.nodeName.toUpperCase() === 'A'
        && /^#note-/.test(ref.getAttribute('href') || '')) {
        return `[^${ref.getAttribute('href').replace(/^#note-/, '')}]`;
      }
      return safeHtmlMd(n, ctx);
    }

    case 'WBR': case 'KBD': case 'SUB': case 'MARK': case 'U': case 'INS':
    case 'SMALL': case 'ABBR': case 'Q': case 'CITE': case 'VAR': case 'SAMP': case 'DFN':
      return safeHtmlMd(n, ctx);

    default:
      // A text tag Markdown ignores: its text stays.
      if (!NEUTRAL[name]) { addLoss(ctx, 'balise', name.toLowerCase()); }
      checkAttributes(n, ctx, []);
      return inlineMd(n.childNodes, ctx);
  }
};

const indentBlock = (text, prefix, continuation) => text.split('\n')
  .map((l, i) => {
    if (i === 0) { return prefix + l; }
    return l === '' ? '' : continuation + l;
  }).join('\n');

const preMd = (el, ctx) => {
  checkAttributes(el, ctx, []);

  const code = el.firstElementChild && el.firstElementChild.nodeName.toUpperCase() === 'CODE' ? el.firstElementChild : el;
  let language = '';

  if (code !== el) {
    const cls = code.getAttribute('class') || '';
    const l = /^language-([\w+#.\-]+)$/.exec(cls);
    if (l) { language = l[1]; } else if (cls) { addLoss(ctx, 'classe', cls); }
    for (let i = 0; i < code.attributes.length; i++) {
      if (code.attributes[i].name !== 'class') { addLoss(ctx, 'attribut', code.attributes[i].name); }
    }
  }

  const text = code.textContent.replace(/\n$/, '');
  let longest = 2;
  (text.match(/^`{3,}/gm) || []).forEach((r) => { longest = Math.max(longest, r.length); });
  const fence = '`'.repeat(longest + 1);

  return `${fence}${language}\n${text}\n${fence}`;
};

const listMd = (el, ctx) => {
  const ordered = el.nodeName.toUpperCase() === 'OL';
  const start = ordered ? parseInt(el.getAttribute('start') || '1', 10) || 1 : 1;

  checkAttributes(el, ctx, ordered ? ['start'] : []);

  const items = [];

  /*
   * LOOSE OR TIGHT: a list with an item holding a <p> is loose (a blank line
   * between the items, and inside each). Tight, the blocks of an item follow
   * each other without a blank line: otherwise the list would come back
   * loose, and the HTML would change.
   */
  const loose = Array.from(el.children).some((li) => Array.from(li.children).some((c) => c.nodeName.toUpperCase() === 'P'));

  Array.from(el.children).forEach((li) => {
    if (li.nodeName.toUpperCase() !== 'LI') { items.push(blockMd(li, ctx)); return; }

    checkAttributes(li, ctx, []);

    /*
     * A TASK: the checkbox at the start of the item (or of its first
     * paragraph) becomes "[ ]" or "[x]" again.
     */
    let task = '';
    let source = li;
    const target = li.firstElementChild && li.firstElementChild.nodeName.toUpperCase() === 'P' ? li.firstElementChild : li;
    const box = target.firstChild && target.firstChild.nodeType === 3 && !target.firstChild.nodeValue.trim()
      ? target.firstChild.nextSibling : target.firstChild;

    if (box && box.nodeType === 1 && box.nodeName.toUpperCase() === 'INPUT' && box.getAttribute('type') === 'checkbox') {
      checkAttributes(box, ctx, ['type', 'disabled', 'checked']);
      task = box.hasAttribute('checked') ? '[x] ' : '[ ] ';
      source = li.cloneNode(true);
      const copy = source.querySelector('input[type="checkbox"]');
      const after = copy.nextSibling;
      if (after && after.nodeType === 3) { after.nodeValue = after.nodeValue.replace(/^ /, ''); }
      copy.remove();
    }

    const body = task + blocksMd(source.childNodes, ctx, loose ? '\n\n' : '\n');

    const marker = ordered ? `${start + items.length}. ` : '- ';
    items.push(indentBlock(body, marker, ' '.repeat(marker.length)));
  });

  return items.join(loose ? '\n\n' : '\n');
};

const tableMd = (el, ctx) => {
  // The class Markus sets (`table`, "dressed tables" setting) passes;
  // another one is a loss.
  if (ctx.tableClass && el.getAttribute('class') === ctx.tableClass) {
    checkAttributes(el, ctx, ['class']);
  } else {
    checkAttributes(el, ctx, []);
  }

  const rows = [];
  const alignments = [];

  Array.from(el.querySelectorAll('tr')).forEach((tr) => {
    if (tr.closest('table') !== el) { return; }

    rows.push(Array.from(tr.children).map((c, k) => {
      // Alignment: the Bootstrap classes Markus sets.
      const a = /^text-(start|center|end)$/.exec(c.getAttribute('class') || '');
      if (a && ctx.tableClass) {
        alignments[k] = alignments[k] || a[1];
        checkAttributes(c, ctx, ['class']);
      } else {
        checkAttributes(c, ctx, []);
      }
      ctx.inTable = true;
      const t = blocksMd(c.childNodes, ctx).replace(/\n+/g, ' ').replace(/\|/g, '\\|').trim();
      ctx.inTable = false;
      return t;
    }));
  });

  if (el.querySelector('caption')) { addLoss(ctx, 'balise', 'caption'); }
  if (!rows.length) { return ''; }

  const width = Math.max(...rows.map((r) => r.length));
  const line = (r) => {
    const cells = [];
    for (let i = 0; i < width; i++) { cells.push(r[i] || ''); }
    return `| ${cells.join(' | ')} |`;
  };

  const delimiters = [];
  for (let k = 0; k < width; k++) {
    const a = alignments[k];
    delimiters.push(a === 'center' ? ':---:' : a === 'end' ? '---:' : a === 'start' ? ':---' : '---');
  }

  return [line(rows[0]), `| ${delimiters.join(' | ')} |`]
    .concat(rows.slice(1).map(line)).join('\n');
};

const blockMd = (el, ctx) => {
  const name = el.nodeName.toUpperCase();
  const m = /^H([1-6])$/.exec(name);

  if (m) {
    checkAttributes(el, ctx, ['id']);
    const n = parseInt(m[1], 10);
    let level = n - ctx.shift;
    // Automatic mode: the h1 is the article title; an h1 in the body would
    // come back as the title, so it comes back as "##".
    if (n < ctx.minLevel) { addLoss(ctx, 'titre-haut', `h${n}`); level = ctx.minLevel - ctx.shift; }
    if (level < 1) { addLoss(ctx, 'titre-haut', `h${n}`); level = 1; }
    return `${'#'.repeat(level)} ${inlineMd(el.childNodes, ctx).trim()}`;
  }

  switch (name) {
    case 'P':
      checkAttributes(el, ctx, []);
      return inlineMd(el.childNodes, ctx).trim().split('\n').map(escapeLineStart).join('\n');

    case 'HR':
      // The "Read more" comes back as its own line (see `blocks`).
      if (el.getAttribute('id') === 'system-readmore') {
        for (let k = 0; k < el.attributes.length; k++) {
          if (el.attributes[k].name !== 'id') { addLoss(ctx, 'attribut', el.attributes[k].name); }
        }
        return '<!-- readmore -->';
      }
      if (/\bsystem-pagebreak\b/.test(el.getAttribute('class') || '')) { addLoss(ctx, 'saut-page'); return ''; }
      checkAttributes(el, ctx, []);
      return '---';

    case 'BLOCKQUOTE':
      checkAttributes(el, ctx, []);
      return blocksMd(el.childNodes, ctx).split('\n').map((l) => (l ? `> ${l}` : '>')).join('\n');

    case 'PRE':
      return preMd(el, ctx);

    case 'UL': case 'OL':
      return listMd(el, ctx);

    case 'TABLE':
      return tableMd(el, ctx);
  }

  if (DROPPED[name]) { addLoss(ctx, 'balise', name.toLowerCase()); return ''; }
  if (WRAPPERS[name]) { addLoss(ctx, 'balise', name.toLowerCase()); }

  // DIV and its kind: the content stays, the box goes.
  checkAttributes(el, ctx, []);

  return blocksMd(el.childNodes, ctx);
};

/*
 * THE FOOTNOTES set by Markus: a numbered list whose every item carries
 * `id="note-..."` and ends with its back link. They become "[^key]: text"
 * definitions again, and the horizontal rule before them goes (it comes back
 * with them).
 */
const isNotes = (el) => !!el && el.nodeType === 1 && el.nodeName.toUpperCase() === 'OL' && el.children.length > 0
  && Array.from(el.children).every((li) => /^note-/.test(li.getAttribute('id') || '') && li.querySelector('a[href^="#appel-"]'));

const notesMd = (el, ctx) => Array.from(el.children).map((li) => {
  const copy = li.cloneNode(true);
  const back = copy.querySelector('a[href^="#appel-"]');
  const before = back.previousSibling;
  if (before && before.nodeType === 3) { before.nodeValue = before.nodeValue.replace(/ $/, ''); }
  back.remove();
  return `[^${li.getAttribute('id').replace(/^note-/, '')}]: ${inlineMd(copy.childNodes, ctx).trim()}`;
}).join('\n');

const nextElement = (nodes, i) => {
  for (let j = i + 1; j < nodes.length; j++) {
    if (nodes[j].nodeType === 1) { return nodes[j]; }
    if (nodes[j].nodeType === 3 && nodes[j].nodeValue.trim()) { return null; }
  }
  return null;
};

/*
 * THE BLOCKS OF A SEQUENCE OF NODES: text and text tags that follow each
 * other make a paragraph; a block closes it. Blocks are separated by a blank
 * line.
 */
const blocksMd = (nodes, ctx, separator) => {
  const parts = [];
  let current = [];

  const flush = () => {
    if (!current.length) { return; }

    const t = inlineMd(current, ctx).trim();
    if (t) { parts.push(t.split('\n').map(escapeLineStart).join('\n')); }
    current = [];
  };

  for (let i = 0; i < nodes.length; i++) {
    const n = nodes[i];

    if (n.nodeType === 1 && n.nodeName.toUpperCase() === 'HR' && !n.attributes.length && isNotes(nextElement(nodes, i))) {
      flush();
      continue;
    }

    if (isNotes(n)) {
      flush();
      parts.push(notesMd(n, ctx));
      continue;
    }

    if (n.nodeType === 1 && HTML_BLOCKS.test(n.nodeName.toUpperCase())) {
      flush();
      const b = blockMd(n, ctx);
      if (b) { parts.push(b); }
    } else {
      current.push(n);
    }
  }

  flush();

  return parts.join(separator || '\n\n');
};

/**
 * Converts HTML back to Markdown.
 *
 * @param {string} html     The HTML (the article, or a selection of it).
 * @param {object} options  shift, minLevel, externalLinks, domain, newWindow,
 *                          tableClass (same meaning and defaults as for
 *                          markdownToHtml, except that minLevel has no upper
 *                          clamp here), and `document`: the document used to
 *                          parse the HTML (default: the global document).
 * @returns {{text: string, losses: Array<{code: string, detail: string, n: number}>}}
 *          The Markdown, and what it could not write (codes at the top of
 *          this file; `detail` is '' when there is none; `n` counts them).
 */
export const htmlToMarkdown = (html, options) => {
  const o = options || {};
  const doc = o.document || globalThis.document;
  const ctx = {
    shift: clampShift(o.shift),
    externalLinks: o.externalLinks !== false,
    domain: o.domain || currentHost(),
    newWindow: o.newWindow || '(nouvelle fenêtre)',
    minLevel: o.minLevel === undefined ? 1 : Math.max(1, parseInt(o.minLevel, 10) || 1),
    tableClass: tableClassOf(o.tableClass),
    losses: {},
    inTable: false
  };

  // A <template>: the HTML is read there without being executed (no script,
  // no image loaded).
  const template = doc.createElement('template');
  template.innerHTML = String(html || '');

  const text = blocksMd(template.content.childNodes, ctx).replace(/\n{3,}/g, '\n\n').trim();

  return {
    text,
    losses: Object.keys(ctx.losses).map((key) => {
      const p = key.split('|');
      return { code: p[0], detail: p.slice(1).join('|'), n: ctx.losses[key] };
    })
  };
};
