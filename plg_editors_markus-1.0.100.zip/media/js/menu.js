/**
 * Markus Editor: the drop-down menus of the toolbar (colours, cleaning).
 *
 * The ARIA menu pattern: the first item takes the focus, the arrows move
 * (in a grid, Up and Down jump a whole row), Home and End go to the ends,
 * Escape or Tab closes and gives the focus back to the button. The text
 * keeps its selection while an item is pressed with the mouse.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

let open = null;

function closeMenu(focusBack) {
  if (!open) {
    return;
  }

  const { box, anchor, outside, resolve } = open;

  open = null;
  document.removeEventListener('pointerdown', outside, true);
  window.removeEventListener('scroll', outside, true);
  box.remove();
  resolve(null);

  if (anchor) {
    anchor.setAttribute('aria-expanded', 'false');

    if (focusBack) {
      anchor.focus({ preventScroll: true });
    }
  }
}

/** Closes the open menu, if any; true when there was one (its button pressed again). */
export function toggleMenu() {
  const was = !!open;

  closeMenu(true);

  return was;
}

/**
 * Opens a menu under `anchor`, its items being the `[role="menuitem"]` of
 * `html`. `columns` is the number of items per row (1 for a list). Resolves
 * with the chosen item, or null when the menu closes without a choice.
 * `at` ({ x, y }, in the window) opens it at a point instead, as the right
 * click does; `anchor` may then be null, the caller giving the focus back.
 */
export function openMenu(anchor, { label, html, className, columns = 1, at = null }) {
  closeMenu(false);

  return new Promise((resolve) => {
    const box = document.createElement('div');

    box.className = `mk-menu ${className || ''}`;
    box.setAttribute('role', 'menu');
    box.setAttribute('aria-label', label);
    box.innerHTML = html;

    const items = [...box.querySelectorAll('[role="menuitem"]')];
    const choose = (item, focusBack = !item) => {
      const done = open.resolve;

      open.resolve = () => {};
      closeMenu(focusBack);
      done(item);
    };

    box.addEventListener('keydown', (e) => {
      const i = items.indexOf(document.activeElement);
      const step = columns > 1
        ? { ArrowRight: 1, ArrowLeft: -1, ArrowDown: columns, ArrowUp: -columns }[e.key]
        : { ArrowDown: 1, ArrowUp: -1 }[e.key];

      if (step) {
        e.preventDefault();
        items[columns > 1 ? Math.max(0, Math.min(items.length - 1, i + step)) : (i + step + items.length) % items.length].focus({ preventScroll: true });
      } else if (e.key === 'Home' || e.key === 'End') {
        e.preventDefault();
        items[e.key === 'Home' ? 0 : items.length - 1].focus({ preventScroll: true });
      } else if (e.key === 'Escape' || e.key === 'Tab') {
        e.preventDefault();
        e.stopPropagation();
        choose(null);
      }
    });
    box.addEventListener('mousedown', (e) => e.preventDefault());
    box.addEventListener('click', (e) => {
      const item = e.target.closest('[role="menuitem"]');

      if (item) {
        choose(item);
      }
    });

    const x0 = window.scrollX;
    const y0 = window.scrollY;
    // The editors' own scroll, where the text scrolls (a late event from before the menu is not a move).
    const tops = new Map([...document.querySelectorAll('.mk-surface')].map((el) => [el, el.scrollTop]));
    const outside = (e) => {
      // A scroll event can arrive late, from a scroll made before the menu opened: only a real move counts.
      // The text scrolling in the editor (it has its own scroll bar) closes the menu too; the menu's own list does not.
      if (e.type === 'scroll' && (e.target === document
        ? Math.abs(window.scrollX - x0) < 2 && Math.abs(window.scrollY - y0) < 2
        : box.contains(e.target) || (tops.has(e.target) && Math.abs(e.target.scrollTop - tops.get(e.target)) < 2))) {
        return;
      }

      // A click elsewhere, or the page scrolling, closes the menu and leaves the focus where it is.
      if (e.type === 'scroll' || (!box.contains(e.target) && !(anchor && anchor.contains(e.target)))) {
        choose(null, false);
      }
    };

    items.forEach((item) => { item.tabIndex = -1; });
    open = { box, anchor, outside, resolve };
    document.addEventListener('pointerdown', outside, true);
    window.addEventListener('scroll', outside, true);

    if (anchor) {
      anchor.setAttribute('aria-expanded', 'true');
    }

    document.body.appendChild(box);

    /*
     * Under the anchor, or at the point; above it when there is no room below.
     * FIXED IN THE WINDOW, never in the page (Cyrille: the page and the panel
     * moved on a right click): a menu added to the page could lengthen it,
     * make the scroll bar appear and shift everything sideways; focusing its
     * first item could scroll the page.
     */
    const r = at ? { left: at.x, top: at.y, bottom: at.y } : anchor.getBoundingClientRect();
    const h = box.offsetHeight;
    const top = r.bottom + 4 + h < window.innerHeight ? r.bottom + 4 : Math.max(8, r.top - h - 4);

    box.style.left = `${Math.max(8, Math.min(r.left, window.innerWidth - box.offsetWidth - 8))}px`;
    box.style.top = `${top}px`;
    items[0].focus({ preventScroll: true });
  });
}
