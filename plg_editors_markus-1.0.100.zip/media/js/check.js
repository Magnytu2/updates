/**
 * Markus Editor: the accessibility check of the content (the "Check" button).
 *
 * What an author can get wrong in an article, and fix in Markus: an image
 * without a text alternative, a heading level skipped (the article title is
 * the level 1), a link whose text says nothing, a colour too pale for its
 * background, a table without headers or title. The alerts inform; they
 * never block saving.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

import { t } from 'plg_editors_markus.i18n';
import { contrast, siteColours } from 'plg_editors_markus.colours';

const TEXT_BLOCKS = ['p', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'blockquote', 'callout'];
const PAIR = /light-dark\(\s*(#[0-9a-f]{6})\s*,\s*(#[0-9a-f]{6})\s*\)/i;
const CODE = /^#[0-9a-f]{6}$/i;

const bodyOf = (block) => block.querySelector(':scope > .mk-body');
const ratio = (r) => r.toLocaleString(document.documentElement.lang || undefined, { maximumFractionDigits: 1 });

/** The text a link gives to a reader: its words, or the alternative of its image. */
function linkText(a) {
  const copy = a.cloneNode(true);

  copy.querySelectorAll('.visually-hidden').forEach((n) => n.remove());

  return (copy.textContent || [...copy.querySelectorAll('img[alt]')].map((i) => i.alt).join(' ')).trim();
}

/** The weakest contrast of a colour written by Markus (or pasted as a code), light and dark mode. */
function weakest(value) {
  const site = siteColours();
  const pair = PAIR.exec(value);

  if (pair) {
    return Math.min(contrast(pair[1].toLowerCase(), site.light.back), contrast(pair[2].toLowerCase(), site.dark.back));
  }

  return CODE.test(value) ? contrast(value.toLowerCase(), site.light.back) : Infinity;
}

/**
 * Checks the blocks, in reading order. Returns [{ block, title, text }].
 * Each block with an alert gets the class `mk-block--alert`.
 */
export function audit(blocks) {
  const alerts = [];
  let level = 1;

  blocks.forEach((block) => {
    const type = block.dataset.type;
    const body = bodyOf(block);
    const said = [];
    const say = (key, ...args) => said.push({ block, title: t(`${key}_TITLE`), text: t(key, ...args) });

    if (type === 'image') {
      const img = body.tagName === 'IMG' ? body : body.querySelector('img');

      // alt="" says "decorative": only a missing alt is a fault.
      if (img && !img.hasAttribute('alt')) {
        say('ALERT_ALT');
      }
    }

    if (type === 'h1') {
      say('ALERT_H1');
    } else if (/^h[2-6]$/.test(type)) {
      const n = Number(type[1]);

      if (n > level + 1) {
        say('ALERT_JUMP', n, level, level + 1);
      }

      level = n;
    }

    if (TEXT_BLOCKS.includes(type) || type === 'table') {
      const vague = t('ALERT_VAGUE_WORDS').toLowerCase().split('|');

      body.querySelectorAll('a[href]').forEach((a) => {
        const words = linkText(a);

        if (!words) {
          say('ALERT_LINK_EMPTY');
        } else if (vague.includes(words.toLowerCase().replace(/[.!…]+$/, ''))) {
          say('ALERT_LINK', words);
        }
      });

      const seen = new Set();

      [body, ...body.querySelectorAll('[style]')].forEach((el) => {
        const value = (String(el.getAttribute('style') || '').match(/(?:^|;)\s*color\s*:\s*([^;]+)/i) || [])[1] || '';

        if (!value || seen.has(value.trim())) {
          return;
        }

        seen.add(value.trim());

        const r = weakest(value.trim());
        const need = /^h[23]$/.test(type) ? 3 : 4.5;

        if (r < need) {
          say('ALERT_CONTRAST', value.trim(), ratio(r), ratio(need));
        }
      });
    }

    if (type === 'table') {
      const table = body.tagName === 'TABLE' ? body : body.querySelector('table');

      if (!table.querySelector('th')) {
        say('ALERT_TH');
      }

      if (!table.caption || !table.caption.textContent.trim()) {
        say('ALERT_CAPTION');
      }
    }

    block.classList.toggle('mk-block--alert', said.length > 0);
    alerts.push(...said);
  });

  return alerts;
}
