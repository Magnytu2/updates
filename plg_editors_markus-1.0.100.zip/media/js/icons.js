/**
 * Markus Editor: the pictograms of the buttons.
 *
 * Written INTO the article as inline SVG, drawn with the text's colour
 * (`currentColor`), one em wide, the very pictograms of Corpus and Opus: they need no icon font, and the site's
 * template (Corpus loads none) shows them as they are. One may paste an SVG
 * of one's own (Tabler, Lucide, Bootstrap Icons...): only the drawing is
 * kept, never a script, a style or a link.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

/**
 * The set offered: the planche of Corpus, shared with Opus (corpus/html/layouts/corpus/pictogrammes.php,
 * 62 pictograms painted in a 24 x 24 square), copied by outils/pictos.py. Painted, not drawn: `fill`.
 */
export const ICONS = {
  'accueil': '<path d="M12 3.5 3 11.6l1.32 1.48L5 12.47V20.5h5.25V15h3.5v5.5H19v-8.03l.68.61L21 11.6 12 3.5Z"/>',
  'actualites': '<path d="M4 4h13v16H6.5A2.5 2.5 0 0 1 4 17.5V4Zm2 2v11.5a.5.5 0 0 0 .5.5H15V6H6Zm1.5 1.5h6V11h-6V7.5Zm0 5h6V14h-6v-1.5Zm0 3h6V17h-6v-1.5ZM18.5 8H21v9.5a2.5 2.5 0 0 1-2.5 2.5V8Z"/>',
  'missions': '<path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm0 2a8 8 0 1 1 0 16 8 8 0 0 1 0-16Zm4.6 3.4-6.1 2.3-2.3 6.1 6.1-2.3 2.3-6.1ZM12 11a1 1 0 1 1 0 2 1 1 0 0 1 0-2Z"/>',
  'demarches': '<path d="M5 2h9l5 5v15H5V2Zm2 2v16h10V9h-4V4H7Zm8-.6V7h3.6L15 3.4ZM8 13.6 9.4 12.2l1.7 1.7 3.5-3.5L16 11.8l-4.9 4.9L8 13.6Z"/>',
  'contact': '<path d="M2 5h20v14H2V5Zm2.4 2L12 12.2 19.6 7H4.4ZM20 8.6l-8 5.4-8-5.4V17h16V8.6Z"/>',
  'recherche': '<path d="M10 2a8 8 0 1 0 4.9 14.3l5.4 5.4 1.4-1.4-5.4-5.4A8 8 0 0 0 10 2Zm0 2a6 6 0 1 1 0 12 6 6 0 0 1 0-12Z"/>',
  'affichage': '<path d="M12 3a9 9 0 1 0 9 9 7 7 0 0 1-9-9Zm-1 2.1A7 7 0 1 0 18.9 13 9 9 0 0 1 11 5.1Z"/>',
  'menu': '<path d="M3 5h18v2H3zm0 6h18v2H3zm0 6h18v2H3z"/>',
  'chevron': '<path d="M12 15.5 5.5 9l1.4-1.4L12 12.7l5.1-5.1L18.5 9 12 15.5Z"/>',
  'fleche': '<path d="M13.2 4.6 20.6 12l-7.4 7.4-1.4-1.4 5-5H3.4v-2h13.4l-5-5 1.4-1.4Z"/>',
  'fleche-g': '<path d="M10.8 4.6 3.4 12l7.4 7.4 1.4-1.4-5-5h13.4v-2H7.2l5-5-1.4-1.4Z"/>',
  'fleche-haut': '<path d="M12 3.4 4.6 10.8l1.4 1.4 5-5v13.4h2V7.2l5 5 1.4-1.4L12 3.4Z"/>',
  'calendrier': '<path d="M7 2h2v2h6V2h2v2h3v18H4V4h3V2ZM6 8v12h12V8H6Zm2 2h3v3H8v-3Z"/>',
  'utilisateur': '<path d="M12 3a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9Zm0 2a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5Zm-8 16c0-4.4 3.6-7 8-7s8 2.6 8 7h-2c0-3.2-2.7-5-6-5s-6 1.8-6 5H4Z"/>',
  'dossier': '<path d="M2 4h7.4l2 2.5H22V20H2V4Zm2 2v12h16V8.5h-9.6L8.4 6H4Z"/>',
  'accessibilite': '<path d="M12 2.2a2.3 2.3 0 1 1 0 4.6 2.3 2.3 0 0 1 0-4.6ZM5.4 8.2c2.3.6 4.5.9 6.6.9s4.3-.3 6.6-.9l.5 1.9c-1.8.5-3.5.8-5.1.9v2.3l3 8.1-1.9.7-3.1-7.7-3.1 7.7-1.9-.7 3-8.1V11c-1.6-.1-3.3-.4-5.1-.9l.5-1.9Z"/>',
  'ticket': '<path d="M2 5h20v5a2.4 2.4 0 0 0 0 4.8V20H2v-5.2a2.4 2.4 0 0 0 0-4.8V5Zm2.8 2.8v.9a5.2 5.2 0 0 1 0 8.6v.9h14.4v-.9a5.2 5.2 0 0 1 0-8.6v-.9H4.8Zm3 2.4h8.4v1.9H7.8v-1.9Zm0 3.6h5.6v1.9H7.8v-1.9Z"/>',
  'panier': '<path d="M2 3h3.4l.6 3H21.5l-2 8.5H8.4l.3 1.5h10.1v2H7L4.1 5H2V3Zm4.4 5 1.6 4.5h10l1.1-4.5H6.4ZM9.5 19.2a1.9 1.9 0 1 1 0 3.8 1.9 1.9 0 0 1 0-3.8Zm8 0a1.9 1.9 0 1 1 0 3.8 1.9 1.9 0 0 1 0-3.8Z"/>',
  'etiquette': '<path d="M11 2h9v9l-8.5 8.5-9-9L11 2Zm.8 2L4.3 11.5l6.2 6.2L18 10.2V4h-6.2ZM16 5.5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Z"/>',
  'oeil': '<path d="M12 5c5 0 9 4.5 10 7-1 2.5-5 7-10 7S3 14.5 2 12c1-2.5 5-7 10-7Zm0 2c-3.5 0-6.6 3-7.8 5 1.2 2 4.3 5 7.8 5s6.6-3 7.8-5C18.6 10 15.5 7 12 7Zm0 1.8a3.2 3.2 0 1 1 0 6.4 3.2 3.2 0 0 1 0-6.4Z"/>',
  'lieu': '<path d="M12 2a7 7 0 0 1 7 7c0 5-7 13-7 13S5 14 5 9a7 7 0 0 1 7-7Zm0 2a5 5 0 0 0-5 5c0 3 3.3 7.9 5 10 1.7-2.1 5-7 5-10a5 5 0 0 0-5-5Zm0 2.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5Z"/>',
  'telephone': '<path d="M7.3 2.5 10.6 6 8.3 8.3c.9 2 2.4 3.5 4.4 4.4L15 10.4l3.5 3.3-3.3 3.3C9.5 15.7 4.6 10.8 3 6.2l4.3-3.7Z"/>',
  'rss': '<path d="M4 4c9.9 0 16 6.1 16 16h-3C17 11.8 12.2 7 4 7V4Zm0 6c5.5 0 10 4.5 10 10h-3c0-3.9-3.1-7-7-7v-3Zm2 7a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5Z"/>',
  'imprimer': '<path d="M7 2h10v4H7V2ZM4 7h16v9h-3v6H7v-6H4V7Zm5 9v4h6v-4H9Zm8-6.5a1 1 0 1 1 0 2 1 1 0 0 1 0-2Z"/>',
  'info': '<path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm1 15h-2v-6h2v6Zm0-8h-2V7h2v2Z"/>',
  'succes': '<path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm-1 14.4-4.2-4.2 1.4-1.4 2.8 2.8 5.6-5.6 1.4 1.4-7 7Z"/>',
  'alerte': '<path d="M12 2 1 21h22L12 2Zm0 4 7.5 13h-15L12 6Zm1 11h-2v-2h2v2Zm0-3h-2v-4h2v4Z"/>',
  'erreur': '<path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm1 15h-2v-2h2v2Zm0-4h-2V7h2v6Z"/>',
  'partage': '<path d="M8.8 11.6 16 7.4l-.8-1.4L8 10.2ZM8.8 12.4 16 16.6l-.8 1.4L8 13.8ZM6 9.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5ZM18 3a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5ZM18 16a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5Z"/>',
  'lien': '<path d="M11 8H8a4 4 0 0 0 0 8h3v-2H8a2 2 0 0 1 0-4h3ZM13 8h3a4 4 0 0 1 0 8h-3v-2h3a2 2 0 0 0 0-4h-3ZM8 11h8v2H8Z"/>',
  'fermer': '<path d="M6.4 4.9 12 10.5l5.6-5.6 1.5 1.5L13.5 12l5.6 5.6-1.5 1.5L12 13.5l-5.6 5.6-1.5-1.5L10.5 12 4.9 6.4z"/>',
  'tri': '<path d="M12 4 7 10h10l-5-6Zm0 16 5-6H7l5 6Z"/>',
  'chevron-g': '<path d="M15.1 5.6 8.7 12l6.4 6.4-1.4 1.4L5.9 12l7.8-7.8 1.4 1.4Z"/>',
  'chevron-gg': '<path d="M11.7 5.6 5.3 12l6.4 6.4-1.4 1.4L2.5 12l7.8-7.8 1.4 1.4Zm9 0L14.3 12l6.4 6.4-1.4 1.4L11.5 12l7.8-7.8 1.4 1.4Z"/>',
  'envoyer': '<path d="M5,14 L5,19 L19,19 L19,14 L21,14 L21,21 L3,21 L3,14 Z M11,16 L11,4.5 L13,4.5 L13,16 L11,16 Z M6.29,8.79 L12,3.09 L17.71,8.79 L16.29,10.21 L12,5.91 L7.71,10.21 Z"/>',
  'telecharger': '<path d="M5,14 L5,19 L19,19 L19,14 L21,14 L21,21 L3,21 L3,14 Z M13,3.5 L13,15 L11,15 L11,3.5 L13,3.5 Z M7.71,9.29 L12,13.59 L16.29,9.29 L17.71,10.71 L12,16.41 L6.29,10.71 Z"/>',
  'dossier-plus': '<path d="M9.48,4 L11.48,6.5 L22,6.5 L22,20 L2,20 L2,4 L9.48,4 Z M4,6 L4,18 L20,18 L20,8.5 L10.52,8.5 L8.52,6 L4,6 Z M13,10 L13,16.5 L11,16.5 L11,10 L13,10 Z M8.75,12.25 L15.25,12.25 L15.25,14.25 L8.75,14.25 L8.75,12.25 Z"/>',
  'crayon': '<path d="M3.03,19.76 L4.3,14.69 L15.5,3.49 L20.51,8.5 L9.31,19.7 L2.63,21.37 Z M5.37,18.63 L8.29,17.9 L17.69,8.5 L15.5,6.31 L6.1,15.71 L5.37,18.63 Z M13.71,6.69 L17.31,10.29 L15.89,11.71 L12.29,8.11 L13.71,6.69 Z"/>',
  'deplacer': '<path d="M9.48,4 L11.48,6.5 L22,6.5 L22,20 L2,20 L2,4 L9.48,4 Z M4,6 L4,18 L20,18 L20,8.5 L10.52,8.5 L8.52,6 L4,6 Z M7.5,12.25 L15.5,12.25 L15.5,14.25 L7.5,14.25 L7.5,12.25 Z M13.21,9.29 L17.16,13.25 L13.21,17.21 L11.79,15.79 L14.34,13.25 L11.79,10.71 Z"/>',
  'copier': '<path d="M7,7 L7,2 L22,2 L22,17 L17,17 L17,15 L20,15 L20,4 L9,4 L9,7 Z M2,7 L17,7 L17,22 L2,22 Z M4,9 L4,20 L15,20 L15,9 Z"/>',
  'recadrer': '<path d="M7,2 L7,17 L22,17 L22,19 L5,19 L5,2 Z M2,5 L19,5 L19,22 L17,22 L17,7 L2,7 Z"/>',
  'alleger': '<path d="M4.21,2.79 L10.21,8.79 L8.79,10.21 L2.79,4.21 L4.21,2.79 Z M11,4.5 L11,11 L4.5,11 L4.5,9 L9,9 L9,4.5 Z M19.79,21.21 L13.79,15.21 L15.21,13.79 L21.21,19.79 L19.79,21.21 Z M13,19.5 L13,13 L19.5,13 L19.5,15 L15,15 L15,19.5 Z"/>',
  'corbeille': '<path d="M3.5,5 L20.5,5 L20.5,7 L3.5,7 L3.5,5 Z M8,6 L8,2 L16,2 L16,6 L14,6 L14,4 L10,4 L10,6 Z M7,5.93 L7.94,20 L16.06,20 L17,5.93 L19,6.07 L17.94,22 L6.06,22 L5,6.07 Z M11,10 L11,17 L9,17 L9,10 L11,10 Z M15,10 L15,17 L13,17 L13,10 L15,10 Z"/>',
  'galerie': '<path d="M2,4 L22,4 L22,20 L2,20 Z M4,6 L4,18 L20,18 L20,6 Z M2.29,15.79 L8,10.09 L12.5,14.59 L15.5,11.59 L21.71,17.79 L20.29,19.21 L15.5,14.41 L12.5,17.41 L8,12.91 L3.71,17.21 Z M18,9 Q18,11 16,11 Q14,11 14,9 Q14,7 16,7 Q18,7 18,9 Z"/>',
  'inserer': '<path d="M14.41,2 L19,6.59 L19,22 L5,22 L5,2 L14.41,2 Z M7,4 L7,20 L17,20 L17,7.41 L13.59,4 L7,4 Z M13,10 L13,17 L11,17 L11,10 L13,10 Z M8.5,12.5 L15.5,12.5 L15.5,14.5 L8.5,14.5 L8.5,12.5 Z"/>',
  'remplacer': '<path d="M4,7.5 L17,7.5 L17,9.5 L4,9.5 L4,7.5 Z M14.21,4.29 L18.41,8.5 L14.21,12.71 L12.79,11.29 L15.59,8.5 L12.79,5.71 Z M20,16.5 L7,16.5 L7,14.5 L20,14.5 L20,16.5 Z M11.21,12.71 L8.41,15.5 L11.21,18.29 L9.79,19.71 L5.59,15.5 L9.79,11.29 Z"/>',
  'verrou': '<path d="M5,10 L19,10 L19,22 L5,22 Z M7,12 L7,20 L17,20 L17,12 Z M7,10 L7,7 A5,5 0 0 1 17,7 L17,10 L15,10 L15,7 A3,3 0 0 0 9,7 L9,10 Z M11,14 L13,14 L13,18 L11,18 Z"/>',
  'etoile': '<path d="M12,2.5 L14.9,8.6 L21.5,9.4 L16.6,14 L17.9,20.6 L12,17.3 L6.1,20.6 L7.4,14 L2.5,9.4 L9.1,8.6 Z"/>',
  'oeil-barre': '<path d="M12 5c5 0 9 4.5 10 7-1 2.5-5 7-10 7S3 14.5 2 12c1-2.5 5-7 10-7Zm0 2c-3.5 0-6.6 3-7.8 5 1.2 2 4.3 5 7.8 5s6.6-3 7.8-5C18.6 10 15.5 7 12 7ZM3.7 2.3 21.7 20.3 20.3 21.7 2.3 3.7Z"/>',
  'pivoter-gauche': '<path d="M12 4.5A8 8 0 1 1 5.07 8.5L6.8 9.5A6 6 0 1 0 12 6.5ZM12 2 8 5.5 12 9Z"/>',
  'pivoter-droite': '<path d="M12 4.5A8 8 0 1 0 18.93 8.5L17.2 9.5A6 6 0 1 1 12 6.5ZM12 2 16 5.5 12 9Z"/>',
  'annuler': '<path d="M9.4 4.6 4 10l5.4 5.4 1.4-1.4-3-3H14a4 4 0 0 1 0 8H8v2h6a6 6 0 0 0 0-12H7.8l3-3-1.4-1.4Z"/>',
  'ligne-plus': '<path d="M3 3h18v4H3V3Zm0 6h18v4H3V9Zm8 6h2v3h3v2h-3v3h-2v-3H8v-2h3v-3Z"/>',
  'ligne-moins': '<path d="M3 3h18v4H3V3Zm0 6h18v4H3V9Zm5 9h8v2H8v-2Z"/>',
  'colonne-plus': '<path d="M3 3h4v18H3V3Zm6 0h4v18H9V3Zm9 5h2v3h3v2h-3v3h-2v-3h-3v-2h3V8Z"/>',
  'colonne-moins': '<path d="M3 3h4v18H3V3Zm6 0h4v18H9V3Zm6 8h8v2h-8v-2Z"/>',
  'aligner-gauche': '<path d="M3 4h18v2H3V4Zm0 5h12v2H3V9Zm0 5h18v2H3v-2Zm0 5h12v2H3v-2Z"/>',
  'centrer': '<path d="M3 4h18v2H3V4Zm3 5h12v2H6V9Zm-3 5h18v2H3v-2Zm3 5h12v2H6v-2Z"/>',
  'aligner-droite': '<path d="M3 4h18v2H3V4Zm6 5h12v2H9V9Zm-6 5h18v2H3v-2Zm6 5h12v2H9v-2Z"/>',
  'en-haut': '<path d="M3 2h18v2H3V2Zm0 18h18v2H3v-2ZM7 7h10v2H7V7Zm0 4h10v2H7v-2Z"/>',
  'au-milieu': '<path d="M3 2h18v2H3V2Zm0 18h18v2H3v-2ZM7 9h10v2H7V9Zm0 4h10v2H7v-2Z"/>',
  'en-bas': '<path d="M3 2h18v2H3V2Zm0 18h18v2H3v-2ZM7 11h10v2H7v-2Zm0 4h10v2H7v-2Z"/>',
};

const SHAPES = new Set(['svg', 'g', 'path', 'circle', 'rect', 'line', 'polyline', 'polygon', 'ellipse']);
const ATTRS = new Set(['viewbox', 'd', 'cx', 'cy', 'r', 'rx', 'ry', 'x', 'y', 'x1', 'y1', 'x2', 'y2', 'width', 'height', 'points',
  'fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'fill-rule', 'clip-rule', 'transform', 'xmlns']);

/** The <svg> of a pictogram of the set. */
export function iconSvg(name) {
  return ICONS[name] ? `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="1em" height="1em" fill="currentColor"`
    + ` aria-hidden="true" focusable="false" data-icon="${name}">${ICONS[name]}</svg>` : '';
}

/**
 * An SVG pasted by the author, kept drawing only: its shapes and their
 * geometry, at the size of the text, in the text's colour, hidden from
 * screen readers (the button's words say what it does). Null when it is not
 * an SVG.
 */
export function cleanSvg(text) {
  const doc = new DOMParser().parseFromString(String(text || '').trim(), 'image/svg+xml');
  const svg = doc.documentElement;

  if (!svg || svg.nodeName.toLowerCase() !== 'svg' || doc.querySelector('parsererror')) {
    return null;
  }

  [...svg.querySelectorAll('*')].forEach((n) => {
    if (!SHAPES.has(n.nodeName.toLowerCase())) {
      n.remove();
    }
  });
  [svg, ...svg.querySelectorAll('*')].forEach((n) => {
    [...n.attributes].forEach((a) => {
      if (!ATTRS.has(a.name.toLowerCase())) {
        n.removeAttribute(a.name);
      }
    });
    // A colour written in the drawing would not follow the button's.
    ['fill', 'stroke'].forEach((a) => {
      const v = n.getAttribute(a);

      if (v && !/^(none|currentColor)$/i.test(v)) {
        n.setAttribute(a, 'currentColor');
      }
    });
  });

  if (!svg.getAttribute('viewBox')) {
    svg.setAttribute('viewBox', `0 0 ${parseFloat(svg.getAttribute('width')) || 24} ${parseFloat(svg.getAttribute('height')) || 24}`);
  }

  svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  svg.setAttribute('width', '1em');
  svg.setAttribute('height', '1em');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');

  return new XMLSerializer().serializeToString(svg).replace(/ xmlns="http:\/\/www\.w3\.org\/2000\/svg"/, '')
    .replace(/^<svg/, '<svg xmlns="http://www.w3.org/2000/svg"');
}
