/**
 * Markus Editor: language strings.
 *
 * Every visible text is a language key, sent to the browser by the PHP
 * provider with Text::script(). `t('BOLD')` reads PLG_EDITORS_MARKUS_BOLD;
 * each `%s` is replaced in order by the extra arguments.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

const PREFIX = 'PLG_EDITORS_MARKUS_';

export function t(key, ...args) {
  const full = PREFIX + key;
  let text = window.Joomla && Joomla.Text ? Joomla.Text._(full, full) : full;

  args.forEach((arg) => {
    text = text.replace('%s', arg);
  });

  return text;
}

/** Escapes a text for use inside HTML, attributes included. */
export function escape(text) {
  return String(text ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}
