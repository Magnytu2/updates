/**
 * Markus Editor: the block model.
 *
 * WHAT IS STORED IS WHAT IS EDITED. A text block edits the stored element
 * itself (the <p>, the <h2>, the <ul>...). Markus only adds the attributes
 * listed in EDIT_ATTRS and removes them on save, so every attribute, class
 * or style written by TinyMCE survives a round trip untouched.
 *
 * NOTHING IS EVER LOST. An element Markus cannot edit faithfully becomes an
 * "html" block, saved verbatim. Joomla's own markup is recognised: the
 * "Read more" separator, {loadmoduleid N}, Bootstrap rows and columns.
 *
 * Editor chrome inside a block carries the `mk-ui` class and is skipped on
 * save. This file holds no UI state: markus.js builds the interface.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

/** Attributes Markus adds while editing, never saved. */
// `data-lt-*`: ours, and the marks the LanguageTool browser extension leaves on what it watches.
export const EDIT_ATTRS = ['contenteditable', 'aria-label', 'data-mk-placeholder', 'data-mk-empty', 'data-mk-hidden', 'data-mk-src', 'draggable',
  'data-lt-active', 'data-lt-tmp-id', 'data-lt-installed'];

/*
 * The editing attributes of one element. `aria-label` is Markus's only on what
 * it makes editable (the name of a typed zone): an author's own (the link
 * back from a footnote, an icon link) is content, kept.
 */
const editAttrsOf = (n) => EDIT_ATTRS.filter((a) => a !== 'aria-label' || n.getAttribute('contenteditable') === 'true');

/** Blocks whose content is typed directly. */
export const TEXT_TYPES = ['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'callout', 'ul', 'ol', 'pre'];

/** Elements allowed inside a text block. Anything else makes it an "html" block. */
const PHRASING = new Set(['A', 'ABBR', 'B', 'BDI', 'BDO', 'BR', 'CITE', 'CODE', 'DATA', 'DEL', 'DFN', 'EM', 'I', 'IMG',
  'INS', 'KBD', 'MARK', 'Q', 'S', 'SAMP', 'SMALL', 'SPAN', 'STRONG', 'SUB', 'SUP', 'TIME', 'U', 'VAR', 'WBR']);
const IN_LISTS = new Set([...PHRASING, 'LI', 'UL', 'OL', 'P']);
const IN_QUOTES = new Set([...PHRASING, 'P', 'UL', 'OL', 'LI', 'FOOTER']);

/** Bootstrap columns, the grid every Joomla template loads (Cassiopeia, Corpus...). */
export const COL = /^col-(?:(sm|md|lg|xl|xxl)-)?(\d{1,2})$/;
const MODULE = /^\{loadmoduleid\s+(\d+)\s*\}$/;

/** State of blocks that do not edit their stored element (cards, raw HTML). */
const stored = new WeakMap();

const isElement = (n) => n && n.nodeType === Node.ELEMENT_NODE;

function onlyChildren(el, allowed) {
  return [...el.querySelectorAll('*')].every((n) => allowed.has(n.tagName));
}

/** The same, a decorative pictogram in a heading allowed (the pictogram of a panel, settings.js). */
function onlyChildrenOrIcon(el, allowed) {
  return [...el.querySelectorAll('*')].every((n) => allowed.has(n.tagName)
    || !!n.closest('h2 > svg[aria-hidden="true"], h3 > svg[aria-hidden="true"], h4 > svg[aria-hidden="true"], h5 > svg[aria-hidden="true"], h6 > svg[aria-hidden="true"]'));
}

function hasEditAttrs(el) {
  return [el, ...el.querySelectorAll('*')].some((n) => editAttrsOf(n).some((a) => n.hasAttribute(a)));
}

/** An image alone, or an image alone in a link (the spoken "new window" aside). */
function imageIn(n) {
  if (n.tagName === 'IMG') {
    return n;
  }

  // A link around the image, or the button that shows it larger (settings.js, `popover`).
  if (n.tagName !== 'A' && !(n.tagName === 'BUTTON' && n.hasAttribute('popovertarget'))) {
    return null;
  }

  const kids = [...n.children];
  const extra = kids.slice(1);
  const text = [...n.childNodes].filter((c) => c.nodeType === Node.TEXT_NODE).map((c) => c.textContent).join('');

  return kids.length && kids[0].tagName === 'IMG' && !text.trim()
    && extra.every((k) => k.tagName === 'SPAN' && k.classList.contains('visually-hidden')) ? kids[0] : null;
}

/** The <img> of an image block, or null: an image (or linked image) alone in a <p> or a <figure>. */
function loneImage(el) {
  if (el.tagName === 'IMG') {
    return el;
  }

  const kids = [...el.children];

  if (el.tagName === 'P' && kids.length === 1 && !el.textContent.replace(kids[0].textContent, '').trim()) {
    return imageIn(kids[0]);
  }

  if (el.tagName === 'FIGURE' && kids.length && kids.length <= 3
    && kids.slice(1).every((k) => k.tagName === 'FIGCAPTION' || (k.tagName === 'DIV' && k.hasAttribute('popover')))) {
    return imageIn(kids[0]);
  }

  return null;
}

/**
 * BUTTONS (Cyrille: "super important"): a paragraph, or a div, holding only
 * links drawn as Bootstrap buttons (`a.btn`) or Corpus's own (`a.bouton`), and spaces between them.
 */
function buttonsIn(el) {
  if (!/^(P|DIV)$/.test(el.tagName) || !el.children.length) {
    return false;
  }

  const loose = [...el.childNodes].some((n) => n.nodeType === Node.TEXT_NODE && n.textContent.trim());

  // Inside a button: its words, the spoken "new window", and a pictogram (icons.js).
  return !loose && [...el.children].every((a) => a.tagName === 'A' && (a.classList.contains('btn') || a.classList.contains('bouton'))
    && [...a.children].every((n) => (n.tagName === 'SPAN' && n.classList.contains('visually-hidden') && !n.children.length)
      || (n.tagName.toLowerCase() === 'svg' && n.getAttribute('aria-hidden') === 'true')));
}

const IN_CALLOUT = new Set([...IN_QUOTES, 'H2', 'H3', 'H4', 'H5', 'H6']);

function isCallout(el) {
  const c = el.classList;

  if (el.tagName === 'DIV' && c.contains('message')) {
    const kids = [...el.children];
    const icon = kids[0] && kids[0].tagName.toLowerCase() === 'svg' ? 1 : 0;

    return kids.length === icon + 1 && kids[icon].tagName === 'DIV';
  }

  return (el.tagName === 'ASIDE' && c.contains('panneau__boite'))
    || (el.tagName === 'DIV' && (c.contains('alert') || (c.contains('card') && c.contains('card-body'))));
}

/** Where the lines of a callout are typed: the div of a message, the element itself otherwise. */
export function calloutLines(el) {
  return (el.classList.contains('message') && el.querySelector(':scope > div')) || el;
}

/** The type of block an element of the article makes. */
export function detect(el) {
  if (hasEditAttrs(el)) {
    return 'html';
  }

  const tag = el.tagName;

  if (tag === 'HR') {
    return el.id === 'system-readmore' ? 'readmore' : 'separator';
  }

  if (tag === 'P' && !el.children.length && MODULE.test(el.textContent.trim())) {
    return 'module';
  }

  if (loneImage(el)) {
    return 'image';
  }

  if (buttonsIn(el)) {
    return 'buttons';
  }

  if (tag === 'TABLE' || (tag === 'DIV' && el.classList.contains('table-responsive')
    && el.children.length === 1 && el.firstElementChild.tagName === 'TABLE')) {
    const table = tag === 'TABLE' ? el : el.firstElementChild;

    return table.querySelector('table, script, iframe, object, embed, form') ? 'html' : 'table';
  }

  /*
   * A CALLOUT (lot 2), Corpus's own (html/tinymce, "Message - Alerte..." and
   * "Encadre mis en avant"): the alert zone `div.message.message--<nature>`
   * (its pictogram, then a div with its title and its text), or the panel
   * `aside.panneau__boite` (a heading, then the text). A Bootstrap alert or
   * card body written before is read as well.
   */
  if (isCallout(el)) {
    const lines = calloutLines(el);
    const loose = [...lines.childNodes].some((n) => n.nodeType === Node.TEXT_NODE && n.textContent.trim());

    return lines.children.length && onlyChildrenOrIcon(lines, IN_CALLOUT) && !loose ? 'callout' : 'html';
  }

  if (tag === 'DIV' && el.classList.contains('row') && el.children.length >= 1 && el.children.length <= 6
    && [...el.children].every((c) => c.tagName === 'DIV' && [...c.classList].some((k) => COL.test(k)))) {
    return 'columns';
  }

  if (tag === 'PRE') {
    const kids = [...el.children];
    const plain = !kids.length || (kids.length === 1 && kids[0].tagName === 'CODE' && !kids[0].children.length);

    return plain ? 'pre' : 'html';
  }

  if (tag === 'UL' || tag === 'OL') {
    return onlyChildren(el, IN_LISTS) ? tag.toLowerCase() : 'html';
  }

  if (tag === 'BLOCKQUOTE') {
    return onlyChildren(el, IN_QUOTES) ? 'blockquote' : 'html';
  }

  if (/^(P|H[1-6])$/.test(tag)) {
    return onlyChildren(el, PHRASING) ? tag.toLowerCase() : 'html';
  }

  return 'html';
}

/**
 * Reads the HTML of an article into a list of { type, el }. Loose text and
 * inline elements at the top level are gathered into paragraphs, as
 * TinyMCE does with its forced root block.
 */
/*
 * WHAT A BROWSER EXTENSION LEAVES IN A TYPED ZONE (Cyrille: an empty
 * `<div class="notranslate" style="all: initial;">` saved at the end of an
 * article): an element shielded from the site's styles and from translators,
 * with nothing in it. Never the author's; removed on load and on save.
 */
export function dropForeign(root) {
  root.querySelectorAll('.notranslate[style]').forEach((n) => {
    if (/(^|;)\s*all\s*:\s*initial/i.test(n.getAttribute('style')) && !n.textContent.replace(/[\s\u00a0]/g, '') && !n.querySelector('img, svg, iframe, video')) {
      n.remove();
    }
  });
}

export function parse(html) {
  const body = new DOMParser().parseFromString(`<body>${html || ''}</body>`, 'text/html').body;

  dropForeign(body);

  return parseNodes(body.childNodes);
}

export function parseNodes(nodes) {
  const list = [];
  let loose = null;

  [...nodes].forEach((n) => {
    const inline = n.nodeType === Node.TEXT_NODE || (isElement(n) && PHRASING.has(n.tagName) && n.tagName !== 'IMG');

    if (inline) {
      if (!loose && n.nodeType === Node.TEXT_NODE && !n.textContent.trim()) {
        return;
      }

      loose = loose || document.createElement('p');
      loose.appendChild(document.importNode(n, true));

      return;
    }

    if (loose) {
      list.push({ type: detect(loose), el: loose });
      loose = null;
    }

    if (n.nodeType === Node.COMMENT_NODE) {
      list.push({ type: 'html', html: `<!--${n.data}-->` });
    } else if (isElement(n)) {
      let el = document.importNode(n, true);

      // A lone image goes in a paragraph, as TinyMCE puts it.
      if (el.tagName === 'IMG') {
        const p = document.createElement('p');

        p.appendChild(el);
        el = p;
      }

      list.push({ type: detect(el), el });
    }
  });

  if (loose && loose.textContent.trim()) {
    list.push({ type: detect(loose), el: loose });
  }

  return list;
}

/** A new, empty stored element for a type chosen in the block list. */
export function emptyElement(type) {
  switch (type) {
    case 'ul':
    case 'ol':
    case 'blockquote': {
      // The inner line holds a <br>: browsers cannot put the caret in an empty line.
      const el = document.createElement(type);
      const line = el.appendChild(document.createElement(type === 'blockquote' ? 'p' : 'li'));

      line.appendChild(document.createElement('br'));

      return el;
    }
    case 'callout': {
      // An information message; its title is written by markus.js, in the language of the site.
      const box = document.createElement('div');

      box.className = 'message rule message--info';
      box.setAttribute('role', 'note');
      box.innerHTML = '<div><p class="message__titre"></p><p><br></p></div>';

      return box;
    }
    case 'pre':
      return document.createElement('pre');
    case 'separator':
      return document.createElement('hr');
    case 'readmore': {
      const hr = document.createElement('hr');

      hr.id = 'system-readmore';

      return hr;
    }
    case 'table':
      return emptyTable(2, 3);
    case 'columns':
      return emptyColumns([6, 6]);
    case 'buttons': {
      const p = document.createElement('p');

      p.innerHTML = '<a class="btn btn-primary" href="#"></a>';

      return p;
    }
    default:
      return document.createElement(TEXT_TYPES.includes(type) ? type : 'p');
  }
}

/** A table with a header row, inside Bootstrap's responsive wrapper. */
export function emptyTable(rows, cols) {
  const wrap = document.createElement('div');
  const cells = (tag) => `<tr>${`<${tag}></${tag}>`.repeat(cols)}</tr>`;

  wrap.className = 'table-responsive';
  wrap.innerHTML = `<table class="table"><thead>${cells('th').replace(/<th>/g, '<th scope="col">')}</thead>`
    + `<tbody>${cells('td').repeat(rows)}</tbody></table>`;

  return wrap;
}

/** A Bootstrap row, widths in twelfths, stacked under the `md` breakpoint. */
export function emptyColumns(widths) {
  const row = document.createElement('div');

  row.className = 'row';
  widths.forEach((w) => {
    const col = document.createElement('div');

    col.className = `col-md-${w}`;
    col.appendChild(document.createElement('p'));
    row.appendChild(col);
  });

  return row;
}

/** Remembers what a card block saves (module, separator, raw HTML). */
export function keep(block, value) {
  stored.set(block, value);
}

export function kept(block) {
  return stored.get(block);
}

/** True when a text block has nothing worth saving. */
export function isEmpty(el) {
  return !el.textContent.trim() && !el.querySelector('img, br + br, hr');
}

/**
 * A clean copy of an edited element: editor attributes and chrome removed,
 * <b> and <i> turned into <strong> and <em> (what TinyMCE saves as well),
 * the <br> a browser leaves at the end of a block dropped.
 */
export function cleanClone(el) {
  const copy = el.cloneNode(true);

  copy.querySelectorAll('.mk-ui').forEach((n) => n.remove());
  dropForeign(copy);
  [copy, ...copy.querySelectorAll('*')].forEach((n) => {
    if (n.hasAttribute('data-mk-src')) {
      n.setAttribute('src', n.getAttribute('data-mk-src'));
    }

    // Hidden on the site: HTML's own `hidden`, every template honours it (Bootstrap, Corpus).
    if (n.hasAttribute('data-mk-hidden')) {
      n.setAttribute('hidden', '');
    }

    editAttrsOf(n).forEach((a) => n.removeAttribute(a));

    // Browsers leave empty style or class attributes behind: they carry nothing.
    ['style', 'class'].forEach((a) => {
      if (n.getAttribute(a) === '') {
        n.removeAttribute(a);
      }
    });
  });

  copy.querySelectorAll('b, i').forEach((n) => {
    const better = document.createElement(n.tagName === 'B' ? 'strong' : 'em');

    [...n.attributes].forEach((a) => better.setAttribute(a.name, a.value));
    better.append(...n.childNodes);
    n.replaceWith(better);
  });

  // The zero-width spaces that hold the caret outside a new <strong> or <code>.
  const walker = document.createTreeWalker(copy, NodeFilter.SHOW_TEXT);

  while (walker.nextNode()) {
    if (walker.currentNode.data.includes('\u200b')) {
      walker.currentNode.data = walker.currentNode.data.replace(/\u200b/g, '');
    }
  }

  // Chrome wraps merged text in bare spans; they carry nothing.
  copy.querySelectorAll('span:not([class]):not([style]):not([lang]):not([id]):not([title])').forEach((n) => {
    n.replaceWith(...n.childNodes);
  });

  [copy, ...copy.querySelectorAll('p, li, h1, h2, h3, h4, h5, h6, td, th, figcaption, caption')].forEach((n) => {
    const last = n.lastChild;

    if (last && last.nodeName === 'BR') {
      last.remove();
    }
  });

  return copy;
}

/** Indents every line of a fragment, for readable nested columns. */
function indent(html, pad) {
  return html.split('\n').map((line) => (line ? pad + line : line)).join('\n');
}

/**
 * The saved HTML of one block wrapper. `children` serialises the blocks of a
 * column; it is passed in by markus.js, which knows the wrappers.
 */
export function serialize(block, children) {
  const type = block.dataset.type;
  const el = block.querySelector(':scope > .mk-body');

  switch (type) {
    case 'module':
    case 'separator':
    case 'readmore':
    case 'html':
      return kept(block) || '';
    case 'columns': {
      const row = el.cloneNode(false);

      if (row.hasAttribute('data-mk-hidden')) {
        row.setAttribute('hidden', '');
      }

      EDIT_ATTRS.forEach((a) => row.removeAttribute(a));
      row.classList.remove('mk-body');

      const cols = [...el.children].filter((c) => !c.classList.contains('mk-ui')).map((col) => {
        const copy = col.cloneNode(false);

        copy.classList.remove('mk-column');
        EDIT_ATTRS.concat(['role']).forEach((a) => copy.removeAttribute(a));

        const inner = children(col);

        return `${copy.outerHTML.replace(/<\/div>$/, '')}\n${indent(inner, '  ')}\n</div>`;
      });

      return `${row.outerHTML.replace(/<\/div>$/, '')}\n${indent(cols.join('\n'), '  ')}\n</div>`;
    }
    default: {
      const copy = cleanClone(el);

      copy.classList.remove('mk-body');

      if (!copy.classList.length) {
        copy.removeAttribute('class');
      }

      return copy.outerHTML;
    }
  }
}

/** The text a block shows to the word counter. */
export function textOf(block) {
  const el = block.querySelector(':scope > .mk-body');

  return TEXT_TYPES.includes(block.dataset.type) || block.dataset.type === 'table' ? el.textContent : '';
}

/** The module id of a {loadmoduleid N} paragraph. */
export function moduleId(html) {
  const m = MODULE.exec(String(html).replace(/<\/?p>/g, '').trim());

  return m ? Number(m[1]) : 0;
}

/** Makes a relative image address usable in the administrator, where it would point to /administrator. */
export function previewImages(el, root) {
  [el, ...el.querySelectorAll('img')].filter((n) => n.tagName === 'IMG').forEach((img) => {
    const src = img.getAttribute('src') || '';

    if (src && !/^([a-z]+:|\/|#)/i.test(src)) {
      img.setAttribute('data-mk-src', src);
      img.setAttribute('src', root + src);
    }
  });
}
