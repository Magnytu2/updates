/**
 * Markus Editor: spelling and grammar with LanguageTool (Cyrille: "it matters
 * to me, TinyMCE cannot do it"; the public service, his choice of
 * 13 October 2026).
 *
 * Only when asked (the "Orthographe" button): the text of the article is sent
 * to LanguageTool's public service (api.languagetool.org), the panel says so.
 * The findings are listed in the side panel, as the accessibility check is:
 * nothing is written into the article, no mark to forget on save. A
 * suggestion is put in place with the browser's own typing, so Ctrl+Z
 * takes it back.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

import { t, escape } from 'plg_editors_markus.i18n';

// The address comes from the settings of the plugin (MarkusProvider::spell): the public service or the site's own server.
const PUBLIC_API = 'https://api.languagetool.org/v2/check';
const apiOf = (m) => (m.options.spell && m.options.spell.url) || PUBLIC_API;
// The public service takes 20 KB a request: the article goes in parts of whole lines.
const PART = 15000;
// Elements that end a line: their words are not glued to the next ones.
const LINE = /^(P|LI|H[1-6]|DIV|TD|TH|CAPTION|FIGCAPTION|BLOCKQUOTE|FOOTER|UL|OL|BR)$/;
// Language variants LanguageTool knows by their full code; the others by their language alone.
const VARIANTS = ['en-GB', 'en-US', 'en-AU', 'en-CA', 'en-NZ', 'en-ZA', 'de-DE', 'de-AT', 'de-CH', 'pt-PT', 'pt-BR', 'pt-AO', 'pt-MZ', 'ca-ES'];

/**
 * The text of a typed zone, with where each piece of it comes from. The
 * pieces nobody types (a footnote's number, its way back) are left out.
 */
function textOf(host) {
  const pieces = [];
  let text = '';
  const walk = (node) => {
    node.childNodes.forEach((n) => {
      if (n.nodeType === Node.TEXT_NODE) {
        pieces.push({ node: n, start: text.length });
        text += n.nodeValue;
      } else if (n.nodeType === Node.ELEMENT_NODE && n.getAttribute('contenteditable') !== 'false' && !n.classList.contains('mk-ui')) {
        if (LINE.test(n.tagName) && text && !text.endsWith('\n')) {
          text += '\n';
        }

        walk(n);
      }
    });
  };

  walk(host);

  return { host, text, pieces };
}

/** The range of `length` characters from `offset` in a zone read by textOf(). */
function rangeIn(zone, offset, length) {
  const at = (pos, end) => {
    const p = zone.pieces.filter((x) => x.start <= pos && (end ? pos <= x.start + x.node.nodeValue.length : pos < x.start + x.node.nodeValue.length)).pop();

    return p ? [p.node, pos - p.start] : null;
  };
  const a = at(offset, false);
  const b = at(offset + length, true);

  if (!a || !b) {
    return null;
  }

  const r = document.createRange();

  r.setStart(...a);
  r.setEnd(...b);

  return r;
}

/** The language of the article (its own, or the one of the administration), as LanguageTool names it. */
function language() {
  const field = document.getElementById('jform_language');
  const code = (field && field.value && field.value !== '*' ? field.value : document.documentElement.lang) || 'fr-FR';

  // The page may say "fr-fr": the region in capitals, as LanguageTool writes it.
  const [lang, region] = code.split('-');
  const full = region ? `${lang.toLowerCase()}-${region.toUpperCase()}` : lang.toLowerCase();

  return VARIANTS.includes(full) ? full : lang.toLowerCase();
}

async function ask(m, text, lang) {
  // A service that does not answer gives up after 15 s: the live underlining must never stay waiting.
  const stop = new AbortController();
  const timer = window.setTimeout(() => stop.abort(), 15000);
  let response;

  try {
    response = await fetch(apiOf(m), {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
      body: new URLSearchParams({ text, language: lang }),
      signal: stop.signal,
    });
  } finally {
    window.clearTimeout(timer);
  }

  if (!response.ok) {
    throw new Error(String(response.status));
  }

  return (await response.json()).matches || [];
}

/**
 * Reads the whole article: every typed zone, sent in parts, each finding tied
 * to its zone and to the very words it is about.
 */
export async function spellCheck(m) {
  const zones = m.textHosts().map(textOf).filter((z) => z.text.trim());
  const lang = language();
  const found = [];
  let part = [];
  let size = 0;

  const send = async () => {
    if (!part.length) {
      return;
    }

    const text = part.map((z) => z.text).join('\n\n');
    const matches = await ask(m, text, lang);
    let start = 0;
    const starts = part.map((z) => { const s = start; start += z.text.length + 2; return s; });

    matches.forEach((match) => {
      const i = starts.filter((s) => s <= match.offset).length - 1;
      const zone = part[i];
      const offset = match.offset - starts[i];

      if (zone && offset + match.length <= zone.text.length) {
        found.push({ zone, offset, length: match.length, words: zone.text.substr(offset, match.length), match });
      }
    });
    part = [];
    size = 0;
  };

  for (const zone of zones) {
    if (size + zone.text.length > PART) {
      // eslint-disable-next-line no-await-in-loop
      await send();
    }

    part.push(zone);
    size += zone.text.length + 2;
  }

  await send();

  return found;
}

/** Puts a suggestion in place of the words, if they are still there. */
export function applySuggestion(m, finding, value) {
  const zone = textOf(finding.zone.host);
  let offset = finding.offset;

  // The text moved since the check (another suggestion before it): the same words, the nearest.
  if (zone.text.substr(offset, finding.length) !== finding.words) {
    const all = [];
    let i = zone.text.indexOf(finding.words);

    while (i >= 0) {
      all.push(i);
      i = zone.text.indexOf(finding.words, i + 1);
    }

    if (!all.length) {
      return false;
    }

    offset = all.sort((a, b) => Math.abs(a - finding.offset) - Math.abs(b - finding.offset))[0];
  }

  const r = rangeIn(zone, offset, finding.length);

  if (!r) {
    return false;
  }

  finding.zone.host.focus({ preventScroll: true });
  window.getSelection().removeAllRanges();
  window.getSelection().addRange(r);
  document.execCommand('insertText', false, value);
  m.changed();

  return true;
}

/** Shows the words of a finding: the block in view, the words selected. */
export function showFinding(finding) {
  const zone = textOf(finding.zone.host);
  const offset = zone.text.substr(finding.offset, finding.length) === finding.words ? finding.offset : zone.text.indexOf(finding.words);
  const r = offset >= 0 ? rangeIn(zone, offset, finding.length) : null;

  finding.zone.host.scrollIntoView({ block: 'center' });
  finding.zone.host.focus({ preventScroll: true });

  if (r) {
    window.getSelection().removeAllRanges();
    window.getSelection().addRange(r);
  }
}

/** The list of the panel: each finding, its words in their sentence, its suggestions. */
export function spellList(found) {
  if (!found.length) {
    return `<ul class="mk-alerts"><li class="mk-alerts__ok"><span><strong>${escape(t('SPELL_NONE_TITLE'))}</strong>${escape(t('SPELL_NONE_TEXT'))}</span></li></ul>`;
  }

  return `<ul class="mk-alerts mk-spell">${found.map((f, i) => {
    const text = f.zone.text;
    // About forty letters around the words, cut between two words.
    const from = Math.max(0, f.offset - 40);
    const to = f.offset + f.length + 40;
    const before = (from ? '\u2026' : '') + text.slice(from, f.offset).replace(from ? /^\S*\s/ : /^/, '').replace(/^.*\n/s, '');
    const after = text.slice(f.offset + f.length, to).replace(to < text.length ? /\s\S*$/ : /$/, '').replace(/\n.*$/s, '') + (to < text.length ? '\u2026' : '');
    const suggestions = f.match.replacements.slice(0, 4);

    return `<li data-i="${i}"${f.match.rule && f.match.rule.issueType === 'misspelling' ? ' class="mk-spell__typo"' : ''}><span>`
      + `<strong>${escape(f.match.shortMessage || f.match.message)}</strong>`
      + `<span class="mk-spell__context">${escape(before)}<mark>${escape(f.words)}</mark>${escape(after)}</span>`
      + (f.match.shortMessage && f.match.message !== f.match.shortMessage ? `<span class="mk-spell__more">${escape(f.match.message)}</span>` : '')
      + `<span class="mk-buttons">${suggestions.map((s, j) => (
        `<button type="button" class="btn btn-sm btn-outline-success" data-fix="${j}">${escape(s.value || t('SPELL_REMOVE'))}</button>`)).join('')}`
      + `<button type="button" class="btn btn-sm btn-outline-secondary" data-show>${escape(t('SPELL_SHOW'))}</button>`
      + `<button type="button" class="btn btn-sm btn-outline-secondary" data-ignore>${escape(t('SPELL_IGNORE'))}</button></span>`
      + '</span></li>';
  }).join('')}</ul>`;
}

/*
 * LIVE UNDERLINING (Cyrille: "is the text not underlined live when there is
 * a mistake?"). A moment after one stops typing, the zones whose text changed
 * (and only those) go to LanguageTool; its findings are underlined with the
 * browser's CSS Custom Highlight API: drawn over the text, NOTHING is written
 * into the article. A right click on underlined words offers the suggestions
 * (markus.js, textMenu). It can be turned off in the panel; the choice is
 * kept in the browser. The browser's own spelling is off meanwhile (two
 * underlinings would mix).
 */
const LIVE_KEY = 'markus:spell-live';
const PAUSE = 1500;

export class LiveSpell {
  constructor(m) {
    this.m = m;
    this.done = new WeakMap();
    this.timer = 0;
    this.busy = false;
    this.again = false;
    // The browser draws highlights, and the site allows live checking (settings of the plugin).
    this.able = typeof CSS !== 'undefined' && !!CSS.highlights && typeof Highlight !== 'undefined'
      && !!m.options.spell && m.options.spell.live !== false;
    this.on = this.able && this.wanted();
    this.m.surface.spellcheck = !this.on;
  }

  wanted() {
    try {
      return window.localStorage.getItem(LIVE_KEY) !== 'off';
    } catch (e) {
      return true;
    }
  }

  turn(on) {
    this.on = this.able && on;
    this.m.surface.spellcheck = !this.on;

    try {
      window.localStorage.setItem(LIVE_KEY, on ? 'on' : 'off');
    } catch (e) {
      // Kept for this session only.
    }

    if (this.on) {
      this.schedule();
    } else {
      this.done = new WeakMap();
      CSS.highlights.delete('mk-spell');
      CSS.highlights.delete('mk-grammar');
    }
  }

  /** After a change (markus.js, changed): the zones read again a moment after the last key. */
  schedule() {
    if (!this.on) {
      return;
    }

    window.clearTimeout(this.timer);
    this.timer = window.setTimeout(() => this.run(), PAUSE);
    this.paint();
  }

  async run() {
    if (this.busy) {
      this.again = true;

      return;
    }

    const zones = this.m.textHosts().map(textOf).filter((z) => z.text.trim() && (this.done.get(z.host) || {}).text !== z.text);

    if (!zones.length) {
      return;
    }

    this.busy = true;

    try {
      const lang = language();
      const ignored = this.m.spellIgnored();
      let part = [];
      let size = 0;
      const send = async () => {
        if (!part.length) {
          return;
        }

        const matches = await ask(this.m, part.map((z) => z.text).join('\n\n'), lang);
        let start = 0;
        const starts = part.map((z) => { const s = start; start += z.text.length + 2; return s; });

        part.forEach((z) => this.done.set(z.host, { text: z.text, found: [] }));
        matches.forEach((match) => {
          const i = starts.filter((s) => s <= match.offset).length - 1;
          const zone = part[i];
          const offset = match.offset - starts[i];
          const words = zone ? zone.text.substr(offset, match.length) : '';

          if (zone && offset + match.length <= zone.text.length
            && !(match.rule && match.rule.issueType === 'misspelling' && ignored.has(words))) {
            this.done.get(zone.host).found.push({ zone, offset, length: match.length, words, match });
          }
        });
        part = [];
        size = 0;
      };

      for (const zone of zones) {
        if (size + zone.text.length > PART) {
          // eslint-disable-next-line no-await-in-loop
          await send();
        }

        part.push(zone);
        size += zone.text.length + 2;
      }

      await send();
    } catch (e) {
      // The public service said no (too many checks a minute): the next pause tries again.
    }

    this.busy = false;
    this.paint();

    if (this.again) {
      this.again = false;
      this.schedule();
    }
  }

  /** The findings of the zones still on the page, each where its words are now. */
  findings() {
    return this.m.textHosts().flatMap((host) => {
      const done = this.done.get(host);

      if (!done || !done.found.length) {
        return [];
      }

      const zone = textOf(host);

      return done.found.filter((f) => zone.text.substr(f.offset, f.length) === f.words).map((f) => ({ ...f, zone }));
    });
  }

  paint() {
    if (!this.able) {
      return;
    }

    if (!this.on) {
      return;
    }

    const spell = [];
    const grammar = [];

    this.findings().forEach((f) => {
      const r = rangeIn(f.zone, f.offset, f.length);

      if (r) {
        (f.match.rule && f.match.rule.issueType === 'misspelling' ? spell : grammar).push(r);
      }
    });

    CSS.highlights.set('mk-spell', new Highlight(...spell));
    CSS.highlights.set('mk-grammar', new Highlight(...grammar));
  }

  /** The finding under a caret (a collapsed range), for the menu of the right click. */
  at(range) {
    if (!this.on || !range) {
      return null;
    }

    const host = (range.startContainer.nodeType === Node.ELEMENT_NODE ? range.startContainer : range.startContainer.parentNode).closest('[contenteditable="true"]');

    if (!host) {
      return null;
    }

    const zone = textOf(host);
    const piece = zone.pieces.find((p) => p.node === range.startContainer);

    if (!piece) {
      return null;
    }

    const pos = piece.start + range.startOffset;

    return this.findings().find((f) => f.zone.host === host && f.offset <= pos && pos <= f.offset + f.length) || null;
  }

  /** A suggestion taken or words ignored: the underlining follows at once. */
  forget(finding) {
    const done = this.done.get(finding.zone.host);

    if (done) {
      done.found = done.found.filter((f) => !(f.words === finding.words && f.offset === finding.offset));
    }

    this.paint();
  }
}
