/**
 * Markus Editor: cleaning, on demand (the "Clean" menu of the toolbar).
 *
 * Cleaning takes away the LOOK of the text (bold, italic, colours,
 * highlights, alignment) and keeps its MEANING: headings, lists, links,
 * tables, images and cards stay. Every operation is undone by Ctrl+Z.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

import { wipe, paint } from 'plg_editors_markus.colours';

const ALIGN = ['text-start', 'text-center', 'text-end'];

/** What cleaning unwraps. The spoken "new window" of a link is not a look: it stays. */
const LOOKS = 'strong, b, em, i, mark, u, s, font, code, span:not(.visually-hidden)';

const unwrap = (n) => n.replaceWith(...n.childNodes);

/** Takes the look away from an editable element. Returns true when something changed. */
export function flatten(el) {
  const before = el.outerHTML;

  el.querySelectorAll(LOOKS).forEach(unwrap);
  wipe(el, 'all');
  el.classList.remove(...ALIGN);

  if (!el.classList.length) {
    el.removeAttribute('class');
  }

  el.normalize();

  return el.outerHTML !== before;
}

/**
 * Takes the look away from the selection, which the browser holds in
 * `host`. The browser's own command splits a bold or a colour that goes
 * beyond the selection; the highlights and colour classes it leaves are
 * taken away by colours.js, text by text.
 */
export function flattenSelection(host) {
  const before = host.innerHTML;
  const selection = window.getSelection();

  document.execCommand('removeFormat');

  if (selection.rangeCount) {
    paint(selection.getRangeAt(0), host, { target: 'all' });
  }

  return host.innerHTML !== before;
}

/*
 * FRENCH TYPOGRAPHY: a narrow no-break space before ; ! ? and a no-break
 * space before : and inside « », as the Imprimerie nationale rules say.
 * Never in code, a keyboard key or a link (an address would break), never
 * between two marks ("?!"), never in a time ("10:30").
 */
const NBSP = '\u00a0';
const NARROW = '\u202f';
const RULES = [
  [/[ \u00a0]([;!?])(?=\s|$)/g, `${NARROW}$1`],
  [/([^\s\u00a0\u202f;!?:])([;!?])(?=\s|$)/g, `$1${NARROW}$2`],
  [/[ \u202f]:(?=\s|$)/g, `${NBSP}:`],
  [/([^\s\u00a0\u202f\d;!?:]):(?=\s|$)/g, `$1${NBSP}:`],
  [/\u00ab[ \u00a0\u202f]?/g, `\u00ab${NBSP}`],
  [/[ \u00a0\u202f]?\u00bb/g, `${NBSP}\u00bb`],
];

/** Applies the French typography to the text of `hosts`. Returns the number of texts changed. */
export function frenchTypography(hosts) {
  let changed = 0;

  hosts.forEach((host) => {
    const walk = document.createTreeWalker(host, NodeFilter.SHOW_TEXT);
    const texts = [];

    while (walk.nextNode()) {
      if (!walk.currentNode.parentNode.closest('code, kbd, samp, pre, a, .mk-ui')) {
        texts.push(walk.currentNode);
      }
    }

    texts.forEach((n) => {
      const value = RULES.reduce((v, [find, put]) => v.replace(find, put), n.nodeValue);

      if (value !== n.nodeValue) {
        n.nodeValue = value;
        changed += 1;
      }
    });
  });

  return changed;
}
