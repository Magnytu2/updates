/**
 * Markus Editor: the block chooser.
 *
 * Opened by a "+" button or by typing "/" in an empty paragraph. A search
 * field drives a list of choices (the ARIA combobox pattern): arrows move,
 * Enter picks, Escape closes and gives the focus back.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

import { t, escape } from 'plg_editors_markus.i18n';

let open = null;

/** Closes the chooser that is open, if any. */
export function closeChooser(giveFocusBack = true) {
  if (!open) {
    return;
  }

  const { box, back, outside } = open;

  open = null;
  document.removeEventListener('pointerdown', outside, true);
  box.remove();

  if (giveFocusBack && back && document.contains(back)) {
    back.focus({ preventScroll: true });
  }
}

/**
 * Opens the chooser in the middle of the window (`anchor`, the button that
 * asked, no longer places it). `groups` is [{ title, items: [{ id,
 * label, hint, sign, icon, keys }] }]. Resolves with the picked item, or null.
 * `icon` names a pictogram of Markus (`.mk-xtd--*`), drawn in place of the
 * `sign`; `hot` is a keyboard shortcut, shown after the Markdown `keys`.
 */
export function openChooser(anchor, groups, back) {
  closeChooser(false);

  return new Promise((resolve) => {
    const uid = `mk-chooser-${Date.now()}`;
    const box = document.createElement('div');

    box.className = 'mk-chooser';
    box.innerHTML = `<label class="visually-hidden" for="${uid}-q">${escape(t('CHOOSER_SEARCH'))}</label>`
      + `<input type="search" id="${uid}-q" class="mk-chooser__search" role="combobox" aria-expanded="true"`
      + ` aria-controls="${uid}-list" aria-autocomplete="list" autocomplete="off" placeholder="${escape(t('CHOOSER_SEARCH'))}">`
      + `<div id="${uid}-list" class="mk-chooser__list" role="listbox" aria-label="${escape(t('CHOOSER'))}"></div>`;

    const search = box.querySelector('input');
    const list = box.querySelector('[role="listbox"]');
    let options = [];
    let shown = [];
    let active = 0;

    const finish = (item) => {
      closeChooser(!item);
      resolve(item);
    };

    const highlight = (i) => {
      options.forEach((o, n) => o.setAttribute('aria-selected', n === i ? 'true' : 'false'));
      active = i;

      if (options[i]) {
        search.setAttribute('aria-activedescendant', options[i].id);
        options[i].scrollIntoView({ block: 'nearest' });
      } else {
        search.removeAttribute('aria-activedescendant');
      }
    };

    const render = () => {
      const q = search.value.trim().toLowerCase();
      let html = '';
      let n = 0;
      const flat = [];

      groups.forEach((g, gi) => {
        // A prefix match ranks first: "/ta" must give Table, not a word containing "ta".
        const items = g.items.filter((it) => !q || `${it.label} ${it.hint || ''} ${it.keys || ''}`.toLowerCase().includes(q))
          .sort((a, b) => Number(!a.label.toLowerCase().startsWith(q)) - Number(!b.label.toLowerCase().startsWith(q)));

        if (!items.length) {
          return;
        }

        html += `<div role="group" aria-labelledby="${uid}-g${gi}"><div class="mk-chooser__title" id="${uid}-g${gi}">${escape(g.title)}</div>`;
        items.forEach((it) => {
          flat.push(it);
          html += `<div role="option" id="${uid}-o${n}" class="mk-chooser__option" data-n="${n}" aria-selected="false"${it.hot ? ` aria-keyshortcuts="Alt+Shift+${escape(it.hot.slice(-1))}"` : ''}>`
            + `<span class="mk-chooser__sign" aria-hidden="true">${it.icon ? `<span class="mk-xtd mk-xtd--${escape(it.icon)}"></span>` : escape(it.sign || '')}</span>`
            + `<span class="mk-chooser__label">${escape(it.label)}${it.hint ? `<small>${escape(it.hint)}</small>` : ''}</span>`
            + `<span class="mk-chooser__keys">${[it.keys, it.hot].filter(Boolean).map((k) => `<kbd aria-hidden="true">${escape(k)}</kbd>`).join('')}</span></div>`;
          n += 1;
        });
        html += '</div>';
      });

      list.innerHTML = html || `<div class="mk-chooser__empty">${escape(t('CHOOSER_NOTHING'))}</div>`;
      options = [...list.querySelectorAll('[role="option"]')];
      shown = flat;
      highlight(options.length ? 0 : -1);
    };

    search.addEventListener('input', render);
    search.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        if (options.length) {
          highlight((active + (e.key === 'ArrowDown' ? 1 : options.length - 1)) % options.length);
        }
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (options[active]) {
          finish(shown[active]);
        }
      } else if (e.key === 'Escape' || e.key === 'Tab') {
        e.preventDefault();
        e.stopPropagation();
        finish(null);
      }
    });

    // `pointerdown` keeps the focus in the search field while choosing.
    list.addEventListener('pointerdown', (e) => e.preventDefault());
    list.addEventListener('click', (e) => {
      const o = e.target.closest('[role="option"]');

      if (o) {
        finish(shown[Number(o.dataset.n)]);
      }
    });

    const outside = (e) => {
      if (!box.contains(e.target)) {
        finish(null);
      }
    };

    open = { box, back, outside };
    document.addEventListener('pointerdown', outside, true);

    // Always in the middle of the window (Cyrille: "its place was not always easy"): the CSS centres it.
    document.body.appendChild(box);
    render();
    search.focus({ preventScroll: true });
  });
}
