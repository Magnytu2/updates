/**
 * Markus Editor: nested lists. Tab puts an item one level deeper, under the
 * item before it; Shift+Tab brings it one level up, after its parent item.
 * The sub-list takes the tag of the list it sits in (ul or ol), as TinyMCE
 * and Gutenberg do.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

const LIST = /^(UL|OL)$/;

/** The sub-list at the end of an item, made when it has none. */
function subList(li, tag) {
  const last = li.lastElementChild;

  if (last && LIST.test(last.tagName)) {
    return last;
  }

  // The <br> that keeps an empty line open has no place before a sub-list.
  if (li.lastChild && li.lastChild.nodeName === 'BR' && li.childNodes.length > 1) {
    li.lastChild.remove();
  }

  return li.appendChild(document.createElement(tag));
}

/** One level deeper. Returns false when the item has no item before it. */
export function indent(li) {
  const before = li.previousElementSibling;

  if (!before || before.tagName !== 'LI') {
    return false;
  }

  subList(before, li.parentNode.tagName.toLowerCase()).appendChild(li);

  return true;
}

/**
 * One level up: the item follows its parent item, and the items that came
 * after it in its list become its own sub-items, so the reading order stays.
 * Returns false at the first level.
 */
export function outdent(li) {
  const list = li.parentNode;
  const parent = list.parentNode;

  if (!parent || parent.tagName !== 'LI') {
    return false;
  }

  const after = [];

  for (let n = li.nextElementSibling; n; n = n.nextElementSibling) {
    after.push(n);
  }

  if (after.length) {
    subList(li, list.tagName.toLowerCase()).append(...after);
  }

  parent.after(li);

  if (!list.children.length) {
    list.remove();
  }

  return true;
}
