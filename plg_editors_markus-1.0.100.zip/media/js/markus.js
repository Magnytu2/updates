/**
 * Markus Editor: the editor.
 *
 * One instance per editor field. It builds the toolbar, the writing surface
 * and the status line in front of the field's <textarea>, which stays in the
 * form and always holds the saved HTML (see sync()).
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

import { JoomlaEditor } from 'editor-api';
import { t, escape } from 'plg_editors_markus.i18n';
import {
  TEXT_TYPES, parse, parseNodes, emptyElement, calloutLines, keep, kept, isEmpty, serialize,
  textOf, moduleId, previewImages,
} from 'plg_editors_markus.blocks';
import { cleanPasted, looksLikeMarkdown, textToHtml } from 'plg_editors_markus.paste';
import { markdownToHtml, htmlToMarkdown, headings } from 'plg_editors_markus.markdown';
import { openChooser, closeChooser } from 'plg_editors_markus.chooser';
import { linkDialog } from 'plg_editors_markus.dialogs';
import { openSettings, countSettings } from 'plg_editors_markus.settings';
import { chooseColour, paint } from 'plg_editors_markus.colours';
import { openMenu, toggleMenu } from 'plg_editors_markus.menu';
import { flatten, flattenSelection, frenchTypography } from 'plg_editors_markus.clean';
import { audit } from 'plg_editors_markus.check';
import { indent, outdent } from 'plg_editors_markus.lists';
import { langAt, setLang, toggleTag } from 'plg_editors_markus.inline';
import { insertNote, syncNotes, lockNotes } from 'plg_editors_markus.notes';
import Finder from 'plg_editors_markus.find';
import { Breaks, splitLines, joinWithBreak, lineBreaks, cuttable } from 'plg_editors_markus.breaks';
import { spellCheck, spellList, applySuggestion, showFinding, LiveSpell } from 'plg_editors_markus.spell';

/**
 * The block list, in the order of the chooser. `keys` is the Markdown that
 * makes the block; `hot`, the digit of its Alt+Shift shortcut (HOTKEYS).
 */
const CHOICES = [
  ['TEXT', [['p', '¶', '', '0'], ['h2', 'H2', '##', '2'], ['h3', 'H3', '###', '3'], ['h4', 'H4', '####', '4'],
    ['h5', 'H5', '#####', '5'], ['h6', 'H6', '######', '6'], ['ul', '•', '-', '8'],
    ['ol', '1.', '1.', '7'], ['blockquote', '“', '>'], ['callout', '▢'], ['pre', '{ }', '```']]],
  ['LAYOUT', [['image', '▣'], ['buttons', '⬭'], ['table', '▦'], ['columns', '▥'], ['separator', '―', '***'],
    ['readmore', '⋯', '---'], ['html', '</>']]],
];

/*
 * THE TYPE OF A TEXT BLOCK FROM THE KEYBOARD: Alt+Shift and a digit, read by
 * its key (`e.code`), so that it works on every keyboard. Not Ctrl+Alt (Google
 * Docs): on a French keyboard, Ctrl+Alt is AltGr, and AltGr+3 types "#".
 */
const HOTKEYS = Object.fromEntries(CHOICES[0][1].filter((c) => c[3]).map((c) => [`Digit${c[3]}`, c[0]]));

/** Markdown typed at the start of a paragraph, followed by a space. */
const SHORTCUTS = {
  '#': 'h2', '##': 'h2', '###': 'h3', '####': 'h4', '#####': 'h5', '######': 'h6', '-': 'ul', '*': 'ul', '+': 'ul', '1.': 'ol', '1)': 'ol', '>': 'blockquote',
};

/** Markdown typed inside a sentence: the closing mark wraps the text. */
const INLINE = [[/()\*\*([^*\s](?:[^*]*[^*\s])?)\*\*$/, 'strong'], [/(^|[^*\w])\*([^*\s](?:[^*]*[^*\s])?)\*$/, 'em'],
  [/(^|[^_\w])_([^_\s](?:[^_]*[^_\s])?)_$/, 'em'], [/()`([^`]+)`$/, 'code']];

const ALIGN = ['text-start', 'text-center', 'text-end'];
const HEADINGS = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
// Blocks with a gear: their own settings, or at least the Swiss army knife (settings.js).
const SETTINGS = ['image', 'buttons', 'table', 'columns', 'pre', 'ol', 'blockquote', 'callout', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul'];

/** What marks blocks copied from Markus on the clipboard: they come back whole, settings included. */
const CLIP = '<!--markus-blocks-->';

/** Words read in a minute, for the reading time (a common average for French and English). */
const READING_SPEED = 230;

/** The "+" of a block: the charter's card, on every block. Moving up and down is in the gear's panel
 * (Cyrille: the arrows crowded the gap between blocks); Alt+Shift+arrows still move a block. */
const PLUS = [['jmj-carte__plus jmj-carte__plus--dessus', 'add-before', 'ADD_BEFORE'],
  ['jmj-carte__plus jmj-carte__plus--dessous', 'add', 'ADD_AFTER']];

/*
 * THE PICTOGRAM OF AN EDITOR BUTTON in the block list, after its own Joomla
 * icon. Drawn by Markus (`.mk-xtd--*`, masks): the icon font of Atum lacks
 * some of them, which showed an empty box (Cyrille).
 */
const XTD_ICONS = {
  'icon-images': 'image', 'icon-pictures': 'image', 'icon-image': 'image', 'icon-puzzle': 'puzzle',
  'icon-envelope': 'envelope', 'icon-file-add': 'article', 'icon-address': 'contact', 'icon-list': 'list',
  'icon-cube': 'cube', 'icon-copy': 'pagebreak', 'icon-arrow-down': 'readmore',
};

/** Our own products show their logo: iris and iris_images, opus, formulus. */
const LOGOS = ['opus', 'iris', 'formulus'];
const logoOf = (name) => {
  const product = String(name || '').split('_')[0];

  return LOGOS.includes(product) ? `logo-${product}` : '';
};

const iconOf = (button) => {
  const icon = button.querySelector('[class^="icon-"], [class*=" icon-"]');
  const name = icon && [...icon.classList].find((c) => XTD_ICONS[c]);

  return name ? XTD_ICONS[name] : 'puzzle';
};

/** Editor buttons left out of the block list: Markus has its own block for them. */
const COVERED = ['image', 'iris_images', 'readmore'];

/** A small icon button of the editor chrome. */
function tool(cls, action, label, keys = '') {
  return `<button type="button" class="mk-ui ${cls}" data-mk="${action}" aria-label="${escape(label)}" title="${escape(label)}"`
    + `${keys ? ` aria-keyshortcuts="${keys}"` : ''}></button>`;
}

export default class Markus {
  constructor(host, textarea, options) {
    this.host = host;
    this.textarea = textarea;
    this.options = options;
    this.history = [];
    this.future = [];
    this.structural = false;
    this.range = null;
    this.current = null;
    this.pending = null;
    this.timer = 0;
    this.alerts = [];
    this.checkPanel = null;
    this.outlinePanel = null;
    this.spellPanel = null;
    this.spellFound = [];

    // A block tall enough shows its tools one under the other (CSS: .mk-block--tall).
    this.sizer = new ResizeObserver((entries) => entries.forEach(({ target }) => {
      target.classList.toggle('mk-block--tall', target.offsetHeight >= 72);
    }));

    this.build();
    this.finder = new Finder(this);
    this.breaks = new Breaks(this);
    this.live = new LiveSpell(this);
    this.load(textarea.value);
    this.listen();
  }

  /* ------------------------------------------------------------------ */
  /* THE INTERFACE                                                      */
  /* ------------------------------------------------------------------ */

  build() {
    const id = this.textarea.id;
    const wrap = document.createElement('div');

    wrap.className = 'mk';
    // At the very bottom, on the right (Cyrille): the version, then the settings (MarkusProvider::about).
    const about = (this.options.version ? `<span class="mk-version">${escape(t('VERSION', this.options.version))}</span>` : '')
      + (this.options.settings ? `<button type="button" class="mk-about__settings" data-mk="plugin-settings">${escape(t('PLUGIN_SETTINGS'))}</button>` : '');

    wrap.innerHTML = `<div class="mk-toolbar" role="toolbar" aria-label="${escape(t('TOOLBAR'))}" aria-controls="${id}-surface">`
      // A thinner line on top (Cyrille): the tools of the whole article, on the right.
      + '<div class="mk-toolbar__top">'
      + `<button type="button" class="mk-button mk-button--outline" data-mk="outline" title="${escape(t('OUTLINE_TITLE'))}">${escape(t('OUTLINE'))}</button>`
      + (this.options.spell ? `<button type="button" class="mk-button mk-button--spell" data-mk="spell" title="${escape(t('SPELL_TITLE'))}">${escape(t('SPELL'))}</button>` : '')
      + `<button type="button" class="mk-button mk-button--check" data-mk="check">${escape(t('CHECK'))}`
      + ' <span class="mk-badge" aria-hidden="true">0</span></button>'
      + `${this.button('find', '', t('FIND_TITLE'), 'Control+F', true)}`
      + `${this.button('markdown', 'M↓', t('MARKDOWN'), 'Control+Shift+M', true)}`
      + `${this.button('source', '', t('SOURCE'), 'Control+Shift+U', true)}`
      + `${this.button('full', '', t('FULL'), 'Control+Shift+F', true)}`
      + '</div><div class="mk-toolbar__main">'
      + `<button type="button" class="mk-button mk-button--type" data-mk="type" aria-haspopup="listbox">${escape(t('TYPE_P'))}</button>`
      // Undo and redo, for the mouse too (Cyrille: "when one makes a mess").
      + `<span class="mk-group">${this.button('undo', '', t('UNDO'), 'Control+Z')}${this.button('redo', '', t('REDO'), 'Control+Y')}</span>`
      + `<span class="mk-group">${this.button('bold', 'B', t('BOLD'), 'Control+B', true)}${this.button('italic', 'I', t('ITALIC'), 'Control+I', true)}${this.button('underline', 'U', t('UNDERLINE'), 'Control+U', true)}`
      + `${this.button('strike', '', t('CTX_STRIKE'), 'Control+Shift+X', true)}${this.button('code', '', t('CTX_CODE'), 'Control+E', true)}`
      + `${this.button('kbd', '', t('CTX_KBD'), '', true)}${this.button('sup', 'x²', t('CTX_SUP'), 'Control+Shift+=', true)}${this.button('sub', 'x₂', t('CTX_SUB'), 'Control+=', true)}</span>`
      + `<span class="mk-group">${this.button('link', '', t('LINK'), 'Control+K', true)}${this.button('colour', 'A', t('COLOURS'))}`
      + `${this.button('lang', '', t('CTX_LANG'))}${this.button('footnote', '', t('CTX_FOOTNOTE'), 'Control+Alt+F')}</span>`
      + `<span class="mk-group">${ALIGN.map((a) => this.button(`align ${a}`, '', t(`ALIGN_${a.slice(5).toUpperCase()}`), '', true)).join('')}</span>`
      + `<span class="mk-group">${this.button('insert', '', t('INSERT'), 'Control+Alt+N')}</span>`
      + `<span class="mk-group">${this.button('clean', t('CLEAN'), t('CLEAN_TITLE'))}</span>`
      + '</div></div>'
      // `data-lt-active="false"`: the LanguageTool browser extension stays out, Markus checks itself (Cyrille).
      + `<div class="mk-surface${this.options.corpus ? ' mk-corpus' : ''}" id="${id}-surface" role="region" aria-label="${escape(t('SURFACE'))}"`
      + ` style="--mk-min:${escape(this.options.height || '30rem')};--mk-welcome:${escape(JSON.stringify(t('WELCOME')))}" spellcheck="true" data-lt-active="false"></div>`
      + `<div class="mk-source" hidden><div class="mk-source__bar" hidden>`
      + `<button type="button" class="btn btn-sm btn-secondary" data-mk="md-open">${escape(t('MD_OPEN'))}</button>`
      + `<button type="button" class="btn btn-sm btn-secondary" data-mk="md-save">${escape(t('MD_SAVE'))}</button>`
      + `<input type="file" accept=".md,.markdown,text/markdown,text/plain" hidden>`
      + `<span class="mk-source__hint">${escape(t('MD_HINT'))}</span></div>`
      + `<label class="visually-hidden" for="${id}-code"></label>`
      + `<textarea id="${id}-code" class="mk-source__code" spellcheck="false" data-lt-active="false"></textarea></div>`
      + `<div class="mk-status"><span class="mk-status__count" aria-live="off"></span>`
      + '<span class="mk-status__say" role="status" aria-live="polite"></span>'
      + `${about ? `<span class="mk-about">${about}</span>` : ''}</div>`;

    this.textarea.before(wrap);
    this.textarea.hidden = true;

    // Joomla's editor buttons stay in the page (Markus runs them from its block
    // list and its link window) but out of sight: the block list replaces them.
    const bar = this.host.querySelector('.editor-xtd-buttons');

    if (bar) {
      bar.hidden = true;
    }
    this.root = wrap;
    this.toolbar = wrap.querySelector('.mk-toolbar');
    this.surface = wrap.querySelector('.mk-surface');
    this.source = wrap.querySelector('.mk-source');
    this.count = wrap.querySelector('.mk-status__count');
    this.voice = wrap.querySelector('.mk-status__say');
    this.toolbar.querySelectorAll('.mk-button').forEach((b, i) => { b.tabIndex = i ? -1 : 0; });
    this.toolbar.querySelectorAll('[data-mk="colour"], [data-mk="clean"]').forEach((b) => {
      b.setAttribute('aria-haspopup', 'menu');
      b.setAttribute('aria-expanded', 'false');
    });

    // Paragraphs, never <div>, when the browser creates a line in a quote.
    document.execCommand('defaultParagraphSeparator', false, 'p');

    // The module cards are the charter's (component "carte"): its sheet goes in the page once.
    window.JoomanjiCarte.habiller(document);
  }

  button(action, text, label, keys = '', toggle = false) {
    const [name, extra] = action.split(' ');

    return `<button type="button" class="mk-button mk-button--${name}${extra ? ` mk-button--${extra}` : ''}" data-mk="${name}"`
      + `${extra ? ` data-value="${extra}"` : ''} aria-label="${escape(label)}" title="${escape(label)}${keys ? ` (${keys.replace('Control', 'Ctrl')})` : ''}"`
      + `${keys ? ` aria-keyshortcuts="${keys}"` : ''}${toggle ? ' aria-pressed="false"' : ''}>${escape(text)}</button>`;
  }

  /** Reads a short message to screen readers, and shows it in the status line. */
  say(text) {
    this.voice.textContent = '';
    window.setTimeout(() => { this.voice.textContent = text; }, 30);
  }

  /* ------------------------------------------------------------------ */
  /* BLOCKS                                                             */
  /* ------------------------------------------------------------------ */

  typeName(type) {
    return t(`TYPE_${type.toUpperCase()}`);
  }

  /** The element where the author types in a block, or the block's first control. */
  editable(block) {
    if (!block) {
      return null;
    }

    const body = block.querySelector(':scope > .mk-body');

    switch (block.dataset.type) {
      case 'image':
        return body.querySelector('figcaption') || block.querySelector(':scope > .mk-tools [data-mk="settings"]');
      case 'table':
        return body.querySelector('caption, th, td');
      case 'buttons':
        return body.querySelector('a');
      case 'callout':
        return calloutLines(body);
      case 'columns':
        return this.editable(body.querySelector('.mk-block'));
      case 'html':
        return block.querySelector('textarea');
      case 'module':
      case 'separator':
      case 'readmore':
        return block.querySelector('.mk-card');
      case 'pre':
        return body.querySelector('code') || body;
      default:
        return body;
    }
  }

  /** Builds the wrapper of one block around its stored element. */
  makeBlock({ type, el, html }) {
    const block = document.createElement('div');
    const name = this.typeName(type);
    let body = el;

    block.className = 'mk-block';
    block.dataset.type = type;
    this.sizer.observe(block);

    // A block hidden on the site (`hidden`) stays seen here, faded: `data-mk-hidden` while editing (blocks.js, cleanClone).
    const hiddenOnSite = !!(el && el.hasAttribute && el.hasAttribute('hidden'));

    if (hiddenOnSite) {
      el.removeAttribute('hidden');
      el.setAttribute('data-mk-hidden', '');
    }

    if (['module', 'separator', 'readmore', 'html'].includes(type)) {
      const saved = html ?? (el ? el.outerHTML : emptyElement(type).outerHTML);

      keep(block, saved);
      body = document.createElement('div');
      body.innerHTML = this.cardHtml(type, saved);
    } else {
      if (!body && type === 'callout') {
        body = emptyElement(type);
        body.querySelector('.message__titre').textContent = t('CALLOUT_INFO');
      }

      body = body || emptyElement(type);
      previewImages(body, this.options.root);
      this.makeEditable(type, body, name);
    }

    body.classList.add('mk-body');

    // A module is already a card, with its own handle and tools.
    if (type === 'module') {
      block.appendChild(body);
      body.querySelector('.jmj-carte__poignee').dataset.mk = 'handle';
    } else {
      block.innerHTML = tool('mk-handle', 'handle', t('MOVE', name), 'Alt+Shift+ArrowUp Alt+Shift+ArrowDown');
      block.appendChild(body);
      // THE TYPE OF THE BLOCK, in a pill on its top line (Cyrille); a text block changes its type there.
      block.insertAdjacentHTML('beforeend', TEXT_TYPES.includes(type)
        ? `<button type="button" class="mk-ui mk-kind" data-mk="kind" aria-label="${escape(t('TYPE_OF', name))}" title="${escape(t('TYPE_OF', name))}">${escape(name)}</button>`
        : `<span class="mk-ui mk-kind" aria-hidden="true">${escape(name)}</span>`);
      this.measureKind(block.querySelector(':scope > .mk-kind'));
      block.insertAdjacentHTML('beforeend', `<div class="mk-ui mk-tools" role="group" aria-label="${escape(t('BLOCK_TOOLS', name))}">`
        // The gear alone (Cyrille): duplicate, hide and remove are at the top of its panel (settings.js).
        + `${tool('jmj-carte__outil jmj-carte__outil--modifier', 'settings', t('SETTINGS', name))}</div>`);
    }

    block.insertAdjacentHTML('beforeend', PLUS.map(([cls, action, key, keys]) => tool(cls, action, t(key, name), keys)).join(''));

    if (type === 'columns') {
      [...body.children].forEach((col) => this.makeColumn(col));
    }

    return block;
  }

  /** The editing attributes of a stored element. All are removed on save (blocks.js, EDIT_ATTRS). */
  makeEditable(type, body, name) {
    const typing = (el, label, placeholder = '') => {
      el.setAttribute('contenteditable', 'true');
      el.setAttribute('aria-label', label);
      // The LanguageTool browser extension reads this on the typed zone itself, not on a parent (Cyrille, Firefox).
      el.setAttribute('data-lt-active', 'false');

      if (placeholder) {
        el.setAttribute('data-mk-placeholder', placeholder);
      }
    };

    if (type === 'image') {
      const caption = body.querySelector('figcaption');


      if (caption) {
        typing(caption, t('IMAGE_CAPTION'), t('IMAGE_CAPTION_PLACEHOLDER'));
      }
    } else if (type === 'table') {
      body.querySelectorAll('caption, th, td').forEach((c) => typing(c, t('TABLE_CELL')));
    } else if (type === 'buttons') {
      // Only the words of each button are typed; the rest is in its settings, its pictogram too.
      body.querySelectorAll(':scope > a').forEach((a) => {
        typing(a, t('BUTTON_TEXT'), t('BUTTON_PLACEHOLDER'));
        a.querySelectorAll(':scope > svg').forEach((svg) => svg.setAttribute('contenteditable', 'false'));
      });
    } else if (type === 'pre') {
      typing(body.querySelector('code') || body, name);
    } else if (type === 'callout') {
      // A message is typed in its div: its pictogram stays out of the text.
      typing(calloutLines(body), name);
      calloutLines(body).querySelectorAll(':scope > :is(h2, h3, h4, h5, h6) > svg').forEach((svg) => svg.setAttribute('contenteditable', 'false'));
    } else if (type !== 'columns') {
      typing(body, name, type === 'p' ? t('PLACEHOLDER') : (HEADINGS.includes(type) ? t('PLACEHOLDER_HEADING') : ''));
    }

    // The number of a footnote's call and the link back from its note are not typed (notes.js).
    lockNotes(body);

    // An empty line has no height: browsers drop a caret put there. A <br> gives it one
    // (removed on save, blocks.js).
    [body, ...body.querySelectorAll('p, li, td, th, figcaption')].forEach((line) => {
      if (!line.firstChild && !/^(UL|OL|BLOCKQUOTE|TABLE|DIV|FIGURE|IMG|HR)$/.test(line.tagName)) {
        line.appendChild(document.createElement('br'));
      }
    });
  }

  /** The face of a block that is not typed in: a module card, a separator, raw HTML. */
  cardHtml(type, saved) {
    const name = this.typeName(type);

    if (type === 'html') {
      return `<label class="mk-html"><span class="mk-html__title">${escape(t('HTML_KEPT'))}</span>`
        + `<textarea class="mk-html__code" spellcheck="false" data-lt-active="false" rows="${Math.min(12, saved.split('\n').length + 1)}">${escape(saved)}</textarea></label>`;
    }

    if (type === 'module') {
      const id = moduleId(saved);
      const known = (this.options.modules || {})[id];

      return window.JoomanjiCarte.html({
        forme: 'page',
        nom: known ? known.title : t('MODULE', id),
        code: `{loadmoduleid ${id}}`,
        outils: { ...(this.options.admin ? { modifier: t('SETTINGS', name) } : {}), retirer: t('REMOVE', name) },
      }).replace('class="jmj-carte"', 'class="jmj-carte mk-card" tabindex="0"');
    }

    return `<div class="mk-card mk-rule mk-rule--${type}" tabindex="0" role="separator" aria-label="${escape(this.typeName(type))}">`
      + `<span>${escape(this.typeName(type))}</span></div>`;
  }

  makeColumn(col) {
    const list = parseNodes(col.childNodes);

    col.classList.add('mk-column');
    col.setAttribute('role', 'group');
    col.replaceChildren(...(list.length ? list : [{ type: 'p' }]).map((d) => this.makeBlock(d)));
    col.insertAdjacentHTML('beforeend', tool('mk-add mk-add--column', 'add-in-column', t('ADD_IN_COLUMN')));
    this.nameColumns(col.parentNode);
  }

  nameColumns(row) {
    const cols = [...row.querySelectorAll(':scope > .mk-column')];

    cols.forEach((c, i) => c.setAttribute('aria-label', t('COLUMN_OF', i + 1, cols.length)));
  }

  /** The blocks of a container (the surface or a column). */
  blocksIn(container) {
    return [...container.children].filter((n) => n.classList.contains('mk-block'));
  }

  blockOf(node) {
    const el = node && (node.nodeType === Node.ELEMENT_NODE ? node : node.parentNode);

    return el && el.closest ? el.closest('.mk-block') : null;
  }

  /** Loads HTML into the surface. */
  load(html) {
    this.surface.replaceChildren(...parse(html).map((d) => this.makeBlock(d)));
    this.ensureEnd();
    this.changed(false);
    this.nameModules();
  }

  /** Always an empty paragraph at the end, to keep writing after an image or a table. */
  ensureEnd() {
    const last = this.surface.lastElementChild;

    if (!last || last.dataset.type !== 'p') {
      this.surface.appendChild(this.makeBlock({ type: 'p' }));
    }
  }

  /* ------------------------------------------------------------------ */
  /* VALUE                                                              */
  /* ------------------------------------------------------------------ */

  /** The saved HTML: one block per line, empty paragraphs left out. */
  htmlOf(container) {
    return this.blocksIn(container).filter((b) => !(TEXT_TYPES.includes(b.dataset.type)
      && isEmpty(b.querySelector(':scope > .mk-body')) && !b.querySelector('li li, img')))
      .map((b) => serialize(b, (col) => this.htmlOf(col))).join('\n');
  }

  getValue() {
    if (this.source.hidden) {
      return this.htmlOf(this.surface);
    }

    const text = this.view ? this.view.state.doc.toString() : this.code().value;

    return this.sourceMode === 'markdown' ? markdownToHtml(text, this.markdownOptions()) : text;
  }

  setValue(html) {
    if (!this.source.hidden) {
      this.closeSource();
    }

    this.load(html);
  }

  /** Writes the HTML into the form field, a moment after the last change. */
  changed(soon = true) {
    window.clearTimeout(this.timer);

    const write = () => {
      syncNotes(this);
      this.ownZooms();
      this.markEmpty();

      if (this.live) {
        this.live.schedule();
      }

      if (this.finder) {
        this.finder.refresh();
      }

      if (this.breaks) {
        this.breaks.soon();
      }

      const words = [...this.surface.querySelectorAll('.mk-block')].map(textOf).join(' ').split(/\s+/).filter(Boolean);

      this.textarea.value = this.getValue();
      this.count.textContent = `${t('WORDS', words.length)}, ${t('READING', Math.max(1, Math.round(words.length / READING_SPEED)))}`;
      this.check();
      this.flatBlocks().forEach((b) => this.markSettings(b));

      if (this.outlinePanel) {
        this.fillOutline(this.outlinePanel.corps);
      }
    };

    if (soon) {
      this.timer = window.setTimeout(write, 250);
    } else {
      write();
    }
  }

  /* ------------------------------------------------------------------ */
  /* UNDO FOR BLOCK OPERATIONS. Typing is undone by the browser.        */
  /* ------------------------------------------------------------------ */

  remember() {
    this.history.push(this.htmlOf(this.surface));

    if (this.history.length > 50) {
      this.history.shift();
    }

    // A new step makes the undone ones unreachable, as in every editor.
    this.future = [];
    this.structural = true;
  }

  undo() {
    const html = this.history.pop();

    if (html === undefined) {
      return false;
    }

    this.future.push(this.htmlOf(this.surface));
    this.load(html);
    this.structural = this.history.length > 0;
    this.say(t('UNDONE'));

    return true;
  }

  /**
   * THE BUTTONS DO WHAT Ctrl+Z AND Ctrl+Y DO: the last step of Markus (a block
   * removed, moved, a setting) when it is the last thing done; otherwise the
   * browser's own undo of the typing, in the block that has the caret.
   */
  undoAny() {
    const typing = !this.structural && this.surface.contains(document.activeElement) && document.queryCommandEnabled('undo');

    if (typing) {
      document.execCommand('undo');
      this.changed();
    } else if (!this.undo()) {
      this.say(t('UNDO_NOTHING'));
    }
  }

  redoAny() {
    if (this.future.length) {
      this.redo();
    } else if (this.surface.contains(document.activeElement) && document.queryCommandEnabled('redo')) {
      document.execCommand('redo');
      this.changed();
    } else {
      this.say(t('REDO_NOTHING'));
    }
  }

  /** Redoes what Markus undid (Ctrl+Y, Ctrl+Shift+Z); typing in between forgets it. */
  redo() {
    const html = this.future.pop();

    if (html === undefined) {
      return false;
    }

    this.history.push(this.htmlOf(this.surface));
    this.load(html);
    this.structural = true;
    this.say(t('REDONE'));

    return true;
  }

  /* ------------------------------------------------------------------ */
  /* CARET                                                              */
  /* ------------------------------------------------------------------ */

  focusEnd(block, atEnd = true) {
    const el = this.editable(block);

    if (!el) {
      return;
    }

    el.focus();

    if (el.isContentEditable) {
      const r = document.createRange();
      let line = el;

      // In a list or a quote, the caret goes into the line itself, not between lines.
      while (/^(UL|OL|BLOCKQUOTE|LI)$/.test(line.tagName) && (atEnd ? line.lastElementChild : line.firstElementChild)
        && /^(P|LI|UL|OL)$/.test((atEnd ? line.lastElementChild : line.firstElementChild).tagName)) {
        line = atEnd ? line.lastElementChild : line.firstElementChild;
      }

      r.selectNodeContents(line);
      r.collapse(!atEnd);
      window.getSelection().removeAllRanges();
      window.getSelection().addRange(r);
    }
  }

  /** The current selection, when it lies in this editor. */
  selection() {
    const s = window.getSelection();

    if (!s.rangeCount || !this.surface.contains(s.anchorNode)) {
      return null;
    }

    return s.getRangeAt(0);
  }

  /** True when the caret is at the very start (or end) of an element. */
  static atEdge(el, range, start) {
    const probe = document.createRange();

    probe.selectNodeContents(el);

    if (start) {
      probe.setEnd(range.startContainer, range.startOffset);
    } else {
      probe.setStart(range.endContainer, range.endOffset);
    }

    return !probe.toString().length && !probe.cloneContents().querySelector('img');
  }

  /** True when the caret sits on the first (or last) line of an element. */
  static onEdgeLine(el, range, first) {
    const caret = range.getClientRects()[0];
    const box = el.getBoundingClientRect();

    if (!caret) {
      return true;
    }

    const line = parseFloat(window.getComputedStyle(el).lineHeight) || caret.height;

    return first ? caret.top - box.top < line : box.bottom - caret.bottom < line;
  }

  /* ------------------------------------------------------------------ */
  /* EVENTS                                                             */
  /* ------------------------------------------------------------------ */

  listen() {
    const s = this.surface;

    s.addEventListener('keydown', (e) => this.onKey(e));
    s.addEventListener('input', (e) => this.onInput(e));
    s.addEventListener('paste', (e) => this.onPaste(e));
    s.addEventListener('click', (e) => this.onClick(e));
    s.addEventListener('contextmenu', (e) => this.onContextMenu(e));
    s.addEventListener('copy', (e) => this.copyBlock(e, false));
    s.addEventListener('cut', (e) => this.copyBlock(e, true));
    s.addEventListener('focusin', () => {
      JoomlaEditor.setActive(this.textarea.id);
    });
    // The text scrolls in the editor: the block list, placed in the page, would stay behind.
    s.addEventListener('scroll', () => closeChooser(false), { passive: true });
    this.toolbar.addEventListener('mousedown', (e) => {
      // Keeps the selection in the text while a toolbar button is pressed.
      if (e.target.closest('.mk-button') && !e.target.closest('[data-mk="source"]')) {
        e.preventDefault();
      }
    });
    this.toolbar.addEventListener('click', (e) => this.onToolbar(e));

    const settings = this.host.querySelector('.mk-about [data-mk="plugin-settings"]');

    if (settings) {
      settings.addEventListener('click', () => this.pluginSettings());
    }
    this.source.addEventListener('click', (e) => {
      const b = e.target.closest('[data-mk]');

      if (b && b.dataset.mk === 'md-open') {
        this.source.querySelector('input[type="file"]').click();
      } else if (b && b.dataset.mk === 'md-save') {
        this.saveMarkdownFile();
      }
    });
    this.source.querySelector('input[type="file"]').addEventListener('change', (e) => {
      if (e.target.files[0]) {
        this.openMarkdownFile(e.target.files[0]);
      }

      e.target.value = '';
    });
    this.toolbar.addEventListener('keydown', (e) => this.roveToolbar(e));
    this.root.addEventListener('keydown', (e) => this.onShortcut(e));
    document.addEventListener('selectionchange', () => this.onSelection());

    if (this.textarea.form) {
      this.textarea.form.addEventListener('submit', () => {
        window.clearTimeout(this.timer);
        this.textarea.value = this.getValue();
      });
    }

    this.dragAndDrop();
  }

  onSelection() {
    const r = this.selection();

    if (!r) {
      return;
    }

    this.range = r.cloneRange();
    this.current = this.blockOf(r.startContainer);
    this.updateToolbar();
  }

  updateToolbar() {
    const block = this.current;
    const type = block ? block.dataset.type : 'p';
    const el = block && block.querySelector(':scope > .mk-body');
    const text = !!block && TEXT_TYPES.includes(type);
    const typeButton = this.toolbar.querySelector('[data-mk="type"]');

    typeButton.textContent = this.typeName(type);
    typeButton.setAttribute('aria-label', t('TYPE_OF', this.typeName(type)));
    typeButton.disabled = !text;

    ['bold', 'italic', 'underline'].forEach((cmd) => {
      const b = this.toolbar.querySelector(`[data-mk="${cmd}"]`);

      b.setAttribute('aria-pressed', String(text && document.queryCommandState(cmd)));
    });

    // The marks around the caret: struck through, code, key, exponent, index.
    const anchor = window.getSelection() && window.getSelection().rangeCount ? window.getSelection().anchorNode : null;
    const inside = anchor && (anchor.nodeType === Node.ELEMENT_NODE ? anchor : anchor.parentNode);

    [['strike', 's'], ['code', 'code'], ['kbd', 'kbd'], ['sup', 'sup'], ['sub', 'sub']].forEach(([name, tag]) => {
      const mark = text && inside && this.surface.contains(inside) ? inside.closest(tag) : null;

      this.toolbar.querySelector(`[data-mk="${name}"]`).setAttribute('aria-pressed', String(!!mark && this.surface.contains(mark)));
    });

    // The caret in a link: the link button says so (Ctrl+K edits it).
    const sel = window.getSelection();
    const at = sel && sel.rangeCount ? sel.anchorNode : null;
    const host = at && (at.nodeType === Node.ELEMENT_NODE ? at : at.parentNode);
    const link = text && host && this.surface.contains(host) ? host.closest('a[href]') : null;

    this.toolbar.querySelector('[data-mk="link"]').setAttribute('aria-pressed', String(!!link && this.surface.contains(link)));

    // In a table, the alignment is the one of the cell (or the title) of the caret.
    const aligned = type === 'table' ? this.alignTarget() : (text && type !== 'pre' ? el : null);

    this.toolbar.querySelectorAll('[data-mk="align"]').forEach((b) => {
      const on = !!aligned && aligned.classList.contains(b.dataset.value);

      b.setAttribute('aria-pressed', String(on || (b.dataset.value === 'text-start' && !!aligned && !ALIGN.some((a) => aligned.classList.contains(a)))));
      b.disabled = !aligned;
    });
    this.toolbar.querySelector('[data-mk="colour"]').disabled = !this.paintable(block);

    // The toolbar keeps one Tab stop, even when its button becomes disabled.
    const enabled = [...this.toolbar.querySelectorAll('.mk-button:not(:disabled)')];

    if (enabled.length && !enabled.some((b) => b.tabIndex === 0)) {
      enabled[0].tabIndex = 0;
    }
  }

  /** One Tab stop for the whole toolbar; arrows move inside it (ARIA toolbar pattern). */
  roveToolbar(e) {
    const buttons = [...this.toolbar.querySelectorAll('.mk-button:not(:disabled)')];
    const i = buttons.indexOf(document.activeElement);
    const go = { ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: buttons.length - 1 }[e.key];

    if (go === undefined || i < 0) {
      return;
    }

    e.preventDefault();

    const next = buttons[(go + buttons.length) % buttons.length];

    buttons.forEach((b) => { b.tabIndex = b === next ? 0 : -1; });
    next.focus();
  }

  onShortcut(e) {
    const mod = e.ctrlKey || e.metaKey;
    const key = e.key.toLowerCase();

    // Find (Ctrl+F) and replace (Ctrl+H), in the text only: the source view keeps the browser's own.
    if (mod && !e.shiftKey && !e.altKey && (e.code === 'KeyF' || e.code === 'KeyH') && this.source.hidden) {
      e.preventDefault();
      this.finder.show(e.code === 'KeyH');
    } else if (mod && e.shiftKey && (key === 'u' || key === 'm')) {
      e.preventDefault();
      this.toggleSource(key === 'u' ? 'html' : 'markdown');
    } else if (mod && e.shiftKey && e.code === 'KeyF') {
      e.preventDefault();
      this.fullScreen();
    } else if (e.key === 'Escape' && !e.defaultPrevented && this.root.classList.contains('mk--full')) {
      this.fullScreen(false);
    } else if (mod && e.altKey && key === 'n' && this.source.hidden) {
      e.preventDefault();
      this.onSelection();
      this.chooseBlock(this.current, 'after');
    }
  }

  onToolbar(e) {
    const b = e.target.closest('[data-mk]');

    if (!b || b.disabled) {
      return;
    }

    switch (b.dataset.mk) {
      case 'type':
        this.chooseBlock(this.current, 'change', b);
        break;
      case 'bold':
      case 'italic':
      case 'underline':
        this.format(b.dataset.mk);
        break;
      case 'undo':
        this.undoAny();
        break;
      case 'redo':
        this.redoAny();
        break;
      case 'link':
        this.link();
        break;
      case 'colour':
        this.colour(b);
        break;
      case 'clean':
        this.clean(b);
        break;
      case 'check':
        this.openCheck();
        break;
      case 'outline':
        this.openOutline();
        break;
      case 'plugin-settings':
        this.pluginSettings();
        break;
      case 'spell':
        this.openSpell();
        break;
      case 'find':
        this.finder.toggle();
        break;
      case 'align':
        this.align(b.dataset.value);
        break;
      case 'insert':
        this.chooseBlock(this.current, 'after', b);
        break;
      case 'source':
        this.toggleSource('html');
        break;
      case 'strike':
        this.markInline('s');
        break;
      case 'code':
        this.markInline('code');
        break;
      case 'kbd':
        this.markInline('kbd');
        break;
      case 'sup':
        this.format('superscript');
        break;
      case 'sub':
        this.format('subscript');
        break;
      case 'lang':
        this.language();
        break;
      case 'footnote':
        insertNote(this);
        break;
      case 'full':
        this.fullScreen();
        break;
      case 'markdown':
        this.toggleSource('markdown');
        break;
      default:
    }
  }

  format(command) {
    if (!this.restore()) {
      return;
    }

    document.execCommand(command);
    this.changed();
    this.updateToolbar();
  }

  /** Puts the last caret of the text back, after a click outside it. */
  restore() {
    if (!this.range || !this.surface.contains(this.range.startContainer)) {
      return false;
    }

    const el = this.range.startContainer.nodeType === Node.ELEMENT_NODE ? this.range.startContainer : this.range.startContainer.parentNode;
    const host = el.closest('[contenteditable="true"]');

    if (!host) {
      return false;
    }

    // The caret goes back where it was: the page must not move for it.
    host.focus({ preventScroll: true });
    window.getSelection().removeAllRanges();
    window.getSelection().addRange(this.range);

    return true;
  }

  /** In a table: the caption, or the cell of the caret; null elsewhere. */
  alignTarget() {
    const n = this.range && this.range.startContainer;
    const el = n && (n.nodeType === Node.ELEMENT_NODE ? n : n.parentNode);

    return el && this.current && this.current.contains(el) ? el.closest('caption, td, th') : null;
  }

  align(value) {
    const block = this.current;
    const type = block && block.dataset.type;
    let targets = [];

    if (type === 'table') {
      const cell = this.alignTarget();

      // The cell of the caret (or the title); a column, a row or the whole table: the table's settings.
      if (cell) {
        targets = [cell];
      }
    } else if (block && TEXT_TYPES.includes(type) && type !== 'pre') {
      targets = [block.querySelector(':scope > .mk-body')];
    }

    if (!targets.length) {
      return;
    }

    this.remember();
    targets.forEach((el) => {
      el.classList.remove(...ALIGN);

      // Left is the default of the site: no class at all, as TinyMCE does.
      if (value !== 'text-start') {
        el.classList.add(value);
      }

      if (!el.classList.length) {
        el.removeAttribute('class');
      }
    });

    this.restore();
    this.changed();
    this.updateToolbar();
    this.say(t(`ALIGNED_${value.slice(5).toUpperCase()}`));
  }

  /* ------------------------------------------------------------------ */
  /* COLOURS: colours.js. The site's colours, or a locked hue.          */
  /* ------------------------------------------------------------------ */

  /** Text blocks and table cells take colours; code keeps the highlighter's. */
  paintable(block) {
    return !!block && (TEXT_TYPES.includes(block.dataset.type) || block.dataset.type === 'table') && block.dataset.type !== 'pre';
  }

  /** The editable element holding the last caret, or null. */
  caretHost() {
    if (!this.range || !this.surface.contains(this.range.startContainer)) {
      return null;
    }

    const el = (n) => (n.nodeType === Node.ELEMENT_NODE ? n : n.parentNode);
    const host = el(this.range.startContainer).closest('[contenteditable="true"]');

    return host && el(this.range.endContainer).closest('[contenteditable="true"]') === host ? host : null;
  }

  /** The colour menu, under its button, or at the point of a right click (`at`). */
  async colour(button, at = null) {
    if (!at && toggleMenu()) {
      return;
    }

    const order = await chooseColour(button, at);

    if (!order) {
      if (at) {
        this.restore();
      }

      return;
    }

    const host = this.caretHost();

    if (!host || !this.paintable(this.blockOf(host))) {
      this.say(t(this.range && !this.range.collapsed ? 'COLOUR_ONE_BLOCK' : 'COLOUR_PLACE'));

      return;
    }

    this.remember();

    const range = this.range.cloneRange();
    const said = paint(range, host, order);

    if (said === 'MARK_SELECT') {
      this.history.pop();
      this.restore();
      this.say(t('COLOUR_MARK_SELECT'));

      return;
    }

    this.range = range;
    this.restore();
    this.changed();
    this.say(t(said, order.name));
  }

  /* ------------------------------------------------------------------ */
  /* CLEANING: clean.js. The look goes, the meaning stays.              */
  /* ------------------------------------------------------------------ */

  async clean(button) {
    if (toggleMenu()) {
      return;
    }

    const item = await openMenu(button, {
      label: t('CLEAN_TITLE'),
      html: ['block', 'article', '', 'empty', 'typography'].map((k) => (k
        ? `<button type="button" role="menuitem" class="mk-menu__item" data-clean="${k}">${escape(t(`CLEAN_${k.toUpperCase()}`))}</button>`
        : '<hr>')).join(''),
    });

    if (item) {
      ({ block: () => this.cleanBlock(), article: () => this.cleanArticle(button), empty: () => this.removeEmpty(),
        typography: () => this.typography() })[item.dataset.clean]();
    }
  }

  /** The selection, or the whole block of the caret. */
  cleanBlock() {
    const host = this.caretHost();

    if (!host || !this.paintable(this.blockOf(host))) {
      this.say(t('COLOUR_PLACE'));

      return;
    }

    const whole = this.range.collapsed;

    this.remember();
    this.restore();

    if (!(whole ? flatten(host) : flattenSelection(host))) {
      this.history.pop();
      this.say(t('CLEAN_NOTHING'));

      return;
    }

    // Merged texts may have taken the caret's node away: the block keeps the focus anyway.
    if (whole && !this.restore()) {
      host.focus({ preventScroll: true });
    }

    this.changed();
    this.say(t(whole ? 'CLEANED_BLOCK' : 'CLEANED_SELECTION'));
  }

  /** Every editable element of the text blocks and table cells, code left out. */
  textHosts() {
    return [...this.surface.querySelectorAll('[contenteditable="true"]')]
      .filter((el) => this.paintable(this.blockOf(el)) && !el.closest('pre'));
  }

  async cleanArticle(button) {
    const yes = await window.JoomanjiFenetre.demander({
      titre: t('CLEAN_ARTICLE_TITLE'),
      texte: `${t('CLEAN_ARTICLE_TEXT')}\n\n${t('CLEAN_ARTICLE_UNDO')}`,
      ton: 'alerte',
      bouton: t('CLEAN'),
    });

    if (!yes) {
      button.focus({ preventScroll: true });

      return;
    }

    this.remember();

    const n = this.textHosts().filter((el) => flatten(el)).length;

    if (!n) {
      this.history.pop();
    }

    this.changed();
    this.backToText();
    this.say(t(n ? 'CLEANED_ARTICLE' : 'CLEAN_NOTHING'));
  }

  /** Empty paragraphs are never saved; this takes them out of sight too. */
  removeEmpty() {
    const empty = this.flatBlocks().filter((b) => b.dataset.type === 'p' && isEmpty(b.querySelector(':scope > .mk-body'))
      && b !== this.blocksIn(b.parentNode).pop());

    if (!empty.length) {
      this.say(t('EMPTY_NONE'));

      return;
    }

    this.remember();
    empty.forEach((b) => b.remove());
    this.changed();
    this.backToText();
    this.say(empty.length === 1 ? t('EMPTY_REMOVED_1') : t('EMPTY_REMOVED', empty.length));
  }

  typography() {
    this.remember();

    const n = frenchTypography(this.textHosts());

    if (!n) {
      this.history.pop();
    }

    this.changed();
    this.backToText();
    this.say(t(n ? 'TYPOGRAPHY_DONE' : 'TYPOGRAPHY_NONE'));
  }

  /** After a menu, the caret goes back to the text, so that Ctrl+Z reaches Markus. */
  backToText() {
    if (!this.restore()) {
      this.focusEnd(this.flatBlocks()[0], false);
    }
  }

  /* ------------------------------------------------------------------ */
  /* THE ACCESSIBILITY CHECK: check.js. Alerts inform, never block.     */
  /* ------------------------------------------------------------------ */

  /**
   * The count on the gear of a block, in violet, as in Opus: how many of its
   * settings are not those of a new block. Said with the button's name.
   */
  markSettings(block) {
    const gear = block.querySelector(':scope > .mk-tools [data-mk="settings"]');

    if (!gear) {
      return;
    }

    const n = countSettings(block);
    const label = t('SETTINGS', this.typeName(block.dataset.type)) + (n ? ` (${n})` : '');

    gear.classList.toggle('mk-gear--set', n > 0);
    gear.dataset.count = n ? String(n) : '';
    gear.setAttribute('aria-label', label);
    gear.title = label;
  }

  /** Checks the article again: the count on the button, the marks on the blocks, the open list. */
  check() {
    this.alerts = audit(this.flatBlocks());

    const button = this.toolbar.querySelector('[data-mk="check"]');
    const n = this.alerts.length;
    const label = n ? (n === 1 ? t('CHECK_ONE') : t('CHECK_COUNT', n)) : t('CHECK_NONE');

    button.querySelector('.mk-badge').textContent = String(n);
    button.classList.toggle('mk-button--check-ok', !n);
    button.setAttribute('aria-label', `${t('CHECK_TITLE')}, ${label}`);
    button.title = `${t('CHECK_TITLE')} (${label})`;

    if (this.checkPanel) {
      this.fillCheck(this.checkPanel.corps);
    }
  }

  openCheck() {
    this.check();
    this.checkPanel = window.JoomanjiPanneau.ouvrir({
      titre: t('CHECK_PANEL'),
      cle: 'markus',
      place: this.sideColumn(),
      pied: t('CHECK_FOOT'),
      fermeture: () => { this.checkPanel = null; },
      onglets: [{ titre: t('CHECK_TAB'), remplir: (zone) => this.fillCheck(zone) }],
    });
    this.say(this.alerts.length ? t('CHECK_SAID', this.alerts.length) : t('CHECK_NONE_TITLE'));
  }

  /**
   * THE SETTINGS OF MARKUS: Joomla's own form of the plugin, in the side
   * window, as a module is (settings.js, module): the article being written
   * stays. Saved, they apply the next time the article is opened.
   */
  pluginSettings() {
    const id = this.options.settings;
    const token = Joomla.getOptions('csrf.token', '');
    let done = false;
    let panel = null;

    panel = window.JoomanjiPanneau.ouvrir({
      titre: t('PLUGIN_SETTINGS_TITLE'),
      cle: 'markus-module',
      onglets: [{
        titre: t('PLUGIN_SETTINGS'),
        remplir: (zone, p) => {
          p.large(true);
          zone.innerHTML = `<iframe class="mk-module-frame" title="${escape(t('PLUGIN_SETTINGS_TITLE'))}"`
            + ` src="index.php?option=com_plugins&amp;task=plugin.edit&amp;layout=modal&amp;tmpl=component&amp;extension_id=${id}"></iframe>`;

          const frame = zone.querySelector('iframe');

          // Saved and closed, or closed: Joomla leaves its form; the window goes too.
          frame.addEventListener('load', () => {
            let search = '';

            try {
              search = frame.contentWindow.location.search;
            } catch (e) {
              search = '';
            }

            // Joomla's modal form ends on `layout=modalreturn` (saved and closed, or closed).
            if (search && (/layout=modalreturn/.test(search) || !/layout=modal/.test(search))) {
              done = true;
              panel.fermer();
              this.say(t(/from-task=save/.test(search) ? 'PLUGIN_SETTINGS_SAVED' : 'PLUGIN_SETTINGS_CLOSED'));
            }
          });
        },
      }],
      // Closed by its cross, Escape or a click beside it: the plugin is checked in again.
      fermeture: () => {
        if (done) {
          return;
        }

        const form = new FormData();

        form.append('task', 'plugin.cancel');
        form.append(token, '1');
        fetch(`index.php?option=com_plugins&layout=edit&extension_id=${id}`, { method: 'POST', body: form });
      },
    });
  }

  /**
   * The empty paragraphs and headings carry `data-mk-empty` (removed on
   * save): their invitation shows (CSS), on the line of the caret, and on the
   * only line of an empty article, so that one knows where to begin.
   */
  markEmpty(only = null) {
    (only ? [only] : this.surface.querySelectorAll('.mk-block > .mk-body[data-mk-placeholder]')).forEach((body) => {
      body.toggleAttribute('data-mk-empty', isEmpty(body));
    });
  }

  /** A duplicated image gets a larger view of its own: two of the same name would open the first. */
  ownZooms() {
    const seen = new Set();

    this.surface.querySelectorAll('[popover][id^="zoom-"]').forEach((pop) => {
      if (seen.has(pop.id)) {
        const id = `zoom-${Math.random().toString(36).slice(2, 8)}`;

        pop.parentNode.querySelectorAll(`[popovertarget="${pop.id}"]`).forEach((b) => b.setAttribute('popovertarget', id));
        pop.id = id;
      }

      seen.add(pop.id);
    });
  }

  /* ------------------------------------------------------------------ */
  /* SPELLING AND GRAMMAR: LanguageTool, on demand (spell.js).          */
  /* ------------------------------------------------------------------ */

  /** The words "ignored" by this author, on this computer (proper names, words of the trade). */
  spellIgnored() {
    try {
      return new Set(JSON.parse(window.localStorage.getItem('markus:spell-ignored') || '[]'));
    } catch (e) {
      return new Set();
    }
  }

  /** Ignored from the menu or the panel: a misspelt word for good (on this computer), other remarks here only. */
  spellIgnoreFinding(f) {
    const typo = f.match.rule && f.match.rule.issueType === 'misspelling';

    if (typo) {
      this.spellIgnore(f.words);
    }

    this.live.findings().filter((x) => x.words === f.words && (typo || x.offset === f.offset)).forEach((x) => this.live.forget(x));
  }

  spellIgnore(words) {
    const all = this.spellIgnored();

    all.add(words);

    try {
      window.localStorage.setItem('markus:spell-ignored', JSON.stringify([...all].slice(-500)));
    } catch (e) {
      // Without the browser's storage, ignored for this session only.
    }
  }

  openSpell() {
    if (this.spellPanel) {
      this.runSpell();

      return;
    }

    this.spellPanel = window.JoomanjiPanneau.ouvrir({
      titre: t('SPELL_TITLE'),
      cle: 'markus',
      place: this.sideColumn(),
      pied: t('SPELL_FOOT'),
      fermeture: () => { this.spellPanel = null; this.spellZone = null; },
      onglets: [{ titre: t('SPELL'), remplir: (zone) => { this.spellZone = zone; this.fillSpell(); } }],
    });
    this.runSpell();
  }

  async runSpell() {
    this.spellBusy = true;
    this.fillSpell();

    try {
      const ignored = this.spellIgnored();

      this.spellFound = (await spellCheck(this)).filter((f) => !(f.match.rule && f.match.rule.issueType === 'misspelling' && ignored.has(f.words)));
      this.spellError = '';
    } catch (e) {
      this.spellFound = [];
      this.spellError = t('SPELL_ERROR', e.message || '');
    }

    this.spellBusy = false;
    this.fillSpell();
    this.say(this.spellError || (this.spellFound.length ? t('SPELL_SAID', this.spellFound.length) : t('SPELL_NONE_TITLE')));
  }

  fillSpell() {
    const zone = this.spellZone;

    if (!zone) {
      return;
    }

    let list = spellList(this.spellFound);

    if (this.spellBusy) {
      list = `<p role="status">${escape(t('SPELL_WAIT'))}</p>`;
    } else if (this.spellError) {
      list = `<p role="alert">${escape(this.spellError)}</p>`;
    }

    // LanguageTool's terms for its public service: a visible link back to it (no nofollow).
    const own = this.options.spell && this.options.spell.public === false;

    zone.innerHTML = (own ? `<p class="mk-field-hint">${escape(t('SPELL_SENT_OWN'))}</p>`
      : `<p class="mk-field-hint">${escape(t('SPELL_SENT'))} <a href="https://languagetool.org" target="_blank" rel="noopener">languagetool.org</a></p>`)
      + (this.live.able ? `<label class="mk-check"><input type="checkbox" data-live${this.live.on ? ' checked' : ''}> ${escape(t('SPELL_LIVE'))}</label>` : '')
      + `<p class="mk-buttons"><button type="button" class="btn btn-sm btn-outline-secondary" data-again${this.spellBusy ? ' disabled' : ''}>${escape(t('SPELL_AGAIN'))}</button></p>`
      + list;

    zone.querySelector('[data-again]').addEventListener('click', () => this.runSpell());

    const live = zone.querySelector('[data-live]');

    if (live) {
      live.addEventListener('change', () => this.live.turn(live.checked));
    }
    zone.querySelectorAll('.mk-spell > li').forEach((li) => {
      const f = this.spellFound[Number(li.dataset.i)];
      const drop = (same) => {
        this.spellFound = this.spellFound.filter((x) => x !== f && !(same && x.words === f.words && x.match.rule.id === f.match.rule.id));
        this.fillSpell();
      };

      li.querySelectorAll('[data-fix]').forEach((b) => b.addEventListener('click', () => {
        if (applySuggestion(this, f, f.match.replacements[Number(b.dataset.fix)].value)) {
          drop(false);
        } else {
          this.say(t('SPELL_GONE'));
        }
      }));
      li.querySelector('[data-show]').addEventListener('click', () => showFinding(f));
      li.querySelector('[data-ignore]').addEventListener('click', () => {
        this.spellIgnoreFinding(f);
        drop(true);
      });
    });
  }

  /* ------------------------------------------------------------------ */
  /* THE OUTLINE: every block in reading order, under its heading.      */
  /* ------------------------------------------------------------------ */

  openOutline() {
    this.outlinePanel = window.JoomanjiPanneau.ouvrir({
      titre: t('OUTLINE_TITLE'),
      cle: 'markus',
      place: this.sideColumn(),
      pied: t('OUTLINE_FOOT'),
      fermeture: () => { this.outlinePanel = null; },
      onglets: [{ titre: t('OUTLINE'), remplir: (zone) => this.fillOutline(zone) }],
    });
  }

  fillOutline(zone) {
    const blocks = this.flatBlocks().filter((b) => !(b.dataset.type === 'p' && isEmpty(b.querySelector(':scope > .mk-body'))));
    let depth = 0;

    zone.innerHTML = blocks.length ? `<ol class="mk-outline">${blocks.map((b, i) => {
      const type = b.dataset.type;
      const heading = /^h[1-6]$/.test(type);
      const words = textOf(b).replace(/\s+/g, ' ').trim();

      // A heading sets the level; the blocks after it sit one step in.
      if (heading) {
        depth = Math.max(0, Number(type[1]) - 2);
      }

      return `<li style="--mk-depth:${heading ? depth : depth + 1}"${heading ? ' class="mk-outline__heading"' : ''}>`
        + `<button type="button" data-go="${i}"><span class="mk-outline__type">${escape(this.typeName(type))}</span>`
        + `<span class="mk-outline__text">${escape(words.length > 70 ? `${words.slice(0, 70)}…` : words)}</span></button></li>`;
    }).join('')}</ol>` : `<p>${escape(t('OUTLINE_EMPTY'))}</p>`;

    zone.querySelectorAll('[data-go]').forEach((button) => button.addEventListener('click', () => {
      const block = blocks[Number(button.dataset.go)];

      block.scrollIntoView({ block: 'center' });
      this.focusEnd(block, false);
    }));
  }

  fillCheck(zone) {
    zone.innerHTML = this.alerts.length
      ? `<ul class="mk-alerts">${this.alerts.map((a, i) => `<li><span><strong>${escape(a.title)}</strong>${escape(a.text)}<br>`
        + `<button type="button" class="btn btn-sm btn-outline-secondary" data-go="${i}">${escape(t('CHECK_GO'))}</button></span></li>`).join('')}</ul>`
      : `<ul class="mk-alerts"><li class="mk-alerts__ok"><span><strong>${escape(t('CHECK_NONE_TITLE'))}</strong>`
        + `${escape(t('CHECK_NONE_TEXT'))}</span></li></ul>`;

    zone.querySelectorAll('[data-go]').forEach((b) => b.addEventListener('click', () => {
      const { block, title } = this.alerts[Number(b.dataset.go)];
      const target = block.querySelector(':scope > .mk-tools [data-mk="settings"]') || this.editable(block);

      block.scrollIntoView({ block: 'center' });

      if (target) {
        target.focus();
      }

      this.say(`${this.typeName(block.dataset.type)} : ${title}.`);
    }));
  }

  /* ------------------------------------------------------------------ */
  /* THE MENU OF THE TEXT: right click, the Menu key or Shift+F10.       */
  /* Shift+right click keeps the browser's own menu.                    */
  /* ------------------------------------------------------------------ */

  onContextMenu(e) {
    const host = e.target.closest && e.target.closest('[contenteditable="true"]');

    if (e.shiftKey || !host || !this.paintable(this.blockOf(host)) || host.closest('pre')) {
      return;
    }

    e.preventDefault();

    // A right click outside the selection puts the caret where it was made.
    const s = window.getSelection();
    const point = document.caretRangeFromPoint ? document.caretRangeFromPoint(e.clientX, e.clientY) : null;

    if (point && host.contains(point.startContainer)
      && (!s.rangeCount || s.isCollapsed || !s.getRangeAt(0).isPointInRange(point.startContainer, point.startOffset))) {
      s.removeAllRanges();
      s.addRange(point);
    }

    this.onSelection();
    this.textMenu({ x: e.clientX, y: e.clientY });
  }

  async textMenu(at) {
    const item = (id, label, keys = '') => `<button type="button" role="menuitem" class="mk-menu__item mk-menu__item--keys" data-text="${id}">`
      + `<span>${escape(label)}</span>${keys ? `<kbd>${escape(keys)}</kbd>` : ''}</button>`;
    // Underlined words under the caret (spell.js): their suggestions first, as in Word.
    const finding = this.live ? this.live.at(this.range) : null;
    const fixes = finding ? finding.match.replacements.slice(0, 5) : [];
    const spelling = finding ? `<p class="mk-menu__note">${escape(finding.match.shortMessage || finding.match.message)}</p>`
      + fixes.map((r, i) => `<button type="button" role="menuitem" class="mk-menu__item mk-menu__item--fix" data-text="fix:${i}"><span>${escape(r.value || t('SPELL_REMOVE'))}</span></button>`).join('')
      + item('ignore-words', t('SPELL_IGNORE')) + '<hr>' : '';
    // Line breaks and paragraphs (breaks.js): offered only where they do something.
    const here = this.current;
    const lines = cuttable(here) && lineBreaks(here.querySelector(':scope > .mk-body')).length > 0;
    const before = here && this.neighbour(here, -1, true);
    const joinable = !!here && here.dataset.type === 'p' && !!before && before.dataset.type === 'p';
    const chosen = await openMenu(null, {
      label: t('CTX_MENU'),
      at,
      html: spelling + item('bold', t('BOLD'), 'Ctrl+B') + item('italic', t('ITALIC'), 'Ctrl+I') + item('link', t('CTX_LINK'), 'Ctrl+K')
        + item('colour', t('CTX_COLOURS')) + item('superscript', t('CTX_SUP'), 'Ctrl+Maj+=') + item('subscript', t('CTX_SUB'), 'Ctrl+=')
        + item('mark-s', t('CTX_STRIKE'), 'Ctrl+Maj+X') + item('mark-code', t('CTX_CODE'), 'Ctrl+E') + item('mark-kbd', t('CTX_KBD'))
        + item('lang', t('CTX_LANG')) + item('footnote', t('CTX_FOOTNOTE'), 'Ctrl+Alt+F') + item('clean', t('CTX_CLEAN'))
        + '<hr>' + item('cut', t(this.range && this.range.collapsed ? 'CTX_CUT_BLOCK' : 'CTX_CUT'), 'Ctrl+X')
        + item('copy', t(this.range && this.range.collapsed ? 'CTX_COPY_BLOCK' : 'CTX_COPY'), 'Ctrl+C')
        + item('paste', t('CTX_PASTE'), 'Ctrl+V')
        + item('duplicate', t('CTX_DUPLICATE'), 'Ctrl+Maj+D')
        + (lines ? item('split-lines', t('CTX_SPLIT_LINES'), 'Ctrl+Maj+Entrée') : '')
        + (joinable ? item('join-prev', t('CTX_JOIN_PREV'), 'Maj+Retour arrière') : '')
        + '<hr>' + item('find', t('FIND_TITLE'), 'Ctrl+F')
        + `<p class="mk-menu__note">${escape(t('CTX_NOTE'))}</p>`,
    });

    this.restore();

    if (!chosen) {
      return;
    }

    if (finding && chosen.dataset.text.startsWith('fix:')) {
      applySuggestion(this, finding, fixes[Number(chosen.dataset.text.slice(4))].value);
      this.live.forget(finding);

      return;
    }

    if (finding && chosen.dataset.text === 'ignore-words') {
      this.spellIgnoreFinding(finding);

      return;
    }

    switch (chosen.dataset.text) {
      case 'bold':
      case 'italic':
      case 'superscript':
      case 'subscript':
        this.format(chosen.dataset.text);
        break;
      case 'lang':
        this.language();
        break;
      case 'footnote':
        insertNote(this);
        break;
      case 'mark-s':
      case 'mark-code':
      case 'mark-kbd':
        this.markInline(chosen.dataset.text.slice(5));
        break;
      case 'duplicate':
        this.duplicate(this.current);
        break;
      case 'link':
        this.link();
        break;
      case 'colour':
        this.colour(null, at);
        break;
      case 'clean':
        this.cleanBlock();
        break;
      case 'cut':
      case 'copy':
        // Without a selection, the whole block (copyBlock, on the browser's own event).
        document.execCommand(chosen.dataset.text);
        break;
      case 'paste':
        this.pasteFromMenu();
        break;
      case 'find':
        this.finder.show();
        break;
      case 'split-lines':
        splitLines(this, here);
        break;
      case 'join-prev':
        joinWithBreak(this, here);
        break;
      default:
    }
  }

  /**
   * PASTE FROM THE MENU (Cyrille). A script may not paste by itself: the
   * clipboard is read with the browser's permission (asked once), then given
   * to onPaste() as a paste event, so it is cleaned exactly as Ctrl+V is.
   */
  async pasteFromMenu() {
    const data = new DataTransfer();

    try {
      const items = await navigator.clipboard.read();

      for (const item of items) {
        for (const type of ['text/html', 'text/plain']) {
          if (item.types.includes(type) && !data.getData(type)) {
            // eslint-disable-next-line no-await-in-loop
            data.setData(type, await (await item.getType(type)).text());
          }
        }
      }
    } catch (e) {
      this.say(t('CTX_PASTE_DENIED'));

      return;
    }

    this.restore();

    const r = this.selection();
    const target = r && (r.startContainer.nodeType === Node.ELEMENT_NODE ? r.startContainer : r.startContainer.parentElement);

    if (target) {
      target.dispatchEvent(new ClipboardEvent('paste', { clipboardData: data, bubbles: true, cancelable: true }));
    }
  }

  /* ------------------------------------------------------------------ */
  /* BLOCKS: duplicate, copy, cut, nest. Lists: lists.js.               */
  /* ------------------------------------------------------------------ */

  /** The saved HTML of one block, as it would be written in the article. */
  blockHtml(block) {
    return serialize(block, (col) => this.htmlOf(col));
  }

  duplicate(block) {
    if (!block) {
      return;
    }

    this.insertBlocks(parse(this.blockHtml(block)), block, block.parentNode);
    this.say(t('DUPLICATED', this.typeName(block.dataset.type)));
  }

  /**
   * Ctrl+C or Ctrl+X with nothing selected takes the whole block, as in
   * Gutenberg; with a selection, the browser copies the text as usual.
   */
  copyBlock(e, cut) {
    const r = this.selection();
    const block = r && r.collapsed && this.blockOf(r.startContainer);

    if (!block || !e.clipboardData) {
      return;
    }

    e.preventDefault();
    e.clipboardData.setData('text/html', CLIP + this.blockHtml(block));
    e.clipboardData.setData('text/plain', textOf(block));

    if (cut) {
      this.remove(block);
    }

    this.say(t(cut ? 'BLOCK_CUT' : 'BLOCK_COPIED', this.typeName(block.dataset.type)));
  }

  /** Tab and Shift+Tab in a list. The caret stays where it was in the moved item. */
  nest(li, r, deeper) {
    const at = [r.startContainer, r.startOffset];
    const block = this.blockOf(li);

    this.remember();

    if (!(deeper ? indent(li) : outdent(li))) {
      this.history.pop();
      this.say(t(deeper ? 'LIST_FIRST' : 'LIST_TOP'));

      return;
    }

    const caret = document.createRange();

    caret.setStart(...at);
    caret.collapse(true);
    window.getSelection().removeAllRanges();
    window.getSelection().addRange(caret);
    this.makeEditable(block.dataset.type, block.querySelector(':scope > .mk-body'), this.typeName(block.dataset.type));
    this.changed();
    this.say(t(deeper ? 'LIST_IN' : 'LIST_OUT'));
  }

  /** The language of a passage (RGAA 8.7): a code such as "en", empty to take it away. */
  /** The editor over the whole window, or back in the page. */
  fullScreen(on = !this.root.classList.contains('mk--full')) {
    this.root.classList.toggle('mk--full', on);
    this.toolbar.querySelector('[data-mk="full"]').setAttribute('aria-pressed', String(on));
    document.documentElement.style.overflow = on ? 'hidden' : '';
    this.say(t(on ? 'FULL_ON' : 'FULL_OFF'));
  }

  /** Struck through, a bit of code, a key: put on the selection, or taken away (inline.js). */
  markInline(tag) {
    const host = this.caretHost();

    if (!host || this.range.collapsed) {
      this.say(t('MARK_SELECT'));

      return;
    }

    const range = this.range.cloneRange();

    this.remember();

    const n = toggleTag(range, host, tag);

    if (!n) {
      this.history.pop();
    }

    this.range = range;
    this.restore();
    this.changed();
    this.updateToolbar();
  }

  async language() {
    const host = this.caretHost();

    if (!host || this.range.collapsed) {
      this.say(t('LANG_SELECT'));

      return;
    }

    const range = this.range.cloneRange();
    const v = await window.JoomanjiFenetre.saisir({
      titre: t('LANG_TITLE'),
      corps: `<label class="mk-field"><span>${escape(t('LANG_CODE'))}</span>`
        + `<input type="text" name="lang" value="${escape(langAt(range, host))}" list="mk-langs" autocomplete="off" spellcheck="false">`
        + `<small>${escape(t('LANG_HINT'))}</small></label><datalist id="mk-langs">`
        + ['en', 'de', 'es', 'it', 'pt', 'nl', 'la', 'fr'].map((c) => `<option value="${c}">${escape(t(`LANG_${c.toUpperCase()}`))}</option>`).join('')
        + '</datalist>',
      bouton: t('HUE_APPLY'),
    });

    if (!v) {
      this.restore();

      return;
    }

    const lang = v.lang.trim();

    if (lang && !/^[a-zA-Z]{2,3}(-[a-zA-Z0-9]{2,8})*$/.test(lang)) {
      this.restore();
      this.say(t('LANG_BAD', lang));

      return;
    }

    this.remember();
    setLang(range, host, lang);
    this.range = range;
    this.restore();
    this.changed();
    this.say(lang ? t('LANG_SET', lang) : t('LANG_REMOVED'));
  }

  onClick(e) {
    const b = e.target.closest('[data-mk], [data-jmj-action]');
    const block = this.blockOf(e.target);

    if (!b || !block) {
      return;
    }

    const action = b.dataset.mk || b.dataset.jmjAction;

    switch (action) {
      case 'add':
        this.chooseBlock(block, 'after', b);
        break;
      case 'add-before':
        this.chooseBlock(block, 'before', b);
        break;
      case 'kind':
        this.chooseBlock(block, 'change', b);
        break;
      case 'add-in-column': {
        const col = b.closest('.mk-column');
        const last = this.blocksIn(col).pop();

        if (last) {
          this.chooseBlock(last, 'after', b);
        } else {
          this.insertBlocks([{ type: 'p' }], null, col);
        }
        break;
      }
      case 'up':
      case 'down':
        this.move(block, action === 'up' ? -1 : 1);
        break;
      case 'remove':
      case 'retirer':
        this.remove(block);
        break;
      case 'settings':
      case 'modifier':
        this.settings(block);
        break;

      default:
    }
  }

  onInput(e) {
    const block = this.blockOf(e.target);

    this.structural = false;
    this.future = [];

    if (!block) {
      return;
    }

    const typed = block.querySelector(':scope > .mk-body[data-mk-placeholder]');

    if (typed) {
      this.markEmpty(typed);
    }

    if (block.dataset.type === 'html' && e.target.tagName === 'TEXTAREA') {
      keep(block, e.target.value);
    } else if (e.inputType === 'insertText' && TEXT_TYPES.includes(block.dataset.type) && block.dataset.type !== 'pre') {
      this.inlineMarkdown();
    }

    this.changed();
  }

  /** **bold**, *italic*, _italic_ and `code`, as soon as the closing mark is typed. */
  inlineMarkdown() {
    const r = this.selection();

    if (!r || !r.collapsed || r.startContainer.nodeType !== Node.TEXT_NODE || r.startContainer.parentNode.closest('code')) {
      return;
    }

    const node = r.startContainer;
    const before = node.data.slice(0, r.startOffset);

    INLINE.some(([re, tag]) => {
      const m = re.exec(before);

      if (!m) {
        return false;
      }

      const range = document.createRange();
      const el = document.createElement(tag);

      // m[1] is the character before the opening mark, kept as it is.
      range.setStart(node, m.index + m[1].length);
      range.setEnd(node, r.startOffset);
      el.textContent = m[2];
      range.deleteContents();
      range.insertNode(el);

      // Browsers keep typing inside an element when the caret touches its end.
      // A zero-width space outside it takes the caret; it is never saved (blocks.js).
      const outside = document.createTextNode('\u200b');

      el.after(outside);
      range.setStart(outside, 1);
      range.collapse(true);
      window.getSelection().removeAllRanges();
      window.getSelection().addRange(range);

      return true;
    });
  }

  onKey(e) {
    const r = this.selection();
    const block = r && this.blockOf(r.startContainer);
    const mod = e.ctrlKey || e.metaKey;

    // The menu of the text from the keyboard: the Menu key, or Shift+F10.
    if (r && (e.key === 'ContextMenu' || (e.shiftKey && e.key === 'F10')) && this.paintable(block)) {
      e.preventDefault();

      const box = r.getBoundingClientRect();
      const place = box.width || box.height ? box : e.target.getBoundingClientRect();

      this.textMenu({ x: place.left, y: place.bottom + 4 });

      return;
    }

    if (e.altKey && e.shiftKey && !mod && HOTKEYS[e.code] && block && TEXT_TYPES.includes(block.dataset.type)) {
      e.preventDefault();
      this.changeType(block, HOTKEYS[e.code]);
      this.say(t('TYPE_OF', this.typeName(HOTKEYS[e.code])));

      return;
    }

    if (e.altKey && e.shiftKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {
      const target = block || this.blockOf(e.target);

      if (target) {
        e.preventDefault();
        this.move(target, e.key === 'ArrowUp' ? -1 : 1);
      }

      return;
    }

    if (mod && !e.shiftKey && e.key.toLowerCase() === 'z' && this.structural) {
      e.preventDefault();
      this.undo();

      return;
    }

    if (mod && ((e.shiftKey && e.key.toLowerCase() === 'z') || (!e.shiftKey && e.key.toLowerCase() === 'y')) && this.future.length) {
      e.preventDefault();
      this.redo();

      return;
    }

    if (mod && e.shiftKey && e.key.toLowerCase() === 'd' && block) {
      e.preventDefault();
      this.duplicate(block);

      return;
    }

    // Exponent and index, Word's keys: Ctrl+Shift+= and Ctrl+=.
    if (mod && e.code === 'Equal' && this.paintable(block)) {
      e.preventDefault();
      this.onSelection();
      this.format(e.shiftKey ? 'superscript' : 'subscript');

      return;
    }

    // Struck through (Ctrl+Shift+X) and a bit of code (Ctrl+E), the keys of Notion and Slack.
    if (mod && !e.altKey && ((e.shiftKey && e.code === 'KeyX') || (!e.shiftKey && e.code === 'KeyE')) && this.paintable(block)) {
      e.preventDefault();
      this.onSelection();
      this.markInline(e.code === 'KeyX' ? 's' : 'code');

      return;
    }

    // A footnote, Word's keys: Ctrl+Alt+F.
    if (mod && e.altKey && e.code === 'KeyF' && this.paintable(block)) {
      e.preventDefault();
      this.onSelection();
      insertNote(this);

      return;
    }

    if (mod && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      this.link();

      return;
    }

    // A card (module, separator) is one piece: removed, passed or followed by a paragraph.
    if (e.target.classList.contains('mk-card') && !mod) {
      const card = this.blockOf(e.target);
      const up = e.key === 'ArrowUp';

      if (e.key === 'Delete' || e.key === 'Backspace') {
        e.preventDefault();
        this.remove(card);
      } else if (e.key === 'Enter') {
        e.preventDefault();
        this.insertBlocks([{ type: 'p' }], card, card.parentNode);
      } else if ((up || e.key === 'ArrowDown') && this.neighbour(card, up ? -1 : 1)) {
        e.preventDefault();
        this.focusEnd(this.neighbour(card, up ? -1 : 1), up);
      }

      return;
    }

    if (!block || !r) {
      return;
    }

    const type = block.dataset.type;
    const el = this.editable(block);
    const cell = r.startContainer.nodeType === Node.ELEMENT_NODE ? r.startContainer : r.startContainer.parentNode;
    const inCaption = cell.closest('figcaption');
    const inCell = cell.closest('td, th, caption');

    if (type === 'table' && e.key === 'Tab') {
      e.preventDefault();
      this.nextCell(block, cell.closest('td, th, caption'), e.shiftKey ? -1 : 1);

      return;
    }

    if ((type === 'ul' || type === 'ol') && e.key === 'Tab' && !mod && cell.closest('li')) {
      e.preventDefault();
      this.nest(cell.closest('li'), r, !e.shiftKey);

      return;
    }

    // A button holds one line: Enter goes on to a new paragraph under the buttons.
    if (type === 'buttons' && e.key === 'Enter') {
      e.preventDefault();
      this.focusEnd(this.insertBlocks([{ type: 'p' }], block, block.parentNode));

      return;
    }

    // Line breaks and paragraphs (breaks.js): Ctrl+Shift+Enter cuts the block at its line breaks,
    // Shift+Backspace at the start of a paragraph joins it to the one above with a line break.
    if (e.key === 'Enter' && e.shiftKey && mod && cuttable(block)) {
      e.preventDefault();
      splitLines(this, block);
    } else if (e.key === 'Backspace' && e.shiftKey && !mod && r.collapsed && type === 'p' && Markus.atEdge(el, r, true)) {
      e.preventDefault();
      joinWithBreak(this, block);
    } else if (e.key === 'Enter' && !e.shiftKey && !mod) {
      this.onEnter(e, block, type, r, inCaption, inCell);
    } else if (e.key === ' ' && type === 'p' && r.collapsed) {
      this.blockMarkdown(e, block, r);
    } else if (e.key === '/' && type === 'p' && isEmpty(el)) {
      e.preventDefault();
      this.chooseBlock(block, 'replace', el);
    } else if (e.key === 'Backspace' && r.collapsed && TEXT_TYPES.includes(type) && Markus.atEdge(el, r, true)) {
      this.onBackspace(e, block, type, el);
    } else if (e.key === 'Delete' && r.collapsed && TEXT_TYPES.includes(type) && Markus.atEdge(el, r, false)) {
      this.onDelete(e, block, el);
    } else if ((e.key === 'ArrowUp' || e.key === 'ArrowDown') && r.collapsed && !inCell && el && el.isContentEditable) {
      const up = e.key === 'ArrowUp';

      if (Markus.onEdgeLine(el, r, up)) {
        const next = this.neighbour(block, up ? -1 : 1);

        if (next) {
          e.preventDefault();
          this.focusEnd(next, up);
        }
      }
    }
  }

  onEnter(e, block, type, r, inCaption, inCell) {
    if (type === 'pre') {
      e.preventDefault();
      document.execCommand('insertText', false, '\n');

      return;
    }

    if (inCell) {
      e.preventDefault();
      document.execCommand('insertLineBreak');

      return;
    }

    if (inCaption) {
      e.preventDefault();
      this.insertBlocks([{ type: 'p' }], block);

      return;
    }

    // The title of a callout is followed by text, not by another title.
    if (type === 'callout') {
      const at = r.startContainer.nodeType === Node.ELEMENT_NODE ? r.startContainer : r.startContainer.parentNode;
      const title = at.closest('.message__titre, h2, h3, h4, h5, h6');

      if (title && calloutLines(block.querySelector(':scope > .mk-body')).contains(title)) {
        e.preventDefault();
        this.remember();

        const p = document.createElement('p');

        p.appendChild(document.createElement('br'));
        title.after(p);

        const caret = document.createRange();

        caret.setStart(p, 0);
        caret.collapse(true);
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(caret);
        this.changed();

        return;
      }
    }

    // In a list, a quote or a callout, Enter on an empty last line leaves it.
    if (type === 'ul' || type === 'ol' || type === 'blockquote' || type === 'callout') {
      const line = (r.startContainer.nodeType === Node.ELEMENT_NODE ? r.startContainer : r.startContainer.parentNode).closest('li, p');
      const body = type === 'callout' ? calloutLines(block.querySelector(':scope > .mk-body')) : block.querySelector(':scope > .mk-body');

      if (line && !line.textContent.trim() && !line.nextElementSibling && line.parentNode === body) {
        const container = block.parentNode;
        let after = block;

        e.preventDefault();
        this.remember();
        line.remove();

        if (!body.children.length) {
          after = block.previousElementSibling;
          block.remove();
        }

        this.insertBlocks([{ type: 'p' }], after, container);
      }

      return;
    }

    if (TEXT_TYPES.includes(type)) {
      e.preventDefault();
      this.split(block, r);
    }
  }

  /** Enter in a paragraph or a heading: the end of the text goes to a new paragraph. */
  split(block, r) {
    const el = block.querySelector(':scope > .mk-body');
    const tail = document.createRange();

    this.remember();
    r.deleteContents();
    tail.setStart(r.endContainer, r.endOffset);
    tail.setEnd(el, el.childNodes.length);

    const p = document.createElement('p');

    p.append(tail.extractContents());

    // A paragraph keeps its alignment; a heading is followed by plain text.
    if (block.dataset.type === 'p' && el.className) {
      p.className = el.className.replace(/\bmk-body\b/, '').trim();
    }

    if (!p.textContent.trim() && !p.querySelector('img')) {
      p.replaceChildren();
    }

    const next = this.makeBlock({ type: 'p', el: p });

    block.after(next);
    this.focusEnd(next, false);
    this.changed();
  }

  blockMarkdown(e, block, r) {
    const el = block.querySelector(':scope > .mk-body');
    const head = document.createRange();

    head.selectNodeContents(el);
    head.setEnd(r.startContainer, r.startOffset);

    const typed = head.toString();
    const type = SHORTCUTS[typed];

    if (type) {
      e.preventDefault();
      head.deleteContents();
      this.changeType(block, type);
      this.say(t('MARKDOWN_MADE', this.typeName(type)));
    } else if (typed === '```') {
      e.preventDefault();
      head.deleteContents();
      this.changeType(block, 'pre');
    }
  }

  onBackspace(e, block, type, el) {
    // A heading, a quote or code turns back into a paragraph first.
    if (type !== 'p' && type !== 'ul' && type !== 'ol') {
      e.preventDefault();
      this.changeType(block, 'p', false);

      return;
    }

    if (type !== 'p') {
      return;
    }

    const prev = this.neighbour(block, -1, true);

    if (!prev) {
      return;
    }

    e.preventDefault();
    this.remember();

    const target = this.mergeTarget(prev);

    if (!target) {
      // An image, a table, a card: an empty paragraph goes, a full one stays.
      if (isEmpty(el)) {
        block.remove();
      }

      this.focusEnd(prev);
      this.changed();

      return;
    }

    this.joinInto(target, el, block);
  }

  onDelete(e, block, el) {
    const next = this.neighbour(block, 1, true);

    if (!next || next.dataset.type !== 'p' || !this.mergeTarget(block)) {
      return;
    }

    e.preventDefault();
    this.remember();
    this.joinInto(this.mergeTarget(block), next.querySelector(':scope > .mk-body'), next);
  }

  /** Where a following paragraph's text goes when the two are joined. */
  mergeTarget(block) {
    const type = block.dataset.type;
    const body = block.querySelector(':scope > .mk-body');

    if (type === 'p' || HEADINGS.includes(type)) {
      return body;
    }

    if (type === 'callout') {
      return calloutLines(body).lastElementChild;
    }

    if (type === 'ul' || type === 'ol' || type === 'blockquote') {
      return body.lastElementChild;
    }

    return null;
  }

  joinInto(target, source, sourceBlock) {
    const mark = document.createRange();

    mark.selectNodeContents(target);
    mark.collapse(false);

    if (target.lastChild && target.lastChild.nodeName === 'BR') {
      target.lastChild.remove();
    }

    const caret = document.createTextNode('');

    target.append(caret, ...[...source.childNodes].filter((n) => n.nodeName !== 'BR' || source.childNodes.length > 1));
    sourceBlock.remove();
    target.closest('[contenteditable="true"]').focus();
    mark.setStart(caret, 0);
    mark.collapse(true);
    window.getSelection().removeAllRanges();
    window.getSelection().addRange(mark);
    this.ensureEnd();
    this.changed();
  }

  /** The block before or after, crossing out of columns when `flat` is false. */
  neighbour(block, step, sameLevel = false) {
    const list = sameLevel ? this.blocksIn(block.parentNode) : this.flatBlocks();
    const i = list.indexOf(block);

    return list[i + step] || null;
  }

  /** Every block where the caret can go, in reading order, columns included. */
  flatBlocks() {
    const out = [];
    const walk = (container) => this.blocksIn(container).forEach((b) => {
      if (b.dataset.type === 'columns') {
        b.querySelectorAll(':scope > .mk-body > .mk-column').forEach(walk);
      } else {
        out.push(b);
      }
    });

    walk(this.surface);

    return out;
  }

  nextCell(block, cell, step) {
    const cells = [...block.querySelectorAll('caption, th, td')];
    const i = cells.indexOf(cell) + step;

    if (i >= cells.length) {
      // Tab in the last cell adds a row, as in a word processor.
      this.tableRow(block, true);
      this.nextCell(block, cell, step);

      return;
    }

    if (i >= 0) {
      const target = cells[i];
      const r = document.createRange();

      target.focus();
      r.selectNodeContents(target);
      window.getSelection().removeAllRanges();
      window.getSelection().addRange(r);
    }
  }

  /* ------------------------------------------------------------------ */
  /* BLOCK OPERATIONS                                                   */
  /* ------------------------------------------------------------------ */

  /** Inserts blocks after `after` (or at the start of `container`). Returns the last one. */
  insertBlocks(list, after, container = this.surface) {
    this.remember();

    let last = after;
    const inColumn = !!(container.closest && container.closest('.mk-column')) || !!(after && after.closest('.mk-column'));

    list.forEach((d) => {
      // No columns in a column, no "Read more" in a column: the article could not be cut there.
      const data = inColumn && (d.type === 'columns' || d.type === 'readmore') ? { type: 'html', html: d.el ? d.el.outerHTML : '' } : d;
      const block = this.makeBlock(data);

      if (last) {
        last.after(block);
      } else {
        container.prepend(block);
      }

      last = block;
    });

    this.ensureEnd();
    this.focusEnd(last);
    this.changed();
    this.nameModules();

    return last;
  }

  /**
   * The names of modules placed while writing (Opus, Formulus, Iris...), read
   * from the site. A comfort only: without it, the card shows the number.
   */
  async nameModules() {
    const known = this.options.modules || {};
    const cards = [...this.surface.querySelectorAll('.mk-block[data-type="module"]')];
    const ids = [...new Set(cards.map((b) => moduleId(kept(b))))].filter((id) => !known[id]);

    this.options.modules = known;

    if (ids.length) {
      const token = Joomla.getOptions('csrf.token', '');
      const base = (Joomla.getOptions('system.paths') || {}).base || '';

      try {
        const answer = await fetch(`${base}/index.php?option=com_ajax&plugin=markus&group=editors&format=json&ids=${ids.join(',')}&${token}=1`);

        Object.assign(known, (await answer.json()).data || {});
      } catch (err) {
        return;
      }
    }

    cards.forEach((b) => {
      const module = known[moduleId(kept(b))];
      const title = b.querySelector('.jmj-carte__titre');

      if (module && title && title.firstChild) {
        title.firstChild.nodeValue = module.title;
      }
    });
  }

  /** The width of a block's name, for the "+" placed beside it (CSS: --mk-kind-w); fonts may load late. */
  measureKind(kind) {
    if (!kind) {
      return;
    }

    if (!this.kindSizes) {
      this.kindSizes = new ResizeObserver((all) => all.forEach(({ target }) => {
        if (target.offsetWidth && target.parentNode) {
          target.parentNode.style.setProperty('--mk-kind-w', `${target.offsetWidth}px`);
        }
      }));
    }

    this.kindSizes.observe(kind);
  }

  /** Moves a block one place. `fromPanel`: the settings panel already remembered the page and keeps the focus. */
  move(block, step, fromPanel = false) {
    const list = this.blocksIn(block.parentNode);
    const i = list.indexOf(block);
    const target = list[i + step];

    if (!target) {
      this.say(t(step < 0 ? 'MOVE_FIRST' : 'MOVE_LAST'));

      return false;
    }

    if (!fromPanel) {
      this.remember();
    }

    if (step < 0) {
      target.before(block);
    } else {
      target.after(block);
    }

    this.ensureEnd();

    if (!fromPanel) {
      this.focusEnd(block);
    }

    this.changed();
    this.say(t('MOVED', this.typeName(block.dataset.type), list.indexOf(target) + 1, list.length));

    return true;
  }

  remove(block) {
    const name = this.typeName(block.dataset.type);
    const next = this.neighbour(block, 1) || this.neighbour(block, -1);
    const column = block.parentNode.closest('.mk-column');

    this.remember();
    block.remove();

    if (column && !this.blocksIn(column).length) {
      column.prepend(this.makeBlock({ type: 'p' }));
    }

    this.ensureEnd();
    this.focusEnd(next && next.isConnected ? next : this.surface.lastElementChild);
    this.changed();
    this.say(t('REMOVED', name));
  }

  /** Turns a text block into another type, keeping its words and its attributes. */
  changeType(block, type, atEnd = true) {
    const from = block.dataset.type;
    const el = block.querySelector(':scope > .mk-body');

    if (from === type) {
      return;
    }

    this.remember();

    const make = (tag) => {
      const n = document.createElement(tag);

      [...el.attributes].forEach((a) => {
        if (a.name !== 'contenteditable' && a.name !== 'aria-label' && a.name !== 'data-mk-placeholder') {
          n.setAttribute(a.name, a.value);
        }
      });
      n.classList.remove('mk-body');

      return n;
    };

    // The lines of the old block: list items, quote paragraphs, or the block itself.
    const lines = from === 'callout' ? [...calloutLines(el).children]
      : ((from === 'ul' || from === 'ol' || from === 'blockquote') ? [...el.children] : [el]);
    const content = (line) => (from === 'pre' ? [document.createTextNode(line.textContent)] : [...line.childNodes]);
    let made;

    if (type === 'ul' || type === 'ol') {
      made = [make(type)];
      lines.forEach((line) => {
        const li = document.createElement('li');

        li.append(...content(line));
        made[0].appendChild(li);
      });
    } else if (type === 'blockquote' || type === 'callout') {
      made = [type === 'callout' ? emptyElement('callout') : make('blockquote')];

      // A message keeps its title; the lines become its text.
      const box = type === 'callout' ? calloutLines(made[0]) : made[0];

      if (type === 'callout') {
        box.querySelector('.message__titre').textContent = t('CALLOUT_INFO');
        box.lastElementChild.remove();
      }

      lines.forEach((line) => {
        const p = document.createElement('p');

        p.append(...content(line));
        box.appendChild(p);
      });
    } else if (type === 'pre') {
      made = [document.createElement('pre')];
      made[0].textContent = lines.map((l) => l.textContent).join('\n');
    } else {
      made = lines.map((line, i) => {
        const n = i === 0 && (from === 'p' || HEADINGS.includes(from)) ? make(type) : document.createElement(type);

        n.append(...content(line));

        return n;
      });
    }

    const blocks = made.map((n) => this.makeBlock({ type, el: n }));

    block.replaceWith(...blocks);
    this.focusEnd(atEnd ? blocks[blocks.length - 1] : blocks[0], atEnd);
    this.ensureEnd();
    this.changed();
    this.updateToolbar();
  }

  /* ------------------------------------------------------------------ */
  /* THE BLOCK CHOOSER                                                  */
  /* ------------------------------------------------------------------ */

  /** The editor buttons of Joomla shown under the editor: Article, Image, Opus, Iris... */
  xtdButtons() {
    return [...this.host.querySelectorAll('.editor-xtd-buttons [data-joomla-editor-button-action]')];
  }

  xtd(name) {
    const i = (this.options.buttons || []).indexOf(name);

    return i < 0 ? null : this.xtdButtons()[i] || null;
  }

  /**
   * Opens the block list. `mode`: "after" or "before" inserts next to
   * `block`, "replace" puts the new block in place of an empty paragraph,
   * "change" turns a text block into another type.
   */
  async chooseBlock(target, mode, anchor) {
    let block = target;

    const changing = mode === 'change';
    const groups = CHOICES.filter(([g]) => !changing || g === 'TEXT').map(([g, items]) => ({
      title: t(`GROUP_${g}`),
      items: items.map(([id, sign, keys, hot]) => ({
        id, sign, keys, hot: hot ? `Alt+${t('KEY_SHIFT')}+${hot}` : '', label: this.typeName(id), hint: t(`HINT_${id.toUpperCase()}`),
      })),
    }));

    if (!changing) {
      const names = this.options.buttons || [];
      const items = this.xtdButtons().map((b, i) => ({
        // The button's own icon (Cyrille: an arrow said "opens a new tab", which it does not).
        id: `xtd:${names[i]}`, icon: logoOf(names[i]) || iconOf(b), label: b.textContent.trim() || b.title, hint: t('HINT_XTD'),
      })).filter((it) => !COVERED.includes(it.id.slice(4)));

      if (items.length) {
        groups.push({ title: t('GROUP_JOOMLA'), items });
      }
    }

    const back = this.editable(block) || this.surface;
    const item = await openChooser(anchor || back, groups, back);

    if (!item) {
      return;
    }

    if (changing) {
      this.changeType(block, item.id);

      return;
    }

    // Before a block: an empty paragraph there, which the new block replaces.
    if (mode === 'before') {
      const p = this.makeBlock({ type: 'p' });

      block.before(p);
      block = p;
    }

    const empty = block && block.dataset.type === 'p' && isEmpty(block.querySelector(':scope > .mk-body'));
    const where = { block, replace: mode === 'replace' || empty };

    if (item.id.startsWith('xtd:') || item.id === 'image') {
      this.runXtd(item.id === 'image' ? this.imageButton() : item.id.slice(4), where);

      return;
    }

    if (where.replace && block && TEXT_TYPES.includes(item.id)) {
      this.changeType(block, item.id);

      return;
    }

    const last = this.insertBlocks([{ type: item.id }], block, block ? block.parentNode : this.surface);

    if (where.replace && block) {
      block.remove();
    }

    this.focusEnd(last);
    this.say(t('ADDED', this.typeName(item.id)));
  }

  /** The media of Iris when it is installed, otherwise Joomla's own image button. */
  imageButton() {
    return this.xtd('iris_images') ? 'iris_images' : 'image';
  }

  /**
   * Runs a Joomla editor button. It answers by calling replaceSelection(),
   * maybe much later (a modal window): the place is remembered until then.
   */
  /**
   * THE ADDRESS OF A JOOMLA PAGE, for a button: Joomla's own window (Article,
   * Contact, Menu) answers with a link; its address is taken, nothing is
   * inserted. Resolves with the address, or never when the window is closed.
   */
  pickLink(name) {
    return new Promise((resolve) => {
      this.linkWanted = resolve;
      this.runXtd(name, null, true);
    });
  }

  runXtd(name, where, picking = false) {
    const button = this.xtd(name);

    // A window closed without a choice left an address wanted: an insertion now is an insertion.
    if (!picking) {
      this.linkWanted = null;
    }

    if (!button) {
      this.say(t('XTD_MISSING', name));

      return;
    }

    this.pending = where;
    JoomlaEditor.setActive(this.textarea.id);
    button.click();
  }

  /* ------------------------------------------------------------------ */
  /* JOOMLA EDITOR API                                                  */
  /* ------------------------------------------------------------------ */

  getSelection() {
    this.onSelection();

    return this.range ? this.range.toString() : '';
  }

  /** What an editor button inserts: inline HTML at the caret, blocks between blocks. */
  replaceSelection(html) {
    if (this.linkWanted) {
      // A link (Article, Contact, Menu), or a file of the media (an image, a document) whose address is taken.
      const doc = new DOMParser().parseFromString(String(html), 'text/html');
      const found = doc.querySelector('a[href]') || doc.querySelector('[src]');
      const done = this.linkWanted;

      this.linkWanted = null;

      if (found) {
        done(found.getAttribute('href') || found.getAttribute('src'));
      }

      return;
    }

    if (!this.source.hidden) {
      const code = this.code();

      code.setRangeText(html, code.selectionStart, code.selectionEnd, 'end');

      return;
    }

    // The live caret when it is in the text; the remembered one when a window took the focus.
    this.onSelection();

    const where = this.pending || { block: this.current };
    const list = parse(html);
    const inline = list.length === 1 && list[0].type === 'p' && !/^\s*<p[\s>]/i.test(html) && !moduleId(html);

    this.pending = null;

    if (inline && !where.replace && this.range && this.blockOf(this.range.startContainer) && this.restore()) {
      this.insertInline(list[0].el);

      return;
    }

    const block = where.block && where.block.isConnected ? where.block : null;
    const empty = block && block.dataset.type === 'p' && isEmpty(block.querySelector(':scope > .mk-body'));
    const last = this.insertBlocks(list, block, block ? block.parentNode : this.surface);

    if (block && (where.replace || empty) && block !== last) {
      block.remove();
    }

    this.ensureEnd();
    this.changed();
  }

  disable(enable) {
    this.surface.querySelectorAll('[contenteditable], textarea').forEach((el) => {
      if (el.tagName === 'TEXTAREA') {
        el.readOnly = !enable;
      } else {
        el.setAttribute('contenteditable', String(enable));
      }
    });
    this.toolbar.querySelectorAll('button').forEach((b) => { b.disabled = !enable; });
  }

  /* ------------------------------------------------------------------ */
  /* LINKS                                                              */
  /* ------------------------------------------------------------------ */

  async link() {
    this.onSelection();

    if (!this.restore()) {
      this.say(t('PLACE_CARET'));

      return;
    }

    const r = this.selection();
    const node = r.startContainer.nodeType === Node.ELEMENT_NODE ? r.startContainer : r.startContainer.parentNode;
    const a = node.closest('a');
    const range = r.cloneRange();
    const hidden = a ? a.querySelector('.visually-hidden') : null;
    const text = a ? [...a.childNodes].filter((n) => n !== hidden).map((n) => n.textContent).join('') : range.toString();
    const v = await linkDialog({
      href: a ? a.getAttribute('href') : '',
      text,
      blank: a ? a.target === '_blank' : false,
      article: !!this.xtd('article'),
      menu: !!this.xtd('menu'),
      pick: (name) => this.pickLink(name),
    });

    if (!v) {
      this.restore();

      return;
    }

    this.range = range;

    if (v.remove && a) {
      this.remember();
      if (hidden) {
        hidden.remove();
      }

      a.replaceWith(...a.childNodes);
      this.changed();
      this.say(t('LINK_REMOVED'));

      return;
    }

    let href;

    if (v.kind === 'article' || v.kind === 'menu') {
      // The address given by Joomla's window, the words of the author.
      href = String(v[`${v.kind}Href`] || '').trim();
    } else {
      href = v.kind === 'mail' ? (v.mail.trim() ? `mailto:${v.mail.trim()}` : '') : v.url.trim().replace(/^www\./i, 'https://www.');
    }

    if (!href || href === 'https://') {
      this.say(t('LINK_EMPTY'));

      return;
    }

    this.remember();

    const el = a || document.createElement('a');

    el.setAttribute('href', href);
    el.textContent = v.text.trim() || text || href;

    if (v.blank) {
      // Announced to screen readers (RGAA 13.2), as Joomla's own links do.
      el.target = '_blank';
      el.rel = 'noopener noreferrer';
      el.insertAdjacentHTML('beforeend', `<span class="visually-hidden"> ${escape(t('NEW_WINDOW'))}</span>`);
    } else {
      el.removeAttribute('target');
      el.removeAttribute('rel');
    }

    if (!a) {
      this.restore();
      const sel = this.selection();

      sel.deleteContents();
      sel.insertNode(el);
    }

    this.focusAfter(el);
    this.changed();
    this.say(t('LINK_DONE'));
  }

  /** Puts the content of an element at the caret, replacing the selection. */
  insertInline(el) {
    const r = this.selection();
    const nodes = [...el.childNodes];

    this.remember();
    r.deleteContents();
    [...nodes].reverse().forEach((n) => r.insertNode(n));

    if (nodes.length) {
      this.focusAfter(nodes[nodes.length - 1]);
    }

    this.changed();
  }

  focusAfter(node) {
    const host = node.parentNode.closest('[contenteditable="true"]');
    const r = document.createRange();

    host.focus({ preventScroll: true });
    r.setStartAfter(node);
    r.collapse(true);
    window.getSelection().removeAllRanges();
    window.getSelection().addRange(r);
  }

  /* ------------------------------------------------------------------ */
  /* PASTE                                                              */
  /* ------------------------------------------------------------------ */

  onPaste(e) {
    const r = this.selection();
    const block = r && this.blockOf(r.startContainer);

    if (!block || !e.clipboardData || e.target.tagName === 'TEXTAREA') {
      return;
    }

    const type = block.dataset.type;
    const html = e.clipboardData.getData('text/html');
    const text = e.clipboardData.getData('text/plain');
    const inCell = (r.startContainer.nodeType === Node.ELEMENT_NODE ? r.startContainer : r.startContainer.parentNode)
      .closest('td, th, caption, figcaption');

    e.preventDefault();

    // Code, cells and captions take the text only, at the caret.
    if (type === 'pre' || inCell) {
      document.execCommand('insertText', false, type === 'pre' ? text : text.replace(/\s*\n\s*/g, ' '));

      return;
    }

    let clean;
    let message;

    // Blocks copied from Markus come back as they were, settings included: no cleaning.
    if (html.includes(CLIP)) {
      const list = parse(html.slice(html.indexOf(CLIP) + CLIP.length).replace(/<!--EndFragment-->[\s\S]*$/, ''));

      if (list.length) {
        this.insertBlocks(list, block, block.parentNode);
        this.say(t('BLOCKS_PASTED', list.length));
      }

      return;
    }

    if (html) {
      const report = cleanPasted(html);

      clean = report.html;
      message = t('PASTED_CLEAN', report.source || t('PASTED_WEB'))
        + (report.lists ? ` ${t('PASTED_LISTS', report.lists)}` : '')
        + (report.images ? ` ${t('PASTED_IMAGES', report.images)}` : '');
    } else if (looksLikeMarkdown(text)) {
      clean = markdownToHtml(text, this.markdownOptions());
      message = t('PASTED_MARKDOWN');
    } else {
      clean = textToHtml(text);
    }

    const list = parse(clean);

    // One paragraph goes into the text, at the caret.
    if (list.length === 1 && list[0].type === 'p') {
      this.insertInline(list[0].el);
    } else if (list.length) {
      const el = block.querySelector(':scope > .mk-body');

      if (TEXT_TYPES.includes(type) && !isEmpty(el) && !Markus.atEdge(el, r, false)) {
        this.split(block, r);
      }

      const empty = type === 'p' && isEmpty(el);
      const last = this.insertBlocks(list, block, block.parentNode);

      if (empty && block !== last) {
        block.remove();
      }
    }

    this.changed();

    if (message) {
      this.say(message);
    }
  }

  /** Joomla's settings column beside the editor (Status, Category...), where the settings panel goes; or null. */
  sideColumn() {
    const form = this.textarea.form;

    return (form && [...form.querySelectorAll('.col-lg-3, .col-md-3')].find((c) => c.offsetWidth && !c.contains(this.host))) || null;
  }

  /* ------------------------------------------------------------------ */
  /* SETTINGS OF A BLOCK: settings.js, in the charter's side panel.     */
  /* ------------------------------------------------------------------ */

  settings(block) {
    if (!openSettings(this, block)) {
      this.say(t('NO_SETTINGS'));
    }
  }

  /** Adds a row at the end. `undoable`: false inside the settings panel, whose cancel undoes it. */
  tableRow(block, atEnd = false, undoable = true) {
    const body = block.querySelector(':scope > .mk-body');
    const table = body.tagName === 'TABLE' ? body : body.querySelector('table');
    const tbody = table.tBodies[0] || table.createTBody();
    const model = tbody.rows[tbody.rows.length - 1] || (table.tHead && table.tHead.rows[0]);
    const row = document.createElement('tr');

    [...(model ? model.cells : [null])].forEach((c) => {
      const cell = document.createElement(c && c.getAttribute('scope') === 'row' ? 'th' : 'td');

      if (cell.tagName === 'TH') {
        cell.setAttribute('scope', 'row');
      }

      row.appendChild(cell);
    });

    if (undoable) {
      this.remember();
    }

    tbody.appendChild(row);
    this.makeEditable('table', body, this.typeName('table'));

    if (!atEnd) {
      this.focusEnd(block);
    }

    this.changed();
  }

  /* ------------------------------------------------------------------ */
  /* SOURCE CODE: Joomla's own CodeMirror, when it is there.            */
  /* ------------------------------------------------------------------ */

  code() {
    return this.source.querySelector('textarea');
  }

  /** The settings of the Markdown converter: "#" gives <h2>, the article title being the <h1>. */
  markdownOptions() {
    return {
      shift: 1,
      newWindow: t('NEW_WINDOW'),
      noteBackLabel: t('NOTE_BACK'),
      takenIds: [...this.surface.querySelectorAll('[id]')].map((n) => n.id),
    };
  }

  /** Shows the article as HTML or as Markdown, in Joomla's CodeMirror; again, back to the blocks. */
  async toggleSource(mode) {
    const open = !this.source.hidden;
    const same = this.sourceMode === mode;

    // The source view has its own search (CodeMirror): the bar of the text closes.
    if (this.finder.open) {
      this.finder.hide();
    }

    if (open) {
      await this.closeSource();

      if (same) {
        return;
      }
    }

    let text = this.htmlOf(this.surface);

    if (mode === 'markdown') {
      const md = htmlToMarkdown(text, this.markdownOptions());

      // What Markdown cannot write is never dropped in silence: it is listed first.
      if (md.losses.length && !await window.JoomanjiFenetre.demander({
        titre: t('LOSS_TITLE'),
        texte: `${t('LOSS_TEXT')}\n\n${md.losses.map((l) => `${t(`LOSS_${l.code.replace('-', '_').toUpperCase()}`, l.detail)} (${l.n})`).join('\n\n')}`,
        ton: 'alerte',
        bouton: t('LOSS_GO'),
      })) {
        return;
      }

      text = md.text;
    }

    const code = this.code();
    const button = this.toolbar.querySelector(`[data-mk="${mode === 'html' ? 'source' : 'markdown'}"]`);

    this.sourceMode = mode;
    code.value = text;
    this.source.querySelector('label[for]').textContent = t(mode === 'markdown' ? 'MARKDOWN' : 'SOURCE');
    this.source.querySelector('.mk-source__bar').hidden = mode !== 'markdown';
    this.surface.hidden = true;
    this.breaks.soon();
    this.source.hidden = false;
    this.toolbar.querySelectorAll('.mk-button').forEach((b) => { b.disabled = b !== button; });
    button.setAttribute('aria-pressed', 'true');

    try {
      const { createFromTextarea } = await import('codemirror');

      this.view = await createFromTextarea(code, { mode, lineWrapping: true, lineNumbers: true, foldGutter: true, height: '30rem' });
    } catch (err) {
      // Without CodeMirror the plain field does the job.
      this.view = null;
    }

    (this.view || code).focus();
    this.say(t(mode === 'markdown' ? 'MARKDOWN_ON' : 'SOURCE_ON'));
  }

  /** Back to the blocks, with what was written in the source view. */
  async closeSource() {
    const html = this.getValue();

    if (this.view) {
      this.view.destroy();
      this.view = null;
      this.code().style.display = '';
    }

    this.source.hidden = true;
    this.surface.hidden = false;
    this.breaks.soon();
    this.toolbar.querySelectorAll('.mk-button').forEach((b) => {
      b.disabled = false;
      b.setAttribute('aria-pressed', 'false');
    });
    this.sourceMode = '';
    this.remember();
    this.load(html);
    this.focusEnd(this.surface.firstElementChild, false);
    this.say(t('SOURCE_OFF'));
  }

  /** Puts a text in the source view, CodeMirror or the plain field. */
  setSourceText(text) {
    if (this.view) {
      this.view.dispatch({ changes: { from: 0, to: this.view.state.doc.length, insert: text } });
    } else {
      this.code().value = text;
    }
  }

  /**
   * Reads a .md file. Its first "#" heading becomes the article title when the
   * title is still empty, as with Markus 1.0; otherwise it stays a heading.
   */
  async readMarkdownFile(file) {
    let text = (await file.text()).replace(/^﻿/, '');
    const title = document.getElementById('jform_title');
    const head = headings(text);

    if (head.title && title && !title.value.trim()) {
      title.value = head.title;
      title.dispatchEvent(new Event('change', { bubbles: true }));
      text = head.rest;
    }

    return text;
  }

  /** "Open a .md file" in the Markdown view: the file replaces the text being written. */
  async openMarkdownFile(file) {
    this.setSourceText(await this.readMarkdownFile(file));
    this.changed();
    this.say(t('MD_OPENED', file.name));
  }

  /** "Save as .md": the article in Markdown, named after the article. */
  saveMarkdownFile() {
    const text = this.view ? this.view.state.doc.toString() : this.code().value;
    const title = document.getElementById('jform_alias') || document.getElementById('jform_title');
    const name = ((title && title.value.trim()) || 'article').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
      .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'article';
    const link = document.createElement('a');

    link.href = URL.createObjectURL(new Blob([text], { type: 'text/markdown;charset=utf-8' }));
    link.download = `${name}.md`;
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(link.href), 1000);
    this.say(t('MD_SAVED', link.download));
  }

  /* ------------------------------------------------------------------ */
  /* DRAG AND DROP, by the handle. The keyboard way is Alt+Shift+arrows. */
  /* ------------------------------------------------------------------ */

  dragAndDrop() {
    let dragged = null;
    let target = null;
    let before = false;

    const clear = () => {
      this.surface.querySelectorAll('.mk-drop-before, .mk-drop-after').forEach((b) => b.classList.remove('mk-drop-before', 'mk-drop-after'));
    };

    // In the editor, a click on an image to be enlarged chooses the block: the larger view is the site's.
    this.surface.addEventListener('click', (e) => {
      if (e.target.closest && e.target.closest('[popovertarget]')) {
        e.preventDefault();
      }
    }, true);

    this.surface.addEventListener('pointerdown', (e) => {
      const handle = e.target.closest('[data-mk="handle"]');

      if (handle) {
        this.blockOf(handle).setAttribute('draggable', 'true');
      }
    });

    this.surface.addEventListener('dragstart', (e) => {
      dragged = e.target.closest && e.target.closest('.mk-block[draggable="true"]');

      if (!dragged) {
        return;
      }

      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', '');
      dragged.classList.add('mk-dragging');
    });

    this.surface.addEventListener('dragover', (e) => {
      if (!dragged) {
        // A .md file dragged from the computer may be dropped too.
        if (e.dataTransfer.types.includes('Files')) {
          e.preventDefault();
        }

        return;
      }

      const over = this.blockOf(e.target);

      if (!over || over === dragged || dragged.contains(over)) {
        return;
      }

      e.preventDefault();
      clear();

      const r = over.getBoundingClientRect();

      target = over;
      before = e.clientY < r.top + r.height / 2;
      over.classList.add(before ? 'mk-drop-before' : 'mk-drop-after');
    });

    this.surface.addEventListener('drop', async (e) => {
      const file = e.dataTransfer.files[0];

      // A .md file: its blocks go after the block it is dropped on.
      if (!dragged && file && /\.(md|markdown|txt)$/i.test(file.name)) {
        e.preventDefault();

        const html = markdownToHtml(await this.readMarkdownFile(file), this.markdownOptions());
        const on = this.blockOf(e.target);

        this.insertBlocks(parse(html), on, on ? on.parentNode : this.surface);
        this.say(t('MD_OPENED', file.name));

        return;
      }

      if (!dragged || !target) {
        return;
      }

      e.preventDefault();
      this.remember();

      if (target.closest('.mk-column') && dragged.dataset.type === 'columns') {
        this.say(t('NO_COLUMNS_IN_COLUMN'));
      } else if (before) {
        target.before(dragged);
      } else {
        target.after(dragged);
      }

      this.ensureEnd();
      this.changed();
    });

    this.surface.addEventListener('dragend', () => {
      clear();

      if (dragged) {
        dragged.classList.remove('mk-dragging');
        dragged.removeAttribute('draggable');
      }

      dragged = null;
      target = null;
    });
  }
}
