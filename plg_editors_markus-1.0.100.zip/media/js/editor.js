/**
 * Markus Editor: the <joomla-editor-markus> element.
 *
 * Built like Joomla's own editors (plg_editors_none): a custom element
 * around the form's <textarea>, registered with the Joomla editor API so
 * that every editor button (Article, Image, Menu, Opus, Iris, Formulus...)
 * talks to Markus as it talks to TinyMCE.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

import { JoomlaEditor, JoomlaEditorDecorator } from 'editor-api';
import Markus from 'plg_editors_markus.markus';

class MarkusDecorator extends JoomlaEditorDecorator {
  getValue() {
    return this.instance.getValue();
  }

  setValue(value) {
    this.instance.setValue(value);

    return this;
  }

  getSelection() {
    return this.instance.getSelection();
  }

  replaceSelection(value) {
    this.instance.replaceSelection(value);

    return this;
  }

  disable(enable) {
    this.instance.disable(enable);

    return this;
  }
}

class JoomlaEditorMarkus extends HTMLElement {
  connectedCallback() {
    const textarea = this.querySelector(':scope > textarea[id]');

    if (!textarea || this.markus) {
      return;
    }

    this.markus = new Markus(this, textarea, JSON.parse(this.getAttribute('options') || '{}'));
    JoomlaEditor.register(new MarkusDecorator(this.markus, 'markus', textarea.id));

    if (textarea.disabled || textarea.readOnly) {
      this.markus.disable(false);
    }
  }

  disconnectedCallback() {
    if (this.markus) {
      JoomlaEditor.unregister(this.markus.textarea.id);
    }
  }
}

customElements.define('joomla-editor-markus', JoomlaEditorMarkus);
