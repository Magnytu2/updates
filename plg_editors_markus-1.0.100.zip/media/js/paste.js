/**
 * Markus Editor: pasting.
 *
 * Text pasted from Word, LibreOffice, Google Docs or a web page arrives with
 * its fonts, sizes, colours, fake lists and office tags. Markus keeps the
 * structure (headings, lists, tables, links, bold, italic, alignment) and
 * drops the rest, like TinyMCE's "paste from Word". Plain text that looks
 * like Markdown becomes blocks: Markdown is a way of writing, never of
 * storing. The Markdown itself is read by markdown.js, the only converter.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

import { escape } from 'plg_editors_markus.i18n';

const DROP = 'style, meta, link, script, title, xml, template, iframe, object, embed, form, input, button, select, textarea, svg, canvas, video, audio';
const UNWRAP = new Set(['SPAN', 'FONT', 'U', 'SMALL', 'BIG', 'INS', 'STRIKE', 'DIV', 'SECTION', 'ARTICLE', 'HEADER',
  'FOOTER', 'MAIN', 'CENTER', 'NAV', 'ASIDE', 'O:P']);
const KEEP_ATTRS = ['href', 'src', 'alt', 'colspan', 'rowspan', 'scope', 'title'];
const SAFE_LINK = /^(https?:|mailto:|tel:|index\.php|\/|#[^_])/i;
const SAFE_IMAGE = /^(https?:|images\/|\/)/i;

/** Where the HTML comes from, for the message read after pasting. */
function sourceOf(html) {
  if (/urn:schemas-microsoft-com:office|class="?Mso|mso-/i.test(html)) {
    return 'Word';
  }

  if (/docs-internal-guid/.test(html)) {
    return 'Google Docs';
  }

  return /<meta[^>]+(LibreOffice|OpenOffice)/i.test(html) ? 'LibreOffice' : '';
}

/** Word writes its lists as paragraphs with "mso-list" and a typed bullet. */
function rebuildWordLists(doc) {
  let current = null;
  let count = 0;

  [...doc.body.querySelectorAll('p')].forEach((p) => {
    const m = /mso-list:\s*l(\d+)\s+level(\d+)/i.exec(p.getAttribute('style') || '');

    if (!m) {
      current = null;

      return;
    }

    const marker = p.querySelector('span[style*="mso-list:Ignore"], span[style*="mso-list: Ignore"]');
    const markerText = marker ? marker.textContent.trim() : '';

    if (marker) {
      const outer = marker.parentNode.tagName === 'SPAN' && marker.parentNode.textContent.trim() === markerText;

      (outer ? marker.parentNode : marker).remove();
    }

    const tag = /^(\d+|[a-z]|[ivxlc]+)[.)]/i.test(markerText) ? 'ol' : 'ul';
    const level = Number(m[2]);
    const li = doc.createElement('li');

    li.append(...p.childNodes);

    if (!current || p.previousElementSibling !== current.last) {
      current = { levels: [null, doc.createElement(tag)] };
      p.before(current.levels[1]);
      count += 1;
    }

    let parent = current.levels[level];

    if (!parent) {
      const above = current.levels[level - 1] || current.levels[1];
      const lastLi = above.lastElementChild || above.appendChild(doc.createElement('li'));

      parent = lastLi.appendChild(doc.createElement(tag));
      current.levels[level] = parent;
    }

    current.levels.length = level + 1;
    parent.appendChild(li);
    current.last = p;
    p.hidden = true;
  });

  doc.body.querySelectorAll('p[hidden]').forEach((p) => p.remove());

  return count;
}

/** Bold and italic written as styles become <strong> and <em>. */
function styledToTags(doc, el) {
  const style = el.getAttribute('style') || '';
  let node = null;

  if (/font-weight:\s*(bold|[6-9]00)/i.test(style) && el.tagName !== 'B' && el.tagName !== 'STRONG') {
    node = doc.createElement('strong');
  }

  if (/font-style:\s*italic/i.test(style) && el.tagName !== 'I' && el.tagName !== 'EM') {
    const em = doc.createElement('em');

    if (node) {
      node.appendChild(em);
    }

    node = node || em;
  }

  return node;
}

/**
 * Cleans pasted HTML. Returns { html, source, lists, styles, images }:
 * the counts feed the message announced to the author.
 */
export function cleanPasted(html) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const body = doc.body;
  const report = { source: sourceOf(html), lists: 0, styles: 0, images: 0 };
  const walker = doc.createTreeWalker(body, NodeFilter.SHOW_COMMENT);
  const comments = [];

  while (walker.nextNode()) {
    comments.push(walker.currentNode);
  }

  comments.forEach((c) => c.remove());
  body.querySelectorAll(DROP).forEach((e) => e.remove());
  report.lists = rebuildWordLists(doc);

  // From the leaves up, so that unwrapping never skips a child.
  [...body.querySelectorAll('*')].reverse().forEach((el) => {
    const tag = el.tagName;
    const style = el.getAttribute('style') || '';

    if (el.hasAttribute('style') || el.hasAttribute('class')) {
      report.styles += 1;
    }

    const wrapper = styledToTags(doc, el);

    if (UNWRAP.has(tag) || tag.includes(':')) {
      if (wrapper) {
        (wrapper.firstElementChild || wrapper).append(...el.childNodes);
        el.replaceWith(wrapper);
      } else {
        el.replaceWith(...el.childNodes);
      }

      return;
    }

    if (tag === 'B' || tag === 'I') {
      const better = doc.createElement(tag === 'B' ? 'strong' : 'em');

      better.append(...el.childNodes);
      el.replaceWith(better);

      return;
    }

    // One <h1> per page: the article title. Pasted levels shift down by one.
    if (/^H[1-6]$/.test(tag)) {
      const level = Math.min(6, Number(tag[1]) + (tag === 'H1' ? 1 : 0));

      if (level !== Number(tag[1])) {
        const h = doc.createElement(`h${level}`);

        h.append(...el.childNodes);
        el.replaceWith(h);
        el = h;
      }
    }

    if (tag === 'A' && !SAFE_LINK.test(el.getAttribute('href') || '')) {
      el.replaceWith(...el.childNodes);

      return;
    }

    // Word sends local files (file://, blob:): they cannot reach the site.
    if (tag === 'IMG' && !SAFE_IMAGE.test(el.getAttribute('src') || '')) {
      report.images += 1;
      el.remove();

      return;
    }

    [...el.attributes].forEach((a) => {
      if (!KEEP_ATTRS.includes(a.name)) {
        el.removeAttribute(a.name);
      }
    });

    const align = (/text-align:\s*(center|right)/i.exec(style) || [])[1];

    if (align && /^(P|H[2-6])$/.test(el.tagName)) {
      el.className = align === 'center' ? 'text-center' : 'text-end';
    }
  });

  body.querySelectorAll('td > p:only-child, th > p:only-child, li > p:only-child').forEach((p) => p.replaceWith(...p.childNodes));

  // A pasted table gets Bootstrap's class; a first row all in bold becomes its header.
  body.querySelectorAll('table').forEach((table) => {
    const first = table.rows[0];
    const bold = first && !table.tHead && [...first.cells].every((c) => {
      const strong = c.querySelector('strong');

      return c.tagName === 'TH' || (strong && strong.textContent.trim() === c.textContent.trim());
    });

    if (bold) {
      const head = table.createTHead();
      const row = head.insertRow();

      [...first.cells].forEach((c) => {
        const th = doc.createElement('th');

        th.scope = 'col';
        th.textContent = c.textContent.trim();
        row.appendChild(th);
      });
      first.remove();
    }

    table.className = 'table';
  });

  body.querySelectorAll('p, h2, h3, h4, h5, h6, li').forEach((p) => {
    if (!p.textContent.trim() && !p.querySelector('img')) {
      p.remove();
    }
  });

  report.html = body.innerHTML.replace(/[ \t]{2,}/g, ' ').trim();

  return report;
}

/** True when a plain text is worth reading as Markdown. */
export function looksLikeMarkdown(text) {
  return /^(#{1,6}\s|\s*[-*+]\s|\s*\d+[.)]\s|>\s?|```|\|.+\|)/m.test(text) || /\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\)/.test(text);
}

/** Plain text that is not Markdown: one paragraph per blank-line group. */
export function textToHtml(text) {
  return String(text).replace(/\r\n?/g, '\n').split(/\n\s*\n/).filter((p) => p.trim())
    .map((p) => `<p>${escape(p.trim()).replace(/\n/g, '<br>')}</p>`).join('\n');
}
