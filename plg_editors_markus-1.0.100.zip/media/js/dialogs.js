/**
 * Markus Editor: the settings windows.
 *
 * Every window is the Joomanji charter's own (`JoomanjiFenetre.saisir()`, a
 * native <dialog>: Escape, focus trap, inert background). Each function
 * resolves with the values of the named fields, or null when cancelled.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

import { t, escape } from 'plg_editors_markus.i18n';
import { pair, readHues, keepHue, pickHue, hueName, shade } from 'plg_editors_markus.colours';
import { ICONS, iconSvg } from 'plg_editors_markus.icons';

const ask = (o) => window.JoomanjiFenetre.saisir(o);

function field(name, label, value, hint = '', type = 'text') {
  return `<label class="mk-field"><span>${escape(label)}</span>`
    + `<input type="${type}" name="${name}" value="${escape(value)}" autocomplete="off" spellcheck="false">`
    + `${hint ? `<small>${escape(hint)}</small>` : ''}</label>`;
}

function check(name, label, checked, hint = '') {
  return `<label class="mk-check"><input type="checkbox" name="${name}"${checked ? ' checked' : ''}> ${escape(label)}</label>`
    + `${hint ? `<p class="mk-field-hint">${escape(hint)}</p>` : ''}`;
}

function radios(name, legend, value, options) {
  return `<fieldset class="mk-radios"><legend>${escape(legend)}</legend>${options.map(([v, label]) => (
    `<label><input type="radio" name="${name}" value="${escape(v)}"${v === value ? ' checked' : ''}> ${escape(label)}</label>`
  )).join('')}</fieldset>`;
}

/** Shows only the fields of the chosen radio: `data-for="value"` sections. */
export function switcher(body, name) {
  const show = () => {
    const value = (body.querySelector(`input[name="${name}"]:checked`) || {}).value;

    body.querySelectorAll('[data-for]').forEach((s) => {
      s.hidden = s.dataset.for !== value;
    });
  };

  body.querySelectorAll(`input[name="${name}"]`).forEach((r) => r.addEventListener('change', show));
  show();
}

/**
 * The link window. Internal links are chosen with Joomla's own windows
 * ("Article" and "Menu" buttons of the editor), so they are written the way
 * Joomla writes them and follow the article when its alias changes. Choosing
 * "Article" or "Menu" opens that window at once (`o.pick`); the address it
 * gives is shown, the words of the link stay the author's.
 */
export function linkDialog(o) {
  const kinds = [['web', t('LINK_WEB')], ['mail', t('LINK_MAIL')]];

  if (o.article) {
    kinds.push(['article', t('LINK_ARTICLE')]);
  }

  if (o.menu) {
    kinds.push(['menu', t('LINK_MENU')]);
  }

  const href = o.href || '';
  const mail = /^mailto:/.test(href);
  let kind = mail ? 'mail' : 'web';

  // A link written by Joomla's windows is shown as such.
  if (o.article && /option=com_content&(amp;)?view=article/.test(href)) {
    kind = 'article';
  } else if (o.menu && /^index\.php\?Itemid=/.test(href)) {
    kind = 'menu';
  }

  const internal = kind === 'article' || kind === 'menu';
  const picked = (k) => `<div data-for="${k}"><p class="mk-buttons"><button type="button" class="btn btn-sm btn-outline-secondary" data-mk-pick="${k}">`
    + `${escape(t(`LINK_PICK_${k.toUpperCase()}`))}</button></p>`
    + field(`${k}Href`, t('LINK_PICKED'), kind === k ? href : '', t(`LINK_${k.toUpperCase()}_HINT`))
    + '</div>';

  return ask({
    titre: href ? t('LINK_EDIT') : t('LINK_ADD'),
    bouton: href ? t('SAVE') : t('LINK_ADD'),
    corps: radios('kind', t('LINK_KIND'), kind, kinds)
      + `<div data-for="web">${field('url', t('LINK_URL'), mail || internal ? '' : (href || 'https://'), t('LINK_URL_HINT'))}</div>`
      + `<div data-for="mail">${field('mail', t('LINK_MAIL_ADDRESS'), mail ? href.slice(7) : '', '', 'email')}</div>`
      + (o.article ? picked('article') : '')
      + (o.menu ? picked('menu') : '')
      + field('text', t('LINK_TEXT'), o.text || '', t('LINK_TEXT_HINT'))
      + check('blank', t('LINK_NEW_TAB'), o.blank, t('LINK_NEW_TAB_HINT'))
      + (href ? check('remove', t('LINK_REMOVE'), false) : ''),
    pret: (body) => {
      switcher(body, 'kind');

      const pick = async (k) => {
        const got = await o.pick(k);
        const input = body.querySelector(`[name="${k}Href"]`);

        if (got && input) {
          input.value = got;
          input.dispatchEvent(new Event('input', { bubbles: true }));
        }
      };

      body.querySelectorAll('[data-mk-pick]').forEach((b) => b.addEventListener('click', () => pick(b.dataset.mkPick)));
      // Choosing "Article" or "Menu" opens Joomla's window straight away, the first time.
      body.querySelectorAll('input[name="kind"]').forEach((r) => r.addEventListener('change', () => {
        const input = body.querySelector(`[name="${r.value}Href"]`);

        if (r.checked && input && !input.value) {
          pick(r.value);
        }
      }));
    },
  });
}

/** The values of the named fields of a form, read like the charter's window does. */
function values(zone) {
  const v = {};

  zone.querySelectorAll('[name]').forEach((c) => {
    if (c.type === 'radio' && !c.checked) {
      return;
    }

    v[c.name] = c.type === 'checkbox' ? c.checked : c.value;
  });

  return v;
}

/** A drop-down list, for choices that would make too many radio buttons. */
function select(name, label, value, options) {
  return `<label class="mk-field"><span>${escape(label)}</span><select name="${name}">${options.map(([v, text]) => (
    `<option value="${escape(v)}"${v === value ? ' selected' : ''}>${escape(text)}</option>`
  )).join('')}</select></label>`;
}

/**
 * A titled group of fields that folds on itself, drawn like Opus's sections
 * (`poserChevron` of mod_opus admin.js): a framed box, its title, and before
 * it a small square button with a chevron that turns a quarter when folded.
 * `key` names the group for the memory of folded groups (rememberGroups()).
 */
let groups = 0;

function group(key, legend, html) {
  groups += 1;

  const id = `mk-group-${groups}`;

  return `<section class="mk-group-settings" data-mk-group="${key}"><h3 class="mk-group-settings__head">`
    + `<button type="button" class="mk-chevron" aria-expanded="true" aria-controls="${id}" aria-label="${escape(t('FOLD', legend))}">`
    + '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 9l6 6 6-6"/></svg></button>'
    + `${escape(legend)}</h3><div class="mk-group-settings__body" id="${id}">${html}</div></section>`;
}

const GROUPS_KEY = 'markus:groups';

function readGroups() {
  try {
    return JSON.parse(window.localStorage.getItem(GROUPS_KEY)) || {};
  } catch (err) {
    return {};
  }
}

/**
 * Groups stay as the author left them: a folded group is still folded when the
 * panel opens again. Kept in the browser only, a convenience: without storage
 * every group simply opens.
 */
function rememberGroups(form) {
  const states = readGroups();

  form.querySelectorAll('[data-mk-group]').forEach((section) => {
    const button = section.querySelector('.mk-chevron');
    const fold = (folded) => {
      section.classList.toggle('mk-group-settings--folded', folded);
      button.setAttribute('aria-expanded', String(!folded));
      section.querySelector('.mk-group-settings__body').hidden = folded;
    };

    fold(states[section.dataset.mkGroup] === false);
    button.addEventListener('click', () => {
      const now = readGroups();
      const folded = button.getAttribute('aria-expanded') === 'true';

      fold(folded);
      now[section.dataset.mkGroup] = !folded;

      try {
        window.localStorage.setItem(GROUPS_KEY, JSON.stringify(now));
      } catch (err) {
        // Storage refused: the groups open again next time, nothing else changes.
      }
    });
  });
}

/**
 * The settings of a block, in the charter's side panel (`JoomanjiPanneau`),
 * like Opus: no veil, the article stays in view, every change shows at once.
 * Closing keeps the changes; "Cancel the changes" puts the block back as it
 * was when the panel opened. Enter in a field applies and closes.
 * `apply(values)` is called on each change; `ready(form, panel)` once.
 */
/*
 * THE RED DOT, as in Opus and Corpus (`legend.js` sets `modified`, Opus draws
 * the dot): a field whose value is not the one it had when the panel opened
 * gets `mk-modified`, and so does its group, folded or not. The value counts,
 * not the gesture: a field set back to where it was loses its dot.
 */
function markModified(form, start, modified) {
  const now = values(form);
  const changed = new Set(Object.keys({ ...start, ...now }).filter((k) => String(now[k] ?? '') !== String(start[k] ?? '')));

  form.querySelectorAll('[name]').forEach((c) => {
    const box = c.closest('.mk-field, .mk-check, fieldset') || c.parentNode;

    // A box holds one field; a fieldset of radios holds one name.
    if (c === box.querySelector('[name]')) {
      box.classList.toggle('mk-modified', changed.has(c.name));
    }
  });
  form.querySelectorAll('.mk-group-settings').forEach((g) => {
    g.classList.toggle('mk-modified', !!g.querySelector('.mk-group-settings__body .mk-modified'));
  });

  if (modified) {
    modified(changed.size);
  }
}

/*
 * THE FIELDS BEHIND THE COUNT ON THE GEAR (Cyrille: "frame in violet what
 * makes the 1", then "more discreet"): a field whose setting is away from
 * that of a new block gets `mk-set`; the CSS draws its border, or its chosen
 * radio, in violet, the colour of the count. `set()` gives the names of those
 * fields (settings.js, setFields).
 */
function markSet(form, set) {
  if (!set) {
    return;
  }

  const names = set();

  form.querySelectorAll('[name]').forEach((c) => {
    const box = c.closest('.mk-field, .mk-check, fieldset') || c.parentNode;

    if (c === box.querySelector('[name]')) {
      box.classList.toggle('mk-set', names.has(c.name));
    }
  });
}

export function openPanel({ title, body, ready, apply, cancel, place, actions = '', blockActions = '', modified, closed, set }) {
  // Closed by its cross, Escape or a click beside it, the changes stay, as with "Save".
  const panel = window.JoomanjiPanneau.ouvrir({
    titre: title,
    cle: 'markus',
    // Over Joomla's settings column beside the editor, following it (charter panel v6).
    place,
    fermeture: closed,
    onglets: [{
      titre: title,
      remplir: (zone, panel) => {
        // No "Save": every change applies at once and stays when the panel closes.
        // The one button undoes them all; it comes first, always in view.
        // `actions`: the block's own buttons (Replace the image), before the cancel.
        // `blockActions`: duplicate, hide, remove the block, on the left (Cyrille: the gear alone on the block).
        zone.innerHTML = `<form class="mk-settings"><div class="mk-settings__actions">`
          + `${blockActions ? `<span class="mk-settings__block">${blockActions}</span>` : ''}${actions}`
          + `<button type="button" class="btn btn-sm btn-outline-secondary mk-ibtn mk-ibtn--annuler" data-mk-cancel title="${escape(t('CANCEL_CHANGES_DESC'))}">${escape(t('CANCEL_CHANGES'))}</button></div>${body}</form>`;

        const form = zone.firstElementChild;
        let timer = 0;
        let start = {};
        const send = () => {
          apply(values(form));
          markModified(form, start, modified);
          markSet(form, set);
        };

        form.addEventListener('submit', (e) => {
          e.preventDefault();
          window.clearTimeout(timer);
          send();
          panel.fermer();
        });
        form.querySelector('[data-mk-cancel]').addEventListener('click', () => {
          window.clearTimeout(timer);
          panel.fermer();
          cancel();
        });
        form.addEventListener('change', send);
        form.addEventListener('input', (e) => {
          if (/^(text|number|url|textarea)$/.test(e.target.type)) {
            window.clearTimeout(timer);
            timer = window.setTimeout(send, 300);
          }
        });

        rememberGroups(form);

        if (ready) {
          ready(form, panel);
        }

        start = values(form);
        markSet(form, set);
        // Typing marks at once; the block follows a moment later (send()).
        form.addEventListener('input', () => markModified(form, start, modified));
      },
    }],
  });

  // The width of Joomla's own settings column; its handle widens it when needed.
  return panel;
}

/** Bootstrap's colour names, for borders: the template gives them their shade. */
const COLOURS = ['', 'primary', 'secondary', 'success', 'danger', 'warning', 'info', 'dark', 'light'];

/** The image settings: the text, the link, the size, the look; Bootstrap classes only. */
export function imageForm(o) {
  return group('image-text', t('IMAGE_TEXT'), field('alt', t('IMAGE_ALT'), o.alt, t('IMAGE_ALT_HINT'))
      + check('decorative', t('IMAGE_DECORATIVE'), o.decorative, t('IMAGE_DECORATIVE_HINT'))
      + check('caption', t('IMAGE_CAPTION'), o.caption))
    + group('image-link', t('IMAGE_LINK'), field('href', t('IMAGE_LINK_URL'), o.href, t('IMAGE_LINK_HINT'), 'url')
      + check('blank', t('LINK_NEW_TAB'), o.blank)
      + check('zoom', t('ZOOM'), o.zoom, t('ZOOM_HINT')))
    + group('image-size', t('IMAGE_SIZE'), `<div class="mk-row">${field('width', t('IMAGE_WIDTH'), o.width, '', 'number')}`
      + `${field('height', t('IMAGE_HEIGHT'), o.height, '', 'number')}</div>`
      + check('ratio', t('IMAGE_RATIO'), true)
      + select('fit', t('IMAGE_FIT'), o.fit, [['', t('IMAGE_FIT_NONE')], ['img-fluid', t('IMAGE_FIT_FLUID')],
        ['w-25', '25 %'], ['w-50', '50 %'], ['w-75', '75 %'], ['w-100', '100 %']]))
    + group('image-look', t('IMAGE_LOOK'), radios('align', t('IMAGE_ALIGN'), o.align, [['', t('IMAGE_ALIGN_NONE')],
      ['float-start', t('IMAGE_ALIGN_START')], ['mx-auto d-block', t('IMAGE_ALIGN_CENTER')], ['float-end', t('IMAGE_ALIGN_END')]])
      + select('rounded', t('IMAGE_ROUNDED'), o.rounded, [['', t('IMAGE_ROUNDED_NONE')], ['rounded', t('IMAGE_ROUNDED_SMALL')],
        ['rounded-4', t('IMAGE_ROUNDED_LARGE')], ['rounded-circle', t('IMAGE_ROUNDED_CIRCLE')]])
      + select('border', t('IMAGE_BORDER'), o.border, [['', t('IMAGE_BORDER_SITE')], ['border-0', t('IMAGE_BORDER_NONE')], ['border', t('IMAGE_BORDER_THIN')],
        ['border border-3', t('IMAGE_BORDER_THICK')], ['img-thumbnail', t('IMAGE_BORDER_FRAME')]])
      + select('borderColour', t('IMAGE_BORDER_COLOUR'), o.borderColour, COLOURS.map((c) => [c, t(`COLOUR_${(c || 'template').toUpperCase()}`)]))
      + select('shadow', t('IMAGE_SHADOW'), o.shadow, [['', t('IMAGE_SHADOW_NONE')], ['shadow-sm', t('IMAGE_SHADOW_SMALL')],
        ['shadow', t('IMAGE_SHADOW_MEDIUM')], ['shadow-lg', t('IMAGE_SHADOW_LARGE')]]))
    + group('image-loading', t('IMAGE_LOADING'), check('lazy', t('IMAGE_LAZY'), o.lazy, t('IMAGE_LAZY_HINT')));
}

/** The image's own button, at the top of its panel beside "Cancel the changes". */
export const imageActions = () => `<button type="button" class="btn btn-sm btn-outline-secondary mk-ibtn mk-ibtn--remplacer" data-mk-replace>${escape(t('IMAGE_REPLACE'))}</button>`;

/** The theme colours a table can take, drawn by the site's template (`table-*`, `border-*`). */
export const TABLE_COLOURS = ['primary', 'secondary', 'success', 'danger', 'warning', 'info'];

const SWATCH_TOKENS = {
  primary: '--jmj-primaire', secondary: '--jmj-secondaire', success: '--jmj-succes', danger: '--jmj-danger',
  warning: '--jmj-alerte', info: '--jmj-info', dark: '--jmj-sombre',
};

/** A choice of theme colours as round swatches: radio buttons, "" being the template's own. */
function swatches(name, legend, value, colours) {
  return `<fieldset class="mk-swatch-radios"><legend>${escape(legend)}</legend>${['', ...colours].map((c) => {
    const label = t(`COLOUR_${(c || 'template').toUpperCase()}`);

    return `<label title="${escape(label)}"><input type="radio" name="${name}" value="${c}"${c === value ? ' checked' : ''}>`
      + `<span class="mk-swatch__dot${c ? '' : ' mk-swatch__dot--none'}"${c ? ` style="background-color:var(${SWATCH_TOKENS[c]})"` : ''}`
      + ` aria-hidden="true"></span><span class="visually-hidden">${escape(label)}</span></label>`;
  }).join('')}</fieldset>`;
}

/** The four borders of a table, each drawn in small. */
function borders(value) {
  // The group above already shows "Borders": the legend stays for screen readers only.
  return `<fieldset class="mk-borders"><legend class="visually-hidden">${escape(t('TABLE_BORDERS'))}</legend>${['lines', 'frame', 'grid', 'none'].map((b) => (
    `<label class="mk-border mk-border--${b}"><input type="radio" name="border" value="${b}"${b === value ? ' checked' : ''}>`
    + `<span aria-hidden="true"><i></i><i></i><i></i><i></i></span>${escape(t(`TABLE_BORDER_${b.toUpperCase()}`))}</label>`
  )).join('')}</fieldset>`;
}

/**
 * The table settings, as Opus's tables: the caption, the headers, the
 * borders and their colour, the corners, the backgrounds, the layout, the
 * rows and columns. Bootstrap's table classes only.
 */
export function tableForm(o) {
  return group('table-title', t('TABLE_CAPTION'), field('caption', t('TABLE_CAPTION'), o.caption, t('TABLE_CAPTION_HINT')))
    + group('table-heads', t('TABLE_HEADS'), check('headRow', t('TABLE_HEAD_ROW'), o.headRow)
      + check('headCol', t('TABLE_HEAD_COL'), o.headCol)
      + check('footRow', t('TABLE_FOOT_ROW'), o.footRow, t('TABLE_FOOT_ROW_HINT')))
    + group('table-borders', t('TABLE_BORDERS'), borders(o.border)
      + swatches('borderColour', t('IMAGE_BORDER_COLOUR'), o.borderColour, TABLE_COLOURS)
      + radios('shape', t('TABLE_SHAPE'), o.shape, [['square', t('TABLE_SHAPE_SQUARE')], ['round', t('TABLE_SHAPE_ROUND')]]))
    + group('table-backs', t('TABLE_BACKS'), swatches('headBack', t('TABLE_HEAD_BACK'), o.headBack, [...TABLE_COLOURS, 'dark'])
      + swatches('back', t('TABLE_BACK'), o.back, TABLE_COLOURS)
      + check('striped', t('TABLE_STRIPED'), o.striped)
      + check('hover', t('TABLE_HOVER'), o.hover)
      + `<p class="mk-field-hint">${escape(t('TABLE_BACKS_HINT'))}</p>`)
    + group('table-layout', t('TABLE_LAYOUT'), check('small', t('TABLE_SMALL'), o.small))
    + group('table-widths', t('TABLE_WIDTHS'), radios('colMode', t('TABLE_WIDTHS'), o.colMode, [['auto', t('TABLE_WIDTHS_AUTO')],
      ['equal', t('TABLE_WIDTHS_EQUAL')], ['custom', t('TABLE_WIDTHS_CUSTOM')]])
      + `<div data-for="custom">${o.colNames.map((name, i) => field(`w${i}`, `${name} (%)`, o.widths[i] || '', '', 'number')).join('')}`
      + `<p class="mk-field-hint">${escape(t('TABLE_WIDTHS_HINT'))}</p></div>`)
    + group('table-place', t('TABLE_PLACE_TITLE'), radios('placeScope', t('TABLE_PLACE_SCOPE'), 'cell', [['cell', t('TABLE_SCOPE_CELL')],
      ['col', t('TABLE_SCOPE_COL')], ['row', t('TABLE_SCOPE_ROW')], ['table', t('TABLE_SCOPE_TABLE')]])
      + `<p class="mk-buttons" role="group" aria-label="${escape(t('TABLE_PLACE_H'))}">${[['text-start', 'aligner-gauche'], ['text-center', 'centrer'],
        ['text-end', 'aligner-droite']].map(([c, icon]) => (
        `<button type="button" class="btn btn-sm btn-outline-secondary mk-ibtn mk-ibtn--${icon}" data-mk-place="${c}">${escape(t(`ALIGN_${c.slice(5).toUpperCase()}`))}</button>`)).join('')}</p>`
      + `<p class="mk-buttons" role="group" aria-label="${escape(t('TABLE_PLACE_V'))}">${[['align-top', 'en-haut'], ['align-middle', 'au-milieu'],
        ['align-bottom', 'en-bas']].map(([c, icon]) => (
        `<button type="button" class="btn btn-sm btn-outline-secondary mk-ibtn mk-ibtn--${icon}" data-mk-place="${c}">${escape(t(`TABLE_${c.replace('-', '_').toUpperCase()}`))}</button>`)).join('')}</p>`
      + `<p class="mk-field-hint">${escape(t('TABLE_PLACE_HINT'))}</p>`)
    + group('table-cells', t('TABLE_CELLS'), '<p class="mk-buttons">'
      + `<button type="button" class="btn btn-sm btn-outline-secondary mk-ibtn mk-ibtn--ligne-plus" data-mk-op="row">${escape(t('TABLE_ADD_ROW'))}</button>`
      + `<button type="button" class="btn btn-sm btn-outline-secondary mk-ibtn mk-ibtn--colonne-plus" data-mk-op="col">${escape(t('TABLE_ADD_COL'))}</button></p>`
      + '<p class="mk-buttons">'
      + `<button type="button" class="btn btn-sm btn-outline-danger mk-ibtn mk-ibtn--ligne-moins" data-mk-op="-row">${escape(t('TABLE_DEL_ROW'))}</button>`
      + `<button type="button" class="btn btn-sm btn-outline-danger mk-ibtn mk-ibtn--colonne-moins" data-mk-op="-col">${escape(t('TABLE_DEL_COL'))}</button></p>`
      + `<p class="mk-field-hint">${escape(t('TABLE_CELLS_HINT'))}</p>`);
}

/** The column layouts, in twelfths of the Bootstrap grid. */
export const LAYOUTS = ['6-6', '4-8', '8-4', '4-4-4', '3-6-3', '3-3-3-3'];

export function columnsForm(o) {
  // The layouts in a grid of their own, under their title (Cyrille: the title sat in the grid's first cell).
  return group('columns-layout', t('COLUMNS_LAYOUT'), `<fieldset class="mk-layouts"><legend class="visually-hidden">${escape(t('COLUMNS_LAYOUT'))}</legend>`
    + `<div class="mk-layouts__grid">${LAYOUTS.map((l) => {
      const parts = l.split('-');

      return `<label class="mk-layout"><input type="radio" name="layout" value="${l}"${l === o.layout ? ' checked' : ''}>`
        + `<span aria-hidden="true" style="--mk-layout:${parts.map((p) => `${p}fr`).join(' ')}">${'<i></i>'.repeat(parts.length)}</span>`
        + `${escape(t(`COLUMNS_${l.replace(/-/g, '_')}`))}</label>`;
    }).join('')}</div></fieldset>`)
    // The group's title already names the choice: the legend stays for screen readers.
    + group('columns-valign', t('COLUMNS_VALIGN'), radios('valign', t('COLUMNS_VALIGN'), o.valign, [['', t('TABLE_ALIGN_TOP')],
      ['center', t('TABLE_ALIGN_MIDDLE')], ['end', t('TABLE_ALIGN_BOTTOM')]]).replace('<legend>', '<legend class="visually-hidden">'))
    + group('columns-stack', t('COLUMNS_STACK'), radios('stack', t('COLUMNS_STACK'), o.stack, [['sm', t('COLUMNS_STACK_SM')],
      ['md', t('COLUMNS_STACK_MD')], ['lg', t('COLUMNS_STACK_LG')]]).replace('<legend>', '<legend class="visually-hidden">'));
}

/*
 * THE SWISS ARMY KNIFE (Cyrille, 12 October 2026): the inner and outer
 * spacing, the border and its colour, the corners, the background, the
 * gutter of columns, for nearly every block. Bootstrap's spacing and border
 * utilities only, the scale of the template (0 to 5). Compact: a pictogram and
 * a narrow list each; the name is in the title and for screen readers.
 */
const STEPS = ['', '0', '1', '2', '3', '4', '5'];

function tinySelect(name, label, value, options) {
  return `<label class="mk-tf mk-tf--${name}" title="${escape(label)}"><span class="mk-tf__icon" aria-hidden="true"></span>`
    + `<span class="visually-hidden">${escape(label)}</span><select name="${name}">${options.map(([v, text]) => (
      `<option value="${escape(v)}"${v === value ? ' selected' : ''}>${escape(text)}</option>`)).join('')}</select></label>`;
}

/*
 * THE COLOURS OF THE KNIFE: the site's (classes), the last locked hues, and
 * "Other hue" (Cyrille: "add the custom hue colours"), the locked hue of the
 * text colours (colours.js): a slider, the lightness computed so that the
 * text stays readable, light and dark. A hue is written as its colour pair,
 * `light-dark(#light, #dark)`, the radio's value being `css:` and that pair.
 */
function hueSwatch(name, value, checked, label, colour) {
  return `<label title="${escape(label)}"><input type="radio" name="${name}" value="${escape(value)}"${checked ? ' checked' : ''}>`
    + `<span class="mk-swatch__dot" style="background-color:${escape(colour)}" aria-hidden="true"></span>`
    + `<span class="visually-hidden">${escape(label)}</span></label>`;
}

function hueSwatches(name, legend, value, target) {
  const hues = readHues()[target].map((h) => [`css:${pair(h, target)}`, hueName(h, target), shade(h, target).light]);

  // The colour the block already has, when it is none of the last hues.
  if (value.startsWith('css:') && !hues.some(([v]) => v === value)) {
    hues.unshift([value, t('BOX_HUE_NOW'), value.slice(4)]);
  }

  return swatches(name, legend, value, TABLE_COLOURS).replace('</fieldset>', `${hues.map(([v, label, colour]) => hueSwatch(name, v, v === value, label, colour)).join('')}`
    + `<button type="button" class="mk-swatch-other" data-mk-hue="${target}" data-mk-for="${name}" title="${escape(t(target === 'back' ? 'HUE_OTHER_BACK' : 'HUE_OTHER_TEXT'))}">`
    + `<span class="mk-swatch__dot mk-swatch__dot--rainbow" aria-hidden="true"></span>`
    + `<span class="visually-hidden">${escape(t(target === 'back' ? 'HUE_OTHER_BACK' : 'HUE_OTHER_TEXT'))}</span></button></fieldset>`);
}

/** "Other hue": the slider window, then the new hue checked in its row. */
export function wireHues(form) {
  form.querySelectorAll('[data-mk-hue]').forEach((b) => b.addEventListener('click', async () => {
    const target = b.dataset.mkHue;
    const h = await pickHue(target);

    if (h === null) {
      b.focus({ preventScroll: true });

      return;
    }

    keepHue(target, h);

    const value = `css:${pair(h, target)}`;
    let radio = [...form.querySelectorAll(`[name="${b.dataset.mkFor}"]`)].find((r) => r.value === value);

    if (!radio) {
      b.insertAdjacentHTML('beforebegin', hueSwatch(b.dataset.mkFor, value, false, hueName(h, target), shade(h, target).light));
      radio = b.previousElementSibling.querySelector('input');
    }

    radio.checked = true;
    radio.dispatchEvent(new Event('change', { bubbles: true }));
    radio.focus({ preventScroll: true });
  }));
}

/** `kinds`: which settings the block takes (pad, mt, mb, border, radius, back, gutter). */
export function boxForm(o, kinds) {
  const steps = STEPS.map((s) => [s, s === '' ? '-' : s]);
  const has = (k) => kinds.includes(k);
  let html = '';

  html += has('pad') ? tinySelect('boxPad', t('BOX_PAD'), o.pad, steps) : '';
  html += has('mt') ? tinySelect('boxMt', t('BOX_MT'), o.mt, steps) : '';
  html += has('mb') ? tinySelect('boxMb', t('BOX_MB'), o.mb, steps) : '';
  html += has('gutter') ? tinySelect('boxGutter', t('BOX_GUTTER'), o.gutter, steps) : '';
  html += has('border') ? tinySelect('boxBorder', t('BOX_BORDER'), o.border, [['', '-'], ['1', '1'], ['2', '2'], ['3', '3'], ['4', '4'], ['5', '5']]) : '';
  html += has('radius') ? tinySelect('boxRadius', t('BOX_RADIUS'), o.radius, [...steps, ['pill', t('BOX_PILL')]]) : '';
  // The size and weight of the text: Bootstrap's `lead`, `small`, `fs-*`, `fw-*`.
  html += has('fs') ? tinySelect('boxFs', t('BOX_FS'), o.fs, [['', '-'], ['lead', t('BOX_FS_LEAD')], ['small', t('BOX_FS_SMALL')],
    ...[1, 2, 3, 4, 5, 6].map((n) => [`fs-${n}`, String(n)])]) : '';
  html += has('fw') ? tinySelect('boxFw', t('BOX_FW'), o.fw, [['', '-'], ['light', t('BOX_FW_LIGHT')], ['normal', t('BOX_FW_NORMAL')],
    ['semibold', t('BOX_FW_SEMIBOLD')], ['bold', t('BOX_FW_BOLD')]]) : '';
  html += has('lh') ? tinySelect('boxLh', t('BOX_LH'), o.lh, [['', '-'], ['1', t('BOX_LH_1')], ['sm', t('BOX_LH_SM')], ['base', t('BOX_LH_BASE')], ['lg', t('BOX_LH_LG')]]) : '';
  html += has('tt') ? tinySelect('boxTt', t('BOX_TT'), o.tt, [['', '-'], ['uppercase', t('BOX_TT_UPPER')], ['lowercase', t('BOX_TT_LOWER')], ['capitalize', t('BOX_TT_CAPITAL')]]) : '';

  let colours = '';

  colours += has('back') ? hueSwatches('boxBack', t('BOX_BACK'), o.back, 'back') : '';
  colours += has('border') ? hueSwatches('boxBorderColour', t('BOX_BORDER_COLOUR'), o.borderColour, 'text') : '';

  // A class of one's own, as in Opus and Formulus: for the site's own CSS.
  const own = has('cls') ? field('boxClass', t('BOX_CLASS'), o.cls, t('BOX_CLASS_HINT')) : '';
  const anchor = has('anchor') ? field('boxAnchor', t('BOX_ANCHOR'), o.anchor, t('BOX_ANCHOR_HINT')) : '';

  return group('box', t('BOX'), `<div class="mk-box">${html}</div><div class="mk-box-colours">${colours}</div>`
    + `<p class="mk-field-hint">${escape(t('BOX_HINT'))}</p>${own}${anchor}`);
}

/*
 * THE BULLETS OF A LIST (Cyrille: "several kinds of bullets"). Each choice
 * shows its own bullet. The sign is drawn here, the value is what settings.js
 * writes: nothing, `list-style-type`, or Bootstrap's `list-unstyled`.
 */
const BULLETS = [['', '\u2022'], ['circle', '\u25e6'], ['square', '\u25aa'], ['dash', '-'], ['check', '\u2713'], ['arrow', '\u2192'], ['none', '']];

export function bulletsForm(o) {
  return group('list-bullets', t('BULLETS'), `<fieldset class="mk-bullets"><legend class="visually-hidden">${escape(t('BULLETS'))}</legend>`
    + BULLETS.map(([v, sign]) => `<label class="mk-bullet"><input type="radio" name="bullet" value="${v}"${v === o.bullet ? ' checked' : ''}>`
      + `<span class="mk-bullet__sign" aria-hidden="true">${escape(sign)}</span>${escape(t(`BULLET_${(v || 'disc').toUpperCase()}`))}</label>`).join('')
    + '</fieldset>');
}

/*
 * THE BUTTONS: one group per button (its address, its colour, outlined or
 * full, a new tab), then how they stand together (size, place, full width).
 * Bootstrap's `btn` classes only: the template draws them.
 */
const BUTTON_STYLES = ['primary', 'secondary', 'success', 'danger', 'warning', 'info', 'light', 'dark', 'link'];

/*
 * The pictograms offered: none, the 62 of the set, or the author's own SVG
 * (`prefix` names the fields: `b0icon`, `b0svg`... or `icon`, `svg`).
 */
function iconsField(prefix, icon, svg) {
  const name = (n) => (n ? t(`ICON_${n.replace(/-/g, '_').toUpperCase()}`) : t('BUTTON_ICON_NONE'));

  return `<fieldset class="mk-icons"><legend>${escape(t('BUTTON_ICON'))}</legend>`
    + ['', ...Object.keys(ICONS), 'own'].map((n) => `<label title="${escape(n === 'own' ? t('ICON_OWN') : name(n))}">`
      + `<input type="radio" name="${prefix}icon" value="${n}"${n === icon ? ' checked' : ''}>`
      + `<span aria-hidden="true">${n === '' ? '\u2205' : (n === 'own' ? '&lt;/&gt;' : iconSvg(n))}</span>`
      + `<span class="visually-hidden">${escape(n === 'own' ? t('ICON_OWN') : name(n))}</span></label>`).join('')
    + '</fieldset>'
    + `<div data-mk-own="${prefix}"><label class="mk-field"><span>${escape(t('BUTTON_ICON_SVG'))}</span><textarea name="${prefix}svg" rows="3" spellcheck="false">${escape(svg)}</textarea>`
    + `<small>${escape(t('BUTTON_ICON_SVG_HINT'))}</small></label></div>`;
}

/** The pasted SVG shows only for "my own". */
export function wireOwnIcons(form) {
  form.querySelectorAll('[data-mk-own]').forEach((box) => {
    const name = `${box.dataset.mkOwn}icon`;
    const show = () => { box.hidden = (form.querySelector(`[name="${name}"]:checked`) || {}).value !== 'own'; };

    form.querySelectorAll(`[name="${name}"]`).forEach((r) => r.addEventListener('change', show));
    show();
  });
}

export function buttonsForm(o) {
  const styles = BUTTON_STYLES.map((c) => [c, t(`BUTTON_STYLE_${c.toUpperCase()}`)]);

  // A page of the site, chosen in Joomla's own windows (the editor's buttons present on this site).
  const pages = (i) => (o.pages.length ? `<p class="mk-buttons" role="group" aria-label="${escape(t('BUTTON_PAGE'))}">${o.pages.map((p) => (
    `<button type="button" class="btn btn-sm btn-outline-secondary" data-mk-pick="${escape(p)}" data-mk-for="b${i}href">${escape(t(`BUTTON_PAGE_${p.toUpperCase()}`))}</button>`)).join('')}</p>` : '');
  const icons = (i, b) => iconsField(`b${i}`, b.icon, b.svg)
    + radios(`b${i}iconAt`, t('BUTTON_ICON_AT'), b.iconAt, [['', t('BUTTON_ICON_BEFORE')], ['after', t('BUTTON_ICON_AFTER')]]);

  return (o.corpus ? `<p class="form-text">${escape(t('BUTTON_CORPUS_HINT'))}</p>` : '')
    + o.buttons.map((b, i) => group(`button-${i}`, t('BUTTON_N', i + 1, b.text || t('BUTTON_PLACEHOLDER')),
      field(`b${i}href`, t('LINK_URL'), b.href, t('BUTTON_URL_HINT'), 'text')
      + pages(i)
      + select(`b${i}style`, t('BUTTON_STYLE'), b.style, styles)
      + check(`b${i}outline`, t('BUTTON_OUTLINE'), b.outline)
      + check(`b${i}blank`, t('LINK_NEW_TAB'), b.blank, t('LINK_NEW_TAB_HINT'))
      + icons(i, b)
      + (o.buttons.length > 1 ? `<p class="mk-buttons"><button type="button" class="btn btn-sm btn-outline-danger" data-mk-button-remove="${i}">${escape(t('BUTTON_REMOVE'))}</button></p>` : '')))
    .join('')
    + `<p class="mk-buttons"><button type="button" class="btn btn-sm btn-outline-success" data-mk-button-add>${escape(t('BUTTON_ADD'))}</button></p>`
    + group('buttons-layout', t('BUTTONS_LAYOUT'), radios('size', t('BUTTON_SIZE'), o.size,
      [['sm', t('BUTTON_SIZE_SM')], ['', t('BUTTON_SIZE_MD')], ['lg', t('BUTTON_SIZE_LG')]])
      + radios('place', t('BUTTON_PLACE'), o.place, [['', t('ALIGN_START')], ['center', t('ALIGN_CENTER')], ['end', t('ALIGN_END')]])
      + check('wide', t('BUTTON_WIDE'), o.wide));
}

/*
 * THE CALLOUT, Corpus's own: the alert zone (four natures, their pictogram,
 * their written title) or the panel put forward (a heading, a pictogram of
 * one's choice beside, above or under it, and its text). Both may be
 * aligned left, centred or right.
 */
export function calloutForm(o) {
  return group('callout-look', t('CALLOUT_LOOK'), radios('kind', t('CALLOUT_KIND'), o.kind, [['message', t('CALLOUT_KIND_MESSAGE')], ['panel', t('CALLOUT_KIND_PANEL')]])
    + `<div data-for="message">${radios('nature', t('CALLOUT_NATURE'), o.nature, ['info', 'succes', 'alerte', 'erreur'].map((n) => [n, t(`CALLOUT_${n.toUpperCase()}`)]))}</div>`
    + `<div data-for="panel">${select('level', t('CALLOUT_LEVEL'), o.level, [['2', t('TYPE_H2')], ['3', t('TYPE_H3')], ['4', t('TYPE_H4')]])}</div>`
    + check('titled', t('CALLOUT_TITLE'), o.titled, t('CALLOUT_TITLE_HINT'))
    + radios('align', t('CALLOUT_ALIGN'), o.align, [['', t('ALIGN_START')], ['center', t('ALIGN_CENTER')], ['end', t('ALIGN_END')]]))
    + `<div data-for="panel">${group('callout-icon', t('CALLOUT_ICON'), `<p class="form-text">${escape(t('CALLOUT_ICON_HINT'))}</p>`
      + iconsField('', o.icon, o.svg)
      + radios('iconAt', t('BUTTON_ICON_AT'), o.iconAt, [['', t('CALLOUT_ICON_LEFT')], ['right', t('CALLOUT_ICON_RIGHT')],
        ['above', t('CALLOUT_ICON_ABOVE')], ['under', t('CALLOUT_ICON_UNDER')]]))}</div>`;
}

/** A numbered list: where it starts, backwards, the kind of numbers (HTML's own attributes). */
export function listForm(o) {
  return field('start', t('LIST_START'), o.start, t('LIST_START_HINT'), 'number')
    + check('reversed', t('LIST_REVERSED'), o.reversed)
    + radios('kind', t('LIST_KIND'), o.kind, [['', '1, 2, 3'], ['a', 'a, b, c'], ['A', 'A, B, C'], ['i', 'i, ii, iii'], ['I', 'I, II, III']]);
}

/** A quote: who said it and where (Bootstrap's `blockquote-footer`, with <cite> for the work). */
export function quoteForm(o) {
  return field('author', t('QUOTE_AUTHOR'), o.author, t('QUOTE_AUTHOR_HINT'))
    + field('work', t('QUOTE_WORK'), o.work, t('QUOTE_WORK_HINT'))
    + field('url', t('QUOTE_URL'), o.url, t('QUOTE_URL_HINT'), 'url');
}

/** The code settings: the language, saved as `language-xxx` on <code>. */
export function codeForm(o) {
  return field('language', t('CODE_LANGUAGE'), o.language, t('CODE_LANGUAGE_HINT'));
}
