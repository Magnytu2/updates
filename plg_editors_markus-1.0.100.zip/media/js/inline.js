/**
 * Markus Editor: marks inside a sentence that are not a look: the language
 * of a passage (`<span lang="en">`, RGAA criterion 8.7, so a screen reader
 * pronounces it right), exponent and index (`<sup>`, `<sub>`).
 *
 * The language is set text by text, like the colours: a selection over two
 * list items gets two marked pieces, the list stays as it was.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

import { selectedTexts, isolate, mergeTwins } from 'plg_editors_markus.colours';

/** The language marked around the start of the range, or "". */
export function langAt(range, host) {
  const n = range.startContainer;
  const el = (n.nodeType === Node.ELEMENT_NODE ? n : n.parentNode).closest('[lang]');

  return el && host.contains(el) && el !== host ? el.getAttribute('lang') : '';
}

/**
 * Marks the selection as written in `lang` (a code such as "en" or
 * "pt-BR"), or takes the mark away when `lang` is "". Returns the number of
 * texts marked or unmarked.
 */
export function setLang(range, host, lang) {
  const texts = selectedTexts(range, host);

  texts.forEach((text) => {
    const marked = [];

    for (let el = text.parentNode; el !== host; el = el.parentNode) {
      if (el.tagName === 'SPAN' && el.hasAttribute('lang')) {
        marked.push(el);
      }
    }

    marked.forEach((el) => {
      isolate(el, text);
      el.removeAttribute('lang');

      if (!el.attributes.length) {
        el.replaceWith(...el.childNodes);
      }
    });

    if (lang) {
      const wrap = document.createElement('span');

      wrap.setAttribute('lang', lang);
      text.before(wrap);
      wrap.appendChild(text);
    }
  });

  mergeTwins(host);

  if (texts.length) {
    range.setStart(texts[0], 0);
    range.setEnd(texts[texts.length - 1], texts[texts.length - 1].length);
  }

  return texts.length;
}

/**
 * Puts the selection in a mark of its own (`s` struck through, `code` a bit
 * of code, `kbd` a key of the keyboard), or takes the mark away when the
 * whole selection already has it. Text by text, as the language. Returns the
 * number of texts changed.
 */
export function toggleTag(range, host, tag) {
  const name = tag.toUpperCase();
  const texts = selectedTexts(range, host);
  const around = (text) => {
    for (let el = text.parentNode; el && el !== host; el = el.parentNode) {
      if (el.tagName === name) {
        return el;
      }
    }

    return null;
  };
  const all = texts.length && texts.every(around);

  texts.forEach((text) => {
    const el = around(text);

    if (all) {
      const part = isolate(el, text);

      part.replaceWith(...part.childNodes);
    } else if (!el) {
      const wrap = document.createElement(tag);

      text.before(wrap);
      wrap.appendChild(text);
    }
  });

  // Two marks side by side become one: <s>a</s><s>b</s> is <s>ab</s>.
  [...host.querySelectorAll(tag)].reverse().forEach((el) => {
    const next = el.nextSibling;

    if (next && next.nodeType === Node.ELEMENT_NODE && next.tagName === name && !el.attributes.length && !next.attributes.length) {
      el.append(...next.childNodes);
      next.remove();
    }
  });

  if (texts.length) {
    range.setStart(texts[0], 0);
    range.setEnd(texts[texts.length - 1], texts[texts.length - 1].length);
  }

  return texts.length;
}
