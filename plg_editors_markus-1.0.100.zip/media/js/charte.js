/*
 * LA CHARTE JOOMANJI DANS MARKUS EDITOR.
 *
 * FICHIER ECRIT EN ENTIER PAR `_charte/charte.py` : n'y rien ecrire a la
 * main. Une amelioration se fait dans `_charte/composants`, puis
 * `python3 _charte/charte.py recopier markus-editeur`. La livraison refuse un fichier
 * qui diverge (`charte.py verifier markus-editeur`).
 *
 * Composants : jetons v6, fenetre v4, panneau v8, site v5, carte v2.
 */

// >>> CHARTE JOOMANJI : fenetre v4 (ne pas modifier ici : _charte/composants) >>>
/*
 * LA FENETRE DE CONFIRMATION. Charte Joomanji, composant « fenetre », v4,
 * 9 octobre 2026.
 *
 *   window.JoomanjiFenetre.demander({
 *     titre: 'Remplacer la mise en page',
 *     texte: 'Tout le montage actuel sera remplace.',   // echappe ici ; ligne vide = paragraphe
 *     ton: 'danger',                                    // 'alerte' (v2), ou rien
 *     bouton: 'Remplacer'                               // le nom du bouton de confirmation
 *   }).then(function (oui) { ... });
 *
 * Rend une promesse : vrai si l'on a confirme, faux sinon.
 *
 *   window.JoomanjiFenetre.saisir({
 *     titre: 'Nouveau dossier',
 *     corps: '<label ...>Nom</label><input name="nom" ...>',  // HTML du produit, deja echappe
 *     pret: function (corps) { ... },                          // appele une fois la fenetre ouverte
 *     ton: 'danger', bouton: 'Creer'                           // comme demander()
 *   }).then(function (valeurs) { ... });
 *
 * La meme fenetre, avec des champs : rend les valeurs des champs nommes du
 * corps (`{ nom: '...' }`, case a cocher en vrai ou faux, bouton radio
 * choisi), ou `null` si l'on a annule. Le focus va au premier champ.
 *
 * « Une fenetre a nous », ni `confirm()` du navigateur (« 127.0.0.1
 * indique »), ni `JoomlaDialog`. Un `dialog` natif ouvert par `showModal()` :
 * fond inerte, Echap, focus rendu a la fermeture. Il est cree au premier
 * appel, sous `body`, et resservi ensuite.
 *
 * Textes : `JCANCEL` et `JCLOSE` (clefs du coeur), `JMJ_FENETRE_VALIDER` et
 * `JMJ_FENETRE_DEFINITIF` (clefs de la charte, dans les fichiers de langue
 * de chaque produit). Les quatre passent par `Text::script`.
 *
 * PIEGES DEJA PAYES (Iris, Opus, Formulus) :
 * - la reponse se lit a l'ENVOI (le bouton presse) et Echap a `cancel`, qui
 *   part tout de suite ; `close` ne vient qu'en dernier recours : Chrome le
 *   retient dans un onglet qui n'a pas le premier plan ;
 * - un drapeau `fini` evite de repondre deux fois ;
 * - deux questions rapprochees attendent leur tour (file), aucune ne
 *   repond a la place de l'autre ;
 * - l'aspect se remet a chaque ouverture : un evenement en retard ne doit pas
 *   repeindre la question suivante ;
 * - en ton danger, le focus est sur Annuler : un Entree distrait ne detruit rien ;
 * - aucun nom global hors de `window.JoomanjiFenetre`.
 */
(function () {
  'use strict';

  /*
   * v4 : LA PLUS RECENTE GAGNE, comme le panneau. Plusieurs produits
   * chargent leur copie sur la meme page ; une copie plus ancienne chargee
   * avant ne doit pas garder la main (elle faisait defiler l'article).
   */
  var VERSION = 4;

  if (window.JoomanjiFenetre && (window.JoomanjiFenetre.version || 0) >= VERSION) {
    return;
  }

  var dialogue = null;
  var file = Promise.resolve();
  var SVG = {
    croix: 'M6.4 4.9 12 10.5l5.6-5.6 1.5 1.5L13.5 12l5.6 5.6-1.5 1.5L12 13.5l-5.6 5.6-1.5-1.5L10.5 12 4.9 6.4z',
    alerte: 'M12 2 1 21h22L12 2Zm0 4 7.5 13h-15L12 6Zm1 11h-2v-2h2v2Zm0-3h-2v-4h2v4Z'
  };

  function mot(cle, defaut) {
    if (window.Joomla && Joomla.Text && Joomla.Text._) {
      var t = Joomla.Text._(cle);
      if (t && t !== cle) { return t; }
    }

    return defaut;
  }

  function echap(t) {
    return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function icone(nom) {
    return '<svg class="jmj-fenetre__i" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="' + SVG[nom] + '"/></svg>';
  }

  function creer() {
    // v4 : la fenetre d'une copie plus ancienne, si elle en a deja pose une, s'en va.
    var vieille = document.getElementById('jmj-fenetre');

    if (vieille) { vieille.remove(); }

    var d = document.createElement('dialog');
    var fermer = echap(mot('JCLOSE', 'Fermer'));

    d.className = 'jmj-fenetre';
    d.id = 'jmj-fenetre';
    d.setAttribute('aria-labelledby', 'jmj-fenetre-titre');
    d.setAttribute('aria-describedby', 'jmj-fenetre-corps');
    // Valider EN PREMIER dans le code : Entree declenche le premier bouton
    // d'envoi. La croix est la derniere, pour la meme raison.
    d.innerHTML = '<form method="dialog">' +
      '<h3 id="jmj-fenetre-titre"></h3>' +
      '<div id="jmj-fenetre-corps"></div>' +
      '<div class="jmj-fenetre__pied">' +
        '<button type="submit" class="btn btn-primary" value="ok" id="jmj-fenetre-ok"></button>' +
        '<button type="submit" class="btn btn-secondary" value="annuler">' + echap(mot('JCANCEL', 'Annuler')) + '</button>' +
      '</div>' +
      '<button type="submit" class="jmj-fenetre__croix" value="annuler" aria-label="' + fermer + '" title="' + fermer + '">' + icone('croix') + '</button>' +
      '</form>';
    document.body.appendChild(d);

    return d;
  }

  function ouvrir(q, saisie) {
    dialogue = dialogue || creer();

    // Sans `dialog` (navigateur ancien) : la question du navigateur, moins
    // belle, mais personne ne perd rien sans le savoir.
    if (typeof dialogue.showModal !== 'function') {
      return Promise.resolve(saisie ? null : window.confirm(q.texte || q.titre || ''));
    }

    return new Promise(function (resoudre) {
      var dlg = dialogue;
      var danger = q.ton === 'danger';
      // v2 : le ton « alerte », orange, pour un choix qui se rattrape.
      var alerte = q.ton === 'alerte';
      var bOk = dlg.querySelector('#jmj-fenetre-ok');
      var h = dlg.querySelector('#jmj-fenetre-titre');
      var forme = dlg.querySelector('form');
      var fini = false;

      h.textContent = q.titre || '';
      var corps = dlg.querySelector('#jmj-fenetre-corps');
      var retour = document.activeElement;

      // `corps` : du HTML fourni par le produit (saisir). Sinon `texte`, un
      // paragraphe par bloc separe d'une ligne vide, echappe : il peut porter
      // des noms saisis.
      corps.innerHTML = q.corps != null ? q.corps : String(q.texte || '').split(/\n{2,}/)
        .filter(function (bout) { return bout !== ''; })
        .map(function (bout) { return '<p>' + echap(bout) + '</p>'; }).join('');
      dlg.classList.toggle('jmj-fenetre--danger', danger);
      dlg.classList.toggle('jmj-fenetre--alerte', alerte);
      // v3 : le bouton ordinaire prend l'accent du trait (fenetre.css).
      bOk.className = 'btn ' + (danger ? 'btn-danger' : alerte ? 'btn-warning' : 'btn-primary jmj-fenetre__valider');
      bOk.textContent = q.bouton || mot('JMJ_FENETRE_VALIDER', 'Valider');

      if (alerte) {
        h.insertAdjacentHTML('afterbegin', icone('alerte'));
      }

      if (danger) {
        h.insertAdjacentHTML('afterbegin', icone('alerte'));
        h.insertAdjacentHTML('beforeend', '<span class="jmj-fenetre__definitif">' + echap(mot('JMJ_FENETRE_DEFINITIF', 'Action définitive')) + '</span>');
      }

      function envoi(e) { fin(e.submitter ? e.submitter.value : ''); }
      function annulation() { fin(''); }
      function fermeture() { fin(dlg.returnValue); }
      function fin(reponse) {
        if (fini) { return; }
        fini = true;
        dlg.removeEventListener('close', fermeture);
        dlg.removeEventListener('cancel', annulation);
        forme.removeEventListener('submit', envoi);
        if (dlg.open && reponse !== 'ok') { dlg.close(); }
        if (retour && retour.focus && document.contains(retour)) { retour.focus({ preventScroll: true }); }

        if (!saisie) {
          resoudre(reponse === 'ok');

          return;
        }

        var valeurs = {};

        [].slice.call(corps.querySelectorAll('[name]')).forEach(function (c) {
          if (c.type === 'radio' && !c.checked) { return; }
          valeurs[c.name] = c.type === 'checkbox' ? c.checked : c.value;
        });
        resoudre(reponse === 'ok' ? valeurs : null);
      }

      dlg.addEventListener('close', fermeture);
      dlg.addEventListener('cancel', annulation);
      forme.addEventListener('submit', envoi);
      dlg.returnValue = '';
      dlg.showModal();

      // En ton danger, le focus sur Annuler ; sinon le premier champ, puis Valider.
      var premier = danger ? dlg.querySelector('.jmj-fenetre__pied [value=annuler]')
        : (corps.querySelector('input:not([type=hidden]), select, textarea') || bOk);

      premier.focus({ preventScroll: true });
      if (premier.select && premier.tagName === 'INPUT') { premier.select(); }
      if (typeof q.pret === 'function') { q.pret(corps); }
    });
  }

  function enFile(q, saisie) {
    var question = file.then(function () { return ouvrir(q || {}, saisie); });

    file = question.catch(function () {});

    return question;
  }

  function demander(q) { return enFile(q, false); }
  function saisir(q) { return enFile(q, true); }

  window.JoomanjiFenetre = { version: VERSION, demander: demander, saisir: saisir };
})();
// <<< CHARTE JOOMANJI : fenetre <<<

// >>> CHARTE JOOMANJI : panneau v8 (ne pas modifier ici : _charte/composants) >>>
/*
 * LE PANNEAU LATERAL. Charte Joomanji, composant « panneau », v8,
 * 12 octobre 2026.
 *
 *   var p = window.JoomanjiPanneau.ouvrir({
 *     titre: 'Poser un bloc Opus',
 *     onglets: [
 *       { titre: 'Mise en page', remplir: function (corps, p) { ... } },
 *       { titre: 'Element', remplir: function (corps, p) { ... } }
 *     ],
 *     pied: 'Un clic ouvre le module, pret a modifier.',   // texte, echappe ici
 *     fermeture: function () { ... }                      // facultatif
 *   });
 *
 *   p.fermer();          // ferme et rend le focus a ce qui l'avait ouvert
 *   p.large(true);       // s'elargit (un rendu a la largeur d'un article)
 *   p.large('812px');    // v2 : a une largeur donnee, jamais plus que l'ecran
 *   p.choisir(1);        // passe au deuxieme onglet
 *
 * v5 (11 octobre 2026, demande de Cyrille dans Markus : « elargir le popup
 * sur la gauche ») : une POIGNEE sur le bord gauche. On la tire a la souris,
 * ou, au clavier, fleche gauche pour elargir, fleche droite pour retrecir,
 * Debut et Fin pour le plus etroit et le plus large. La largeur choisie
 * passe devant `large()` et se retient : `cle: 'markus'` dans les options
 * la garde d'une page a l'autre (stockage du navigateur), sans `cle`
 * jusqu'a la fin de la page. Texte : `JMJ_PANNEAU_LARGEUR`, dans les
 * fichiers de langue du produit.
 *   p.corps              // la zone de l'onglet ouvert (neuve a chaque onglet)
 *
 * v6 (12 October 2026, Cyrille in Markus: "it must take the place of
 * Joomla's settings"): `place: element` in the options. The panel then sits
 * exactly over that element (Joomla's settings column beside the editor):
 * same left edge, same width, followed live when the page moves (Astus
 * opening, a window resized), never glued over another panel docked on the
 * right. The handle still widens it to the left; that extra width lasts
 * until the panel closes, nothing is stored.
 *
 * v7 (12 October 2026, Cyrille: "J'ai un decalage a droite du panneau"):
 * placed, the panel keeps the element's left edge but runs to the right
 * edge of the window, as a docked panel does, and sits under a panel that
 * unfolds on the right over the page (Astus): `--jmj-plan-place`.
 *
 * v8 (12 October 2026, Cyrille: the article must never scroll when a
 * window opens or closes): the focus given or given back no longer scrolls
 * the page.
 *
 * Un onglet est REMPLI A CHAQUE FOIS qu'on l'ouvre : le produit y relit ses
 * donnees, rien ne reste perime d'une ouverture a l'autre.
 *
 * NON MODAL, ET C'EST VOULU (maquette validee par Cyrille le 10 octobre
 * 2026) : pas de voile, l'article reste visible et l'editeur garde son
 * curseur. Le panneau se ferme par sa croix, par Echap, ou par un clic a
 * cote. Un clic dans une fenetre ouverte au-dessus de lui (un `dialog`
 * natif, la grande fenetre de Joomla) ne le ferme pas.
 *
 * Un seul panneau a la fois : en ouvrir un ferme le precedent.
 *
 * Texte : `JCLOSE` (clef du coeur), par `Text::script`.
 */
(function () {
  'use strict';

  /*
   * v5 : LA PLUS RECENTE GAGNE. Plusieurs produits chargent ce composant sur
   * la meme page (Opus, Formulus, Iris, Markus sous l'editeur d'article) ;
   * avant, le premier charge gagnait, meme ancien : la poignee de la v5 ne
   * sortait pas dans Markus tant qu'Opus avait sa v4 (banc 8130, 11 octobre
   * 2026). Un panneau deja OUVERT garde le sien jusqu'a sa fermeture.
   */
  var VERSION = 6;

  if (window.JoomanjiPanneau && (window.JoomanjiPanneau.version || 0) >= VERSION) { return; }

  var courant = null;
  var compteur = 0;

  // v5 : les largeurs choisies a la poignee, par cle de produit.
  var largeurs = {};

  function lireLargeur(cle) {
    if (largeurs[cle]) { return largeurs[cle]; }
    try { return parseInt(window.localStorage.getItem('jmj-panneau:' + cle), 10) || 0; } catch (e) { return 0; }
  }

  function retenirLargeur(cle, px) {
    largeurs[cle] = px;
    try { window.localStorage.setItem('jmj-panneau:' + cle, String(px)); } catch (e) { /* stockage refuse : la page suffit */ }
  }

  function mot(cle, defaut) {
    if (window.Joomla && Joomla.Text && Joomla.Text._) {
      var t = Joomla.Text._(cle);
      if (t && t !== cle) { return t; }
    }

    return defaut;
  }

  function ouvrir(options) {
    if (courant) { courant.fermer(); }

    var n = ++compteur;
    var avant = document.activeElement;
    var onglets = options.onglets || [];
    var choisi = -1;

    var el = document.createElement('div');
    el.className = options.place ? 'jmj-panneau jmj-panneau--place' : 'jmj-panneau';
    el.setAttribute('role', 'dialog');
    el.setAttribute('aria-modal', 'false');
    el.setAttribute('aria-labelledby', 'jmj-panneau-titre-' + n);

    var tete = document.createElement('div');
    tete.className = 'jmj-panneau__tete';

    var h = document.createElement('h2');
    h.id = 'jmj-panneau-titre-' + n;
    h.textContent = options.titre || '';

    var croix = document.createElement('button');
    croix.type = 'button';
    croix.className = 'jmj-panneau__croix';
    croix.setAttribute('aria-label', mot('JCLOSE', 'Fermer'));

    tete.appendChild(h);
    tete.appendChild(croix);
    el.appendChild(tete);

    /*
     * v5 : LA POIGNEE DE LARGEUR, sur le bord gauche. Un vrai separateur
     * ARIA (`role="separator"`, valeur en pixels), atteignable au clavier.
     * La capture du pointeur garde le glisser meme au-dessus de l'iframe de
     * TinyMCE, qui sinon avalait le mouvement.
     */
    var cle = options.cle || '';
    var poignee = document.createElement('div');
    poignee.className = 'jmj-panneau__poignee';
    poignee.setAttribute('role', 'separator');
    poignee.setAttribute('aria-orientation', 'vertical');
    poignee.setAttribute('aria-label', mot('JMJ_PANNEAU_LARGEUR', 'Largeur du panneau'));
    poignee.tabIndex = 0;
    el.appendChild(poignee);

    function rem() { return parseFloat(window.getComputedStyle(document.documentElement).fontSize) || 16; }

    /*
     * v6 : THE PLACE OF AN ELEMENT. `ajout` is what the handle added to the
     * element's width. Read again at each move: the element is the measure,
     * never a number kept from before.
     */
    var place = options.place && options.place.getBoundingClientRect ? options.place : null;
    var ajout = 0;
    var suivi = null;

    function suivre() {
      var gauche = Math.max(0, place.getBoundingClientRect().left - ajout);
      var largeur = document.documentElement.clientWidth - gauche;

      el.style.insetInlineEnd = 'auto';
      el.style.left = gauche + 'px';
      el.style.width = largeur + 'px';
      // The border counts or not depending on the page's box model: measured, then corrected.
      el.style.width = (2 * largeur - el.getBoundingClientRect().width) + 'px';
      poignee.setAttribute('aria-valuenow', String(Math.round(largeur)));
    }

    function poserLargeur(px, retenir) {
      if (place) {
        ajout = Math.max(0, Math.round(px - (document.documentElement.clientWidth - place.getBoundingClientRect().left)));
        suivre();

        return;
      }

      var min = Math.round(20 * rem());
      var max = window.innerWidth;
      var l = Math.max(min, Math.min(max, Math.round(px)));

      el.style.width = l + 'px';
      poignee.setAttribute('aria-valuemin', String(min));
      poignee.setAttribute('aria-valuemax', String(max));
      poignee.setAttribute('aria-valuenow', String(l));
      if (retenir) { retenirLargeur(cle || '*', l); }
    }

    poignee.addEventListener('pointerdown', function (e) {
      if (e.button !== 0) { return; }
      e.preventDefault();
      poignee.setPointerCapture(e.pointerId);
      el.classList.add('jmj-panneau--etire');
    });

    poignee.addEventListener('pointermove', function (e) {
      if (!poignee.hasPointerCapture || !poignee.hasPointerCapture(e.pointerId)) { return; }
      // Le panneau est colle a droite : sa largeur est ce qui reste a droite du pointeur.
      poserLargeur(window.innerWidth - e.clientX, false);
    });

    function lacher(e) {
      if (poignee.hasPointerCapture && poignee.hasPointerCapture(e.pointerId)) { poignee.releasePointerCapture(e.pointerId); }
      el.classList.remove('jmj-panneau--etire');
      poserLargeur(el.getBoundingClientRect().width, true);
    }

    poignee.addEventListener('pointerup', lacher);
    poignee.addEventListener('pointercancel', lacher);

    poignee.addEventListener('keydown', function (e) {
      var l = el.getBoundingClientRect().width;
      var pas = e.shiftKey ? 8 * rem() : 2 * rem();

      if (e.key === 'ArrowLeft') { poserLargeur(l + pas, true); }
      else if (e.key === 'ArrowRight') { poserLargeur(l - pas, true); }
      else if (e.key === 'Home') { poserLargeur(0, true); }
      else if (e.key === 'End') { poserLargeur(window.innerWidth, true); }
      else { return; }

      e.preventDefault();
    });

    var liste = document.createElement('div');
    liste.className = 'jmj-panneau__onglets';
    liste.setAttribute('role', 'tablist');

    var corps = document.createElement('div');
    corps.className = 'jmj-panneau__corps';
    corps.id = 'jmj-panneau-corps-' + n;
    corps.setAttribute('role', onglets.length > 1 ? 'tabpanel' : 'region');
    corps.tabIndex = 0;

    var boutons = onglets.map(function (o, i) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'jmj-panneau__onglet';
      b.id = 'jmj-panneau-onglet-' + n + '-' + i;
      b.setAttribute('role', 'tab');
      b.setAttribute('aria-controls', corps.id);
      b.textContent = o.titre;
      b.addEventListener('click', function () { choisir(i); });
      liste.appendChild(b);

      return b;
    });

    liste.addEventListener('keydown', function (e) {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') { return; }

      e.preventDefault();
      var i = (choisi + (e.key === 'ArrowRight' ? 1 : -1) + boutons.length) % boutons.length;
      choisir(i);
      boutons[i].focus();
    });

    if (onglets.length > 1) { el.appendChild(liste); }

    el.appendChild(corps);

    var pied = document.createElement('div');
    pied.className = 'jmj-panneau__pied';
    pied.textContent = options.pied || '';
    el.appendChild(pied);

    var p = {
      element: el,
      corps: corps,
      fermer: fermer,
      choisir: choisir,
      large: function (oui) {
        el.classList.toggle('jmj-panneau--large', !!oui);
        el.style.width = typeof oui === 'string' ? oui : '';
      },
      pied: function (t) { pied.textContent = t || ''; }
    };

    function choisir(i) {
      if (!onglets[i]) { return; }

      choisi = i;
      boutons.forEach(function (b, j) {
        b.setAttribute('aria-selected', j === i ? 'true' : 'false');
        b.tabIndex = j === i ? 0 : -1;
      });

      if (boutons[i]) { corps.setAttribute('aria-labelledby', boutons[i].id); }

      /*
       * UNE ZONE NEUVE A CHAQUE ONGLET : le produit y pose ses ecouteurs
       * sans se soucier de ceux de l'onglet d'avant, partis avec elle.
       */
      var zone = document.createElement('div');
      el.classList.remove('jmj-panneau--large');
      el.style.width = '';
      corps.textContent = '';
      corps.appendChild(zone);
      corps.scrollTop = 0;
      p.corps = zone;
      onglets[i].remplir(zone, p);

      // v5 : la largeur choisie a la poignee passe devant celle du produit
      // (v6 : sauf a la place d'un element, qui donne la sienne).
      var retenue = place ? 0 : lireLargeur(cle || '*');
      if (retenue) { poserLargeur(retenue, false); }
      if (place) { suivre(); }
    }

    /*
     * UN CLIC A COTE FERME, mais pas n'importe ou. Une fenetre ouverte
     * par-dessus (le `dialog` de la grande fenetre, celui de la charte) est
     * dans la couche du haut : un clic dedans n'est pas un clic a cote. On
     * ecoute `pointerdown` et non `click` : un glisser commence dans le
     * panneau et lache dehors ne doit pas le fermer.
     */
    function dehors(e) {
      if (el.contains(e.target)) { return; }
      if (e.target.closest && e.target.closest('dialog, joomla-dialog, .jmj-fenetre')) { return; }
      if (document.querySelector('dialog[open], joomla-dialog[open]')) { return; }

      fermer();
    }

    function touche(e) {
      if (e.key !== 'Escape' || e.defaultPrevented) { return; }
      if (document.querySelector('dialog[open], joomla-dialog[open]')) { return; }

      e.preventDefault();
      fermer();
    }

    function fermer() {
      if (courant !== p) { return; }

      courant = null;
      if (suivi) { suivi.disconnect(); }
      window.removeEventListener('resize', suivreFenetre);
      document.removeEventListener('pointerdown', dehors, true);
      document.removeEventListener('keydown', touche);
      el.remove();

      if (avant && avant.focus && document.contains(avant)) { avant.focus({ preventScroll: true }); }
      if (options.fermeture) { options.fermeture(); }
    }

    function suivreFenetre() { if (place) { suivre(); } }

    croix.addEventListener('click', fermer);
    document.body.appendChild(el);

    if (place) {
      suivi = new ResizeObserver(suivre);
      suivi.observe(place);
      window.addEventListener('resize', suivreFenetre);
    }
    courant = p;

    // Le clic qui a ouvert le panneau est encore en cours : on n'ecoute
    // les clics a cote qu'au tour suivant.
    window.setTimeout(function () {
      if (courant === p) { document.addEventListener('pointerdown', dehors, true); }
    }, 0);
    document.addEventListener('keydown', touche);

    choisir(0);
    (boutons[0] || corps).focus({ preventScroll: true });

    return p;
  }

  window.JoomanjiPanneau = { ouvrir: ouvrir, version: VERSION };
}());
// <<< CHARTE JOOMANJI : panneau <<<

// >>> CHARTE JOOMANJI : carte v2 (ne pas modifier ici : _charte/composants) >>>
/*
 * LA CARTE D'UN BLOC. Charte Joomanji, composant « carte », v2,
 * 12 octobre 2026 (v2 : chaque carte a ses « + » sur ses bords).
 *
 * La carte d'Opus dans l'article (plg_editors-xtd_opus, editeur.js, version
 * d'octobre 2026, validee par Cyrille), sortie dans la charte SANS CHANGER SON
 * DESSIN (demande de Cyrille, 12 octobre 2026), pour qu'Opus, Formulus, Iris
 * et Markus dessinent le meme bloc avec le meme code. Ses mesures et ses
 * signes sont les jetons v5.
 *
 *   var c = window.JoomanjiCarte;
 *
 *   c.habiller(doc);     // pose la feuille de la carte dans `doc` : la page,
 *                        // ou le document de TinyMCE (ed.getDoc()), ou les
 *                        // jetons sont alors recopies depuis la page
 *
 *   c.html({
 *     forme: 'tinymce',  // ou 'page' (Markus, la charte) : voir plus bas
 *     attributs: { 'data-opus-module': 148 },   // ceux du produit
 *     nom: 'Bloc Opus : Rangee de trois cartes',
 *     code: '{loadmoduleid 148}',               // la ligne du dessous
 *     outils: { modifier: 'Modifier', apercu: 'Apercu', retirer: 'Retirer' },
 *     plus: { dessus: '...', monter: '...', dessous: '...', descendre: '...' },
 *     deplacer: 'Deplacer',                    // la bulle de la poignee
 *     bogus: false                              // Iris : pieces retirees a
 *   });                                         // l'enregistrement par TinyMCE
 *
 * Chaque outil porte `data-jmj-action` (modifier, apercu, retirer, dessus,
 * monter, dessous, descendre) : le produit ecoute les clics et fait le reste.
 * Un outil absent de `outils` ou de `plus` n'est pas dessine.
 *
 * DEUX FORMES, UN DESSIN. « tinymce » : les outils sont des `span` a
 * `role="button"`, comme dans Opus (TinyMCE ne garde pas de `button` dans un
 * bloc non modifiable). « page » : de vrais `button`, atteignables a Tab,
 * pour Markus (cahier des charges, section 8) : les « + » et les fleches
 * s'allument alors des que le focus entre dans la carte.
 *
 * Aucune couleur ni mesure ecrite ici : uniquement les jetons `--jmj-`.
 */
(function () {
  'use strict';

  // LA PLUS RECENTE GAGNE (regle de « panneau » v5) : Opus, Formulus, Iris et
  // Markus chargent ce composant sur la meme page d'article.
  var VERSION = 2;

  if (window.JoomanjiCarte && (window.JoomanjiCarte.version || 0) >= VERSION) { return; }

  /*
   * LES JETONS A RECOPIER dans un document qui n'a pas la feuille de la
   * charte (le cadre de TinyMCE). Leur valeur calculee est lue sur la page :
   * clair, sombre, teinte d'Atum et mouvement reduit suivent.
   */
  var JETONS = ['--jmj-texte', '--jmj-accent', '--jmj-accent-doux', '--jmj-surface', '--jmj-surface-2',
    '--jmj-filet', '--jmj-texte-doux', '--jmj-succes', '--jmj-danger', '--jmj-violet', '--jmj-arrondi',
    '--jmj-texte-petit', '--jmj-texte-mini', '--jmj-icone', '--jmj-icone-grande', '--jmj-outil',
    '--jmj-carte-survol', '--jmj-carte-ecart-fleches', '--jmj-carte-lisere', '--jmj-duree',
    '--jmj-contour', '--jmj-contour-ecart', '--jmj-icone-poignee', '--jmj-icone-plus',
    '--jmj-icone-fleche', '--jmj-icone-roue', '--jmj-icone-oeil', '--jmj-icone-moins'];

  /*
   * LA FEUILLE, celle d'Opus d'octobre 2026 regle pour regle (`STYLE` de
   * editeur.js), les valeurs remplacees par leurs jetons. Seul ajout : le
   * contour au clavier des vrais boutons de la forme « page ».
   */
  var CSS = ''
    // La carte : liseré d'accent a gauche, fond d'accent doux.
    + '.jmj-carte{position:relative;display:flex;flex-wrap:wrap;align-items:center;gap:.5em;margin:1em 0;padding:.6em .8em;'
    + 'border:1px solid var(--jmj-filet);border-inline-start:var(--jmj-carte-lisere) solid var(--jmj-accent);'
    + 'border-radius:var(--jmj-arrondi);background:var(--jmj-accent-doux);'
    + 'font:var(--jmj-texte-petit)/1.4 system-ui,sans-serif;cursor:grab;user-select:none}'
    // La poignee a six points : « on peut deplacer ce bloc ».
    + '.jmj-carte__poignee{flex:none;width:var(--jmj-icone);height:var(--jmj-icone-grande);font-size:0;cursor:grab;'
    + 'background:var(--jmj-texte-doux);-webkit-mask:var(--jmj-icone-poignee) center/var(--jmj-icone) no-repeat;'
    + 'mask:var(--jmj-icone-poignee) center/var(--jmj-icone) no-repeat}'
    + '.jmj-carte__titre{flex:1;min-width:10em;font-weight:600}'
    + '.jmj-carte__code{display:block;font-weight:400;color:var(--jmj-texte-doux);font-size:var(--jmj-texte-mini)}'
    // Les outils en carres : roue violette, oeil, moins rouge.
    + '.jmj-carte__outil,.jmj-carte__plus{display:inline-flex;align-items:center;justify-content:center;'
    + 'width:var(--jmj-outil);height:var(--jmj-outil);box-sizing:border-box;margin:0;padding:0;font-size:0;'
    + 'border:1px solid var(--jmj-filet);border-radius:var(--jmj-arrondi);background-color:var(--jmj-surface);cursor:pointer}'
    + '.jmj-carte__outil{flex:none}'
    + '.jmj-carte__outil::before,.jmj-carte__plus::before{content:"";display:block;width:var(--jmj-icone);height:var(--jmj-icone);'
    + 'background-color:var(--jmj-texte-doux);-webkit-mask:var(--jmj-signe) center/contain no-repeat;'
    + 'mask:var(--jmj-signe) center/contain no-repeat}'
    + '.jmj-carte__outil:hover{background-color:var(--jmj-surface-2);border-color:var(--jmj-texte-doux)}'
    + '.jmj-carte__outil--modifier{--jmj-signe:var(--jmj-icone-roue)}'
    + '.jmj-carte__outil--modifier::before{background-color:var(--jmj-violet)}'
    + '.jmj-carte__outil--modifier:hover{border-color:var(--jmj-violet)}'
    + '.jmj-carte__outil--apercu{--jmj-signe:var(--jmj-icone-oeil)}'
    + '.jmj-carte__outil--retirer{--jmj-signe:var(--jmj-icone-moins)}'
    + '.jmj-carte__outil--retirer::before{background-color:var(--jmj-danger)}'
    + '.jmj-carte__outil--retirer:hover{border-color:var(--jmj-danger)}'
    // Le survol se voit : un trait leger, dans l'accent.
    + '.jmj-carte:hover:not([data-mce-selected]){outline:var(--jmj-carte-survol)}'
    // Les « + » : au milieu du bord du haut et du bord du bas, en fondu.
    + '.jmj-carte__plus{position:absolute;left:50%;z-index:1;--jmj-signe:var(--jmj-icone-plus);'
    + 'transform:translate(-50%,-50%);opacity:0;pointer-events:none;transition:opacity var(--jmj-duree)}'
    + '.jmj-carte__plus::before{background-color:var(--jmj-succes)}'
    + '.jmj-carte__plus--dessus{top:0}.jmj-carte__plus--dessous{top:100%}'
    + '.jmj-carte__plus:hover{background-color:var(--jmj-surface-2);border-color:var(--jmj-succes)}'
    // Les fleches, de part et d'autre du « + » du bas.
    + '.jmj-carte__fleche{left:calc(50% - var(--jmj-carte-ecart-fleches));--jmj-signe:var(--jmj-icone-fleche)}'
    + '.jmj-carte__fleche--bas{left:calc(50% + var(--jmj-carte-ecart-fleches))}'
    + '.jmj-carte__plus.jmj-carte__fleche::before{background-color:var(--jmj-texte-doux)}'
    + '.jmj-carte__fleche--bas::before{transform:rotate(180deg)}'
    + '.jmj-carte__plus.jmj-carte__fleche:hover{border-color:var(--jmj-texte-doux)}'
    // Pas de fleche qui ne mene nulle part : en tete et au bout de l'article.
    + '.jmj-carte:not(:has(~ :not([data-mce-bogus])))>.jmj-carte__fleche--bas,'
    + '.jmj-carte:first-child>.jmj-carte__fleche:not(.jmj-carte__fleche--bas){display:none}'
    // Quand les « + » s'allument : survol, carte choisie, focus dedans.
    + '.jmj-carte:hover>.jmj-carte__plus,.jmj-carte[data-mce-selected]>.jmj-carte__plus,'
    + '.jmj-carte:focus-within>.jmj-carte__plus{opacity:1;pointer-events:auto}'
    // v2 : chaque carte allume SES « + », sur ses propres bords (Cyrille : le
    // « + » du haut, emprunte a la carte d'avant, flottait dans l'ecart).
    // Deux voisines allumees ensemble : la survolee garde le « + » de l'ecart.
    + '.jmj-carte:has(+.jmj-carte:hover)>.jmj-carte__plus--dessous:not(.jmj-carte__fleche),'
    + '.jmj-carte:hover+.jmj-carte>.jmj-carte__plus--dessus{opacity:0;pointer-events:none}'
    // Forme « page » : le contour au clavier de la charte.
    + '.jmj-carte__outil:focus-visible,.jmj-carte__plus:focus-visible{outline:var(--jmj-contour);'
    + 'outline-offset:var(--jmj-contour-ecart)}';

  function echap(t) {
    return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /** Les attributs du produit, ecrits tels quels (noms et valeurs echappes). */
  function attributs(a) {
    var s = '';

    Object.keys(a || {}).forEach(function (k) { s += ' ' + echap(k) + '="' + echap(a[k]) + '"'; });

    return s;
  }

  /** Le HTML d'une carte (voir l'en-tete). */
  function html(o) {
    var page = o.forme === 'page';
    var bogus = o.bogus ? ' data-mce-bogus="all"' : '';
    var vide = page ? '' : '&nbsp;';

    function outil(classe, action, texte, touches) {
      var n = echap(texte);
      var debut = page ? '<button type="button"' : '<span role="button"';

      return debut + ' class="' + classe + '" data-jmj-action="' + action + '" aria-label="' + n + '" title="' + n + '"'
        + (touches ? ' aria-keyshortcuts="' + touches + '"' : '') + bogus + '>' + vide + (page ? '</button>' : '</span>');
    }

    var t = o.outils || {};
    var p = o.plus || {};
    var s = '<div class="jmj-carte"' + attributs(o.attributs) + (page ? '' : ' contenteditable="false"') + '>'
      + '<span class="jmj-carte__poignee" aria-hidden="true"' + (o.deplacer ? ' title="' + echap(o.deplacer) + '"' : '')
      + bogus + '>' + vide + '</span>'
      + '<span class="jmj-carte__titre"' + attributs(o.titre) + '>' + echap(o.nom)
      + (o.code ? '<span class="jmj-carte__code">' + echap(o.code) + '</span>' : '') + '</span>';

    ['modifier', 'apercu', 'retirer'].forEach(function (a) {
      if (t[a]) { s += outil('jmj-carte__outil jmj-carte__outil--' + a, a, t[a]); }
    });

    if (p.dessus) { s += outil('jmj-carte__plus jmj-carte__plus--dessus', 'dessus', p.dessus); }
    if (p.monter) { s += outil('jmj-carte__plus jmj-carte__plus--dessous jmj-carte__fleche', 'monter', p.monter, 'Alt+Shift+ArrowUp'); }
    if (p.dessous) { s += outil('jmj-carte__plus jmj-carte__plus--dessous', 'dessous', p.dessous); }
    if (p.descendre) {
      s += outil('jmj-carte__plus jmj-carte__plus--dessous jmj-carte__fleche jmj-carte__fleche--bas', 'descendre',
        p.descendre, 'Alt+Shift+ArrowDown');
    }

    return s + '</div>';
  }

  /**
   * Pose la feuille de la carte dans un document. Dans un autre document que
   * la page (le cadre de TinyMCE), les jetons y sont recopies d'abord. A
   * rappeler apres un changement de theme : les valeurs sont relues.
   */
  function habiller(doc) {
    doc = doc || document;

    if (doc !== document) {
      var calcul = window.getComputedStyle(document.documentElement);
      var racine = doc.documentElement;

      JETONS.forEach(function (j) { racine.style.setProperty(j, calcul.getPropertyValue(j)); });
    }

    var style = doc.getElementById('jmj-carte-feuille');

    if (!style) {
      style = doc.createElement('style');
      style.id = 'jmj-carte-feuille';
      (doc.head || doc.documentElement).appendChild(style);
    }

    if (style.getAttribute('data-version') !== String(VERSION)) {
      style.textContent = CSS;
      style.setAttribute('data-version', String(VERSION));
    }
  }

  window.JoomanjiCarte = { version: VERSION, html: html, habiller: habiller, jetons: JETONS };
}());
// <<< CHARTE JOOMANJI : carte <<<
