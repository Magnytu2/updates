/**
 * Markus Editor: line breaks and paragraphs (Cyrille, 18 October 2026).
 *
 * A line break (Shift+Enter) and a new paragraph (Enter) look alike on the
 * screen; pasted text often brings line breaks where one expected paragraphs,
 * and a setting then reaches every line of the block. So:
 *
 * - each line break of a paragraph or a title shows a small violet sign at the
 *   end of its line, drawn over the text (never written into the article);
 *   a click on it cuts the block there into two paragraphs;
 * - "Split into paragraphs" (Ctrl+Shift+Enter, or the right click menu) turns
 *   every line break of the block into a new block;
 * - "Join to the paragraph above" (Shift+Backspace at the start of a
 *   paragraph, or the right click menu) joins it to the one above with a line
 *   break, where Backspace glues the two texts.
 *
 * Each of them is one step of Markus's undo.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

import { t, escape } from 'plg_editors_markus.i18n';
import { parse, isEmpty } from 'plg_editors_markus.blocks';

// The blocks whose line breaks are shown and can be cut: a paragraph, a title.
const CUTTABLE = ['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'];

/** True when something is written after `br` in `el`: a last <br> only holds an empty line open. */
function endsALine(br, el) {
  const r = document.createRange();

  r.setStartAfter(br);
  r.setEnd(el, el.childNodes.length);

  return r.toString().replace(/[\s​]/g, '') !== '' || !!r.cloneContents().querySelector('img, svg, br');
}

/** The line breaks of an element that really end a line, in reading order. */
export function lineBreaks(el) {
  return [...el.querySelectorAll('br')].filter((br) => endsALine(br, el));
}

/** True when a block can be cut at its line breaks. */
export function cuttable(block) {
  return !!block && CUTTABLE.includes(block.dataset.type);
}

/**
 * Cuts a paragraph or a title at its line breaks: at all of them, or at the
 * `only`-th one. Each new block keeps the element of the first (its classes,
 * its style), not its anchor.
 */
export function splitLines(m, block, only = null) {
  if (!cuttable(block)) {
    return false;
  }

  const holder = document.createElement('template');

  holder.innerHTML = m.blockHtml(block);

  const el = holder.content.firstElementChild;
  const all = el ? lineBreaks(el) : [];
  const cuts = only === null ? all : all.slice(only, only + 1);

  if (!cuts.length) {
    m.say(t('SPLIT_NONE'));

    return false;
  }

  const pieces = [];

  // From the last break to the first: what is cut off goes into a new element.
  cuts.reverse().forEach((br) => {
    const r = document.createRange();

    r.setStartAfter(br);
    r.setEnd(el, el.childNodes.length);

    const piece = el.cloneNode(false);

    piece.removeAttribute('id');
    piece.append(r.extractContents());
    pieces.unshift(piece);
    br.remove();
  });

  const html = [el, ...pieces].map((p) => p.outerHTML).join('\n');
  const parent = block.parentNode;

  // insertBlocks() takes the step of undo, then the old block goes: one Ctrl+Z puts it back.
  m.insertBlocks(parse(html), block, parent);
  block.remove();
  m.changed();
  m.say(t('SPLIT_DONE', pieces.length + 1));

  return true;
}

/** Joins a paragraph to the one above, with a line break between their texts. */
export function joinWithBreak(m, block) {
  const prev = block && m.neighbour(block, -1, true);

  if (!block || block.dataset.type !== 'p' || !prev || prev.dataset.type !== 'p') {
    m.say(t('JOIN_NONE'));

    return false;
  }

  const target = prev.querySelector(':scope > .mk-body');
  const source = block.querySelector(':scope > .mk-body');

  m.remember();

  // joinInto() drops a last <br> (an empty line held open): the text node after ours keeps it.
  if (!isEmpty(target) && !isEmpty(source)) {
    target.append(document.createElement('br'), document.createTextNode(''));
  }

  m.joinInto(target, source, block);
  m.say(t('JOINED'));

  return true;
}

/**
 * THE SIGNS OF THE LINE BREAKS, drawn in a layer over the text: nothing is
 * written in the blocks, the caret never meets them. They follow the text
 * (typing, scrolling, a resized window).
 */
export class Breaks {
  constructor(m) {
    this.m = m;
    this.list = [];
    this.frame = 0;
    this.layer = document.createElement('div');
    this.layer.className = 'mk-ui mk-breaks';
    this.layer.setAttribute('aria-hidden', 'true');
    m.root.appendChild(this.layer);

    // The mouse keeps the caret where it is; the click cuts there.
    this.layer.addEventListener('mousedown', (e) => e.preventDefault());
    this.layer.addEventListener('click', (e) => {
      const sign = e.target.closest('[data-i]');
      const found = sign && this.list[Number(sign.dataset.i)];

      if (found && found.br.isConnected) {
        splitLines(m, found.block, found.index);
      }
    });

    const soon = () => this.soon();

    m.surface.addEventListener('input', soon);
    m.surface.addEventListener('scroll', soon, { passive: true });
    window.addEventListener('resize', soon, { passive: true });
    new ResizeObserver(soon).observe(m.surface);
  }

  soon() {
    window.cancelAnimationFrame(this.frame);
    this.frame = window.requestAnimationFrame(() => this.draw());
  }

  draw() {
    const m = this.m;

    this.list = [];

    if (m.surface.hidden) {
      this.layer.replaceChildren();

      return;
    }

    const base = m.root.getBoundingClientRect();
    const view = m.surface.getBoundingClientRect();
    let html = '';

    m.surface.querySelectorAll('.mk-block').forEach((block) => {
      if (!cuttable(block)) {
        return;
      }

      const body = block.querySelector(':scope > .mk-body');

      lineBreaks(body).forEach((br, index) => {
        const box = br.getBoundingClientRect();

        // Out of the visible text (scrolled away): not drawn.
        if (!box.height || box.bottom < view.top || box.top > view.bottom) {
          return;
        }

        const i = this.list.push({ br, block, index }) - 1;

        // A target of 24 px at least (WCAG 2.5.8), centred on its line.
        const h = Math.max(24, box.height);

        html += `<button type="button" class="mk-break" tabindex="-1" data-i="${i}" title="${escape(t('BREAK_TITLE'))}"`
          + ` style="left:${Math.round(box.left - base.left + 2)}px;top:${Math.round(box.top - base.top + (box.height - h) / 2)}px;height:${Math.round(h)}px"></button>`;
      });
    });

    this.layer.innerHTML = html;
  }
}
