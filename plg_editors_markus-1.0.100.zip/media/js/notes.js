/**
 * Markus Editor: footnotes (Cyrille: "oui" in the comparison with Gutenberg).
 *
 * Written as the Markdown of Markus writes them (markdown.js), so that both
 * ways read each other: in the text, `<sup id="appel-KEY"><a href="#note-KEY">N</a></sup>`;
 * at the end of the article, a separator then a numbered list whose items are
 * `<li id="note-KEY">text <a href="#appel-KEY" aria-label="Back to the text">↩</a></li>`.
 * Plain HTML: every template shows them, no script or style sheet on the site.
 * The numbers follow the order of the calls in the text, the notes too.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

import { t, escape } from 'plg_editors_markus.i18n';
import { parse } from 'plg_editors_markus.blocks';

const CALL = 'sup[id^="appel-"] > a[href^="#note-"]';

/** A list of footnotes: every item is a note with its link back to the text. */
export function isNotesList(el) {
  return !!el && el.tagName === 'OL' && el.children.length > 0
    && [...el.children].every((li) => /^note-/.test(li.id) && li.querySelector('a[href^="#appel-"]'));
}

/**
 * The list of footnotes of the article (the last one, if an article has
 * several). A line typed in it with Enter (no note of its own) does not make
 * it another list.
 */
function notesList(m) {
  return [...m.surface.querySelectorAll('.mk-block[data-type="ol"] > .mk-body')]
    .filter((ol) => [...ol.children].some((li) => /^note-/.test(li.id) && li.querySelector('a[href^="#appel-"]'))).pop() || null;
}

/** The first key no note or call of the article uses yet. */
function freeKey(m) {
  let n = 1;

  while (m.surface.querySelector(`[id="note-${n}"], [id="appel-${n}"]`)) {
    n += 1;
  }

  return String(n);
}

/** The pieces nobody types in: the number of a call, the link back from a note. */
export function lockNotes(root) {
  root.querySelectorAll('sup[id^="appel-"], a[href^="#appel-"]').forEach((el) => el.setAttribute('contenteditable', 'false'));
}

/**
 * Puts a footnote at the caret: its call in the text, its note at the end of
 * the article (the list is made when the article has none), and the caret in
 * the note, to write it.
 */
export function insertNote(m) {
  if (!m.restore()) {
    m.say(t('PLACE_CARET'));

    return;
  }

  const at = m.selection().cloneRange();
  const block = m.blockOf(at.startContainer);
  const key = freeKey(m);
  const item = `<li id="note-${key}"> <a href="#appel-${key}" aria-label="${escape(t('NOTE_BACK'))}">↩</a></li>`;
  let list = notesList(m);

  if (!block || list && list.contains(at.startContainer)) {
    m.say(t('NOTE_PLACE'));

    return;
  }

  if (list) {
    m.remember();
    list.insertAdjacentHTML('beforeend', item);
  } else {
    // After the last block that says something: the empty paragraph at the end stays last.
    const blocks = [...m.surface.children].filter((b) => b.classList.contains('mk-block'));
    let last = blocks[blocks.length - 1];

    while (last && last !== block && last.dataset.type === 'p' && !last.textContent.trim()) {
      last = last.previousElementSibling;
    }

    m.insertBlocks(parse(`<hr><ol>${item}</ol>`), last, m.surface);
    list = notesList(m);
    m.ensureEnd();
  }

  // The call, after the selection, never inside a word cut in two.
  const sup = document.createElement('sup');

  sup.id = `appel-${key}`;
  sup.innerHTML = `<a href="#note-${key}">${key}</a>`;
  at.collapse(false);
  at.insertNode(sup);
  lockNotes(m.surface);
  syncNotes(m);

  // The caret in the note, before its link back.
  const li = list.querySelector(`[id="note-${key}"]`);
  const r = document.createRange();

  list.focus({ preventScroll: true });
  r.setStart(li.firstChild, 0);
  r.collapse(true);
  window.getSelection().removeAllRanges();
  window.getSelection().addRange(r);
  li.scrollIntoView({ block: 'nearest' });
  m.changed();
  m.say(t('NOTE_ADDED', [...list.children].indexOf(li) + 1));
}

/**
 * Numbers the calls in the order of the text and puts the notes in the same
 * order. A note whose call is gone stays, at the end (Ctrl+Z may bring its
 * call back): the article check names it.
 */
export function syncNotes(m) {
  const list = notesList(m);

  if (!list) {
    return;
  }

  const items = new Map([...list.children].map((li) => [li.id.slice(5), li]));
  const order = [];

  [...m.surface.querySelectorAll(CALL)].filter((a) => !list.contains(a)).forEach((a) => {
    const li = items.get(a.getAttribute('href').slice(6));

    if (!li || order.includes(li)) {
      return;
    }

    order.push(li);

    if (a.textContent !== String(order.length)) {
      a.textContent = String(order.length);
    }
  });

  const now = [...list.children];

  if (order.some((li, i) => now[i] !== li)) {
    order.forEach((li) => list.appendChild(li));
    now.filter((li) => !order.includes(li)).forEach((li) => list.appendChild(li));
  }
}
