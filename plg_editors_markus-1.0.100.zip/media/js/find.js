/**
 * Markus Editor: find and replace (Cyrille, 18 October 2026).
 *
 * Ctrl+F opens the bar on the search field, Ctrl+H on the replace field; the
 * magnifier of the toolbar does the same. The bar sits between the toolbar
 * and the text, never over it. Options: match case, whole word, regular
 * expression.
 *
 * The matches are drawn with the browser's CSS Custom Highlight API, as the
 * live spelling is (spell.js): NOTHING is written into the article, no mark
 * to forget on save. A word cut by bold or a link is found all the same:
 * each typed zone is read as one text, its pieces mapped back to the nodes.
 *
 * Replacing takes one step of Markus's undo (remember()): one Ctrl+Z takes
 * back a single replacement as well as "Replace all".
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

import { t, escape } from 'plg_editors_markus.i18n';

// Elements that end a line: a match never runs from one line into the next.
const LINE = /^(P|LI|H[1-6]|DIV|TD|TH|CAPTION|FIGCAPTION|BLOCKQUOTE|FOOTER|UL|OL|BR|PRE)$/;
// The zero width space that keeps the caret out of a bold (markus.js): invisible, so never searched.
const HOLDER = '​';
// Inline elements a replacement may leave empty: removed then, nothing else is.
const INLINE = /^(STRONG|B|EM|I|U|S|CODE|KBD|MARK|SPAN|A|SUB|SUP|ABBR|SMALL)$/;
// The options, kept in the browser: a convenience only.
const KEY = 'markus:find';
// Beyond this, the count stops: a search for "e" in a long article stays quick.
const LIMIT = 5000;

const store = {
  get() {
    try {
      return JSON.parse(window.localStorage.getItem(KEY)) || {};
    } catch (e) {
      return {};
    }
  },
  set(value) {
    try {
      window.localStorage.setItem(KEY, JSON.stringify(value));
    } catch (e) {
      // Storage refused (private window): the options last for the page only.
    }
  },
};

/**
 * The text of a typed zone, and for each of its characters the text node and
 * offset it comes from (null for a line break between elements).
 */
function read(host) {
  let text = '';
  const map = [];
  const walk = (node) => {
    node.childNodes.forEach((n) => {
      if (n.nodeType === Node.TEXT_NODE) {
        const value = n.nodeValue;

        for (let i = 0; i < value.length; i += 1) {
          if (value[i] !== HOLDER) {
            text += value[i];
            map.push([n, i]);
          }
        }
      } else if (n.nodeType === Node.ELEMENT_NODE && n.getAttribute('contenteditable') !== 'false' && !n.classList.contains('mk-ui')) {
        if (LINE.test(n.tagName) && text && !text.endsWith('\n')) {
          text += '\n';
          map.push(null);
        }

        walk(n);
      }
    });
  };

  walk(host);

  return { host, text, map };
}

/** The range of a match, or null when it crosses a line break. */
function rangeOf(zone, start, end) {
  const a = zone.map[start];
  const b = zone.map[end - 1];

  if (!a || !b) {
    return null;
  }

  const r = document.createRange();

  r.setStart(a[0], a[1]);
  r.setEnd(b[0], b[1] + 1);

  return r;
}

/** Writes `$&`, `$1`... of a regular expression replacement, `$$` for a dollar. */
function expand(pattern, m) {
  return pattern.replace(/\$(\$|&|\d{1,2})/g, (all, what) => {
    if (what === '$') {
      return '$';
    }

    if (what === '&') {
      return m[0];
    }

    const n = Number(what);

    return n > 0 && n < m.length ? (m[n] ?? '') : all;
  });
}

export default class Finder {
  constructor(m) {
    this.m = m;
    this.matches = [];
    this.index = -1;
    this.saved = null;
    this.replaced = 0;
    this.able = typeof CSS !== 'undefined' && !!CSS.highlights && typeof Highlight !== 'undefined';
    this.options = { case: false, word: false, regex: false, ...store.get() };
    this.build();
  }

  build() {
    const id = `${this.m.textarea.id}-find`;
    const option = (name, text, key) => `<button type="button" class="mk-find__option" data-find="${name}" aria-pressed="${this.options[name]}"`
      + ` aria-label="${escape(t(`FIND_${name.toUpperCase()}`))}" title="${escape(t(`FIND_${name.toUpperCase()}`))} (Alt+${key})"`
      + ` aria-keyshortcuts="Alt+${key}">${escape(text)}</button>`;
    const icon = (name, label, keys) => `<button type="button" class="mk-button mk-button--${name}" data-find="${name}"`
      + ` aria-label="${escape(label)}" title="${escape(label)}" aria-keyshortcuts="${keys}"></button>`;
    const bar = document.createElement('div');

    bar.className = 'mk-find';
    bar.hidden = true;
    bar.setAttribute('role', 'search');
    bar.setAttribute('aria-label', t('FIND_TITLE'));
    bar.innerHTML = '<div class="mk-find__row">'
      + `<label class="visually-hidden" for="${id}">${escape(t('FIND_LABEL'))}</label>`
      + `<span class="mk-find__field"><input type="text" class="form-control form-control-sm mk-find__input" id="${id}" data-find="search"`
      + ` placeholder="${escape(t('FIND_LABEL'))}" autocomplete="off" spellcheck="false" data-lt-active="false">`
      + `${option('case', 'Aa', 'C')}${option('word', 'ab', 'W')}${option('regex', '.*', 'R')}</span>`
      + '<span class="mk-find__count" aria-live="polite" aria-atomic="true"></span>'
      + `${icon('find-prev', t('FIND_PREV'), 'Shift+Enter')}${icon('find-next', t('FIND_NEXT'), 'Enter')}`
      // Search and replace on one line (Cyrille); the line wraps on a narrow screen.
      + `<span class="mk-find__sep" aria-hidden="true"></span><label class="visually-hidden" for="${id}-by">${escape(t('FIND_REPLACE_LABEL'))}</label>`
      + `<span class="mk-find__field"><input type="text" class="form-control form-control-sm mk-find__input" id="${id}-by" data-find="by"`
      + ` placeholder="${escape(t('FIND_REPLACE_LABEL'))}" autocomplete="off" spellcheck="false" data-lt-active="false"></span>`
      + `<button type="button" class="btn btn-sm btn-outline-secondary" data-find="replace">${escape(t('FIND_REPLACE'))}</button>`
      + `<button type="button" class="btn btn-sm btn-outline-secondary" data-find="replace-all">${escape(t('FIND_REPLACE_ALL'))}</button>`
      + `<span class="mk-spacer"></span>${icon('find-close', t('FIND_CLOSE'), 'Escape')}</div>`;

    this.m.toolbar.after(bar);
    this.bar = bar;
    this.input = bar.querySelector('[data-find="search"]');
    this.by = bar.querySelector('[data-find="by"]');
    this.counter = bar.querySelector('.mk-find__count');

    // The text of the search can change several times a second: one count, read once typing stops.
    this.input.addEventListener('input', () => { this.replaced = 0; this.search(true); });
    this.by.addEventListener('input', () => { this.replaced = 0; });
    bar.addEventListener('click', (e) => this.onClick(e));
    // An option pressed with the mouse leaves the caret in the search field, as in every editor.
    bar.addEventListener('mousedown', (e) => {
      if (e.target.closest('.mk-find__option')) {
        e.preventDefault();
      }
    });
    bar.addEventListener('keydown', (e) => this.onKey(e));
  }

  get open() {
    return !this.bar.hidden;
  }

  /** Opens the bar: on the search field, or on the replace field (Ctrl+H). */
  show(replace = false) {
    const r = this.m.selection();

    this.saved = r ? r.cloneRange() : this.saved;

    // A short selection on one line is what one looks for, as in every editor.
    const chosen = r && !r.collapsed ? r.toString().replace(new RegExp(HOLDER, 'g'), '') : '';

    if (chosen && chosen.length < 200 && !/\n/.test(chosen)) {
      this.input.value = this.options.regex ? chosen.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') : chosen;
    }

    this.bar.hidden = false;
    this.m.toolbar.querySelector('[data-mk="find"]')?.setAttribute('aria-pressed', 'true');
    this.search(false, r);

    const field = replace ? this.by : this.input;

    field.focus();
    field.select();
  }

  /** Closes the bar; the caret goes back to the text, on the match shown if there is one. */
  hide() {
    const current = this.matches[this.index];
    const r = current ? rangeOf(current.zone, current.start, current.end) : this.saved;

    this.bar.hidden = true;
    this.m.toolbar.querySelector('[data-mk="find"]')?.setAttribute('aria-pressed', 'false');
    this.clear();

    const node = r && r.startContainer.isConnected ? r.startContainer : null;
    const el = node && (node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement);
    const host = current ? current.zone.host : el && el.closest('[contenteditable="true"]');

    if (host && this.m.surface.contains(host)) {
      host.focus({ preventScroll: true });
      window.getSelection().removeAllRanges();
      window.getSelection().addRange(r);
    } else {
      // The text was rebuilt meanwhile (an undo): the block of the caret, if it is still there, or the first one.
      const block = this.m.current && this.m.current.isConnected ? this.m.current : this.m.surface.querySelector('.mk-block');

      this.m.focusEnd(block, false);
    }
  }

  /** The magnifier of the toolbar: opens, or closes an open bar. */
  toggle() {
    if (this.open) {
      this.hide();
    } else {
      this.show();
    }
  }

  /** Every typed zone of the text: the blocks, the captions, the table cells, the code. */
  zones() {
    return [...this.m.surface.querySelectorAll('[contenteditable="true"]')]
      .filter((el) => !el.parentElement.closest('[contenteditable="true"]'))
      .map(read);
  }

  /** The expression of the search, or null (empty, or a regular expression that does not read). */
  pattern() {
    const text = this.input.value;

    if (!text) {
      return null;
    }

    let source = this.options.regex ? text : text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

    if (this.options.word) {
      source = `(?<![\\p{L}\\p{N}_])(?:${source})(?![\\p{L}\\p{N}_])`;
    }

    try {
      return new RegExp(source, `gu${this.options.case ? '' : 'i'}`);
    } catch (e) {
      return false;
    }
  }

  /**
   * Finds every match. `near` is a range: the first match shown is the first
   * one after it (where the caret was), otherwise the one shown stays.
   */
  search(typing = false, near = null) {
    const re = this.pattern();

    this.matches = [];
    this.input.classList.toggle('is-invalid', re === false);
    this.input.setAttribute('aria-invalid', re === false ? 'true' : 'false');

    if (re) {
      for (const zone of this.zones()) {
        re.lastIndex = 0;

        let m = re.exec(zone.text);

        while (m && this.matches.length < LIMIT) {
          if (!m[0].length) {
            // A regular expression that matches nothing (^, \b): step on, or it loops forever.
            re.lastIndex += 1;
          } else if (!m[0].includes('\n')) {
            this.matches.push({ zone, start: m.index, end: m.index + m[0].length, groups: [...m] });
          }

          m = re.exec(zone.text);
        }
      }
    }

    if (near) {
      const i = this.matches.findIndex((x) => {
        const r = rangeOf(x.zone, x.start, x.end);

        return r && r.compareBoundaryPoints(Range.START_TO_START, near) >= 0;
      });

      this.index = this.matches.length ? Math.max(0, i) : -1;
    } else {
      this.index = this.matches.length ? Math.min(Math.max(this.index, 0), this.matches.length - 1) : -1;
    }

    this.paint(!typing || !!near);
    this.tell(re);
  }

  /** After a change of the text (markus.js, changed): the matches follow, nothing moves. */
  refresh() {
    if (this.open) {
      this.search(true);
    }
  }

  tell(re) {
    let text = '';

    if (re === false) {
      text = t('FIND_BAD');
    } else if (re && !this.matches.length) {
      text = t('FIND_NONE');
    } else if (re) {
      text = t('FIND_COUNT', this.index + 1, this.matches.length + (this.matches.length >= LIMIT ? '+' : ''));
    }

    this.counter.textContent = text;
    this.counter.classList.toggle('mk-find__count--none', !!re && !this.matches.length);
    this.bar.querySelectorAll('[data-find="find-prev"], [data-find="find-next"], [data-find="replace"], [data-find="replace-all"]')
      .forEach((b) => { b.disabled = !this.matches.length; });
  }

  paint(scroll) {
    if (!this.able) {
      return;
    }

    const all = [];
    let current = null;

    this.matches.forEach((x, i) => {
      const r = rangeOf(x.zone, x.start, x.end);

      if (r) {
        (i === this.index ? (current = r) : all.push(r));
      }
    });

    CSS.highlights.set('mk-find', new Highlight(...all));
    CSS.highlights.set('mk-find-current', current ? new Highlight(current) : new Highlight());

    if (scroll && current) {
      this.reveal(current);
    }
  }

  clear() {
    if (this.able) {
      CSS.highlights.delete('mk-find');
      CSS.highlights.delete('mk-find-current');
    }
  }

  /** Brings the match shown into view, in the text that scrolls (the surface), not the page. */
  reveal(r) {
    const box = r.getBoundingClientRect();
    const s = this.m.surface;
    const view = s.getBoundingClientRect();

    if (s.scrollHeight > s.clientHeight + 1) {
      if (box.top < view.top + 8 || box.bottom > view.bottom - 8) {
        s.scrollTop += box.top - view.top - s.clientHeight / 3;
      }
    } else {
      (r.startContainer.parentElement || s).scrollIntoView({ block: 'nearest' });
    }
  }

  step(by) {
    if (!this.matches.length) {
      return;
    }

    this.index = (this.index + by + this.matches.length) % this.matches.length;
    this.paint(true);
    this.tell(this.pattern());
  }

  /** What a match becomes: the text typed, or for a regular expression its groups too. */
  replacement(x) {
    return this.options.regex ? expand(this.by.value, x.groups) : this.by.value;
  }

  /** Puts a text in place of a range; the inline elements it leaves empty go. */
  static put(r, text) {
    const touched = [];
    const root = r.commonAncestorContainer.nodeType === Node.ELEMENT_NODE ? r.commonAncestorContainer : r.commonAncestorContainer.parentElement;

    // The match fills a bold or a link of its own: that element may be left empty too.
    for (let el = root; el && INLINE.test(el.tagName); el = el.parentElement) {
      touched.push(el);
    }

    root.querySelectorAll('*').forEach((el) => {
      if (INLINE.test(el.tagName) && r.intersectsNode(el)) {
        touched.push(el);
      }
    });

    const start = r.startContainer;
    const at = r.startOffset;

    r.deleteContents();

    if (text) {
      if (start.nodeType === Node.TEXT_NODE && start.isConnected) {
        start.insertData(at, text);
      } else {
        r.insertNode(document.createTextNode(text));
      }
    }

    touched.forEach((el) => {
      if (el.isConnected && !el.textContent && !el.querySelector('img, br, svg')) {
        el.remove();
      }
    });
  }

  replaceOne() {
    const x = this.matches[this.index];
    const r = x && rangeOf(x.zone, x.start, x.end);

    if (!r) {
      return;
    }

    this.m.remember();
    Finder.put(r, this.replacement(x));
    this.after(1);
  }

  replaceAll() {
    if (!this.matches.length) {
      return;
    }

    // From the end of each zone to its start: the offsets still to come do not move.
    const todo = [...this.matches].reverse().map((x) => [rangeOf(x.zone, x.start, x.end), this.replacement(x)]).filter(([r]) => r);

    this.m.remember();
    todo.forEach(([r, text]) => Finder.put(r, text));
    this.after(todo.length);
  }

  /** After replacing: the text saved, the matches read again, the next one shown. */
  after(n) {
    this.m.changed(false);
    this.search(false);

    // The button pressed may now be disabled (nothing left to replace): the focus stays in the bar.
    if (!this.bar.contains(document.activeElement) || document.activeElement.disabled) {
      this.by.focus();
    }
    this.m.say(n === 1 ? t('FIND_REPLACED_ONE') : t('FIND_REPLACED', n));
    // Ctrl+Z in the bar, right after: it takes the replacement back, not the typing of the field.
    this.replaced = (this.replaced || 0) + 1;
  }

  onClick(e) {
    const b = e.target.closest('[data-find]');

    if (!b || b.disabled) {
      return;
    }

    switch (b.dataset.find) {
      case 'find-prev':
        this.step(-1);
        break;
      case 'find-next':
        this.step(1);
        break;
      case 'find-close':
        this.hide();
        break;
      case 'replace':
        this.replaceOne();
        break;
      case 'replace-all':
        this.replaceAll();
        break;
      case 'case':
      case 'word':
      case 'regex':
        this.setOption(b.dataset.find);
        break;
      default:
    }
  }

  setOption(name) {
    this.options[name] = !this.options[name];
    this.bar.querySelector(`[data-find="${name}"]`).setAttribute('aria-pressed', String(this.options[name]));
    store.set(this.options);
    this.search(false);
  }

  onKey(e) {
    const mod = e.ctrlKey || e.metaKey;

    if (mod && !e.shiftKey && e.code === 'KeyZ' && this.replaced) {
      e.preventDefault();
      this.replaced -= 1;
      this.m.undoAny();
      this.search(false);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      this.hide();
    } else if (e.key === 'Enter' && e.target === this.input) {
      e.preventDefault();
      this.step(e.shiftKey ? -1 : 1);
    } else if (e.key === 'Enter' && e.target === this.by) {
      e.preventDefault();

      if (mod && e.altKey) {
        this.replaceAll();
      } else {
        this.replaceOne();
      }
    } else if (e.altKey && !mod && ['KeyC', 'KeyW', 'KeyR'].includes(e.code)) {
      e.preventDefault();
      this.setOption({ KeyC: 'case', KeyW: 'word', KeyR: 'regex' }[e.code]);
    } else if (e.key === 'F3') {
      e.preventDefault();
      this.step(e.shiftKey ? -1 : 1);
    }
  }
}
