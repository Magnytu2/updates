/**
 * Markus Editor: the colours of the text and of its background.
 *
 * THE SITE'S COLOURS FIRST: Bootstrap classes (`text-*-emphasis`,
 * `bg-*-subtle`) that the site's template draws, in light and dark modes.
 *
 * ANY OTHER HUE IS LOCKED, like Corpus's hue. The author only picks a hue
 * (0 to 359); Markus computes the lightness that keeps the text readable
 * (4.5:1, WCAG AA) on the site's background in light AND dark mode, and
 * writes both: `color: light-dark(#light, #dark)`. No hue can give an
 * unreadable text, whatever the visitor's mode. A browser without
 * `light-dark()` or a site without `color-scheme` takes the light value,
 * which is readable on the light background.
 *
 * The colours go on the selection (a <span>, or a <mark> to highlight), or
 * on the whole block when nothing is selected. A background on a whole
 * block also gets Bootstrap's `p-3 rounded`, so the text does not touch
 * the edge of the colour.
 *
 * @copyright  (C) 2026 joomanji.eu
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

import { t, escape } from 'plg_editors_markus.i18n';
import { openMenu } from 'plg_editors_markus.menu';

/** [class, label key, charter token used for the swatch]. */
const TEXT = [['text-primary-emphasis', 'PRIMARY', '--jmj-primaire-texte'],
  ['text-secondary', 'SECONDARY', '--jmj-texte-doux'],
  ['text-success-emphasis', 'SUCCESS', '--jmj-succes-texte'],
  ['text-danger-emphasis', 'DANGER', '--jmj-danger-texte'],
  ['text-warning-emphasis', 'WARNING', '--jmj-alerte-texte'],
  ['text-info-emphasis', 'INFO', '--jmj-info-texte']];

const BACK = [['bg-primary-subtle', 'PRIMARY', '--jmj-primaire-doux'],
  ['bg-secondary-subtle', 'SECONDARY', '--jmj-secondaire-doux'],
  ['bg-success-subtle', 'SUCCESS', '--jmj-succes-doux'],
  ['bg-danger-subtle', 'DANGER', '--jmj-danger-doux'],
  ['bg-warning-subtle', 'WARNING', '--jmj-alerte-doux'],
  ['bg-info-subtle', 'INFO', '--jmj-info-doux']];

const TEXT_CLASSES = TEXT.map((c) => c[0]);
const BACK_CLASSES = [...BACK.map((c) => c[0]), 'p-3', 'rounded'];

/** The only styles Markus writes: a colour, as a code or a light/dark pair. */
const DECLARATION = /^(color|background-color)\s*:\s*(#[0-9a-f]{6}|light-dark\(\s*#[0-9a-f]{6}\s*,\s*#[0-9a-f]{6}\s*\))$/i;

const HUES_KEY = 'markus:hues';

/* THE CALCULATION: WCAG luminance and contrast. ------------------------ */

function hslHex(h, s, l) {
  const a = (s / 100) * Math.min(l / 100, 1 - l / 100);
  const f = (n) => {
    const k = (n + h / 30) % 12;

    return l / 100 - a * Math.max(-1, Math.min(k - 3, 9 - k, 1));
  };

  return `#${[f(0), f(8), f(4)].map((x) => Math.round(x * 255).toString(16).padStart(2, '0')).join('')}`;
}

function luminance(hex) {
  const [r, g, b] = [1, 3, 5].map((i) => {
    const c = parseInt(hex.substr(i, 2), 16) / 255;

    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });

  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

export function contrast(a, b) {
  const [l1, l2] = [luminance(a), luminance(b)].sort((x, y) => y - x);

  return (l1 + 0.05) / (l2 + 0.05);
}

/** A computed colour as a hex code, a transparent one laid on `under`. */
function hex(css, under = '#ffffff') {
  const m = /rgba?\(([^)]+)\)/.exec(css || '');

  if (!m) {
    return under;
  }

  const [r, g, b, a = 1] = m[1].split(/[\s,/]+/).filter(Boolean).map(Number);
  const base = [1, 3, 5].map((i) => parseInt(under.substr(i, 2), 16));

  return `#${[r, g, b].map((c, i) => Math.round(c * a + base[i] * (1 - a)).toString(16).padStart(2, '0')).join('')}`;
}

/**
 * The background and text of the template, in light and dark mode, measured
 * once on a hidden probe: Atum (and Bootstrap) redraw a themed element.
 */
let site = null;

export function siteColours() {
  if (site) {
    return site;
  }

  site = {};
  ['light', 'dark'].forEach((theme) => {
    const probe = document.createElement('div');

    probe.setAttribute('data-bs-theme', theme);
    probe.setAttribute('data-color-scheme', theme);
    probe.style.cssText = 'position:absolute;visibility:hidden;background-color:var(--body-bg);color:var(--body-color)';
    document.body.appendChild(probe);

    const style = getComputedStyle(probe);
    const back = hex(style.backgroundColor);

    site[theme] = { back, text: hex(style.color, back) };
    probe.remove();
  });

  return site;
}

/**
 * THE LOCKED HUE. For a text: the most vivid lightness that keeps 4.6:1 (a
 * margin over 4.5) on the background. For a background: the most coloured
 * one on which the site's text keeps 4.6:1.
 */
export function shade(h, target) {
  const s = siteColours();
  let light;
  let dark;

  if (target === 'back') {
    for (let l = 88; l <= 97; l += 1) {
      light = hslHex(h, 70, l);
      if (contrast(s.light.text, light) >= 4.6) { break; }
    }

    for (let l = 20; l >= 6; l -= 1) {
      dark = hslHex(h, 35, l);
      if (contrast(s.dark.text, dark) >= 4.6) { break; }
    }
  } else {
    for (let l = 55; l >= 5; l -= 1) {
      light = hslHex(h, 65, l);
      if (contrast(light, s.light.back) >= 4.6) { break; }
    }

    for (let l = 45; l <= 95; l += 1) {
      dark = hslHex(h, 65, l);
      if (contrast(dark, s.dark.back) >= 4.6) { break; }
    }
  }

  return { light, dark };
}

export const pair = (h, target) => {
  const { light, dark } = shade(h, target);

  return `light-dark(${light}, ${dark})`;
};

export const hueName = (h, target) => t(target === 'back' ? 'HUE_BACK_NAME' : 'HUE_TEXT_NAME', h);

/* THE LAST HUES, kept in the browser: a convenience only. ---------------- */

export function readHues() {
  try {
    const v = JSON.parse(window.localStorage.getItem(HUES_KEY));

    return { text: (v && v.text) || [], back: (v && v.back) || [] };
  } catch (err) {
    return { text: [], back: [] };
  }
}

export function keepHue(target, h) {
  const hues = readHues();

  hues[target] = [h, ...hues[target].filter((x) => x !== h)].slice(0, 5);

  try {
    window.localStorage.setItem(HUES_KEY, JSON.stringify(hues));
  } catch (err) {
    // Storage refused: the hue is simply not offered again.
  }
}

/* THE MENU ------------------------------------------------------------- */

function swatch(attrs, label, colour, extra = '') {
  return `<button type="button" role="menuitem" class="mk-swatch" ${attrs} aria-label="${escape(label)}" title="${escape(label)}">`
    + `<span class="mk-swatch__dot${extra}" style="background-color:${colour}" aria-hidden="true"></span></button>`;
}

function grid(target) {
  const list = target === 'back' ? BACK : TEXT;
  const hues = readHues()[target];

  return `<div class="mk-swatches" role="group" aria-label="${escape(t(target === 'back' ? 'COLOURS_BACK' : 'COLOURS_TEXT'))}">`
    + list.map(([cls, key, token]) => swatch(`data-target="${target}" data-class="${cls}"`,
      t(`${target === 'back' ? 'BACK' : 'TEXT'}_${key}`), `var(${token})`)).join('')
    + (target === 'back' ? swatch('data-target="back" data-class="mark"', t('HIGHLIGHT'), 'var(--jmj-alerte-doux)') : '')
    + hues.map((h) => swatch(`data-target="${target}" data-hue="${h}"`, hueName(h, target), shade(h, target).light)).join('')
    + swatch(`data-target="${target}" data-other="1"`, t(target === 'back' ? 'HUE_OTHER_BACK' : 'HUE_OTHER_TEXT'), 'transparent',
      ' mk-swatch__dot--rainbow')
    + '</div>';
}

/**
 * Opens the colour menu under `anchor`. Resolves with a paint order
 * ({ target, cls?, style?, name }), or null when closed without a choice.
 */
export async function chooseColour(anchor, at = null) {
  const item = await openMenu(anchor, {
    at,
    label: t('COLOURS'),
    className: 'mk-colours',
    columns: 7,
    html: `<p class="mk-menu__title">${escape(t('COLOURS_TEXT'))}</p>${grid('text')}`
      + `<p class="mk-menu__title">${escape(t('COLOURS_BACK'))}</p>${grid('back')}`
      + `<hr><button type="button" role="menuitem" class="mk-menu__item" data-remove="1">${escape(t('COLOURS_REMOVE'))}</button>`
      + `<p class="mk-menu__note">${escape(t('COLOURS_NOTE'))}</p>`,
  });

  if (!item) {
    return null;
  }

  const target = item.dataset.target;

  if (item.dataset.remove) {
    return { target: 'all', name: '' };
  }

  if (item.dataset.other) {
    const h = await pickHue(target);

    if (h === null) {
      if (anchor) {
        anchor.focus({ preventScroll: true });
      }

      return null;
    }

    keepHue(target, h);

    return { target, style: pair(h, target), name: hueName(h, target) };
  }

  if (item.dataset.hue) {
    const h = Number(item.dataset.hue);

    return { target, style: pair(h, target), name: hueName(h, target) };
  }

  return { target, cls: item.dataset.class, name: item.getAttribute('aria-label') };
}

/* THE CHOICE OF A HUE: one slider, the lightness is computed. ----------- */

export function pickHue(target) {
  const s = siteColours();
  const start = readHues()[target][0] ?? (target === 'back' ? 160 : 280);
  const box = (mode) => `<div class="mk-hue__theme" data-mode="${mode}"><small>${escape(t(mode === 'light' ? 'HUE_LIGHT' : 'HUE_DARK'))}</small>`
    + '<p></p><span class="mk-hue__ratio"></span></div>';

  return window.JoomanjiFenetre.saisir({
    titre: t(target === 'back' ? 'HUE_BACK_TITLE' : 'HUE_TEXT_TITLE'),
    // The slider, and the number beside it for a hue one knows (Cyrille: Cassiopeia's is 214).
    corps: `<div class="mk-field mk-hue__row"><label for="mk-hue-range">${escape(t('HUE'))}</label>`
      + `<input type="range" class="mk-hue" id="mk-hue-range" name="hue" min="0" max="359" step="1" value="${start}">`
      + `<input type="number" class="mk-hue__number" min="0" max="359" step="1" value="${start}" aria-label="${escape(t('HUE_NUMBER'))}"></div>`
      + `<div class="mk-hue__themes">${box('light')}${box('dark')}</div>`
      + `<p class="mk-field-hint">${escape(t('HUE_NOTE'))}</p>`,
    bouton: t('HUE_APPLY'),
    pret: (body) => {
      const range = body.querySelector('.mk-hue');
      const show = () => {
        const h = Number(range.value);
        const pick = shade(h, target);

        range.setAttribute('aria-valuetext', hueName(h, target));
        ['light', 'dark'].forEach((mode) => {
          const theme = body.querySelector(`[data-mode="${mode}"]`);
          const sample = theme.querySelector('p');
          const fore = target === 'back' ? s[mode].text : pick[mode];
          const back = target === 'back' ? pick[mode] : s[mode].back;

          // The preview shows the computed colours themselves: this is the one place
          // where a colour is written in a style, as it will be in the article.
          theme.style.cssText = `background-color:${s[mode].back};color:${s[mode].text}`;
          sample.style.cssText = `color:${fore};background-color:${back}`;
          sample.textContent = t(target === 'back' ? 'HUE_SAMPLE_BACK' : 'HUE_SAMPLE_TEXT');
          theme.querySelector('.mk-hue__ratio').textContent = t('HUE_RATIO', contrast(fore, back).toLocaleString(document.documentElement.lang || undefined, { maximumFractionDigits: 1 }));
        });
      };

      const number = body.querySelector('.mk-hue__number');

      range.addEventListener('input', () => {
        number.value = range.value;
        show();
      });
      number.addEventListener('input', () => {
        const h = Math.round(Number(number.value));

        if (number.value !== '' && h >= 0 && h <= 359) {
          range.value = String(h);
          show();
        }
      });
      show();
    },
  }).then((v) => (v ? Number(v.hue) : null));
}

/* PAINTING -------------------------------------------------------------- */

function readStyle(el) {
  const o = {};

  String(el.getAttribute('style') || '').split(';').forEach((d) => {
    const m = DECLARATION.exec(d.trim());

    if (m) {
      o[m[1].toLowerCase()] = m[2].replace(/\s+/g, ' ').replace(/\(\s*/, '(').replace(/\s*\)/, ')').toLowerCase();
    } else if (d.trim()) {
      // Any other declaration (written by TinyMCE, say) is kept as it was.
      o[`~${d.trim()}`] = '';
    }
  });

  return o;
}

function writeStyle(el, o) {
  const s = Object.keys(o).map((k) => (k[0] === '~' ? k.slice(1) : (o[k] ? `${k}: ${o[k]}` : ''))).filter(Boolean).join('; ');

  if (s) {
    el.setAttribute('style', s);
  } else {
    el.removeAttribute('style');
  }
}

/** Removes from an element the colour of a target: text, back or all. */
export function wipe(el, target) {
  const st = readStyle(el);

  if (target !== 'back') {
    el.classList.remove(...TEXT_CLASSES);
    delete st.color;
  }

  if (target !== 'text') {
    el.classList.remove(...BACK_CLASSES);
    delete st['background-color'];
  }

  writeStyle(el, st);

  if (!el.classList.length) {
    el.removeAttribute('class');
  }
}

const unwrap = (n) => n.replaceWith(...n.childNodes);

/**
 * The text nodes of the range inside `host`, the two ends split at the
 * range's limits, so that each one is selected whole. Working text by text
 * keeps the structure: a selection over two list items colours two pieces,
 * it never moves a piece of a list item into another.
 */
export function selectedTexts(range, host) {
  const { startContainer: sc, startOffset: so, endContainer: ec, endOffset: eo } = range;
  const walk = document.createTreeWalker(host, NodeFilter.SHOW_TEXT);
  const texts = [];

  while (walk.nextNode()) {
    const n = walk.currentNode;

    if (range.intersectsNode(n) && !n.parentNode.closest('.mk-ui')) {
      texts.push(n);
    }
  }

  return texts.filter((n) => n.length && !(n === ec && eo === 0) && !(n === sc && so >= n.length)).map((n) => {
    if (n === ec && eo < n.length) {
      n.splitText(eo);
    }

    return n === sc && so > 0 ? n.splitText(so) : n;
  });
}

/**
 * Splits the inline element `el` so that one copy holds `node` alone: the
 * parts before and after go to copies of `el` beside it. Returns the copy
 * that holds `node`.
 */
export function isolate(el, node) {
  const part = document.createRange();

  part.setStartBefore(el.firstChild);
  part.setEndBefore(node);

  if (!part.collapsed) {
    const before = el.cloneNode(false);

    before.appendChild(part.extractContents());

    if (before.textContent) {
      el.before(before);
    }
  }

  part.setStartAfter(node);
  part.setEndAfter(el.lastChild);

  if (!part.collapsed) {
    const after = el.cloneNode(false);

    after.appendChild(part.extractContents());

    if (after.textContent) {
      el.after(after);
    }
  }

  return el;
}

/**
 * Joins two neighbouring spans or marks that carry the same attributes. The
 * split texts are left split: the selection still points at them, and the
 * saved HTML is the same.
 */
export function mergeTwins(host) {
  host.querySelectorAll('span, mark').forEach((el) => {
    const next = el.nextSibling;

    if (next && next.nodeType === Node.ELEMENT_NODE && next.tagName === el.tagName && el.isConnected
      && [...el.attributes].length === [...next.attributes].length
      && [...el.attributes].every((a) => next.getAttribute(a.name) === a.value)) {
      next.prepend(...el.childNodes);
      el.remove();
    }
  });
}

/** Gives each text its new colour (or none), the old one of the same target removed first. */
function recolour(texts, host, order) {
  const prop = order.target === 'back' ? 'background-color' : 'color';

  texts.forEach((text) => {
    // The colours of the same target already around the text give way to the new one.
    const around = [];

    for (let el = text.parentNode; el !== host; el = el.parentNode) {
      if (el.matches('mark, span:not(.visually-hidden)')) {
        around.push(el);
      }
    }

    around.forEach((el) => {
      isolate(el, text);

      if (el.tagName === 'SPAN') {
        wipe(el, order.target);
      }

      if (el.tagName === 'MARK' ? order.target !== 'text' : !el.attributes.length) {
        unwrap(el);
      }
    });

    if (order.cls || order.style) {
      const wrap = document.createElement(order.cls === 'mark' ? 'mark' : 'span');

      if (order.cls && order.cls !== 'mark') {
        wrap.className = order.cls;
      }

      if (order.style) {
        writeStyle(wrap, { [prop]: order.style });
      }

      text.before(wrap);
      wrap.appendChild(text);
    }
  });

  mergeTwins(host);
}

/**
 * Paints `order` (from chooseColour) on the range, inside `host`, the
 * editable element of a block. Returns the key of the message to say, or
 * '' when nothing could be done (`MARK_SELECT`: highlighting needs a selection).
 */
export function paint(range, host, order) {
  const prop = order.target === 'back' ? 'background-color' : 'color';

  if (range.collapsed) {
    if (order.cls === 'mark') {
      return 'MARK_SELECT';
    }

    wipe(host, order.target);

    // Removing the colours of a block takes them from the whole text inside, too.
    if (order.target === 'all') {
      const all = document.createRange();

      all.selectNodeContents(host);
      recolour(selectedTexts(all, host), host, order);
    }

    if (order.cls) {
      host.classList.add(order.cls);
    }

    if (order.style) {
      writeStyle(host, { ...readStyle(host), [prop]: order.style });
    }

    if (order.target === 'back' && (order.cls || order.style)) {
      host.classList.add('p-3', 'rounded');
    }

    return order.target === 'all' ? 'COLOURS_REMOVED_BLOCK' : 'COLOUR_ON_BLOCK';
  }

  const texts = selectedTexts(range, host);

  recolour(texts, host, order);

  if (texts.length) {
    range.setStart(texts[0], 0);
    range.setEnd(texts[texts.length - 1], texts[texts.length - 1].length);
  }

  return order.target === 'all' ? 'COLOURS_REMOVED_SELECTION' : 'COLOUR_ON_SELECTION';
}
