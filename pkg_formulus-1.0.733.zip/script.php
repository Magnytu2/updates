<?php

/**
 * @package     Formulus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Mail\MailTemplate;
use Joomla\CMS\Table\Asset;
use Joomla\Database\DatabaseInterface;

/**
 * Le script du paquet.
 *
 * Avant : refuse un Joomla plus ancien que 6.2 ou un PHP trop ancien.
 * Apres : met en place ce que Joomla ne fait pas seul, et le DIT a chaque fois, jamais en silence.
 */
return new class () implements InstallerScriptInterface {
    // Joomla 6.2 au minimum (decision de Cyrille du 16 octobre 2026, CLAUDE.md
    // commun, 10 : nous suivons la derniere version mineure de Joomla).
    private string $joomlaMinimum = '6.2.0';

    private string $phpMinimum = '8.3.0';

    /**
     * Les plugins du paquet (groupe => cle du message d'activation).
     */
    private const PLUGINS = [
        'fields'  => 'PKG_FORMULUS_PLUGIN_ACTIVE',
        'task'    => 'PKG_FORMULUS_PLUGIN_TACHE_ACTIVE',
        'privacy' => 'PKG_FORMULUS_PLUGIN_PRIVACY_ACTIVE',
        // Le bouton de l'editeur et la note des modules poses (1.0.501).
        'editors-xtd' => 'PKG_FORMULUS_PLUGIN_EDITEUR_ACTIVE',
        'system'      => 'PKG_FORMULUS_PLUGIN_SYSTEME_ACTIVE',
    ];

    /**
     * Les deux modeles de mails et leurs balises. Sujet et corps sont des
     * CLES DE LANGUE : Joomla les traduit a l'envoi dans la langue du site ;
     * un administrateur qui les modifie dans com_mails les remplace par son
     * propre texte, pour une langue donnee.
     */
    private const MODELES = [
        'com_formulus.notification' => ['formulaire', 'nom', 'email', 'tous_les_champs', 'lien_reponse', 'date', 'sitename'],
        'com_formulus.accuse'       => ['formulaire', 'nom', 'email', 'tous_les_champs', 'date', 'sitename'],
        // La Lettre d'info (1.0.702, CAHIER-ABONNEMENTS.md, 6).
        'com_formulus.lettre_confirmation' => ['sitename', 'email', 'lien', 'themes', 'delai'],
        'com_formulus.lettre_preferences'  => ['sitename', 'email', 'lien', 'themes', 'desabonnement'],
        // L'invitation d'un compte du site (1.0.733).
        'com_formulus.lettre_invitation'   => ['sitename', 'email', 'lien', 'themes', 'delai'],
        'com_formulus.lettre_article'      => ['sitename', 'titre', 'intro', 'image', 'lien', 'categorie', 'date', 'preferences', 'desabonnement'],
    ];

    /**
     * Les plugins deja installes AVANT cette installation, lus au preflight,
     * avant que le paquet n'installe ses extensions.
     */
    private array $existaient = [];

    public function preflight(string $type, InstallerAdapter $adapter): bool
    {
        if ($type === 'uninstall') {
            return true;
        }

        // Les messages sont dans la langue du paquet, pas encore installee a
        // ce stade : on la lit dans l'archive.
        Factory::getLanguage()->load('pkg_formulus.sys', $adapter->getParent()->getPath('source'));

        foreach (array_keys(self::PLUGINS) as $groupe) {
            $this->existaient[$groupe] = $this->idPlugin($groupe) > 0;
        }

        if (version_compare(JVERSION, $this->joomlaMinimum, '<')) {
            // Le message dit quelle version de Formulus refuse, et quoi faire.
            $version = (string) ($adapter->getManifest()->version ?? '');
            Factory::getApplication()->enqueueMessage(Text::sprintf('PKG_FORMULUS_JOOMLA_TROP_ANCIEN', $version), 'error');

            return false;
        }

        if (version_compare(PHP_VERSION, $this->phpMinimum, '<')) {
            Factory::getApplication()->enqueueMessage(Text::sprintf('PKG_FORMULUS_PHP_TROP_ANCIEN', $this->phpMinimum), 'error');

            return false;
        }

        return true;
    }

    public function install(InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function update(InstallerAdapter $adapter): bool
    {
        return true;
    }

    /**
     * Ce que l'installateur ne retire pas avec les extensions : les modeles
     * de mails (com_mails), la tache planifiee, la ligne du journal.
     */
    public function uninstall(InstallerAdapter $adapter): bool
    {
        foreach (array_keys(self::MODELES) as $modele) {
            MailTemplate::deleteTemplate($modele);
        }

        $db = $this->db();
        $db->setQuery($db->createQuery()->delete($db->quoteName('#__scheduler_tasks'))->where($db->quoteName('type') . ' = ' . $db->quote('formulus.purge')))->execute();
        $db->setQuery($db->createQuery()->delete($db->quoteName('#__action_logs_extensions'))->where($db->quoteName('extension') . ' = ' . $db->quote('com_formulus')))->execute();

        return true;
    }

    public function postflight(string $type, InstallerAdapter $adapter): bool
    {
        if ($type !== 'install' && $type !== 'update') {
            return true;
        }

        $this->activerPlugins();
        $this->noterModules();

        if ($type === 'install') {
            $this->activerCaptchaNatif();
        }

        $this->creerModelesDeMails();
        $this->creerTachePurge();
        $this->creerTacheLettre();
        $this->migrerCategoriesLettre();
        $this->declarerAuJournal();
        $this->donnerDroitPublic();

        return true;
    }

    /**
     * Joomla installe un plugin DESACTIVE. On active chaque plugin de Formulus
     * a sa PREMIERE arrivee seulement : un administrateur qui l'a desactive
     * ensuite garde son choix.
     */
    private function activerPlugins(): void
    {
        $db = $this->db();

        foreach (self::PLUGINS as $groupe => $message) {
            if (!empty($this->existaient[$groupe]) || !($id = $this->idPlugin($groupe))) {
                continue;
            }

            $db->setQuery(
                $db->createQuery()
                    ->update($db->quoteName('#__extensions'))
                    ->set($db->quoteName('enabled') . ' = 1')
                    ->where($db->quoteName('extension_id') . ' = ' . (int) $id)
            )->execute();

            Factory::getApplication()->enqueueMessage(Text::_($message), 'info');
        }
    }

    /**
     * LA NOTE ET LA POSITION DES MODULES POSES DANS UN ARTICLE (1.0.501),
     * recalculees a chaque installation ou mise a jour par le plugin systeme
     * (comme le paquet d'Opus). Ce n'est qu'une aide : l'installation ne
     * doit pas echouer pour elle.
     */
    private function noterModules(): void
    {
        $classe = 'Joomanji\\Plugin\\System\\Formulus\\Extension\\Formulus';
        $source = JPATH_PLUGINS . '/system/formulus/src/Extension/Formulus.php';

        if (!class_exists($classe) && is_file($source)) {
            require_once $source;
        }

        if (!class_exists($classe)) {
            return;
        }

        try {
            $classe::tous($this->db());
        } catch (\Throwable $e) {
            Factory::getApplication()->enqueueMessage(Text::sprintf('PKG_FORMULUS_NOTE_ECHEC', $e->getMessage()), 'warning');
        }
    }

    /**
     * Les modeles de mails, s'ils n'existent pas encore. Un modele deja la,
     * peut-etre modifie par l'administrateur, n'est pas touche.
     */
    /**
     * LE CAPTCHA NATIF DE JOOMLA 6, active a la premiere installation.
     *
     * Demande de Cyrille : chaque modele pose un CAPTCHA, et il faut qu'il
     * existe. Joomla 6 n'embarque plus reCAPTCHA ; son CAPTCHA natif est
     * « Captcha - Proof of Work » (powcaptcha) : ni cle, ni service tiers, ni
     * cookie, donc rien a declarer au titre du RGPD. Installe desactive, il
     * est active ici UNE fois ; un administrateur qui le coupe ensuite garde
     * son choix, et l'ecran d'un formulaire le lui signale.
     */
    private function activerCaptchaNatif(): void
    {
        $db = $this->db();
        $db->setQuery(
            $db->createQuery()
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('enabled') . ' = 1')
                ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                ->where($db->quoteName('folder') . ' = ' . $db->quote('captcha'))
                ->where($db->quoteName('element') . ' = ' . $db->quote('powcaptcha'))
        )->execute();
    }

    private function creerModelesDeMails(): void
    {
        foreach (self::MODELES as $modele => $balises) {
            $cle = strtoupper(str_replace('com_formulus.', 'COM_FORMULUS_MAIL_', $modele));

            // Les courriels de la Lettre d'info ont aussi leur version HTML
            // (boutons, 1.0.729) ; ceux d'une reponse restent en texte.
            $html = str_starts_with($modele, 'com_formulus.lettre_') ? $cle . '_HTMLBODY' : '';

            if (MailTemplate::getTemplate($modele, '') === null) {
                MailTemplate::createTemplate($modele, $cle . '_SUBJECT', $cle . '_BODY', $balises, $html);
            } elseif ($html !== '') {
                // Un modele cree avant la 1.0.729 n'a pas de HTML : on le lui
                // donne, sans toucher a un HTML ecrit par l'administrateur.
                $db = $this->db();
                $db->setQuery(
                    $db->createQuery()
                        ->update($db->quoteName('#__mail_templates'))
                        ->set($db->quoteName('htmlbody') . ' = ' . $db->quote($html))
                        ->where($db->quoteName('template_id') . ' = ' . $db->quote($modele))
                        ->where($db->quoteName('language') . ' = ' . $db->quote(''))
                        ->where($db->quoteName('htmlbody') . ' = ' . $db->quote(''))
                )->execute();
            }
        }
    }

    /**
     * LA TACHE DE PURGE (RGPD). Une duree de conservation sans tache qui
     * l'applique est un reglage qui ne fait rien : on la cree, une fois par
     * jour, sur le modele des taches que l'installation de Joomla cree
     * elle-meme (installation/sql/mysql/extensions.sql). Si l'administrateur
     * la supprime, elle ne revient pas : on ne la cree que si le plugin
     * arrive pour la premiere fois.
     */
    private function creerTachePurge(): void
    {
        if (!empty($this->existaient['task'])) {
            return;
        }

        $db = $this->db();

        $existe = (int) $db->setQuery(
            $db->createQuery()
                ->select('COUNT(*)')
                ->from($db->quoteName('#__scheduler_tasks'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('formulus.purge'))
        )->loadResult();

        if ($existe) {
            return;
        }

        $maintenant = Factory::getDate();
        $demain     = Factory::getDate('tomorrow 03:00');

        $tache = (object) [
            'asset_id'        => 0,
            'title'           => Text::_('PKG_FORMULUS_TACHE_TITRE'),
            'type'            => 'formulus.purge',
            'execution_rules' => json_encode(['rule-type' => 'interval-days', 'interval-days' => '1', 'exec-day' => '1', 'exec-time' => '03:00']),
            'cron_rules'      => json_encode(['type' => 'interval', 'exp' => 'P1D']),
            'state'           => 1,
            'next_execution'  => $demain->toSql(),
            'params'          => json_encode([
                'individual_log' => false,
                'log_file'       => '',
                'notifications'  => ['success_mail' => '0', 'failure_mail' => '1', 'fatal_failure_mail' => '1', 'orphan_mail' => '1'],
            ]),
            'created'         => $maintenant->toSql(),
            'created_by'      => (int) Factory::getApplication()->getIdentity()?->id,
        ];

        try {
            $db->insertObject('#__scheduler_tasks', $tache);
            Factory::getApplication()->enqueueMessage(Text::_('PKG_FORMULUS_TACHE_CREEE'), 'info');
        } catch (\RuntimeException) {
            Factory::getApplication()->enqueueMessage(Text::_('PKG_FORMULUS_TACHE_ECHEC'), 'warning');
        }
    }

    /**
     * LES CATEGORIES PASSENT DES OPTIONS AUX FORMULAIRES (1.0.723). Un
     * formulaire qui inscrit, sans categorie a lui, recoit celles qui etaient
     * dans les Options : rien ne change pour ses abonnes. Les Options gardent
     * leur ancienne valeur, inemployee.
     */
    private function migrerCategoriesLettre(): void
    {
        try {
            $options = json_decode((string) $this->db()->setQuery(
                $this->db()->createQuery()
                    ->select($this->db()->quoteName('params'))
                    ->from($this->db()->quoteName('#__extensions'))
                    ->where($this->db()->quoteName('element') . ' = ' . $this->db()->quote('com_formulus'))
                    ->where($this->db()->quoteName('type') . ' = ' . $this->db()->quote('component'))
            )->loadResult(), true) ?: [];

            $categories = array_values(array_filter(array_map('intval', (array) ($options['lettre_categories'] ?? []))));

            if (!$categories) {
                return;
            }

            $db     = $this->db();
            $lignes = $db->setQuery(
                $db->createQuery()
                    ->select($db->quoteName(['id', 'params']))
                    ->from($db->quoteName('#__formulus_formulaires'))
            )->loadObjectList();

            foreach ($lignes as $ligne) {
                $params = json_decode((string) $ligne->params, true) ?: [];

                if ((int) ($params['lettre_inscrire'] ?? 0) !== 1 || !empty($params['lettre_categories'])) {
                    continue;
                }

                $params['lettre_categories']      = $categories;
                $params['lettre_sous_categories'] = (int) ($options['lettre_sous_categories'] ?? 1);
                $json                             = json_encode($params);
                $id                               = (int) $ligne->id;

                $db->setQuery(
                    $db->createQuery()
                        ->update($db->quoteName('#__formulus_formulaires'))
                        ->set($db->quoteName('params') . ' = :params')
                        ->where($db->quoteName('id') . ' = :id')
                        ->bind(':params', $json)
                        ->bind(':id', $id, \Joomla\Database\ParameterType::INTEGER)
                )->execute();
            }
        } catch (\RuntimeException) {
            // Premiere installation, pas encore de table : rien a reprendre.
        }
    }

    /**
     * LA TACHE DE LA LETTRE D'INFO (1.0.704), toutes les 5 minutes : sans
     * elle, rien ne part (CAHIER-ABONNEMENTS.md, 7). Creee si elle manque :
     * pour l'arreter, la desactiver plutot que la supprimer (une mise a jour
     * la recreerait). Elle ne fait rien tant que la Lettre d'info est eteinte.
     */
    private function creerTacheLettre(): void
    {
        $db = $this->db();

        $existe = (int) $db->setQuery(
            $db->createQuery()
                ->select('COUNT(*)')
                ->from($db->quoteName('#__scheduler_tasks'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('formulus.lettre'))
        )->loadResult();

        if ($existe) {
            return;
        }

        $maintenant = Factory::getDate();
        $tache      = (object) [
            'asset_id'        => 0,
            'title'           => Text::_('PKG_FORMULUS_TACHE_LETTRE_TITRE'),
            'type'            => 'formulus.lettre',
            'execution_rules' => json_encode(['rule-type' => 'interval-minutes', 'interval-minutes' => '5', 'exec-day' => '1', 'exec-time' => '00:00']),
            'cron_rules'      => json_encode(['type' => 'interval', 'exp' => 'PT5M']),
            'state'           => 1,
            'next_execution'  => $maintenant->toSql(),
            'params'          => json_encode([
                'individual_log' => false,
                'log_file'       => '',
                'notifications'  => ['success_mail' => '0', 'failure_mail' => '1', 'fatal_failure_mail' => '1', 'orphan_mail' => '1'],
            ]),
            'created'         => $maintenant->toSql(),
            'created_by'      => (int) Factory::getApplication()->getIdentity()?->id,
        ];

        try {
            $db->insertObject('#__scheduler_tasks', $tache);
        } catch (\RuntimeException) {
            Factory::getApplication()->enqueueMessage(Text::_('PKG_FORMULUS_TACHE_LETTRE_ECHEC'), 'warning');
        }
    }

    /**
     * Formulus dans la liste des extensions du journal des actions, pour que
     * le filtre « Extension » le propose.
     */
    private function declarerAuJournal(): void
    {
        $db = $this->db();

        $existe = (int) $db->setQuery(
            $db->createQuery()
                ->select('COUNT(*)')
                ->from($db->quoteName('#__action_logs_extensions'))
                ->where($db->quoteName('extension') . ' = ' . $db->quote('com_formulus'))
        )->loadResult();

        if (!$existe) {
            // Une VARIABLE, pas un objet ecrit sur place : insertObject() prend
            // son objet par reference. Releve a l'installation de la 1.0.206.
            $ligne = (object) ['extension' => 'com_formulus'];
            $db->insertObject('#__action_logs_extensions', $ligne);
        }
    }

    /**
     * LE DROIT « MODIFIER LA VALEUR DU CHAMP » POUR LE PUBLIC.
     *
     * Mesure dans la source (FieldsPlugin::onCustomFieldsPrepareDom) : un champ
     * dont l'utilisateur n'a pas `core.edit.value` sort DESACTIVE. Sans ce droit,
     * un visiteur verrait le formulaire public et ne pourrait rien y saisir.
     *
     * On ne le pose que s'il n'a jamais ete regle : un administrateur qui l'a
     * change dans Options, Droits garde son choix.
     */
    private function donnerDroitPublic(): void
    {
        $asset = new Asset($this->db());

        if (!$asset->loadByName('com_formulus')) {
            return;
        }

        $regles = json_decode((string) $asset->rules, true) ?: [];

        if (\array_key_exists('core.edit.value', $regles)) {
            return;
        }

        $regles['core.edit.value'] = ['1' => 1];
        $asset->rules              = json_encode($regles);

        if ($asset->store()) {
            Factory::getApplication()->enqueueMessage(Text::_('PKG_FORMULUS_DROIT_PUBLIC_POSE'), 'info');
        }
    }

    private function idPlugin(string $groupe): int
    {
        $db = $this->db();

        return (int) $db->setQuery(
            $db->createQuery()
                ->select($db->quoteName('extension_id'))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                ->where($db->quoteName('folder') . ' = ' . $db->quote($groupe))
                ->where($db->quoteName('element') . ' = ' . $db->quote('formulus'))
        )->loadResult();
    }

    private function db(): DatabaseInterface
    {
        return Factory::getContainer()->get(DatabaseInterface::class);
    }
};
