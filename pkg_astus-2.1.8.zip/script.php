<?php

/**
 * @package     Astus
 * @subpackage  pkg_astus
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\Database\DatabaseInterface;

/**
 * Joomla installe tout plugin DESACTIVE. Sans le plugin, Astus n'a ni panneau,
 * ni traductions dans ses modules (ils affichaient les cles brutes
 * PLG_SYSTEM_ASTUS_AUDIT_...). On l'active donc a la premiere installation.
 * Une mise a jour ne touche pas a l'etat choisi par l'administrateur.
 */
class Pkg_AstusInstallerScript
{
    public function postflight(string $type, InstallerAdapter $parent): bool
    {
        if ($type !== 'install' && $type !== 'discover_install') {
            return true;
        }

        try {
            $db    = Factory::getContainer()->get(DatabaseInterface::class);
            $query = $db->getQuery(true)
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('enabled') . ' = 1')
                ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
                ->where($db->quoteName('element') . ' = ' . $db->quote('astus'));
            $db->setQuery($query)->execute();
        } catch (\Throwable $e) {
            // L'installation reste valide : le plugin s'active a la main.
        }

        return true;
    }
}
