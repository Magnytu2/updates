<?php
/**
 * Le pied de site, commun aux quatre scénarios.
 *
 * Ce fichier ne renvoie PAS un tableau de modules, mais une FERMETURE qui en
 * fabrique un pour une langue donnée. Le scénario multilingue en demande un jeu
 * par langue ; les trois autres en demandent un seul, sans langue.
 *
 * Une fermeture et non une fonction nommée : le fichier peut être lu deux fois
 * dans la même requête, et une fonction déclarée deux fois arrête PHP net.
 *
 * DEUX MODULES, ET PAS CINQ. Les quatre blocs auraient pu être quatre modules
 * répartis par `layoutWidth_footer`. Ils tiennent dans un seul, avec la grille
 * de Bootstrap que Corpus embarque déjà : le pied ne dépend alors d'AUCUN
 * réglage de largeur de bande, et il sort pareil sur un site dont le style
 * n'aurait pas été préparé pour lui.
 *
 * TOUS LES LIENS SORTENT DU SITE. C'est la demande, et c'est aussi ce qui rend
 * ce pied réutilisable tel quel : il ne référence aucune page installée, donc
 * il ne casse pas quand la démonstration est retirée.
 */

defined('_JEXEC') or die;

return static function (string $code, string $langueModule = '*'): array {

	/*
	 * LES ADRESSES.
	 *
	 * Celles de joomla.org sont les domaines du projet. Les deux adresses
	 * francophones ont été ouvertes le 25 août 2026 : `www.joomla.fr` répond et
	 * pointe lui-même vers `forum.joomla.fr`, qui répond aussi.
	 *
	 * Celles de joomanji.eu sont déduites de l'arborescence de la boutique et
	 * restent à confirmer par Cyrille.
	 */
	$liens = [
		'corpus'    => 'https://joomanji.eu/corpus',
		'astus'     => 'https://joomanji.eu/astus',
		'iris'      => 'https://joomanji.eu/iris',
		'oculus'    => 'https://joomanji.eu/oculus',
		'boutique'  => 'https://joomanji.eu',
		'projet'    => 'https://www.joomla.org',
		'doc'       => 'https://docs.joomla.org',
		'ext'       => 'https://extensions.joomla.org',
		'forum'     => 'https://forum.joomla.org',
		'magazine'  => 'https://magazine.joomla.org',
		'communaute' => 'https://community.joomla.org',
		'benevoles' => 'https://volunteers.joomla.org',
		'dev'       => 'https://developer.joomla.org',
		'joomlafr'  => 'https://www.joomla.fr/',
		'forumfr'   => 'https://forum.joomla.fr/',
	];

	/*
	 * LES TEXTES.
	 *
	 * La phrase de marque est la formule retenue par Cyrille le 25 août : elle
	 * oppose ce qui se règle à ce qui ne se négocie pas, plutôt que d'aligner
	 * des adjectifs qu'on ne peut pas vérifier.
	 *
	 * La mention de marque est le texte de Cyrille, mot pour mot en français.
	 * Les trois traductions sont au plus près : c'est un texte juridique, ce
	 * n'est pas un endroit où reformuler. L'allemand et l'espagnol restent à
	 * faire relire par un locuteur.
	 */
	$textes = [
		'fr-FR' => [
			'marque'     => "Souple là où c'est utile, strict là où ça compte. Tout se règle dans"
				. " l'administration ; l'accessibilité et le gestionnaire de consentement, eux, sont"
				. " déjà là.",
			'marqueLien' => 'Découvrir Corpus',
			'joomanji'   => 'Joomanji',
			'joomla'     => 'Joomla',
			'communaute' => 'Communauté',
			'boutique'   => 'La boutique',
			'projet'     => 'Le projet Joomla',
			'doc'        => 'La documentation',
			'ext'        => 'Les extensions',
			'forum'      => 'Le forum',
			'magazine'   => 'Le magazine',
			'commu'      => 'La communauté',
			'benevoles'  => 'Les bénévoles',
			'dev'        => 'Les développeurs',
			'joomlafr'   => 'Joomla francophone',
			'forumfr'    => 'Le forum francophone',
			'legal'      => "Joomanji.eu n'est pas affilié ou approuvé par le projet Joomla!® ou Open"
				. " Source Matters. Le nom et le logo Joomla!® sont utilisés sous une licence limitée"
				. " accordée par Open Source Matters, le détenteur de la marque aux États-Unis et dans"
				. " d'autres pays.",
		],

		'en-GB' => [
			'marque'     => 'Flexible where it helps, strict where it matters. Everything is set from'
				. ' the admin; accessibility and the consent manager are already there.',
			'marqueLien' => 'Discover Corpus',
			'joomanji'   => 'Joomanji',
			'joomla'     => 'Joomla',
			'communaute' => 'Community',
			'boutique'   => 'The shop',
			'projet'     => 'The Joomla Project',
			'doc'        => 'Documentation',
			'ext'        => 'Extensions',
			'forum'      => 'Forum',
			'magazine'   => 'The magazine',
			'commu'      => 'The community',
			'benevoles'  => 'Volunteers',
			'dev'        => 'Developers',
			'legal'      => 'Joomanji.eu is not affiliated with or endorsed by the Joomla!® Project or'
				. ' Open Source Matters. The Joomla!® name and logo are used under a limited licence'
				. ' granted by Open Source Matters, the trademark holder in the United States and other'
				. ' countries.',
		],

		'de-DE' => [
			'marque'     => 'Flexibel, wo es nützt, streng, wo es zählt. Alles wird im Backend'
				. ' eingestellt; Barrierefreiheit und Einwilligungsverwaltung sind bereits da.',
			'marqueLien' => 'Corpus entdecken',
			'joomanji'   => 'Joomanji',
			'joomla'     => 'Joomla',
			'communaute' => 'Gemeinschaft',
			'boutique'   => 'Der Shop',
			'projet'     => 'Das Joomla-Projekt',
			'doc'        => 'Dokumentation',
			'ext'        => 'Erweiterungen',
			'forum'      => 'Forum',
			'magazine'   => 'Das Magazin',
			'commu'      => 'Die Gemeinschaft',
			'benevoles'  => 'Freiwillige',
			'dev'        => 'Entwickler',
			'legal'      => 'Joomanji.eu ist weder mit dem Joomla!®-Projekt noch mit Open Source Matters'
				. ' verbunden noch wird es von diesen unterstützt. Name und Logo Joomla!® werden unter'
				. ' einer eingeschränkten Lizenz von Open Source Matters verwendet, dem Inhaber der'
				. ' Marke in den Vereinigten Staaten und in anderen Ländern.',
		],

		'es-ES' => [
			'marque'     => 'Flexible donde conviene, estricto donde importa. Todo se configura desde la'
				. ' administración; la accesibilidad y el gestor de consentimiento ya están.',
			'marqueLien' => 'Descubrir Corpus',
			'joomanji'   => 'Joomanji',
			'joomla'     => 'Joomla',
			'communaute' => 'Comunidad',
			'boutique'   => 'La tienda',
			'projet'     => 'El proyecto Joomla',
			'doc'        => 'La documentación',
			'ext'        => 'Las extensiones',
			'forum'      => 'El foro',
			'magazine'   => 'La revista',
			'commu'      => 'La comunidad',
			'benevoles'  => 'Los voluntarios',
			'dev'        => 'Los desarrolladores',
			'legal'      => 'Joomanji.eu no está afiliado ni respaldado por el proyecto Joomla!® ni por'
				. ' Open Source Matters. El nombre y el logotipo Joomla!® se utilizan bajo una licencia'
				. ' limitada concedida por Open Source Matters, titular de la marca en los Estados'
				. ' Unidos y en otros países.',
		],
	];

	$t = $textes[$code] ?? $textes['en-GB'];

	/*
	 * Un lien de la liste, en <li>. TOUS SORTENT DU SITE, sans exception : ils
	 * ouvrent donc un onglet, portent le pictogramme de lien et l'avertissement
	 * pour lecteur d'écran. Voir `lien-externe.php` pour le pourquoi de chacune
	 * des trois choses.
	 */
	$externe = require __DIR__ . '/lien-externe.php';

	$item = static function (string $url, string $intitule) use ($externe, $code): string {
		return '<li>' . $externe($url, $intitule, $code) . '</li>';
	};

	/*
	 * LES DEUX LIENS FRANCOPHONES NE SORTENT QU'EN FRANÇAIS. Un forum en
	 * français dans le pied allemand n'aide personne, et un lien qu'on ne peut
	 * pas lire est un lien mort pour celui qui tombe dessus.
	 */
	$communaute = $item($liens['magazine'], $t['magazine']);

	if ($code === 'fr-FR') {
		$communaute .= $item($liens['joomlafr'], $t['joomlafr'])
			. $item($liens['forumfr'], $t['forumfr']);
	}

	$communaute .= $item($liens['communaute'], $t['commu'])
		. $item($liens['benevoles'], $t['benevoles'])
		. $item($liens['dev'], $t['dev']);

	/*
	 * LA GRILLE. `row` et `col-md-*` viennent de Bootstrap, que Corpus embarque
	 * et dont les tampons se servent déjà. Le reste des classes vient du pied de
	 * Corpus lui-même, relevé dans `_entete-pied.scss` : `pied__marque` borne le
	 * texte de marque à 34 caractères et le passe en gris doux, et les règles
	 * `.pied__bloc h2 / ul / a`, posées par la bande, habillent les trois listes
	 * sans qu'on ait une classe à écrire.
	 */
	/*
	 * LA RÉPARTITION EST 6 / 2 / 2 / 2, choix de Cyrille : le bloc de marque
	 * porte une phrase, les trois autres portent des listes de deux ou trois
	 * mots. Leur donner la même largeur revenait à laisser respirer ce qui n'en
	 * a pas besoin et à serrer ce qui en a besoin. Les douze douzièmes sont
	 * utilisés, la ligne est pleine.
	 *
	 * LA BORNE DU TEXTE DE MARQUE EST RELEVÉE À 44 CARACTÈRES, et c'est la
	 * conséquence directe de cette largeur. `.pied__marque p` de Corpus la fixe
	 * à 34 : bon à quatre douzièmes, où le texte remplissait la colonne, mais à
	 * six il laissait un tiers de la colonne vide et le bloc paraissait
	 * inachevé. Quarante-quatre reste une longueur de ligne courte et lisible.
	 *
	 * En attribut de style, faute de mieux : c'est un réglage de ce pied-ci, pas
	 * une règle du template, et Corpus n'a pas de classe pour le dire.
	 */
	$grille = '<div class="row">'
		. '<div class="col-md-6 pied__marque">'
		. '<p><strong>Corpus</strong></p>'
		. '<p style="max-width:44ch">' . $t['marque'] . '</p>'
		. '<ul>' . $item($liens['corpus'], $t['marqueLien']) . '</ul>'
		. '</div>'

		. '<div class="col-md-2">'
		. '<h2>' . $t['joomanji'] . '</h2><ul>'
		. $item($liens['corpus'], 'Corpus')
		. $item($liens['astus'], 'Astus')
		. $item($liens['iris'], 'Iris')
		. $item($liens['oculus'], 'Oculus')
		. $item($liens['boutique'], $t['boutique'])
		. '</ul></div>'

		. '<div class="col-md-2">'
		. '<h2>' . $t['joomla'] . '</h2><ul>'
		. $item($liens['projet'], $t['projet'])
		. $item($liens['doc'], $t['doc'])
		. $item($liens['ext'], $t['ext'])
		. $item($liens['forum'], $t['forum'])
		. '</ul></div>'

		. '<div class="col-md-2">'
		. '<h2>' . $t['communaute'] . '</h2><ul>' . $communaute . '</ul></div>'

		. '</div>';

	/*
	 * LA MENTION DE MARQUE, SUR SA PROPRE LIGNE.
	 *
	 * `.pied__bas` est une rangée en `flex` que le template garnit déjà d'un
	 * bouton de réglages d'affichage et d'une mention de propriété poussée à
	 * droite. Un texte de trois cent cinquante signes qui partage cette ligne
	 * écrase les deux autres.
	 *
	 * `flex: 1 1 100%` en attribut de style, faute de mieux : Corpus n'a pas de
	 * classe pour ce cas. LE VRAI CORRECTIF EST DANS LE TEMPLATE, une classe du
	 * genre `.pied__bas--pleine`, et ce style en dur devra disparaître le jour
	 * où elle existera.
	 *
	 * CE STYLE DOIT PORTER SUR L'ITEM DU FLEX, ET C'EST LÀ QUE JE ME SUIS
	 * TROMPÉ, mesuré sur le banc le 25 août : le module portait
	 * `style => corpus-no-card`, qui écrase le chrome demandé par `index.php` et
	 * enveloppe la sortie dans un `<div class="module">`. C'est CE div qui
	 * devenait l'item du flex, pas le paragraphe ; il tombait à zéro de large et
	 * mille quatre-vingts de haut, et le texte descendait en colonne d'un
	 * caractère.
	 *
	 * D'où l'absence de `style` sur ce module, plus bas : `index.php` inclut
	 * `footer-bottom` avec le chrome `none`, qui ne pose aucun conteneur. Le
	 * paragraphe est alors l'item du flex, et le style s'applique où il faut.
	 */
	$mention = '<p style="flex:1 1 100%;margin:0">' . $t['legal'] . '</p>';

	return [
		[
			'title'     => 'Pied de site',
			'module'    => 'mod_custom',
			'position'  => 'footer',
			'showtitle' => 0,
			'pages'     => 'all',
			'language'  => $langueModule,
			'content'   => $grille,
			'params'    => ['prepare_content' => 1, 'style' => 'corpus-no-card'],
		],
		[
			'title'     => 'Mention de marque',
			'module'    => 'mod_custom',
			'position'  => 'footer-bottom',
			'showtitle' => 0,
			'pages'     => 'all',
			'language'  => $langueModule,
			'content'   => $mention,

			// PAS DE `style` ICI : voir plus haut. Le laisser vide fait tomber
			// le rendu sur le chrome `none` que demande `index.php`, donc sur
			// une sortie sans conteneur.
			'params'    => ['prepare_content' => 1],
		],
	];
};
