<?php
/**
 * Le menu, commun au blog et au magazine.
 *
 * Un scénario le reprend tel quel et n'ajuste que son entrée d'accueil, qui
 * porte les réglages de la une et diffère donc d'une mise en page à l'autre.
 *
 * `key` sert de référence pour les entrées filles. `mega` pose le mot dans le
 * champ natif « Style CSS du lien », ce qui suffit à déclencher le méga-menu
 * de Corpus sur une entrée de premier niveau.
 *
 * CE FICHIER REND UNE FONCTION DEPUIS LE 26 AOÛT, et non plus un tableau.
 *
 * Mesuré sur le banc : la page d'atterrissage anglaise affichait « Découvrir »,
 * « Typographie », « Les tampons » et « Connexion » au milieu d'un menu par
 * ailleurs traduit. Le fichier était repris tel quel pour les deux langues.
 *
 * Seuls les INTITULÉS changent. Les clés (`key`, `parent`), les catégories et
 * les alias d'article restent les mêmes : le contenu de démonstration est en
 * « Toutes langues », il n'a qu'un seul jeu d'adresses. Ce qui change de langue,
 * c'est ce que le visiteur lit.
 *
 * L'anglais n'a pas été relu par un anglophone.
 */

defined('_JEXEC') or die;

/*
 * LES INTITULÉS, PAR LANGUE. Une langue inconnue retombe sur l'anglais : le
 * module se vend hors de France, et un menu anglais est toujours lisible par un
 * francophone, l'inverse est moins vrai.
 */
$intitules = [
	'fr-FR' => [
		'accueil'    => 'Accueil',
		'recettes'   => 'Recettes',
		'potager'    => 'Le potager',
		'decouvrir'  => 'Découvrir',
		'toutesRec'  => 'Toutes les recettes',
		'entrees'    => 'Entrées',
		'plats'      => 'Plats',
		'desserts'   => 'Desserts',
		'tousLeg'    => 'Tous les légumes',
		'aubergine'  => "L'aubergine",
		'tomate'     => 'La tomate',
		'potimaron'  => 'Le potimaron',
		'poireau'    => 'Le poireau',
		'site'       => 'Le site',
		'typo'       => 'Typographie',
		'tampons'    => 'Les tampons',
		'connexion'  => 'Connexion',
		'compte'     => 'Créer un compte',
		'motDePasse' => 'Mot de passe oublié',
		'recherche'  => 'Recherche',
		'contacts'   => 'Contacts',
	],
	'en-GB' => [
		'accueil'    => 'Home',
		'recettes'   => 'Recipes',
		'potager'    => 'The kitchen garden',
		'decouvrir'  => 'Discover',
		'toutesRec'  => 'All recipes',
		'entrees'    => 'Starters',
		'plats'      => 'Mains',
		'desserts'   => 'Desserts',
		'tousLeg'    => 'All vegetables',
		'aubergine'  => 'The aubergine',
		'tomate'     => 'The tomato',
		'potimaron'  => 'The red kuri squash',
		'poireau'    => 'The leek',
		'site'       => 'The site',
		'typo'       => 'Typography',
		'tampons'    => 'Content blocks',
		'connexion'  => 'Log in',
		'compte'     => 'Create an account',
		'motDePasse' => 'Forgotten password',
		'recherche'  => 'Search',
		'contacts'   => 'Contacts',
	],
];

// LES PAGES DE CATÉGORIE DES RECETTES, réglées une fois pour toutes.
//
// « Le potager » ne les reçoit PAS : Cyrille le veut en mise en page native de
// Joomla, pour qu'on voie la différence entre une page habillée et une page
// que le template laisse tranquille.
//
// Demande de Cyrille : tous les articles de la catégorie, à l'horizontale,
// l'image d'un côté puis de l'autre. Corpus porte exactement cela dans le
// champ natif « Classe d'article » du lien de menu, avec le vocabulaire de
// Cassiopeia repris volontairement (voir `etc/aide-classes.ini`) :
//
//   image-left        l'image à gauche, le texte à droite
//   image-alternate   à combiner avec l'un des deux : un côté sur deux
//   no-card           la vignette sans cadre
//
// UNE SEULE COLONNE, et aucun article de tête : une vignette horizontale n'a
// pas la place de se déployer dans une colonne de six douzièmes, et un article
// de tête casserait l'alternance dès la première ligne.
$pagesCategorie = [
	'num_leading_articles' => '0',
	'num_intro_articles'   => '20',
	'num_columns'          => '1',
	'num_links'            => '0',
	'blog_class'           => 'image-left image-alternate no-card',
	'blog_class_leading'   => 'image-left no-card',
	'show_intro'           => '1',
	'orderby_sec'          => 'rdate',

	// « Recettes » ne porte aucun article en propre : ils sont dans Entrées,
	// Plats et Desserts. Sans cette ligne, sa page serait vide.
	'show_subcategory_content' => '-1',
	'maxLevel'                 => '-1',
];


return static function (string $code = 'fr-FR') use ($intitules, $pagesCategorie): array {

	$m = $intitules[$code] ?? $intitules['en-GB'];

	return [

	[
		'key'    => 'accueil',
		'title'  => $m['accueil'],
		'type'   => 'featured',
		'home'   => true,
	],

	// Les entrées ordinaires d'abord.
	['title' => $m['recettes'], 'type' => 'category', 'params' => $pagesCategorie, 'category' => 'recettes'],
	['title' => $m['potager'], 'type' => 'category', 'category' => 'potager'],

	// LE MÉGA-MENU EN DERNIER, demandé par Cyrille : un panneau large ouvert
	// sous la dernière entrée reste dans la page, alors qu'ouvert sous la
	// première il pousse tout le reste vers la droite.
	// Type « heading » : l'entrée n'ouvre aucune page, elle ne sert qu'à
	// porter le panneau.
	['key' => 'decouvrir', 'title' => $m['decouvrir'], 'type' => 'heading', 'mega' => true],

	// Colonne 1
	['key' => 'col-recettes', 'title' => $m['recettes'], 'type' => 'heading', 'parent' => 'decouvrir'],
	['key' => 'toutes-recettes', 'title' => $m['toutesRec'], 'type' => 'category', 'params' => $pagesCategorie, 'category' => 'recettes', 'parent' => 'col-recettes'],
	['title' => $m['entrees'], 'type' => 'category', 'params' => $pagesCategorie, 'category' => 'entrees', 'parent' => 'col-recettes'],
	['title' => $m['plats'], 'type' => 'category', 'params' => $pagesCategorie, 'category' => 'plats', 'parent' => 'col-recettes'],
	['title' => $m['desserts'], 'type' => 'category', 'params' => $pagesCategorie, 'category' => 'desserts', 'parent' => 'col-recettes'],

	// Colonne 2
	['key' => 'col-potager', 'title' => $m['potager'], 'type' => 'heading', 'parent' => 'decouvrir'],
	['key' => 'tous-legumes', 'title' => $m['tousLeg'], 'type' => 'category', 'category' => 'potager', 'parent' => 'col-potager'],
	['title' => $m['aubergine'], 'type' => 'article', 'article' => 'aubergine', 'parent' => 'col-potager'],
	['title' => $m['tomate'], 'type' => 'article', 'article' => 'la-tomate', 'parent' => 'col-potager'],
	['title' => $m['potimaron'], 'type' => 'article', 'article' => 'le-potimaron', 'parent' => 'col-potager'],
	['title' => $m['poireau'], 'type' => 'article', 'article' => 'le-poireau', 'parent' => 'col-potager'],

	// Colonne 3. Elle porte les pages du template ET celles que Joomla sait
	// rendre tout seul : d'où son intitulé, « Le site », qui vaut pour les
	// deux. Quatre colonnes faisaient un panneau trop large.
	['key' => 'col-site', 'title' => $m['site'], 'type' => 'heading', 'parent' => 'decouvrir'],
	['key' => 'typo', 'title' => $m['typo'], 'type' => 'article', 'article' => 'typographie', 'parent' => 'col-site'],
	['key' => 'tampons', 'title' => $m['tampons'], 'type' => 'article', 'article' => 'les-tampons', 'parent' => 'col-site'],
	['key' => 'connexion', 'title' => $m['connexion'], 'type' => 'url', 'link' => 'index.php?option=com_users&view=login', 'component' => 'com_users', 'parent' => 'col-site'],
	['key' => 'compte', 'title' => $m['compte'], 'type' => 'url', 'link' => 'index.php?option=com_users&view=registration', 'component' => 'com_users', 'parent' => 'col-site'],
	['key' => 'motdepasse', 'title' => $m['motDePasse'], 'type' => 'url', 'link' => 'index.php?option=com_users&view=reset', 'component' => 'com_users', 'parent' => 'col-site'],
	['key' => 'recherche', 'title' => $m['recherche'], 'type' => 'url', 'link' => 'index.php?option=com_finder&view=search', 'component' => 'com_finder', 'parent' => 'col-site'],
	['key' => 'contacts', 'title' => $m['contacts'], 'type' => 'url', 'link' => 'index.php?option=com_contact&view=categories&id=0', 'component' => 'com_contact', 'parent' => 'col-site'],

	];
};
