<?php
/**
 * Les textes de la page d'atterrissage, par langue.
 *
 * POURQUOI CE FICHIER EXISTE. `landing.php` mêlait le texte et le balisage :
 * une seconde langue aurait demandé d'y recopier quatorze modules entiers, et
 * la moindre correction de mise en page se serait faite en double. Les textes
 * sont donc ici, le balisage reste là-bas, et une langue de plus ne coûte
 * qu'un bloc de traductions.
 *
 * L'ANGLAIS EST LA BASE, décision de Cyrille du 25 août : Joomanji vend hors de
 * France, et une page d'atterrissage en français devant un acheteur anglophone
 * ne vend rien. Une langue inconnue retombe donc sur l'anglais, pas sur le
 * français.
 *
 * CES TEXTES ANGLAIS N'ONT PAS ÉTÉ RELUS PAR UN LOCUTEUR NATIF. Ils sont
 * corrects, ce qui ne veut pas dire qu'ils sonnent juste. Sur une page qui
 * vend, une formulation bancale coûte plus qu'une faute : à faire relire avant
 * la mise en vente.
 */

defined('_JEXEC') or die;

return [

	'fr-FR' => [

		// --- Le hero et son sommaire ---------------------------------------
		'heroTitre'   => 'Un template complet, lisible et solide',
		'heroLead'    => 'Simple à prendre en main, complet à l\'usage : tampons, gabarits'
			. ' d\'article, préréglages de mise en page, accessibilité tenue et consentement aux'
			. ' cookies intégré.',
		'heroBtn1'    => 'Voir les tampons',
		'heroBtn2'    => 'La typographie',
		'heroNote'    => 'Tout ce que montre cette page a été posé en un clic par le module de'
			. ' démarrage, et le bouton « Tout réinitialiser » le retire.',

		'noteTitre'   => 'Une démonstration, pas un thème',
		'noteTexte'   => 'Ces pages servent à montrer ce que le template sait faire. Vous pouvez'
			. ' tout effacer et repartir d\'un Joomla vierge.',
		'sommaire'    => 'Sommaire',
		'somTypo'     => 'La typographie',
		'somTampons'  => 'Les tampons',
		'somGabarit'  => 'Le gabarit d\'article',
		'somNative'   => 'Une catégorie en mise en page native',
		'somRech'     => 'La recherche',
		'somConnex'   => 'La connexion',
		'somContacts' => 'Les contacts',
		'somArticle'  => 'Un article, mise en page native',

		// --- Les trois tuiles ----------------------------------------------
		'apercuTitre' => 'Trois entrées pour comprendre',
		'tuile1Titre' => 'Le texte avant tout',
		'tuile1Texte' => 'Titres, listes, citations, tableaux et messages : le template habille le'
			. ' texte courant sans qu\'on ait une classe à écrire.',
		'tuile2Titre' => 'Cinquante-cinq tampons',
		'tuile2Texte' => 'Des blocs tout prêts que l\'éditeur insère en deux clics, du hero à'
			. ' l\'accordéon, et qui restent modifiables à la main.',
		'tuile3Titre' => 'Un gabarit par catégorie',
		'tuile3Texte' => 'Chaque catégorie peut avoir sa propre mise en page d\'article, montée en'
			. ' rangées et en briques, sans une ligne de code.',

		// --- Les quatre cartes à pastille ----------------------------------
		'chantiersTitre' => 'Ce que fait Corpus',
		'chantiersLead'  => 'Quatre outils du template, et chacun remplace une extension qu\'on'
			. ' n\'aura pas à installer, ni à mettre à jour, ni à remplacer le jour où elle'
			. ' s\'arrête.',
		'carte1Titre' => 'La typographie',
		'carte1Texte' => 'Titres, listes, citations, tableaux et messages, habillés sans qu\'on ait'
			. ' une classe à écrire.',
		'carte1Etat'  => 'Plus rien à écrire en CSS',
		'carte2Titre' => 'Les tampons',
		'carte2Texte' => 'Cinquante-cinq blocs tout prêts, insérés depuis l\'éditeur et modifiables'
			. ' à la main.',
		'carte2Etat'  => 'Plus besoin de pagebuilder',
		'carte3Titre' => 'Le gabarit d\'article',
		'carte3Texte' => 'Une mise en page par catégorie, montée en rangées et en briques, sans une'
			. ' ligne de code.',
		'carte3Etat'  => 'Plus besoin d\'un CCK',
		'carte4Titre' => 'Les préréglages',
		'carte4Texte' => 'Quatre ossatures de site, du blog à la page d\'atterrissage, en un seul'
			. ' choix.',
		'carte4Etat'  => 'Plus rien à remonter à la main',

		// --- Les quatre partis pris ----------------------------------------
		'partisTitre' => 'Quatre partis pris',
		'partisAlt'   => 'L\'écran Mise en page de Corpus dans l\'administration de Joomla : à'
			. ' gauche les réglages d\'une bande, à droite le plan des positions de modules.',
		'parti1Titre' => 'L\'accessibilité n\'est pas une option',
		'parti1Texte' => 'Contrastes tenus, ordre de lecture stable, tout au clavier. La couleur'
			. ' n\'est jamais le seul indice, et rien d\'utile n\'est caché par la feuille de style.',
		'parti2Titre' => 'Ce qui marche sous Cassiopeia marche sous Corpus',
		'parti2Texte' => 'Les positions, les classes de vignette, les mots-clés du blog : le'
			. ' vocabulaire de Joomla est repris tel quel, il n\'y a rien à réapprendre.',
		'parti3Titre' => 'Des réglages, pas du code',
		'parti3Texte' => 'La mise en page, les gabarits d\'article et les bandes se règlent dans le'
			. ' style du template. Un préréglage change toute l\'ossature d\'un site en une fois.',
		'parti4Titre' => 'Rien d\'irréversible',
		'parti4Texte' => 'Cette démonstration s\'installe et se retire d\'un clic. Vos réglages'
			. ' d\'avant sont notés, et ils vous sont rendus.',

		// --- Les chiffres --------------------------------------------------
		'chiffresTitre' => 'Vérifié, pas promis',
		'chiffresLead'  => 'Pas d\'années d\'existence ni de millions de téléchargements à'
			. ' afficher. Des contrôles, et ils tournent à chaque livraison.',
		'chiffre1'      => 'Tampons livrés avec le template',
		'chiffre2'      => 'Briques pour composer un gabarit d\'article',
		'chiffre3'      => 'Langues, et autant de préréglages de mise en page',

		// --- Comment c'est construit ---------------------------------------
		'constrTitre' => 'Comment Corpus est construit',
		'constrLead'  => 'Ce qu\'il y a dessous, et ce qu\'il n\'y a pas.',
		'constr1Titre' => 'Ce sur quoi il s\'appuie',
		'constr1Texte' => 'Le Bootstrap livré avec Joomla, pas une copie embarquée : une seule'
			. ' version sur le site, celle que Joomla met à jour. Son JavaScript n\'est chargé que'
			. ' si une extension le réclame. Le reste est une feuille de style maison, écrite en'
			. ' Sass et compilée en un seul fichier.',
		'constr2Titre' => 'Ce qui le fait tenir',
		'constr2Texte' => 'Une seule valeur commande toutes les couleurs : un angle de teinte. Le'
			. ' template en dérive la palette entière, claire et sombre, contrastes compris. La'
			. ' mise en page est en flex et en grille CSS, sans aucun framework JavaScript. Les'
			. ' positions et les classes sont celles de Cassiopeia : rien à réapprendre.',
		'constr3Titre' => 'Ce qui est vérifié avant chaque livraison',
		'constr3Texte' => 'Un script calcule les contrastes sur les 360 teintes possibles et refuse'
			. ' la livraison si un seuil tombe. Un autre compare la feuille de style avant et après'
			. ' chaque refonte, sélecteur par sélecteur ; il a déjà rattrapé deux propriétés'
			. ' déplacées en silence. Les critères RGAA sont cités dans le code, à l\'endroit où'
			. ' ils s\'appliquent.',
		'constr4Titre' => 'Moins de code, moins de surface',
		'constr4Texte' => 'Corpus n\'embarque aucune bibliothèque tierce, aucun constructeur de'
			. ' page, aucune police ni image chargée depuis un autre serveur. Ce qui n\'est pas là'
			. ' ne peut pas servir de porte d\'entrée, et n\'a pas à être corrigé dans l\'urgence.',
		'constr5Titre' => 'Écrit à deux',
		'constr5Texte' => 'Corpus vient de quinze ans passés à intégrer des sites Joomla, pas d\'une'
			. ' école de développement. Ce que l\'intelligence artificielle a apporté n\'est pas la'
			. ' vitesse : c\'est d\'avoir rendu tenable la discipline ci-dessus. Mesurer avant'
			. ' d\'affirmer, et écrire dans le code pourquoi chaque correction existe.',

		// --- Les questions -------------------------------------------------
		'questionsTitre' => 'Les questions qu\'on nous pose',
		'q1'  => 'Puis-je tout effacer ensuite ?',
		'r1'  => 'Oui. Le bouton « Tout réinitialiser » retire les articles, les catégories, les'
			. ' menus et les modules posés par le module de démarrage, et rend vos réglages'
			. ' d\'avant. Rien d\'autre n\'est touché.',
		'q2'  => 'Faut-il savoir coder ?',
		'r2'  => 'Non. Tout ce que montre cette page se règle dans l\'administration de Joomla : le'
			. ' style du template, les paramètres d\'un lien de menu, et le champ « Classe du'
			. ' module ».',
		'q3'  => 'Est-ce que ça marche avec mon site existant ?',
		'r3'  => 'Le principe de Corpus est que ce qui marche sous Cassiopeia marche sous Corpus :'
			. ' mêmes positions, même vocabulaire de classes. Un site existant se retrouve donc en'
			. ' terrain connu.',
		'q4'  => 'Que devient mon contenu si j\'installe la démonstration ?',
		'r4'  => 'Rien ne lui arrive. Le module n\'écrit que ses propres articles, catégories et'
			. ' modules, tous marqués. Il déplace une seule chose, votre page d\'accueil, et il la'
			. ' note pour vous la rendre.',
		'q5'  => 'Puis-je installer les trois scénarios l\'un après l\'autre ?',
		'r5'  => 'Il faut réinitialiser entre deux. Le module refuse une seconde installation'
			. ' par-dessus la première, pour ne pas laisser deux jeux d\'articles impossibles à'
			. ' démêler ensuite.',
		'q6'  => 'Où se règle la mise en page d\'un article ?',
		'r6'  => 'Dans le style du template, onglet « Gabarits d\'article » : on y monte des rangées'
			. ' et des briques, puis on affecte le gabarit à une catégorie. La catégorie « Le'
			. ' potager » montre l\'inverse, la mise en page native de Joomla.',
		'q7'  => 'Comment change-t-on toute l\'ossature du site ?',
		'r7'  => 'Par un préréglage, dans l\'onglet « Mise en page ». Cette page en applique un,'
			. ' `landing`, qui éteint le corps de page et n\'affiche plus que des bandes de modules.'
			. ' Le blog et le magazine en utilisent d\'autres.',
		'q8'  => 'Et l\'accessibilité ?',
		'r8'  => 'Elle est le point de départ, pas une option de fin. Contrastes tenus, ordre de'
			. ' lecture stable, tout au clavier, et rien d\'utile masqué par la feuille de style. La'
			. ' couleur n\'est jamais le seul indice.',
		'q9'  => 'Les images de la démonstration, je peux les garder ?',
		'r9'  => 'Elles viennent de Pexels et servent d\'illustration. Pour un vrai site,'
			. ' remplacez-les : ce sont des photos de démonstration, pas votre matière.',
		'q10' => 'Faut-il Corpus pour que ce module serve ?',
		'r10' => 'Le contenu s\'installe sur n\'importe quel template. Ce qui demande Corpus, c\'est'
			. ' le gabarit d\'article, les préréglages de mise en page et les classes de bande :'
			. ' sans lui, la démonstration s\'installe mais sans son habillage.',

		// --- L'appel final -------------------------------------------------
		'appelTitre' => 'Voir avant de décider',
		'appelTexte' => 'Les mêmes articles existent en blog et en magazine. Installez l\'un puis'
			. ' l\'autre : le contenu ne change pas, seule la mise en page change.',
		'appelBtn1'  => 'Ouvrir la démonstration',
		'appelBtn2'  => 'Voir les tampons',

		// --- Le menu et les deux menus de la page --------------------------
		'menuAccueil'  => 'Corpus',
		'mAper'        => 'Aperçu',
		'mChantiers'   => 'Ce que fait Corpus',
		'mPartis'      => 'Partis pris',
		'mChiffres'    => 'Les chiffres',
		'mConstruction' => 'Construction',
		'mQuestions'   => 'Questions',
		'mEssayer'     => 'Essayer',
		'mTampons'     => 'Les tampons',
		'menuActions'  => 'Corpus : appels à l\'action',
		'menuActionsDesc' => 'Le menu affiché à droite de la navigation sur la page'
			. ' d\'atterrissage. Posé par le module de démarrage, retiré par la réinitialisation.',
		'styleDedie'   => 'Corpus : page d\'atterrissage',
	],

	'en-GB' => [

		'heroTitre'   => 'A complete, readable, solid template',
		'heroLead'    => 'Simple to pick up, complete in use: content blocks, article layouts,'
			. ' layout presets, accessibility held to, and cookie consent built in.',
		'heroBtn1'    => 'See the blocks',
		'heroBtn2'    => 'Typography',
		'heroNote'    => 'Everything on this page was put in place with one click by the start-up'
			. ' module, and the "Reset everything" button takes it away.',

		'noteTitre'   => 'A demonstration, not a theme',
		'noteTexte'   => 'These pages exist to show what the template can do. You can wipe it all'
			. ' and go back to a clean Joomla.',
		'sommaire'    => 'On this page',
		'somTypo'     => 'Typography',
		'somTampons'  => 'Content blocks',
		'somGabarit'  => 'The article layout',
		'somNative'   => 'A category in Joomla\'s own layout',
		'somRech'     => 'Search',
		'somConnex'   => 'Login',
		'somContacts' => 'Contacts',
		'somArticle'  => 'An article in Joomla\'s own layout',

		'apercuTitre' => 'Three ways in',
		'tuile1Titre' => 'Text first',
		'tuile1Texte' => 'Headings, lists, quotations, tables and messages: the template styles'
			. ' running text without a single class to write.',
		'tuile2Titre' => 'Fifty-five content blocks',
		'tuile2Texte' => 'Ready-made blocks the editor drops in with two clicks, from the hero to'
			. ' the accordion, and which stay editable by hand.',
		'tuile3Titre' => 'One layout per category',
		'tuile3Texte' => 'Each category can have its own article layout, built from rows and'
			. ' bricks, without a line of code.',

		'chantiersTitre' => 'What Corpus does',
		'chantiersLead'  => 'Four tools in the template, each one replacing an extension you will'
			. ' not have to install, nor update, nor replace the day it stops.',
		'carte1Titre' => 'Typography',
		'carte1Texte' => 'Headings, lists, quotations, tables and messages, styled without a single'
			. ' class to write.',
		'carte1Etat'  => 'No CSS left to write',
		'carte2Titre' => 'Content blocks',
		'carte2Texte' => 'Fifty-five ready-made blocks, dropped in from the editor and editable by'
			. ' hand.',
		'carte2Etat'  => 'No page builder needed',
		'carte3Titre' => 'The article layout',
		'carte3Texte' => 'One layout per category, built from rows and bricks, without a line of'
			. ' code.',
		'carte3Etat'  => 'No CCK needed',
		'carte4Titre' => 'Layout presets',
		'carte4Texte' => 'Four site structures, from the blog to the landing page, in a single'
			. ' choice.',
		'carte4Etat'  => 'Nothing left to rebuild by hand',

		'partisTitre' => 'Four commitments',
		'partisAlt'   => 'The Corpus layout screen in the Joomla administration: the settings of a'
			. ' row on the left, the map of module positions on the right.',
		'parti1Titre' => 'Accessibility is not an option',
		'parti1Texte' => 'Contrast held, reading order stable, everything reachable by keyboard.'
			. ' Colour is never the only cue, and nothing useful is hidden by the stylesheet.',
		'parti2Titre' => 'What works under Cassiopeia works under Corpus',
		'parti2Texte' => 'Positions, thumbnail classes, blog keywords: Joomla\'s own vocabulary is'
			. ' kept as it is, so there is nothing to relearn.',
		'parti3Titre' => 'Settings, not code',
		'parti3Texte' => 'Layout, article layouts and rows are set in the template style. One'
			. ' preset changes a whole site structure at once.',
		'parti4Titre' => 'Nothing irreversible',
		'parti4Texte' => 'This demonstration installs and removes itself with one click. Your'
			. ' earlier settings are noted, and they are given back to you.',

		'chiffresTitre' => 'Checked, not claimed',
		'chiffresLead'  => 'No years in business, no millions of downloads to show. Checks, and'
			. ' they run at every release.',
		'chiffre1'      => 'Content blocks shipped with the template',
		'chiffre2'      => 'Bricks to compose an article layout',
		'chiffre3'      => 'Languages, and as many layout presets',

		'constrTitre' => 'How Corpus is built',
		'constrLead'  => 'What is underneath, and what is not.',
		'constr1Titre' => 'What it rests on',
		'constr1Texte' => 'The Bootstrap that ships with Joomla, not an embedded copy: one version'
			. ' on the site, the one Joomla updates. Its JavaScript loads only when an extension'
			. ' asks for it. The rest is an in-house stylesheet, written in Sass and compiled into'
			. ' a single file.',
		'constr2Titre' => 'What holds it together',
		'constr2Texte' => 'A single value drives every colour: a hue angle. The template derives'
			. ' the whole palette from it, light and dark, contrast included. Layout is flex and'
			. ' CSS grid, with no JavaScript framework. Positions and classes are Cassiopeia\'s:'
			. ' nothing to relearn.',
		'constr3Titre' => 'What is checked before every release',
		'constr3Texte' => 'One script computes contrast across all 360 possible hues and refuses'
			. ' the release if a threshold drops. Another compares the stylesheet before and after'
			. ' each rework, selector by selector; it has already caught two properties that had'
			. ' moved silently. Accessibility criteria are quoted in the code, where they apply.',
		'constr4Titre' => 'Less code, less surface',
		'constr4Texte' => 'Corpus embeds no third-party library, no page builder, no font or image'
			. ' loaded from another server. What is not there cannot become a way in, and does not'
			. ' have to be patched in a hurry.',
		'constr5Titre' => 'Written by two',
		'constr5Texte' => 'Corpus comes from fifteen years of building Joomla sites, not from a'
			. ' development degree. What artificial intelligence brought is not speed: it is what'
			. ' made the discipline above sustainable. Measure before claiming, and write in the'
			. ' code why each fix exists.',

		'questionsTitre' => 'Questions we get asked',
		'q1'  => 'Can I wipe it all afterwards?',
		'r1'  => 'Yes. The "Reset everything" button removes the articles, categories, menus and'
			. ' modules the start-up module created, and gives your earlier settings back. Nothing'
			. ' else is touched.',
		'q2'  => 'Do I need to know how to code?',
		'r2'  => 'No. Everything on this page is set in the Joomla administration: the template'
			. ' style, the settings of a menu item, and the "Module Class" field.',
		'q3'  => 'Will it work with my existing site?',
		'r3'  => 'The principle of Corpus is that what works under Cassiopeia works under Corpus:'
			. ' same positions, same class vocabulary. An existing site therefore lands on familiar'
			. ' ground.',
		'q4'  => 'What happens to my content if I install the demonstration?',
		'r4'  => 'Nothing happens to it. The module only writes its own articles, categories and'
			. ' modules, all marked. It moves one single thing, your home page, and it notes it in'
			. ' order to give it back.',
		'q5'  => 'Can I install the three scenarios one after another?',
		'r5'  => 'You have to reset in between. The module refuses a second install on top of the'
			. ' first, so as not to leave two sets of articles impossible to tell apart afterwards.',
		'q6'  => 'Where is an article layout set?',
		'r6'  => 'In the template style, under "Article layouts": you build rows and bricks there,'
			. ' then assign the layout to a category. The "Kitchen garden" category shows the'
			. ' opposite, Joomla\'s own layout.',
		'q7'  => 'How do you change a whole site structure?',
		'r7'  => 'With a preset, under the "Layout" tab. This page applies one, `landing`, which'
			. ' switches the page body off and shows nothing but rows of modules. The blog and the'
			. ' magazine use others.',
		'q8'  => 'What about accessibility?',
		'r8'  => 'It is the starting point, not a finishing option. Contrast held, reading order'
			. ' stable, everything reachable by keyboard, and nothing useful hidden by the'
			. ' stylesheet. Colour is never the only cue.',
		'q9'  => 'Can I keep the demonstration images?',
		'r9'  => 'They come from Pexels and serve as illustration. For a real site, replace them:'
			. ' they are demonstration photographs, not your own material.',
		'q10' => 'Do I need Corpus for this module to be useful?',
		'r10' => 'The content installs on any template. What needs Corpus is the article layout,'
			. ' the layout presets and the row classes: without it, the demonstration installs but'
			. ' without its styling.',

		'appelTitre' => 'Look before you decide',
		'appelTexte' => 'The same articles exist as a blog and as a magazine. Install one, then the'
			. ' other: the content does not change, only the layout does.',
		'appelBtn1'  => 'Open the demonstration',
		'appelBtn2'  => 'See the blocks',

		'menuAccueil'  => 'Corpus',
		'mAper'        => 'Overview',
		'mChantiers'   => 'What Corpus does',
		'mPartis'      => 'Commitments',
		'mChiffres'    => 'Figures',
		'mConstruction' => 'How it is built',
		'mQuestions'   => 'Questions',
		'mEssayer'     => 'Try it',
		'mTampons'     => 'Content blocks',
		'menuActions'  => 'Corpus: calls to action',
		'menuActionsDesc' => 'The menu shown to the right of the navigation on the landing page.'
			. ' Created by the start-up module, removed on reset.',
		'styleDedie'   => 'Corpus: landing page',
	],
];
