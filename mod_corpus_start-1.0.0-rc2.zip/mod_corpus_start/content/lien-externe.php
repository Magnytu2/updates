<?php
/**
 * Un lien qui sort du site : nouvel onglet, pictogramme, et avertissement.
 *
 * Demande de Cyrille du 26 août 2026, pour les réseaux sociaux de la barre et
 * pour les liens du pied de page. Tous sortent du site ; aucun ne pointe une
 * page de la démonstration.
 *
 * DEUX CHOSES SEULEMENT, PARCE QUE LE TEMPLATE FAIT LA TROISIÈME.
 *
 * `target="_blank"` ouvre l'onglet. `rel="noopener"` va avec, toujours : sans
 * lui, la page ouverte reçoit une référence vers celle qui l'a ouverte, par
 * `window.opener`, et peut la faire naviguer ailleurs. C'est la faille du
 * « tabnabbing ». Les navigateurs récents l'appliquent d'office, mais on ne
 * livre pas un template qui dépend de la version du navigateur du visiteur.
 *
 * LE PICTOGRAMME, ON NE LE POSE PAS. Première version du 26 août 2026 : j'y
 * ajoutais un `<svg><use href="#i-lien"></svg>`. Cyrille a vu le résultat
 * aussitôt, deux dessins à la suite derrière chaque intitulé, dont un maillon
 * de chaîne écrasé.
 *
 * `_typographie.scss` de Corpus, ligne 91, pose déjà le pictogramme sur
 * `a[target="_blank"]`, en `::after`, avec un masque colorié par
 * `currentColor` : il suit donc le thème, la teinte et le survol, ce qu'un
 * `<svg>` en dur ne sait pas faire. Le commentaire du template dit exactement
 * pourquoi il travaille ainsi : « Un <svg> posé à la main serait oublié un
 * jour ou l'autre ». Il avait raison avant même que je le lise.
 *
 * LA LEÇON, ET ELLE VAUT POUR TOUT CE FICHIER : regarder ce que Corpus fait
 * déjà avant d'écrire du balisage. Le module habille un template qu'il connaît.
 *
 * L'AVERTISSEMENT TEXTUEL RESTE À NOTRE CHARGE. Une icône ne prévient personne
 * au lecteur d'écran, et le RGAA (13.2, WCAG 3.2.5) exige de prévenir avant
 * d'ouvrir une fenêtre : le bouton « Précédent » cesse de fonctionner. La
 * classe est `visuellement-cache`, celle de Corpus, et non `visually-hidden`
 * de Bootstrap : c'est celle que le template nomme dans ce même commentaire.
 */

defined('_JEXEC') or die;

/*
 * L'AVERTISSEMENT, DANS LES QUATRE LANGUES DU MODULE. Une langue inconnue
 * retombe sur l'anglais.
 *
 * La formule est celle que Joomla emploie lui-même dans son cœur, et non une
 * invention : « (opens in a new window) ». Un lecteur d'écran l'annonce à la
 * suite de l'intitulé, ce qui donne « Facebook, nouvelle fenêtre ».
 */
$avertissements = [
	'fr-FR' => 'nouvelle fenêtre',
	'en-GB' => 'opens in a new window',
	'de-DE' => 'öffnet in einem neuen Fenster',
	'es-ES' => 'se abre en una ventana nueva',
];

/**
 * @param  string $url       L'adresse, complète, protocole compris.
 * @param  string $intitule  Le texte du lien. Il est écrit tel quel : les
 *                           appelants ne passent que leurs propres libellés.
 * @param  string $code      La langue de la page, pour l'avertissement.
 *
 * @return string
 */
return static function (string $url, string $intitule, string $code = 'en-GB') use ($avertissements): string {

	$avert = $avertissements[$code] ?? $avertissements['en-GB'];

	return '<a href="' . $url . '" target="_blank" rel="noopener">'
		. $intitule
		. '<span class="visuellement-cache"> (' . $avert . ')</span>'
		. '</a>';
};
