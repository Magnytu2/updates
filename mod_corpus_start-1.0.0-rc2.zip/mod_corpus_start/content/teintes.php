<?php
/**
 * Les quatre préréglages de couleur de Corpus, recopiés.
 *
 * POURQUOI RECOPIER PLUTÔT QUE LIRE LE TEMPLATE. Les préréglages vivent dans
 * `templates/corpus/etc/presets/styles/*.nvp`, qui n'appartiennent pas à ce
 * module : il s'installe sur des sites où Corpus peut manquer, ou être d'une
 * version antérieure. Un chemin en dur vers un fichier d'un autre paquet est la
 * panne qui n'arrive que chez le client.
 *
 * CE QU'UN PRÉRÉGLAGE DE COULEUR CONTIENT, ET CE QU'IL NE CONTIENT PAS. Corpus
 * n'a plus qu'UN réglage de couleur, `styleTeinte`, un ANGLE en degrés dont la
 * feuille dérive l'accent, les fonds et les filets. Les quatre couleurs de
 * message l'accompagnent, et elles ne suivent pas la teinte : elles gardent au
 * moins 25 degrés d'écart avec elle, sinon un bouton d'action ressemble à une
 * alerte. Les valeurs ci-dessous sont celles que Corpus a mesurées le 19 août
 * 2026, chacune à 4,5:1 au moins sur son fond pâle. On ne les invente pas.
 *
 * `styleTeinte` EST COMPILÉ, pas lu à chaque page : il finit dans
 * `media/templates/site/corpus/css/custom-styles/<id>.css`. Écrire la valeur en
 * base ne suffit donc pas, il faut redemander la feuille au template. C'est ce
 * que fait `regenererStyleCorpus()`, une fois, à la toute fin de l'installation.
 *
 * QUELLE DÉMONSTRATION PORTE QUELLE COULEUR, décision de Cyrille du 26 août
 * 2026 : un panaché, pour qu'un visiteur qui passe d'un site à l'autre voie
 * quatre sites et non quatre fois le même.
 *
 *     blog         rouge profond
 *     magazine     bleu Joomla
 *     landing      olive, la teinte propre de Corpus
 *     multilingue  orange
 */

defined('_JEXEC') or die;

return [

	// Teinte 214 deg. Info 180 deg 5,08:1 | succès 144 deg 5,44:1
	// | alerte 36 deg 5,30:1 | erreur 357 deg 6,23:1
	'bleu' => [
		'styleTeinte'     => '214',
		'styleEtatInfo'   => '#176e6e',
		'styleEtatSucces' => '#1f6b3d',
		'styleEtatAlerte' => '#8a5300',
		'styleEtatErreur' => '#a02127',
	],

	// Teinte 90 deg. Info 205 deg 6,11:1 | succès 144 deg 5,44:1
	// | alerte 36 deg 5,30:1 | erreur 357 deg 6,23:1
	'olive' => [
		'styleTeinte'     => '90',
		'styleEtatInfo'   => '#1c5a86',
		'styleEtatSucces' => '#1f6b3d',
		'styleEtatAlerte' => '#8a5300',
		'styleEtatErreur' => '#a02127',
	],

	// Teinte 30 deg. L'alerte descend à 58 deg : à 36, elle aurait été à six
	// degrés de la teinte, donc indiscernable d'un bouton d'action.
	'orange' => [
		'styleTeinte'     => '30',
		'styleEtatInfo'   => '#1c5a86',
		'styleEtatSucces' => '#1f6b3d',
		'styleEtatAlerte' => '#696500',
		'styleEtatErreur' => '#a02127',
	],

	// Teinte 332 deg. Info 205 deg 6,11:1 | succès 144 deg 5,44:1
	// | alerte 36 deg 5,30:1 | erreur 357 deg 6,23:1
	'rouge' => [
		'styleTeinte'     => '332',
		'styleEtatInfo'   => '#1c5a86',
		'styleEtatSucces' => '#1f6b3d',
		'styleEtatAlerte' => '#8a5300',
		'styleEtatErreur' => '#a02127',
	],
];
