<?php
/**
 * Le resserrement du sélecteur de langue, à droite du logo.
 *
 * CE QUI A ÉTÉ MESURÉ, le 26 août 2026, après que Cyrille a trouvé l'écart
 * « grand, bizarre ». Il l'est : entre les deux drapeaux, larges de 17 pixels
 * chacun, il y en avait 43. Ils viennent de trois couches empilées, aucune
 * fautive en elle-même.
 *
 *     8 px   `gap` du <ul>, posé par `.mod-languages__list` de Corpus
 *     16 px  marges du <li>, 8 de chaque côté, posées par mod_languages de Joomla
 *     16 px  remplissage du <a>, 8 de chaque côté, posé par Corpus
 *
 * ON NE TOUCHE PAS AU REMPLISSAGE DU LIEN, et c'est important : ce sont ces
 * 8 pixels qui portent la zone cliquable à 24 px de côté, le plancher de
 * WCAG 2.5.8. Un drapeau de Joomla mesure 16 x 11 px ; sans eux, la cible
 * serait deux fois trop petite, ce qui se paie surtout au doigt sur téléphone.
 *
 * On retire donc les deux couches qui ne servent qu'à espacer : les marges du
 * <li> et l'écart du <ul>. Les deux zones cliquables se touchent alors, et les
 * drapeaux se retrouvent à 16 pixels l'un de l'autre. Ils se lisent comme une
 * paire, ce qu'ils sont.
 *
 * POURQUOI CE N'EST PAS DÉJÀ LE CAS. Corpus soigne ce module, mais dans UNE
 * zone : `.navigation__droite`, à droite du menu, où il en fait un vrai
 * interrupteur segmenté avec cadre et pastille. Le sélecteur a quitté cette
 * zone le 26 août, parce qu'elle était trop étroite ; dans la zone des outils
 * d'en-tête, seules les règles générales s'appliquent.
 *
 * LE VRAI CORRECTIF EST DANS LE TEMPLATE, une règle de `_modules.scss` qui
 * étende à `.entete__outils` le traitement déjà écrit pour `.navigation__droite`.
 * Tant qu'elle n'existe pas, le module ne peut pas s'appuyer dessus. Ceci est
 * une dette, et elle est notée comme telle.
 *
 * LE CHAMP EST PRÉVU POUR ÇA. `styleCssPerso` est un réglage de style comme les
 * autres : Corpus le compile dans la feuille du style, il est sauvegardé avant
 * d'être écrit, et la réinitialisation rend ce qu'il contenait. Rien n'est
 * injecté dans le HTML.
 */

defined('_JEXEC') or die;

return "/* mod_corpus_start : le sélecteur de langue dans les outils d'en-tête.\n"
	. "   À retirer le jour où Corpus porte la règle lui-même. */\n"
	. ".entete__outils .mod-languages__list { gap: 0; }\n"
	. ".entete__outils .mod-languages__list > li { margin: 0; }\n";
