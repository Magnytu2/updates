<?php
/**
 * Les liens entre les quatre sites de démonstration.
 *
 * Chaque démonstration vit sur son propre Joomla : quatre sous-domaines, un
 * scénario chacun. Sans passerelle, un visiteur qui arrive sur le blog ne sait
 * pas que le magazine existe.
 *
 * TROIS LIENS, JAMAIS QUATRE, demande de Cyrille du 26 août 2026 : le site où
 * l'on se trouve ne se met pas en lien vers lui-même. C'est le scénario passé
 * en argument qui décide lequel des quatre disparaît.
 *
 * OÙ ILS VONT : la zone à droite du logo, `social-links`, JUSTE AVANT le
 * sélecteur de langue. L'ordre est obtenu sans réglage d'ordonnancement : les
 * modules d'une même position sortent dans l'ordre où ils ont été créés, et le
 * sélecteur est créé en dernier, après la boucle des langues.
 *
 * CE BLOC PARTIRA CHEZ LES CLIENTS SI ON N'Y PREND PAS GARDE. Le module se
 * vend ; trois liens vers les démonstrations de Joomanji sur le site d'un
 * client n'ont rien à y faire. Le pied de page pose déjà la question et Cyrille
 * l'a tranchée pour lui ; celle-ci reste ouverte. La réponse propre est un
 * réglage du module, « mode vitrine », éteint par défaut.
 */

defined('_JEXEC') or die;

/*
 * LES QUATRE SITES. L'adresse est écrite en entier, avec le protocole : ces
 * liens sortent du site, un chemin relatif n'aurait aucun sens.
 *
 * L'INTITULÉ EST COURT PAR NÉCESSITÉ. La zone partage sa ligne avec le nom du
 * site à gauche et les drapeaux à droite ; « Une page d'atterrissage » y ferait
 * passer les drapeaux à la ligne, ce qu'on vient précisément de corriger.
 */
$sites = [
	'blog' => [
		'url'   => 'https://blog.joomanji.eu/',
		'fr-FR' => 'Blog',
		'en-GB' => 'Blog',
	],
	'magazine' => [
		'url'   => 'https://magazine.joomanji.eu/',
		'fr-FR' => 'Magazine',
		'en-GB' => 'Magazine',
	],
	'landing' => [
		'url'   => 'https://landing.joomanji.eu/',
		'fr-FR' => 'Landing',
		'en-GB' => 'Landing',
	],
	'multilingue' => [
		'url'   => 'https://multilang.joomanji.eu/',
		'fr-FR' => 'Multilingue',
		'en-GB' => 'Multilingual',
	],
];

$libelles = [
	'fr-FR' => ['titre' => 'Démonstrations', 'aria' => 'Les autres démonstrations'],
	'en-GB' => ['titre' => 'Demos',          'aria' => 'The other demos'],
];

/**
 * @param  string $code      La langue du contenu affiché.
 * @param  string $courant   Le scénario installé sur CE site, à ne pas lier.
 * @param  string $langueMod La langue du module, `*` pour toutes.
 *
 * @return array Un module, ou aucun si la liste est vide.
 */
return static function (string $code, string $courant = '', string $langueMod = '*') use ($sites, $libelles): array {

	$l = $libelles[$code] ?? $libelles['en-GB'];

	/*
	 * LES STYLES SONT EN LIGNE, ET C'EST UNE DETTE ASSUMÉE, la même que celle
	 * de la barre du haut. Corpus ne déclare pas de classe pour une liste
	 * horizontale dans l'en-tête, et `_typographie.scss` pose un
	 * `li + li { margin-top: var(--e-1) }` global qui décale le deuxième lien
	 * d'un cran vers le bas. `margin:0` sur chaque `<li>` le neutralise.
	 *
	 * Le vrai correctif est dans le template : une classe d'en-tête, et `li`
	 * ajouté à la remise à zéro des marges. Tant qu'elle n'existe pas, le
	 * module ne peut pas s'appuyer dessus.
	 */
	$styleListe = 'display:flex;align-items:center;flex-wrap:wrap;gap:.25rem .75rem;'
		. 'margin:0;padding:0;list-style:none';
	$styleItem  = 'display:flex;align-items:center;margin:0';

	$liens = '';

	foreach ($sites as $cle => $site) {
		if ($cle === $courant) {
			continue;
		}

		$liens .= '<li style="' . $styleItem . '">'
			. '<a href="' . $site['url'] . '">' . ($site[$code] ?? $site['en-GB']) . '</a>'
			. '</li>';
	}

	if ($liens === '') {
		return [];
	}

	return [
		[
			'title'     => $l['titre'],
			'module'    => 'mod_custom',
			'position'  => 'social-links',
			'showtitle' => 0,
			'pages'     => 'all',
			'language'  => $langueMod,
			'content'   => '<ul aria-label="' . $l['aria'] . '" style="' . $styleListe . '">'
				. $liens . '</ul>',
			'params'    => ['prepare_content' => 1],
		],
	];
};
