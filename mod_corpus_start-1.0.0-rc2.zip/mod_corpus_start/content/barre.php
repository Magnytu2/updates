<?php
/**
 * La barre d'information, commune aux quatre scénarios.
 *
 * La bande fine au-dessus de l'en-tête : les réseaux d'un côté, un numéro de
 * l'autre. Corpus la porte déjà, avec DEUX positions déclarées, `topbar-left`
 * et `topbar-right`, et deux conteneurs en vis-à-vis dans `index.php`. Rien à
 * inventer : il suffit d'y publier deux modules.
 *
 * Même forme que `pied.php` : une fermeture qui fabrique les modules pour une
 * langue, parce que le scénario multilingue en demande un jeu par langue.
 *
 * LE CÔTÉ DROIT EST DÉCLARÉ, PAS ESPÉRÉ. Le gabarit du template le dit :
 * « deux côtés déclarés, et non deux modules qu'on espère voir tomber du bon
 * côté ». Un module publié à droite reste à droite même si la gauche est vide.
 */

defined('_JEXEC') or die;

return static function (string $code, string $langueModule = '*'): array {

	/*
	 * LES COMPTES SOCIAUX SONT CEUX DU PROJET JOOMLA, relevés sur la page
	 * d'accueil de joomla.org le 25 août 2026, dans ses propres liens.
	 *
	 * Pourquoi les siens et pas des liens d'exemple : un `href="#"` est un lien
	 * mort, et un compte inventé emmène le visiteur nulle part. Ceux-ci
	 * existent, ils sont nommés pour ce qu'ils sont, et ils vont dans le même
	 * sens que le pied de site, qui pointe déjà vers le projet.
	 *
	 * Quatre suffisent dans une bande fine. Joomla en tient sept.
	 *
	 * MATTERMOST A REMPLACÉ BLUESKY LE 26 AOÛT 2026, demande de Cyrille. Ce
	 * n'est pas un réseau social de plus : c'est la messagerie de travail du
	 * projet, celle où l'on trouve quelqu'un quand on est bloqué. Sur une
	 * démonstration destinée à des intégrateurs, elle vaut mieux qu'un fil
	 * d'actualité.
	 *
	 * L'ADRESSE EST LA COURTE, `joom.la/chat`, et c'est délibéré : c'est celle
	 * que la documentation de Joomla donne, et elle survit à un changement
	 * d'hébergeur du serveur, ce que ne fait pas l'adresse complète en
	 * `joomlacommunity.cloud.mattermost.com`.
	 */
	$reseaux = [
		'Facebook'   => 'https://www.facebook.com/joomla',
		'LinkedIn'   => 'https://www.linkedin.com/company/joomla',
		'YouTube'    => 'https://www.youtube.com/user/joomla',
		'GitHub'     => 'https://github.com/joomla',
		'Mattermost' => 'https://joom.la/chat',
	];

	/*
	 * LE NUMÉRO EST FAUX, ET IL EST FAUX COMME IL FAUT.
	 *
	 * `01 99 00 12 34` appartient à la tranche que l'ARCEP réserve à la fiction,
	 * `0X 99 00 00 00` à `0X 99 00 99 99` : aucun opérateur ne peut l'attribuer,
	 * donc personne ne sera jamais dérangé par une démonstration.
	 *
	 * Prendre un numéro « qui a l'air faux » au hasard ne donne pas cette
	 * garantie : la plupart sont attribuables, et certains sont attribués.
	 */
	$numero    = '01 99 00 12 34';
	$numeroTel = '+33199001234';

	$libelles = [
		'fr-FR' => ['suivre' => 'Suivre Joomla', 'joindre' => 'Renseignements'],
		'en-GB' => ['suivre' => 'Follow Joomla', 'joindre' => 'Enquiries'],
		'de-DE' => ['suivre' => 'Joomla folgen', 'joindre' => 'Auskunft'],
		'es-ES' => ['suivre' => 'Seguir a Joomla', 'joindre' => 'Información'],
	];

	$l = $libelles[$code] ?? $libelles['en-GB'];

	/*
	 * L'ALIGNEMENT, ET POURQUOI IL EST ÉCRIT ICI PLUTÔT QUE LAISSÉ AU TEMPLATE.
	 *
	 * `.barre-info ul` de Corpus est déjà en `flex` centré. Ça ne suffisait pas,
	 * et c'est mesuré sur le banc le 25 août : les entrées tombaient à 10 puis
	 * 12 pixels du haut, et les deux côtés de la barre ne faisaient pas la même
	 * hauteur, trente à gauche contre vingt-six à droite.
	 *
	 * LA CAUSE EST LE CONTENEUR DU MODULE. `index.php` inclut les deux positions
	 * avec le chrome `no-card`, qui enveloppe chaque module dans un
	 * `<div class="module">`. C'est CE div qui est l'item du flex de la barre,
	 * pas ma liste : le centrage de la barre agit sur lui, et ce qu'il contient
	 * retombe sur le flux normal. Un `<li>` reste alors un `list-item`, et le
	 * `<p>` de droite un bloc où le pictogramme pend par son `vertical-align`.
	 *
	 * On ne peut pas retirer ce conteneur depuis un module : le chrome est
	 * demandé par le gabarit du template. On rend donc chaque contenu centré
	 * PAR LUI-MÊME, ce qui ne dépend plus de ce qui l'enveloppe.
	 *
	 * LE `margin:0` DES ENTRÉES N'EST PAS DU ZÈLE, et c'est la seconde moitié du
	 * défaut, trouvée le 25 août après un premier correctif incomplet. Le
	 * premier lien restait plus haut que les autres, de deux pixels.
	 *
	 * `_typographie.scss` du template pose, ligne 61, une règle GLOBALE :
	 * `li + li { margin-top: var(--e-1) }`. Elle épargne le premier de la liste
	 * et s'applique aux suivants. Dans un conteneur centré, une marge haute de
	 * quatre pixels décale l'entrée de deux vers le bas : d'où les dix pixels du
	 * premier lien et les douze des autres, mesurés à l'écran.
	 *
	 * La barre remet déjà les marges à zéro, mais seulement sur `p`, `ul`, `ol`
	 * et `div` : `li` manque à la liste. C'EST LÀ LE CORRECTIF DE FOND, un mot à
	 * ajouter dans `.barre-info :is(...)`.
	 *
	 * Ces styles en dur sont une dette, comme les deux du pied de page. LE VRAI
	 * CORRECTIF EST DANS CORPUS, une règle qui centre le contenu des modules de
	 * la barre plutôt que leur seul conteneur.
	 */
	$styleListe = 'display:flex;align-items:center;flex-wrap:wrap;gap:.25rem .75rem;'
		. 'margin:0;padding:0;list-style:none';
	$styleItem  = 'display:flex;align-items:center;margin:0';

	/*
	 * CHAQUE RÉSEAU SORT DU SITE : nouvel onglet, pictogramme de lien,
	 * avertissement pour lecteur d'écran. Voir `lien-externe.php`.
	 */
	$externe = require __DIR__ . '/lien-externe.php';

	$liens = '';

	foreach ($reseaux as $nom => $url) {
		$liens .= '<li style="' . $styleItem . '">' . $externe($url, $nom, $code) . '</li>';
	}

	$gauche = '<ul aria-label="' . $l['suivre'] . '" style="' . $styleListe . '">' . $liens . '</ul>';

	/*
	 * LE PICTOGRAMME VIENT DU JEU DE CORPUS. `index.php` pose le sprite sur
	 * chaque page, donc `<use href="#i-telephone">` trouve son symbole. Il est
	 * masqué aux lecteurs d'écran : le numéro est déjà là, en toutes lettres, et
	 * l'intitulé le nomme.
	 *
	 * Le paragraphe est en flex pour la même raison que la liste. En prime, le
	 * `vertical-align: -4px` que la classe `.i` pose sur le SVG cesse d'agir
	 * dans un conteneur flex : le pictogramme se centre au lieu de descendre.
	 */
	$droite = '<p style="display:flex;align-items:center;gap:.4em;margin:0">'
		. '<svg class="i" aria-hidden="true" focusable="false"><use href="#i-telephone" /></svg>'
		. '<span>' . $l['joindre'] . '</span>'
		. '<a href="tel:' . $numeroTel . '">' . $numero . '</a></p>';

	return [
		[
			'title'     => 'Réseaux',
			'module'    => 'mod_custom',
			'position'  => 'topbar-left',
			'showtitle' => 0,
			'pages'     => 'all',
			'language'  => $langueModule,
			'content'   => $gauche,
			'params'    => ['prepare_content' => 1],
		],
		[
			'title'     => 'Nous joindre',
			'module'    => 'mod_custom',
			'position'  => 'topbar-right',
			'showtitle' => 0,
			'pages'     => 'all',
			'language'  => $langueModule,
			'content'   => $droite,
			'params'    => ['prepare_content' => 1],
		],
	];
};
