<?php
/**
 * Contenu commun à tous les scénarios de démarrage.
 *
 * Ce qui ne change pas d'une mise en page à l'autre : les catégories, les
 * champs de la recette, le gabarit d'article, et les quatorze articles.
 * Chaque scénario ajoute par-dessus ce qui lui est propre, à savoir la page
 * d'accueil, le menu et les modules. Voir blog.php.
 *
 * Tableau de données pur, aucune logique.
 */

defined('_JEXEC') or die;

return [
	'categories' => [
		'recettes' => ['title' => 'Recettes', 'alias' => 'recettes', 'parent' => null],
		'entrees'  => ['title' => 'Entrées', 'alias' => 'entrees', 'parent' => 'recettes'],
		'plats'    => ['title' => 'Plats', 'alias' => 'plats', 'parent' => 'recettes'],
		'desserts' => ['title' => 'Desserts', 'alias' => 'desserts', 'parent' => 'recettes'],
		'potager'  => ['title' => 'Le potager', 'alias' => 'potager', 'parent' => null],
		'template' => ['title' => 'Le template', 'alias' => 'le-template', 'parent' => null],
	],

	/*
	 * LE TITRE QUI OUVRE LES ÉTAPES D'UNE RECETTE.
	 *
	 * IL EST ICI, ET NON DANS UN FICHIER DE LANGUE, depuis le 26 août 2026.
	 * Il passait par `Text::_('MOD_CORPUS_START_STEPS')`, donc par la langue de
	 * l'ADMINISTRATION au moment du clic : Cyrille, qui travaille avec une
	 * administration en anglais, s'est retrouvé avec « Method » en tête d'une
	 * recette française, écrit en dur dans l'article et impossible à rattraper
	 * autrement qu'à la main.
	 *
	 * Un titre inscrit dans le corps d'un article est du CONTENU. Les quatorze
	 * recettes sont en français et en « Toutes langues » : leur titre l'est
	 * aussi, et il ne doit dépendre de rien d'autre.
	 */
	'titreEtapes' => 'Les étapes',

	'fieldgroup' => ['title' => 'En bref'],

	// Le gabarit « Recette » s'affecte à « Recettes » ; les sous-catégories en
	// héritent par la remontée d'arbre de Corpus.
	//
	// « natif » n'est PAS une précaution inutile. Une catégorie laissée sur
	// « Hériter » et qui n'hérite de rien retombe sur le PREMIER gabarit
	// déclaré : le potager prenait donc la mise en page des recettes. On lui
	// affecte explicitement le gabarit natif de Joomla.
	'gabarit' => [
		'categorie' => 'recettes',
		'natif'     => ['potager', 'template'],
	],

	'fields' => [
		'preparation' => ['title' => 'Préparation', 'type' => 'text', 'group' => true, 'suffix' => ' min'],
		'cuisson'     => ['title' => 'Cuisson', 'type' => 'text', 'group' => true, 'suffix' => ' min'],
		'repos'       => ['title' => 'Repos', 'type' => 'text', 'group' => true, 'suffix' => ' min'],
		'pour'        => ['title' => 'Pour', 'type' => 'text', 'group' => true, 'suffix' => ' personnes'],
		'difficulte'  => ['title' => 'Difficulté', 'type' => 'list', 'group' => true, 'options' => ['Facile', 'Moyen', 'Haute']],
		'cout'        => ['title' => 'Coût', 'type' => 'list', 'group' => true, 'options' => ['Facile', 'Moyen', 'Haute']],
		'conseil-du-chef'   => ['title' => 'Conseil du chef', 'type' => 'textarea', 'group' => false],
		'liste-ingredients' => ['title' => "Liste d'ingrédients", 'type' => 'textarea', 'group' => false],
	],

	'articles' => [
		// --- Les 6 recettes ------------------------------------------------
		[
			'title'    => 'Velouté de potimaron',
			'alias'    => 'veloute-de-potimaron',
			'image'    => 'veloute-de-potimaron.webp',
			'category' => 'entrees',
			'intro'    => "<p>Un velouté d'automne tout simple, la peau du potimaron se mixe avec la chair : pas d'épluchage.</p>",
			'steps'    => [
				"Couper le potimaron en morceaux sans le peler, émincer l'oignon.",
				"Faire suer l'oignon 5 minutes, ajouter le potimaron et le bouillon.",
				"Cuire 20 minutes à couvert, jusqu'à ce que le potimaron s'écrase à la fourchette.",
				"Mixer, ajouter la crème, rectifier l'assaisonnement.",
			],
			'fields' => [
				'preparation' => 10, 'cuisson' => 25, 'repos' => 0, 'pour' => 4,
				'difficulte'  => 'Facile', 'cout' => 'Facile',
				'conseil-du-chef'   => "Une pointe de muscade fraîchement râpée change tout : la poudre en boîte est souvent trop discrète.",
				'liste-ingredients' => ['1 potimaron (environ 1 kg)', '1 oignon', '75 cl de bouillon de légumes', '10 cl de crème liquide', 'Muscade, sel, poivre'],
			],
			'tags' => ['Potimaron', 'Automne', 'Velouté'],
		],
		[
			'title'    => 'Fondue de poireaux',
			'alias'    => 'fondue-de-poireaux',
			'image'    => 'fondue-de-poireaux.webp',
			'category' => 'entrees',
			'intro'    => "<p>Le poireau cuit longtemps, à feu doux, jusqu'à fondre presque entièrement. Une garniture qui accompagne tout, ou se mange seule sur une tartine.</p>",
			'steps'    => [
				'Laver les poireaux, les émincer finement (blanc et vert clair).',
				'Faire fondre le beurre, ajouter les poireaux, saler.',
				'Couvrir, cuire 25 minutes à feu très doux en remuant de temps en temps.',
				"Mouiller avec le bouillon si ça attache, poursuivre 5 minutes à découvert.",
			],
			'fields' => [
				'preparation' => 10, 'cuisson' => 30, 'repos' => 0, 'pour' => 4,
				'difficulte'  => 'Facile', 'cout' => 'Facile',
				'conseil-du-chef'   => "Le feu doit rester doux tout du long : un poireau qui colore devient amer.",
				'liste-ingredients' => ['4 poireaux', '30 g de beurre', '10 cl de bouillon de légumes', 'Sel, poivre'],
			],
			'tags' => ['Poireau', 'Légumes', 'Accompagnement'],
		],
		[
			'title'    => 'Ratatouille méditerranéenne',
			'alias'    => 'ratatouille-mediterraneenne',
			'image'    => 'ratatouille-mediterraneenne.webp',
			'category' => 'plats',
			'intro'    => "<p>Chaque légume cuit à part avant d'être réuni. C'est ce qui évite la bouillie et garde le goût de chacun.</p>",
			'steps'    => [
				'Couper chaque légume en dés, séparément.',
				"Faire revenir chaque légume à part dans l'huile d'olive, réserver.",
				"Faire suer l'oignon et l'ail, ajouter les tomates, thym et laurier.",
				'Réunir tous les légumes, mijoter 20 minutes à couvert à feu doux.',
			],
			'fields' => [
				'preparation' => 25, 'cuisson' => 40, 'repos' => 0, 'pour' => 6,
				'difficulte'  => 'Moyen', 'cout' => 'Facile',
				'conseil-du-chef'   => "Meilleure réchauffée le lendemain : les goûts ont eu le temps de se rejoindre.",
				'liste-ingredients' => ['2 aubergines', '2 courgettes', '2 poivrons', '4 tomates', "1 oignon, 2 gousses d'ail", 'Huile d\'olive, thym, laurier'],
			],
			'tags' => ['Aubergine', 'Méditerranée', 'Été'],
		],
		[
			'title'    => 'Tarte fine à la tomate et aux olives',
			'alias'    => 'tarte-fine-tomate-olives',
			'image'    => 'tarte-fine-tomate-olives.webp',
			'category' => 'plats',
			'intro'    => "<p>Une pâte fine, des tomates bien mûres, quelques olives : la simplicité qui fait la différence en plein été.</p>",
			'steps'    => [
				'Étaler la pâte, la piquer, tartiner de moutarde.',
				'Trancher les tomates finement, les égoutter 10 minutes sur du papier absorbant.',
				"Disposer les tomates en rosace, ajouter les olives, arroser d'huile d'olive.",
				"Cuire 25 minutes à 200 °C, parsemer d'origan à la sortie du four.",
			],
			'fields' => [
				'preparation' => 15, 'cuisson' => 25, 'repos' => 10, 'pour' => 4,
				'difficulte'  => 'Facile', 'cout' => 'Facile',
				'conseil-du-chef'   => "Égoutter les tomates est l'étape qu'on saute toujours et qui évite pourtant une pâte détrempée.",
				'liste-ingredients' => ['1 pâte feuilletée', '5 tomates', '12 olives noires', '1 cuillère à soupe de moutarde', "Origan, huile d'olive, sel"],
			],
			'tags' => ['Tomate', 'Olive', 'Été'],
		],
		[
			'title'    => 'Petits pois à la française',
			'alias'    => 'petits-pois-a-la-francaise',
			'image'    => 'petits-pois-a-la-francaise.webp',
			'category' => 'plats',
			'intro'    => "<p>Petits pois, laitue et lardons mijotés ensemble, une recette de grand-mère qui n'a pas pris une ride.</p>",
			'steps'    => [
				'Faire revenir les lardons et les petits oignons dans le beurre.',
				'Ajouter les petits pois et la laitue émincée.',
				'Couvrir d\'eau à mi-hauteur, saler légèrement (les lardons salent déjà).',
				'Mijoter 25 minutes à couvert, à feu doux.',
			],
			'fields' => [
				'preparation' => 15, 'cuisson' => 30, 'repos' => 0, 'pour' => 4,
				'difficulte'  => 'Facile', 'cout' => 'Moyen',
				'conseil-du-chef'   => "Des petits pois surgelés conviennent très bien hors saison : inutile d'attendre le printemps.",
				'liste-ingredients' => ['500 g de petits pois écossés', '1 laitue', '100 g de lardons', '12 petits oignons', '20 g de beurre'],
			],
			'tags' => ['Petit pois', 'Printemps', 'Traditionnel'],
		],
		[
			'title'    => 'Gâteau moelleux à la courgette et au citron',
			'alias'    => 'gateau-courgette-citron',
			'image'    => 'gateau-courgette-citron.webp',
			'category' => 'desserts',
			'intro'    => "<p>La courgette râpée disparaît dans la mie et l'humidifie. Le dessert qui surprend toujours à l'aveugle.</p>",
			'steps'    => [
				'Râper la courgette, l\'égoutter dans un torchon sans trop presser.',
				"Fouetter les œufs et le sucre, ajouter l'huile puis la courgette et le zeste.",
				'Incorporer la farine et la levure tamisées.',
				'Verser dans un moule, cuire 35 minutes à 180 °C.',
			],
			'fields' => [
				'preparation' => 15, 'cuisson' => 35, 'repos' => 10, 'pour' => 8,
				'difficulte'  => 'Facile', 'cout' => 'Facile',
				'conseil-du-chef'   => "Ne pas égoutter la courgette à l'excès : c'est son eau qui rend le gâteau moelleux.",
				'liste-ingredients' => ['200 g de courgette râpée', '3 œufs', '150 g de sucre', "100 g d'huile neutre", '200 g de farine, 1 sachet de levure', "Zeste d'un citron"],
			],
			'tags' => ['Courgette', 'Citron', 'Gâteau'],
		],

		// --- Les 6 articles « Le potager » ---------------------------------
		[
			'title'    => "L'aubergine",
			'alias'    => 'aubergine',
			'image'    => 'legume-aubergine.webp',
			'category' => 'potager',
			'intro'    => "<p>Originaire d'Inde, l'aubergine a mis des siècles à convaincre l'Europe : on la croyait toxique jusqu'au XVII<sup>e</sup> siècle, où son nom italien (<em>mela insana</em>, la pomme folle) en garde la trace.</p>",
			'steps'    => null,
			'body'     => "<p>Elle a fini par s'imposer sur tout le pourtour méditerranéen, où sa chair qui absorbe l'huile d'olive et les épices en a fait un pilier de la cuisine d'été. On la choisit ferme, à la peau brillante et sans taches : un signe qu'elle n'a pas trop mûri.</p>",
			'fields'   => [],
			'tags'     => ['Aubergine', 'Histoire', 'Méditerranée'],
		],
		[
			'title'    => 'La tomate',
			'alias'    => 'la-tomate',
			'image'    => 'legume-tomate.webp',
			'category' => 'potager',
			'intro'    => "<p>Ramenée d'Amérique du Sud au XVI<sup>e</sup> siècle, la tomate a d'abord servi de plante d'ornement en Europe : on se méfiait de ce fruit de la famille des solanacées, comme la pomme de terre et l'aubergine.</p>",
			'steps'    => null,
			'body'     => "<p>Il faudra attendre le XVIII<sup>e</sup> siècle pour qu'elle passe dans l'assiette, d'abord en Italie. Elle n'a plus quitté les étés méditerranéens depuis, et se décline en centaines de variétés, du minuscule cerise à la grosse cœur de bœuf.</p>",
			'fields'   => [],
			'tags'     => ['Tomate', 'Histoire', 'Été'],
		],
		[
			'title'    => 'Le potimaron',
			'alias'    => 'le-potimaron',
			'image'    => 'legume-potimaron.webp',
			'category' => 'potager',
			'intro'    => "<p>Ce petit cousin de la courge débarque du Japon en France dans les années 1980.</p>",
			'steps'    => null,
			'body'     => "<p>Son nom même mélange « potiron » et « marron », pour dire ce goût de châtaigne qui le distingue des autres courges. Sa peau, fine, se mange sans problème une fois cuite : pas besoin d'éplucher, ce qui en fait un légume d'automne particulièrement rapide à préparer.</p>",
			'fields'   => [],
			'tags'     => ['Potimaron', 'Histoire', 'Automne'],
		],
		[
			'title'    => 'Le poireau',
			'alias'    => 'le-poireau',
			'image'    => 'legume-poireau.webp',
			'category' => 'potager',
			'intro'    => "<p>Cultivé depuis l'Égypte antique, le poireau a longtemps été un aliment de base plutôt qu'un légume de fête : on le retrouve dans les rations des bâtisseurs de pyramides.</p>",
			'steps'    => null,
			'body'     => "<p>Il pousse presque toute l'année et supporte bien le froid, ce qui en a fait un pilier des potagers d'hiver européens. Aujourd'hui encore, la vichyssoise ou le pot-au-feu lui doivent leur fond de goût.</p>",
			'fields'   => [],
			'tags'     => ['Poireau', 'Histoire', 'Hiver'],
		],
		[
			'title'    => 'Le petit pois',
			'alias'    => 'le-petit-pois',
			'image'    => 'legume-petit-pois.webp',
			'category' => 'potager',
			'intro'    => "<p>Longtemps consommé sec, le petit pois frais devient un mets de choix à la cour de Louis XIV, où on se le fait livrer hors saison à prix d'or, et le roi lui-même en raffolait.</p>",
			'steps'    => null,
			'body'     => "<p>Aujourd'hui cultivé partout et souvent surgelé aussitôt récolté, il a gardé son statut de légume printanier par excellence, même si on le trouve toute l'année.</p>",
			'fields'   => [],
			'tags'     => ['Petit pois', 'Histoire', 'Printemps'],
		],
		[
			'title'    => 'La courgette',
			'alias'    => 'la-courgette',
			'image'    => 'legume-courgette.webp',
			'category' => 'potager',
			'intro'    => "<p>Cousine de la citrouille, la courgette est une courge cueillie jeune, avant que sa peau ne durcisse : c'est cette récolte précoce, mise au point en Italie au XIX<sup>e</sup> siècle, qui lui donne sa texture tendre.</p>",
			'steps'    => null,
			'body'     => "<p>Peu calorique et très majoritairement composée d'eau, elle se prête aussi bien au salé qu'au sucré, comme le prouve le gâteau qui l'accompagne ici.</p>",
			'fields'   => [],
			'tags'     => ['Courgette', 'Histoire', 'Potager'],
		],

		// --- Les deux pages qui expliquent le template ---------------------
		[
			'title'    => 'Typographie',
			'alias'    => 'typographie',
			'category' => 'template',
			'intro'    => "<p class=\"lead\">Cette page montre comment Corpus habille le texte courant. Rien n'y est décoré à la main : chaque exemple est écrit avec les balises ordinaires de l'éditeur, et c'est le template qui décide de l'allure.</p>",
			'steps'    => null,
			'body'     => <<<'HTML'
<h2>Les titres</h2>
<p>L'article porte déjà son titre en <code>h1</code>. Un seul <code>h1</code> par page : dans le corps, on commence donc au niveau 2, et on descend d'un cran à chaque fois qu'une idée dépend de la précédente. Sauter un niveau, passer de <code>h2</code> à <code>h4</code>, laisse un trou dans le sommaire que lit une personne aveugle.</p>
<h3>Un titre de niveau 3</h3>
<p>Il dépend du titre de niveau 2 qui le précède.</p>
<h4>Un titre de niveau 4</h4>
<p>Et celui-ci du niveau 3. Au-delà, la page est trop profonde : mieux vaut la couper en deux.</p>

<h2>Le texte courant</h2>
<p>Un paragraphe ordinaire. La largeur de lecture est bornée par le template, autour de soixante-dix caractères : au-delà, l'œil peine à retrouver le début de la ligne suivante.</p>
<p class="lead">Un paragraphe d'accroche, avec la classe <code>lead</code>. Un seul par page, juste sous le titre.</p>
<p>Dans une phrase, <strong>ce qui compte se met en gras</strong> et <em>ce qui prend une nuance se met en italique</em>. On peut citer du <code>code</code>, poser un <a href="#">lien</a>, ou noter une <abbr title="Chose Mal Sue">CMS</abbr> abréviation.</p>

<h2>Les listes</h2>
<p>Une liste à puces, quand l'ordre n'a pas d'importance :</p>
<ul>
	<li>Le premier élément</li>
	<li>Le deuxième, qui peut tenir sur plusieurs lignes sans que cela change quoi que ce soit à sa présentation</li>
	<li>Le troisième</li>
</ul>
<p>Une liste numérotée, quand l'ordre compte, comme dans les étapes d'une recette :</p>
<ol>
	<li>Préparer</li>
	<li>Cuire</li>
	<li>Servir</li>
</ol>

<h2>La citation</h2>
<p>Aucune classe à poser : la balise de citation reçoit son filet toute seule.</p>
<blockquote>
	<p>On ne fait pas de bonne cuisine avec de mauvais produits.</p>
</blockquote>

<h2>Les messages</h2>
<p>Quatre tons, et un seul balisage. Le <code>role="note"</code> les fait annoncer comme une remarque par un lecteur d'écran, et la couleur n'est jamais le seul indice : le titre du message dit déjà de quoi il s'agit, ce qui reste vrai pour une personne qui ne distingue pas le rouge du vert.</p>
<div class="message rule message--info" role="note">
	<div>
		<p class="message__titre">Information</p>
		<p>Le potimaron ne s'épluche pas : sa peau se mange une fois cuite.</p>
	</div>
</div>
<div class="message rule message--succes" role="note">
	<div>
		<p class="message__titre">Succès</p>
		<p>Le contenu de démonstration a bien été installé.</p>
	</div>
</div>
<div class="message rule message--alerte" role="note">
	<div>
		<p class="message__titre">Avertissement</p>
		<p>Égouttez les tomates avant de garnir la tarte, sinon la pâte se détrempe.</p>
	</div>
</div>
<div class="message rule message--erreur" role="note">
	<div>
		<p class="message__titre">Erreur</p>
		<p>Un caramel brûlé ne se rattrape pas. Il faut le recommencer.</p>
	</div>
</div>

<h2>Le tableau</h2>
<p>Un tableau sert à comparer des données, jamais à mettre en page. La première ligne est une ligne d'en-tête, et c'est elle qui permet à un lecteur d'écran d'annoncer « Cuisson, 25 minutes » plutôt que « 25 » tout seul.</p>
<table>
	<thead>
		<tr><th scope="col">Recette</th><th scope="col">Préparation</th><th scope="col">Cuisson</th></tr>
	</thead>
	<tbody>
		<tr><td>Velouté de potimaron</td><td>10 min</td><td>25 min</td></tr>
		<tr><td>Ratatouille</td><td>25 min</td><td>40 min</td></tr>
		<tr><td>Tarte fine à la tomate</td><td>15 min</td><td>25 min</td></tr>
	</tbody>
</table>

<h2>Le bouton</h2>
<p>Un lien qui déclenche une action prend la classe <code>btn</code>. Un lien qui mène simplement à une autre page reste un lien.</p>
<p><a class="btn" href="#">Voir les recettes</a></p>
HTML,
			'fields'   => [],
			'tags'     => ['Corpus', 'Typographie'],
		],
		[
			'title'    => 'Les tampons',
			'alias'    => 'les-tampons',
			'category' => 'template',
			'intro'    => "<p class=\"lead\">Un tampon est un bloc tout prêt qu'on insère dans un article depuis l'éditeur, par le bouton « Modèles de contenu ». Corpus en livre cinquante-cinq. En voici quelques-uns, montés à la suite comme ils le seraient dans une vraie page.</p>",
			'steps'    => null,
			'body'     => <<<'HTML'
<h2>Le hero</h2>
<p>L'ouverture d'une page : un titre, une phrase, une action. Dans une vraie page ce titre serait le <code>h1</code>. Ici il descend en <code>h3</code>, parce que l'article porte déjà son <code>h1</code> et que cette section porte son <code>h2</code> : on ne saute jamais un niveau.</p>
<div class="text-center">
	<h3>Un livre de recettes pour découvrir Corpus</h3>
	<p class="lead">Six recettes, six légumes, et de quoi comprendre comment le template met en page un article.</p>
	<p><a class="btn" href="#">Voir les recettes</a></p>
</div>

<hr>

<h2>La grille</h2>
<p>Douze colonnes, la même grille que celle du gabarit d'article. Les colonnes retombent l'une sous l'autre sur téléphone, sans que vous ayez à le régler. La somme des nombres doit faire douze.</p>
<div class="row text-center">
	<div class="col-md-4">
		<h3>Entrées</h3>
		<p>Deux recettes pour commencer un repas.</p>
	</div>
	<div class="col-md-4">
		<h3>Plats</h3>
		<p>Trois recettes de légumes du soleil.</p>
	</div>
	<div class="col-md-4">
		<h3>Desserts</h3>
		<p>Un gâteau qui cache son légume.</p>
	</div>
</div>

<hr>

<h2>Les chiffres clés</h2>
<p>Le chiffre seul ne dit rien : le libellé en dessous fait partie de l'information. Un lecteur d'écran lit les deux à la suite.</p>
<div class="row">
	<div class="col-md-4">
		<p><strong style="font-size:2.5rem;line-height:1.1;display:block">6</strong>
			Recettes de saison</p>
	</div>
	<div class="col-md-4">
		<p><strong style="font-size:2.5rem;line-height:1.1;display:block">6</strong>
			Légumes racontés</p>
	</div>
	<div class="col-md-4">
		<p><strong style="font-size:2.5rem;line-height:1.1;display:block">55</strong>
			Tampons livrés avec Corpus</p>
	</div>
</div>

<hr>

<h2>Le texte et l'image</h2>
<p>Une rangée à deux colonnes inégales. L'ordre de lecture est celui du code : ne vous servez pas des colonnes pour remonter un bloc, il ne remonterait que pour l'œil.</p>
<div class="row">
	<div class="col-md-4">
		<img class="img-fluid" src="images/corpus-start/legume-tomate.webp" alt="Des tomates cerises">
	</div>
	<div class="col-md-8">
		<h3>La tomate</h3>
		<p>Ramenée d'Amérique du Sud au XVI<sup>e</sup> siècle, elle a d'abord servi de plante d'ornement avant de passer dans l'assiette.</p>
		<p><a class="btn" href="#">Lire la suite</a></p>
	</div>
</div>

<hr>

<h2>Les cartes à pastille</h2>
<p>Une carte par sujet, et un état d'un coup d'œil. La pastille prend sa couleur d'un jeton du template, jamais d'une valeur écrite à la main. Elle porte <code>aria-hidden</code> : c'est le mot à côté qui donne l'information, pas la couleur, ce qui reste vrai pour qui ne distingue pas le vert de l'orange.</p>
<div class="row g-4">
	<div class="col-md-4">
		<article class="card h-100">
			<div class="card-body">
				<p class="lead fw-semibold mb-2">Velouté de potimarron</p>
				<p>Dix minutes de préparation, aucune épluchure.</p>
				<p class="mb-0" style="color:var(--succes,#136c3a)"><span aria-hidden="true" style="display:inline-block;width:.6em;height:.6em;border-radius:50%;background:currentColor;margin-right:.4em"></span><strong>De saison</strong></p>
			</div>
		</article>
	</div>
	<div class="col-md-4">
		<article class="card h-100">
			<div class="card-body">
				<p class="lead fw-semibold mb-2">Ratatouille</p>
				<p>Chaque légume cuit à part, puis tout se rejoint.</p>
				<p class="mb-0" style="color:var(--alerte,#8a5300)"><span aria-hidden="true" style="display:inline-block;width:.6em;height:.6em;border-radius:50%;background:currentColor;margin-right:.4em"></span><strong>Fin de saison</strong></p>
			</div>
		</article>
	</div>
	<div class="col-md-4">
		<article class="card h-100">
			<div class="card-body">
				<p class="lead fw-semibold mb-2">Petits pois à la française</p>
				<p>Laitue et lardons, une recette de grand-mère.</p>
				<p class="mb-0" style="color:var(--texte-doux,#555)"><span aria-hidden="true" style="display:inline-block;width:.6em;height:.6em;border-radius:50%;background:currentColor;margin-right:.4em"></span><strong>Au printemps</strong></p>
			</div>
		</article>
	</div>
</div>

<hr>

<h2>L'encadré</h2>
<p>Ce qu'il faut retenir, sorti du fil du texte.</p>
<aside class="panneau__boite">
	<h3>Le conseil du chef</h3>
	<p>Une pointe de muscade fraîchement râpée change tout : la poudre en boîte est souvent trop discrète.</p>
</aside>

<hr>

<h2>L'accordéon</h2>
<p>Des volets qui se déplient. Le titre porte le bouton, et non l'inverse : c'est ce qui permet d'y arriver au clavier et d'entendre annoncer son état.</p>
<div class="accordeon">
	<h3 class="accordeon__titre">
		<button type="button" class="accordeon__bouton" aria-expanded="true" aria-controls="tampon-acc-1">
			Faut-il éplucher le potimarron ?
		</button>
	</h3>
	<div class="accordeon__volet" id="tampon-acc-1">
		<p>Non. Sa peau est fine et se mange sans problème une fois cuite.</p>
	</div>
	<h3 class="accordeon__titre">
		<button type="button" class="accordeon__bouton" aria-expanded="false" aria-controls="tampon-acc-2">
			Peut-on prendre des petits pois surgelés ?
		</button>
	</h3>
	<div class="accordeon__volet" id="tampon-acc-2" hidden>
		<p>Oui, et très bien. Inutile d'attendre le printemps.</p>
	</div>
</div>

<hr>

<h2>Le bandeau d'appel</h2>
<p>La fin d'une page, quand elle demande quelque chose au lecteur.</p>
<div class="panneau__boite">
	<h3>Envie d'essayer ?</h3>
	<p>Les six recettes sont courtes, et aucune ne demande de matériel particulier.</p>
	<p><a class="btn" href="#">Ouvrir le livre de recettes</a></p>
</div>
HTML,
			'fields'   => [],
			'tags'     => ['Corpus', 'Tampons'],
		],
	],
];
