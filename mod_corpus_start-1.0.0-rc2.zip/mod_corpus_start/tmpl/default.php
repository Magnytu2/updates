<?php
/**
 * Gabarit d'affichage du module de démarrage Corpus.
 *
 * Structure calquée sur mod_sampledata (cœur Joomla) : liste .list-group,
 * bouton .btn.btn-primary.btn-sm, barre de progression masquée par défaut.
 * Aucune couleur n'est déclarée ici : tout vient des classes Bootstrap/Atum
 * déjà chargées par l'administration.
 *
 * Variables reçues de mod_corpus_start.php : $scenarios, $params, $module.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;

// LA FENÊTRE EST CELLE DE JOOMLA, celle de la visite guidée et des traitements
// par lot : le composant <joomla-dialog>, pas une modale Bootstrap. On demande
// donc son script, sinon `data-joomla-dialog` n'a personne pour l'écouter et le
// bouton reste mort, sans erreur et sans message.
Factory::getApplication()->getDocument()->getWebAssetManager()
	->useScript('joomla.dialog-autocreate');

// Uri::root() renvoie toujours la racine du SITE, jamais /administrator :
// il faut l'ajouter explicitement, sinon com_ajax cherche le module côté site.
$ajaxUrl   = Uri::root(true) . '/administrator/index.php?option=com_ajax&module=corpus_start&format=json';
$csrf      = Session::getFormToken();
$wrapperId = 'corpus-start-' . (int) $module->id;
$modalId   = $wrapperId . '-reset-modal';

// Les réglages de la fenêtre, au format qu'attend joomla-dialog-autocreate.js.
$dialogConfig = json_encode([
	'popupType'    => 'inline',
	// 'src' et non 'popupContent' : joomla-dialog.js ne fait un querySelector que
	// sur 'src' (ligne 352). Un sélecteur passé dans 'popupContent' serait inséré
	// tel quel, en texte, et la fenêtre afficherait « #corpus-start-… ».
	'src'          => '#' . $modalId,
	'textHeader'   => Text::_('MOD_CORPUS_START_RESET_CONFIRM_TITLE'),
	'width'        => '600px',
	'height'       => 'fit-content',
], JSON_UNESCAPED_UNICODE);
?>
<div id="<?php echo $wrapperId; ?>" class="corpus-start" data-ajax-url="<?php echo $ajaxUrl; ?>" data-csrf="<?php echo $csrf; ?>">

	<div class="corpus-start__alert" role="status" aria-live="polite"></div>

	<ul class="list-group list-group-flush corpus-start">
		<?php foreach ($scenarios as $key => $scenario) : ?>
			<li class="list-group-item corpusstart-<?php echo $key; ?>">
				<div class="d-flex justify-content-between align-items-center">
					<div class="corpus-start__title">
						<span class="corpus-start__icon <?php echo $scenario['icon']; ?> me-1" aria-hidden="true"></span>
						<?php echo Text::_($scenario['langPrefix'] . '_TITLE'); ?>
					</div>
					<?php
					/*
					 * LA CROIX ROUGE PAR SCÉNARIO A ÉTÉ RETIRÉE LE 26 AOÛT 2026, à la
					 * demande de Cyrille.
					 *
					 * Elle servait un usage qui n'existe plus : montrer les quatre mises
					 * en page sur un même Joomla et passer de l'une à l'autre.
					 * L'architecture retenue est de quatre sites, un scénario chacun. Sur
					 * un site qui ne porte QU'UNE démonstration, « retirer la landing » et
					 * « réinitialiser » sont le même geste, et deux boutons rouges pour un
					 * seul geste, c'est un de trop.
					 *
					 * LE RETRAIT SÉLECTIF RESTE DANS LE HELPER : la tâche `reset` accepte
					 * toujours un nom de scénario, et `resetUn()` ne bouge pas. Ce n'est
					 * plus le tableau de bord qui les appelle, voilà tout.
					 */
					?>
					<div class="d-flex align-items-center gap-2">
					<?php
					/*
					 * DÉSACTIVÉ TANT QU'UNE DÉMONSTRATION EST EN PLACE.
					 *
					 * Une seule mise en page à la fois, décision de Cyrille du
					 * 26 août 2026 : deux installées ensemble se disputent le
					 * style du site, la page d'accueil et les positions de
					 * module, et la réinitialisation ne peut plus rien rendre de
					 * juste. Le pourquoi complet est dans
					 * `refuserSiDejaInstalle()` du helper.
					 *
					 * CE N'EST PAS LÀ QUE LA RÈGLE EST TENUE. Le helper refuse la
					 * tâche de son côté, et c'est lui qui compte : `com_ajax` est
					 * joignable sans passer par ce bouton. Ici on évite
					 * seulement de proposer un geste qui sera refusé.
					 *
					 * `disabled` ET NON UN BOUTON RETIRÉ : la liste garde ses
					 * quatre lignes, on voit ce qui existe et ce qu'on pourra
					 * installer après une réinitialisation. Un bouton qui
					 * disparaît laisse croire que la mise en page a disparu
					 * aussi.
					 */
					?>
					<button type="button" class="btn btn-primary btn-sm corpus-start__install"
						data-task="<?php echo $key; ?>"
						<?php echo $installes ? ' disabled' : ''; ?>
						<?php echo $installes ? ' title="' . htmlspecialchars(Text::_('MOD_CORPUS_START_ONE_AT_A_TIME'), ENT_QUOTES, 'UTF-8') . '"' : ''; ?>>
						<span class="icon-upload" aria-hidden="true"></span>
						<?php echo Text::_('MOD_CORPUS_START_BTN_INSTALL'); ?>
						<span class="visually-hidden"><?php echo Text::_($scenario['langPrefix'] . '_TITLE'); ?></span>
					</button>
					<?php
					/*
					 * CE QUI EST DÉJÀ POSÉ. 26 août 2026, demande de Cyrille.
					 *
					 * La croix rouge de retrait disait deux choses à la fois : ce qui est
					 * installé, et ce qu'on peut retirer. En la supprimant, on a perdu la
					 * première, et le tableau de bord ne disait plus rien de son propre
					 * état : quatre boutons « Installer » identiques, qu'il y ait une
					 * démonstration en place ou aucune.
					 *
					 * C'EST UN CARRÉ, PAS UN BOUTON. Il n'attend aucun clic, il constate.
					 * D'où un `<span>` et non un `<button>` : un élément cliquable qui ne
					 * fait rien apprend au lecteur à ne plus essayer de cliquer. Il porte
					 * quand même les classes `btn btn-sm` de Bootstrap, et rien d'autre :
					 * ce sont elles qui lui donnent EXACTEMENT la hauteur du bouton
					 * « Installer » d'à côté, sans une ligne de CSS à écrire ni à
					 * maintenir le jour où Atum change ses mesures.
					 *
					 * PAS DE TEXTE VISIBLE, demande de Cyrille du 26 août 2026 : la
					 * première version portait le mot « Installé », qui allongeait la
					 * ligne de quatre pastilles.
					 *
					 * LA COULEUR SEULE NE DIT RIEN, et retirer le mot ne change pas cette
					 * règle (RGAA 3.1) : un carré vert est illisible pour qui ne
					 * distingue pas le vert du rouge. Le sens passe donc par
					 * `role="img"` et `aria-label`, qui donnent à ce carré un nom complet
					 * (« Installé : Blog ») pour un lecteur d'écran, et par `title` pour
					 * la souris. La coche, elle, est un dessin : `aria-hidden`.
					 *
					 * La lecture se refait à chaque affichage du tableau de bord : une
					 * base restaurée depuis une sauvegarde se voit au rafraîchissement
					 * suivant, sans réglage à corriger nulle part.
					 */
					?>
					<?php if (in_array($key, $installes, true)) : ?>
					<span class="btn btn-success btn-sm corpus-start__done"
						role="img"
						aria-label="<?php echo htmlspecialchars(Text::_('MOD_CORPUS_START_INSTALLED') . ' : ' . Text::_($scenario['langPrefix'] . '_TITLE'), ENT_QUOTES, 'UTF-8'); ?>"
						title="<?php echo htmlspecialchars(Text::_('MOD_CORPUS_START_INSTALLED') . ' : ' . Text::_($scenario['langPrefix'] . '_TITLE'), ENT_QUOTES, 'UTF-8'); ?>">
						<span class="icon-checkmark" aria-hidden="true"></span>
					</span>
					<?php endif; ?>
					</div>
				</div>
				<p class="corpus-start__desc small mt-1">
					<?php echo Text::_($scenario['langPrefix'] . '_DESC'); ?>
				</p>
			</li>
			<li class="list-group-item corpusstart-progress-<?php echo $key; ?> d-none">
				<div class="progress mb-1">
					<div class="progress-bar progress-bar-striped progress-bar-animated" style="width: 100%"></div>
				</div>
			</li>
		<?php endforeach; ?>

		<li class="list-group-item corpusstart-reset">
			<div class="d-flex justify-content-between align-items-center">
				<div class="corpus-start__title">
					<span class="corpus-start__icon icon-trash me-1" aria-hidden="true"></span>
					<?php echo Text::_('MOD_CORPUS_START_RESET_TITLE'); ?>
				</div>
				<button type="button" class="btn btn-danger btn-sm corpus-start__reset-open" data-joomla-dialog="<?php echo htmlspecialchars($dialogConfig, ENT_QUOTES, 'UTF-8'); ?>">
					<span class="icon-trash" aria-hidden="true"></span>
					<?php echo Text::_('MOD_CORPUS_START_RESET_BTN'); ?>
				</button>
			</div>
			<p class="corpus-start__desc small mt-1">
				<?php echo Text::_('MOD_CORPUS_START_RESET_DESC'); ?>
			</p>
			<?php
			/*
			 * POURQUOI LES AUTRES BOUTONS SONT GRIS. Un bouton désactivé sans
			 * explication passe pour une panne. Cette ligne ne s'affiche que
			 * lorsqu'elle a quelque chose à expliquer.
			 */
			?>
			<?php if ($installes) : ?>
			<p class="corpus-start__desc small mt-2 mb-0">
				<span class="icon-info" aria-hidden="true"></span>
				<?php echo Text::_('MOD_CORPUS_START_ONE_AT_A_TIME'); ?>
			</p>
			<?php endif; ?>
			<?php
			/*
			 * UNE DÉMONSTRATION SANS SCÉNARIO.
			 *
			 * `getInstalled()` range sous une clé vide ce qui porte la note
			 * `corpus_start` sans suffixe : c'est le cas de tout ce qui a été
			 * posé avant que les scénarios soient nommés. On ne peut pas
			 * deviner de quel scénario il s'agit, donc AUCUNE pastille verte ne
			 * s'affiche en face d'un scénario.
			 *
			 * SANS CETTE LIGNE, LE TABLEAU DE BORD MENT PAR OMISSION : quatre
			 * mises en page sans pastille, ce qui se lit « rien n'est
			 * installé », alors qu'il y a bien une démonstration en place.
			 */
			?>
			<?php if (in_array('', $installes, true)) : ?>
			<p class="corpus-start__desc small mt-2 mb-0 text-warning">
				<span class="icon-warning" aria-hidden="true"></span>
				<?php echo Text::_('MOD_CORPUS_START_LEGACY'); ?>
			</p>
			<?php endif; ?>
		</li>
		<li class="list-group-item corpusstart-progress-reset d-none">
			<div class="progress mb-1">
				<div class="progress-bar progress-bar-striped progress-bar-animated" style="width: 100%"></div>
			</div>
		</li>
	</ul>

	<!--
		Confirmation de réinitialisation.

		Le contenu vit dans un <template> : JoomlaDialog en CLONE le contenu au
		lieu de le déplacer (joomla-dialog.js, ligne 358). Les écouteurs posés
		sur les nœuds d'origine ne suivraient donc pas la copie. D'où la
		délégation sur `document` plus bas, et non un addEventListener direct.
	-->
	<template id="<?php echo $modalId; ?>">
		<!-- p-3 : le corps de <joomla-dialog> ne pose aucune marge intérieure.
		     Classe utilitaire Bootstrap, déjà chargée par Atum, aucun style ajouté. -->
		<div class="p-3">
		<p class="mb-0"><?php echo Text::_('MOD_CORPUS_START_RESET_CONFIRM_BODY'); ?></p>
		<div class="d-flex justify-content-end gap-2 mt-4">
			<button type="button" class="btn btn-secondary btn-sm corpus-start__reset-cancel">
				<?php echo Text::_('MOD_CORPUS_START_CANCEL'); ?>
			</button>
			<button type="button" class="btn btn-danger btn-sm corpus-start__reset-confirm" data-wrapper="<?php echo $wrapperId; ?>">
				<span class="icon-trash" aria-hidden="true"></span>
				<?php echo Text::_('MOD_CORPUS_START_RESET_CONFIRM_BTN'); ?>
			</button>
		</div>
		</div>
	</template>
</div>

<script>
(function () {
	'use strict';

	var wrapper = document.getElementById('<?php echo $wrapperId; ?>');
	if (!wrapper) {
		return;
	}

	var ajaxUrl = wrapper.dataset.ajaxUrl;
	var csrf    = wrapper.dataset.csrf;
	var alertEl = wrapper.querySelector('.corpus-start__alert');

	function showMessage(text, isError) {
		alertEl.textContent = text;
		alertEl.className = 'corpus-start__alert alert ' + (isError ? 'alert-danger' : 'alert-info') + ' mb-3';
	}

	function callTask(task, button, progressSelector, scenario) {
		var body = new URLSearchParams();
		body.set('task', task);
		body.set(csrf, '1');

		if (scenario) {
			body.set('scenario', scenario);
		}

		var progress = wrapper.querySelector(progressSelector);
		if (button) {
			button.disabled = true;
		}
		if (progress) {
			progress.classList.remove('d-none');
		}

		fetch(ajaxUrl, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' },
			body: body.toString(),
			credentials: 'same-origin'
		})
			.then(function (response) { return response.json(); })
			.then(function (json) {
				if (json && json.success) {
					var msg = (json.data && json.data.message) || <?php echo json_encode(Text::_('MOD_CORPUS_START_SKELETON_OK')); ?>;
					showMessage(msg, false);

					// Le tableau de bord est écrit par PHP : seul un
					// rechargement fait apparaître ou disparaître les boutons
					// rouges. Assez tard pour que le message reste lisible.
					window.setTimeout(function () { window.location.reload(); }, 2500);
				} else {
					var errMsg = (json && json.message) || <?php echo json_encode(Text::_('MOD_CORPUS_START_ERROR')); ?>;
					showMessage(errMsg, true);
				}
			})
			.catch(function () {
				showMessage(<?php echo json_encode(Text::_('MOD_CORPUS_START_ERROR')); ?>, true);
			})
			.finally(function () {
				if (button) {
					button.disabled = false;
				}
				if (progress) {
					progress.classList.add('d-none');
				}
			});
	}

	wrapper.querySelectorAll('.corpus-start__install').forEach(function (btn) {
		btn.addEventListener('click', function () {
			callTask(btn.dataset.task, btn, '.corpusstart-progress-' + btn.dataset.task);
		});
	});

	/*
	 * Les boutons de la fenêtre sont des COPIES : JoomlaDialog clone le contenu
	 * du <template>. On écoute donc sur `document`, et on reconnaît les nôtres
	 * par l'identifiant du module qu'ils portent. Deux instances du module sur
	 * la même page ne se marchent pas dessus.
	 */
	document.addEventListener('click', function (event) {
		var confirmer = event.target.closest('.corpus-start__reset-confirm[data-wrapper="<?php echo $wrapperId; ?>"]');
		var annuler   = event.target.closest('.corpus-start__reset-cancel');

		if (!confirmer && !annuler) {
			return;
		}

		var fenetre = event.target.closest('joomla-dialog');
		if (fenetre && typeof fenetre.close === 'function') {
			fenetre.close();
		}

		if (confirmer) {
			callTask('reset', null, '.corpusstart-progress-reset');
		}
	});
})();
</script>
