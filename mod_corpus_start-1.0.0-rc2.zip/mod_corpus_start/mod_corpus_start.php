<?php
/**
 * Module de démarrage Corpus : le point d'entrée.
 *
 * Il ne fait que deux choses : demander au helper la liste des scénarios, et
 * lui demander lesquels sont déjà installés. Toute l'écriture en base passe par
 * `com_ajax`, jamais par l'affichage du tableau de bord.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

require_once __DIR__ . '/helper.php';

$scenarios = ModCorpusStartHelper::getScenarios();

/*
 * CE QUI EST DÉJÀ POSÉ, pour l'annoncer en face de chaque mise en page.
 *
 * La lecture se fait à chaque affichage du tableau de bord, et c'est voulu :
 * une démonstration retirée ailleurs, ou une base restaurée depuis une
 * sauvegarde, se voit au rafraîchissement suivant, sans réglage à corriger
 * nulle part. Aucun état n'est mémorisé, donc aucun ne peut mentir.
 */
$installes = ModCorpusStartHelper::getInstalled();

require ModuleHelper::getLayoutPath('mod_corpus_start', $params->get('layout', 'default'));
