<?php

/**
 * Oculus — Plugin de tâche planifiée : alertes de surveillance.
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Mail\MailerFactoryInterface;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\Database\DatabaseInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Event\DispatcherInterface;
use Joomanji\Plugin\Task\Oculus\Extension\Oculus;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            PluginInterface::class,
            function (Container $container) {
                $plugin = new Oculus(
                    $container->get(DispatcherInterface::class),
                    (array) PluginHelper::getPlugin('task', 'oculus')
                );
                $plugin->setApplication(Factory::getApplication());
                $plugin->setDatabase($container->get(DatabaseInterface::class));
                $plugin->setMailerFactory($container->get(MailerFactoryInterface::class));

                return $plugin;
            }
        );
    }
};
