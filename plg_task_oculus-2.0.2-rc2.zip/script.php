<?php

/**
 * Oculus — Script d'installation du plugin d'alertes.
 * Crée la table de stockage des instantanés.
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;

class PlgTaskOculusInstallerScript
{
    public function postflight($type, $parent): bool
    {
        if ($type === 'uninstall') {
            return true;
        }

        $db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);

        $db->setQuery(
            'CREATE TABLE IF NOT EXISTS ' . $db->quoteName('#__oculus_state') . ' ('
            . $db->quoteName('site_key') . ' varchar(32) NOT NULL, '
            . $db->quoteName('site_name') . ' varchar(255) NOT NULL DEFAULT ' . $db->quote('') . ', '
            . $db->quoteName('site_url') . ' varchar(500) NOT NULL DEFAULT ' . $db->quote('') . ', '
            . $db->quoteName('snapshot') . ' mediumtext NULL, '
            . $db->quoteName('failures') . ' int NOT NULL DEFAULT 0, '
            . $db->quoteName('alerted_down') . ' tinyint NOT NULL DEFAULT 0, '
            . $db->quoteName('checked') . ' datetime NULL, '
            . 'PRIMARY KEY (' . $db->quoteName('site_key') . ')'
            . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
        )->execute();

        return true;
    }
}
