<?php

/**
 * Oculus Alerte — Champ d'affichage de la version installée (lecture seule).
 * Version lue dans le manifeste enregistré par Joomla (source unique : le
 * <version> du fichier XML). La constante Oculus::VERSION n'est qu'un secours.
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

namespace Joomanji\Plugin\Task\Oculus\Field;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormField;
use Joomla\Database\DatabaseInterface;
use Joomanji\Plugin\Task\Oculus\Extension\Oculus;

class VersionField extends FormField
{
    protected $type = 'Version';

    protected function getInput()
    {
        return '<span class="badge bg-info">Oculus Alerte — version installée : '
            . htmlspecialchars($this->installedVersion(), ENT_QUOTES, 'UTF-8')
            . '</span>';
    }

    private function installedVersion(): string
    {
        try {
            $db    = Factory::getContainer()->get(DatabaseInterface::class);
            $cache = $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('manifest_cache'))
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                    ->where($db->quoteName('folder') . ' = ' . $db->quote('task'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('oculus'))
            )->loadResult();

            $manifest = json_decode((string) $cache, true) ?: [];
            $version  = (string) ($manifest['version'] ?? '');

            return $version !== '' ? $version : Oculus::VERSION;
        } catch (\Throwable $e) {
            return Oculus::VERSION;
        }
    }
}
