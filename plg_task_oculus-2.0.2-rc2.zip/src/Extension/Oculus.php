<?php

/**
 * Oculus — Plugin de tâche planifiée : alertes de surveillance.
 * Interroge les sites déclarés dans le module mod_oculus, compare avec
 * l'instantané précédent (table #__oculus_state) et alerte par mail.
 * LECTURE SEULE côté sites surveillés.
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

namespace Joomanji\Plugin\Task\Oculus\Extension;

\defined('_JEXEC') or die;

use Joomla\CMS\Access\Access;
use Joomla\CMS\Http\HttpFactory;
use Joomla\CMS\Mail\MailerFactoryAwareTrait;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Component\Scheduler\Administrator\Event\ExecuteTaskEvent;
use Joomla\Component\Scheduler\Administrator\Task\Status;
use Joomla\Component\Scheduler\Administrator\Traits\TaskPluginTrait;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Event\SubscriberInterface;

final class Oculus extends CMSPlugin implements SubscriberInterface
{
    use DatabaseAwareTrait;
    use MailerFactoryAwareTrait;
    use TaskPluginTrait;

    public const VERSION = '0.9.1';

    /** Nombre d'échecs consécutifs avant l'alerte « injoignable ». */
    private const FAILURES_BEFORE_ALERT = 3;

    /** Intervalle (secondes) entre deux rafraîchissements des mises à jour d'un site. */
    private $updatesInterval = 21600;

    protected const TASKS_MAP = [
        'oculus.check' => [
            'langConstPrefix' => 'PLG_TASK_OCULUS_CHECK',
            'method'          => 'checkSites',
        ],
    ];

    protected $autoloadLanguage = true;

    public static function getSubscribedEvents(): array
    {
        return [
            'onTaskOptionsList' => 'advertiseRoutines',
            'onExecuteTask'     => 'standardRoutineHandler',
        ];
    }

    // ------------------------------------------------------------------
    // Routine principale
    // ------------------------------------------------------------------

    private function checkSites(ExecuteTaskEvent $event): int
    {
        [$sites, $timeout] = $this->getConfiguredSites();

        // La tâche ne passe que toutes les 5 min : elle peut accorder un délai
        // généreux à un site lent, là où l'affichage temps réel se limite à 5 s.
        // Sans cela, un site alourdi (charge, voire malware) resterait « injoignable »
        // et la surveillance des fichiers ne s'exécuterait jamais dessus.
        $timeout = max($timeout, 45);

        if ($sites === []) {
            $this->logTask('Aucun site configuré dans le module Oculus.', 'warning');

            return Status::OK;
        }

        // On collecte les rapports de tous les sites, puis on envoie UN SEUL mail
        // récapitulatif : lors d'une mise à jour touchant tout le parc, on reçoit
        // une liste unique plutôt que 20 messages séparés.
        $reports = [];

        foreach ($sites as $site) {
            try {
                $report = $this->processSite($site, $timeout);

                if ($report !== null) {
                    $reports[] = $report;
                }
            } catch (\Throwable $e) {
                $this->logTask('Erreur sur ' . $site['url'] . ' : ' . $e->getMessage(), 'error');
            }
        }

        if ($reports !== []) {
            $this->sendDigest($reports);
        }

        return Status::OK;
    }

    /**
     * Envoie UN mail récapitulatif regroupant tous les sites concernés.
     *
     * @param array[] $reports Rapports renvoyés par processSite()
     */
    private function sendDigest(array $reports): void
    {
        $downBlocks   = [];
        $changeBlocks = [];
        $totalChanges = 0;

        foreach ($reports as $report) {
            $header = $report['name'] . ' (' . $report['url'] . ')';

            if (!empty($report['down'])) {
                $downBlocks[] = '• ' . $header . "\n    Injoignable — échecs consécutifs : "
                    . (int) $report['failures'] . '.';

                continue;
            }

            $totalChanges  += \count($report['lines']);
            $changeBlocks[] = '• ' . $header . "\n    - " . implode("\n    - ", $report['lines']);
        }

        // Objet : lisible d'un coup d'œil dans la boîte de réception.
        $parts = [];

        if ($downBlocks !== []) {
            $parts[] = \count($downBlocks) . ' site(s) injoignable(s)';
        }

        if ($changeBlocks !== []) {
            $parts[] = $totalChanges . ' changement(s) sur ' . \count($changeBlocks) . ' site(s)';
        }

        $subject = '[Oculus] ' . implode(' — ', $parts);

        // Corps : les sites injoignables d'abord (plus urgents), puis les changements.
        $body = "Rapport de surveillance du " . date('d/m/Y à H:i') . "\n";

        if ($downBlocks !== []) {
            $body .= "\nSITES INJOIGNABLES\n\n" . implode("\n\n", $downBlocks) . "\n";
        }

        if ($changeBlocks !== []) {
            $body .= "\nCHANGEMENTS DÉTECTÉS\n\n" . implode("\n\n", $changeBlocks) . "\n";
        }

        $body .= "\nSi ces changements ne sont pas de votre fait, vérifiez les sites concernés immédiatement.";

        $this->sendMail($subject, $body);
    }

    /**
     * Lit la liste des sites dans les paramètres du module mod_oculus
     * (source unique de vérité, la même que le tableau de bord).
     */
    private function getConfiguredSites(): array
    {
        $db = $this->getDatabase();

        $raw = $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName('params'))
                ->from($db->quoteName('#__modules'))
                ->where($db->quoteName('module') . ' = ' . $db->quote('mod_oculus'))
                ->where($db->quoteName('client_id') . ' = 1')
                ->where($db->quoteName('published') . ' = 1')
                ->setLimit(1)
        )->loadResult();

        $params  = json_decode((string) $raw, true) ?: [];
        $timeout = max(2, min(30, (int) ($params['timeout'] ?? 5)));

        $this->updatesInterval = max(1, min(48, (int) ($params['updates_hours'] ?? 6))) * 3600;
        $sites   = [];

        foreach ((array) ($params['sites'] ?? []) as $site) {
            $site  = (array) $site;
            $url   = trim((string) ($site['url'] ?? ''));
            $token = trim((string) ($site['token'] ?? ''));

            if ($url === '' || $token === '') {
                continue;
            }

            $sites[] = [
                'name'  => trim((string) ($site['sitename'] ?? '')) ?: $url,
                'url'   => $url,
                'token' => $token,
            ];
        }

        return [$sites, $timeout];
    }

    // ------------------------------------------------------------------
    // Traitement d'un site
    // ------------------------------------------------------------------

    /**
     * Traite un site et RENVOIE son rapport (sans envoyer de mail) :
     * ['name','url','down'=>bool,'failures'=>int,'lines'=>string[]], ou null si
     * rien à signaler. Les mails sont regroupés en un seul envoi par passage.
     *
     * @return array|null
     */
    private function processSite(array $site, int $timeout): ?array
    {
        $state = $this->loadState($site);

        // Une fois par jour : demander au site de rafraîchir sa liste de
        // mises à jour (sans visite admin, Joomla ne le fait jamais seul).
        $previousSnapshot = $state->snapshot !== null ? json_decode((string) $state->snapshot, true) : null;
        $lastRefresh      = \is_array($previousSnapshot) ? (int) ($previousSnapshot['_updates_refreshed_at'] ?? 0) : 0;
        $refreshedNow     = false;

        if (time() - $lastRefresh > $this->updatesInterval - 300) {
            $refreshedNow = $this->refreshSiteUpdates($site);
        }

        $data = $this->fetchSite($site, $timeout);

        if ($data === null) {
            // Échec : on incrémente, on signale au seuil, une seule fois.
            $state->failures++;
            $report = null;

            if ($state->failures >= self::FAILURES_BEFORE_ALERT && !$state->alerted_down) {
                $report = [
                    'name'     => $site['name'],
                    'url'      => $site['url'],
                    'down'     => true,
                    'failures' => (int) $state->failures,
                    'lines'    => [],
                ];
                $state->alerted_down = 1;
            }

            $this->saveState($state);

            return $report;
        }

        $lines = [];

        // Retour en ligne après une alerte « injoignable ».
        if ($state->alerted_down) {
            $lines[] = 'Le site est de nouveau joignable.';
        }

        $state->failures     = 0;
        $state->alerted_down = 0;

        $snapshot        = $this->buildSnapshot($data);
        $snapshot['ssl'] = $this->getSslDays($site['url']);

        $snapshot['_updates_refreshed_at'] = $refreshedNow ? time() : $lastRefresh;
        $previous = $state->snapshot !== null ? json_decode((string) $state->snapshot, true) : null;

        if (\is_array($previous)) {
            $lines = array_merge($lines, $this->diffSnapshots($previous, $snapshot));
        } else {
            $this->logTask('Premier passage pour ' . $site['name'] . ' : instantané de référence enregistré.', 'info');
        }

        $state->snapshot = json_encode($snapshot, JSON_UNESCAPED_UNICODE);
        $this->saveState($state);

        if ($lines === []) {
            return null;
        }

        return [
            'name'     => $site['name'],
            'url'      => $site['url'],
            'down'     => false,
            'failures' => 0,
            'lines'    => $lines,
        ];
    }

    /**
     * Demande au site de rafraîchir sa liste de mises à jour
     * (équivalent du bouton « Chercher les mises à jour »).
     */
    private function refreshSiteUpdates(array $site): bool
    {
        $endpoint = rtrim($site['url'], '/')
            . '/index.php?option=com_ajax&plugin=sitemonitor&format=raw&refresh=updates&token=' . urlencode($site['token']);

        try {
            $response = HttpFactory::getHttp()->get($endpoint, ['Accept' => 'application/json'], 40);
        } catch (\Throwable $e) {
            $this->logTask('Rafraîchissement des mises à jour impossible pour ' . $site['name'] . ' : ' . $e->getMessage(), 'warning');

            return false;
        }

        if ($response->code !== 200) {
            $this->logTask('Rafraîchissement des mises à jour refusé pour ' . $site['name'] . ' (HTTP ' . $response->code . ') — plugin client v0.7+ requis.', 'warning');

            return false;
        }

        $body = json_decode((string) $response->body, true);

        return \is_array($body) && !empty($body['refreshed']);
    }

    /**
     * Interroge le plugin client d'un site. Renvoie null si injoignable/invalide.
     */
    private function fetchSite(array $site, int $timeout): ?array
    {
        $endpoint = rtrim($site['url'], '/')
            . '/index.php?option=com_ajax&plugin=sitemonitor&format=raw&token=' . urlencode($site['token']);

        try {
            $response = HttpFactory::getHttp()->get($endpoint, ['Accept' => 'application/json'], $timeout);
        } catch (\Throwable $e) {
            return null;
        }

        if ($response->code !== 200) {
            return null;
        }

        $data = json_decode((string) $response->body, true);

        return (\is_array($data) && ($data['status'] ?? '') === 'ok') ? $data : null;
    }

    // ------------------------------------------------------------------
    // Instantanés et comparaison
    // ------------------------------------------------------------------

    /**
     * Ne conserve que les valeurs de base à surveiller.
     */
    private function buildSnapshot(array $data): array
    {
        // Utilisateurs backend (plugin v0.5+) ; repli sur les super users (plugins plus anciens).
        $sourceUsers = (isset($data['backend_users']) && \is_array($data['backend_users']) && !isset($data['backend_users']['error']))
            ? $data['backend_users']
            : (array) ($data['super_users'] ?? []);

        $backendUsers = [];

        $backendMfa = [];

        foreach ($sourceUsers as $user) {
            if (isset($user['id'])) {
                $groups = (isset($user['groups']) && \is_array($user['groups'])) ? ' — groupes : ' . implode(', ', $user['groups']) : '';

                $backendUsers[(string) $user['id']] = ($user['username'] ?? '?') . ' (' . ($user['email'] ?? '?') . ')' . $groups;
                $backendMfa[(string) $user['id']]   = $user['mfa_enabled'] ?? null;
            }
        }

        // SUPER ADMINS (droit core.admin) : indexés à part. Leur apparition — ou la
        // promotion d'un compte existant à ce rang — est l'un des signes les plus
        // clairs d'une compromission (l'attaquant se crée un accès permanent).
        $superIds = [];

        foreach ((array) ($data['super_users'] ?? []) as $user) {
            if (isset($user['id'])) {
                $superIds[(string) $user['id']] = ($user['username'] ?? '?') . ' (' . ($user['email'] ?? '?') . ')';
            }
        }

        $extensions = [];

        foreach ((array) ($data['extensions'] ?? []) as $ext) {
            if (isset($ext['id'])) {
                $extensions[(string) $ext['id']] = [
                    'name'    => (string) ($ext['name'] ?? '?'),
                    'enabled' => !empty($ext['enabled']),
                ];
            }
        }

        $tasks = [];

        foreach ((array) ($data['scheduled_tasks'] ?? []) as $task) {
            if (isset($task['id'])) {
                $tasks[(string) $task['id']] = (string) ($task['title'] ?? '?');
            }
        }

        $updates = [];

        foreach ((array) ($data['updates']['available'] ?? []) as $update) {
            $newVersion = (string) ($update['new_version'] ?? '');
            $curVersion = (string) ($update['current_version'] ?? '');

            // Garde-fou : ignore les entrées « fantômes » laissées par Joomla dans
            // #__updates, dont la version cible n'est pas supérieure à l'installée
            // (ex. « Joomla! 6.1.2 → 6.1.2 »). Sans cela, Oculus alerte pour rien.
            if ($curVersion !== '' && $newVersion !== '' && version_compare($newVersion, $curVersion, '<=')) {
                continue;
            }

            $updates[] = ($update['name'] ?? '?') . ' → ' . ($newVersion !== '' ? $newVersion : '?');
        }

        $usersTotal = $data['summary']['users_total'] ?? null;

        // Ancienneté de la dernière sauvegarde Akeeba (jours), si connue.
        $backupDays = null;
        $backupLast = null;

        if (\is_array($data['backup'] ?? null) && !empty($data['backup']['installed'])) {
            $backupLast = $data['backup']['last_backup'] ?? null;

            if ($backupLast && ($ts = strtotime((string) $backupLast)) !== false) {
                $backupDays = (int) floor((time() - $ts) / 86400);
            }
        }

        $phpFiles = (\is_array($data['php_files'] ?? null) && !isset($data['php_files']['error']))
            ? array_keys($data['php_files'])
            : null;

        return [
            'php_files'     => $phpFiles,
            'joomla'        => (string) ($data['core']['joomla_version'] ?? '?'),
            'offline'       => !empty($data['core']['offline']),
            'backend_users' => $backendUsers,
            'backend_mfa'   => $backendMfa,
            'super_ids'     => $superIds,
            'backup_days'   => $backupDays,
            'backup_last'   => $backupLast,
            'users_total'   => \is_numeric($usersTotal) ? (int) $usersTotal : null,
            'extensions'  => $extensions,
            'tasks'       => $tasks,
            'updates'     => $updates,
        ];
    }

    /**
     * Compare deux instantanés et renvoie les changements en français.
     */
    private function diffSnapshots(array $old, array $new): array
    {
        $lines = [];

        // NOUVEAUX FICHIERS PHP dans les emplacements sensibles = porte dérobée probable.
        // (On n'alerte que sur les APPARITIONS, pas les disparitions : un fichier
        //  supprimé n'est pas une menace.)
        if (\is_array($old['php_files'] ?? null) && \is_array($new['php_files'] ?? null)) {
            $added = array_diff($new['php_files'], $old['php_files']);

            foreach ($added as $file) {
                $lines[] = '🛑 FICHIER PHP APPARU : ' . $file . ' — porte dérobée possible, à vérifier d\'urgence';
            }
        }

        // Compatibilité : les anciens instantanés stockaient la liste sous 'super_users'.
        $oldUsers = $old['backend_users'] ?? ($old['super_users'] ?? []);
        $newUsers = $new['backend_users'] ?? [];

        // SUPER ADMIN apparu ou compte existant PROMU super admin : signal de
        // compromission le plus fort après un fichier PHP suspect. Traité en premier
        // et avec un ton sans ambiguïté (cf. l'article : « il s'ajoute un Super User »).
        $newSuper = $new['super_ids'] ?? [];

        // Garde-fou : si l'ancien instantané est ANTÉRIEUR à cette fonction (clé
        // absente), on ne compare pas ce cycle-ci — sinon tous les admins déjà en
        // place seraient signalés « créés ». Le nouvel instantané mémorise la liste,
        // et la comparaison redevient fiable dès le passage suivant.
        $oldSuper = \array_key_exists('super_ids', $old) ? (array) $old['super_ids'] : $newSuper;

        foreach (array_diff_key($newSuper, $oldSuper) as $id => $label) {
            $noMfa       = (($new['backend_mfa'][$id] ?? null) === false) ? ' (et SANS 2FA)' : '';
            $isNewAcct   = !\array_key_exists((string) $id, $oldUsers);

            $lines[] = $isNewAcct
                ? '🛑 SUPER ADMIN CRÉÉ : ' . $label . $noMfa
                    . ' — un compte super administrateur vient d\'apparaître. Si ce n\'est pas de votre fait, '
                    . 'COMPROMISSION PROBABLE : vérifiez le site IMMÉDIATEMENT.'
                : '🛑 ÉLÉVATION EN SUPER ADMIN : ' . $label . $noMfa
                    . ' — un compte existant a reçu les droits super administrateur. À vérifier d\'urgence.';
        }

        foreach (array_diff_key($newUsers, $oldUsers) as $id => $label) {
            // Les nouveaux super admins sont déjà signalés ci-dessus (alerte forte).
            if (\array_key_exists((string) $id, $newSuper)) {
                continue;
            }

            $noMfa   = (($new['backend_mfa'][$id] ?? null) === false) ? ' — SANS 2FA !' : '';
            $lines[] = '⚠ UTILISATEUR BACKEND AJOUTÉ : ' . $label . $noMfa;
        }

        foreach (array_diff_key($oldUsers, $newUsers) as $label) {
            $lines[] = 'Utilisateur backend retiré : ' . $label;
        }

        // Double authentification activée ou désactivée sur un compte backend.
        $oldMfa = $old['backend_mfa'] ?? [];
        $newMfa = $new['backend_mfa'] ?? [];

        foreach (array_intersect_key($newMfa, $oldMfa) as $id => $mfa) {
            $label = $newUsers[$id] ?? ('utilisateur #' . $id);

            if ($oldMfa[$id] === true && $mfa === false) {
                $lines[] = '⚠ 2FA DÉSACTIVÉE pour ' . $label;
            } elseif ($oldMfa[$id] === false && $mfa === true) {
                $lines[] = '2FA activée pour ' . $label;
            }
        }

        // Sauvegarde Akeeba : alerte au franchissement des seuils 15 j et 30 j.
        $oldBackup = $old['backup_days'] ?? null;
        $newBackup = $new['backup_days'] ?? null;

        if (\is_int($oldBackup) && \is_int($newBackup)) {
            if ($oldBackup <= 30 && $newBackup > 30) {
                $lines[] = '⚠ CRITIQUE : aucune sauvegarde Akeeba réussie depuis ' . $newBackup . ' jours (dernière : ' . ($new['backup_last'] ?? '?') . ')';
            } elseif ($oldBackup <= 15 && $newBackup > 15) {
                $lines[] = '⚠ Aucune sauvegarde Akeeba réussie depuis ' . $newBackup . ' jours (dernière : ' . ($new['backup_last'] ?? '?') . ')';
            }
        }

        // Certificat SSL : expiration proche, expiré, renouvelé.
        $oldSsl = \is_array($old['ssl'] ?? null) ? ($old['ssl']['days'] ?? null) : null;
        $newSsl = \is_array($new['ssl'] ?? null) ? ($new['ssl']['days'] ?? null) : null;

        if (\is_int($oldSsl) && \is_int($newSsl)) {
            $expires = \is_array($new['ssl']) ? ($new['ssl']['expires'] ?? '?') : '?';

            if ($oldSsl >= 0 && $newSsl < 0) {
                $lines[] = '⚠ CERTIFICAT SSL EXPIRÉ (depuis le ' . $expires . ')';
            } elseif ($oldSsl > 14 && $newSsl <= 14) {
                $lines[] = '⚠ Certificat SSL : expiration dans ' . $newSsl . ' jours (le ' . $expires . ')';
            } elseif ($oldSsl <= 14 && $newSsl > 30) {
                $lines[] = 'Certificat SSL renouvelé (expire le ' . $expires . ')';
            }
        }

        // Variation massive du nombre total de comptes (spam d'inscriptions, purge...).
        if (isset($old['users_total'], $new['users_total'])) {
            $delta = (int) $new['users_total'] - (int) $old['users_total'];

            if ($delta >= 10) {
                $lines[] = '⚠ CRÉATION MASSIVE DE COMPTES : +' . $delta . ' utilisateurs (total : ' . $new['users_total'] . ')';
            } elseif ($delta <= -10) {
                $lines[] = 'Suppression massive de comptes : ' . $delta . ' utilisateurs (total : ' . $new['users_total'] . ')';
            }
        }

        $oldExt = $old['extensions'] ?? [];
        $newExt = $new['extensions'] ?? [];

        foreach (array_diff_key($newExt, $oldExt) as $ext) {
            $lines[] = '⚠ Extension installée : ' . $ext['name'];
        }

        foreach (array_diff_key($oldExt, $newExt) as $ext) {
            $lines[] = 'Extension désinstallée : ' . $ext['name'];
        }

        foreach (array_intersect_key($newExt, $oldExt) as $id => $ext) {
            if ($ext['enabled'] && !$oldExt[$id]['enabled']) {
                $lines[] = '⚠ Extension activée : ' . $ext['name'];
            } elseif (!$ext['enabled'] && $oldExt[$id]['enabled']) {
                $lines[] = 'Extension désactivée : ' . $ext['name'];
            }
        }

        foreach (array_diff_key($new['tasks'] ?? [], $old['tasks'] ?? []) as $title) {
            $lines[] = '⚠ Tâche planifiée créée : ' . $title;
        }

        foreach (array_diff_key($old['tasks'] ?? [], $new['tasks'] ?? []) as $title) {
            $lines[] = 'Tâche planifiée supprimée : ' . $title;
        }

        if (($new['joomla'] ?? '') !== ($old['joomla'] ?? '')) {
            $lines[] = 'Version de Joomla : ' . ($old['joomla'] ?? '?') . ' → ' . ($new['joomla'] ?? '?');
        }

        if (($new['offline'] ?? false) !== ($old['offline'] ?? false)) {
            $lines[] = ($new['offline'] ?? false)
                ? 'Le site est passé HORS LIGNE (mode maintenance).'
                : 'Le site est repassé EN LIGNE.';
        }

        foreach (array_diff($new['updates'] ?? [], $old['updates'] ?? []) as $update) {
            $lines[] = 'Mise à jour disponible : ' . $update;
        }

        return $lines;
    }

    // ------------------------------------------------------------------
    // Stockage de l'état (#__oculus_state)
    // ------------------------------------------------------------------

    /**
     * Jours restants avant expiration du certificat SSL du site.
     */
    private function getSslDays(string $url): ?array
    {
        try {
            $host = (string) parse_url($url, PHP_URL_HOST);

            if ($host === '' || stripos($url, 'https://') !== 0) {
                return null;
            }

            $context = stream_context_create(['ssl' => [
                'capture_peer_cert' => true,
                'verify_peer'       => false,
                'verify_peer_name'  => false,
                'SNI_enabled'       => true,
            ]]);

            $client = @stream_socket_client('ssl://' . $host . ':443', $errno, $errstr, 8, STREAM_CLIENT_CONNECT, $context);

            if (!$client) {
                return null;
            }

            $params = stream_context_get_params($client);
            fclose($client);

            $certResource = $params['options']['ssl']['peer_certificate'] ?? null;

            if (!$certResource) {
                return null;
            }

            $cert = openssl_x509_parse($certResource);

            if (!\is_array($cert) || empty($cert['validTo_time_t'])) {
                return null;
            }

            return [
                'days'    => (int) floor(((int) $cert['validTo_time_t'] - time()) / 86400),
                'expires' => date('d-m-Y H:i', (int) $cert['validTo_time_t']),
            ];
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function loadState(array $site): object
    {
        $db  = $this->getDatabase();
        $key = md5(rtrim($site['url'], '/'));

        $row = $db->setQuery(
            $db->getQuery(true)
                ->select('*')
                ->from($db->quoteName('#__oculus_state'))
                ->where($db->quoteName('site_key') . ' = ' . $db->quote($key))
        )->loadObject();

        if ($row === null) {
            $row = (object) [
                'site_key'     => $key,
                'snapshot'     => null,
                'failures'     => 0,
                'alerted_down' => 0,
                '_new'         => true,
            ];
        }

        $row->site_name = $site['name'];
        $row->site_url  = $site['url'];

        return $row;
    }

    private function saveState(object $state): void
    {
        $db    = $this->getDatabase();
        $isNew = !empty($state->_new);
        unset($state->_new);

        $state->checked      = gmdate('Y-m-d H:i:s');
        $state->failures     = (int) $state->failures;
        $state->alerted_down = (int) $state->alerted_down;

        if ($isNew) {
            $db->insertObject('#__oculus_state', $state, 'site_key');
        } else {
            $db->updateObject('#__oculus_state', $state, 'site_key');
        }
    }

    // ------------------------------------------------------------------
    // Envoi des mails
    // ------------------------------------------------------------------

    /**
     * Envoie aux super users du site central ayant
     * « Recevoir les emails système » activé.
     */
    private function sendMail(string $subject, string $body): void
    {
        $recipients = $this->getRecipients();

        if ($recipients === []) {
            $this->logTask('Aucun destinataire : aucun super user avec « Recevoir les emails système ».', 'warning');

            return;
        }

        foreach ($recipients as $email) {
            try {
                $mailer = $this->getMailerFactory()->createMailer();
                $mailer->isHtml(false);
                $mailer->setSubject($subject);
                $mailer->setBody($body . "\n\n— Oculus, surveillance du parc Joomla");
                $mailer->addRecipient($email);
                $mailer->Send();
            } catch (\Throwable $e) {
                $this->logTask('Envoi du mail impossible à ' . $email . ' : ' . $e->getMessage(), 'error');
            }
        }
    }

    private function getRecipients(): array
    {
        $db = $this->getDatabase();

        $groupIds = $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName('id'))
                ->from($db->quoteName('#__usergroups'))
        )->loadColumn();

        $superGroups = [];

        foreach ($groupIds as $groupId) {
            if (Access::checkGroup((int) $groupId, 'core.admin')) {
                $superGroups[] = (int) $groupId;
            }
        }

        if ($superGroups === []) {
            return [];
        }

        $userIds = $db->setQuery(
            $db->getQuery(true)
                ->select('DISTINCT ' . $db->quoteName('user_id'))
                ->from($db->quoteName('#__user_usergroup_map'))
                ->whereIn($db->quoteName('group_id'), $superGroups)
        )->loadColumn();

        if ($userIds === []) {
            return [];
        }

        return $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName('email'))
                ->from($db->quoteName('#__users'))
                ->whereIn($db->quoteName('id'), array_map('intval', $userIds))
                ->where($db->quoteName('block') . ' = 0')
                ->where($db->quoteName('sendEmail') . ' = 1')
        )->loadColumn();
    }
}
