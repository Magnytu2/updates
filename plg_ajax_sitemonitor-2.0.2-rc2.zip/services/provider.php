<?php

/**
 * Oculus — Plugin client de surveillance (groupe ajax).
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\Database\DatabaseInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Event\DispatcherInterface;
use Joomanji\Plugin\Ajax\Sitemonitor\Extension\Sitemonitor;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            PluginInterface::class,
            function (Container $container) {
                $plugin = new Sitemonitor(
                    $container->get(DispatcherInterface::class),
                    (array) PluginHelper::getPlugin('ajax', 'sitemonitor')
                );
                $plugin->setApplication(Factory::getApplication());
                $plugin->setDatabase($container->get(DatabaseInterface::class));

                return $plugin;
            }
        );
    }
};
