<?php

/**
 * Oculus — Champ « Token secret » : boutons Générer et Copier,
 * affichage de la version installée du plugin.
 * Le token est généré par le navigateur (crypto.getRandomValues),
 * il ne transite par aucun serveur.
 *
 * @copyright (C) 2026 Joomanji
 * @license   GNU General Public License version 2 or later
 */

namespace Joomanji\Plugin\Ajax\Sitemonitor\Field;

\defined('_JEXEC') or die;

use Joomla\CMS\Form\Field\TextField;
use Joomanji\Plugin\Ajax\Sitemonitor\Extension\Sitemonitor;

class TokenField extends TextField
{
    protected $type = 'Token';

    protected function getInput()
    {
        $input = parent::getInput();
        $id    = htmlspecialchars($this->id, ENT_QUOTES, 'UTF-8');

        $jsGenerate = "var a=new Uint8Array(20);"
            . "crypto.getRandomValues(a);"
            . "var f=document.getElementById('" . $id . "');"
            . "f.value=Array.from(a,function(b){return ('0'+b.toString(16)).slice(-2);}).join('');"
            . "f.dispatchEvent(new Event('change'));";

        $jsCopy = "var f=document.getElementById('" . $id . "');"
            . "var b=this;"
            . "navigator.clipboard.writeText(f.value).then(function(){"
            . "b.textContent='Copié !';"
            . "setTimeout(function(){b.textContent='Copier';},2000);"
            . "});";

        return '<div class="input-group">'
            . $input
            . '<button type="button" class="btn btn-primary"'
            . ' onclick="' . htmlspecialchars($jsGenerate, ENT_QUOTES, 'UTF-8') . '">Générer un token</button>'
            . '<button type="button" class="btn btn-outline-secondary"'
            . ' onclick="' . htmlspecialchars($jsCopy, ENT_QUOTES, 'UTF-8') . '">Copier</button>'
            . '</div>'
            . '<div class="form-text">Générez, copiez, puis collez la valeur dans le module Oculus du site central. Un token unique par site.</div>'
            . '<div class="mt-2"><span class="badge bg-info">Plugin Oculus — version installée : '
            . htmlspecialchars(Sitemonitor::installedVersion(), ENT_QUOTES, 'UTF-8')
            . '</span></div>';
    }
}
