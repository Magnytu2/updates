<?php

/**
 * @package     Corpus
 * @copyright   Copyright (C) 2026 Cyrille Poussin.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

/**
 * LE SCRIPT DU PAQUET
 *
 * Il fait UNE chose apres l'installation : activer le plugin.
 *
 * Sans cela, l'installation reussit, le template s'affiche, et le champ
 * « Gabarit d'article » n'apparait nulle part dans les categories. Personne ne
 * fait le rapprochement avec un plugin desactive : on cherche la panne dans le
 * template. Une extension qui a besoin d'etre activee pour fonctionner
 * s'active elle-meme, ou elle n'aurait pas du etre livree ensemble.
 */
return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            InstallerScriptInterface::class,
            new class () implements InstallerScriptInterface {
                public function install(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function update(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function uninstall(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                /**
                 * LE VERROU DE VERSION DE JOOMLA (16 octobre 2026, decision de Cyrille)
                 *
                 * Corpus suit la derniere version mineure de Joomla (CLAUDE.md
                 * commun, § 10). Depuis Joomla 6.2.0, sortie le 13 octobre 2026,
                 * il n'est plus garanti sur la 6.1 : on refuse l'installation et
                 * la mise a jour sur un Joomla plus ancien, avec un message qui
                 * dit quoi faire. Un site qui ne recoit rien ne casse pas.
                 *
                 * La desinstallation n'est jamais bloquee.
                 */
                public function preflight(string $type, InstallerAdapter $adapter): bool
                {
                    if (!\in_array($type, ['install', 'update', 'discover_install'], true)) {
                        return true;
                    }

                    if (version_compare(JVERSION, '6.2.0', '<')) {
                        $version = (string) ($adapter->getManifest()->version ?? '');
                        $cle     = 'PKG_CORPUS_JOOMLA_TROP_ANCIEN';

                        // Au moment du preflight, la langue du paquet n'est pas
                        // forcement chargee : on la charge depuis l'archive.
                        if (Text::_($cle) === $cle) {
                            $source = (string) $adapter->getParent()->getPath('source');
                            $langue = Factory::getApplication()->getLanguage();
                            $langue->load('pkg_corpus.sys', $source, null, false, true)
                                || $langue->load('pkg_corpus.sys', JPATH_ADMINISTRATOR, null, false, true);
                        }

                        $message = Text::_($cle) === $cle
                            ? 'Corpus %s requires Joomla 6.2 or later. Please update Joomla first.'
                            : Text::_($cle);

                        Factory::getApplication()->enqueueMessage(sprintf($message, $version), 'error');

                        return false;
                    }

                    return true;
                }

                public function postflight(string $type, InstallerAdapter $adapter): bool
                {
                    if ($type === 'uninstall') {
                        return true;
                    }

                    $db    = Factory::getContainer()->get(DatabaseInterface::class);
                    $query = $db->getQuery(true)
                        ->update($db->quoteName('#__extensions'))
                        ->set($db->quoteName('enabled') . ' = 1')
                        ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                        ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
                        ->where($db->quoteName('element') . ' = ' . $db->quote('corpus'));

                    try {
                        $db->setQuery($query)->execute();
                    } catch (\Throwable $e) {
                        // On ne fait pas echouer une installation reussie pour
                        // ca : on le dit, et l'administrateur active a la main.
                        Factory::getApplication()->enqueueMessage(
                            Text::_('PKG_CORPUS_PLUGIN_NON_ACTIVE'),
                            'warning'
                        );
                    }

                    return true;
                }
            }
        );
    }
};
