<?php
/**
 * Aide du module de démarrage Corpus.
 *
 * Phase 3 : installation réelle du scénario « blog » et réinitialisation.
 *
 * MARQUAGE. Tout ce que ce module crée porte la note « corpus_start » dans
 * la colonne `note` de sa table (contenu, catégories, tags, champs, menus).
 * La réinitialisation ne supprime QUE ce qui porte cette note : rien d'autre
 * n'est touché, et surtout pas les réglages du template.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;
use Joomla\Database\ParameterType;
use Joomla\Filesystem\File;
use Joomla\Filesystem\Folder;

class ModCorpusStartHelper
{
	/**
	 * Note posée sur chaque élément créé. Seule clé de la réinitialisation.
	 */
	public const MARKER = 'corpus_start';

	/**
	 * Le scénario en cours d'installation ou de retrait.
	 *
	 * IL SUFFIXE LE MARQUEUR ET LES SAUVEGARDES, et c'est ce qui rend le retrait
	 * SÉLECTIF possible : un site de démonstration porte les quatre mises en
	 * page à la fois, et remonter l'une d'elles après une version de Corpus ne
	 * doit pas faire disparaître les trois autres le temps de la manoeuvre.
	 *
	 * Vide, on parle de tout ce que le module a posé, quel que soit le scénario.
	 *
	 * @var string
	 */
	protected static $scenario = '';

	/**
	 * La note à poser sur ce que le scénario crée.
	 *
	 * `corpus_start:landing` plutôt que `corpus_start`. Les recherches globales
	 * passent par `LIKE 'corpus_start%'`, qui retrouve les deux formes : une
	 * démonstration posée par une version antérieure du module, sans suffixe,
	 * reste donc retirable.
	 *
	 * @return string
	 */
	protected static function marker(): string
	{
		return self::$scenario !== '' ? self::MARKER . ':' . self::$scenario : self::MARKER;
	}

	/**
	 * Les scénarios actuellement installés, lus dans les notes des articles.
	 *
	 * Chaque scénario en pose au moins un : c'est le repère le plus sûr, et il
	 * ne demande aucun réglage à tenir à jour en parallèle.
	 *
	 * @return string[]
	 */
	public static function getInstalled(): array
	{
		/*
		 * LES ENTRÉES DE MENU, ET NON LES ARTICLES.
		 *
		 * Depuis que le contenu est partagé, les articles portent la marque
		 * `commun` et non celle d'un scénario : les compter ne dirait plus
		 * quelles démonstrations sont en place. Chaque scénario, lui, crée ses
		 * propres entrées de menu, et il est le seul à le faire.
		 */
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select('DISTINCT ' . $db->quoteName('note'))
			->from($db->quoteName('#__menu'))
			->where($db->quoteName('note') . ' LIKE ' . $db->quote(self::MARKER . '%'));

		$notes = (array) $db->setQuery($query)->loadColumn();
		$liste = [];

		foreach ($notes as $note) {
			$bout = explode(':', (string) $note, 2);

			// Sans suffixe : une démonstration d'avant le retrait sélectif. On la
			// range sous une clé vide, pour que le bouton global reste le seul à
			// pouvoir la retirer.
			$liste[] = $bout[1] ?? '';
		}

		// `commun` n'est pas un scénario : c'est le contenu que les autres se
		// partagent. Il ne s'installe ni ne se retire tout seul.
		return array_values(array_diff(array_unique($liste), ['commun']));
	}

	/**
	 * Les menus créés par l'installation en cours, clé du scénario vers nom réel.
	 *
	 * Une propriété plutôt qu'un argument de plus : elle sert au seul repère
	 * {menu:…}, et la faire descendre jusqu'à `resoudreParams` obligerait à
	 * changer six signatures pour un cas.
	 *
	 * @var array<string, string>
	 */
	protected static $menuTypes = [];

	/**
	 * Le style de template dédié au scénario, quand il en demande un.
	 *
	 * 0 signifie « le style par défaut du site ». Voir createStyleScenario()
	 * pour ce que ce détour répare.
	 *
	 * @var int
	 */
	protected static $styleScenarioId = 0;

	/**
	 * Les quatre scénarios de démarrage.
	 *
	 * 'langPrefix' pointe vers les clés MOD_CORPUS_START_SCENARIO_xxx_TITLE
	 * et _DESC des fichiers de langue. 'icon' est une classe de l'icône
	 * d'administration native de Joomla (préfixe icon-), jamais Font Awesome.
	 *
	 * @return array<string, array{icon: string, langPrefix: string}>
	 */
	public static function getScenarios(): array
	{
		return [
			'blog' => [
				'icon'       => 'icon-book',
				'langPrefix' => 'MOD_CORPUS_START_SCENARIO_BLOG',
			],
			'magazine' => [
				'icon'       => 'icon-grid-2',
				'langPrefix' => 'MOD_CORPUS_START_SCENARIO_MAGAZINE',
			],
			'landing' => [
				'icon'       => 'icon-flag',
				'langPrefix' => 'MOD_CORPUS_START_SCENARIO_LANDING',
			],
			'multilingue' => [
				'icon'       => 'icon-language',
				'langPrefix' => 'MOD_CORPUS_START_SCENARIO_MULTILINGUE',
			],
		];
	}

	/**
	 * La clé de langue du nom d'un scénario, pour le nommer dans un message.
	 *
	 * On passe par `getScenarios()` plutôt que par une seconde liste : deux
	 * listes de scénarios divergent le jour où l'on en ajoute un, et c'est
	 * toujours celle qu'on a oubliée qui sert au message d'erreur.
	 *
	 * @param  string $cle
	 *
	 * @return string La clé de langue, ou la clé brute si le scénario est
	 *                inconnu : mieux vaut « landing » qu'un message vide.
	 */
	protected static function nomScenario(string $cle): string
	{
		$scenarios = self::getScenarios();

		return isset($scenarios[$cle])
			? $scenarios[$cle]['langPrefix'] . '_TITLE'
			: $cle;
	}

	/**
	 * Point d'entrée Ajax du module.
	 *
	 * Appelé via index.php?option=com_ajax&module=corpus_start&format=json,
	 * avec 'task' = une clé de getScenarios() ou 'reset', et le jeton CSRF
	 * en paramètre de requête (Joomla.getOptions('csrf.token')=1).
	 *
	 * @return array
	 * @throws Exception
	 */
	public static function getAjax()
	{
		if (!Session::checkToken('request')) {
			throw new Exception(Text::_('JINVALID_TOKEN'), 403);
		}

		$app  = Factory::getApplication();
		$task = $app->getInput()->getCmd('task', '');

		$known   = array_keys(self::getScenarios());
		$known[] = 'reset';

		if (!in_array($task, $known, true)) {
			throw new Exception('Tâche inconnue : ' . $task, 400);
		}

		// com_ajax ne charge pas la langue du module : il faut le faire ici.
		$app->getLanguage()->load('mod_corpus_start', JPATH_ADMINISTRATOR);

		if ($task === 'reset') {
			/*
			 * LE RETRAIT SÉLECTIF. Sans `scenario`, on retire tout ce que le
			 * module a posé, y compris les démonstrations d'une version
			 * antérieure, qui n'ont pas de suffixe.
			 *
			 * Le nom reçu est vérifié contre la liste des scénarios connus : il
			 * finit dans une note et dans des clés de réglages, ce n'est pas un
			 * endroit où laisser passer ce qui vient de la requête.
			 */
			$vise = $app->getInput()->getCmd('scenario', '');

			self::$scenario = in_array($vise, array_keys(self::getScenarios()), true) ? $vise : '';

			return self::reset();
		}

		self::$scenario = $task;

		$file = __DIR__ . '/content/' . $task . '.php';

		if (!is_file($file)) {
			// Scénario prévu mais pas encore écrit (magazine, landing, multilingue).
			return [
				'task'    => $task,
				'message' => Text::_('MOD_CORPUS_START_NOT_YET'),
			];
		}

		$contenu = require $file;

		// UNE SEULE MISE EN PAGE À LA FOIS, et le refus est ici, avant les deux
		// branches : les deux mécaniques d'installation écrivent dans le même
		// style de site et se disputeraient les mêmes réglages. Voir la méthode.
		self::refuserSiDejaInstalle();

		// Le scénario multilingue ne monte ni gabarit, ni préréglage, ni champ :
		// il a sa propre mécanique, et elle dépend des langues installées.
		if (!empty($contenu['multilangue'])) {
			return self::installMultilangue($task, $contenu['multilangue']);
		}

		return self::install($task, $contenu);
	}

	// =====================================================================
	// INSTALLATION
	// =====================================================================

	/**
	 * Refuse une seconde mise en page tant que la première est là.
	 *
	 * UNE SEULE À LA FOIS, ET LE REFUS PORTE SUR LE SITE ENTIER.
	 *
	 * Décision de Cyrille du 26 août 2026, après avoir installé le magazine
	 * par-dessus le blog : « cela met le bazar ». Il a raison, et la
	 * cohabitation était une erreur de conception de ma part.
	 *
	 * CE QUI SE DISPUTAIT. Le style du site est unique : la couleur, la largeur
	 * de page, le nom du logo, les zones allumées sont écrits par la dernière
	 * installation, qui écrase la précédente. La page d'accueil par défaut est
	 * unique elle aussi. Les modules des deux scénarios remplissent les mêmes
	 * positions.
	 *
	 * ET LA RÉINITIALISATION NE POUVAIT PLUS RIEN RENDRE DE JUSTE : chaque
	 * sauvegarde de réglage est prise AVANT écriture, donc la seconde
	 * installation notait comme « valeur d'avant » ce que la première venait de
	 * poser. Retirer les deux rendait un état qui n'avait jamais existé.
	 *
	 * L'ARCHITECTURE RETENUE LE DIT DÉJÀ : quatre sites de démonstration, un
	 * scénario chacun. Rien ne demandait qu'ils tiennent ensemble.
	 *
	 * LE REFUS EST ICI, ET PAS SEULEMENT DANS LE TABLEAU DE BORD. Les boutons y
	 * sont désactivés quand une démonstration est en place, mais un bouton
	 * désactivé n'est qu'une politesse : la tâche passe par `com_ajax`, et on ne
	 * construit pas une garantie sur du HTML.
	 *
	 * @return void
	 * @throws Exception
	 */
	protected static function refuserSiDejaInstalle(): void
	{
		$deja = self::getInstalled();

		if (!$deja) {
			return;
		}

		$noms = [];

		foreach ($deja as $cle) {
			$noms[] = $cle === ''
				? Text::_('MOD_CORPUS_START_UNNAMED')
				: Text::_(self::nomScenario($cle));
		}

		throw new Exception(
			Text::sprintf('MOD_CORPUS_START_ALREADY_INSTALLED', implode(', ', $noms)),
			409
		);
	}


	/**
	 * Installe un scénario à partir de son tableau de contenu.
	 *
	 * @param  string $task
	 * @param  array  $content
	 *
	 * @return array
	 * @throws Exception
	 */
	protected static function install(string $task, array $content): array
	{
		/*
		 * LE FILTRE DE LANGUE S'ALLUME AVANT TOUT LE RESTE, ET C'EST UN ORDRE
		 * D'OPÉRATIONS, PAS UNE PRÉFÉRENCE.
		 *
		 * Relevé le 25 août, dans `Table\Menu::store()` de Joomla 6.1.2 : deux
		 * entrées de menu de même alias au même niveau ne sont acceptées, en
		 * langues différentes, QUE si `Multilanguage::isEnabled()` répond vrai.
		 * Sinon Joomla applique le contrôle monolingue et refuse le doublon,
		 * quel que soit le menu.
		 *
		 * En allumant le filtre après la création des entrées, la première
		 * langue passait et la seconde était refusée à sa première entrée : le
		 * menu anglais existait, vide. C'est ce que Cyrille a vu.
		 *
		 * TOUT EN TÊTE, et non juste avant la boucle : `isEnabled()` garde son
		 * résultat pour toute la requête, dès le premier appel. Or le premier
		 * appel vient des modèles de Joomla, à la création des catégories.
		 */
		$langues  = self::languesDuSite();
		$bilingue = count($langues) >= 2 && !empty($content['parLangue']);

		if ($bilingue) {
			self::publierLanguesContenu($langues);
			self::activerFiltreDeLangue();
		} else {
			$langues = ['*'];
		}

		$counts = ['categories' => 0, 'fields' => 0, 'articles' => 0, 'menu' => 0];

		/*
		 * --- 0. LES IMAGES, ET ELLES PASSENT EN PREMIER ---------------------
		 *
		 * L'ORDRE EST LA CHOSE QUI COMPTE ICI, et il a coûté une demi-journée.
		 * Relevé par Cyrille le 26 août 2026 : les fichiers étaient bien dans
		 * `images/corpus-start/` sur le disque, et pas une seule vignette ne
		 * s'affichait.
		 *
		 * `imagesJson()`, qui remplit le champ « Images » d'un article, vérifie
		 * que le fichier EXISTE avant d'écrire son chemin : sans cette
		 * vérification, un article pointerait une image absente. La copie était
		 * appelée plus bas, APRÈS la création des articles. Les quatorze
		 * articles recevaient donc `{}`, et les images arrivaient une seconde
		 * trop tard, sur un disque que plus personne ne relisait.
		 *
		 * Rien ne le signalait : ni erreur, ni compte faux. Les fichiers étaient
		 * là, les articles étaient là, et le lien entre les deux n'existait pas.
		 *
		 * CE QUE CELA IMPLIQUE POUR UNE DÉMONSTRATION DÉJÀ POSÉE : le contenu
		 * commun n'est créé qu'une fois. Des articles écrits avec `{}` gardent
		 * leur champ vide, même après une nouvelle installation d'un autre
		 * scénario. Il faut réinitialiser en entier, puis réinstaller.
		 */
		$counts['images'] = self::copyImages();

		// --- 1 à 3. Le contenu, posé une fois et partagé --------------------
		// Voir installerCommun() : les catégories, les champs et les articles
		// appartiennent à tous les scénarios à la fois.
		$commun = self::installerCommun($content);

		$catIds     = $commun['catIds'];
		$fieldIds   = $commun['fieldIds'];
		$articleIds = $commun['articleIds'];
		$groupId    = $commun['groupId'];

		$counts['categories'] = $commun['categories'];
		$counts['fields']     = $commun['fields'];
		$counts['articles']   = $commun['articles'];

		// --- 2 bis. Le gabarit d'article, et son affectation ----------------
		// Il porte les identifiants réels des champs qu'on vient de créer :
		// il ne peut donc s'écrire qu'ici, une fois les champs en base.
		$gabarit = self::createGabarit($fieldIds, $groupId);

		if ($gabarit !== '') {
			self::assignGabarit($catIds[$content['gabarit']['categorie']], $gabarit);

			// Les catégories qui doivent garder la mise en page classique de
			// Joomla. Sans cette affectation explicite elles retomberaient sur
			// le premier gabarit déclaré, faute d'en hériter d'une parente.
			foreach ($content['gabarit']['natif'] ?? [] as $cle) {
				if (!empty($catIds[$cle])) {
					self::assignGabarit($catIds[$cle], 'natif');
				}
			}

			// Le gabarit place les champs lui-même : l'affichage automatique
			// de Joomla les sortirait une seconde fois.
			self::hideFieldsFromAutoDisplay(array_values($fieldIds));

		}

		// --- 2 quater. Le préréglage de mise en page ------------------------
		/*
		 * LE STYLE DÉDIÉ D'ABORD, s'il en faut un : tout ce qui suit écrit dans
		 * le style CIBLE, et la cible n'est plus le style du site dès qu'il
		 * existe. Voir createStyleScenario() pour la panne que cela répare.
		 */
		self::$styleScenarioId = 0;

		if (!empty($content['styleDedie'])) {
			self::$styleScenarioId = self::createStyleScenario($content['styleDedie']['title']);
		}

		$counts['preset'] = !empty($content['preset']) ? self::applyPreset($content['preset']) : 0;

		/*
		 * LES RÉGLAGES QUI DOIVENT ALLER DANS LE STYLE DU SITE, même quand le
		 * scénario travaille dans un style dédié. Un seul cas aujourd'hui : la
		 * largeur de page de la landing, qui doit valoir aussi pour les articles
		 * et les catégories, lesquels gardent le style du site.
		 *
		 * On vise le style du site en remettant la cible à zéro le temps de
		 * l'écriture. La sauvegarde joue normalement : ces valeurs-là seront
		 * rendues à la réinitialisation.
		 */
		if (!empty($content['styleParamsSite'])) {
			$cible = self::$styleScenarioId;
			self::$styleScenarioId = 0;

			$counts['preset'] += self::applyStyleParams($content['styleParamsSite']);

			self::$styleScenarioId = $cible;
		}

		// Les réglages de style propres au scénario, posés APRÈS le préréglage
		// pour pouvoir le corriger : la largeur de page, la zone de recherche.
		$counts['preset'] += self::applyStyleParams($content['styleParams'] ?? []);

		// --- 4. Mises en avant ---------------------------------------------
		$counts['featured'] = self::setFeatured($content['featured'] ?? [], $articleIds);

		// --- 5. Éléments de menu -------------------------------------------
		/*
		 * LES LANGUES DE LA DÉMONSTRATION.
		 *
		 * Décision de Cyrille du 25 août : les quatre sites de démonstration
		 * parlent français ET anglais. Ce qui EXPLIQUE Corpus est traduit ; le
		 * contenu d'illustration, lui, reste en langue « Toutes » et s'affiche
		 * dans les deux. C'est le choix A du 25 août, et il tient en une phrase :
		 * un visiteur anglophone trouve dans sa langue tout ce qui explique le
		 * template, et tombe sur des recettes françaises, ce qu'on attend d'un
		 * éditeur français.
		 *
		 * Un site qui n'a qu'une langue installée retombe sur l'ancien
		 * comportement, langue « Toutes » partout : c'est ce qui se passe sur un
		 * Joomla ordinaire, et le module doit continuer d'y servir.
		 */
		self::$menuTypes = [];

		$modulesCrees      = [];
		$counts['menu']    = 0;
		$counts['modules'] = 0;
		$accueils          = [];

		foreach ($langues as $code) {
			/*
			 * CHAQUE LANGUE A SON MENU, SES ENTRÉES ET SES MODULES.
			 *
			 * C'est la règle du multilingue de Joomla, et elle n'a rien
			 * d'optionnel : le filtre de langue choisit la page d'accueil de la
			 * langue courante, et un module sans langue s'affiche dans toutes.
			 * Un seul menu pour deux langues afficherait les deux jeux
			 * d'entrées l'un sous l'autre.
			 *
			 * Le suffixe reste absent en monolingue, pour que les noms de menus
			 * ne changent pas sur un site qui n'a qu'une langue.
			 */
			$suffixe  = $bilingue ? '-' . strtolower($code) : '';
			$langueOu = $bilingue ? $code : '*';

			$bloc = $bilingue ? ($content['parLangue'])($code) : $content;

			$menutype = self::createMenuType(
				'corpus-' . self::$scenario . $suffixe,
				($bloc['menuTitre'] ?? ('Corpus : ' . self::$scenario)) . ($bilingue ? ' (' . $code . ')' : ''),
				$bloc['menuDesc'] ?? ''
			);

			// Les menus annexes du scénario, la page d'atterrissage en demande
			// un pour ses appels à l'action.
			foreach ($bloc['menus'] ?? [] as $cle => $menu) {
				self::$menuTypes[$cle] = self::createMenuType(
					$menu['menutype'] . $suffixe,
					$menu['title'],
					$menu['description'] ?? ''
				);
			}

			$menuIds       = [];
			$accueilId     = 0;
			$entreesLangue = [];

			foreach ($bloc['menu'] ?? [] as $item) {
				$cible = !empty($item['menu']) ? (self::$menuTypes[$item['menu']] ?? '') : $menutype;

				if ($cible === '') {
					continue;
				}

				// L'alias doit rester unique dans son menu. Chaque langue ayant
				// le sien, il n'y a rien à suffixer ; la langue, elle, marque
				// l'entrée pour le filtre.
				$item['language'] = $langueOu;

				$id = self::createMenuItem($cible, $item, $catIds, $articleIds, $menuIds);

				if (!$id) {
					continue;
				}

				$entreesLangue[] = $id;
				$toutesEntrees[] = $id;

				if (!empty($item['key'])) {
					$menuIds[$item['key']] = $id;
				}

				if (!empty($item['home'])) {
					$accueilId = $id;
				}

				$counts['menu']++;
			}

			if ($accueilId) {
				$accueils[$code] = $accueilId;
			}

			// Le module de menu de cette langue.
			$moduleMenuId = self::creerModuleMenu(
				$menutype,
				($bloc['menuTitre'] ?? 'Menu') . ($bilingue ? ' (' . $code . ')' : ''),
				$langueOu
			);

			$modulesLangue = array_filter([$moduleMenuId]);

			foreach ($bloc['modules'] ?? [] as $module) {
				// Un module sans langue s'afficherait dans les deux : on impose
				// celle du tour de boucle, sauf si le contenu en demande une
				// autre, ce que fait le sélecteur de langue.
				$module['language'] = $module['language'] ?? $langueOu;

				$modulesLangue[] = self::createModule($module, $catIds, $articleIds, $accueilId);
				$counts['modules']++;
			}

			/*
			 * LES MODULES NE SORTENT QUE SUR LES PAGES DE LEUR LANGUE.
			 *
			 * La langue du module ne suffit pas : elle écarte les autres
			 * langues, pas les autres démonstrations. Sur un site qui n'en porte
			 * qu'une, cette ligne ne change rien ; elle protège le jour où il y
			 * en a deux.
			 */
			$modulesCrees = array_merge($modulesCrees, $modulesLangue);
			self::bornerModulesAuScenario($modulesLangue, $entreesLangue);
		}

		/*
		 * CE QUI REND LE SITE MULTILINGUE, et qui ne se pose qu'une fois.
		 *
		 * Sans le filtre de langue, les deux langues s'affichent en même temps
		 * et le sélecteur ne fait rien de visible. Sans langues de contenu
		 * publiées, le contenu qui les porte devient invisible.
		 */
		if ($bilingue) {
			$counts['langues'] = count($langues);
			$counts['plugin']  = 1;

			if (!empty($content['switch'])) {
				$switch = $content['switch'];

				$modulesCrees[] = self::createModule(
					[
						'title'     => $switch['title'],
						'module'    => 'mod_languages',
						'position'  => $switch['position'],
						'showtitle' => 0,
						'pages'     => 'all',
						'language'  => '*',
						'params'    => $switch['params'],
					],
					[],
					[]
				);

				$counts['modules']++;
			}
		}

		/*
		 * --- 6 bis. LE MODULE DE MENU DE L'UTILISATEUR ----------------------
		 *
		 * MESURÉ SUR LE BANC LE 26 AOÛT, sur la page d'atterrissage anglaise :
		 * la position `menu` portait TROIS modules de navigation. Le nôtre en
		 * français, le nôtre en anglais, et « Main Menu », celui que Joomla
		 * installe avec le site. Dans l'en-tête, cela donnait une liste d'un
		 * seul élément, « Home », collée devant la vraie navigation.
		 *
		 * On le dépublie, comme Joomla le fait lui-même dans sa donnée
		 * d'exemple multilingue. IL N'EST PAS À NOUS : on ne le marque pas, on
		 * ne le supprime jamais, on note son état d'avant et la
		 * réinitialisation le rend tel quel (`restoreMenuPosition`).
		 *
		 * Un second scénario installé par-dessus ne trouve plus de module
		 * publié à dépublier : la requête filtre sur `published = 1`. Il
		 * n'écrase donc pas la sauvegarde du premier, et le retrait du premier
		 * rend bien à l'utilisateur son menu.
		 */
		$counts['menuModule'] = self::depublierModuleMenu() ? 1 : 0;

		/*
		 * --- 7. LES PAGES D'ACCUEIL -----------------------------------------
		 *
		 * En dernier : elles délogent celle de l'utilisateur, et on ne veut pas
		 * le faire si quelque chose a échoué avant.
		 *
		 * EN BILINGUE, CHAQUE LANGUE A LA SIENNE, et elles cohabitent : Joomla
		 * accepte une page par défaut par langue, en plus de celle qui vaut
		 * pour toutes. C'est `setHome()` qui déloge, donc on ne l'appelle que
		 * pour la page « Toutes langues » d'un site monolingue ; les entrées de
		 * langue, elles, portent déjà `home` depuis leur création.
		 */
		$counts['accueil'] = 0;

		if (!$bilingue) {
			$counts['accueil'] = !empty($accueils['*']) ? self::setHome($accueils['*']) : 0;
		}

		/*
		 * --- 7 bis. LE STYLE DÉDIÉ, ET SUR QUELLES ENTRÉES ------------------
		 *
		 * Il ne peut être assigné qu'ici : les entrées n'existaient pas quand le
		 * style a été créé.
		 *
		 * SUR TOUTES, POUR LE BLOG ET LE MAGAZINE. Leur style dédié porte
		 * l'ossature de la démonstration entière, page d'accueil comprise : le
		 * retirer d'une page la ferait sortir du lot.
		 *
		 * SUR LA SEULE PAGE D'ACCUEIL, POUR LA PAGE D'ATTERRISSAGE. Relevé par
		 * Cyrille le 26 août 2026 sur landing.joomanji.eu : « Typographie »,
		 * « Les tampons », « Connexion » et les autres entrées du menu
		 * « Découvrir » s'ouvraient sur une page vide.
		 *
		 * LA CAUSE EST LE PRÉRÉGLAGE `landing` LUI-MÊME, qui pose
		 * `layoutEnable_content: 0` : la page n'est plus faite que de rangées de
		 * modules, et `index.php` du template n'émet plus de <main> du tout.
		 * C'est ce qu'il faut sur l'accueil, qui est bâti de modules ; c'est une
		 * page blanche partout ailleurs. Mesuré sur la page « Connexion » : pas
		 * un `<main>` dans le document, et la feuille chargée était bien celle
		 * du style dédié.
		 *
		 * C'est le même défaut que le 20 août, quand le préréglage était écrit
		 * dans le style DU SITE et éteignait le corps de page partout. On avait
		 * alors créé un style à part sans restreindre à qui il s'applique : le
		 * défaut avait changé de portée, pas de nature.
		 *
		 * `styleParamsSite` de `landing.php` porte déjà ce qui doit valoir pour
		 * tout le site : le nom, la teinte, la largeur, les deux zones. Les
		 * autres pages gardent donc l'identité de la démonstration, et
		 * retrouvent leur corps de page.
		 */
		$cibles = !empty($content['styleDedie']['accueilSeul'])
			? array_values($accueils)
			: $toutesEntrees;

		$counts['styleAssigne'] = self::assignStyleToMenuItems($cibles, self::$styleScenarioId);

		// Le fil d'Ariane, écarté de la seule page d'accueil quand le scénario
		// le demande. Ici aussi, l'entrée devait exister d'abord.
		$counts['ariane'] = 0;

		if (!empty($content['masquerAriane'])) {
			foreach ($accueils as $unAccueil) {
				$counts['ariane'] += self::masquerFilAriane($unAccueil);
			}
		}

		// --- 8. La feuille de style du template -----------------------------
		// Tout à la fin, et une seule fois : voir regenererStyleCorpus().
		$counts['style'] = self::regenererStyleCorpus() ? 1 : 0;

		return [
			'task'    => $task,
			'counts'  => $counts,
			'gabarit' => $gabarit,
			'message' => Text::sprintf(
				'MOD_CORPUS_START_INSTALL_DONE',
				$counts['articles'],
				$counts['categories'],
				$counts['fields'],
				$counts['menu'],
				$counts['modules'] ?? 0
			) . ($gabarit === '' ? ' ' . Text::_('MOD_CORPUS_START_NO_CORPUS') : ''),
		];
	}

	/**
	 * Pose le contenu commun, ou retrouve celui qui est déjà là.
	 *
	 * POURQUOI LE CONTENU EST PARTAGÉ, ET PAS RECOPIÉ PAR SCÉNARIO.
	 *
	 * C'est d'abord une démonstration : le blog et le magazine montrent LES
	 * MÊMES articles sous deux ossatures, et le visiteur passe de l'un à
	 * l'autre sur le même texte. Avec deux jeux d'articles distincts, il
	 * faudrait le croire sur parole.
	 *
	 * C'est ensuite une contrainte : Joomla refuse deux catégories de même
	 * alias sous la même parente. Recopier aurait demandé de suffixer chaque
	 * alias, donc des adresses en `recettes-magazine` que personne ne veut lire.
	 *
	 * IL PORTE SA PROPRE MARQUE, `corpus_start:commun`, et n'appartient donc à
	 * aucun scénario. Le retrait d'une démonstration le laisse en place tant
	 * qu'une autre s'en sert ; il ne part qu'avec la dernière.
	 *
	 * @param  array $content
	 *
	 * @return array
	 * @throws Exception
	 */
	protected static function installerCommun(array $content): array
	{
		$vise = self::$scenario;
		self::$scenario = 'commun';

		$deja = self::countMarked('#__categories') > 0;

		$resultat = $deja
			? self::relireCommun($content)
			: self::creerCommun($content);

		self::$scenario = $vise;

		return $resultat;
	}

	/**
	 * Crée le contenu commun. Appelée sous le scénario `commun`.
	 *
	 * @param  array $content
	 *
	 * @return array
	 * @throws Exception
	 */
	protected static function creerCommun(array $content): array
	{
		$catIds = [];
		$n      = ['categories' => 0, 'fields' => 0, 'articles' => 0];

		foreach ($content['categories'] as $key => $cat) {
			$parentId = 1;

			if (!empty($cat['parent'])) {
				if (empty($catIds[$cat['parent']])) {
					throw new Exception('Catégorie parente absente : ' . $cat['parent'], 500);
				}

				$parentId = $catIds[$cat['parent']];
			}

			$catIds[$key] = self::createCategory($cat['title'], $cat['alias'], $parentId);
			$n['categories']++;
		}

		$groupId  = self::createFieldGroup($content['fieldgroup']['title']);
		$fieldIds = [];

		foreach ($content['fields'] as $name => $field) {
			$fieldIds[$name] = self::createField(
				$name,
				$field['title'],
				$field['type'],
				!empty($field['group']) ? $groupId : 0,
				$field['options'] ?? [],
				$field['suffix'] ?? ''
			);
			$n['fields']++;
		}

		$articleIds = [];

		foreach ($content['articles'] as $article) {
			if (empty($catIds[$article['category']])) {
				throw new Exception('Catégorie inconnue : ' . $article['category'], 500);
			}

			// Le titre des étapes vient du fichier de contenu, jamais de la
			// langue de l'administration : voir `commun.php`.
			$article['titreEtapes'] = $content['titreEtapes'] ?? 'Les étapes';

			$articleId = self::createArticle($article, $catIds[$article['category']]);
			$articleIds[$article['alias']] = $articleId;
			$n['articles']++;

			if (!empty($article['fields'])) {
				self::saveFieldValues($articleId, $article['fields'], $fieldIds);
			}
		}

		return [
			'catIds'     => $catIds,
			'fieldIds'   => $fieldIds,
			'articleIds' => $articleIds,
			'groupId'    => $groupId,
		] + $n;
	}

	/**
	 * Retrouve le contenu commun déjà posé, sans rien créer.
	 *
	 * LA CORRESPONDANCE SE FAIT PAR ALIAS, et non par identifiant : les
	 * identifiants dépendent de l'ordre d'insertion, l'alias est écrit dans le
	 * fichier de contenu. Un article ajouté au fichier après coup sera
	 * simplement absent de la table rendue, et le scénario qui s'en sert le
	 * signalera au lieu de pointer un autre article.
	 *
	 * @param  array $content
	 *
	 * @return array
	 */
	protected static function relireCommun(array $content): array
	{
		$db = Factory::getContainer()->get('DatabaseDriver');

		$lire = static function (string $table, string $colonne) use ($db) {
			$query = $db->getQuery(true)
				->select($db->quoteName(['id', $colonne]))
				->from($db->quoteName($table))
				->where(self::conditionMarque($db));

			$trouve = (array) $db->setQuery($query)->loadAssocList($colonne, 'id');

			return array_map('intval', $trouve);
		};

		$parAlias   = $lire('#__categories', 'alias');
		$artParAlias = $lire('#__content', 'alias');
		$champs      = $lire('#__fields', 'name');
		$groupes     = $lire('#__fields_groups', 'title');

		$catIds = [];

		foreach ($content['categories'] as $key => $cat) {
			if (isset($parAlias[$cat['alias']])) {
				$catIds[$key] = $parAlias[$cat['alias']];
			}
		}

		$articleIds = [];

		foreach ($content['articles'] as $article) {
			if (isset($artParAlias[$article['alias']])) {
				$articleIds[$article['alias']] = $artParAlias[$article['alias']];
			}
		}

		$fieldIds = [];

		foreach ($content['fields'] as $name => $field) {
			if (isset($champs[$name])) {
				$fieldIds[$name] = $champs[$name];
			}
		}

		return [
			'catIds'     => $catIds,
			'fieldIds'   => $fieldIds,
			'articleIds' => $articleIds,
			'groupId'    => (int) (reset($groupes) ?: 0),

			// Rien n'a été créé : les compteurs restent à zéro, et le message
			// d'installation dit donc la vérité, « 0 article » plutôt que de
			// recompter ce qui était déjà là.
			'categories' => 0,
			'fields'     => 0,
			'articles'   => 0,
		];
	}

	// =====================================================================
	// LE GABARIT D'ARTICLE
	// =====================================================================

	/**
	 * Nom du gabarit écrit par ce module. Sert aussi de témoin : c'est ce
	 * nom, et lui seul, que la réinitialisation retire des réglages.
	 */
	public const GABARIT_NOM = 'Recette';

	/**
	 * Écrit un gabarit « Recette » dans les réglages du style Corpus.
	 *
	 * Le gabarit référence les champs par leur IDENTIFIANT, c'est ce
	 * qu'attendent les briques `champ` et `groupe-champs` de Corpus. Il ne
	 * peut donc pas être écrit avant que les champs n'existent.
	 *
	 * Rend '' si Corpus n'est pas le template du site : le module reste
	 * utilisable, il installe simplement le contenu sans gabarit.
	 *
	 * @param  array $fieldIds
	 * @param  int   $groupId
	 *
	 * @return string La clé du gabarit, ou '' si rien n'a été écrit
	 */
	protected static function createGabarit(array $fieldIds, int $groupId): string
	{
		/*
		 * DANS LE STYLE DU SCÉNARIO, ET NON DANS CELUI DU SITE. Les articles
		 * s'affichent par les entrées de menu du scénario, qui portent son
		 * style : un gabarit écrit ailleurs ne serait jamais lu. Quand aucun
		 * style dédié n'existe, la cible EST le style du site, et rien ne
		 * change par rapport à avant.
		 */
		$style = self::getStyleCible();

		if (!$style) {
			return '';
		}

		$briques = [];
		$n       = 0;

		$poser = static function (string $brique, int $rangee, string $colonne, string $option = '') use (&$briques, &$n) {
			$briques['briques' . $n] = [
				'brique'      => $brique,
				'rangee'      => (string) $rangee,
				'colonne'     => $colonne,
				'option'      => $option,
				'classe'      => '',
				'identifiant' => '',
			];
			$n++;
		};

		// Rangée 1 : le titre, avec les icônes d'impression et d'envoi.
		$poser('titre', 1, 'p');
		$poser('icones', 1, 'p');

		// Rangée 2 : la fiche d'état civil et les étiquettes.
		$poser('plugins-apres-titre', 2, 'p');
		$poser('info', 2, 'p');
		$poser('etiquettes', 2, 'p');

		// Rangée 3 : l'image à gauche, « En bref » à droite sur un aplat teinté.
		$poser('image-pleine', 3, 'g');
		$poser('groupe-champs', 3, 'd', $groupId . ':titre');

		// Rangée 4 : l'accroche, pleine largeur.
		$poser('introduction', 4, 'p');

		// Rangée 5 : les ingrédients sur un aplat à gauche, les étapes à droite.
		// Le corps est réglé sur « sans-intro » : l'accroche est déjà posée en
		// rangée 4, il ne doit pas la répéter.
		if (!empty($fieldIds['liste-ingredients'])) {
			$poser('champ', 5, 'g', (string) $fieldIds['liste-ingredients']);
		}

		$poser('corps', 5, 'd', 'sans-intro');

		// Rangée 6 : les liens de l'article, puis le conseil du chef.
		$poser('liens', 6, 'p');

		if (!empty($fieldIds['conseil-du-chef'])) {
			$poser('champ', 6, 'p', (string) $fieldIds['conseil-du-chef']);
		}

		// Rangée 7 : la fin d'article. « Article précédent / suivant » sort du
		// plugin Pagenavigation, qui écoute onContentBeforeDisplay : c'est donc
		// la brique « plugins avant contenu » qui le porte, et c'est en la
		// posant ICI qu'on obtient la navigation en bas de page.
		$poser('plugins-avant-contenu', 7, 'p');
		$poser('plugins-apres-contenu', 7, 'p');
		$poser('outils', 7, 'p');
		$poser('pagination', 7, 'p');

		$gabarit = [
			'nom'     => self::GABARIT_NOM,
			'rangees' => [
				'rangees0' => ['colonnes' => '1', 'rapport' => '', 'fond' => '', 'fondSur' => ''],
				'rangees1' => ['colonnes' => '1', 'rapport' => '', 'fond' => '', 'fondSur' => ''],
				'rangees2' => ['colonnes' => '2', 'rapport' => '8-4', 'fond' => self::fondTeinte(), 'fondSur' => 'd'],
				'rangees3' => ['colonnes' => '1', 'rapport' => '', 'fond' => '', 'fondSur' => ''],
				'rangees4' => ['colonnes' => '2', 'rapport' => '3-9', 'fond' => 'section--alt', 'fondSur' => 'g'],
				'rangees5' => ['colonnes' => '1', 'rapport' => '', 'fond' => '', 'fondSur' => ''],
				'rangees6' => ['colonnes' => '1', 'rapport' => '', 'fond' => '', 'fondSur' => ''],
			],
			'briques' => $briques,
		];

		$params = self::decodeParams($style->params);
		$liste  = self::gabaritList($params);

		// Un gabarit du même nom déjà présent est remplacé, jamais doublé.
		foreach ($liste as $k => $existant) {
			if (isset($existant['nom']) && $existant['nom'] === self::GABARIT_NOM) {
				unset($liste[$k]);
			}
		}

		$liste[] = $gabarit;

		$params['gabaritsArticle'] = array_values($liste);

		self::saveStyleParams((int) $style->id, $params);

		// La clé est calculée par Corpus à partir du nom, à l'identique.
		return self::gabaritCle(self::GABARIT_NOM);
	}

	/**
	 * Position de gabarit qui reçoit le module « Recettes de saison ».
	 */
	public const MODULE_POSITION = 'article-2';

	/**
	 * La valeur du fond teinté, telle que la comprend le Corpus INSTALLÉ.
	 *
	 * Elle a changé de nom au renommage des classes en anglais : les versions
	 * antérieures attendent « section--teinte », les suivantes « section--tint ».
	 * Écrire la mauvaise ne produit aucun aplat, et sans message. On lit donc
	 * les options réellement déclarées par le template en place plutôt que d'en
	 * supposer une.
	 *
	 * @return string
	 */
	protected static function fondTeinte(): string
	{
		$manifeste = JPATH_SITE . '/templates/corpus/templateDetails.xml';

		if (is_file($manifeste)) {
			$xml = @file_get_contents($manifeste);

			if ($xml !== false && strpos($xml, 'section--tint') !== false) {
				return 'section--tint';
			}

			if ($xml !== false && strpos($xml, 'section--teinte') !== false) {
				return 'section--teinte';
			}
		}

		return 'section--tint';
	}

	/**
	 * Retire du style le gabarit écrit par ce module, et lui seul.
	 *
	 * @return int
	 */
	protected static function removeGabarit(): int
	{
		$style = self::getCorpusStyle();

		if (!$style) {
			return 0;
		}

		$params = self::decodeParams($style->params);
		$liste  = self::gabaritList($params);
		$avant  = count($liste);

		foreach ($liste as $k => $gabarit) {
			if (isset($gabarit['nom']) && $gabarit['nom'] === self::GABARIT_NOM) {
				unset($liste[$k]);
			}
		}

		if (count($liste) === $avant) {
			return 0;
		}

		$params['gabaritsArticle'] = array_values($liste);

		self::saveStyleParams((int) $style->id, $params);

		return $avant - count($liste);
	}

	/**
	 * La clé d'un gabarit, calculée exactement comme CorpusGabarits::cle().
	 *
	 * @param  string $nom
	 *
	 * @return string
	 */
	protected static function gabaritCle(string $nom): string
	{
		$cle = strtolower(trim($nom));
		$cle = preg_replace('/[^a-z0-9]+/', '-', $cle);
		$cle = trim((string) $cle, '-');

		return $cle !== '' ? $cle : 'gabarit-1';
	}

	/**
	 * Le style de site du template Corpus, ou null.
	 *
	 * Même règle de repli que CorpusGabarits::listeDepuisBase() : le style
	 * par défaut d'abord (home décroissant).
	 *
	 * @return object|null
	 */
	protected static function getCorpusStyle()
	{
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName(['id', 'params']))
			->from($db->quoteName('#__template_styles'))
			->where($db->quoteName('client_id') . ' = 0')
			->where($db->quoteName('template') . ' = ' . $db->quote('corpus'))
			->order($db->quoteName('home') . ' DESC');

		$db->setQuery($query, 0, 1);

		return $db->loadObject();
	}

	/**
	 * Le style sur lequel écrire les réglages de mise en page du scénario.
	 *
	 * C'est le style dédié quand le scénario en demande un, et le style par
	 * défaut du site sinon. Le gabarit d'article, lui, va TOUJOURS dans le
	 * style par défaut : ce sont les pages d'article qui l'utilisent, et elles
	 * ne prennent pas le style dédié.
	 *
	 * @return object|null
	 */
	protected static function getStyleCible()
	{
		if (!self::$styleScenarioId) {
			return self::getCorpusStyle();
		}

		// Une variable locale, et non la propriété : `bind` garde une RÉFÉRENCE
		// sur ce qu'on lui passe, et la lit au moment d'exécuter la requête.
		$id = (int) self::$styleScenarioId;

		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName(['id', 'params']))
			->from($db->quoteName('#__template_styles'))
			->where($db->quoteName('id') . ' = :id')
			->bind(':id', $id, ParameterType::INTEGER);

		return $db->setQuery($query)->loadObject();
	}

	/**
	 * Crée un second style de template, copie du style par défaut de Corpus.
	 *
	 * CE QUE CE DÉTOUR RÉPARE, ET POURQUOI IL N'ÉTAIT PAS ÉVITABLE.
	 *
	 * Un préréglage de mise en page s'écrit dans un STYLE de template, et un
	 * style s'applique à toutes les pages auxquelles il est assigné. Le
	 * préréglage `landing` porte `layoutEnable_content: 0`, qui éteint le corps
	 * de page. Écrit dans le style par défaut, il éteignait donc le corps de
	 * page DU SITE ENTIER : chaque article s'ouvrait sur une page sans <main>,
	 * où seules les bandes de la page d'atterrissage se répétaient. Le lien
	 * était bon, la route était bonne, la page était vide. Relevé par Cyrille
	 * sur le banc, et son diagnostic était le bon.
	 *
	 * Un site Joomla peut porter plusieurs styles du même template, et chaque
	 * élément de menu choisit le sien. C'est le mécanisme prévu pour exactement
	 * ce cas. Le style dédié est une copie du style par défaut, donc il en
	 * hérite les couleurs, la typographie et le logo ; seule sa mise en page
	 * diffère. Il n'est assigné qu'à l'entrée d'accueil.
	 *
	 * Conséquence utile : le style par défaut n'est plus touché du tout par ce
	 * scénario, donc il n'y a plus rien à lui rendre à la réinitialisation.
	 *
	 * @param  string $titre
	 *
	 * @return int L'identifiant du style créé, 0 si Corpus n'est pas là
	 */
	protected static function createStyleScenario(string $titre): int
	{
		$db     = Factory::getContainer()->get('DatabaseDriver');
		$query  = $db->getQuery(true)
			->select($db->quoteName(['template', 'client_id', 'inheritable', 'parent', 'params']))
			->from($db->quoteName('#__template_styles'))
			->where($db->quoteName('client_id') . ' = 0')
			->where($db->quoteName('template') . ' = ' . $db->quote('corpus'))
			->order($db->quoteName('home') . ' DESC');

		$db->setQuery($query, 0, 1);
		$modele = $db->loadObject();

		if (!$modele) {
			return 0;
		}

		$colonnes = $db->quoteName(['template', 'client_id', 'home', 'title', 'inheritable', 'parent', 'params']);

		$query = $db->getQuery(true)
			->insert($db->quoteName('#__template_styles'))
			->columns($colonnes)
			->values(implode(',', [
				$db->quote($modele->template),
				'0',
				$db->quote('0'),
				$db->quote($titre),
				(int) $modele->inheritable,
				$db->quote((string) $modele->parent),
				$db->quote((string) $modele->params),
			]));

		$db->setQuery($query)->execute();

		$id = (int) $db->insertid();

		self::setExtensionParam('styleScenario', $id);

		return $id;
	}

	/**
	 * Assigne un style de template à un élément de menu.
	 *
	 * @param  int $itemId
	 * @param  int $styleId
	 *
	 * @return void
	 */
	protected static function assignStyleToMenuItems(array $itemIds, int $styleId): int
	{
		$itemIds = array_values(array_filter(array_map('intval', $itemIds)));

		if (!$itemIds || !$styleId) {
			return 0;
		}

		/*
		 * TOUTES LES ENTRÉES DU SCÉNARIO, ET PAS SEULEMENT SON ACCUEIL.
		 *
		 * Tant qu'un seul scénario tenait sur un site, assigner le style à la
		 * page d'accueil suffisait : le reste du site prenait le style du site,
		 * ce qui était le bon comportement. Avec plusieurs démonstrations
		 * côte à côte, chacune doit emporter son ossature sur TOUTES ses pages,
		 * sinon la page d'un article du blog s'affiche sous le style de la
		 * dernière démonstration installée.
		 */
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->update($db->quoteName('#__menu'))
			->set($db->quoteName('template_style_id') . ' = :style')
			->whereIn($db->quoteName('id'), $itemIds)
			->bind(':style', $styleId, ParameterType::INTEGER);

		$db->setQuery($query)->execute();

		return count($itemIds);
	}

	/**
	 * Supprime le style dédié, et libère les éléments de menu qui le visaient.
	 *
	 * L'ordre est important : un élément de menu qui pointe un style disparu
	 * fait retomber Joomla sur le style par défaut sans rien dire, mais la
	 * valeur reste en base et resurgirait si un nouveau style reprenait le
	 * même identifiant.
	 *
	 * @return int
	 */
	protected static function removeStyleScenario(): int
	{
		$id = (int) self::getExtensionParam('styleScenario');

		if (!$id) {
			return 0;
		}

		$db = Factory::getContainer()->get('DatabaseDriver');

		$query = $db->getQuery(true)
			->update($db->quoteName('#__menu'))
			->set($db->quoteName('template_style_id') . ' = 0')
			->where($db->quoteName('template_style_id') . ' = :style')
			->bind(':style', $id, ParameterType::INTEGER);

		$db->setQuery($query)->execute();

		$query = $db->getQuery(true)
			->delete($db->quoteName('#__template_styles'))
			->where($db->quoteName('id') . ' = :id')
			->where($db->quoteName('home') . ' = ' . $db->quote('0'))
			->bind(':id', $id, ParameterType::INTEGER);

		$db->setQuery($query)->execute();

		/*
		 * LES FICHIERS QUE LE STYLE LAISSE DERRIÈRE LUI. Corpus écrit une
		 * feuille compilée par style, et une révision à chaque enregistrement,
		 * toutes deux nommées d'après l'identifiant. Un identifiant est
		 * réattribué par MySQL : sans ce ménage, un style créé plus tard
		 * hériterait de la feuille du nôtre.
		 */
		$media = JPATH_SITE . '/media/templates/site/corpus';

		@unlink($media . '/css/custom-styles/' . $id . '.css');

		foreach (['styles', 'layouts'] as $groupe) {
			foreach ((array) @glob($media . '/revisions/' . $groupe . '/' . $id . '-*.nvp') as $fichier) {
				@unlink($fichier);
			}
		}

		self::setExtensionParam('styleScenario', null);

		return 1;
	}

	/**
	 * Les réglages d'un style, en tableau.
	 *
	 * @param  string $raw
	 *
	 * @return array
	 */
	protected static function decodeParams($raw): array
	{
		$params = json_decode((string) $raw, true);

		return is_array($params) ? $params : [];
	}

	/**
	 * La liste des gabarits déjà déclarés, en tableau indexé.
	 *
	 * Le sous-formulaire peut être enregistré en objet ou en chaîne JSON
	 * selon le chemin d'écriture : les deux sont acceptés.
	 *
	 * @param  array $params
	 *
	 * @return array
	 */
	protected static function gabaritList(array $params): array
	{
		$brut = $params['gabaritsArticle'] ?? [];

		if (is_string($brut)) {
			$brut = $brut !== '' ? json_decode($brut, true) : [];
		}

		return is_array($brut) ? array_values($brut) : [];
	}

	/**
	 * Réécrit les réglages d'un style.
	 *
	 * @param  int   $styleId
	 * @param  array $params
	 *
	 * @return void
	 */
	protected static function saveStyleParams(int $styleId, array $params): void
	{
		$db   = Factory::getContainer()->get('DatabaseDriver');
		$json = json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

		$query = $db->getQuery(true)
			->update($db->quoteName('#__template_styles'))
			->set($db->quoteName('params') . ' = :params')
			->where($db->quoteName('id') . ' = :id')
			->bind(':params', $json)
			->bind(':id', $styleId, ParameterType::INTEGER);

		$db->setQuery($query)->execute();
	}

	/**
	 * Affecte un gabarit à une catégorie, par ses paramètres.
	 *
	 * On écrit dans la table plutôt que par le modèle : le champ
	 * `corpusGabarit` est greffé dans le formulaire par le plugin de Corpus,
	 * et un enregistrement sans requête ne le porterait pas.
	 *
	 * @param  int    $catId
	 * @param  string $cle
	 *
	 * @return void
	 */
	protected static function assignGabarit(int $catId, string $cle): void
	{
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName('params'))
			->from($db->quoteName('#__categories'))
			->where($db->quoteName('id') . ' = :id')
			->bind(':id', $catId, ParameterType::INTEGER);

		$db->setQuery($query);

		$params = self::decodeParams($db->loadResult());

		$params['corpusGabarit'] = $cle;

		$json  = json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
		$query = $db->getQuery(true)
			->update($db->quoteName('#__categories'))
			->set($db->quoteName('params') . ' = :params')
			->where($db->quoteName('id') . ' = :id')
			->bind(':params', $json)
			->bind(':id', $catId, ParameterType::INTEGER);

		$db->setQuery($query)->execute();
	}

	/**
	 * Coupe l'affichage automatique des champs placés par le gabarit.
	 *
	 * Sans cela Joomla les sort une seconde fois, en bas de l'article :
	 * c'est l'avertissement porté par la brique `champ` de Corpus.
	 *
	 * @param  int[] $ids
	 *
	 * @return void
	 */
	protected static function hideFieldsFromAutoDisplay(array $ids): void
	{
		$db = Factory::getContainer()->get('DatabaseDriver');

		foreach ($ids as $id) {
			$id = (int) $id;

			$query = $db->getQuery(true)
				->select($db->quoteName('params'))
				->from($db->quoteName('#__fields'))
				->where($db->quoteName('id') . ' = :id')
				->bind(':id', $id, ParameterType::INTEGER);

			$db->setQuery($query);

			$params = self::decodeParams($db->loadResult());

			$params['display'] = '0';

			$json  = json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
			$query = $db->getQuery(true)
				->update($db->quoteName('#__fields'))
				->set($db->quoteName('params') . ' = :params')
				->where($db->quoteName('id') . ' = :id')
				->bind(':params', $json)
				->bind(':id', $id, ParameterType::INTEGER);

			$db->setQuery($query)->execute();
		}
	}

	/**
	 * Crée le module « Recettes de saison », en position article-2.
	 *
	 * Sans lui, la troisième colonne de la rangée des étapes reste vide et la
	 * mise en page paraît cassée. Il porte la note du module : la
	 * réinitialisation le supprimera comme le reste.
	 *
	 * @param  int $catId Catégorie des recettes
	 *
	 * @return int
	 * @throws Exception
	 */
	protected static function createArticlesModule(int $catId): int
	{
		$model = self::getModel('com_modules', 'Module');

		$data = [
			'id'        => 0,
			'title'     => Text::_('MOD_CORPUS_START_MODULE_TITLE'),
			'module'    => 'mod_articles',
			'position'  => self::MODULE_POSITION,
			'published' => 1,
			'access'    => 1,
			'showtitle' => 1,
			'language'  => '*',
			'note'      => self::marker(),
			'client_id' => 0,
			'assignment' => 0,
			'params'    => [
				'mode'                        => 'normal',
				'count'                       => '5',
				'category_filtering_type'     => '1',
				'catid'                       => [$catId],
				'show_child_category_articles' => '1',
				'levels'                      => '2',
				'show_front'                  => 'show',
				'show_introtext'              => '0',
				'item_heading'                => '4',
				'article_grouping'            => 'none',
				'ordering'                    => 'a.publish_up',
				'direction'                   => '1',
			],
		];

		if (!$model->save($data)) {
			throw new Exception('Module « Recettes de saison » : ' . $model->getError(), 500);
		}

		$id = (int) $model->getState('module.id');

		// Un module neuf n'est affecté à aucune page : sans cette ligne dans
		// #__modules_menu, il ne sort nulle part. 0 = toutes les pages.
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select('COUNT(*)')
			->from($db->quoteName('#__modules_menu'))
			->where($db->quoteName('moduleid') . ' = :id')
			->bind(':id', $id, ParameterType::INTEGER);

		$db->setQuery($query);

		if (!(int) $db->loadResult()) {
			$query = $db->getQuery(true)
				->insert($db->quoteName('#__modules_menu'))
				->columns($db->quoteName(['moduleid', 'menuid']))
				->values(':id, 0')
				->bind(':id', $id, ParameterType::INTEGER);

			$db->setQuery($query)->execute();
		}

		return $id;
	}

	// =====================================================================
	// LE MODULE DE MENU
	// =====================================================================

	/**
	 * Position de navigation de Corpus, déclarée dans templateDetails.xml.
	 */
	public const MENU_POSITION = 'menu';

	/**
	 * Pose le module de menu du site en position « menu », et le publie.
	 *
	 * CE MODULE N'EST PAS LE NÔTRE : on ne le marque donc pas, et on ne le
	 * supprimera jamais. On note son état d'avant dans les réglages de
	 * l'extension, et la réinitialisation le remet exactement comme il était.
	 *
	 * @param  string $menutype
	 *
	 * @return bool
	 */
	protected static function forceMenuPosition(string $menutype): bool
	{
		$db = Factory::getContainer()->get('DatabaseDriver');

		$query = $db->getQuery(true)
			->select($db->quoteName(['id', 'position', 'published', 'params']))
			->from($db->quoteName('#__modules'))
			->where($db->quoteName('client_id') . ' = 0')
			->where($db->quoteName('module') . ' = ' . $db->quote('mod_menu'))
			->order($db->quoteName('id') . ' ASC');

		$db->setQuery($query);

		$modules = (array) $db->loadObjectList();

		if (!$modules) {
			return false;
		}

		// Celui qui affiche le menu qu'on vient de garnir, sinon le premier.
		$cible = $modules[0];

		foreach ($modules as $module) {
			$params = self::decodeParams($module->params);

			if (($params['menutype'] ?? '') === $menutype) {
				$cible = $module;

				break;
			}
		}

		if ($cible->position === self::MENU_POSITION && (int) $cible->published === 1) {
			return true;
		}

		self::setExtensionParam('menuBackup', [
			'id'        => (int) $cible->id,
			'position'  => (string) $cible->position,
			'published' => (int) $cible->published,
		]);

		$id       = (int) $cible->id;
		$position = self::MENU_POSITION;

		$query = $db->getQuery(true)
			->update($db->quoteName('#__modules'))
			->set($db->quoteName('position') . ' = :position')
			->set($db->quoteName('published') . ' = 1')
			->where($db->quoteName('id') . ' = :id')
			->bind(':position', $position)
			->bind(':id', $id, ParameterType::INTEGER);

		$db->setQuery($query)->execute();

		return true;
	}

	/**
	 * Remet le module de menu là où il était avant l'installation.
	 *
	 * @return int
	 */
	protected static function restoreMenuPosition(): int
	{
		$backup = self::getExtensionParam('menuBackup');

		if (!is_array($backup) || empty($backup['id'])) {
			return 0;
		}

		$db        = Factory::getContainer()->get('DatabaseDriver');
		$id        = (int) $backup['id'];
		$position  = (string) $backup['position'];
		$published = (int) $backup['published'];

		$query = $db->getQuery(true)
			->update($db->quoteName('#__modules'))
			->set($db->quoteName('position') . ' = :position')
			->set($db->quoteName('published') . ' = :published')
			->where($db->quoteName('id') . ' = :id')
			->bind(':position', $position)
			->bind(':published', $published, ParameterType::INTEGER)
			->bind(':id', $id, ParameterType::INTEGER);

		$db->setQuery($query)->execute();

		self::setExtensionParam('menuBackup', null);

		return 1;
	}

	/**
	 * Lit un réglage de l'extension mod_corpus_start.
	 *
	 * Les réglages de l'EXTENSION, pas ceux d'une instance de module : il peut
	 * y avoir plusieurs instances, il n'y a qu'une extension.
	 *
	 * @param  string $cle
	 *
	 * @return mixed
	 */
	/**
	 * La clé sous laquelle un scénario range ce qu'il doit rendre.
	 *
	 * POURQUOI ELLE EST SUFFIXÉE. Le module note ce qu'il déplace pour le
	 * remettre en place : la page d'accueil d'avant, la position du module de
	 * menu, les réglages de style. Avec deux scénarios installés côte à côte et
	 * une seule clé, le retrait de l'un rendrait ce que l'autre avait noté, et
	 * le site se retrouverait dans un état qui n'a jamais existé.
	 *
	 * Sans scénario, la clé reste nue : c'est celle des versions du module
	 * antérieures au retrait sélectif, et le retrait global la relit telle
	 * quelle.
	 *
	 * @param  string $cle
	 *
	 * @return string
	 */
	protected static function cleSauvegarde(string $cle): string
	{
		return self::$scenario !== '' ? $cle . ':' . self::$scenario : $cle;
	}

	protected static function getExtensionParam(string $cle)
	{
		$cle = self::cleSauvegarde($cle);

		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName('params'))
			->from($db->quoteName('#__extensions'))
			->where($db->quoteName('element') . ' = ' . $db->quote('mod_corpus_start'))
			->where($db->quoteName('type') . ' = ' . $db->quote('module'));

		$db->setQuery($query);

		$params = self::decodeParams($db->loadResult());

		return $params[$cle] ?? null;
	}

	/**
	 * Écrit un réglage de l'extension. Une valeur null l'efface.
	 *
	 * @param  string $cle
	 * @param  mixed  $valeur
	 *
	 * @return void
	 */
	protected static function setExtensionParam(string $cle, $valeur): void
	{
		$cle = self::cleSauvegarde($cle);

		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName(['extension_id', 'params']))
			->from($db->quoteName('#__extensions'))
			->where($db->quoteName('element') . ' = ' . $db->quote('mod_corpus_start'))
			->where($db->quoteName('type') . ' = ' . $db->quote('module'));

		$db->setQuery($query);

		$ligne = $db->loadObject();

		if (!$ligne) {
			return;
		}

		$params = self::decodeParams($ligne->params);

		if ($valeur === null) {
			unset($params[$cle]);
		} else {
			$params[$cle] = $valeur;
		}

		$json = json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
		$id   = (int) $ligne->extension_id;

		$query = $db->getQuery(true)
			->update($db->quoteName('#__extensions'))
			->set($db->quoteName('params') . ' = :params')
			->where($db->quoteName('extension_id') . ' = :id')
			->bind(':params', $json)
			->bind(':id', $id, ParameterType::INTEGER);

		$db->setQuery($query)->execute();
	}

	// =====================================================================
	// LES PRÉRÉGLAGES DE MISE EN PAGE
	// =====================================================================

	/**
	 * Applique un préréglage de disposition de Corpus au style du site.
	 *
	 * LE PRÉRÉGLAGE EST LU DANS LE TEMPLATE INSTALLÉ, jamais recopié ici : ses
	 * quatre-vingt-seize clés changent d'une version de Corpus à l'autre, et
	 * une copie figée se périmerait sans prévenir. Le fichier vit dans
	 * templates/corpus/etc/presets/layouts/<nom>.nvp.
	 *
	 * Les valeurs d'avant sont notées dans les réglages de l'extension, clé
	 * par clé, y compris celles qui n'existaient pas : la réinitialisation
	 * doit pouvoir les retirer aussi bien que les rendre.
	 *
	 * @param  string $nom
	 *
	 * @return int Le nombre de clés écrites, 0 si le préréglage est absent
	 */
	protected static function applyPreset(string $nom): int
	{
		$fichier = JPATH_SITE . '/templates/corpus/etc/presets/layouts/' . $nom . '.nvp';

		if (!is_file($fichier)) {
			return 0;
		}

		$valeurs = self::lirePreset($fichier);

		if (!$valeurs) {
			return 0;
		}

		if (!self::getStyleCible()) {
			return 0;
		}

		return self::applyStyleParams($valeurs);
	}

	/**
	 * Écrit des réglages dans le style du site, en notant ceux d'avant.
	 *
	 * La sauvegarde ne se laisse PAS écraser : si une clé y figure déjà, on
	 * garde la valeur la plus ancienne. Sans cela, un préréglage appliqué puis
	 * quelques réglages posés par-dessus feraient perdre l'état d'origine, et
	 * la réinitialisation rendrait un état intermédiaire qui n'a jamais existé.
	 *
	 * @param  array<string, mixed> $valeurs
	 *
	 * @return int
	 */
	protected static function applyStyleParams(array $valeurs): int
	{
		if (!$valeurs) {
			return 0;
		}

		$style = self::getStyleCible();

		if (!$style) {
			return 0;
		}

		$params = self::decodeParams($style->params);

		/*
		 * LA SAUVEGARDE N'A DE SENS QUE SUR LE STYLE DU SITE. Quand le scénario
		 * écrit dans un style dédié, ce style est neuf et la réinitialisation le
		 * supprime en entier : noter ce qu'il contenait avant reviendrait à
		 * noter ce qu'on vient d'y mettre, et le rendre à la fin réécrirait des
		 * réglages dans un style qui n'existe plus.
		 */
		if (!self::$styleScenarioId) {
			$sauvegarde = self::getExtensionParam('presetBackup');
			$sauvegarde = is_array($sauvegarde) ? $sauvegarde : [];

			foreach ($valeurs as $cle => $valeur) {
				if (!array_key_exists($cle, $sauvegarde)) {
					// null note une clé qui n'existait pas : il faudra la retirer.
					$sauvegarde[$cle] = array_key_exists($cle, $params) ? $params[$cle] : null;
				}
			}

			self::setExtensionParam('presetBackup', $sauvegarde);
		}

		foreach ($valeurs as $cle => $valeur) {
			$params[$cle] = $valeur;
		}

		self::saveStyleParams((int) $style->id, $params);

		return count($valeurs);
	}

	/**
	 * Demande à Corpus de recompiler sa feuille de style, et note une révision.
	 *
	 * POURQUOI CE DÉTOUR, ET CE QU'IL RÉPARE VRAIMENT.
	 *
	 * Les réglages de disposition (`layoutPos_*`, `layoutEnable_*`,
	 * `layoutName_*`) sont lus à chaque page par le gabarit du template : les
	 * écrire en base suffit, et ils prennent effet aussitôt.
	 *
	 * D'AUTRES RÉGLAGES NE SONT PAS LUS : ils sont COMPILÉS. `layoutMaxWidth`,
	 * les teintes, la gouttière et une vingtaine d'autres deviennent du CSS,
	 * écrit une fois pour toutes dans
	 * `media/templates/site/corpus/css/custom-styles/<id>.css`. Tant que ce
	 * fichier existe, le template le charge tel quel : la valeur en base a beau
	 * être la bonne, la page garde l'ancienne. Rien ne le signale.
	 *
	 * C'est `afterSave()` du template qui refait ce fichier. Il fait aussi deux
	 * choses qui comptent pour l'utilisateur : il dépose une RÉVISION `.nvp`,
	 * qui rend le retour arrière possible depuis la liste « Préréglage » de
	 * l'écran de style, et il remet à zéro le témoin de recompilation.
	 *
	 * UN SEUL APPEL PAR REQUÊTE, et c'est une contrainte du template :
	 * `buildCustomStyle()` garde son résultat dans une variable statique. Un
	 * second appel dans la même requête rendrait la feuille du premier, donc une
	 * feuille périmée. D'où la place de cet appel, tout à la fin.
	 *
	 * Ne lève jamais : un site sans Corpus, ou un dossier média en lecture
	 * seule, ne doit pas faire échouer une installation par ailleurs réussie.
	 *
	 * @return bool
	 */
	protected static function regenererStyleCorpus(): bool
	{
		$fichier = JPATH_SITE . '/templates/corpus/helper.php';

		if (!is_file($fichier)) {
			return false;
		}

		$style = self::getStyleCible();

		if (!$style) {
			return false;
		}

		try {
			/*
			 * LE TÉMOIN, POSÉ AVANT. `saveRevision()` ne fait rien si
			 * `tplhelper` ne déclare pas le groupe modifié, et ce témoin n'est
			 * posé que par le formulaire de l'admin. Sans lui, la feuille serait
			 * bien refaite mais aucune révision ne serait déposée, et la liste
			 * « Préréglage » resterait muette sur ce que le module a appliqué.
			 *
			 * Il est stocké en CHAÎNE JSON, pas en tableau : c'est ce
			 * qu'attend `groupNeedUpdate()`. `afterSave()` le remet à vide.
			 */
			$params              = self::decodeParams($style->params);
			$params['tplhelper'] = json_encode(['styles' => 1, 'layouts' => 1]);
			self::saveStyleParams((int) $style->id, $params);

			$helper = require $fichier;

			if (!is_object($helper) || !method_exists($helper, 'afterSave')) {
				return false;
			}

			$helper->loadStyle((int) $style->id);
			$helper->afterSave();

			return true;
		} catch (\Throwable $e) {
			return false;
		}
	}

	/**
	 * Rend au style ses réglages de disposition d'avant.
	 *
	 * @return int
	 */
	protected static function restorePreset(): int
	{
		$sauvegarde = self::getExtensionParam('presetBackup');

		if (!is_array($sauvegarde) || !$sauvegarde) {
			return 0;
		}

		$style = self::getCorpusStyle();

		if (!$style) {
			return 0;
		}

		$params = self::decodeParams($style->params);

		foreach ($sauvegarde as $cle => $valeur) {
			if ($valeur === null) {
				unset($params[$cle]);
			} else {
				$params[$cle] = $valeur;
			}
		}

		self::saveStyleParams((int) $style->id, $params);
		self::setExtensionParam('presetBackup', null);

		return count($sauvegarde);
	}

	/**
	 * Lit un fichier .nvp : des paires « clé: valeur », une par ligne.
	 *
	 * Les lignes qui commencent par # sont des commentaires, et la première
	 * ligne utile est l'intitulé du préréglage, sans deux-points. Une valeur
	 * peut être vide, ce qui a un sens : elle remet la clé au défaut.
	 *
	 * @param  string $fichier
	 *
	 * @return array<string, string>
	 */
	protected static function lirePreset(string $fichier): array
	{
		$lignes  = (array) @file($fichier, FILE_IGNORE_NEW_LINES);
		$valeurs = [];

		foreach ($lignes as $ligne) {
			$ligne = trim((string) $ligne);

			if ($ligne === '' || $ligne[0] === '#' || strpos($ligne, ':') === false) {
				continue;
			}

			[$cle, $valeur] = explode(':', $ligne, 2);

			$cle = trim($cle);

			if ($cle === '') {
				continue;
			}

			$valeurs[$cle] = trim($valeur);
		}

		return $valeurs;
	}

	// =====================================================================
	// LES IMAGES
	// =====================================================================

	/**
	 * Dossier d'arrivée des images, sous la racine du site.
	 */
	public const IMAGES_DIR = 'images/corpus-start';

	/**
	 * Copie les images livrées dans le module vers images/corpus-start.
	 *
	 * ELLE ÉCHOUAIT EN SILENCE, ET C'EST LE DÉFAUT LE PLUS COÛTEUX DE CE
	 * FICHIER. Relevé par Cyrille le 26 août 2026 sur blog.joomanji.eu : aucune
	 * image sur le site, et pourtant un message d'installation réussie.
	 *
	 * La version d'avant employait `@mkdir` et `@copy`. L'arrobase avale
	 * l'avertissement, la valeur de retour n'était pas regardée, et un dossier
	 * `images/` que PHP ne peut pas écrire (le cas ordinaire d'un hébergement
	 * où le serveur web et le compte FTP sont deux utilisateurs différents)
	 * donnait exactement le même message qu'une réussite.
	 *
	 * Trois changements. On passe par la couche de fichiers de Joomla, celle que
	 * le gestionnaire de médias utilise, plutôt que par les fonctions nues de
	 * PHP. On regarde ce qu'elle rend. Et on LÈVE UNE EXCEPTION si rien n'est
	 * arrivé alors qu'il y avait quelque chose à copier : mieux vaut une
	 * installation qui s'arrête en nommant le dossier fautif qu'une
	 * démonstration sans images dont personne ne connaît la cause.
	 *
	 * @return int Le nombre de fichiers copiés
	 * @throws Exception
	 */
	protected static function copyImages(): int
	{
		$source = __DIR__ . '/images';

		if (!is_dir($source)) {
			throw new Exception(Text::sprintf('MOD_CORPUS_START_IMAGES_SOURCE', $source), 500);
		}

		$fichiers = (array) glob($source . '/*.webp');

		if (!$fichiers) {
			return 0;
		}

		$cible = JPATH_SITE . '/' . self::IMAGES_DIR;

		if (!is_dir($cible) && !Folder::create($cible)) {
			throw new Exception(
				Text::sprintf('MOD_CORPUS_START_IMAGES_DOSSIER', self::IMAGES_DIR),
				500
			);
		}

		$copies = 0;
		$ratees = [];

		foreach ($fichiers as $fichier) {
			$nom = basename($fichier);

			if (File::copy($fichier, $cible . '/' . $nom)) {
				$copies++;

				continue;
			}

			$ratees[] = $nom;
		}

		/*
		 * ON NE S'ARRÊTE QUE SI TOUT A RATÉ. Un fichier isolé qui résiste, c'est
		 * une vignette manquante ; zéro fichier sur treize, c'est un dossier
		 * fermé, et l'installation entière n'a plus de sens.
		 */
		if ($copies === 0) {
			throw new Exception(
				Text::sprintf('MOD_CORPUS_START_IMAGES_COPIE', count($ratees), self::IMAGES_DIR),
				500
			);
		}

		return $copies;
	}

	/**
	 * Supprime les images copiées, et le dossier s'il ne reste rien.
	 *
	 * Ne supprime QUE les fichiers livrés par le module : une image que
	 * l'utilisateur aurait déposée dans ce dossier reste en place, et le
	 * dossier avec elle.
	 *
	 * @return int
	 */
	protected static function removeImages(): int
	{
		$source = __DIR__ . '/images';
		$cible  = JPATH_SITE . '/' . self::IMAGES_DIR;

		if (!is_dir($source) || !is_dir($cible)) {
			return 0;
		}

		$supprimes = 0;

		foreach ((array) glob($source . '/*.webp') as $fichier) {
			$chemin = $cible . '/' . basename($fichier);

			if (is_file($chemin) && @unlink($chemin)) {
				$supprimes++;
			}
		}

		$reste = array_diff((array) scandir($cible), ['.', '..']);

		if (!$reste) {
			@rmdir($cible);
		}

		return $supprimes;
	}

	/**
	 * Crée une catégorie de contenu marquée.
	 *
	 * @param  string $title
	 * @param  string $alias
	 * @param  int    $parentId
	 *
	 * @return int
	 * @throws Exception
	 */
	protected static function createCategory(string $title, string $alias, int $parentId, string $langue = '*'): int
	{
		$model = self::getModel('com_categories', 'Category');

		$data = [
			'id'          => 0,
			'title'       => $title,
			'alias'       => $alias,
			'parent_id'   => $parentId,
			'extension'   => 'com_content',
			'published'   => 1,
			'access'      => 1,
			'language'    => $langue,
			'description' => '',
			'note'        => self::marker(),
			'params'      => '{}',
			'metadata'    => '{}',
		];

		if (!$model->save($data)) {
			throw new Exception('Catégorie « ' . $title . " » : " . $model->getError(), 500);
		}

		return (int) $model->getState('category.id');
	}

	/**
	 * Crée le groupe de champs qui porte le bloc « En bref ».
	 *
	 * @param  string $title
	 *
	 * @return int
	 * @throws Exception
	 */
	protected static function createFieldGroup(string $title): int
	{
		$model = self::getModel('com_fields', 'Group');

		$data = [
			'id'          => 0,
			'title'       => $title,
			'context'     => 'com_content.article',
			'state'       => 1,
			'access'      => 1,
			'language'    => '*',
			'description' => '',
			'note'        => self::marker(),
			'params'      => '{}',
		];

		if (!$model->save($data)) {
			throw new Exception('Groupe de champs : ' . $model->getError(), 500);
		}

		return (int) $model->getState('group.id');
	}

	/**
	 * Crée un champ personnalisé marqué.
	 *
	 * @param  string   $name
	 * @param  string   $title
	 * @param  string   $type
	 * @param  int      $groupId
	 * @param  string[] $options
	 *
	 * @return int
	 * @throws Exception
	 */
	protected static function createField(string $name, string $title, string $type, int $groupId, array $options = [], string $suffix = ''): int
	{
		$model = self::getModel('com_fields', 'Field');

		$params = [
			'hint'                => '',
			'class'               => '',
			'label_class'         => '',
			'show_on'             => '',
			'render_class'        => '',
			'showlabel'           => '1',
			'label_render_class'  => '',
			'display'             => '2',
			'prefix'              => '',
			'suffix'              => $suffix,
			'layout'              => '',
			'display_readonly'    => '2',
		];

		$fieldparams = [];

		if ($type === 'list' && $options) {
			$values = [];
			$i      = 0;

			foreach ($options as $option) {
				$values['options' . $i] = [
					'name'  => $option,
					'value' => $option,
				];
				$i++;
			}

			$fieldparams['options'] = $values;
		}

		if ($type === 'textarea') {
			$fieldparams['rows']   = '5';
			$fieldparams['cols']   = '30';
			$fieldparams['filter'] = 'safehtml';
		}

		$data = [
			'id'          => 0,
			'title'       => $title,
			'name'        => $name,
			'label'       => $title,
			'type'        => $type,
			'context'     => 'com_content.article',
			'group_id'    => $groupId,
			'state'       => 1,
			'access'      => 1,
			'language'    => '*',
			'required'    => 0,
			'description' => '',
			'note'        => self::marker(),
			'params'      => $params,
			'fieldparams' => $fieldparams,
		];

		if (!$model->save($data)) {
			throw new Exception('Champ « ' . $title . " » : " . $model->getError(), 500);
		}

		return (int) $model->getState('field.id');
	}

	/**
	 * Crée un article marqué.
	 *
	 * Le corps suit le gabarit recette : introduction, coupure « lire la
	 * suite », puis le bloc des étapes. Un article sans étapes (les articles
	 * du potager) n'a pas de texte complet.
	 *
	 * @param  array $article
	 * @param  int   $catId
	 *
	 * @return int
	 * @throws Exception
	 */
	protected static function createArticle(array $article, int $catId): int
	{
		$model = self::getModel('com_content', 'Article');

		$fulltext = '';

		if (!empty($article['body'])) {
			// Une page rédigée d'un bloc : pas de titre « Les étapes ».
			$fulltext = $article['body'];
		} elseif (!empty($article['steps'])) {
			/*
			 * PAS DE `Text::_()` ICI. Ce titre finit DANS le corps de l'article,
			 * en base : le traduire au moment de l'installation, c'est le figer
			 * dans la langue de l'administration de la personne qui a cliqué.
			 * Le 26 août 2026, une administration en anglais a écrit « Method »
			 * en tête de quatorze recettes françaises.
			 *
			 * L'interface se traduit, le contenu se rédige. `commun.php` porte
			 * le titre, comme il porte les recettes.
			 */
			$titreEtapes = (string) ($article['titreEtapes'] ?? 'Les étapes');

			$fulltext = '<h2>' . $titreEtapes . "</h2>\n<ol class=\"etapes\">\n";

			foreach ($article['steps'] as $step) {
				$fulltext .= "\t<li>" . $step . "</li>\n";
			}

			$fulltext .= '</ol>';
		}

		$data = [
			'id'        => 0,
			'title'     => $article['title'],
			'alias'     => $article['alias'],
			'catid'     => $catId,
			'articletext' => $article['intro'] . ($fulltext !== '' ? '<hr id="system-readmore">' . $fulltext : ''),
			'state'     => 1,
			'access'    => 1,
			'language'  => $article['language'] ?? '*',
			'featured'  => (int) ($article['featured'] ?? 0),
			'note'      => self::marker(),
			'metadesc'  => '',
			'metakey'   => '',
			'images'    => self::imagesJson($article),
			'urls'      => '{}',
			'attribs'   => '{}',
			'metadata'  => '{}',
		];

		if (!empty($article['tags'])) {
			// « #new# » crée le tag au passage s'il n'existe pas encore.
			$data['tags'] = array_map(
				static fn ($tag) => '#new#' . $tag,
				$article['tags']
			);
		}

		if (!$model->save($data)) {
			throw new Exception('Article « ' . $article['title'] . " » : " . $model->getError(), 500);
		}

		return (int) $model->getState('article.id');
	}

	/**
	 * Le champ `images` d'un article, au format de Joomla.
	 *
	 * L'image n'est posée que si le fichier a bien été copié : un chemin
	 * vers une image absente afficherait un cadre cassé sur le site.
	 *
	 * @param  array $article
	 *
	 * @return string
	 */
	protected static function imagesJson(array $article): string
	{
		if (empty($article['image'])) {
			return '{}';
		}

		$chemin = self::IMAGES_DIR . '/' . $article['image'];

		/*
		 * ON N'ÉCRIT PAS LE CHEMIN D'UN FICHIER QUI N'EST PAS LÀ : un article
		 * qui pointe une image absente affiche un cadre vide et une alternative
		 * textuelle dans le vide.
		 *
		 * CETTE LIGNE DÉPEND D'UN ORDRE, et c'est elle qui a fait disparaître
		 * toutes les vignettes le 26 août : la copie des images se faisait après
		 * la création des articles, donc le test échouait pour les quatorze.
		 * `copyImages()` est désormais le tout premier geste de `install()`.
		 * Si on déplace l'un, il faut regarder l'autre.
		 */
		if (!is_file(JPATH_SITE . '/' . $chemin)) {
			return '{}';
		}

		$alt = $article['imageAlt'] ?? $article['title'];

		return json_encode(
			[
				'image_intro'             => $chemin,
				'image_intro_alt'         => $alt,
				'float_intro'             => 'none',
				'image_intro_caption'     => '',
				'image_fulltext'          => $chemin,
				'image_fulltext_alt'      => $alt,
				// « none » et non '' : une valeur vide laisse le réglage global du
				// composant décider, et il vaut « left ». L'image flotterait alors à
				// gauche, à sa taille naturelle, au lieu de remplir sa colonne.
				'float_fulltext'          => 'none',
				'image_fulltext_caption'  => '',
			],
			JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
		);
	}

	/**
	 * Enregistre les valeurs des champs personnalisés d'un article.
	 *
	 * @param  int   $articleId
	 * @param  array $values
	 * @param  array $fieldIds
	 *
	 * @return void
	 */
	protected static function saveFieldValues(int $articleId, array $values, array $fieldIds): void
	{
		$model = self::getModel('com_fields', 'Field');

		foreach ($values as $name => $value) {
			if (empty($fieldIds[$name])) {
				continue;
			}

			if (is_array($value)) {
				// Liste d'ingrédients : une ligne par ingrédient.
				$value = '<ul>' . implode('', array_map(static fn ($v) => '<li>' . $v . '</li>', $value)) . '</ul>';
			}

			$model->setFieldValue($fieldIds[$name], $articleId, $value);
		}
	}

	/**
	 * Publie un module de menu pour le menu d'un scénario.
	 *
	 * En position `menu`, celle que Corpus range dans sa barre de navigation.
	 * Le module porte la marque du scénario, donc la réinitialisation le retire
	 * comme le reste, et le module de menu de l'utilisateur n'est ni déplacé ni
	 * dépublié : il reste où il est, et les deux cohabitent.
	 *
	 * @param  string $menutype
	 * @param  string $titre
	 *
	 * @return int
	 * @throws Exception
	 */
	protected static function creerModuleMenu(string $menutype, string $titre, string $langue = '*'): int
	{
		if ($menutype === '') {
			return 0;
		}

		return self::createModule(
			[
				'title'     => $titre,
				'module'    => 'mod_menu',
				'position'  => self::MENU_POSITION,
				'showtitle' => 0,
				'pages'     => 'all',
				'language'  => $langue,
				'params'    => [
					'menutype'        => $menutype,
					'base'            => '',
					'startLevel'      => '1',
					'endLevel'        => '0',

					/*
					 * « AFFICHER LES SOUS-ÉLÉMENTS » DOIT ÊTRE À OUI. Mesuré le
					 * 26 août 2026 sur le banc : « Découvrir » sortait en
					 * `<span class="mod-menu__heading separator">` SANS aucun
					 * `<ul>` à l'intérieur, alors que ses sept enfants étaient
					 * bien en base, publiés et correctement rattachés à lui.
					 *
					 * À zéro, `MenuHelper` ne retient que les enfants de la
					 * BRANCHE ACTIVE. Sur une page d'accueil, la branche active
					 * est l'accueil : le méga-menu du blog et du magazine, comme
					 * le sous-menu de la landing, n'avaient jamais rien à
					 * déplier. Une rubrique morte au bout de la barre.
					 *
					 * La surcharge de mod_menu de Corpus n'y pouvait rien : elle
					 * construit son panneau à partir de la liste qu'on lui donne,
					 * et cette liste était tronquée avant elle.
					 */
					'showAllChildren' => '1',
					'tag_id'          => '',
					'class_sfx'       => '',
					'window_open'     => '',
					'layout'          => '',
				],
			],
			[],
			[]
		);
	}

	/**
	 * Borne des modules aux seules entrées de menu d'un scénario.
	 *
	 * ON NE TOUCHE QUE CEUX QUI SONT SUR « TOUTES LES PAGES ». Un module déjà
	 * borné à l'accueil du scénario y reste : le restreindre une seconde fois
	 * l'élargirait, ce qui est l'inverse du but.
	 *
	 * @param  int[] $moduleIds
	 * @param  int[] $itemIds
	 *
	 * @return int
	 */
	protected static function bornerModulesAuScenario(array $moduleIds, array $itemIds): int
	{
		$moduleIds = array_values(array_filter(array_map('intval', $moduleIds)));
		$itemIds   = array_values(array_filter(array_map('intval', $itemIds)));

		if (!$moduleIds || !$itemIds) {
			return 0;
		}

		$db = Factory::getContainer()->get('DatabaseDriver');
		$n  = 0;

		foreach ($moduleIds as $moduleId) {
			$query = $db->getQuery(true)
				->select($db->quoteName('menuid'))
				->from($db->quoteName('#__modules_menu'))
				->where($db->quoteName('moduleid') . ' = :id')
				->bind(':id', $moduleId, ParameterType::INTEGER);

			$actuel = array_map('intval', (array) $db->setQuery($query)->loadColumn());

			// « Toutes les pages » s'écrit par une ligne unique à zéro.
			if ($actuel !== [0]) {
				continue;
			}

			$query = $db->getQuery(true)
				->delete($db->quoteName('#__modules_menu'))
				->where($db->quoteName('moduleid') . ' = :id')
				->bind(':id', $moduleId, ParameterType::INTEGER);

			$db->setQuery($query)->execute();

			foreach ($itemIds as $itemId) {
				$query = $db->getQuery(true)
					->insert($db->quoteName('#__modules_menu'))
					->columns($db->quoteName(['moduleid', 'menuid']))
					->values(':module, :menu')
					->bind(':module', $moduleId, ParameterType::INTEGER)
					->bind(':menu', $itemId, ParameterType::INTEGER);

				$db->setQuery($query)->execute();
			}

			$n++;
		}

		return $n;
	}

	/**
	 * Renvoie le menutype du menu de site à garnir, ou '' si aucun.
	 *
	 * On garnit un menu existant plutôt que d'en créer un : un menu neuf
	 * serait invisible sans module de menu à créer en plus.
	 *
	 * @return string
	 */
	/**
	 * Crée un menu de site, et note son nom pour la réinitialisation.
	 *
	 * `#__menu_types` N'A PAS DE COLONNE `note` : le repère qui sert à tout le
	 * reste du module ne peut pas s'y poser. Les noms créés sont donc notés
	 * dans les réglages de l'extension, comme la page d'accueil et les
	 * réglages de style, et c'est cette liste que la réinitialisation relit.
	 *
	 * Le nom est suffixé tant qu'un menu du même nom existe : on n'écrase
	 * jamais un menu de l'utilisateur, même homonyme.
	 *
	 * @param  string $menutype
	 * @param  string $titre
	 * @param  string $description
	 *
	 * @return string Le nom réellement créé, ou '' en cas d'échec
	 */
	protected static function createMenuType(string $menutype, string $titre, string $description = ''): string
	{
		$db      = Factory::getContainer()->get('DatabaseDriver');
		$candidat = $menutype;
		$rang     = 1;

		while (true) {
			$query = $db->getQuery(true)
				->select('COUNT(*)')
				->from($db->quoteName('#__menu_types'))
				->where($db->quoteName('menutype') . ' = :menutype')
				->bind(':menutype', $candidat);

			if (!(int) $db->setQuery($query)->loadResult()) {
				break;
			}

			$candidat = $menutype . '-' . (++$rang);
		}

		$model = self::getModel('com_menus', 'Menu');

		$ok = $model->save([
			'id'          => 0,
			'menutype'    => $candidat,
			'title'       => $titre,
			'description' => $description,
			'client_id'   => 0,
		]);

		if (!$ok) {
			throw new Exception('Menu « ' . $titre . " » : " . $model->getError(), 500);
		}

		$notes = self::getExtensionParam('menuTypes');
		$notes = is_array($notes) ? $notes : [];
		$notes[] = $candidat;
		self::setExtensionParam('menuTypes', $notes);

		return $candidat;
	}

	/**
	 * Supprime les menus créés par le module.
	 *
	 * À appeler APRÈS la suppression des éléments de menu marqués : le modèle
	 * de Joomla emporte les éléments restants avec le menu, et on ne veut pas
	 * qu'un élément de l'utilisateur, déplacé là entre-temps, parte avec.
	 *
	 * @return int
	 */
	protected static function removeMenuTypes(): int
	{
		$notes = self::getExtensionParam('menuTypes');

		if (!is_array($notes) || !$notes) {
			return 0;
		}

		$db    = Factory::getContainer()->get('DatabaseDriver');
		$model = self::getModel('com_menus', 'Menu');
		$n     = 0;

		foreach ($notes as $menutype) {
			$query = $db->getQuery(true)
				->select($db->quoteName('id'))
				->from($db->quoteName('#__menu_types'))
				->where($db->quoteName('menutype') . ' = :menutype')
				->bind(':menutype', $menutype);

			$id = (int) $db->setQuery($query)->loadResult();

			if ($id && $model->delete($id)) {
				$n++;
			}
		}

		self::setExtensionParam('menuTypes', null);

		return $n;
	}

	protected static function getSiteMenutype(): string
	{
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName('menutype'))
			->from($db->quoteName('#__menu_types'))
			->where($db->quoteName('client_id') . ' = 0')
			->order($db->quoteName('id') . ' ASC');

		$db->setQuery($query, 0, 1);

		return (string) $db->loadResult();
	}

	/**
	 * Crée un élément de menu « Blog d'une catégorie » marqué.
	 *
	 * @param  string $menutype
	 * @param  string $title
	 * @param  string $alias
	 * @param  int    $catId
	 *
	 * @return int
	 * @throws Exception
	 */
	protected static function createMenuItem(string $menutype, array $item, array $catIds, array $articleIds, array $menuIds): int
	{
		$type      = $item['type'] ?? 'category';
		$link      = '';
		$component = 'com_content';

		switch ($type) {
			case 'featured':
				$link = 'index.php?option=com_content&view=featured';
				break;

			case 'category':
				if (empty($catIds[$item['category']])) {
					return 0;
				}

				$link = 'index.php?option=com_content&view=category&layout=blog&id=' . (int) $catIds[$item['category']];
				break;

			case 'article':
				if (empty($articleIds[$item['article']])) {
					return 0;
				}

				$link = 'index.php?option=com_content&view=article&id=' . (int) $articleIds[$item['article']];
				break;

			case 'url':
				$link      = (string) ($item['link'] ?? '');
				$component = (string) ($item['component'] ?? 'com_content');
				break;

			/*
			 * UNE ANCRE N'EST PAS UN LIEN DE COMPOSANT. Le type natif de Joomla
			 * est `url` : il stocke l'adresse telle quelle et ne la fait pas
			 * passer par le routeur. Un `component` porteur de `#section`
			 * ressortirait routé, donc cassé.
			 *
			 * Le dièse seul ne suffit pas : le menu s'affiche sur toutes les
			 * pages, et `#section` depuis un article renverrait sur cet article.
			 * On préfixe donc par la racine du site.
			 */
			case 'ancre':
				$link = (string) ($item['link'] ?? '');

				if (strncmp($link, '#', 1) === 0) {
					$link = Uri::root(true) . '/' . $link;
				}

				break;

			case 'heading':
				// Type natif de Joomla : une entrée qui n'ouvre rien. C'est
				// elle qui porte une colonne du méga-menu.
				$link = '';
				break;
		}

		$parentId = 1;

		if (!empty($item['parent'])) {
			if (empty($menuIds[$item['parent']])) {
				return 0;
			}

			$parentId = (int) $menuIds[$item['parent']];
		}

		$params = [];

		if (!empty($item['mega'])) {
			/*
			 * LE DÉCLENCHEUR DU MÉGA-MENU DE CORPUS : le mot « mega » dans le
			 * champ natif « Style CSS du lien », sur une entrée de PREMIER
			 * niveau. Pas dans « Classe d'icône de lien », qui porte déjà les
			 * pictogrammes. Les entrées filles deviennent les colonnes.
			 */
			$params['menu-anchor_css'] = 'mega';
		}

		if (!empty($item['params'])) {
			$params = array_merge($params, $item['params']);
		}

		/*
		 * L'ALIAS DOIT ÊTRE LIBRE, ET LE MENU N'Y EST POUR RIEN.
		 *
		 * Relevé par Cyrille le 26 août 2026, à l'installation du blog sur un
		 * site bilingue : « The alias home is already being used by the Home
		 * menu item in the Main Menu menu ». Notre entrée d'accueil anglaise
		 * s'appelle « Home », donc son alias vaut `home`, et Joomla installe
		 * déjà une entrée « Home » d'alias `home` dans son propre menu.
		 *
		 * ON POURRAIT CROIRE QUE DEUX MENUS DIFFÉRENTS SUFFISENT. Ils ne
		 * suffisent pas. Lu dans `Table\Menu::store()` de Joomla 6 : le
		 * contrôle d'unicité porte sur `alias` + `parent_id` + `client_id`, et
		 * le `menutype` n'en fait PAS partie. Deux entrées de premier niveau
		 * ont toutes le même parent, la racine, quel que soit leur menu.
		 *
		 * LE FILTRE DE LANGUE N'Y SUFFIT PAS NON PLUS. Il autorise le même
		 * alias dans deux langues différentes, mais une entrée en « Toutes
		 * langues » bloque toutes les autres. Le « Home » de Joomla est
		 * justement en « Toutes langues ».
		 *
		 * On vérifie donc avant d'écrire, et on suffixe si c'est pris. Une
		 * démonstration ne doit jamais échouer à cause d'une entrée que le
		 * site portait déjà, et qui ne nous appartient pas.
		 */
		$data = [
			'id'           => 0,
			'title'        => $item['title'],
			'alias'        => self::aliasLibre(
				$item['alias'] ?? self::alias($item['title']),
				$parentId,
				$item['language'] ?? '*'
			),
			'menutype'     => $menutype,
			'type'         => $type === 'heading' ? 'heading' : ($type === 'ancre' ? 'url' : 'component'),
			'link'         => $link,
			'component_id' => in_array($type, ['heading', 'ancre'], true) ? 0 : self::getComponentId($component),
			'parent_id'    => $parentId,
			'published'    => 1,
			'access'       => 1,
			'language'     => $item['language'] ?? '*',
			'note'         => self::marker(),
			'params'       => $params,
			'client_id'    => 0,
		];

		/*
		 * LA PAGE D'ACCUEIL D'UNE LANGUE. Joomla accepte une page par défaut
		 * PAR LANGUE, en plus de celle qui vaut pour toutes. On la pose ici,
		 * et non par `setHome`, qui déloge l'existante : sur un site
		 * multilingue, il ne faut justement pas y toucher.
		 */
		if (!empty($item['home']) && ($item['language'] ?? '*') !== '*') {
			$data['home'] = 1;
		}

		$model = self::getModel('com_menus', 'Item');

		if (!$model->save($data)) {
			throw new Exception('Élément de menu « ' . $item['title'] . " » : " . $model->getError(), 500);
		}

		return (int) $model->getState('item.id');
	}

	/**
	 * Un alias d'URL à partir d'un intitulé.
	 *
	 * @param  string $titre
	 *
	 * @return string
	 */
	protected static function alias(string $titre): string
	{
		return \Joomla\CMS\Filter\OutputFilter::stringUrlSafe($titre);
	}

	/**
	 * Rend un alias d'entrée de menu qui ne heurte rien, sous ce parent.
	 *
	 * REPRODUIT LE CONTRÔLE DE JOOMLA, ET NE LE DEVINE PAS. `Table\Menu::store()`
	 * cherche une ligne de même `alias`, même `parent_id`, même `client_id`. Sur
	 * un site multilingue il tolère la même valeur dans DEUX LANGUES
	 * DIFFÉRENTES, mais une entrée en « Toutes langues » les bloque toutes, et
	 * une entrée qu'on veut en « Toutes langues » est bloquée par n'importe
	 * quelle langue.
	 *
	 * ON NE LIT PAS LE MESSAGE D'ERREUR POUR SAVOIR QUOI FAIRE. Il arrive
	 * traduit dans la langue de l'administration, et un correctif qui dépend
	 * d'une phrase traduite casse dès qu'on change de langue.
	 *
	 * Le suffixe nomme le coupable : `home-corpus` dit d'où vient l'entrée. Le
	 * compteur ne sert que si `-corpus` est pris lui aussi, ce qui suppose une
	 * installation précédente mal retirée. Dix essais, puis on laisse Joomla
	 * refuser : mieux vaut une erreur claire qu'une boucle sans fin.
	 *
	 * @param  string $alias
	 * @param  int    $parentId
	 * @param  string $langue
	 *
	 * @return string
	 */
	protected static function aliasLibre(string $alias, int $parentId, string $langue): string
	{
		$candidat = $alias;

		for ($essai = 0; $essai < 10; $essai++) {
			if (!self::aliasPris($candidat, $parentId, $langue)) {
				return $candidat;
			}

			$candidat = $essai === 0
				? $alias . '-corpus'
				: $alias . '-corpus-' . ($essai + 1);
		}

		return $candidat;
	}

	/**
	 * Vrai si cet alias est déjà tenu sous ce parent, pour cette langue.
	 *
	 * @param  string $alias
	 * @param  int    $parentId
	 * @param  string $langue
	 *
	 * @return bool
	 */
	protected static function aliasPris(string $alias, int $parentId, string $langue): bool
	{
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select('COUNT(*)')
			->from($db->quoteName('#__menu'))
			->where($db->quoteName('client_id') . ' = 0')
			->where($db->quoteName('parent_id') . ' = :parent')
			->where($db->quoteName('alias') . ' = :alias')
			->bind(':parent', $parentId, ParameterType::INTEGER)
			->bind(':alias', $alias);

		/*
		 * UNE ENTRÉE DE LANGUE NE HEURTE QUE SA LANGUE ET « TOUTES LANGUES ».
		 * Une entrée en « Toutes langues », elle, heurte tout le monde : on ne
		 * pose alors aucune condition de langue.
		 */
		if ($langue !== '*') {
			$query->where(
				'(' . $db->quoteName('language') . ' = :langue OR '
				. $db->quoteName('language') . ' = ' . $db->quote('*') . ')'
			)->bind(':langue', $langue);
		}

		return (int) $db->setQuery($query)->loadResult() > 0;
	}

	// =====================================================================
	// MISES EN AVANT, MODULES, PAGE D'ACCUEIL
	// =====================================================================

	/**
	 * Met des articles en vedette, par leur alias.
	 *
	 * On passe par le modèle et non par une requête : la mise en vedette
	 * s'écrit dans DEUX tables, `#__content` et `#__content_frontpage`, et
	 * n'écrire que la première laisse un article invisible sur l'accueil.
	 *
	 * @param  string[] $aliases
	 * @param  array    $articleIds
	 *
	 * @return int
	 */
	protected static function setFeatured(array $aliases, array $articleIds): int
	{
		$ids = [];

		foreach ($aliases as $alias) {
			if (!empty($articleIds[$alias])) {
				$ids[] = (int) $articleIds[$alias];
			}
		}

		if (!$ids) {
			return 0;
		}

		$model = self::getModel('com_content', 'Article');

		if (method_exists($model, 'featured')) {
			$model->featured($ids, 1);
		}

		return count($ids);
	}

	/**
	 * Crée un module de site marqué.
	 *
	 * ÉCRIRE LES PARAMÈTRES À LA MAIN NE DONNE AUCUN DÉFAUT. Un module créé
	 * par le formulaire reçoit les valeurs par défaut déclarées dans son
	 * manifeste ; un module créé ici ne reçoit QUE ce qu'on lui donne, et
	 * toute clé absente vaut null. C'est ce qui a vidé les listes d'articles :
	 * `item_title` valait null au lieu de 1, et le gabarit de Joomla saute
	 * l'entrée quand aucune option d'affichage n'est allumée. Il faut donc
	 * énumérer les réglages d'affichage, sans en supposer aucun.
	 *
	 * @param  array $module
	 * @param  array $catIds
	 * @param  array $articleIds
	 *
	 * @return int
	 * @throws Exception
	 */
	protected static function createModule(array $module, array $catIds, array $articleIds, int $accueilId = 0): int
	{
		// Les identifiants n'existent pas quand le fichier de contenu est lu :
		// il y écrit des repères, {lien:…}, {cat:…} et {art:…}, qu'on remplace
		// ici par les vraies valeurs. La résolution parcourt TOUS les
		// paramètres, et pas seulement le contenu : `catid` d'un module
		// d'articles en a besoin autant qu'un lien dans du HTML.
		$params = self::resoudreParams($module['params'] ?? [], $catIds, $articleIds);

		/*
		 * LE CONTENU D'UN MODULE PERSONNALISÉ N'EST PAS UN PARAMÈTRE.
		 * mod_custom affiche `$module->content`, une COLONNE de la table, et
		 * ignore complètement un `content` rangé dans les paramètres. Le
		 * module s'affichait donc, vide, sans la moindre erreur.
		 */
		$contenu = (string) self::resoudreParams($module['content'] ?? '', $catIds, $articleIds);

		$data = [
			'id'        => 0,
			'title'     => $module['title'],
			'module'    => $module['module'],
			'position'  => $module['position'],
			'content'   => $contenu,
			'published' => 1,
			'access'    => 1,
			'showtitle' => (int) ($module['showtitle'] ?? 1),

			// La langue d'un module le restreint aux pages de cette langue.
			// C'est ce qui fait qu'un menu par langue ne s'affiche que dans la
			// sienne, sans aucun réglage d'affectation de page.
			'language'  => $module['language'] ?? '*',
			'note'      => self::marker(),
			'client_id' => 0,
			'params'    => $params,
		];

		$model = self::getModel('com_modules', 'Module');

		if (!$model->save($data)) {
			throw new Exception('Module « ' . $module['title'] . " » : " . $model->getError(), 500);
		}

		$id = (int) $model->getState('module.id');

		self::affecterModuleAuxPages($id, $module['pages'] ?? 'all', $accueilId);

		return $id;
	}

	/**
	 * Résout les repères dans un arbre de paramètres, à toute profondeur.
	 *
	 * {cat:cle} et {art:cle} rendent un identifiant, et non une adresse : ce
	 * sont des valeurs de champs, pas du texte. Un paramètre qui vaut
	 * exactement un repère devient donc un entier, alors qu'un repère au
	 * milieu d'une phrase reste dans sa chaîne.
	 *
	 * @param  mixed $valeur
	 * @param  array $catIds
	 * @param  array $articleIds
	 *
	 * @return mixed
	 */
	protected static function resoudreParams($valeur, array $catIds, array $articleIds)
	{
		if (is_array($valeur)) {
			foreach ($valeur as $cle => $sous) {
				$valeur[$cle] = self::resoudreParams($sous, $catIds, $articleIds);
			}

			return $valeur;
		}

		if (!is_string($valeur) || strpos($valeur, '{') === false) {
			return $valeur;
		}

		if (preg_match('/^\{(cat|art):([a-z0-9\-]+)\}$/i', $valeur, $trouve)) {
			$table = $trouve[1] === 'cat' ? $catIds : $articleIds;

			return (int) ($table[$trouve[2]] ?? 0);
		}

		/*
		 * {menu:cle} rend le NOM DU MENU, pas un identifiant : c'est ce
		 * qu'attend le paramètre `menutype` de mod_menu. Le nom réel n'est connu
		 * qu'à l'installation, puisqu'il est suffixé si un menu du même nom
		 * existe déjà.
		 */
		if (preg_match('/^\{menu:([a-z0-9\-]+)\}$/i', $valeur, $trouve)) {
			return (string) (self::$menuTypes[$trouve[1]] ?? '');
		}

		return self::resoudreLiens($valeur, $catIds, $articleIds);
	}

	/**
	 * Remplace {lien:cle} par une vraie adresse.
	 *
	 * @param  string $html
	 * @param  array  $catIds
	 * @param  array  $articleIds
	 *
	 * @return string
	 */
	protected static function resoudreLiens(string $html, array $catIds, array $articleIds): string
	{
		// {cat:x} et {art:x} rendent un identifiant nu, utile dans une liste
		// d'identifiants séparés par des virgules.
		$html = (string) preg_replace_callback(
			'/\{(cat|art):([a-z0-9\-]+)\}/i',
			static function ($trouve) use ($catIds, $articleIds) {
				$table = $trouve[1] === 'cat' ? $catIds : $articleIds;

				return (string) (int) ($table[$trouve[2]] ?? 0);
			},
			$html
		);

		return (string) preg_replace_callback(
			'/\{lien:([a-z0-9\-]+)\}/i',
			static function ($trouve) use ($catIds, $articleIds) {
				$cle = $trouve[1];

				if (!empty($articleIds[$cle])) {
					return 'index.php?option=com_content&view=article&id=' . (int) $articleIds[$cle];
				}

				if (!empty($catIds[$cle])) {
					return 'index.php?option=com_content&view=category&layout=blog&id=' . (int) $catIds[$cle];
				}

				return '#';
			},
			$html
		);
	}

	/**
	 * Dit sur quelles pages un module sort.
	 *
	 * SANS LIGNE DANS `#__modules_menu`, UN MODULE NE SORT NULLE PART. Un
	 * module neuf n'est affecté à aucune page, et rien ne le signale.
	 * menuid 0 vaut « toutes les pages ».
	 *
	 * @param  int    $moduleId
	 * @param  string $pages  'all' ou 'home'
	 *
	 * @return void
	 */
	protected static function affecterModuleAuxPages(int $moduleId, string $pages, int $accueilId = 0): void
	{
		$db = Factory::getContainer()->get('DatabaseDriver');

		$query = $db->getQuery(true)
			->delete($db->quoteName('#__modules_menu'))
			->where($db->quoteName('moduleid') . ' = :id')
			->bind(':id', $moduleId, ParameterType::INTEGER);

		$db->setQuery($query)->execute();

		// 0 vaut « toutes les pages ». Sinon, la seule entrée d'accueil.
		$cibles = ($pages === 'home' && $accueilId) ? [$accueilId] : [0];

		foreach ($cibles as $cible) {
			$cible = (int) $cible;

			$query = $db->getQuery(true)
				->insert($db->quoteName('#__modules_menu'))
				->columns($db->quoteName(['moduleid', 'menuid']))
				->values(':module, :menu')
				->bind(':module', $moduleId, ParameterType::INTEGER)
				->bind(':menu', $cible, ParameterType::INTEGER);

			$db->setQuery($query)->execute();
		}
	}

	/**
	 * Passe une entrée de menu en page d'accueil du site.
	 *
	 * CELLE DE L'UTILISATEUR N'EST PAS LA NÔTRE : on la rétrograde, on note
	 * son identifiant dans les réglages de l'extension, et la
	 * réinitialisation la remet en place. Joomla n'accepte qu'une seule page
	 * par défaut par langue, il faut donc bien déloger l'ancienne.
	 *
	 * @param  int $itemId
	 *
	 * @return int
	 */
	protected static function setHome(int $itemId): int
	{
		$db = Factory::getContainer()->get('DatabaseDriver');

		$query = $db->getQuery(true)
			->select($db->quoteName('id'))
			->from($db->quoteName('#__menu'))
			->where($db->quoteName('home') . ' = 1')
			->where($db->quoteName('client_id') . ' = 0')
			->where($db->quoteName('language') . ' = ' . $db->quote('*'));

		$db->setQuery($query);

		$ancienne = (int) $db->loadResult();

		if ($ancienne === $itemId) {
			return 0;
		}

		if ($ancienne) {
			self::setExtensionParam('homeBackup', $ancienne);

			/*
			 * ON LA DÉPUBLIE AUSSI, et pas seulement rétrograde. Rétrogradée
			 * seule, elle reste dans le menu : le site affiche alors deux
			 * entrées d'accueil côte à côte, « Home » et « Accueil ». La
			 * réinitialisation la republie.
			 */
			$query = $db->getQuery(true)
				->update($db->quoteName('#__menu'))
				->set($db->quoteName('home') . ' = 0')
				->set($db->quoteName('published') . ' = 0')
				->where($db->quoteName('id') . ' = :id')
				->bind(':id', $ancienne, ParameterType::INTEGER);

			$db->setQuery($query)->execute();
		}

		$query = $db->getQuery(true)
			->update($db->quoteName('#__menu'))
			->set($db->quoteName('home') . ' = 1')
			->where($db->quoteName('id') . ' = :id')
			->bind(':id', $itemId, ParameterType::INTEGER);

		$db->setQuery($query)->execute();

		return 1;
	}

	/**
	 * Rend à l'utilisateur sa page d'accueil.
	 *
	 * Appelée AVANT la suppression des entrées de menu : sinon Joomla se
	 * retrouve un instant sans aucune page par défaut.
	 *
	 * @return int
	 */
	protected static function restoreHome(): int
	{
		$ancienne = (int) self::getExtensionParam('homeBackup');

		if (!$ancienne) {
			return 0;
		}

		$db = Factory::getContainer()->get('DatabaseDriver');

		$query = $db->getQuery(true)
			->update($db->quoteName('#__menu'))
			->set($db->quoteName('home') . ' = 0')
			->where($db->quoteName('client_id') . ' = 0')
			->where($db->quoteName('language') . ' = ' . $db->quote('*'));

		$db->setQuery($query)->execute();

		$query = $db->getQuery(true)
			->update($db->quoteName('#__menu'))
			->set($db->quoteName('home') . ' = 1')
			->set($db->quoteName('published') . ' = 1')
			->where($db->quoteName('id') . ' = :id')
			->bind(':id', $ancienne, ParameterType::INTEGER);

		$db->setQuery($query)->execute();

		self::setExtensionParam('homeBackup', null);

		return 1;
	}

	// =====================================================================
	// LE SCÉNARIO MULTILINGUE
	// =====================================================================

	/**
	 * Monte un site à plusieurs langues, sur le modèle de la donnée d'exemple
	 * multilingue de Joomla.
	 *
	 * IL NE PASSE PAS PAR install(). Ce scénario ne pose ni champ, ni gabarit
	 * d'article, ni article en vedette, et son contenu n'est pas connu à
	 * l'avance : il dépend des langues trouvées sur le site. Le faire entrer
	 * dans le moule des trois autres aurait demandé une exception à chaque
	 * étape, pour un résultat plus difficile à suivre.
	 *
	 * @param  string $task
	 * @param  array  $conf
	 *
	 * @return array
	 * @throws Exception
	 */
	protected static function installMultilangue(string $task, array $conf): array
	{
		if (self::countMarked('#__content') > 0) {
			throw new Exception(Text::_('MOD_CORPUS_START_ALREADY_INSTALLED'), 409);
		}

		$langues = self::languesDuSite();

		/*
		 * DEUX LANGUES AU MINIMUM, ET ON REFUSE PLUTÔT QUE DE FAIRE SEMBLANT.
		 * Un site « multilingue » à une seule langue ne montre rien de ce que
		 * ce scénario est censé expliquer, et laisserait derrière lui un
		 * sélecteur de langue à un seul drapeau.
		 */
		if (count($langues) < 2) {
			throw new Exception(Text::_('MOD_CORPUS_START_NEED_LANGUAGES'), 409);
		}

		self::$menuTypes = [];

		$counts = [
			'langues'    => self::publierLanguesContenu($langues),
			'plugin'     => self::activerFiltreDeLangue() ? 1 : 0,
			'categories' => 0,
			'articles'   => 0,
			'menu'       => 0,
			'modules'    => 0,
		];

		// Les réglages de zone dont le sélecteur a besoin pour sortir quelque
		// part. Sur le style du site : ce scénario ne crée pas de style dédié.
		self::$styleScenarioId = 0;
		$counts['preset'] = self::applyStyleParams($conf['styleParams'] ?? []);

		$associations = [];
		$repli        = [];

		foreach ($langues as $code) {
			$def = $conf['langues'][$code] ?? null;

			if ($def === null) {
				// Langue installée mais pas prévue ici : on reprend les textes
				// anglais, en suffixant tout ce qui doit rester unique.
				$def     = self::replierSurAnglais($conf['langues']['en-GB'], $code);
				$repli[] = $code;
			}

			$suffixe = strtolower($code);

			// --- La catégorie de la langue ---------------------------------
			$catId = self::createCategory(
				$def['categorie']['title'],
				$def['categorie']['alias'],
				1,
				$code
			);
			$counts['categories']++;
			$associations['com_categories.item']['cat'][$code] = $catId;

			// --- Ses articles ----------------------------------------------
			foreach ($def['articles'] as $article) {
				$article['language'] = $code;

				$id = self::createArticle($article, $catId);
				$counts['articles']++;

				$associations['com_content.item'][$article['cle']][$code] = $id;
			}

			// --- Son menu, et sa page d'accueil ----------------------------
			$menutype = self::createMenuType(
				$def['menu']['menutype'],
				$def['menu']['title'],
				$def['menu']['description'] ?? ''
			);

			self::$menuTypes[$suffixe] = $menutype;

			$itemId = self::createMenuItem(
				$menutype,
				[
					'title'    => $def['accueil'],
					'alias'    => 'accueil-' . $suffixe,
					'type'     => 'category',
					'category' => 'cat',
					'language' => $code,
					'home'     => true,
					'params'   => $conf['accueilParams'] ?? [],
				],
				['cat' => $catId],
				[],
				[]
			);

			$counts['menu']++;
			$associations['com_menus.item']['accueil'][$code] = $itemId;

			// --- Son module de menu ----------------------------------------
			self::createModule(
				[
					'title'     => $def['menu']['title'],
					'module'    => 'mod_menu',
					'position'  => self::MENU_POSITION,
					'showtitle' => 0,
					'pages'     => 'all',
					'language'  => $code,
					'params'    => [
						'menutype'        => $menutype,
						'base'            => '',
						'startLevel'      => '1',
						'endLevel'        => '0',

						// Même raison que dans `creerModuleMenu()` : à zéro, aucun
						// sous-élément ne sort hors de la branche active, et une
						// rubrique se réduit à un intitulé mort.
						'showAllChildren' => '1',
						'tag_id'          => '',
						'class_sfx'       => '',
						'window_open'     => '',
						'layout'          => '',
					],
				],
				[],
				[]
			);

			$counts['modules']++;

			// --- Son pied de site ------------------------------------------
			// Le second argument est la langue DU MODULE : c'est elle qui fait
			// qu'un visiteur ne voit que le pied de sa langue.
			foreach (['pied', 'barre', 'demos'] as $bloc) {
				if (empty($conf[$bloc])) {
					continue;
				}

				foreach ($conf[$bloc]($code, $code) as $module) {
					self::createModule($module, [], []);
					$counts['modules']++;
				}
			}
		}

		// --- Le sélecteur de langue ----------------------------------------
		$switch = $conf['switch'];

		self::createModule(
			[
				'title'     => $switch['title'],
				'module'    => 'mod_languages',
				'position'  => $switch['position'],
				'showtitle' => 0,
				'pages'     => 'all',
				'language'  => '*',
				'params'    => $switch['params'],
			],
			[],
			[]
		);

		$counts['modules']++;

		/*
		 * LE MODULE DE MENU D'AVANT EST DÉPUBLIÉ, comme le fait Joomla dans sa
		 * donnée d'exemple. Chaque langue a maintenant le sien, filtré sur sa
		 * langue ; celui d'avant afficherait un menu sans langue par-dessus, et
		 * la navigation apparaîtrait en double.
		 */
		$counts['menuModule'] = self::depublierModuleMenu() ? 1 : 0;

		/*
		 * LE FIL D'ARIANE N'A RIEN À FAIRE SUR UNE PAGE D'ACCUEIL. Il dit où
		 * l'on est dans une arborescence, et l'accueil n'est nulle part dans
		 * une arborescence : il en est le point d'entrée. Le fil s'y réduit à
		 * « Vous êtes ici : Accueil », qui n'apprend rien.
		 *
		 * ON N'EXCLUT QUE CETTE PAGE, et le module reste publié partout
		 * ailleurs : il appartient à l'utilisateur. Chaque langue a sa propre
		 * page d'accueil, donc chacune reçoit son exclusion.
		 */
		$counts['ariane'] = 0;

		foreach ($associations['com_menus.item']['accueil'] ?? [] as $unAccueil) {
			$counts['ariane'] += self::masquerFilAriane((int) $unAccueil);
		}

		// --- Les associations ----------------------------------------------
		$counts['associations'] = self::createAssociations($associations);

		// --- La feuille compilée, une seule fois et en dernier --------------
		$counts['style'] = self::regenererStyleCorpus() ? 1 : 0;

		$message = Text::sprintf(
			'MOD_CORPUS_START_MULTILANGUE_DONE',
			count($langues),
			$counts['articles'],
			$counts['menu'],
			$counts['associations']
		);

		if ($repli) {
			$message .= ' ' . Text::sprintf('MOD_CORPUS_START_MULTILANGUE_FALLBACK', implode(', ', $repli));
		}

		return ['task' => $task, 'counts' => $counts, 'message' => $message];
	}

	/**
	 * Les langues du site utilisables pour du contenu.
	 *
	 * Croisement de DEUX listes, et les deux comptent : une langue de contenu
	 * déclarée dans `#__languages` SANS pack installé afficherait un site à
	 * moitié traduit, et un pack installé SANS langue de contenu ne peut
	 * étiqueter aucun article. Joomla crée la seconde à l'installation du
	 * premier depuis longtemps, mais rien ne garantit qu'on ne l'a pas
	 * supprimée depuis.
	 *
	 * @return string[]
	 */
	protected static function languesDuSite(): array
	{
		$db = Factory::getContainer()->get('DatabaseDriver');

		$query = $db->getQuery(true)
			->select($db->quoteName('element'))
			->from($db->quoteName('#__extensions'))
			->where($db->quoteName('type') . ' = ' . $db->quote('language'))
			->where($db->quoteName('client_id') . ' = 0')
			->where($db->quoteName('enabled') . ' = 1');

		$packs = (array) $db->setQuery($query)->loadColumn();

		$query = $db->getQuery(true)
			->select($db->quoteName('lang_code'))
			->from($db->quoteName('#__languages'))
			->order($db->quoteName('ordering') . ' ASC');

		$contenus = (array) $db->setQuery($query)->loadColumn();

		return array_values(array_intersect($contenus, $packs));
	}

	/**
	 * Publie les langues de contenu retenues.
	 *
	 * Une langue de contenu dépubliée n'apparaît pas dans le sélecteur, et le
	 * filtre de langue l'ignore : le contenu qui la porte devient invisible.
	 *
	 * @param  string[] $codes
	 *
	 * @return int
	 */
	protected static function publierLanguesContenu(array $codes): int
	{
		if (!$codes) {
			return 0;
		}

		$db = Factory::getContainer()->get('DatabaseDriver');

		$query = $db->getQuery(true)
			->update($db->quoteName('#__languages'))
			->set($db->quoteName('published') . ' = 1')
			->whereIn($db->quoteName('lang_code'), $codes, ParameterType::STRING);

		$db->setQuery($query)->execute();

		return count($codes);
	}

	/**
	 * Allume le plugin « Système : Filtre de langue », en notant son état.
	 *
	 * SANS LUI, RIEN NE MARCHE : c'est ce plugin qui lit la langue courante,
	 * écarte le contenu des autres et redirige vers la page d'accueil de la
	 * bonne langue. Éteint, le site affiche toutes les langues mélangées, et le
	 * sélecteur ne fait rien de visible.
	 *
	 * @return bool
	 */
	protected static function activerFiltreDeLangue(): bool
	{
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName(['extension_id', 'enabled', 'params']))
			->from($db->quoteName('#__extensions'))
			->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
			->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
			->where($db->quoteName('element') . ' = ' . $db->quote('languagefilter'));

		$plugin = $db->setQuery($query)->loadObject();

		if (!$plugin) {
			return false;
		}

		$params = self::decodeParams($plugin->params);

		/*
		 * ACTIVER LE PLUGIN NE SUFFIT PAS, ET C'ÉTAIT LE DÉFAUT.
		 *
		 * Relevé par Cyrille le 26 août 2026 : « je suis en France, mon
		 * navigateur est en français, et landing.joomanji.eu m'ouvre l'anglais ».
		 *
		 * `detect_browser` VAUT ZÉRO PAR DÉFAUT chez Joomla, et zéro veut dire
		 * « langue du site », pas « langue du visiteur ». Lu dans
		 * `languagefilter.xml` de Joomla 6.1.2 : deux valeurs seulement, 0 pour
		 * PLG_SYSTEM_LANGUAGEFILTER_SITE_LANGUAGE, 1 pour
		 * PLG_SYSTEM_LANGUAGEFILTER_BROWSER_SETTINGS. Nos quatre sites ont
		 * l'anglais pour langue de site : tout le monde arrivait en anglais.
		 *
		 * C'EST LE CŒUR DE CE QUE CYRILLE A DEMANDÉ LE 25 AOÛT : « le site doit
		 * être en français quand il est ouvert en France et en anglais pour le
		 * reste ». Sans ce réglage, la démonstration multilingue montre deux
		 * langues et n'en choisit aucune.
		 *
		 * LE CHOIX DU VISITEUR RESTE PLUS FORT. Dès qu'il clique un drapeau,
		 * Joomla pose un cookie de langue qui l'emporte sur la détection : c'est
		 * pour cela que le sélecteur doit rester visible.
		 */
		$avant = [
			'id'      => (int) $plugin->extension_id,
			'enabled' => (int) $plugin->enabled,
			'params'  => $params,
		];

		$dejaBon = (int) $plugin->enabled === 1
			&& (int) ($params['detect_browser'] ?? 0) === 1;

		if ($dejaBon) {
			return true;
		}

		// On ne note l'état d'avant qu'une fois : un second scénario installé
		// par-dessus ne doit pas sauvegarder ce que le premier vient de poser.
		if (self::getExtensionParam('pluginBackup') === null) {
			self::setExtensionParam('pluginBackup', $avant);
		}

		$params['detect_browser'] = 1;

		$id      = (int) $plugin->extension_id;
		$encodes = json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

		$query = $db->getQuery(true)
			->update($db->quoteName('#__extensions'))
			->set($db->quoteName('enabled') . ' = 1')
			->set($db->quoteName('params') . ' = :params')
			->where($db->quoteName('extension_id') . ' = :id')
			->bind(':params', $encodes)
			->bind(':id', $id, ParameterType::INTEGER);

		$db->setQuery($query)->execute();

		return true;
	}

	/**
	 * Exclut le fil d'Ariane d'une page, sans toucher au module.
	 *
	 * COMMENT JOOMLA EXCLUT UN MODULE D'UNE PAGE, mesuré dans
	 * `ModuleHelper::cleanModuleList()` de Joomla 6.1.2 : une ligne de
	 * `#__modules_menu` dont le `menuid` vaut MOINS l'identifiant de l'élément
	 * de menu. La requête de chargement, elle, ne filtre rien du tout, elle
	 * ramène aussi les valeurs négatives ; c'est le nettoyage qui les applique
	 * ensuite, et une exclusion gagne sur une affectation « toutes les pages ».
	 *
	 * ON AJOUTE UNE LIGNE, ON N'EN RETIRE AUCUNE. Le module de fil d'Ariane
	 * appartient à l'utilisateur : le dépublier ou réécrire son affectation
	 * toucherait tout son site pour une seule page. La ligne ajoutée est notée,
	 * et la réinitialisation la retire.
	 *
	 * @param  int $itemId
	 *
	 * @return int Le nombre de modules exclus
	 */
	protected static function masquerFilAriane(int $itemId): int
	{
		if (!$itemId) {
			return 0;
		}

		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName('id'))
			->from($db->quoteName('#__modules'))
			->where($db->quoteName('client_id') . ' = 0')
			->where($db->quoteName('module') . ' = ' . $db->quote('mod_breadcrumbs'))
			->where($db->quoteName('published') . ' = 1');

		$ids = array_map('intval', (array) $db->setQuery($query)->loadColumn());

		if (!$ids) {
			return 0;
		}

		$negatif = -$itemId;
		$notes   = [];

		foreach ($ids as $moduleId) {
			$query = $db->getQuery(true)
				->select('COUNT(*)')
				->from($db->quoteName('#__modules_menu'))
				->where($db->quoteName('moduleid') . ' = :module')
				->where($db->quoteName('menuid') . ' = :menu')
				->bind(':module', $moduleId, ParameterType::INTEGER)
				->bind(':menu', $negatif, ParameterType::INTEGER);

			if ((int) $db->setQuery($query)->loadResult()) {
				continue;
			}

			$query = $db->getQuery(true)
				->insert($db->quoteName('#__modules_menu'))
				->columns($db->quoteName(['moduleid', 'menuid']))
				->values(':module, :menu')
				->bind(':module', $moduleId, ParameterType::INTEGER)
				->bind(':menu', $negatif, ParameterType::INTEGER);

			$db->setQuery($query)->execute();

			$notes[] = [$moduleId, $negatif];
		}

		/*
		 * ON CUMULE, ON N'ÉCRASE PAS. Cette méthode est appelée UNE FOIS PAR
		 * PAGE D'ACCUEIL, et un site bilingue en a deux. La version d'avant
		 * réécrivait la sauvegarde à chaque appel : la seconde langue effaçait
		 * la note de la première, et la réinitialisation laissait derrière elle
		 * une exclusion de fil d'Ariane que plus personne ne savait retirer.
		 */
		if ($notes) {
			$deja  = self::getExtensionParam('arianeBackup');
			$deja  = is_array($deja) ? $deja : [];
			$notes = array_merge($deja, $notes);

			self::setExtensionParam('arianeBackup', $notes);
		}

		return count($notes);
	}

	/**
	 * Retire les exclusions posées sur le fil d'Ariane.
	 *
	 * @return int
	 */
	protected static function restaurerFilAriane(): int
	{
		$notes = self::getExtensionParam('arianeBackup');

		if (!is_array($notes) || !$notes) {
			return 0;
		}

		$db = Factory::getContainer()->get('DatabaseDriver');
		$n  = 0;

		foreach ($notes as $ligne) {
			$moduleId = (int) ($ligne[0] ?? 0);
			$menuId   = (int) ($ligne[1] ?? 0);

			if (!$moduleId || !$menuId) {
				continue;
			}

			$query = $db->getQuery(true)
				->delete($db->quoteName('#__modules_menu'))
				->where($db->quoteName('moduleid') . ' = :module')
				->where($db->quoteName('menuid') . ' = :menu')
				->bind(':module', $moduleId, ParameterType::INTEGER)
				->bind(':menu', $menuId, ParameterType::INTEGER);

			$db->setQuery($query)->execute();
			$n++;
		}

		self::setExtensionParam('arianeBackup', null);

		return $n;
	}

	/**
	 * Rend au plugin de filtre de langue son état d'avant.
	 *
	 * @return int
	 */
	protected static function restaurerFiltreDeLangue(): int
	{
		$backup = self::getExtensionParam('pluginBackup');

		if (!is_array($backup) || empty($backup['id'])) {
			return 0;
		}

		$db      = Factory::getContainer()->get('DatabaseDriver');
		$id      = (int) $backup['id'];
		$enabled = (int) $backup['enabled'];

		$query = $db->getQuery(true)
			->update($db->quoteName('#__extensions'))
			->set($db->quoteName('enabled') . ' = :enabled')
			->where($db->quoteName('extension_id') . ' = :id')
			->bind(':enabled', $enabled, ParameterType::INTEGER)
			->bind(':id', $id, ParameterType::INTEGER);

		/*
		 * LES RÉGLAGES REVIENNENT AUSSI, et pas seulement l'interrupteur. On
		 * pose `detect_browser` à l'installation ; le rendre à la
		 * réinitialisation est la moitié qui manquait. La clé n'existe pas dans
		 * les sauvegardes d'avant le 26 août 2026 : on ne touche alors à rien,
		 * plutôt que d'écraser les réglages par un tableau vide.
		 */
		if (array_key_exists('params', $backup) && is_array($backup['params'])) {
			$encodes = json_encode(
				$backup['params'],
				JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
			);

			$query->set($db->quoteName('params') . ' = :params')->bind(':params', $encodes);
		}

		$db->setQuery($query)->execute();

		self::setExtensionParam('pluginBackup', null);

		return 1;
	}

	/**
	 * Dépublie le module de menu du site, en notant son état.
	 *
	 * Réutilise la même note que `forceMenuPosition` : les deux ne servent
	 * jamais dans le même scénario, et `restoreMenuPosition` les rend l'une
	 * comme l'autre.
	 *
	 * @return bool
	 */
	protected static function depublierModuleMenu(): bool
	{
		$db = Factory::getContainer()->get('DatabaseDriver');

		$query = $db->getQuery(true)
			->select($db->quoteName(['id', 'position', 'published']))
			->from($db->quoteName('#__modules'))
			->where($db->quoteName('client_id') . ' = 0')
			->where($db->quoteName('module') . ' = ' . $db->quote('mod_menu'))
			->where($db->quoteName('published') . ' = 1')
			// Tout module de menu posé par ce module est écarté, quel que soit
			// son scénario : on cherche celui de l'utilisateur.
			->where('(' . $db->quoteName('note') . ' IS NULL OR ' . $db->quoteName('note')
				. ' NOT LIKE ' . $db->quote(self::MARKER . '%') . ')')
			->order($db->quoteName('id') . ' ASC');

		$db->setQuery($query, 0, 1);
		$cible = $db->loadObject();

		if (!$cible) {
			return false;
		}

		self::setExtensionParam('menuBackup', [
			'id'        => (int) $cible->id,
			'position'  => (string) $cible->position,
			'published' => (int) $cible->published,
		]);

		$id    = (int) $cible->id;
		$query = $db->getQuery(true)
			->update($db->quoteName('#__modules'))
			->set($db->quoteName('published') . ' = 0')
			->where($db->quoteName('id') . ' = :id')
			->bind(':id', $id, ParameterType::INTEGER);

		$db->setQuery($query)->execute();

		return true;
	}

	/**
	 * Écrit les associations de langue.
	 *
	 * FORMAT DE LA TABLE, RELEVÉ DANS LE PLUGIN DE JOOMLA : une ligne par
	 * élément, toutes les lignes d'un même groupe partageant une `key` qui est
	 * le md5 du groupe encodé en JSON. Ce n'est pas une clé arbitraire : c'est
	 * elle qui fait le lien, et Joomla la recalcule de la même façon.
	 *
	 * Un groupe d'une seule langue n'est pas une association : on l'écarte.
	 *
	 * @param  array $groupes  context => clé => [langue => id]
	 *
	 * @return int
	 */
	protected static function createAssociations(array $groupes): int
	{
		$db = Factory::getContainer()->get('DatabaseDriver');
		$n  = 0;

		foreach ($groupes as $context => $parCle) {
			foreach ($parCle as $paires) {
				if (count($paires) < 2) {
					continue;
				}

				$cle = md5(json_encode($paires));

				foreach ($paires as $id) {
					$query = $db->getQuery(true)
						->insert($db->quoteName('#__associations'))
						->columns($db->quoteName(['id', 'context', 'key']))
						->values(':id, :context, :cle')
						->bind(':id', $id, ParameterType::INTEGER)
						->bind(':context', $context)
						->bind(':cle', $cle);

					$db->setQuery($query)->execute();
					$n++;
				}
			}
		}

		return $n;
	}

	/**
	 * Supprime les associations qui visent le contenu marqué.
	 *
	 * `#__associations` N'A PAS DE COLONNE `note` : on ne peut pas y poser le
	 * repère. On passe donc par les identifiants, tant que les articles et les
	 * éléments de menu existent encore. D'où l'ordre du reset : ceci d'abord,
	 * les suppressions ensuite.
	 *
	 * @return int
	 */
	protected static function removeAssociations(): int
	{
		$db = Factory::getContainer()->get('DatabaseDriver');
		$n  = 0;

		$tables = [
			'com_content.item'    => '#__content',
			'com_menus.item'      => '#__menu',
			'com_categories.item' => '#__categories',
		];

		foreach ($tables as $context => $table) {
			$ids = self::getMarkedIds($table);

			if (!$ids) {
				continue;
			}

			$query = $db->getQuery(true)
				->delete($db->quoteName('#__associations'))
				->where($db->quoteName('context') . ' = ' . $db->quote($context))
				->whereIn($db->quoteName('id'), $ids);

			$db->setQuery($query)->execute();
			$n += $db->getAffectedRows();
		}

		return $n;
	}

	/**
	 * Les textes anglais, repliés sur une langue que le module ne connaît pas.
	 *
	 * Tout ce qui doit rester unique est suffixé du code de langue : deux
	 * catégories de même alias sous la même parente, ou deux menus de même nom,
	 * seraient refusées par Joomla.
	 *
	 * @param  array  $def
	 * @param  string $code
	 *
	 * @return array
	 */
	protected static function replierSurAnglais(array $def, string $code): array
	{
		$suffixe = strtolower($code);

		$def['categorie']['title'] .= ' (' . $code . ')';
		$def['categorie']['alias'] .= '-' . $suffixe;
		$def['menu']['menutype']    = 'corpus-' . $suffixe;
		$def['menu']['title']       = 'Main menu (' . $code . ')';

		foreach ($def['articles'] as $rang => $article) {
			$def['articles'][$rang]['alias'] = $article['alias'] . '-' . $suffixe;
		}

		return $def;
	}

	/**
	 * Retire le contenu partagé quand plus aucune démonstration ne s'en sert.
	 *
	 * APPELÉE APRÈS la suppression des entrées de menu du scénario : c'est
	 * elle que `getInstalled()` lit, et la liste doit déjà refléter le départ
	 * en cours.
	 *
	 * Rien ne se passe tant qu'il reste une démonstration. C'est la contrepartie
	 * du partage, et elle se voit à l'usage : retirer le blog quand le magazine
	 * est là ne fait pas disparaître les articles, puisque le magazine les
	 * affiche encore.
	 *
	 * @return int
	 */
	protected static function retirerCommunSiSeul(): int
	{
		// Le retrait global fait sa propre passe : il ne doit pas se déclencher
		// ici, au milieu, alors que d'autres scénarios attendent leur tour.
		if (self::$scenario === '' || self::$scenario === 'commun') {
			return 0;
		}

		if (self::getInstalled()) {
			return 0;
		}

		$vise = self::$scenario;
		self::$scenario = 'commun';

		$n  = self::deleteMarked('com_content', 'Article', '#__content', 'state');
		$n += self::deleteMarkedCategories();
		$n += self::deleteMarked('com_fields', 'Field', '#__fields', 'state');
		$n += self::deleteMarked('com_fields', 'Group', '#__fields_groups', 'state');

		self::$scenario = $vise;

		return $n;
	}

	// =====================================================================
	// RÉINITIALISATION
	// =====================================================================

	/**
	 * Supprime tout ce que le module a créé, et rien d'autre.
	 *
	 * L'ordre compte : articles avant catégories (une catégorie non vide ne
	 * se supprime pas), éléments de menu avant catégories aussi.
	 *
	 * @return array
	 * @throws Exception
	 */
	protected static function reset(): array
	{
		/*
		 * SANS SCÉNARIO VISÉ, ON RETIRE CHACUN À SON TOUR plutôt que tout d'un
		 * coup. Les sauvegardes sont rangées par scénario : une passe unique
		 * avec une clé nue ne trouverait ni la largeur de page notée par le
		 * blog, ni la page d'accueil notée par la landing, et ne rendrait rien.
		 *
		 * La liste est relevée AVANT la première suppression : elle se lit dans
		 * les notes des articles, qui disparaissent au fur et à mesure.
		 */
		if (self::$scenario === '') {
			$installes = self::getInstalled();

			if (count($installes) > 1 || (count($installes) === 1 && $installes[0] !== '')) {
				$cumul = [];

				foreach ($installes as $un) {
					self::$scenario = $un;
					$passe = self::resetUn();

					foreach ($passe['counts'] as $cle => $valeur) {
						$cumul[$cle] = ($cumul[$cle] ?? 0) + $valeur;
					}
				}

				/*
				 * LE COMMUN EN DERNIER. Chaque passe l'a laissé en place, parce
				 * qu'il restait des scénarios à retirer derrière elle. Une fois
				 * la boucle finie, plus personne ne s'en sert.
				 */
				self::$scenario = 'commun';
				$cumul['articles']   = ($cumul['articles'] ?? 0)
					+ self::deleteMarked('com_content', 'Article', '#__content', 'state');
				$cumul['categories'] = ($cumul['categories'] ?? 0) + self::deleteMarkedCategories();
				$cumul['fields']     = ($cumul['fields'] ?? 0)
					+ self::deleteMarked('com_fields', 'Field', '#__fields', 'state');
				$cumul['groups']     = ($cumul['groups'] ?? 0)
					+ self::deleteMarked('com_fields', 'Group', '#__fields_groups', 'state');

				self::$scenario = '';

				return [
					'task'    => 'reset',
					'counts'  => $cumul,
					'message' => Text::sprintf(
						'MOD_CORPUS_START_RESET_DONE',
						$cumul['articles'] ?? 0,
						$cumul['categories'] ?? 0,
						$cumul['fields'] ?? 0,
						$cumul['menu'] ?? 0
					),
				];
			}
		}

		return self::resetUn();
	}

	/**
	 * Retire un seul scénario, celui que `self::$scenario` désigne.
	 *
	 * @return array
	 * @throws Exception
	 */
	protected static function resetUn(): array
	{
		$counts = [];

		// D'ABORD rendre sa page d'accueil : supprimer nos entrées de menu
		// alors que l'une d'elles est encore la page par défaut laisserait
		// Joomla sans aucune page d'accueil.
		// En bilingue, rien n'a été délogé : `setHome()` n'a pas été appelé, et
		// `homeBackup` est vide. La méthode le voit et ne fait rien.
		$counts['accueil']    = self::restoreHome();

		// AVANT TOUTE SUPPRESSION : les associations se désignent par les
		// identifiants des articles et des entrées de menu, qui n'existeront
		// plus dans trois lignes.
		$counts['associations'] = self::removeAssociations();

		$counts['menu']       = self::deleteMarked('com_menus', 'Item', '#__menu', 'published');

		// APRÈS les entrées : le modèle de Joomla emporte avec le menu tout ce
		// qu'il contient encore, et une entrée que l'utilisateur y aurait
		// déplacée entre-temps ne nous appartient pas.
		$counts['menuTypes']  = self::removeMenuTypes();

		$counts['modules']    = self::deleteMarked('com_modules', 'Module', '#__modules', 'published');
		$counts['articles']   = self::deleteMarked('com_content', 'Article', '#__content', 'state');
		$counts['categories'] = self::deleteMarkedCategories();
		$counts['fields']     = self::deleteMarked('com_fields', 'Field', '#__fields', 'state');
		$counts['groups']     = self::deleteMarked('com_fields', 'Group', '#__fields_groups', 'state');
		$counts['gabarit']    = self::removeGabarit();

		// Le style dédié part en entier ; le style du site, lui, se voit rendre
		// les réglages notés. Un scénario n'utilise jamais les deux.
		$counts['styleDedie'] = self::removeStyleScenario();
		$counts['preset']     = self::restorePreset();
		$counts['images']     = self::removeImages();
		$counts['menuModule'] = self::restoreMenuPosition();
		$counts['plugin']     = self::restaurerFiltreDeLangue();
		$counts['ariane']     = self::restaurerFilAriane();

		// --- Le contenu partagé, s'il ne sert plus à personne ---------------
		$counts['commun'] = self::retirerCommunSiSeul();

		// En dernier, comme à l'installation : la feuille compilée du template
		// doit refléter les réglages RENDUS, pas ceux qu'on vient de retirer.
		$counts['style']      = self::regenererStyleCorpus() ? 1 : 0;

		return [
			'task'    => 'reset',
			'counts'  => $counts,
			'message' => Text::sprintf(
				'MOD_CORPUS_START_RESET_DONE',
				$counts['articles'],
				$counts['categories'],
				$counts['fields'] + $counts['groups'],
				$counts['menu']
			),
		];
	}

	/**
	 * Supprime les éléments marqués d'une table via son modèle.
	 *
	 * Joomla refuse de supprimer un élément qui n'est pas à la corbeille :
	 * on le passe donc en état -2 avant.
	 *
	 * @param  string $component
	 * @param  string $modelName
	 * @param  string $table
	 * @param  string $stateColumn
	 *
	 * @return int
	 */
	protected static function deleteMarked(string $component, string $modelName, string $table, string $stateColumn): int
	{
		$ids = self::getMarkedIds($table);

		if (!$ids) {
			return 0;
		}

		$model = self::getModel($component, $modelName);

		self::trash($table, $stateColumn, $ids);

		$pks = $ids;
		$model->delete($pks);

		return count($ids) - count(self::getMarkedIds($table));
	}

	/**
	 * Supprime les catégories marquées, enfants d'abord.
	 *
	 * @return int
	 */
	protected static function deleteMarkedCategories(): int
	{
		$db = Factory::getContainer()->get('DatabaseDriver');

		$query = $db->getQuery(true)
			->select($db->quoteName('id'))
			->from($db->quoteName('#__categories'))
			->where(self::conditionMarque($db))
			->order($db->quoteName('level') . ' DESC');

		$db->setQuery($query);

		$ids = (array) $db->loadColumn();

		if (!$ids) {
			return 0;
		}

		$model   = self::getModel('com_categories', 'Category');
		$deleted = 0;

		foreach ($ids as $id) {
			self::trash('#__categories', 'published', [(int) $id]);

			$pks = [(int) $id];

			if ($model->delete($pks)) {
				$deleted++;
			}
		}

		return $deleted;
	}

	/**
	 * Passe des lignes à l'état corbeille (-2), condition de suppression.
	 *
	 * @param  string $table
	 * @param  string $column
	 * @param  int[]  $ids
	 *
	 * @return void
	 */
	protected static function trash(string $table, string $column, array $ids): void
	{
		$ids = array_map('intval', $ids);

		if (!$ids) {
			return;
		}

		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->update($db->quoteName($table))
			->set($db->quoteName($column) . ' = -2')
			->whereIn($db->quoteName('id'), $ids);

		$db->setQuery($query)->execute();
	}

	/**
	 * Identifiants des lignes marquées d'une table.
	 *
	 * @param  string $table
	 *
	 * @return int[]
	 */
	protected static function getMarkedIds(string $table): array
	{
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName('id'))
			->from($db->quoteName($table))
			->where(self::conditionMarque($db));

		$db->setQuery($query);

		return array_map('intval', (array) $db->loadColumn());
	}

	/**
	 * La condition SQL qui désigne ce que le module a posé.
	 *
	 * UN SCÉNARIO VISÉ, ON EST EXACT ; sinon on prend large. La forme large
	 * retrouve aussi les notes sans suffixe, celles des versions du module
	 * antérieures au retrait sélectif : une démonstration installée avant ce
	 * jour reste retirable par le bouton global.
	 *
	 * @param  object $db
	 *
	 * @return string
	 */
	protected static function conditionMarque($db): string
	{
		if (self::$scenario !== '') {
			return $db->quoteName('note') . ' = ' . $db->quote(self::marker());
		}

		return $db->quoteName('note') . ' LIKE ' . $db->quote(self::MARKER . '%');
	}

	/**
	 * Nombre de lignes marquées d'une table.
	 *
	 * @param  string $table
	 *
	 * @return int
	 */
	protected static function countMarked(string $table): int
	{
		return count(self::getMarkedIds($table));
	}

	// =====================================================================
	// OUTILS
	// =====================================================================

	/**
	 * Renvoie un modèle d'administration d'un composant.
	 *
	 * @param  string $component
	 * @param  string $name
	 *
	 * @return \Joomla\CMS\MVC\Model\AdminModel
	 * @throws Exception
	 */
	protected static function getModel(string $component, string $name)
	{
		$model = Factory::getApplication()
			->bootComponent($component)
			->getMVCFactory()
			->createModel($name, 'Administrator', ['ignore_request' => true]);

		if (!$model) {
			throw new Exception('Modèle introuvable : ' . $component . '/' . $name, 500);
		}

		return $model;
	}

	/**
	 * Identifiant d'extension d'un composant, pour les éléments de menu.
	 *
	 * @param  string $element
	 *
	 * @return int
	 */
	protected static function getComponentId(string $element): int
	{
		$db    = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true)
			->select($db->quoteName('extension_id'))
			->from($db->quoteName('#__extensions'))
			->where($db->quoteName('element') . ' = :element')
			->where($db->quoteName('type') . ' = ' . $db->quote('component'))
			->bind(':element', $element);

		$db->setQuery($query);

		return (int) $db->loadResult();
	}
}
