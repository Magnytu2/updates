<?php

/**
 * @package     Opus
 * @copyright   Copyright (C) 2026 joomanji.eu
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *
 * LE PAQUET ALLUME SES PLUGINS ET ECRIT LA NOTE DES BLOCS.
 *
 * Joomla installe un plugin eteint. Sans ceci, « Opus : poser un bloc »
 * n'apparaissait nulle part apres l'installation (banc, 10 octobre 2026).
 * Un plugin n'est allume qu'a sa premiere arrivee : une mise a jour respecte
 * le choix de qui l'aurait eteint. La premiere arrivee se lit dans la base,
 * avant l'installation, plugin par plugin : le plugin de contenu, nouveau en
 * 1.5.627, s'allume donc aussi lors d'une mise a jour du paquet. (En 1.5.627,
 * lu par la version du paquet, il restait eteint sur le banc.)
 *
 * A chaque installation ou mise a jour, la note de tous les blocs Opus est
 * recalculee (« Article 3 : Titre », lu dans la liste des modules).
 *
 * DEPUIS 1.5.654 (16 octobre 2026) :
 *  - VERROU : installation et mise a jour refusees sur un Joomla plus ancien
 *    que 6.2.0 (CLAUDE.md commun, § 10, « Quelles versions de Joomla nous
 *    suivons »). Le site garde intacte la version d'Opus qu'il avait. La
 *    desinstallation reste libre ;
 *  - PASSAGE DU MODULE SEUL AU PAQUET : le serveur de mises a jour est celui
 *    du paquet (pkg_opus.xml). La fiche de l'ancien serveur du module seul
 *    (mod_opus.xml), qui reste attachee a mod_opus sur un site qui avait le
 *    module seul, est retiree en postflight. Sinon Joomla proposerait deux
 *    mises a jour pour la meme chose.
 *
 * DEPUIS 1.5.931 (23 octobre 2026) : LES FICHES DE MISE A JOUR DES AUTRES.
 * Vu sur joomanji.eu : la fiche d'Iris s'appelait encore « Iris » mais
 * pointait vers pkg_opus.xml et etait rattachee a Opus. Iris ne recevait plus
 * rien (reste en 3.0.066). Le mecanisme est celui deja decrit dans le script
 * d'Iris : quand aucune fiche ne porte l'adresse du manifeste et que
 * l'extension est deja reliee a une fiche (lien orphelin laisse par une
 * extension desinstallee qui avait le meme extension_id), Joomla REECRIT
 * l'adresse de cette fiche au lieu d'en creer une. Le paquet Opus, installe
 * pour la premiere fois le 16 octobre, a pris ainsi la fiche d'Iris.
 * Deux gardes, en postflight, donc avant que Joomla traite les serveurs du
 * manifeste :
 *  - Opus se detache de toute fiche qui ne porte pas son adresse : il ne peut
 *    plus reecrire celle d'un autre ;
 *  - chaque produit Joomanji installe retrouve une fiche a sa propre adresse,
 *    recreee si besoin. C'est par Opus qu'on atteint un site deja touche,
 *    puisque sa fiche a lui marche. Une fiche qui ne porte pas la bonne
 *    adresse est detachee du produit ; elle n'est retiree que si plus rien
 *    ne s'y rattache.
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\Installer;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;

// Joomla n'emploie l'objet rendu que s'il declare InstallerScriptInterface ;
// sans elle, il cherche une classe pkg_opusInstallerScript et ne lance rien
// (1.5.627 : ni allumage ni note sur le banc). Corrige en 1.5.630.
return new class () implements InstallerScriptInterface {
    public function install(InstallerAdapter $parent): bool
    {
        return true;
    }

    public function update(InstallerAdapter $parent): bool
    {
        return true;
    }

    public function uninstall(InstallerAdapter $parent): bool
    {
        return true;
    }

    /** Les groupes dont le plugin Opus n'existait pas encore avant ce paquet. */
    private array $nouveaux = [];

    /** La version de Joomla en dessous de laquelle Opus refuse de s'installer. */
    private const JOOMLA_MINIMUM = '6.2.0';

    /** L'adresse du serveur du module seul, abandonnee pour celle du paquet. */
    private const ANCIEN_SERVEUR = 'https://magnytu2.github.io/updates/mod_opus.xml';

    /** Le serveur des produits Joomanji. */
    private const SERVEUR = 'https://magnytu2.github.io/updates/';

    /**
     * Les produits Joomanji et l'adresse de leur fiche : [type, dossier,
     * element, fichier xml, nom de la fiche]. Opus en tete.
     */
    private const PRODUITS = [
        ['package', '', 'pkg_opus', 'pkg_opus.xml', 'Opus'],
        ['package', '', 'pkg_iris', 'pkg_iris.xml', 'Iris'],
        ['package', '', 'pkg_formulus', 'pkg_formulus.xml', 'Formulus'],
        ['package', '', 'pkg_corpus', 'pkg_corpus.xml', 'Corpus'],
        ['package', '', 'pkg_astus', 'pkg_astus.xml', 'Astus'],
        ['package', '', 'pkg_tikus', 'pkg_tikus.xml', 'Tikus'],
        ['plugin', 'editors', 'markus', 'plg_editors_markus.xml', 'Markus Editor'],
    ];

    public function preflight(string $type, InstallerAdapter $parent): bool
    {
        if ($type !== 'uninstall' && version_compare(JVERSION, self::JOOMLA_MINIMUM, '<')) {
            $this->refuser($parent);

            return false;
        }

        $db = Factory::getContainer()->get(DatabaseInterface::class);

        foreach (['editors-xtd', 'system'] as $groupe) {
            $query = $db->getQuery(true)
                ->select('COUNT(*)')
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                ->where($db->quoteName('folder') . ' = ' . $db->quote($groupe))
                ->where($db->quoteName('element') . ' = ' . $db->quote('opus'));

            if (!(int) $db->setQuery($query)->loadResult()) {
                $this->nouveaux[] = $groupe;
            }
        }

        return true;
    }

    public function postflight(string $type, InstallerAdapter $parent): bool
    {
        $db = Factory::getContainer()->get(DatabaseInterface::class);

        foreach ($this->nouveaux as $groupe) {
            $this->allumer($db, $groupe);
        }

        $this->ancienContenu($db);

        if ($type !== 'uninstall') {
            try {
                $this->ancienServeur($db);
            } catch (\Throwable $e) {
                // Au pire, le site voit encore l'ancienne adresse : sans danger.
            }

            foreach (self::PRODUITS as $produit) {
                try {
                    $this->remettreFiche($db, $produit, $produit[2] === 'pkg_opus');
                } catch (\Throwable $e) {
                    // Une fiche qu'on n'a pas pu remettre ne doit pas faire
                    // echouer l'installation d'Opus.
                }
            }
        }

        $classe = 'Joomanji\\Plugin\\System\\Opus\\Extension\\Opus';
        $source = JPATH_PLUGINS . '/system/opus/src/Extension/Opus.php';

        if (!class_exists($classe) && is_file($source)) {
            require_once $source;
        }

        if (class_exists($classe)) {
            try {
                $classe::tous($db);
            } catch (\Throwable $e) {
                // La note n'est qu'une aide : l'installation ne doit pas echouer pour elle.
                Factory::getApplication()->enqueueMessage('Opus, note des blocs : ' . $e->getMessage(), 'warning');
            }
        } else {
            Factory::getApplication()->enqueueMessage('Opus, note des blocs : plugin de contenu introuvable', 'warning');
        }

        return true;
    }

    /**
     * LE VERROU : un message clair, dans la langue du site, puis le refus.
     * Le fichier de langue du paquet n'est pas encore installe : on le lit
     * dans le paquet en cours d'installation. Un message de secours en
     * francais prend le relais si la clef reste brute.
     */
    private function refuser(InstallerAdapter $parent): void
    {
        $version = (string) ($parent->getManifest()->version ?? '');
        $cle     = 'PKG_OPUS_ERREUR_JOOMLA_TROP_ANCIEN';
        $message = '';

        try {
            $app    = Factory::getApplication();
            $source = $parent->getParent()->getPath('source');

            if ($source) {
                $app->getLanguage()->load('pkg_opus.sys', $source, null, false, true);
            }

            $message = Text::sprintf($cle, $version);

            if ($message === '' || strpos($message, $cle) === 0) {
                $message = '';
            }

            if ($message === '') {
                $message = sprintf("Opus %s demande Joomla 6.2 ou plus récent. Mettez d'abord Joomla à jour.", $version);
            }

            $app->enqueueMessage($message, 'error');
        } catch (\Throwable $e) {
            // Sans application, le refus suffit.
        }
    }

    /**
     * L'ANCIEN SERVEUR DU MODULE SEUL (mod_opus.xml), retire d'un site qui
     * passe au paquet : la fiche, ses liens a des extensions et les mises a
     * jour deja trouvees par elle. Rien ne se passe sur un site qui ne l'a
     * pas. Le serveur du paquet est pose par Joomla apres ce postflight.
     */
    private function ancienServeur(DatabaseInterface $db): void
    {
        $adresse = self::ANCIEN_SERVEUR;
        $query   = $db->getQuery(true)
            ->select($db->quoteName('update_site_id'))
            ->from($db->quoteName('#__update_sites'))
            ->where($db->quoteName('location') . ' = :adresse')
            ->bind(':adresse', $adresse);
        $sites = array_map('intval', $db->setQuery($query)->loadColumn());

        foreach ($sites as $site) {
            foreach (['#__update_sites_extensions', '#__updates', '#__update_sites'] as $table) {
                $query = $db->getQuery(true)
                    ->delete($db->quoteName($table))
                    ->where($db->quoteName('update_site_id') . ' = :site')
                    ->bind(':site', $site, ParameterType::INTEGER);
                $db->setQuery($query)->execute();
            }
        }
    }

    /**
     * UNE FICHE A SA PROPRE ADRESSE pour un produit Joomanji installe.
     *
     * 1. Le produit est detache des fiches qui ne portent pas son adresse
     *    (et les mises a jour trouvees par elles pour lui sont effacees).
     *    La fiche n'est retiree que si plus aucune extension n'y est reliee.
     * 2. Pour Opus ($soiMeme), on s'arrete la : Joomla, juste apres ce
     *    postflight, cree ou retrouve sa fiche, et ne peut plus en reecrire
     *    une autre.
     * 3. Pour les autres : s'il n'est relie a aucune fiche a son adresse, il
     *    est relie a celle qui existe deja a cette adresse, ou a une fiche
     *    neuve. Une fiche a la bonne adresse reprend aussi son nom.
     */
    private function remettreFiche(DatabaseInterface $db, array $produit, bool $soiMeme): void
    {
        [$type, $dossier, $element, $xml, $nom] = $produit;
        $adresse = self::SERVEUR . $xml;

        $query = $db->getQuery(true)
            ->select($db->quoteName('extension_id'))
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = :type')
            ->where($db->quoteName('element') . ' = :element')
            ->bind(':type', $type)
            ->bind(':element', $element);

        if ($dossier !== '') {
            $query->where($db->quoteName('folder') . ' = :dossier')->bind(':dossier', $dossier);
        }

        $eid = (int) $db->setQuery($query)->loadResult();

        if ($eid <= 0) {
            return;
        }

        // Les fiches reliees au produit, avec leur adresse.
        $query = $db->getQuery(true)
            ->select($db->quoteName(['s.update_site_id', 's.location', 's.name']))
            ->from($db->quoteName('#__update_sites', 's'))
            ->join('INNER', $db->quoteName('#__update_sites_extensions', 'l'), $db->quoteName('l.update_site_id') . ' = ' . $db->quoteName('s.update_site_id'))
            ->where($db->quoteName('l.extension_id') . ' = :eid')
            ->bind(':eid', $eid, ParameterType::INTEGER);
        $reliees = $db->setQuery($query)->loadObjectList();

        $bonne = 0;

        foreach ($reliees as $fiche) {
            $site = (int) $fiche->update_site_id;

            if (trim((string) $fiche->location) === $adresse) {
                $bonne = $site;

                if ((string) $fiche->name !== $nom) {
                    $query = $db->getQuery(true)
                        ->update($db->quoteName('#__update_sites'))
                        ->set($db->quoteName('name') . ' = :nom')
                        ->where($db->quoteName('update_site_id') . ' = :site')
                        ->bind(':nom', $nom)
                        ->bind(':site', $site, ParameterType::INTEGER);
                    $db->setQuery($query)->execute();
                }

                continue;
            }

            // Fiche a une autre adresse : le produit s'en detache.
            foreach (['#__update_sites_extensions', '#__updates'] as $table) {
                $query = $db->getQuery(true)
                    ->delete($db->quoteName($table))
                    ->where($db->quoteName('update_site_id') . ' = :site')
                    ->where($db->quoteName('extension_id') . ' = :eid')
                    ->bind(':site', $site, ParameterType::INTEGER)
                    ->bind(':eid', $eid, ParameterType::INTEGER);
                $db->setQuery($query)->execute();
            }

            // Detachee de tout, la fiche ne sert plus a personne : elle est
            // retiree, sinon Joomla continuerait de la lire pour rien.
            $query = $db->getQuery(true)
                ->select('COUNT(*)')
                ->from($db->quoteName('#__update_sites_extensions'))
                ->where($db->quoteName('update_site_id') . ' = :site')
                ->bind(':site', $site, ParameterType::INTEGER);

            if (!(int) $db->setQuery($query)->loadResult()) {
                foreach (['#__updates', '#__update_sites'] as $table) {
                    $query = $db->getQuery(true)
                        ->delete($db->quoteName($table))
                        ->where($db->quoteName('update_site_id') . ' = :site')
                        ->bind(':site', $site, ParameterType::INTEGER);
                    $db->setQuery($query)->execute();
                }
            }
        }

        if ($soiMeme || $bonne > 0) {
            return;
        }

        // Une fiche existe-t-elle deja a cette adresse, reliee a personne ou
        // a un autre ? On la reprend plutot que d'en creer une seconde.
        $query = $db->getQuery(true)
            ->select($db->quoteName('update_site_id'))
            ->from($db->quoteName('#__update_sites'))
            ->where($db->quoteName('location') . ' = :adresse')
            ->bind(':adresse', $adresse)
            ->setLimit(1);
        $site = (int) $db->setQuery($query)->loadResult();

        if ($site <= 0) {
            $fiche = (object) [
                'name'                 => $nom,
                'type'                 => 'extension',
                'location'             => $adresse,
                'enabled'              => 1,
                'last_check_timestamp' => 0,
            ];
            $db->insertObject('#__update_sites', $fiche, 'update_site_id');
            $site = (int) $fiche->update_site_id;
        } else {
            $query = $db->getQuery(true)
                ->update($db->quoteName('#__update_sites'))
                ->set($db->quoteName('name') . ' = :nom')
                ->set($db->quoteName('enabled') . ' = 1')
                ->set($db->quoteName('last_check_timestamp') . ' = 0')
                ->where($db->quoteName('update_site_id') . ' = :site')
                ->bind(':nom', $nom)
                ->bind(':site', $site, ParameterType::INTEGER);
            $db->setQuery($query)->execute();
        }

        if ($site > 0) {
            $lien = (object) ['update_site_id' => $site, 'extension_id' => $eid];
            $db->insertObject('#__update_sites_extensions', $lien);
        }
    }

    /**
     * L'ANCIEN PLUGIN DE CONTENU (1.5.627 a 637) est remplace par le plugin
     * systeme : il est desinstalle. Au pire, s'il resiste, il est eteint,
     * pour ne pas travailler deux fois.
     */
    private function ancienContenu(DatabaseInterface $db): void
    {
        $query = $db->getQuery(true)
            ->select($db->quoteName('extension_id'))
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote('content'))
            ->where($db->quoteName('element') . ' = ' . $db->quote('opus'));

        $id = (int) $db->setQuery($query)->loadResult();

        if (!$id) {
            return;
        }

        try {
            // Hors du paquet d'abord : Joomla refuse de desinstaller seul un
            // element qui appartient encore a un paquet.
            $db->setQuery($db->getQuery(true)
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('package_id') . ' = 0')
                ->set($db->quoteName('enabled') . ' = 0')
                ->where($db->quoteName('extension_id') . ' = ' . $id))->execute();

            $installeur = new Installer();
            $installeur->setDatabase($db);
            $installeur->uninstall('plugin', $id);
        } catch (\Throwable $e) {
            // Il reste eteint : sans effet.
        }
    }

    private function allumer(DatabaseInterface $db, string $groupe): void
    {
        $query = $db->getQuery(true)
            ->update($db->quoteName('#__extensions'))
            ->set($db->quoteName('enabled') . ' = 1')
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote($groupe))
            ->where($db->quoteName('element') . ' = ' . $db->quote('opus'));

        $db->setQuery($query)->execute();
    }
};
